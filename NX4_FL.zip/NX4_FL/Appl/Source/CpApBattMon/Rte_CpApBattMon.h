/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApBattMon.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApBattMon
 *  Generation Time:  2023-04-20 13:52:19
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApBattMon> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPBATTMON_H
# define _RTE_CPAPBATTMON_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApBattMon_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApBattMon
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApBattMon, RTE_CONST, RTE_CONST) Rte_Inst_CpApBattMon; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApBattMon, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_Faultstatus_De_Faultstatus (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApBattMon_PP_BattMonData_De_BattMonData(P2CONST(BattMonData_t, AUTOMATIC, RTE_CPAPBATTMON_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApBattMon_PP_Faultstatus_De_Faultstatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) APP_Camera1_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) APP_Camera1_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(P2VAR(sint16, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) APP_EyeQTemperature1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(P2VAR(sint16, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) APP_EyeQTemperature2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_CPAPBATTMON_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_BattMonData_De_BattMonData Rte_Write_CpApBattMon_PP_BattMonData_De_BattMonData
# define Rte_Write_PP_Faultstatus_De_Faultstatus Rte_Write_CpApBattMon_PP_Faultstatus_De_Faultstatus


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1 Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2 Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1 Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2 Rte_Call_CpApBattMon_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2
# define Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON Rte_Call_CpApBattMon_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON




# define CpApBattMon_START_SEC_CODE
# include "CpApBattMon_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApBattMonInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApBattMonInit Re_CpApBattMonInit
FUNC(void, CpApBattMon_CODE) Re_CpApBattMonInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApBattMonMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_BattMonData_De_BattMonData(const BattMonData_t *data)
 *   Std_ReturnType Rte_Write_PP_Faultstatus_De_Faultstatus(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApBattMonMain Re_CpApBattMonMain
FUNC(void, CpApBattMon_CODE) Re_CpApBattMonMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApBattMon_STOP_SEC_CODE
# include "CpApBattMon_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EYEQDG_APP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPBATTMON_H */
