/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApPreCond_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPreCond
 *  Generation Time:  2023-04-20 13:52:47
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApPreCond> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPPRECOND_TYPE_H
# define _RTE_CPAPPRECOND_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_DNMT_VCAN_Rx
#  define RTE_MODETYPE_DNMT_VCAN_Rx
typedef uint8 Rte_ModeType_DNMT_VCAN_Rx;
# endif
# ifndef RTE_MODETYPE_DNMT_VCAN_Tx
#  define RTE_MODETYPE_DNMT_VCAN_Tx
typedef uint8 Rte_ModeType_DNMT_VCAN_Tx;
# endif
# ifndef RTE_MODETYPE_DcmControlDtcSetting
#  define RTE_MODETYPE_DcmControlDtcSetting
typedef uint8 Rte_ModeType_DcmControlDtcSetting;
# endif

# define RTE_MODE_CpApPreCond_DNMT_VCAN_Rx_RX_DISABLE (0U)
# ifndef RTE_MODE_DNMT_VCAN_Rx_RX_DISABLE
#  define RTE_MODE_DNMT_VCAN_Rx_RX_DISABLE (0U)
# endif
# define RTE_MODE_CpApPreCond_DNMT_VCAN_Rx_RX_ENABLE (1U)
# ifndef RTE_MODE_DNMT_VCAN_Rx_RX_ENABLE
#  define RTE_MODE_DNMT_VCAN_Rx_RX_ENABLE (1U)
# endif
# define RTE_TRANSITION_CpApPreCond_DNMT_VCAN_Rx (2U)
# ifndef RTE_TRANSITION_DNMT_VCAN_Rx
#  define RTE_TRANSITION_DNMT_VCAN_Rx (2U)
# endif

# define RTE_MODE_CpApPreCond_DNMT_VCAN_Tx_TX_DISABLE (0U)
# ifndef RTE_MODE_DNMT_VCAN_Tx_TX_DISABLE
#  define RTE_MODE_DNMT_VCAN_Tx_TX_DISABLE (0U)
# endif
# define RTE_MODE_CpApPreCond_DNMT_VCAN_Tx_TX_ENABLE (1U)
# ifndef RTE_MODE_DNMT_VCAN_Tx_TX_ENABLE
#  define RTE_MODE_DNMT_VCAN_Tx_TX_ENABLE (1U)
# endif
# define RTE_TRANSITION_CpApPreCond_DNMT_VCAN_Tx (2U)
# ifndef RTE_TRANSITION_DNMT_VCAN_Tx
#  define RTE_TRANSITION_DNMT_VCAN_Tx (2U)
# endif

# define RTE_MODE_CpApPreCond_DcmControlDtcSetting_ENABLEDTCSETTING (0U)
# ifndef RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING
#  define RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING (0U)
# endif
# define RTE_MODE_CpApPreCond_DcmControlDtcSetting_DISABLEDTCSETTING (1U)
# ifndef RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING
#  define RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING (1U)
# endif
# define RTE_TRANSITION_CpApPreCond_DcmControlDtcSetting (2U)
# ifndef RTE_TRANSITION_DcmControlDtcSetting
#  define RTE_TRANSITION_DcmControlDtcSetting (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPPRECOND_TYPE_H */
