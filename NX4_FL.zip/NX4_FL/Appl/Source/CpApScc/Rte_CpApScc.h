/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApScc.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApScc
 *  Generation Time:  2023-04-20 13:52:48
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApScc> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPSCC_H
# define _RTE_CPAPSCC_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApScc_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApScc
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApScc, RTE_CONST, RTE_CONST) Rte_Inst_CpApScc; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApScc, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_Core1ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo(P2VAR(SccCanSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccInput_De_SccInput(P2VAR(SccInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccInputFromFca_De_SccInputFromFca(P2VAR(SccInputFromFca_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccInputFromLss_De_SccInternalInFromLSS(P2VAR(SccInternalInFromLSS_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn01_De_SccDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn02_De_SccDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn03_De_SccDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn04_De_SccDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn05_De_SccDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccLogicDbgIn06_De_SccDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApScc_RP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo(P2VAR(SccRdrSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_MrmUxOutToIvc_De_MrmUxOutToIvc(P2CONST(MrmUxOutToIvc_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_MrmUxOutToLss_De_MrmUxOutToIvc(P2CONST(LssMrmUxOutToIvc_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut01_De_SccLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut02_De_SccLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut03_De_SccLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut04_De_SccLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut05_De_SccLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut06_De_SccLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut07_De_SccLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut08_De_SccLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut09_De_SccLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut10_De_SccLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut11_De_SccLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut12_De_SccLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut13_De_SccLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut14_De_SccLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut15_De_SccLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut16_De_SccLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut17_De_SccLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut18_De_SccLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut19_De_SccLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccLogicDbgOut20_De_SccLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccOutput_De_SccOutput(P2CONST(SccOutput_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApScc_PP_SccUxOutToIvc_De_SccUxOutToIvc(P2CONST(SccUxOutToIvc_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FrCmrFcfVd_getFrCmrFcfVd(P2VAR(FcfVd_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FrCmrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FrCmrFcfVru_getFrCmrFcfVru(P2VAR(FcfVru_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FrCmrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_RdrInfo_getRdrInfo(P2VAR(RdrInfo_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) Rdrmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_SccNvmData_ReadSccNvmData(P2VAR(SccNvmData_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) SccNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApScc_RP_SccNvmData_WriteSccNvmData(P2CONST(SccNvmData_t, AUTOMATIC, RTE_CPAPSCC_APPL_DATA) SccNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApScc_RP_Core1ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo Rte_Read_CpApScc_RP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo
# define Rte_Read_RP_SccInput_De_SccInput Rte_Read_CpApScc_RP_SccInput_De_SccInput
# define Rte_Read_RP_SccInputFromFca_De_SccInputFromFca Rte_Read_CpApScc_RP_SccInputFromFca_De_SccInputFromFca
# define Rte_Read_RP_SccInputFromLss_De_SccInternalInFromLSS Rte_Read_CpApScc_RP_SccInputFromLss_De_SccInternalInFromLSS
# define Rte_Read_RP_SccLogicDbgIn01_De_SccDbgIn01 Rte_Read_CpApScc_RP_SccLogicDbgIn01_De_SccDbgIn01
# define Rte_Read_RP_SccLogicDbgIn02_De_SccDbgIn02 Rte_Read_CpApScc_RP_SccLogicDbgIn02_De_SccDbgIn02
# define Rte_Read_RP_SccLogicDbgIn03_De_SccDbgIn03 Rte_Read_CpApScc_RP_SccLogicDbgIn03_De_SccDbgIn03
# define Rte_Read_RP_SccLogicDbgIn04_De_SccDbgIn04 Rte_Read_CpApScc_RP_SccLogicDbgIn04_De_SccDbgIn04
# define Rte_Read_RP_SccLogicDbgIn05_De_SccDbgIn05 Rte_Read_CpApScc_RP_SccLogicDbgIn05_De_SccDbgIn05
# define Rte_Read_RP_SccLogicDbgIn06_De_SccDbgIn06 Rte_Read_CpApScc_RP_SccLogicDbgIn06_De_SccDbgIn06
# define Rte_Read_RP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo Rte_Read_CpApScc_RP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_MrmUxOutToIvc_De_MrmUxOutToIvc Rte_Write_CpApScc_PP_MrmUxOutToIvc_De_MrmUxOutToIvc
# define Rte_Write_PP_MrmUxOutToLss_De_MrmUxOutToIvc Rte_Write_CpApScc_PP_MrmUxOutToLss_De_MrmUxOutToIvc
# define Rte_Write_PP_SccLogicDbgOut01_De_SccLogicDbgOutput01 Rte_Write_CpApScc_PP_SccLogicDbgOut01_De_SccLogicDbgOutput01
# define Rte_Write_PP_SccLogicDbgOut02_De_SccLogicDbgOutput02 Rte_Write_CpApScc_PP_SccLogicDbgOut02_De_SccLogicDbgOutput02
# define Rte_Write_PP_SccLogicDbgOut03_De_SccLogicDbgOutput03 Rte_Write_CpApScc_PP_SccLogicDbgOut03_De_SccLogicDbgOutput03
# define Rte_Write_PP_SccLogicDbgOut04_De_SccLogicDbgOutput04 Rte_Write_CpApScc_PP_SccLogicDbgOut04_De_SccLogicDbgOutput04
# define Rte_Write_PP_SccLogicDbgOut05_De_SccLogicDbgOutput05 Rte_Write_CpApScc_PP_SccLogicDbgOut05_De_SccLogicDbgOutput05
# define Rte_Write_PP_SccLogicDbgOut06_De_SccLogicDbgOutput06 Rte_Write_CpApScc_PP_SccLogicDbgOut06_De_SccLogicDbgOutput06
# define Rte_Write_PP_SccLogicDbgOut07_De_SccLogicDbgOutput07 Rte_Write_CpApScc_PP_SccLogicDbgOut07_De_SccLogicDbgOutput07
# define Rte_Write_PP_SccLogicDbgOut08_De_SccLogicDbgOutput08 Rte_Write_CpApScc_PP_SccLogicDbgOut08_De_SccLogicDbgOutput08
# define Rte_Write_PP_SccLogicDbgOut09_De_SccLogicDbgOutput09 Rte_Write_CpApScc_PP_SccLogicDbgOut09_De_SccLogicDbgOutput09
# define Rte_Write_PP_SccLogicDbgOut10_De_SccLogicDbgOutput10 Rte_Write_CpApScc_PP_SccLogicDbgOut10_De_SccLogicDbgOutput10
# define Rte_Write_PP_SccLogicDbgOut11_De_SccLogicDbgOutput11 Rte_Write_CpApScc_PP_SccLogicDbgOut11_De_SccLogicDbgOutput11
# define Rte_Write_PP_SccLogicDbgOut12_De_SccLogicDbgOutput12 Rte_Write_CpApScc_PP_SccLogicDbgOut12_De_SccLogicDbgOutput12
# define Rte_Write_PP_SccLogicDbgOut13_De_SccLogicDbgOutput13 Rte_Write_CpApScc_PP_SccLogicDbgOut13_De_SccLogicDbgOutput13
# define Rte_Write_PP_SccLogicDbgOut14_De_SccLogicDbgOutput14 Rte_Write_CpApScc_PP_SccLogicDbgOut14_De_SccLogicDbgOutput14
# define Rte_Write_PP_SccLogicDbgOut15_De_SccLogicDbgOutput15 Rte_Write_CpApScc_PP_SccLogicDbgOut15_De_SccLogicDbgOutput15
# define Rte_Write_PP_SccLogicDbgOut16_De_SccLogicDbgOutput16 Rte_Write_CpApScc_PP_SccLogicDbgOut16_De_SccLogicDbgOutput16
# define Rte_Write_PP_SccLogicDbgOut17_De_SccLogicDbgOutput17 Rte_Write_CpApScc_PP_SccLogicDbgOut17_De_SccLogicDbgOutput17
# define Rte_Write_PP_SccLogicDbgOut18_De_SccLogicDbgOutput18 Rte_Write_CpApScc_PP_SccLogicDbgOut18_De_SccLogicDbgOutput18
# define Rte_Write_PP_SccLogicDbgOut19_De_SccLogicDbgOutput19 Rte_Write_CpApScc_PP_SccLogicDbgOut19_De_SccLogicDbgOutput19
# define Rte_Write_PP_SccLogicDbgOut20_De_SccLogicDbgOutput20 Rte_Write_CpApScc_PP_SccLogicDbgOut20_De_SccLogicDbgOutput20
# define Rte_Write_PP_SccOutput_De_SccOutput Rte_Write_CpApScc_PP_SccOutput_De_SccOutput
# define Rte_Write_PP_SccUxOutToIvc_De_SccUxOutToIvc Rte_Write_CpApScc_PP_SccUxOutToIvc_De_SccUxOutToIvc


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApScc_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApScc_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApScc_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApScc_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd Rte_Call_CpApScc_RP_FrCmrFcfVd_getFrCmrFcfVd
# define Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru Rte_Call_CpApScc_RP_FrCmrFcfVru_getFrCmrFcfVru
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApScc_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApScc_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApScc_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_RdrInfo_getRdrInfo Rte_Call_CpApScc_RP_RdrInfo_getRdrInfo
# define Rte_Call_RP_SccNvmData_ReadSccNvmData Rte_Call_CpApScc_RP_SccNvmData_ReadSccNvmData
# define Rte_Call_RP_SccNvmData_WriteSccNvmData Rte_Call_CpApScc_RP_SccNvmData_WriteSccNvmData




# define CpApScc_START_SEC_CODE
# include "CpApScc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccCc
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccCc Re_CpApSccCc
FUNC(void, CpApScc_CODE) Re_CpApSccCc(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_SccNvmData_ReadSccNvmData(SccNvmData_t *SccNvmData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SccNvmData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccInit Re_CpApSccInit
FUNC(void, CpApScc_CODE) Re_CpApSccInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccIsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccIsp Re_CpApSccIsp
FUNC(void, CpApScc_CODE) Re_CpApSccIsp(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccOsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccOsp Re_CpApSccOsp
FUNC(void, CpApScc_CODE) Re_CpApSccOsp(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccRed
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo(SccCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_SccInput_De_SccInput(SccInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccInputFromFca_De_SccInputFromFca(SccInputFromFca_t *data)
 *   Std_ReturnType Rte_Read_RP_SccInputFromLss_De_SccInternalInFromLSS(SccInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn01_De_SccDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn02_De_SccDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn03_De_SccDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn04_De_SccDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn05_De_SccDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgIn06_De_SccDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo(SccRdrSigFailSafeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_RdrInfo_getRdrInfo(RdrInfo_t *Rdrmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_RdrInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccRed Re_CpApSccRed
FUNC(void, CpApScc_CODE) Re_CpApSccRed(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccSm
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccSm Re_CpApSccSm
FUNC(void, CpApScc_CODE) Re_CpApSccSm(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccTid
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_MrmUxOutToIvc_De_MrmUxOutToIvc(const MrmUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_MrmUxOutToLss_De_MrmUxOutToIvc(const LssMrmUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut01_De_SccLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut02_De_SccLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut03_De_SccLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut04_De_SccLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut05_De_SccLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut06_De_SccLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut07_De_SccLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut08_De_SccLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut09_De_SccLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut10_De_SccLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut11_De_SccLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut12_De_SccLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut13_De_SccLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut14_De_SccLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut15_De_SccLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut16_De_SccLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut17_De_SccLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut18_De_SccLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut19_De_SccLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccLogicDbgOut20_De_SccLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccOutput_De_SccOutput(const SccOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccUxOutToIvc_De_SccUxOutToIvc(const SccUxOutToIvc_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_SccNvmData_WriteSccNvmData(const SccNvmData_t *SccNvmData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SccNvmData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccTid Re_CpApSccTid
FUNC(void, CpApScc_CODE) Re_CpApSccTid(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccTos
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *     and not in Mode(s) <SccFunctionalityDisabled>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccTos Re_CpApSccTos
FUNC(void, CpApScc_CODE) Re_CpApSccTos(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApSccVersionReq
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_SccAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApSccVersionReq(SccAppVersionInfo_t *SccAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_SccAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApSccVersionReq Re_CpApSccVersionReq
FUNC(Std_ReturnType, CpApScc_CODE) Re_CpApSccVersionReq(P2VAR(SccAppVersionInfo_t, AUTOMATIC, RTE_CPAPSCC_APPL_VAR) SccAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApScc_STOP_SEC_CODE
# include "CpApScc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_IF_RdrInfo_ReturnType (1U)

# define RTE_E_IF_SccAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_SccNvmData_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPSCC_H */
