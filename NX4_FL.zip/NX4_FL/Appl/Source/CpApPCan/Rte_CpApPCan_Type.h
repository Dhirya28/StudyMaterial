/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApPCan_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPCan
 *  Generation Time:  2023-04-20 13:52:45
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApPCan> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPPCAN_TYPE_H
# define _RTE_CPAPPCAN_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"

/**********************************************************************************************************************
 * Range, Invalidation, Enumeration and Bit Field Definitions
 *********************************************************************************************************************/

# ifndef Cx0_Not_defined
#  define Cx0_Not_defined (0U)
# endif

# ifndef Cx1_Stationary
#  define Cx1_Stationary (1U)
# endif

# ifndef Cx2_Moving
#  define Cx2_Moving (2U)
# endif

# ifndef Cx3_Stopped
#  define Cx3_Stopped (3U)
# endif

# ifndef Cx4_Reserved
#  define Cx4_Reserved (4U)
# endif

# ifndef Cx5_Reserved
#  define Cx5_Reserved (5U)
# endif

# ifndef Cx6_Not_used
#  define Cx6_Not_used (6U)
# endif

# ifndef Cx7_Error_Indicator
#  define Cx7_Error_Indicator (7U)
# endif

# ifndef Cx0_Undecided
#  define Cx0_Undecided (0U)
# endif

# ifndef Cx1_New_Target
#  define Cx1_New_Target (1U)
# endif

# ifndef Cx2_Updated_Target
#  define Cx2_Updated_Target (2U)
# endif

# ifndef Cx3_Memory_Tartget
#  define Cx3_Memory_Tartget (3U)
# endif

# ifndef Cx0_Engine_Stop
#  define Cx0_Engine_Stop (0U)
# endif

# ifndef Cx1_Cranking
#  define Cx1_Cranking (1U)
# endif

# ifndef Cx2_Stalled
#  define Cx2_Stalled (2U)
# endif

# ifndef Cx3_Running
#  define Cx3_Running (3U)
# endif

# ifndef Cx6_Reserved
#  define Cx6_Reserved (6U)
# endif

# ifndef Cx7_Fault
#  define Cx7_Fault (7U)
# endif

# ifndef Cx0_Off
#  define Cx0_Off (0U)
# endif

# ifndef Cx1_On
#  define Cx1_On (1U)
# endif

# ifndef Cx0_P
#  define Cx0_P (0U)
# endif

# ifndef Cx1_L
#  define Cx1_L (1U)
# endif

# ifndef Cx2_2
#  define Cx2_2 (2U)
# endif

# ifndef Cx3_3
#  define Cx3_3 (3U)
# endif

# ifndef Cx4_DS_Mode
#  define Cx4_DS_Mode (4U)
# endif

# ifndef Cx5_D
#  define Cx5_D (5U)
# endif

# ifndef Cx6_N
#  define Cx6_N (6U)
# endif

# ifndef Cx7_R
#  define Cx7_R (7U)
# endif

# ifndef Cx8_sportsmode_manual_paddleshift
#  define Cx8_sportsmode_manual_paddleshift (8U)
# endif

# ifndef Cx9_Not_Display_at_Cluster
#  define Cx9_Not_Display_at_Cluster (9U)
# endif

# ifndef CxA_Sub_Rom_Communication
#  define CxA_Sub_Rom_Communication (10U)
# endif

# ifndef CxB_Sub_Rom_Communication_Error
#  define CxB_Sub_Rom_Communication_Error (11U)
# endif

# ifndef CxC_Paddle_shift_D_position_
#  define CxC_Paddle_shift_D_position_ (12U)
# endif

# ifndef CxD_Reserved
#  define CxD_Reserved (13U)
# endif

# ifndef CxE_Intermediate_Position
#  define CxE_Intermediate_Position (14U)
# endif

# ifndef CxF_fault
#  define CxF_fault (15U)
# endif

# ifndef Cx0_No_Coding
#  define Cx0_No_Coding (0U)
# endif

# ifndef Cx1_Internal_combustion_engine
#  define Cx1_Internal_combustion_engine (1U)
# endif

# ifndef Cx2_HEV
#  define Cx2_HEV (2U)
# endif

# ifndef Cx3_PHEV
#  define Cx3_PHEV (3U)
# endif

# ifndef Cx4_EV
#  define Cx4_EV (4U)
# endif

# ifndef Cx7_Reserved
#  define Cx7_Reserved (7U)
# endif

# ifndef Cx8_sports_mode_manual_shift_paddle_shift
#  define Cx8_sports_mode_manual_shift_paddle_shift (8U)
# endif



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_BswMPCAN_RteModeDclGroup
#  define RTE_MODETYPE_BswMPCAN_RteModeDclGroup
typedef uint8 Rte_ModeType_BswMPCAN_RteModeDclGroup;
# endif

# define RTE_MODE_CpApPCan_BswMPCAN_RteModeDclGroup_PCANBusoff (0U)
# ifndef RTE_MODE_BswMPCAN_RteModeDclGroup_PCANBusoff
#  define RTE_MODE_BswMPCAN_RteModeDclGroup_PCANBusoff (0U)
# endif
# define RTE_MODE_CpApPCan_BswMPCAN_RteModeDclGroup_PCANNormal (1U)
# ifndef RTE_MODE_BswMPCAN_RteModeDclGroup_PCANNormal
#  define RTE_MODE_BswMPCAN_RteModeDclGroup_PCANNormal (1U)
# endif
# define RTE_TRANSITION_CpApPCan_BswMPCAN_RteModeDclGroup (2U)
# ifndef RTE_TRANSITION_BswMPCAN_RteModeDclGroup
#  define RTE_TRANSITION_BswMPCAN_RteModeDclGroup (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPPCAN_TYPE_H */
