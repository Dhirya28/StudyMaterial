/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApUds_sid31.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUds_sid31
 *  Generation Time:  2023-04-20 13:53:25
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApUds_sid31>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Dcm_NegativeResponseCodeType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Dcm_OpStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApUds_sid31.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * CpApDiag_Status: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Dcm_NegativeResponseCodeType: Enumeration of integer in interval [0...254] with enumerators
 *   DCM_E_POSITIVERESPONSE (0U)
 *   DCM_E_GENERALREJECT (16U)
 *   DCM_E_SERVICENOTSUPPORTED (17U)
 *   DCM_E_SUBFUNCTIONNOTSUPPORTED (18U)
 *   DCM_E_INCORRECTMESSAGELENGTHORINVALIDFORMAT (19U)
 *   DCM_E_RESPONSETOOLONG (20U)
 *   DCM_E_BUSYREPEATREQUEST (33U)
 *   DCM_E_CONDITIONSNOTCORRECT (34U)
 *   DCM_E_REQUESTSEQUENCEERROR (36U)
 *   DCM_E_NORESPONSEFROMSUBNETCOMPONENT (37U)
 *   DCM_E_FAILUREPREVENTSEXECUTIONOFREQUESTEDACTION (38U)
 *   DCM_E_REQUESTOUTOFRANGE (49U)
 *   DCM_E_SECURITYACCESSDENIED (51U)
 *   DCM_E_INVALIDKEY (53U)
 *   DCM_E_EXCEEDNUMBEROFATTEMPTS (54U)
 *   DCM_E_REQUIREDTIMEDELAYNOTEXPIRED (55U)
 *   DCM_E_UPLOADDOWNLOADNOTACCEPTED (112U)
 *   DCM_E_TRANSFERDATASUSPENDED (113U)
 *   DCM_E_GENERALPROGRAMMINGFAILURE (114U)
 *   DCM_E_WRONGBLOCKSEQUENCECOUNTER (115U)
 *   DCM_E_REQUESTCORRECTLYRECEIVEDRESPONSEPENDING (120U)
 *   DCM_E_SUBFUNCTIONNOTSUPPORTEDINACTIVESESSION (126U)
 *   DCM_E_SERVICENOTSUPPORTEDINACTIVESESSION (127U)
 *   DCM_E_RPMTOOHIGH (129U)
 *   DCM_E_RPMTOOLOW (130U)
 *   DCM_E_ENGINEISRUNNING (131U)
 *   DCM_E_ENGINEISNOTRUNNING (132U)
 *   DCM_E_ENGINERUNTIMETOOLOW (133U)
 *   DCM_E_TEMPERATURETOOHIGH (134U)
 *   DCM_E_TEMPERATURETOOLOW (135U)
 *   DCM_E_VEHICLESPEEDTOOHIGH (136U)
 *   DCM_E_VEHICLESPEEDTOOLOW (137U)
 *   DCM_E_THROTTLE_PEDALTOOHIGH (138U)
 *   DCM_E_THROTTLE_PEDALTOOLOW (139U)
 *   DCM_E_TRANSMISSIONRANGENOTINNEUTRAL (140U)
 *   DCM_E_TRANSMISSIONRANGENOTINGEAR (141U)
 *   DCM_E_BRAKESWITCH_NOTCLOSED (143U)
 *   DCM_E_SHIFTERLEVERNOTINPARK (144U)
 *   DCM_E_TORQUECONVERTERCLUTCHLOCKED (145U)
 *   DCM_E_VOLTAGETOOHIGH (146U)
 *   DCM_E_VOLTAGETOOLOW (147U)
 *   DCM_E_VMSCNC_0 (240U)
 *   DCM_E_VMSCNC_1 (241U)
 *   DCM_E_VMSCNC_2 (242U)
 *   DCM_E_VMSCNC_3 (243U)
 *   DCM_E_VMSCNC_4 (244U)
 *   DCM_E_VMSCNC_5 (245U)
 *   DCM_E_VMSCNC_6 (246U)
 *   DCM_E_VMSCNC_7 (247U)
 *   DCM_E_VMSCNC_8 (248U)
 *   DCM_E_VMSCNC_9 (249U)
 *   DCM_E_VMSCNC_A (250U)
 *   DCM_E_VMSCNC_B (251U)
 *   DCM_E_VMSCNC_C (252U)
 *   DCM_E_VMSCNC_D (253U)
 *   DCM_E_VMSCNC_E (254U)
 * Dcm_OpStatusType: Enumeration of integer in interval [0...64] with enumerators
 *   DCM_INITIAL (0U)
 *   DCM_PENDING (1U)
 *   DCM_CANCEL (2U)
 *   DCM_FORCE_RCRRP_OK (3U)
 *   DCM_FORCE_RCRRP_NOT_OK (64U)
 *
 * Array Types:
 * ============
 * Dcm_Data15ByteType: Array with 15 element(s) of type uint8
 * Dcm_Data2ByteType: Array with 2 element(s) of type uint8
 * Dcm_Data3ByteType: Array with 3 element(s) of type uint8
 *
 *********************************************************************************************************************/


#define CpApUds_sid31_START_SEC_CODE
#include "CpApUds_sid31_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_40ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_40ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_40ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_40ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_UpdateTAC2Status
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateTAC2Status> of PortPrototype <PP_UpdateTAC2Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApUds_sid31_UpdateTAC2Status(uint8 status_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_UpdateTAC2Status_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_UpdateTAC2Status(uint8 status_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUds_sid31_UpdateTAC2Status
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Buffer(uint16 *CLB_DYN_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_CRC(uint32 *CLB_DYN_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height(uint16 *CLB_DYN_Cam_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence(uint8 *CLB_DYN_Cam_Height_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Error(uint8 *CLB_DYN_Cam_Height_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Progress(uint8 *CLB_DYN_Cam_Height_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Status(uint8 *CLB_DYN_Cam_Height_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_Buffer(uint32 *CLB_DYN_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_CRC(uint32 *CLB_DYN_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pause_Reason(uint8 *CLB_DYN_Pause_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Confidence(uint8 *CLB_DYN_Pitch_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Deg(float32 *CLB_DYN_Pitch_Deg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Error(uint8 *CLB_DYN_Pitch_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Progress(uint8 *CLB_DYN_Pitch_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Px(uint16 *CLB_DYN_Pitch_Px)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Status(uint8 *CLB_DYN_Pitch_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Protocol_Version(uint8 *CLB_DYN_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll(float32 *CLB_DYN_Roll)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Confidence(uint8 *CLB_DYN_Roll_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Error(uint8 *CLB_DYN_Roll_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Progress(uint8 *CLB_DYN_Roll_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Status(uint8 *CLB_DYN_Roll_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Run_Mode(uint8 *CLB_DYN_Run_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Sync_ID(uint8 *CLB_DYN_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist(uint16 *CLB_DYN_Total_Cam_Height_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time(uint16 *CLB_DYN_Total_Cam_Height_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist(uint16 *CLB_DYN_Total_Pitch_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Time(uint16 *CLB_DYN_Total_Pitch_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Dist(uint16 *CLB_DYN_Total_Roll_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Time(uint16 *CLB_DYN_Total_Roll_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist(uint16 *CLB_DYN_Total_Yaw_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Time(uint16 *CLB_DYN_Total_Yaw_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Confidence(uint8 *CLB_DYN_Yaw_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Deg(float32 *CLB_DYN_Yaw_Deg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Error(uint8 *CLB_DYN_Yaw_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Progress(uint8 *CLB_DYN_Yaw_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Px(uint16 *CLB_DYN_Yaw_Px)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Status(uint8 *CLB_DYN_Yaw_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus(uint8 *spcProcessStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_RequestResults(Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data15ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_RequestResults_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_RequestResults (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess(uint8 spcType_u8, boolean *startSPCProcess_pb, boolean freshStart_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_Start_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_Start (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_Stop_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F001_SPC_Calibration_Stop (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode(uint8 VisionModeType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQ_SwitchToVisionMode_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_RequestResults(Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data2ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_RequestResults_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_RequestResults (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Tac2FreshStart_De_Tac2FreshStart(boolean *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis(boolean *EyeQSPTACStartCloseTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartCloseTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis(boolean *EyeQSPTACStartFarTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartFarTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus(uint8 *spcProcessStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess(uint8 spcType_u8, boolean *startSPCProcess_pb, boolean freshStart_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus(uint8 *ProcCmdResults_pu8, uint16 *ErrorCode_pu16, boolean *SPTAC_EyeQSPTACProcStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPTAC_EyeQGetSPTACProcStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_TAC2_EYEQMESP_TO_APPL_EYEQMESP_StartTAC2ProcessReq(boolean freshStart_bo, boolean *startTAC2Process_pb, boolean disableNVMWrite_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_TAC2_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_Start_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_Start (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_Stop_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F002_EOL_Calibration_TAC_Stop (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode(uint8 VisionModeType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQ_SwitchToVisionMode_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus(uint8 *ProcCmdResults_pu8, uint16 *ErrorCode_pu16, boolean *SPTAC_EyeQSPTACProcStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPTAC_EyeQGetSPTACProcStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_RequestResults(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_RequestResults_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_RequestResults(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_RequestResults (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis(boolean *EyeQSPTACStartCloseTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartCloseTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis(boolean *EyeQSPTACStartFarTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartFarTargetAnalysis_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_Start(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_Start_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_Start(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_Start (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_Stop(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_Stop_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_Stop(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F003_SPTAC_Calibration_Stop (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F004_LDW_Function_Validation_on_EOL_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LdwFuncTestSts_De_LdwFuncTestSts(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F004_LDW_Function_Validation_on_EOL_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F004_LDW_Function_Validation_on_EOL_Start_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F004_LDW_Function_Validation_on_EOL_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F004_LDW_Function_Validation_on_EOL_Start (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F004_LDW_Function_Validation_on_EOL_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LdwFuncTestSts_De_LdwFuncTestSts(uint8 data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F004_LDW_Function_Validation_on_EOL_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F004_LDW_Function_Validation_on_EOL_Stop_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F004_LDW_Function_Validation_on_EOL_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F004_LDW_Function_Validation_on_EOL_Stop (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F005_HBA_Regulation_Test_Procedure_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F005_HBA_Regulation_Test_Procedure_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F005_HBA_Regulation_Test_Procedure_Start_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F005_HBA_Regulation_Test_Procedure_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F005_HBA_Regulation_Test_Procedure_Start (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F005_HBA_Regulation_Test_Procedure_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F005_HBA_Regulation_Test_Procedure_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F005_HBA_Regulation_Test_Procedure_Stop_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F005_HBA_Regulation_Test_Procedure_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Routine_F005_HBA_Regulation_Test_Procedure_Stop (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApUds_sid31_STOP_SEC_CODE
#include "CpApUds_sid31_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
