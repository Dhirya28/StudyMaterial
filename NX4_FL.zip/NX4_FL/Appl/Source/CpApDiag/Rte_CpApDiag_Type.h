/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApDiag_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApDiag
 *  Generation Time:  2023-04-20 13:52:26
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApDiag> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPDIAG_TYPE_H
# define _RTE_CPAPDIAG_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"

/**********************************************************************************************************************
 * Range, Invalidation, Enumeration and Bit Field Definitions
 *********************************************************************************************************************/

# ifndef DCM_INITIAL
#  define DCM_INITIAL (0U)
# endif

# ifndef DCM_PENDING
#  define DCM_PENDING (1U)
# endif

# ifndef DCM_CANCEL
#  define DCM_CANCEL (2U)
# endif

# ifndef DCM_FORCE_RCRRP_OK
#  define DCM_FORCE_RCRRP_OK (3U)
# endif

# ifndef DCM_FORCE_RCRRP_NOT_OK
#  define DCM_FORCE_RCRRP_NOT_OK (64U)
# endif

# ifndef DEM_EVENT_STATUS_PASSED
#  define DEM_EVENT_STATUS_PASSED (0U)
# endif

# ifndef DEM_EVENT_STATUS_FAILED
#  define DEM_EVENT_STATUS_FAILED (1U)
# endif

# ifndef DEM_EVENT_STATUS_PREPASSED
#  define DEM_EVENT_STATUS_PREPASSED (2U)
# endif

# ifndef DEM_EVENT_STATUS_PREFAILED
#  define DEM_EVENT_STATUS_PREFAILED (3U)
# endif

# ifndef DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED
#  define DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED (4U)
# endif

# ifndef DEM_EVENT_STATUS_PASSED_CONDITIONS_NOT_FULFILLED
#  define DEM_EVENT_STATUS_PASSED_CONDITIONS_NOT_FULFILLED (5U)
# endif

# ifndef DEM_EVENT_STATUS_FAILED_CONDITIONS_NOT_FULFILLED
#  define DEM_EVENT_STATUS_FAILED_CONDITIONS_NOT_FULFILLED (6U)
# endif

# ifndef DEM_EVENT_STATUS_PREPASSED_CONDITIONS_NOT_FULFILLED
#  define DEM_EVENT_STATUS_PREPASSED_CONDITIONS_NOT_FULFILLED (7U)
# endif

# ifndef DEM_EVENT_STATUS_PREFAILED_CONDITIONS_NOT_FULFILLED
#  define DEM_EVENT_STATUS_PREFAILED_CONDITIONS_NOT_FULFILLED (8U)
# endif

# ifndef DEM_UDS_STATUS_TF
#  define DEM_UDS_STATUS_TF (1U)
# endif

# ifndef DEM_UDS_STATUS_TF_BflMask
#  define DEM_UDS_STATUS_TF_BflMask 1U
# endif

# ifndef DEM_UDS_STATUS_TF_BflPn
#  define DEM_UDS_STATUS_TF_BflPn 0U
# endif

# ifndef DEM_UDS_STATUS_TF_BflLn
#  define DEM_UDS_STATUS_TF_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_TFTOC
#  define DEM_UDS_STATUS_TFTOC (2U)
# endif

# ifndef DEM_UDS_STATUS_TFTOC_BflMask
#  define DEM_UDS_STATUS_TFTOC_BflMask 2U
# endif

# ifndef DEM_UDS_STATUS_TFTOC_BflPn
#  define DEM_UDS_STATUS_TFTOC_BflPn 1U
# endif

# ifndef DEM_UDS_STATUS_TFTOC_BflLn
#  define DEM_UDS_STATUS_TFTOC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_PDTC
#  define DEM_UDS_STATUS_PDTC (4U)
# endif

# ifndef DEM_UDS_STATUS_PDTC_BflMask
#  define DEM_UDS_STATUS_PDTC_BflMask 4U
# endif

# ifndef DEM_UDS_STATUS_PDTC_BflPn
#  define DEM_UDS_STATUS_PDTC_BflPn 2U
# endif

# ifndef DEM_UDS_STATUS_PDTC_BflLn
#  define DEM_UDS_STATUS_PDTC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_CDTC
#  define DEM_UDS_STATUS_CDTC (8U)
# endif

# ifndef DEM_UDS_STATUS_CDTC_BflMask
#  define DEM_UDS_STATUS_CDTC_BflMask 8U
# endif

# ifndef DEM_UDS_STATUS_CDTC_BflPn
#  define DEM_UDS_STATUS_CDTC_BflPn 3U
# endif

# ifndef DEM_UDS_STATUS_CDTC_BflLn
#  define DEM_UDS_STATUS_CDTC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_TNCSLC
#  define DEM_UDS_STATUS_TNCSLC (16U)
# endif

# ifndef DEM_UDS_STATUS_TNCSLC_BflMask
#  define DEM_UDS_STATUS_TNCSLC_BflMask 16U
# endif

# ifndef DEM_UDS_STATUS_TNCSLC_BflPn
#  define DEM_UDS_STATUS_TNCSLC_BflPn 4U
# endif

# ifndef DEM_UDS_STATUS_TNCSLC_BflLn
#  define DEM_UDS_STATUS_TNCSLC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_TFSLC
#  define DEM_UDS_STATUS_TFSLC (32U)
# endif

# ifndef DEM_UDS_STATUS_TFSLC_BflMask
#  define DEM_UDS_STATUS_TFSLC_BflMask 32U
# endif

# ifndef DEM_UDS_STATUS_TFSLC_BflPn
#  define DEM_UDS_STATUS_TFSLC_BflPn 5U
# endif

# ifndef DEM_UDS_STATUS_TFSLC_BflLn
#  define DEM_UDS_STATUS_TFSLC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_TNCTOC
#  define DEM_UDS_STATUS_TNCTOC (64U)
# endif

# ifndef DEM_UDS_STATUS_TNCTOC_BflMask
#  define DEM_UDS_STATUS_TNCTOC_BflMask 64U
# endif

# ifndef DEM_UDS_STATUS_TNCTOC_BflPn
#  define DEM_UDS_STATUS_TNCTOC_BflPn 6U
# endif

# ifndef DEM_UDS_STATUS_TNCTOC_BflLn
#  define DEM_UDS_STATUS_TNCTOC_BflLn 1U
# endif

# ifndef DEM_UDS_STATUS_WIR
#  define DEM_UDS_STATUS_WIR (128U)
# endif

# ifndef DEM_UDS_STATUS_WIR_BflMask
#  define DEM_UDS_STATUS_WIR_BflMask 128U
# endif

# ifndef DEM_UDS_STATUS_WIR_BflPn
#  define DEM_UDS_STATUS_WIR_BflPn 7U
# endif

# ifndef DEM_UDS_STATUS_WIR_BflLn
#  define DEM_UDS_STATUS_WIR_BflLn 1U
# endif

# ifndef NVM_REQ_OK
#  define NVM_REQ_OK (0U)
# endif

# ifndef NVM_REQ_NOT_OK
#  define NVM_REQ_NOT_OK (1U)
# endif

# ifndef NVM_REQ_PENDING
#  define NVM_REQ_PENDING (2U)
# endif

# ifndef NVM_REQ_INTEGRITY_FAILED
#  define NVM_REQ_INTEGRITY_FAILED (3U)
# endif

# ifndef NVM_REQ_BLOCK_SKIPPED
#  define NVM_REQ_BLOCK_SKIPPED (4U)
# endif

# ifndef NVM_REQ_NV_INVALIDATED
#  define NVM_REQ_NV_INVALIDATED (5U)
# endif

# ifndef NVM_REQ_CANCELED
#  define NVM_REQ_CANCELED (6U)
# endif

# ifndef NVM_REQ_REDUNDANCY_FAILED
#  define NVM_REQ_REDUNDANCY_FAILED (7U)
# endif

# ifndef NVM_REQ_RESTORED_FROM_ROM
#  define NVM_REQ_RESTORED_FROM_ROM (8U)
# endif



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_DcmControlDtcSetting
#  define RTE_MODETYPE_DcmControlDtcSetting
typedef uint8 Rte_ModeType_DcmControlDtcSetting;
# endif

# define RTE_MODE_CpApDiag_DcmControlDtcSetting_ENABLEDTCSETTING (0U)
# ifndef RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING
#  define RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING (0U)
# endif
# define RTE_MODE_CpApDiag_DcmControlDtcSetting_DISABLEDTCSETTING (1U)
# ifndef RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING
#  define RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING (1U)
# endif
# define RTE_TRANSITION_CpApDiag_DcmControlDtcSetting (2U)
# ifndef RTE_TRANSITION_DcmControlDtcSetting
#  define RTE_TRANSITION_DcmControlDtcSetting (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPDIAG_TYPE_H */
