/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApPreCond.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPreCond
 *  Generation Time:  2023-04-20 13:52:47
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApPreCond> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPPRECOND_H
# define _RTE_CPAPPRECOND_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApPreCond_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApPreCond
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApPreCond, RTE_CONST, RTE_CONST) Rte_Inst_CpApPreCond; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApPreCond, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng_Power9v_De_Eng_Power9v (0U)
# define Rte_InitValue_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v (0U)
# define Rte_InitValue_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF (0U)
# define Rte_InitValue_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc (0U)
# define Rte_InitValue_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA (0U)
# define Rte_InitValue_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF (0U)
# define Rte_InitValue_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc (0U)
# define Rte_InitValue_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v (0U)
# define Rte_InitValue_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v (0U)
# define Rte_InitValue_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus (0U)
# define Rte_InitValue_RP_BattVoltRaw_De_BattVoltRaw (0U)
# define Rte_InitValue_RP_CpApZfBattStatus_De_CpApZfBattStatus (0U)
# define Rte_InitValue_RP_ECU_SSC_STAT_De_ECU_SSC_STAT (0U)
# define Rte_InitValue_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status (0U)
# define Rte_InitValue_RP_HCU_HevRdySta_De_HCU_HevRdySta (0U)
# define Rte_InitValue_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus (0U)
# define Rte_InitValue_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_BattVoltRaw_De_BattVoltRaw(P2VAR(uint16, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_CpApZfBattStatus_De_CpApZfBattStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_ECU_SSC_STAT_De_ECU_SSC_STAT(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_ENG_EngSta_De_VCan_ENG_EngSta(P2VAR(VCan_ENG_EngSta_t, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_ENG_IsgSta_De_VCan_ENG_IsgSta(P2VAR(VCan_ENG_IsgSta_t, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_HCU_HevRdySta_De_HCU_HevRdySta(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPreCond_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_Power9v_De_Eng_Power9v(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPreCond_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApPreCond_DcmControlDtcSetting_DcmControlDtcSetting(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApPreCond_Switch_BswMSwitchPort_DNMT_VCAN_Rx_BswM_MDGP_DNMT_VCAN_Rx(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApPreCond_Switch_BswMSwitchPort_DNMT_VCAN_Tx_BswM_MDGP_DNMT_VCAN_Tx(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApPreCond_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApPreCond_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApPreCond_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPPRECOND_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_BattVoltRaw_De_BattVoltRaw Rte_Read_CpApPreCond_RP_BattVoltRaw_De_BattVoltRaw
# define Rte_Read_RP_CpApZfBattStatus_De_CpApZfBattStatus Rte_Read_CpApPreCond_RP_CpApZfBattStatus_De_CpApZfBattStatus
# define Rte_Read_RP_ECU_SSC_STAT_De_ECU_SSC_STAT Rte_Read_CpApPreCond_RP_ECU_SSC_STAT_De_ECU_SSC_STAT
# define Rte_Read_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status Rte_Read_CpApPreCond_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status
# define Rte_Read_RP_ENG_EngSta_De_VCan_ENG_EngSta Rte_Read_CpApPreCond_RP_ENG_EngSta_De_VCan_ENG_EngSta
# define Rte_Read_RP_ENG_IsgSta_De_VCan_ENG_IsgSta Rte_Read_CpApPreCond_RP_ENG_IsgSta_De_VCan_ENG_IsgSta
# define Rte_Read_RP_HCU_HevRdySta_De_HCU_HevRdySta Rte_Read_CpApPreCond_RP_HCU_HevRdySta_De_HCU_HevRdySta
# define Rte_Read_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus Rte_Read_CpApPreCond_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus
# define Rte_Read_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus Rte_Read_CpApPreCond_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF
# define Rte_Write_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF
# define Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc
# define Rte_Write_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF
# define Rte_Write_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Eng_Power9v_De_Eng_Power9v Rte_Write_CpApPreCond_PP_Eng_Power9v_De_Eng_Power9v
# define Rte_Write_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF
# define Rte_Write_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF Rte_Write_CpApPreCond_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF
# define Rte_Write_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v
# define Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF
# define Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF
# define Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF
# define Rte_Write_PP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc Rte_Write_CpApPreCond_PP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc
# define Rte_Write_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc Rte_Write_CpApPreCond_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc
# define Rte_Write_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA Rte_Write_CpApPreCond_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA
# define Rte_Write_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF
# define Rte_Write_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Write_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc Rte_Write_CpApPreCond_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc
# define Rte_Write_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v Rte_Write_CpApPreCond_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v
# define Rte_Write_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v Rte_Write_CpApPreCond_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v
# define Rte_Write_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus Rte_Write_CpApPreCond_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus


/**********************************************************************************************************************
 * Rte_Mode_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Mode_DcmControlDtcSetting_DcmControlDtcSetting Rte_Mode_CpApPreCond_DcmControlDtcSetting_DcmControlDtcSetting
# define Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Rx_BswM_MDGP_DNMT_VCAN_Rx Rte_Mode_CpApPreCond_Switch_BswMSwitchPort_DNMT_VCAN_Rx_BswM_MDGP_DNMT_VCAN_Rx
# define Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Tx_BswM_MDGP_DNMT_VCAN_Tx Rte_Mode_CpApPreCond_Switch_BswMSwitchPort_DNMT_VCAN_Tx_BswM_MDGP_DNMT_VCAN_Tx


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus Rte_Call_CpApPreCond_RP_AppDiagFaultStatus_GetAppDiagFltStatus
# define Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApPreCond_RP_AppDiagFaultStatus_SetAppDiagFltStatus
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApPreCond_RP_EOLInfo_getEOLInfo




# define CpApPreCond_START_SEC_CODE
# include "CpApPreCond_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApCommunicationControl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EnableDisableCommunication> of PortPrototype <PP_CpApEnableDisableCommunication>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApCommunicationControl(uint8 arg)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApCommunicationControl Re_CpApCommunicationControl
FUNC(void, CpApPreCond_CODE) Re_CpApCommunicationControl(uint8 arg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPreCondInit Re_CpApPreCondInit
FUNC(void, CpApPreCond_CODE) Re_CpApPreCondInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_BattVoltRaw_De_BattVoltRaw(uint16 *data)
 *   Std_ReturnType Rte_Read_RP_CpApZfBattStatus_De_CpApZfBattStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_ENG_EngSta_De_VCan_ENG_EngSta(VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Read_RP_ENG_IsgSta_De_VCan_ENG_IsgSta(VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Read_RP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_De_Eng_Power9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(uint8 data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_DcmControlDtcSetting_DcmControlDtcSetting(void)
 *   Modes of Rte_ModeType_DcmControlDtcSetting:
 *   - RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING
 *   - RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING
 *   - RTE_TRANSITION_DcmControlDtcSetting
 *   uint8 Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Rx_BswM_MDGP_DNMT_VCAN_Rx(void)
 *   Modes of Rte_ModeType_DNMT_VCAN_Rx:
 *   - RTE_MODE_DNMT_VCAN_Rx_RX_DISABLE
 *   - RTE_MODE_DNMT_VCAN_Rx_RX_ENABLE
 *   - RTE_TRANSITION_DNMT_VCAN_Rx
 *   uint8 Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Tx_BswM_MDGP_DNMT_VCAN_Tx(void)
 *   Modes of Rte_ModeType_DNMT_VCAN_Tx:
 *   - RTE_MODE_DNMT_VCAN_Tx_TX_DISABLE
 *   - RTE_MODE_DNMT_VCAN_Tx_TX_ENABLE
 *   - RTE_TRANSITION_DNMT_VCAN_Tx
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPreCondMain Re_CpApPreCondMain
FUNC(void, CpApPreCond_CODE) Re_CpApPreCondMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPreCondOut Re_CpApPreCondOut
FUNC(void, CpApPreCond_CODE) Re_CpApPreCondOut(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApPreCond_STOP_SEC_CODE
# include "CpApPreCond_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPPRECOND_H */
