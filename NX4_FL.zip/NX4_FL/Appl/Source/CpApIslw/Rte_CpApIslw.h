/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApIslw.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIslw
 *  Generation Time:  2023-04-20 13:52:34
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApIslw> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPISLW_H
# define _RTE_CPAPISLW_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApIslw_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApIslw
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApIslw, RTE_CONST, RTE_CONST) Rte_Inst_CpApIslw; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApIslw, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_Core2ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn01_De_IslwDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn02_De_IslwDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn03_De_IslwDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn04_De_IslwDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn05_De_IslwDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwDbgIn06_De_IslwDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwFailInfo_De_IslwFailInfo(P2VAR(IslwFailInfo_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslw_RP_IslwInput_De_IslwInput(P2VAR(IslwInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslaUxOutToIvc_De_IslaUxOutToIvc(P2CONST(IslaUxOutToIvc_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIslw_PP_IslwOutput_De_IslwOutput(P2CONST(IslwOutput_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_FrCmrHdrFS_getFrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_IslwEyeQInput_getIslwEyeQInput(P2VAR(IslwEyeQInput_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) IslwEyeQInput); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_IslwFrqNvData_ReadIslwFrqNvData(P2VAR(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) IslwFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_IslwFrqNvData_WriteIslwFrqNvData(P2CONST(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) IslwFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_IslwOccNvData_ReadIslwOccNvData(P2VAR(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) IslwOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_IslwOccNvData_WriteIslwOccNvData(P2CONST(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLW_APPL_DATA) IslwOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslw_RP_TsrInfo_getTsrInfo(P2VAR(IslwTSRInfo_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) TsrInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApIslw_RP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_IslwDbgIn01_De_IslwDbgIn01 Rte_Read_CpApIslw_RP_IslwDbgIn01_De_IslwDbgIn01
# define Rte_Read_RP_IslwDbgIn02_De_IslwDbgIn02 Rte_Read_CpApIslw_RP_IslwDbgIn02_De_IslwDbgIn02
# define Rte_Read_RP_IslwDbgIn03_De_IslwDbgIn03 Rte_Read_CpApIslw_RP_IslwDbgIn03_De_IslwDbgIn03
# define Rte_Read_RP_IslwDbgIn04_De_IslwDbgIn04 Rte_Read_CpApIslw_RP_IslwDbgIn04_De_IslwDbgIn04
# define Rte_Read_RP_IslwDbgIn05_De_IslwDbgIn05 Rte_Read_CpApIslw_RP_IslwDbgIn05_De_IslwDbgIn05
# define Rte_Read_RP_IslwDbgIn06_De_IslwDbgIn06 Rte_Read_CpApIslw_RP_IslwDbgIn06_De_IslwDbgIn06
# define Rte_Read_RP_IslwFailInfo_De_IslwFailInfo Rte_Read_CpApIslw_RP_IslwFailInfo_De_IslwFailInfo
# define Rte_Read_RP_IslwInput_De_IslwInput Rte_Read_CpApIslw_RP_IslwInput_De_IslwInput


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_IslaUxOutToIvc_De_IslaUxOutToIvc Rte_Write_CpApIslw_PP_IslaUxOutToIvc_De_IslaUxOutToIvc
# define Rte_Write_PP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01
# define Rte_Write_PP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02
# define Rte_Write_PP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03
# define Rte_Write_PP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04
# define Rte_Write_PP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05
# define Rte_Write_PP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06
# define Rte_Write_PP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07
# define Rte_Write_PP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08
# define Rte_Write_PP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09
# define Rte_Write_PP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10
# define Rte_Write_PP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11
# define Rte_Write_PP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12
# define Rte_Write_PP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13
# define Rte_Write_PP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14
# define Rte_Write_PP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15
# define Rte_Write_PP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16
# define Rte_Write_PP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17
# define Rte_Write_PP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18
# define Rte_Write_PP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19
# define Rte_Write_PP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20 Rte_Write_CpApIslw_PP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20
# define Rte_Write_PP_IslwOutput_De_IslwOutput Rte_Write_CpApIslw_PP_IslwOutput_De_IslwOutput


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApIslw_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApIslw_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApIslw_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApIslw_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApIslw_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS Rte_Call_CpApIslw_RP_FrCmrHdrFS_getFrCmrHdrFS
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApIslw_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_IslwEyeQInput_getIslwEyeQInput Rte_Call_CpApIslw_RP_IslwEyeQInput_getIslwEyeQInput
# define Rte_Call_RP_IslwFrqNvData_ReadIslwFrqNvData Rte_Call_CpApIslw_RP_IslwFrqNvData_ReadIslwFrqNvData
# define Rte_Call_RP_IslwFrqNvData_WriteIslwFrqNvData Rte_Call_CpApIslw_RP_IslwFrqNvData_WriteIslwFrqNvData
# define Rte_Call_RP_IslwOccNvData_ReadIslwOccNvData Rte_Call_CpApIslw_RP_IslwOccNvData_ReadIslwOccNvData
# define Rte_Call_RP_IslwOccNvData_WriteIslwOccNvData Rte_Call_CpApIslw_RP_IslwOccNvData_WriteIslwOccNvData
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApIslw_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApIslw_RP_Os_Service_GetElapsedValue
# define Rte_Call_RP_TsrInfo_getTsrInfo Rte_Call_CpApIslw_RP_TsrInfo_getTsrInfo




# define CpApIslw_START_SEC_CODE
# include "CpApIslw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwFrqNvData_ReadIslwFrqNvData(IslwFrqNvData_t *IslwFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwOccNvData_ReadIslwOccNvData(IslwOccNvData_t *IslwOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwInit Re_CpApIslwInit
FUNC(void, CpApIslw_CODE) Re_CpApIslwInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn01_De_IslwDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn02_De_IslwDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn03_De_IslwDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn04_De_IslwDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn05_De_IslwDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn06_De_IslwDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwFailInfo_De_IslwFailInfo(IslwFailInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwInput_De_IslwInput(IslwInput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_IslaUxOutToIvc_De_IslaUxOutToIvc(const IslaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwOutput_De_IslwOutput(const IslwOutput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwEyeQInput_getIslwEyeQInput(IslwEyeQInput_t *IslwEyeQInput)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IslwFrqNvData_WriteIslwFrqNvData(const IslwFrqNvData_t *IslwFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwOccNvData_WriteIslwOccNvData(const IslwOccNvData_t *IslwOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwOccNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_TsrInfo_getTsrInfo(IslwTSRInfo_t *TsrInfo)
 *     Synchronous Server Invocation. Timeout: None
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwMain Re_CpApIslwMain
FUNC(void, CpApIslw_CODE) Re_CpApIslwMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_IslwAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwVersionReq(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwVersionReq Re_CpApIslwVersionReq
FUNC(Std_ReturnType, CpApIslw_CODE) Re_CpApIslwVersionReq(P2VAR(IslwAppVersionInfo_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) IslwAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApIslw_STOP_SEC_CODE
# include "CpApIslw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_IslwAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_IslwFrqNvData_ReturnType (1U)

# define RTE_E_IF_IslwOccNvData_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPISLW_H */
