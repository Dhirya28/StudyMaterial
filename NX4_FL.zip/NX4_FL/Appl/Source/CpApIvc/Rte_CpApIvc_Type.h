/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApIvc_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIvc
 *  Generation Time:  2023-04-20 13:52:36
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApIvc> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPIVC_TYPE_H
# define _RTE_CPAPIVC_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_ProxyCore2Ready_QM
#  define RTE_MODETYPE_ProxyCore2Ready_QM
typedef uint8 Rte_ModeType_ProxyCore2Ready_QM;
# endif

# define RTE_MODE_CpApIvc_ProxyCore2Ready_QM_FALSE (0U)
# ifndef RTE_MODE_ProxyCore2Ready_QM_FALSE
#  define RTE_MODE_ProxyCore2Ready_QM_FALSE (0U)
# endif
# define RTE_MODE_CpApIvc_ProxyCore2Ready_QM_TRUE (1U)
# ifndef RTE_MODE_ProxyCore2Ready_QM_TRUE
#  define RTE_MODE_ProxyCore2Ready_QM_TRUE (1U)
# endif
# define RTE_TRANSITION_CpApIvc_ProxyCore2Ready_QM (2U)
# ifndef RTE_TRANSITION_ProxyCore2Ready_QM
#  define RTE_TRANSITION_ProxyCore2Ready_QM (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPIVC_TYPE_H */
