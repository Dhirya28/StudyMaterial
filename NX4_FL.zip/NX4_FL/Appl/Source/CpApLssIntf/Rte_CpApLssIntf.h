/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApLssIntf.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLssIntf
 *  Generation Time:  2023-04-20 13:52:41
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApLssIntf> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPLSSINTF_H
# define _RTE_CPAPLSSINTF_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApLssIntf_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApLssIntf
{
  /* PIM Handles section */
  P2VAR(LssFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_LssFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApLssIntf, RTE_CONST, RTE_CONST) Rte_Inst_CpApLssIntf; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApLssIntf, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_DrivingSideStatus_De_DrivingSideStatus (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_RxMsgsInFrame (0ULL)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLssIntf_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLssIntf_RP_EyeQ_FrameReady_RxMsgsInFrame(P2VAR(uint64, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLssIntf_PP_DrivingSideStatus_De_DrivingSideStatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLssIntf_PP_LssMeInfo_De_LssMeInfo(P2CONST(LssMeInfo_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Application_version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Brain_drops_counter); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_CRC32); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera1_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera1_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera1_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera1_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera2_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera2_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera2_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera2_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera3_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera3_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera3_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Camera3_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Diagnostics_part_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Diagnostics_part_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_External_Video_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(P2VAR(sint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_EyeQTemperature1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(P2VAR(sint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_EyeQTemperature2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_EyeQ_Current_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_EyeQ_Process_Index); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_EyeQ_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_FE_OPTICAL_PATH_DEVICE_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Internal_Camera_Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Internal_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Minor_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_RSRV_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_SPI_Bus_Load_Rx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_SPI_Bus_Load_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_SPI_Retransmit_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Sub_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(P2VAR(sint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Temperature_DDR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Valid_cameras_information); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_Valid_second_cam_temp_info); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_ZQ_Cal_internal_diag1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_ZQ_Cal_internal_diag2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_appMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) APP_spiErrors); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) Application_Message_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Cam_Frame_ID(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Cam_Frame_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_DayTime_Indicator(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_DayTime_Indicator); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Delta_Sync(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Delta_Sync); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Driving_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side_V(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Driving_Side_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Exposure_Type(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Exposure_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_EyeQ_Frame_ID(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_EyeQ_Frame_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Frame_MCU_TS_Start(P2VAR(uint64, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Frame_MCU_TS_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_HIL_Mode_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_HIL_Mode_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Is_HighSpeed_Road); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road_V(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Is_HighSpeed_Road_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_In_Tunnel(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Is_In_Tunnel); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Last_Clock_Sync_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Skew(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Last_Clock_Sync_Skew); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_MCU_Sync_TS(P2VAR(uint64, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Last_MCU_Sync_TS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_ProtocolCycle_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_ProtocolCycle_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Region_Code); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code_V(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Region_Code_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ReportingCycleMode(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_ReportingCycleMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Sync_Frame_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Sync_Frame_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Tunnel_Conf(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) COM_Tunnel_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Blur_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_C2C_Out_Of_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_C2W_OOR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Camera_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Cameras_Number); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Fog); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Free_Sight); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Frozen_Windshield_Lens); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Full_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Impacted_Technologies); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Low_Sun); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Out_Of_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Out_Of_Focus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Partial_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Rain); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Splashes); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Sun_Ray); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FS_TSR_Out_OF_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Suppression_Reason_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Suppression_Reason_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Time_To_Warning_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Time_To_Warning_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Warning_Status_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LDW_Warning_Status_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Exit_Merge_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Distance_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Is_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Is_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Lat_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Long_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Role); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_SRD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_INTP_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Is_Highway_Exit_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Is_Highway_Exit_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Is_Highway_Merge_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Is_Highway_Merge_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_First_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Half_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Second_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Second_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Second_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Second_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_Second_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Path_Pred_second_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Snow_On_Road); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LAP_Vertical_Surface_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) MainState_pu8, P2VAR(uint8, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) SubState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_NvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLssIntf_RP_NvMService_LssFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApLssIntf_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame Rte_Read_CpApLssIntf_RP_EyeQ_FrameReady_RxMsgsInFrame


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_DrivingSideStatus_De_DrivingSideStatus Rte_Write_CpApLssIntf_PP_DrivingSideStatus_De_DrivingSideStatus
# define Rte_Write_PP_LssMeInfo_De_LssMeInfo Rte_Write_CpApLssIntf_PP_LssMeInfo_De_LssMeInfo


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApLssIntf_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_CRC Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_CRC
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Cam_Frame_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Cam_Frame_ID
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_DayTime_Indicator Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_DayTime_Indicator
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Delta_Sync Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Delta_Sync
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side_V Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side_V
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Exposure_Type Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Exposure_Type
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_EyeQ_Frame_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_EyeQ_Frame_ID
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Frame_MCU_TS_Start Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Frame_MCU_TS_Start
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_HIL_Mode_Status Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_HIL_Mode_Status
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road_V Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road_V
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_In_Tunnel Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_In_Tunnel
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Error Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Error
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Skew Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Skew
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_MCU_Sync_TS Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_MCU_Sync_TS
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_1
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_2
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Protocol_Version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code_V Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code_V
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ReportingCycleMode Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ReportingCycleMode
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Sync_Frame_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Sync_Frame_ID
# define Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Tunnel_Conf Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Tunnel_Conf
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3 Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid Rte_Call_CpApLssIntf_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid
# define Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState Rte_Call_CpApLssIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApLssIntf_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_NvMService_LssFrqNvData_ReadBlock Rte_Call_CpApLssIntf_RP_NvMService_LssFrqNvData_ReadBlock
# define Rte_Call_RP_NvMService_LssFrqNvData_WriteBlock Rte_Call_CpApLssIntf_RP_NvMService_LssFrqNvData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_LssFrqNvData() (Rte_Inst_CpApLssIntf->Pim_LssFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   LssFrqNvData_t *Rte_Pim_LssFrqNvData(void)
 *
 *********************************************************************************************************************/


# define CpApLssIntf_START_SEC_CODE
# include "CpApLssIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished
FUNC(void, CpApLssIntf_CODE) CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_DrivingSideStatus_De_DrivingSideStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_LssMeInfo_De_LssMeInfo(const LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_CRC(uint32 *COM_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Cam_Frame_ID(uint32 *COM_Cam_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_DayTime_Indicator(uint8 *COM_DayTime_Indicator)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Delta_Sync(uint32 *COM_Delta_Sync)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side(uint8 *COM_Driving_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side_V(uint8 *COM_Driving_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Exposure_Type(uint8 *COM_Exposure_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_EyeQ_Frame_ID(uint32 *COM_EyeQ_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Frame_MCU_TS_Start(uint64 *COM_Frame_MCU_TS_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_HIL_Mode_Status(uint8 *COM_HIL_Mode_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road(uint8 *COM_Is_HighSpeed_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road_V(uint8 *COM_Is_HighSpeed_Road_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_In_Tunnel(uint8 *COM_Is_In_Tunnel)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Error(uint8 *COM_Last_Clock_Sync_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Skew(uint32 *COM_Last_Clock_Sync_Skew)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_MCU_Sync_TS(uint64 *COM_Last_MCU_Sync_TS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_1(uint32 *COM_ProtocolCycle_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_2(uint32 *COM_ProtocolCycle_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Protocol_Version(uint8 *COM_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code(uint8 *COM_Region_Code)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code_V(uint8 *COM_Region_Code_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ReportingCycleMode(uint8 *COM_ReportingCycleMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Sync_Frame_ID(uint8 *COM_Sync_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Tunnel_Conf(uint8 *COM_Tunnel_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, uint8 *FS_Blur_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(uint16 *FS_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, uint8 *FS_C2C_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(uint8 *FS_C2W_OOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, uint32 *FS_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, uint8 *FS_Camera_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(uint8 *FS_Cameras_Number)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, uint8 *FS_Free_Sight)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, uint8 *FS_Frozen_Windshield_Lens)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(uint32 *FS_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(uint16 *FS_Impacted_Technologies)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, uint8 *FS_Low_Sun)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(uint8 *FS_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, uint8 *FS_Out_Of_Focus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(uint8 *FS_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(uint8 *FS_Rain)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, uint8 *FS_Splashes)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(uint8 *FS_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(uint8 *FS_TSR_Out_OF_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(float32 *LDW_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(float32 *LDW_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(uint8 *LDW_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, uint32 *LDW_Suppression_Reason_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, uint32 *LDW_Suppression_Reason_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(uint8 *LDW_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, float32 *LDW_Time_To_Warning_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, float32 *LDW_Time_To_Warning_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, uint8 *LDW_Warning_Status_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, uint8 *LDW_Warning_Status_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(uint8 *LAP_Exit_Merge_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(uint8 *LAP_INTP_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, uint8 *LAP_INTP_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(uint8 *LAP_INTP_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, uint16 *LAP_INTP_Distance_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, uint8 *LAP_INTP_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, uint8 *LAP_INTP_Is_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, uint8 *LAP_INTP_Is_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, uint16 *LAP_INTP_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, uint16 *LAP_INTP_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, uint8 *LAP_INTP_Role)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, uint8 *LAP_INTP_SRD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, uint8 *LAP_INTP_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(uint8 *LAP_Is_Highway_Exit_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(uint8 *LAP_Is_Highway_Exit_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(uint8 *LAP_Is_Highway_Merge_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(uint8 *LAP_Is_Highway_Merge_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(uint8 *LAP_Path_Pred_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(uint32 *LAP_Path_Pred_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(uint8 *LAP_Path_Pred_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(float32 *LAP_Path_Pred_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(float32 *LAP_Path_Pred_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(float32 *LAP_Path_Pred_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(float32 *LAP_Path_Pred_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(uint16 *LAP_Path_Pred_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(uint8 *LAP_Path_Pred_First_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(uint16 *LAP_Path_Pred_Half_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(float32 *LAP_Path_Pred_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(float32 *LAP_Path_Pred_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(float32 *LAP_Path_Pred_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(float32 *LAP_Path_Pred_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(uint8 *LAP_Path_Pred_Second_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(uint16 *LAP_Path_Pred_second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(uint8 *LAP_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(uint8 *LAP_Snow_On_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(uint8 *LAP_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(uint8 *LAP_Vertical_Surface_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(float32 *LAP_Vertical_Surface_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(float32 *LAP_Vertical_Surface_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(float32 *LAP_Vertical_Surface_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(float32 *LAP_Vertical_Surface_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(uint16 *LAP_Vertical_Surface_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIntfEyeQRead Re_CpApLssIntfEyeQRead
FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfEyeQRead(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIntfInit Re_CpApLssIntfInit
FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LssMeInfo_De_LssMeInfo(const LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_LssFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIntfMain Re_CpApLssIntfMain
FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfReadLssFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadLssFrqNvData> of PortPrototype <PP_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssIntfReadLssFrqNvData(LssFrqNvData_t *LssFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIntfReadLssFrqNvData Re_CpApLssIntfReadLssFrqNvData
FUNC(Std_ReturnType, CpApLssIntf_CODE) Re_CpApLssIntfReadLssFrqNvData(P2VAR(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LssFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfWriteLssFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteLssFrqNvData> of PortPrototype <PP_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssIntfWriteLssFrqNvData(const LssFrqNvData_t *LssFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIntfWriteLssFrqNvData Re_CpApLssIntfWriteLssFrqNvData
FUNC(Std_ReturnType, CpApLssIntf_CODE) Re_CpApLssIntfWriteLssFrqNvData(P2CONST(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_DATA) LssFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApLssIntf_STOP_SEC_CODE
# include "CpApLssIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType (1U)

# define RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_LssFrqNvData_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPLSSINTF_H */
