/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApEDR.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApEDR
 *  Generation Time:  2023-04-20 13:52:27
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApEDR> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPEDR_H
# define _RTE_CPAPEDR_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApEDR_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApEDR
{
  /* PIM Handles section */
  P2VAR(EDR_NvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_EDRData_MirrorBlock_Event1; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EDR_NvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_EDRData_MirrorBlock_Event2; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EDR_NvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_EDRData_MirrorBlock_Event3; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EDR_NvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_EDRData_MirrorBlock_Event4; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EDR_NvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_EDRData_MirrorBlock_Event5; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EDR_IndexData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_PerInstanceMemory_EDRIndexData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApEDR, RTE_CONST, RTE_CONST) Rte_Inst_CpApEDR; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApEDR, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEDR_rp_EDR_Input_Data_EDRInputData(P2VAR(EDR_InputData, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_EraseBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPEDR_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_InvalidateNvBlock(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_rp_EDR_Input_Data_EDRInputData Rte_Read_CpApEDR_rp_EDR_Input_Data_EDRInputData


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_EraseBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_GetErrorStatus
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_ReadBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_WriteBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_EraseBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_GetErrorStatus
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_ReadBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_WriteBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_EraseBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_GetErrorStatus
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_ReadBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_WriteBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_EraseBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_GetErrorStatus
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_ReadBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_WriteBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_EraseBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_GetErrorStatus
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_ReadBlock
# define Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_WriteBlock
# define Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_EraseBlock Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_EraseBlock
# define Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_GetErrorStatus Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_GetErrorStatus
# define Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_InvalidateNvBlock Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_InvalidateNvBlock
# define Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_ReadBlock Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_ReadBlock
# define Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_WriteBlock Rte_Call_CpApEDR_NvMService_AC3_NvBlockNeed_EDRIndexData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event1() (Rte_Inst_CpApEDR->Pim_NvBlockNeed_EDRData_MirrorBlock_Event1) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event2() (Rte_Inst_CpApEDR->Pim_NvBlockNeed_EDRData_MirrorBlock_Event2) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event3() (Rte_Inst_CpApEDR->Pim_NvBlockNeed_EDRData_MirrorBlock_Event3) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event4() (Rte_Inst_CpApEDR->Pim_NvBlockNeed_EDRData_MirrorBlock_Event4) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event5() (Rte_Inst_CpApEDR->Pim_NvBlockNeed_EDRData_MirrorBlock_Event5) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_PerInstanceMemory_EDRIndexData() (Rte_Inst_CpApEDR->Pim_PerInstanceMemory_EDRIndexData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   EDR_NvData_t *Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event1(void)
 *   EDR_NvData_t *Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event2(void)
 *   EDR_NvData_t *Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event3(void)
 *   EDR_NvData_t *Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event4(void)
 *   EDR_NvData_t *Rte_Pim_NvBlockNeed_EDRData_MirrorBlock_Event5(void)
 *   EDR_IndexData_t *Rte_Pim_PerInstanceMemory_EDRIndexData(void)
 *
 *********************************************************************************************************************/


# define CpApEDR_START_SEC_CODE
# include "CpApEDR_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EDR_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_EDR_Init Re_EDR_Init
FUNC(void, CpApEDR_CODE) Re_EDR_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EDR_Trigger
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EDR_Trigger_Function> of PortPrototype <rp_EDR_Trigger>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_EDR_Trigger(void)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_EDR_Trigger Re_EDR_Trigger
FUNC(void, CpApEDR_CODE) Re_EDR_Trigger(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_Main_200ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 200ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_rp_EDR_Input_Data_EDRInputData(EDR_InputData *data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event1_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event2_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event3_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event4_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_DS_NvBlockNeed_EDRData_Event5_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_EraseBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_InvalidateNvBlock(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC3_NvBlockNeed_EDRIndexData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_Main_200ms Re_Main_200ms
FUNC(void, CpApEDR_CODE) Re_Main_200ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1_JobFinished Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1_JobFinished
FUNC(void, CpApEDR_CODE) Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_1_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2_JobFinished Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2_JobFinished
FUNC(void, CpApEDR_CODE) Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_2_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3_JobFinished Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3_JobFinished
FUNC(void, CpApEDR_CODE) Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_3_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4_JobFinished Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4_JobFinished
FUNC(void, CpApEDR_CODE) Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_4_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5_JobFinished Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5_JobFinished
FUNC(void, CpApEDR_CODE) Re_NvMNotifyJobFinished_NvBlockNeed_EDRData_Event_5_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApEDR_STOP_SEC_CODE
# include "CpApEDR_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_NvMService_AC3_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPEDR_H */
