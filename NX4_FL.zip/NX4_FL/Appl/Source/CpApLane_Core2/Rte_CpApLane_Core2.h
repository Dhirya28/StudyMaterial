/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApLane_Core2.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLane_Core2
 *  Generation Time:  2023-04-20 13:52:39
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApLane_Core2> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPLANE_CORE2_H
# define _RTE_CPAPLANE_CORE2_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApLane_Core2_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApLane_Core2
{
  /* PIM Handles section */
  P2VAR(ArrFrCmrLDW, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrLDW; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrLnAdj, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrLnAdj; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrLnAppl, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrLnAppl; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrLnHost, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrLnHost; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrLnRdEdg, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrLnRdEdg; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApLane_Core2, RTE_CONST, RTE_CONST) Rte_Inst_CpApLane_Core2; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApLane_Core2, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus (0U)
# define Rte_InitValue_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8 (0U)
# define Rte_InitValue_RP_Eol_DriveType_DriveType (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_RxMsgsInFrame (0ULL)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLane_Core2_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLane_Core2_RP_Eol_DriveType_DriveType(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLane_Core2_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLane_Core2_RP_EyeQ_FrameReady_RxMsgsInFrame(P2VAR(uint64, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLane_Core2_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(P2VAR(EYEQMESP_EnvironmentParams_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Application_version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Brain_drops_counter); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_CRC32); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera1_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera1_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera1_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera1_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera2_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera2_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera2_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera2_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera3_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera3_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera3_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Camera3_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Diagnostics_part_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Diagnostics_part_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_External_Video_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(P2VAR(sint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_EyeQTemperature1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(P2VAR(sint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_EyeQTemperature2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_EyeQ_Current_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_EyeQ_Process_Index); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_EyeQ_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_FE_OPTICAL_PATH_DEVICE_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Internal_Camera_Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Internal_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Minor_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_RSRV_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_SPI_Bus_Load_Rx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_SPI_Bus_Load_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_SPI_Retransmit_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Sub_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(P2VAR(sint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Temperature_DDR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Valid_cameras_information); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_Valid_second_cam_temp_info); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_ZQ_Cal_internal_diag1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_ZQ_Cal_internal_diag2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_appMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) APP_spiErrors); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Application_Message_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Suppression_Reason_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Suppression_Reason_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Time_To_Warning_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Time_To_Warning_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Warning_Status_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LDW_Warning_Status_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_2(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_3(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_4(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Adjacent_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Adjacent_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Age(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Availability_State(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Availability_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Color); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color_Conf(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Color_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DECEL_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_DECEL_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DLM_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_DLM_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lane_Track_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Lane_Track_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Lanemark_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type_Conf(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Lanemark_Type_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C0(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Line_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C1(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Line_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C2(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Line_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C3(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Line_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_Side(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Line_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Marker_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width_STD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Marker_Width_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Measured_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Measured_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Prediction_Reason(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Prediction_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_View_Range_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_Start(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LA_View_Range_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LH_Buffer_C1(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_2(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_4(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c3(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Buffer_c3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c4(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Buffer_c4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c5(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Buffer_c5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Exit_Merge_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Distance_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Is_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Is_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Lat_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Long_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Role); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_SRD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_INTP_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Is_Highway_Exit_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Is_Highway_Exit_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Is_Highway_Merge_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Is_Highway_Merge_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_First_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Half_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Is_Triggered_SDM_Model(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Is_Triggered_SDM_Model); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Second_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Second_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Second_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Second_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_Second_Valid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Path_Pred_second_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Snow_On_Road); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LAP_Vertical_Surface_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_2(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_3(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_4(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_5(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_6(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_7(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_8(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_9(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Age(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Availability_State(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Availability_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Buffer_C3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Buffer_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Color); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Color_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Crossing(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Crossing); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DECEL_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_DECEL_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DLM_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_DLM_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Available(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Dash_Average_Available); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Gap(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Dash_Average_Gap); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Length(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Dash_Average_Length); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Estimated_Width(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Estimated_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_Measured_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_First_Measured_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_First_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_Start(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_First_VR_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Construction_Area(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Is_Construction_Area); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Multi_Clothoid(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Is_Multi_Clothoid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Model(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Is_Triggered_SDM_Model); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Is_Triggered_SDM_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Lanemark_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type_Conf(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Lanemark_Type_Conf); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanes_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Lanes_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C0(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_First_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C1(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_First_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C2(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_First_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C3(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_First_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C0(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_Second_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C1(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_Second_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C2(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_Second_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C3(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Line_Second_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Marker_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width_STD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Marker_Width_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Prediction_Reason(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Prediction_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_Measured_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Second_Measured_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Second_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_Start(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Second_VR_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Side(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Track_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LH_Track_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_2(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_6(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_7(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_LNHST_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Age(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Availability_State(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Availability_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Buffer_C4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Buffer_C4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_Buffer(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Element_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Element_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_Buffer(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Header_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height_STD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Is_Triggered_SDM_Model(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Is_Triggered_SDM_Model); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C0(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Line_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C1(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Line_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C2(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Line_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C3(uint16 Index, P2VAR(float32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Line_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Measured_VR_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Measured_VR_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Position(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Position); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Prediction_Reason(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Prediction_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Side(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_End(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_View_Range_End); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_Start(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) LRE_View_Range_Start); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_1(P2VAR(uint32, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_2(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_4(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_LNRE_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8 Rte_Read_CpApLane_Core2_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8
# define Rte_Read_RP_Eol_DriveType_DriveType Rte_Read_CpApLane_Core2_RP_Eol_DriveType_DriveType
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApLane_Core2_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame Rte_Read_CpApLane_Core2_RP_EyeQ_FrameReady_RxMsgsInFrame


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus Rte_Write_CpApLane_Core2_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams Rte_Call_CpApLane_Core2_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Adjacent_Count Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Adjacent_Count
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Age Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Age
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Availability_State Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Availability_State
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color_Conf Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color_Conf
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Confidence Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DECEL_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DECEL_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DLM_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DLM_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lane_Track_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lane_Track_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type_Conf Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type_Conf
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_Side Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_Side
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width_STD Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width_STD
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Measured_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Measured_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Prediction_Reason Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Prediction_Reason
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Protocol_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Sync_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_End
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_Start Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LH_Buffer_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LH_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c4
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c5 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c5
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Is_Triggered_SDM_Model Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Is_Triggered_SDM_Model
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_5 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_6 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_7 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_7
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_8 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_8
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_9 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_9
# define Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Age Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Age
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Availability_State Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Availability_State
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Buffer_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Buffer_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_CRC Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_CRC
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color_Confidence Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Confidence Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Crossing Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Crossing
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DECEL_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DECEL_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DLM_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DLM_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Available Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Available
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Gap Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Gap
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Length Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Length
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Estimated_Width Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Estimated_Width
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_Measured_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_Measured_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_Start Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Construction_Area Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Construction_Area
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Multi_Clothoid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Multi_Clothoid
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Model Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Model
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type_Conf Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type_Conf
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanes_Count Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanes_Count
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width_STD Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width_STD
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Prediction_Reason Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Prediction_Reason
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Protocol_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_Measured_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_Measured_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_Start Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Side Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Side
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Sync_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Track_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Track_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_5 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_6 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_7 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_7
# define Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_LNHST_IsMsgValid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNHST_EYEQDG_LNHST_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Age Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Age
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Availability_State Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Availability_State
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Buffer_C4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Buffer_C4
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Confidence Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Count Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Count
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_Buffer Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_CRC Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_CRC
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_Buffer Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_CRC Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height_STD Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Is_Triggered_SDM_Model Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Is_Triggered_SDM_Model
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C0 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C0
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C1
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C2
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C3
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Measured_VR_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Measured_VR_End
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Position Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Position
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Prediction_Reason Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Prediction_Reason
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Protocol_Version Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Side Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Side
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Sync_ID Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Type Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Type
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_End Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_End
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_Start Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_Start
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_1 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_2 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_3 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_4 Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_LNRE_IsMsgValid Rte_Call_CpApLane_Core2_RP_EyeQCddSatCore2_LNRE_EYEQDG_LNRE_IsMsgValid


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_ArrFrCmrLDW() (Rte_Inst_CpApLane_Core2->Pim_ArrFrCmrLDW) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrLnAdj() (Rte_Inst_CpApLane_Core2->Pim_ArrFrCmrLnAdj) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrLnAppl() (Rte_Inst_CpApLane_Core2->Pim_ArrFrCmrLnAppl) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrLnHost() (Rte_Inst_CpApLane_Core2->Pim_ArrFrCmrLnHost) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrLnRdEdg() (Rte_Inst_CpApLane_Core2->Pim_ArrFrCmrLnRdEdg) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrLDW *Rte_Pim_ArrFrCmrLDW(void)
 *   ArrFrCmrLnAdj *Rte_Pim_ArrFrCmrLnAdj(void)
 *   ArrFrCmrLnAppl *Rte_Pim_ArrFrCmrLnAppl(void)
 *   ArrFrCmrLnHost *Rte_Pim_ArrFrCmrLnHost(void)
 *   ArrFrCmrLnRdEdg *Rte_Pim_ArrFrCmrLnRdEdg(void)
 *
 *********************************************************************************************************************/


# define CpApLane_Core2_START_SEC_CODE
# include "CpApLane_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLDW
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLDW> of PortPrototype <PP_FrCmrHdrLDW>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLDW(FrCmrHdrLDW_t *FrCmrHdrLDW)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLDW_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrHdrLDW Re_CpApLane_Core2_FrCmrHdrLDW
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLDW(P2VAR(FrCmrHdrLDW_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLDW); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnAdj
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnAdj> of PortPrototype <PP_FrCmrHdrLnAdj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnAdj(FrCmrHdrLnAdj_t *FrCmrHdrLnAdj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnAdj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrHdrLnAdj Re_CpApLane_Core2_FrCmrHdrLnAdj
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnAdj(P2VAR(FrCmrHdrLnAdj_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnAdj); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnAppl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnAppl> of PortPrototype <PP_FrCmrHdrLnAppl>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnAppl(FrCmrHdrLnAppl_t *FrCmrHdrLnAppl)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnAppl_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrHdrLnAppl Re_CpApLane_Core2_FrCmrHdrLnAppl
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnAppl(P2VAR(FrCmrHdrLnAppl_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnAppl); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnHost
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnHost> of PortPrototype <PP_FrCmrHdrLnHost>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrHdrLnHost Re_CpApLane_Core2_FrCmrHdrLnHost
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnHost(P2VAR(FrCmrHdrLnHost_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnRdEdg
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnRdEdg> of PortPrototype <PP_FrCmrHdrLnRdEdg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnRdEdg(FrCmrHdrLnRdEdg_t *FrCmrHdrLnRdEdg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrHdrLnRdEdg Re_CpApLane_Core2_FrCmrHdrLnRdEdg
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnRdEdg(P2VAR(FrCmrHdrLnRdEdg_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnRdEdg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLDW
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLDW> of PortPrototype <PP_FrCmrLDW>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLDW(LDW_t *FrCmrLDW)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLDW_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrLDW Re_CpApLane_Core2_FrCmrLDW
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLDW(P2VAR(LDW_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLDW); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnAdj
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnAdj> of PortPrototype <PP_FrCmrLnAdj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnAdj(LanesAdjacent_t *FrCmrLnAdj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnAdj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrLnAdj Re_CpApLane_Core2_FrCmrLnAdj
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnAdj(P2VAR(LanesAdjacent_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnAdj); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnAppl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnAppl> of PortPrototype <PP_FrCmrLnAppl>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnAppl(LanesApplications_t *FrCmrLnAppl)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnAppl_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrLnAppl Re_CpApLane_Core2_FrCmrLnAppl
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnAppl(P2VAR(LanesApplications_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnAppl); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnHost
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnHost> of PortPrototype <PP_FrCmrLnHost>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnHost_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrLnHost Re_CpApLane_Core2_FrCmrLnHost
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnRdEdg
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnRdEdg> of PortPrototype <PP_FrCmrLnRdEdg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnRdEdg(LanesRoadEdge_t *FrCmrLnRdEdg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnRdEdg_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_FrCmrLnRdEdg Re_CpApLane_Core2_FrCmrLnRdEdg
FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnRdEdg(P2VAR(LanesRoadEdge_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnRdEdg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_Init Re_CpApLane_Core2_Init
FUNC(void, CpApLane_Core2_CODE) Re_CpApLane_Core2_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(float32 *LDW_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(float32 *LDW_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(uint8 *LDW_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, uint32 *LDW_Suppression_Reason_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, uint32 *LDW_Suppression_Reason_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(uint8 *LDW_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, float32 *LDW_Time_To_Warning_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, float32 *LDW_Time_To_Warning_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, uint8 *LDW_Warning_Status_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, uint8 *LDW_Warning_Status_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_2(uint16 Index, uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_3(uint16 Index, uint16 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_4(uint16 Index, uint32 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Adjacent_Count(uint8 *LA_Adjacent_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Age(uint16 Index, uint8 *LA_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Availability_State(uint16 Index, uint8 *LA_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color(uint16 Index, uint8 *LA_Color)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color_Conf(uint16 Index, uint8 *LA_Color_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Confidence(uint16 Index, uint8 *LA_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DECEL_Type(uint16 Index, uint8 *LA_DECEL_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DLM_Type(uint16 Index, uint8 *LA_DLM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lane_Track_ID(uint16 Index, uint8 *LA_Lane_Track_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type(uint16 Index, uint8 *LA_Lanemark_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type_Conf(uint16 Index, uint8 *LA_Lanemark_Type_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C0(uint16 Index, float32 *LA_Line_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C1(uint16 Index, float32 *LA_Line_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C2(uint16 Index, float32 *LA_Line_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C3(uint16 Index, float32 *LA_Line_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_Side(uint16 Index, uint8 *LA_Line_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width(uint16 Index, uint8 *LA_Marker_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width_STD(uint16 Index, uint8 *LA_Marker_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Measured_VR_End(uint16 Index, uint16 *LA_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Prediction_Reason(uint16 Index, uint8 *LA_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Protocol_Version(uint8 *LA_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Sync_ID(uint8 *LA_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_End(uint16 Index, uint16 *LA_View_Range_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_Start(uint16 Index, uint16 *LA_View_Range_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LH_Buffer_C1(uint16 Index, uint8 *LH_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_4(uint16 Index, uint32 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c3(uint8 *LAP_Buffer_c3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c4(uint8 *LAP_Buffer_c4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c5(uint8 *LAP_Buffer_c5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(uint8 *LAP_Exit_Merge_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(uint8 *LAP_INTP_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, uint8 *LAP_INTP_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(uint8 *LAP_INTP_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, uint16 *LAP_INTP_Distance_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, uint8 *LAP_INTP_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, uint8 *LAP_INTP_Is_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, uint8 *LAP_INTP_Is_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, uint16 *LAP_INTP_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, uint16 *LAP_INTP_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, uint8 *LAP_INTP_Role)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, uint8 *LAP_INTP_SRD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, uint8 *LAP_INTP_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(uint8 *LAP_Is_Highway_Exit_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(uint8 *LAP_Is_Highway_Exit_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(uint8 *LAP_Is_Highway_Merge_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(uint8 *LAP_Is_Highway_Merge_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(uint8 *LAP_Path_Pred_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(uint32 *LAP_Path_Pred_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(uint8 *LAP_Path_Pred_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(float32 *LAP_Path_Pred_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(float32 *LAP_Path_Pred_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(float32 *LAP_Path_Pred_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(float32 *LAP_Path_Pred_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(uint16 *LAP_Path_Pred_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(uint8 *LAP_Path_Pred_First_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(uint16 *LAP_Path_Pred_Half_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Is_Triggered_SDM_Model(uint8 *LAP_Path_Pred_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(float32 *LAP_Path_Pred_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(float32 *LAP_Path_Pred_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(float32 *LAP_Path_Pred_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(float32 *LAP_Path_Pred_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(uint8 *LAP_Path_Pred_Second_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(uint16 *LAP_Path_Pred_second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(uint8 *LAP_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(uint8 *LAP_Snow_On_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(uint8 *LAP_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(uint8 *LAP_Vertical_Surface_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(float32 *LAP_Vertical_Surface_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(float32 *LAP_Vertical_Surface_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(float32 *LAP_Vertical_Surface_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(float32 *LAP_Vertical_Surface_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(uint16 *LAP_Vertical_Surface_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_2(uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_3(uint32 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_4(uint16 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_5(uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_6(uint32 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_8(uint16 Index, uint8 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_9(uint16 Index, uint32 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Age(uint16 Index, uint8 *LH_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Availability_State(uint16 Index, uint8 *LH_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Buffer_C3(uint16 Index, uint8 *LH_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_CRC(uint16 Index, uint32 *LH_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color(uint16 Index, uint8 *LH_Color)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color_Confidence(uint16 Index, uint8 *LH_Color_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Confidence(uint16 Index, uint8 *LH_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Crossing(uint16 Index, uint8 *LH_Crossing)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DECEL_Type(uint16 Index, uint8 *LH_DECEL_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DLM_Type(uint16 Index, uint8 *LH_DLM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Available(uint16 Index, uint8 *LH_Dash_Average_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Gap(uint16 Index, uint8 *LH_Dash_Average_Gap)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Length(uint16 Index, uint8 *LH_Dash_Average_Length)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Estimated_Width(uint16 *LH_Estimated_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_Measured_VR_End(uint16 Index, uint16 *LH_First_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_End(uint16 Index, uint16 *LH_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_Start(uint16 Index, uint16 *LH_First_VR_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Construction_Area(uint16 Index, uint8 *LH_Is_Construction_Area)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Multi_Clothoid(uint16 Index, uint8 *LH_Is_Multi_Clothoid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Model(uint16 Index, uint8 *LH_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Type(uint16 Index, uint8 *LH_Is_Triggered_SDM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type(uint16 Index, uint8 *LH_Lanemark_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type_Conf(uint16 Index, uint8 *LH_Lanemark_Type_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanes_Count(uint8 *LH_Lanes_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C0(uint16 Index, float32 *LH_Line_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C1(uint16 Index, float32 *LH_Line_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C2(uint16 Index, float32 *LH_Line_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C3(uint16 Index, float32 *LH_Line_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C0(uint16 Index, float32 *LH_Line_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C1(uint16 Index, float32 *LH_Line_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C2(uint16 Index, float32 *LH_Line_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C3(uint16 Index, float32 *LH_Line_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width(uint16 Index, uint8 *LH_Marker_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width_STD(uint16 Index, uint8 *LH_Marker_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Prediction_Reason(uint16 Index, uint8 *LH_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Protocol_Version(uint8 *LH_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_Measured_VR_End(uint16 Index, uint16 *LH_Second_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_End(uint16 Index, uint16 *LH_Second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_Start(uint16 Index, uint16 *LH_Second_VR_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Side(uint16 Index, uint8 *LH_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Sync_ID(uint8 *LH_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Track_ID(uint16 Index, uint8 *LH_Track_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_2(uint32 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_6(uint16 Index, uint16 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_7(uint16 Index, uint32 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_LNHST_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Age(uint16 Index, uint8 *LRE_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Availability_State(uint16 Index, uint8 *LRE_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Buffer_C4(uint16 Index, uint8 *LRE_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Confidence(uint16 Index, uint8 *LRE_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Count(uint8 *LRE_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_Buffer(uint16 Index, uint32 *LRE_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_CRC(uint16 Index, uint32 *LRE_Element_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_Buffer(uint16 *LRE_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_CRC(uint32 *LRE_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height(uint16 Index, uint8 *LRE_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height_STD(uint16 Index, uint8 *LRE_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_ID(uint16 Index, uint8 *LRE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Is_Triggered_SDM_Model(uint16 Index, uint8 *LRE_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C0(uint16 Index, float32 *LRE_Line_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C1(uint16 Index, float32 *LRE_Line_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C2(uint16 Index, float32 *LRE_Line_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C3(uint16 Index, float32 *LRE_Line_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Measured_VR_End(uint16 Index, uint16 *LRE_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Position(uint16 Index, uint8 *LRE_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Prediction_Reason(uint16 Index, uint8 *LRE_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Protocol_Version(uint8 *LRE_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Side(uint16 Index, uint8 *LRE_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Sync_ID(uint8 *LRE_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Type(uint16 Index, uint8 *LRE_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_End(uint16 Index, uint16 *LRE_View_Range_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_Start(uint16 Index, uint16 *LRE_View_Range_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_1(uint32 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_4(uint16 Index, uint16 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_LNRE_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLane_Core2_Main Re_CpApLane_Core2_Main
FUNC(void, CpApLane_Core2_CODE) Re_CpApLane_Core2_Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApLane_Core2_STOP_SEC_CODE
# include "CpApLane_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLDW_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnAdj_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnAppl_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType (1U)

# define RTE_E_IF_FrCmrLDW_ReturnType (1U)

# define RTE_E_IF_FrCmrLnAdj_ReturnType (1U)

# define RTE_E_IF_FrCmrLnAppl_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrLnRdEdg_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPLANE_CORE2_H */
