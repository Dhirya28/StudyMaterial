/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApWdgMonCore2_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApWdgMonCore2
 *  Generation Time:  2023-04-20 13:52:59
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApWdgMonCore2> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPWDGMONCORE2_TYPE_H
# define _RTE_CPAPWDGMONCORE2_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"

/**********************************************************************************************************************
 * Range, Invalidation, Enumeration and Bit Field Definitions
 *********************************************************************************************************************/

# ifndef WDGM_GLOBAL_STATUS_OK
#  define WDGM_GLOBAL_STATUS_OK (0U)
# endif

# ifndef WDGM_GLOBAL_STATUS_FAILED
#  define WDGM_GLOBAL_STATUS_FAILED (1U)
# endif

# ifndef WDGM_GLOBAL_STATUS_EXPIRED
#  define WDGM_GLOBAL_STATUS_EXPIRED (2U)
# endif

# ifndef WDGM_GLOBAL_STATUS_STOPPED
#  define WDGM_GLOBAL_STATUS_STOPPED (3U)
# endif

# ifndef WDGM_GLOBAL_STATUS_DEACTIVATED
#  define WDGM_GLOBAL_STATUS_DEACTIVATED (4U)
# endif

# ifndef WDGM_LOCAL_STATUS_OK
#  define WDGM_LOCAL_STATUS_OK (0U)
# endif

# ifndef WDGM_LOCAL_STATUS_FAILED
#  define WDGM_LOCAL_STATUS_FAILED (1U)
# endif

# ifndef WDGM_LOCAL_STATUS_EXPIRED
#  define WDGM_LOCAL_STATUS_EXPIRED (2U)
# endif

# ifndef WDGM_LOCAL_STATUS_DEACTIVATED
#  define WDGM_LOCAL_STATUS_DEACTIVATED (4U)
# endif



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_ProxyCore2Ready
#  define RTE_MODETYPE_ProxyCore2Ready
typedef uint8 Rte_ModeType_ProxyCore2Ready;
# endif
# ifndef RTE_MODETYPE_WdgM_Mode
#  define RTE_MODETYPE_WdgM_Mode
typedef uint8 Rte_ModeType_WdgM_Mode;
# endif

# define RTE_MODE_CpApWdgMonCore2_ProxyCore2Ready_False (0U)
# ifndef RTE_MODE_ProxyCore2Ready_False
#  define RTE_MODE_ProxyCore2Ready_False (0U)
# endif
# define RTE_MODE_CpApWdgMonCore2_ProxyCore2Ready_True (1U)
# ifndef RTE_MODE_ProxyCore2Ready_True
#  define RTE_MODE_ProxyCore2Ready_True (1U)
# endif
# define RTE_TRANSITION_CpApWdgMonCore2_ProxyCore2Ready (2U)
# ifndef RTE_TRANSITION_ProxyCore2Ready
#  define RTE_TRANSITION_ProxyCore2Ready (2U)
# endif

# define RTE_MODE_CpApWdgMonCore2_WdgM_Mode_SUPERVISION_OK (0U)
# ifndef RTE_MODE_WdgM_Mode_SUPERVISION_OK
#  define RTE_MODE_WdgM_Mode_SUPERVISION_OK (0U)
# endif
# define RTE_MODE_CpApWdgMonCore2_WdgM_Mode_SUPERVISION_FAILED (1U)
# ifndef RTE_MODE_WdgM_Mode_SUPERVISION_FAILED
#  define RTE_MODE_WdgM_Mode_SUPERVISION_FAILED (1U)
# endif
# define RTE_MODE_CpApWdgMonCore2_WdgM_Mode_SUPERVISION_EXPIRED (2U)
# ifndef RTE_MODE_WdgM_Mode_SUPERVISION_EXPIRED
#  define RTE_MODE_WdgM_Mode_SUPERVISION_EXPIRED (2U)
# endif
# define RTE_MODE_CpApWdgMonCore2_WdgM_Mode_SUPERVISION_STOPPED (3U)
# ifndef RTE_MODE_WdgM_Mode_SUPERVISION_STOPPED
#  define RTE_MODE_WdgM_Mode_SUPERVISION_STOPPED (3U)
# endif
# define RTE_MODE_CpApWdgMonCore2_WdgM_Mode_SUPERVISION_DEACTIVATED (4U)
# ifndef RTE_MODE_WdgM_Mode_SUPERVISION_DEACTIVATED
#  define RTE_MODE_WdgM_Mode_SUPERVISION_DEACTIVATED (4U)
# endif
# define RTE_TRANSITION_CpApWdgMonCore2_WdgM_Mode (255U)
# ifndef RTE_TRANSITION_WdgM_Mode
#  define RTE_TRANSITION_WdgM_Mode (255U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPWDGMONCORE2_TYPE_H */
