/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApObjt_Core2.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApObjt_Core2
 *  Generation Time:  2023-04-20 13:52:44
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApObjt_Core2> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPOBJT_CORE2_H
# define _RTE_CPAPOBJT_CORE2_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApObjt_Core2_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApObjt_Core2
{
  /* PIM Handles section */
  P2VAR(ArrFrCmrCA, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrCA; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrFcfVd, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrFcfVd; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrFcfVru, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrFcfVru; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ArrFrCmrObj, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrObj; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApObjt_Core2, RTE_CONST, RTE_CONST) Rte_Inst_CpApObjt_Core2; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApObjt_Core2, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8 (0U)
# define Rte_InitValue_RP_Eol_DriveType_DriveType (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_RxMsgsInFrame (0ULL)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_Core2ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_Eol_DriveType_DriveType(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_EyeQ_FrameReady_RxMsgsInFrame(P2VAR(uint64, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApObjt_Core2_RP_VdVruSupp_De_VdVruSuppFlagInfo(P2VAR(VdVruSuppFlagInfo_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApObjt_Core2_PP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(P2CONST(IsMsgVaildObjtAEBStatus_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(P2VAR(EYEQMESP_EnvironmentParams_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Application_version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Brain_drops_counter); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_CRC32); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera1_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera1_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera1_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera1_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera2_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera2_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera2_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera2_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera3_VideoErrorFlags_pt1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera3_VideoErrorFlags_pt2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera3_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Camera3_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Diagnostics_part_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Diagnostics_part_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_External_Video_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(P2VAR(sint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_EyeQTemperature1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(P2VAR(sint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_EyeQTemperature2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_EyeQ_Current_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_EyeQ_Process_Index); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_EyeQ_Timestamp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_FE_OPTICAL_PATH_DEVICE_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Internal_Camera_Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Internal_Fatal_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Minor_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_RSRV_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_SPI_Bus_Load_Rx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_SPI_Bus_Load_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_SPI_Retransmit_Tx); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Sub_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(P2VAR(sint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Temperature_DDR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Valid_cameras_information); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_Valid_second_cam_temp_info); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_ZQ_Cal_internal_diag1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_ZQ_Cal_internal_diag2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_appMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) APP_spiErrors); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Application_Message_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Camera_Source(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Camera_Source); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Existence_Prob(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Existence_Prob); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Frame_Age(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Frame_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Lat_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Lat_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Long_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Long_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Measurement_Status(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Measurement_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Object_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Object_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Object_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Object_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Object_Width_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Objects_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Objects_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Type_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) CA_Type_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_2(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_6(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_7(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_FCFVDDYN_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C0(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_DYN_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_DYN_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C2(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_DYN_Buffer_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_DYN_Buffer_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_AEB_Supp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp_FCV(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_AEB_Supp_FCV); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Alert(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Alert); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Element_Buffer(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Element_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_FCW_Supp(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_FCW_Supp); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HW_Supp_Reason(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_HW_Supp_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Alert(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_HeadWay_Alert); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Distance(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_HeadWay_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_Buffer(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Header_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID_FCV(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_ID_FCV); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SET_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_SET_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Safety_Suppressed(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Safety_Suppressed); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Set_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_Set_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SyncID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_SyncID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_TTC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC_Thresh(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VD_Dyn_TTC_Thresh); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_2(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_3(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_4(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_6(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_FCFVRUDYN_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_DYN_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_DYN_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_SyncID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_DYN_SyncID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Alert(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Alert); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C0(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C1(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Curr_In_Path(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Curr_In_Path); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Element_Buffer(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Element_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Header_Buffer(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Header_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Level_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Level_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_PED_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_PED_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Pred_In_Path(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Pred_In_Path); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Safety_Suppressed(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Safety_Suppressed); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Set_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Set_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Suppress(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_Suppress); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_TTC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC_Thresh(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FCF_VRU_Dyn_TTC_Thresh); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_2(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Bicycle_Probability(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_2W_Is_Bicycle_Probability); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Motorbike_Probability(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_2W_Is_Motorbike_Probability); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Acc_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Acc_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Acceleration); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Acceleration_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Acc); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Acc_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Acc_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Acc_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Vel_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Vel_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Velocity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Velocity_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Lat_Velocity_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Acc); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Acc_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Acc_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Acc_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Vel_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Vel_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Velocity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Velocity_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Abs_Long_Velocity_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Absolute_Speed); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Absolute_Speed_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Absolute_Speed_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Absolute_Speed_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Age_Seconds); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Age_Seconds_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Bottom); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Bottom_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Bottom_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Bottom_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Left_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Left_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Left_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Mid); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Mid_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Mid_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Mid_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Rate); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Rate_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Rate_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Rate_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Right_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Right_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Right_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Side_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Side_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Angle_Side_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Animal_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Animal_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Bottom_Out_Of_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Bottom_Out_Of_Image_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Brake_Light); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light_Validity(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Brake_Light_Validity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C0(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C1(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C10(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C10); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C11(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C11); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C12(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C12); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C13(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C13); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C16(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C17(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C17); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C2(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C20(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C20); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C21(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C21); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C6(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C7(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C8(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C9(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Buffer_C9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Camera_Source(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Camera_Source); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Class_Probability(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Class_Probability); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_LIGHT_COLOR(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_EMERGENCY_LIGHT_COLOR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_EMERGENCY_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Existence_Probability(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Existence_Probability); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Fusion_Source(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Fusion_Source); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_General_OBJ_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_General_OBJ_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Lane(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Has_Cut_Lane); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Path(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Has_Cut_Path); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Heading); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Heading_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Heading_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Heading_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Height_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Height_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Inv_TTC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Inv_TTC_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Inv_TTC_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Inv_TTC_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_Blocked_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_Blocked_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_EMERGENCY_VCL(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_EMERGENCY_VCL); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_In_Drivable_Area); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_In_Drivable_Area_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_VeryClose); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Is_VeryClose_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lane_Assignment); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lane_Assignment_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lat_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lat_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lat_Distance_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Lat_Distance_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Left_Out_Of_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Left_Out_Of_Image_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Length); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Length_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Length_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Length_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Long_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Long_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Long_Distance_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Long_Distance_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Measuring_Status(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Measuring_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Category(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Motion_Category); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Orientation(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Motion_Orientation); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Status(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Motion_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Age(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Object_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Class(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Object_Class); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Left(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Open_Door_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Right(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Open_Door_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Radar_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Radar_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Lat_Vel_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Rel_Lat_Vel_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Acc_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Rel_Long_Acc_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Vel_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Rel_Long_Vel_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Lat_Velocity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Lat_Velocity_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Lat_Velocity_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Acc); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Acc_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Acc_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Vel_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Vel_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Velocity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Relative_Long_Velocity_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Right_Out_Of_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Right_Out_Of_Image_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Top_Out_Of_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Top_Out_Of_Image_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Triggered_SDM(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Triggered_SDM); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Left(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Turn_Indicator_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Right(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Turn_Indicator_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Validity(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Turn_Indicator_Validity); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Allow_Acc(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_Allow_Acc); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_CIPV_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_Lost(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_CIPV_Lost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Left(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_NIV_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Right(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VD_NIV_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VRU_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_VRU_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Visibility_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Visibility_Side_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Visible_Left_or_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Visible_Left_or_Right_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Width_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Width_STD_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_V(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) OBJ_Width_V); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Obj_partially_in_lane(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Obj_partially_in_lane); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_1(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_10(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_10); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_11(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_11); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_12(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_12); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_13(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_13); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_14(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_14); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_15(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_15); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_16(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_17(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_17); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_18(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_18); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_19(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_19); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_2(P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_20(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_20); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_21(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_21); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_22(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_22); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_23(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_23); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_24(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_24); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_25(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_25); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_26(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_26); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_27(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_27); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_3(P2VAR(uint32, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_6(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_7(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_8(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_9(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) Reserved_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_OBJT_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApObjt_Core2_RP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8 Rte_Read_CpApObjt_Core2_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8
# define Rte_Read_RP_Eol_DriveType_DriveType Rte_Read_CpApObjt_Core2_RP_Eol_DriveType_DriveType
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApObjt_Core2_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame Rte_Read_CpApObjt_Core2_RP_EyeQ_FrameReady_RxMsgsInFrame
# define Rte_Read_RP_VdVruSupp_De_VdVruSuppFlagInfo Rte_Read_CpApObjt_Core2_RP_VdVruSupp_De_VdVruSuppFlagInfo


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus Rte_Write_CpApObjt_Core2_PP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams Rte_Call_CpApObjt_Core2_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Camera_Source Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Camera_Source
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Existence_Prob Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Existence_Prob
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Frame_Age Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Frame_Age
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_ID
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Measurement_Status Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Measurement_Status
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Type Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Type
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width_STD
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Objects_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Objects_Count
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Protocol_Version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Sync_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Type_Confidence Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Type_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_4 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_5 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_6 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_7 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_7
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_FCFVDDYN_IsMsgValid Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_FCFVDDYN_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C0 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C2
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C3
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp_FCV Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp_FCV
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Alert Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Alert
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Count
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Element_Buffer Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Element_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_FCW_Supp Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_FCW_Supp
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HW_Supp_Reason Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HW_Supp_Reason
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Alert Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Alert
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Distance Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Distance
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_Buffer Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID_FCV Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID_FCV
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Protocol_Version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SET_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SET_ID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Safety_Suppressed Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Safety_Suppressed
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Set_Type Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Set_Type
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SyncID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SyncID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC_Thresh Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC_Thresh
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_4 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_5 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_6 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_FCFVRUDYN_IsMsgValid Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_FCFVRUDYN_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Header_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Protocol_Version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_SyncID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_SyncID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Alert Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Alert
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C0 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Count
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Curr_In_Path Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Curr_In_Path
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Element_Buffer Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Element_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Header_Buffer Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Header_Buffer
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Level_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Level_ID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_PED_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_PED_ID
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Pred_In_Path Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Pred_In_Path
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Safety_Suppressed Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Safety_Suppressed
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Set_Type Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Set_Type
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Suppress Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Suppress
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC_Thresh Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC_Thresh
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Bicycle_Probability Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Bicycle_Probability
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Motorbike_Probability Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Motorbike_Probability
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Vel_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Vel_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Vel_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Vel_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Animal_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Animal_Count
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light_Validity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light_Validity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C0 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C10 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C10
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C11 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C11
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C12 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C12
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C13 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C13
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C16 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C16
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C17 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C17
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C2
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C20 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C20
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C21 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C21
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C3
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C4 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C4
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C5 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C5
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C6 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C6
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C7 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C7
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C8 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C8
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C9 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C9
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_CRC
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Camera_Source Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Camera_Source
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Class_Probability Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Class_Probability
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_LIGHT_COLOR Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_LIGHT_COLOR
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Existence_Probability Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Existence_Probability
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Fusion_Source Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Fusion_Source
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_General_OBJ_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_General_OBJ_Count
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Lane Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Lane
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Path Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Path
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Header_CRC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_ID
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Left Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Left
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_EMERGENCY_VCL Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_EMERGENCY_VCL
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Measuring_Status Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Measuring_Status
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Category Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Category
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Orientation Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Orientation
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Status Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Status
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Age Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Age
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Class Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Class
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Left Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Left
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Protocol_Version Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Radar_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Radar_ID
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Lat_Vel_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Lat_Vel_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Acc_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Acc_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Vel_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Vel_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Vel_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Vel_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Sync_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Triggered_SDM Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Triggered_SDM
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Left Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Left
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Validity Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Validity
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Allow_Acc Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Allow_Acc
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_ID Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_ID
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_Lost Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_Lost
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Count
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Left Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Left
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VRU_Count Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VRU_Count
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_V Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_V
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Obj_partially_in_lane Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Obj_partially_in_lane
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_1 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_10 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_10
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_11 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_11
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_12 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_12
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_13 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_13
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_14 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_14
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_15 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_15
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_16 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_16
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_17 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_17
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_18 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_18
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_19 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_19
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_2 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_20 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_20
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_21 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_21
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_22 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_22
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_23 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_23
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_24 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_24
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_25 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_25
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_26 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_26
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_27 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_27
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_3 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_4 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_5 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_6 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_7 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_7
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_8 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_8
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_9 Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_9
# define Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_OBJT_IsMsgValid Rte_Call_CpApObjt_Core2_RP_EyeQCddSatCore2_OBJT_EYEQDG_OBJT_IsMsgValid


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_ArrFrCmrCA() (Rte_Inst_CpApObjt_Core2->Pim_ArrFrCmrCA) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrFcfVd() (Rte_Inst_CpApObjt_Core2->Pim_ArrFrCmrFcfVd) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrFcfVru() (Rte_Inst_CpApObjt_Core2->Pim_ArrFrCmrFcfVru) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ArrFrCmrObj() (Rte_Inst_CpApObjt_Core2->Pim_ArrFrCmrObj) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrCA *Rte_Pim_ArrFrCmrCA(void)
 *   ArrFrCmrFcfVd *Rte_Pim_ArrFrCmrFcfVd(void)
 *   ArrFrCmrFcfVru *Rte_Pim_ArrFrCmrFcfVru(void)
 *   ArrFrCmrObj *Rte_Pim_ArrFrCmrObj(void)
 *
 *********************************************************************************************************************/


# define CpApObjt_Core2_START_SEC_CODE
# include "CpApObjt_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrCA
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrCA> of PortPrototype <PP_FrCmrCA>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrCA(ConstructionArea_t *FrCmrCA)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrCA_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrCA Re_CpApObjt_Core2_FrCmrCA
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrCA(P2VAR(ConstructionArea_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrCA); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrFcfVd
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFcfVd> of PortPrototype <PP_FrCmrFcfVd>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFcfVd_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrFcfVd Re_CpApObjt_Core2_FrCmrFcfVd
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrFcfVd(P2VAR(FcfVd_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrFcfVru
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFcfVru> of PortPrototype <PP_FrCmrFcfVru>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFcfVru_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrFcfVru Re_CpApObjt_Core2_FrCmrFcfVru
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrFcfVru(P2VAR(FcfVru_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrHdrCA
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrCA> of PortPrototype <PP_FrCmrHdrCA>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrHdrCA(FrCmrHdrCA_t *FrCmrHdrCA)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrCA_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrHdrCA Re_CpApObjt_Core2_FrCmrHdrCA
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrHdrCA(P2VAR(FrCmrHdrCA_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrHdrCA); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrHdrFcfVd
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFcfVd> of PortPrototype <PP_FrCmrHdrFcfVd>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrHdrFcfVd(FrCmrHdrFcfVd_t *FrCmrHdrFcfVd)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFcfVd_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrHdrFcfVd Re_CpApObjt_Core2_FrCmrHdrFcfVd
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrHdrFcfVd(P2VAR(FrCmrHdrFcfVd_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrHdrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrHdrFcfVru
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFcfVru> of PortPrototype <PP_FrCmrHdrFcfVru>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrHdrFcfVru(FrCmrHdrFcfVru_t *FrCmrHdrFcfVru)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFcfVru_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrHdrFcfVru Re_CpApObjt_Core2_FrCmrHdrFcfVru
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrHdrFcfVru(P2VAR(FrCmrHdrFcfVru_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrHdrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrHdrObj
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrObj> of PortPrototype <PP_FrCmrHdrObj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrObj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrHdrObj Re_CpApObjt_Core2_FrCmrHdrObj
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_FrCmrObj
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrObj> of PortPrototype <PP_FrCmrObj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core2_FrCmrObj(Objects_t *FrCmrObj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_FrCmrObj Re_CpApObjt_Core2_FrCmrObj
FUNC(Std_ReturnType, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_FrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPOBJT_CORE2_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_Init Re_CpApObjt_Core2_Init
FUNC(void, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core2_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *   Std_ReturnType Rte_Read_RP_VdVruSupp_De_VdVruSuppFlagInfo(VdVruSuppFlagInfo_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(const IsMsgVaildObjtAEBStatus_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Camera_Source(uint16 Index, uint8 *CA_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Existence_Prob(uint16 Index, uint8 *CA_Existence_Prob)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Frame_Age(uint16 Index, uint8 *CA_Frame_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height(uint16 Index, uint16 *CA_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Height_STD(uint16 Index, uint16 *CA_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_ID(uint16 Index, uint8 *CA_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance(uint16 Index, uint16 *CA_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance_STD(uint16 Index, uint16 *CA_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance(uint16 Index, uint16 *CA_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance_STD(uint16 Index, uint16 *CA_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Measurement_Status(uint16 Index, uint8 *CA_Measurement_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height(uint16 Index, uint16 *CA_Object_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Height_STD(uint16 Index, uint16 *CA_Object_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Type(uint16 Index, uint8 *CA_Object_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width(uint16 Index, uint16 *CA_Object_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Object_Width_STD(uint16 Index, uint16 *CA_Object_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Objects_Count(uint8 *CA_Objects_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Protocol_Version(uint8 *CA_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Sync_ID(uint8 *CA_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_CA_Type_Confidence(uint16 Index, uint8 *CA_Type_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_2(uint16 Index, uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CONAR_EYEQDG_Get_CONAR_Reserved_7(uint16 Index, uint32 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_FCFVDDYN_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C0(uint8 *FCF_VD_DYN_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C1(uint8 *FCF_VD_DYN_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C2(uint8 *FCF_VD_DYN_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C3(uint16 Index, uint8 *FCF_VD_DYN_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp(uint16 Index, uint16 *FCF_VD_Dyn_AEB_Supp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp_FCV(uint16 *FCF_VD_Dyn_AEB_Supp_FCV)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Alert(uint16 Index, uint16 *FCF_VD_Dyn_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_CRC(uint16 Index, uint32 *FCF_VD_Dyn_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Count(uint8 *FCF_VD_Dyn_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Element_Buffer(uint16 Index, uint16 *FCF_VD_Dyn_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_FCW_Supp(uint16 Index, uint32 *FCF_VD_Dyn_FCW_Supp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HW_Supp_Reason(uint16 *FCF_VD_Dyn_HW_Supp_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Alert(uint8 *FCF_VD_Dyn_HeadWay_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Distance(uint16 *FCF_VD_Dyn_HeadWay_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_Buffer(uint8 *FCF_VD_Dyn_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_CRC(uint32 *FCF_VD_Dyn_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID(uint16 Index, uint8 *FCF_VD_Dyn_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID_FCV(uint8 *FCF_VD_Dyn_ID_FCV)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Protocol_Version(uint8 *FCF_VD_Dyn_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SET_ID(uint16 Index, uint8 *FCF_VD_Dyn_SET_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Safety_Suppressed(uint16 Index, uint8 *FCF_VD_Dyn_Safety_Suppressed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Set_Type(uint16 Index, uint8 *FCF_VD_Dyn_Set_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SyncID(uint8 *FCF_VD_Dyn_SyncID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC(uint16 Index, uint16 *FCF_VD_Dyn_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC_Thresh(uint16 Index, uint16 *FCF_VD_Dyn_TTC_Thresh)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_2(uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_3(uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_4(uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_FCFVRUDYN_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Header_CRC(uint32 *FCF_VRU_DYN_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Protocol_Version(uint8 *FCF_VRU_DYN_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_SyncID(uint8 *FCF_VRU_DYN_SyncID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Alert(uint16 Index, uint16 *FCF_VRU_Dyn_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C0(uint8 *FCF_VRU_Dyn_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C1(uint16 Index, uint8 *FCF_VRU_Dyn_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_CRC(uint16 Index, uint32 *FCF_VRU_Dyn_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Count(uint8 *FCF_VRU_Dyn_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Curr_In_Path(uint16 Index, uint8 *FCF_VRU_Dyn_Curr_In_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Element_Buffer(uint16 Index, uint32 *FCF_VRU_Dyn_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Header_Buffer(uint32 *FCF_VRU_Dyn_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Level_ID(uint16 Index, uint8 *FCF_VRU_Dyn_Level_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_PED_ID(uint16 Index, uint8 *FCF_VRU_Dyn_PED_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Pred_In_Path(uint16 Index, uint8 *FCF_VRU_Dyn_Pred_In_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Safety_Suppressed(uint16 Index, uint8 *FCF_VRU_Dyn_Safety_Suppressed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Set_Type(uint16 Index, uint8 *FCF_VRU_Dyn_Set_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Suppress(uint16 Index, uint8 *FCF_VRU_Dyn_Suppress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC(uint16 Index, uint16 *FCF_VRU_Dyn_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC_Thresh(uint16 Index, uint16 *FCF_VRU_Dyn_TTC_Thresh)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Bicycle_Probability(uint16 Index, uint8 *OBJ_2W_Is_Bicycle_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Motorbike_Probability(uint16 Index, uint8 *OBJ_2W_Is_Motorbike_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration(uint16 Index, uint16 *OBJ_Abs_Acceleration)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration_V(uint16 Index, uint8 *OBJ_Abs_Acceleration_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc(uint16 Index, uint16 *OBJ_Abs_Lat_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Lat_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Lat_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_V(uint16 Index, uint8 *OBJ_Abs_Lat_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Vel_STD_V(uint16 Index, uint8 *OBJ_Abs_Lat_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity(uint16 Index, uint16 *OBJ_Abs_Lat_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_STD(uint16 Index, uint16 *OBJ_Abs_Lat_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_V(uint16 Index, uint8 *OBJ_Abs_Lat_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc(uint16 Index, uint16 *OBJ_Abs_Long_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Long_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Long_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_V(uint16 Index, uint8 *OBJ_Abs_Long_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Vel_STD_V(uint16 Index, uint8 *OBJ_Abs_Long_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity(uint16 Index, uint16 *OBJ_Abs_Long_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_STD(uint16 Index, uint16 *OBJ_Abs_Long_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_V(uint16 Index, uint8 *OBJ_Abs_Long_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed(uint16 Index, uint16 *OBJ_Absolute_Speed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD(uint16 Index, uint16 *OBJ_Absolute_Speed_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD_V(uint16 Index, uint8 *OBJ_Absolute_Speed_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_V(uint16 Index, uint8 *OBJ_Absolute_Speed_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds(uint16 Index, uint8 *OBJ_Age_Seconds)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds_V(uint16 Index, uint8 *OBJ_Age_Seconds_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom(uint16 Index, uint16 *OBJ_Angle_Bottom)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD(uint16 Index, uint16 *OBJ_Angle_Bottom_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD_V(uint16 Index, uint8 *OBJ_Angle_Bottom_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_V(uint16 Index, uint8 *OBJ_Angle_Bottom_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left(uint16 Index, uint16 *OBJ_Angle_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD(uint16 Index, uint16 *OBJ_Angle_Left_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD_V(uint16 Index, uint8 *OBJ_Angle_Left_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_V(uint16 Index, uint8 *OBJ_Angle_Left_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid(uint16 Index, uint16 *OBJ_Angle_Mid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD(uint16 Index, uint16 *OBJ_Angle_Mid_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD_V(uint16 Index, uint8 *OBJ_Angle_Mid_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_V(uint16 Index, uint8 *OBJ_Angle_Mid_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate(uint16 Index, uint16 *OBJ_Angle_Rate)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD(uint16 Index, uint16 *OBJ_Angle_Rate_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD_V(uint16 Index, uint8 *OBJ_Angle_Rate_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_V(uint16 Index, uint8 *OBJ_Angle_Rate_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right(uint16 Index, uint16 *OBJ_Angle_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD(uint16 Index, uint16 *OBJ_Angle_Right_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD_V(uint16 Index, uint8 *OBJ_Angle_Right_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_V(uint16 Index, uint8 *OBJ_Angle_Right_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side(uint16 Index, uint16 *OBJ_Angle_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD(uint16 Index, uint16 *OBJ_Angle_Side_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD_V(uint16 Index, uint8 *OBJ_Angle_Side_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_V(uint16 Index, uint8 *OBJ_Angle_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Animal_Count(uint8 *OBJ_Animal_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image(uint16 Index, uint8 *OBJ_Bottom_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Bottom_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light(uint16 Index, uint8 *OBJ_Brake_Light)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light_Validity(uint16 Index, uint8 *OBJ_Brake_Light_Validity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C0(uint16 Index, uint8 *OBJ_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C1(uint16 Index, uint8 *OBJ_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C10(uint16 Index, uint16 *OBJ_Buffer_C10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C11(uint16 Index, uint8 *OBJ_Buffer_C11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C12(uint16 Index, uint16 *OBJ_Buffer_C12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C13(uint16 Index, uint8 *OBJ_Buffer_C13)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C16(uint8 *OBJ_Buffer_C16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C17(uint8 *OBJ_Buffer_C17)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C2(uint16 Index, uint8 *OBJ_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C20(uint16 Index, uint8 *OBJ_Buffer_C20)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C21(uint16 Index, uint8 *OBJ_Buffer_C21)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C3(uint16 Index, uint8 *OBJ_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C4(uint16 Index, uint8 *OBJ_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C5(uint16 Index, uint8 *OBJ_Buffer_C5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C6(uint16 Index, uint8 *OBJ_Buffer_C6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C7(uint16 Index, uint8 *OBJ_Buffer_C7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C8(uint16 Index, uint16 *OBJ_Buffer_C8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C9(uint16 Index, uint16 *OBJ_Buffer_C9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_CRC(uint16 Index, uint32 *OBJ_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Camera_Source(uint16 Index, uint8 *OBJ_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Class_Probability(uint16 Index, uint8 *OBJ_Class_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_LIGHT_COLOR(uint16 Index, uint8 *OBJ_EMERGENCY_LIGHT_COLOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_V(uint16 Index, uint8 *OBJ_EMERGENCY_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Existence_Probability(uint16 Index, uint8 *OBJ_Existence_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Fusion_Source(uint16 Index, uint16 *OBJ_Fusion_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_General_OBJ_Count(uint8 *OBJ_General_OBJ_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Lane(uint16 Index, uint8 *OBJ_Has_Cut_Lane)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Path(uint16 Index, uint8 *OBJ_Has_Cut_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Header_CRC(uint32 *OBJ_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading(uint16 Index, uint16 *OBJ_Heading)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD(uint16 Index, uint16 *OBJ_Heading_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD_V(uint16 Index, uint8 *OBJ_Heading_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_V(uint16 Index, uint8 *OBJ_Heading_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height(uint16 Index, uint16 *OBJ_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD(uint16 Index, uint16 *OBJ_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD_V(uint16 Index, uint8 *OBJ_Height_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Height_V(uint16 Index, uint8 *OBJ_Height_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_ID(uint16 Index, uint8 *OBJ_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC(uint16 Index, uint16 *OBJ_Inv_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD(uint16 Index, uint16 *OBJ_Inv_TTC_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD_V(uint16 Index, uint8 *OBJ_Inv_TTC_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_V(uint16 Index, uint8 *OBJ_Inv_TTC_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Left(uint8 *OBJ_Is_Blocked_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Right(uint8 *OBJ_Is_Blocked_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_EMERGENCY_VCL(uint16 Index, uint8 *OBJ_Is_EMERGENCY_VCL)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area(uint16 Index, uint8 *OBJ_Is_In_Drivable_Area)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area_V(uint16 Index, uint8 *OBJ_Is_In_Drivable_Area_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose(uint16 Index, uint8 *OBJ_Is_VeryClose)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose_V(uint16 Index, uint8 *OBJ_Is_VeryClose_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment(uint16 Index, uint8 *OBJ_Lane_Assignment)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment_V(uint16 Index, uint8 *OBJ_Lane_Assignment_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance(uint16 Index, uint16 *OBJ_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD(uint16 Index, uint16 *OBJ_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD_V(uint16 Index, uint8 *OBJ_Lat_Distance_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_V(uint16 Index, uint8 *OBJ_Lat_Distance_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image(uint16 Index, uint8 *OBJ_Left_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Left_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length(uint16 Index, uint16 *OBJ_Length)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD(uint16 Index, uint16 *OBJ_Length_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD_V(uint16 Index, uint8 *OBJ_Length_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Length_V(uint16 Index, uint8 *OBJ_Length_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance(uint16 Index, uint16 *OBJ_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD(uint16 Index, uint16 *OBJ_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD_V(uint16 Index, uint8 *OBJ_Long_Distance_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_V(uint16 Index, uint8 *OBJ_Long_Distance_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Measuring_Status(uint16 Index, uint8 *OBJ_Measuring_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Category(uint16 Index, uint8 *OBJ_Motion_Category)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Orientation(uint16 Index, uint8 *OBJ_Motion_Orientation)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Status(uint16 Index, uint8 *OBJ_Motion_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Age(uint16 Index, uint16 *OBJ_Object_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Class(uint16 Index, uint8 *OBJ_Object_Class)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Left(uint16 Index, uint8 *OBJ_Open_Door_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Right(uint16 Index, uint8 *OBJ_Open_Door_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Protocol_Version(uint8 *OBJ_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Radar_ID(uint16 Index, uint8 *OBJ_Radar_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Lat_Vel_STD_V(uint16 Index, uint8 *OBJ_Rel_Lat_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Acc_STD_V(uint16 Index, uint8 *OBJ_Rel_Long_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Vel_STD_V(uint16 Index, uint8 *OBJ_Rel_Long_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity(uint16 Index, uint16 *OBJ_Relative_Lat_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_STD(uint16 Index, uint16 *OBJ_Relative_Lat_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_V(uint16 Index, uint8 *OBJ_Relative_Lat_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc(uint16 Index, uint16 *OBJ_Relative_Long_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_STD(uint16 Index, uint16 *OBJ_Relative_Long_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_V(uint16 Index, uint8 *OBJ_Relative_Long_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Vel_STD(uint16 Index, uint16 *OBJ_Relative_Long_Vel_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity(uint16 Index, uint16 *OBJ_Relative_Long_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity_V(uint16 Index, uint8 *OBJ_Relative_Long_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image(uint16 Index, uint8 *OBJ_Right_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Right_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Sync_ID(uint8 *OBJ_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image(uint16 Index, uint8 *OBJ_Top_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Top_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Triggered_SDM(uint16 Index, uint8 *OBJ_Triggered_SDM)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Left(uint16 Index, uint8 *OBJ_Turn_Indicator_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Right(uint16 Index, uint8 *OBJ_Turn_Indicator_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Validity(uint16 Index, uint8 *OBJ_Turn_Indicator_Validity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Allow_Acc(uint8 *OBJ_VD_Allow_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_ID(uint8 *OBJ_VD_CIPV_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_Lost(uint8 *OBJ_VD_CIPV_Lost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Count(uint8 *OBJ_VD_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Left(uint8 *OBJ_VD_NIV_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Right(uint8 *OBJ_VD_NIV_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_VRU_Count(uint8 *OBJ_VRU_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side(uint16 Index, uint8 *OBJ_Visibility_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side_V(uint16 Index, uint8 *OBJ_Visibility_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right(uint16 Index, uint8 *OBJ_Visible_Left_or_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right_V(uint16 Index, uint8 *OBJ_Visible_Left_or_Right_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width(uint16 Index, uint16 *OBJ_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD(uint16 Index, uint16 *OBJ_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD_V(uint16 Index, uint8 *OBJ_Width_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_OBJ_Width_V(uint16 Index, uint8 *OBJ_Width_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Obj_partially_in_lane(uint16 Index, uint8 *Obj_partially_in_lane)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_1(uint32 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_10(uint16 Index, uint8 *Reserved_10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_11(uint16 Index, uint8 *Reserved_11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_12(uint16 Index, uint8 *Reserved_12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_13(uint16 Index, uint16 *Reserved_13)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_14(uint16 Index, uint8 *Reserved_14)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_15(uint16 Index, uint8 *Reserved_15)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_16(uint16 Index, uint8 *Reserved_16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_17(uint16 Index, uint8 *Reserved_17)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_18(uint16 Index, uint8 *Reserved_18)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_19(uint16 Index, uint8 *Reserved_19)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_2(uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_20(uint16 Index, uint8 *Reserved_20)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_21(uint16 Index, uint8 *Reserved_21)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_22(uint16 Index, uint8 *Reserved_22)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_23(uint16 Index, uint8 *Reserved_23)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_24(uint16 Index, uint8 *Reserved_24)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_25(uint16 Index, uint16 *Reserved_25)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_26(uint16 Index, uint8 *Reserved_26)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_27(uint16 Index, uint32 *Reserved_27)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_3(uint32 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_8(uint16 Index, uint16 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_Get_OBJT_Reserved_9(uint16 Index, uint8 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_OBJT_EYEQDG_OBJT_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApObjt_Core2_Main Re_CpApObjt_Core2_Main
FUNC(void, CpApObjt_Core2_CODE) Re_CpApObjt_Core2_Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApObjt_Core2_STOP_SEC_CODE
# include "CpApObjt_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_CONAR_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_FCFVDDYN_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_FCFVRUDYN_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_OBJT_ReturnType (1U)

# define RTE_E_IF_FrCmrCA_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrCA_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPOBJT_CORE2_H */
