/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApObjt_Core1.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApObjt_Core1
 *  Generation Time:  2023-04-20 13:53:23
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApObjt_Core1>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Rte_DT_VdVruSuppFlagInfo_t_0
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_1
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_2
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_3
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApObjt_Core1.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Rte_DT_VdVruSuppFlagInfo_t_0: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_1: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_2: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_3: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 *
 * Array Types:
 * ============
 * Rte_DT_ArrFrCmrCA_0: Array with 10 element(s) of type ConstructionArea_t
 * Rte_DT_ArrFrCmrFcfVd_0: Array with 8 element(s) of type FcfVd_t
 * Rte_DT_ArrFrCmrFcfVru_0: Array with 8 element(s) of type FcfVru_t
 * Rte_DT_ArrFrCmrObj_0: Array with 20 element(s) of type Objects_t
 *
 * Record Types:
 * =============
 * ArrFrCmrCA: Record with elements
 *   FrCmrCA of type Rte_DT_ArrFrCmrCA_0
 * ArrFrCmrFcfVd: Record with elements
 *   FrCmrFcfVd of type Rte_DT_ArrFrCmrFcfVd_0
 * ArrFrCmrFcfVru: Record with elements
 *   FrCmrFcfVru of type Rte_DT_ArrFrCmrFcfVru_0
 * ArrFrCmrObj: Record with elements
 *   FrCmrObj of type Rte_DT_ArrFrCmrObj_0
 * ConstructionArea_t: Record with elements
 *   CA_ID of type uint8
 *   CA_Frame_Age of type uint8
 *   CA_Object_Type of type uint8
 *   CA_Object_Height of type uint16
 *   CA_Object_Height_STD of type uint16
 *   CA_Object_Width of type uint16
 *   CA_Object_Width_STD of type uint16
 *   CA_Long_Distance of type uint16
 *   CA_Long_Distance_STD of type uint16
 *   CA_Lat_Distance of type uint16
 *   CA_Lat_Distance_STD of type uint16
 *   CA_Height of type uint16
 *   CA_Height_STD of type uint16
 * EYEQMESP_EnvironmentParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   LeftWheel_u16 of type uint16
 *   RightWheel_u16 of type uint16
 *   RefPX_Front_Bumper_u16 of type uint16
 *   CamToFrontAxle_u16 of type uint16
 *   CamToRearAxle_u16 of type uint16
 *   WheelWidth_u8 of type uint8
 *   WheelRadius_u8 of type uint8
 *   MinHorizon_u16 of type uint16
 *   MaxHorizon_u16 of type uint16
 *   MinYaw_u16 of type uint16
 *   MaxYaw_u16 of type uint16
 *   MaxRoll_u16 of type uint16
 *   Top_Crop_u16 of type uint16
 *   Bottom_Crop_u16 of type uint16
 *   Steering_Ratio_u16 of type uint16
 *   GPSToCam_dx_u16 of type uint16
 *   GPSToCam_dy_u16 of type uint16
 *   GPSToCam_dz_u16 of type uint16
 *   GPSToCam_dx_V_u8 of type uint8
 *   GPSToCam_dy_V_u8 of type uint8
 *   GPSToCam_dz_V_u8 of type uint8
 *   Top_Crop_V_u8 of type uint8
 *   Steering_Ratio_V_u8 of type uint8
 *   WheelWidth_V_u8 of type uint8
 *   WheelRadius_V_u8 of type uint8
 *   LeftWheel_V_u8 of type uint8
 *   RightWheel_V_u8 of type uint8
 *   RefPX_Front_Bumper_V_u8 of type uint8
 *   CamToFrontAxle_V_u8 of type uint8
 *   CamToRearAxle_V_u8 of type uint8
 *   MinHorizon_V_u8 of type uint8
 *   MaxHorizon_V_u8 of type uint8
 *   MinYaw_V_u8 of type uint8
 *   MaxYaw_V_u8 of type uint8
 *   MaxRoll_V_u8 of type uint8
 *   Bottom_Crop_V_u8 of type uint8
 *   fixedGpsLatency_u8 of type uint8
 *   fixedGpsLatency_V_u8 of type uint8
 *   receiverFrequency_u8 of type uint8
 *   receiverFrequency_V_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * FcfVd_t: Record with elements
 *   FCF_VD_Dyn_CRC of type uint32
 *   FCF_VD_Dyn_Alert of type uint16
 *   FCF_VD_Dyn_ID of type uint8
 *   FCF_VD_Dyn_AEB_Supp of type uint16
 *   FCF_VD_Dyn_FCW_Supp of type uint32
 *   FCF_VD_Dyn_Set_Type of type uint8
 *   FCF_VD_Dyn_TTC_Thresh of type uint16
 *   FCF_VD_Dyn_TTC of type uint16
 * FcfVru_t: Record with elements
 *   FCF_VRU_Dyn_CRC of type uint32
 *   FCF_VRU_Dyn_Alert of type uint16
 *   FCF_VRU_Dyn_PED_ID of type uint8
 *   FCF_VRU_Dyn_Suppress of type uint8
 *   FCF_VRU_Dyn_Set_Type of type uint8
 *   FCF_VRU_Dyn_Curr_In_Path of type boolean
 *   FCF_VRU_Dyn_Pred_In_Path of type boolean
 *   FCF_VRU_Dyn_TTC of type uint16
 *   FCF_VRU_Dyn_TTC_Thresh of type uint16
 * FrCmrHdrCA_t: Record with elements
 *   CA_Protocol_Version of type uint8
 *   CA_Sync_ID of type uint8
 *   CA_Region_Code of type uint8
 *   CA_Objects_Count of type uint8
 * FrCmrHdrFcfVd_t: Record with elements
 *   FCF_VD_Dyn_Protocol_Version of type uint8
 *   FCF_VD_Dyn_SyncID of type uint8
 *   FCF_VD_Dyn_Header_CRC of type uint32
 *   FCF_VD_Dyn_AEB_Supp_FCV of type uint16
 *   FCF_VD_Dyn_Alert_FCV of type uint16
 *   FCF_VD_Dyn_ID_FCV of type uint8
 *   FCF_VD_Dyn_HeadWay_Alert of type boolean
 *   FCF_VD_Dyn_HeadWay_Distance of type uint16
 *   FCF_VD_Dyn_HW_Supp_Reason of type uint16
 * FrCmrHdrFcfVru_t: Record with elements
 *   FCF_VRU_Dyn_Protocol_Version of type uint8
 *   FCF_VRU_Dyn_SyncID of type uint8
 * FrCmrHdrObj_t: Record with elements
 *   OBJ_Header_CRC of type uint32
 *   OBJ_Protocol_Version of type uint8
 *   OBJ_Sync_ID of type uint8
 *   OBJ_VRU_Count of type uint8
 *   OBJ_VD_Count of type uint8
 *   OBJ_General_OBJ_Count of type uint8
 *   OBJ_Animal_Count of type uint8
 *   OBJ_VD_NIV_Left of type uint8
 *   OBJ_VD_NIV_Right of type uint8
 *   OBJ_VD_CIPV_ID of type uint8
 *   OBJ_VD_CIPV_Lost of type uint8
 *   OBJ_VD_Allow_Acc of type uint8
 *   OBJ_Is_Blocked_Left of type boolean
 *   OBJ_Is_Blocked_Right of type boolean
 * IsMsgVaildObjtAEBStatus_t: Record with elements
 *   VDStatus_u8 of type uint8
 *   VRUStatus_u8 of type uint8
 *   ObjtStatus_u8 of type uint8
 * Objects_t: Record with elements
 *   OBJ_CRC of type uint32
 *   OBJ_ID of type uint8
 *   OBJ_VD_CIPVFlag of type uint8
 *   OBJ_Existence_Probability of type uint8
 *   OBJ_Fusion_Source of type uint16
 *   OBJ_Triggered_SDM of type uint8
 *   OBJ_Motion_Category of type uint8
 *   OBJ_Object_Age of type uint16
 *   OBJ_Measuring_Status of type uint8
 *   OBJ_Object_Class of type uint8
 *   OBJ_Class_Probability of type uint8
 *   OBJ_Camera_Source of type uint8
 *   OBJ_Motion_Status of type uint8
 *   OBJ_Motion_Orientation of type uint8
 *   OBJ_Has_Cut_Lane of type boolean
 *   OBJ_Has_Cut_Path of type boolean
 *   OBJ_Brake_Light_Validity of type boolean
 *   OBJ_Brake_Light of type boolean
 *   OBJ_Turn_Indicator_Right of type boolean
 *   OBJ_Turn_Indicator_Left of type boolean
 *   OBJ_Turn_Indicator_Validity of type boolean
 *   OBJ_Right_Out_Of_Image of type boolean
 *   OBJ_Left_Out_Of_Image of type boolean
 *   OBJ_Right_Out_Of_Image_V of type boolean
 *   OBJ_Left_Out_Of_Image_V of type boolean
 *   OBJ_Top_Out_Of_Image of type boolean
 *   OBJ_Bottom_Out_Of_Image of type boolean
 *   OBJ_Top_Out_Of_Image_V of type boolean
 *   OBJ_Bottom_Out_Of_Image_V of type boolean
 *   OBJ_Lane_Assignment of type uint8
 *   OBJ_Lane_Assignment_V of type boolean
 *   OBJ_Age_Seconds of type uint8
 *   OBJ_Age_Seconds_V of type boolean
 *   OBJ_Width of type uint16
 *   OBJ_Width_V of type boolean
 *   OBJ_Width_STD of type uint16
 *   OBJ_Width_STD_V of type boolean
 *   OBJ_Length of type uint16
 *   OBJ_Length_V of type boolean
 *   OBJ_Length_STD of type uint16
 *   OBJ_Length_STD_V of type boolean
 *   OBJ_Height of type uint16
 *   OBJ_Height_V of type boolean
 *   OBJ_Height_STD of type uint16
 *   OBJ_Height_STD_V of type boolean
 *   OBJ_Abs_Long_Velocity of type uint16
 *   OBJ_Abs_Long_Velocity_V of type boolean
 *   OBJ_Abs_Long_Velocity_STD of type uint16
 *   OBJ_Abs_Long_Vel_STD_V of type boolean
 *   OBJ_Abs_Lat_Velocity of type uint16
 *   OBJ_Abs_Lat_Velocity_V of type boolean
 *   OBJ_Abs_Lat_Velocity_STD of type uint16
 *   OBJ_Abs_Lat_Vel_STD_V of type boolean
 *   OBJ_Abs_Long_Acc of type uint16
 *   OBJ_Abs_Long_Acc_V of type boolean
 *   OBJ_Abs_Long_Acc_STD of type uint16
 *   OBJ_Abs_Long_Acc_STD_V of type boolean
 *   OBJ_Abs_Lat_Acc of type uint16
 *   OBJ_Abs_Lat_Acc_V of type boolean
 *   OBJ_Abs_Lat_Acc_STD of type uint16
 *   OBJ_Abs_Lat_Acc_STD_V of type boolean
 *   OBJ_Abs_Acceleration of type uint16
 *   OBJ_Abs_Acceleration_V of type boolean
 *   OBJ_Abs_Acc_STD of type uint16
 *   OBJ_Abs_Acc_STD_V of type boolean
 *   OBJ_Inv_TTC of type uint16
 *   OBJ_Inv_TTC_V of type boolean
 *   OBJ_Inv_TTC_STD of type uint16
 *   OBJ_Inv_TTC_STD_V of type boolean
 *   OBJ_Relative_Long_Acc of type uint16
 *   OBJ_Relative_Long_Acc_V of type boolean
 *   OBJ_Relative_Long_Acc_STD of type uint16
 *   OBJ_Rel_Long_Acc_STD_V of type boolean
 *   OBJ_Relative_Long_Velocity of type uint16
 *   OBJ_Relative_Long_Velocity_V of type boolean
 *   OBJ_Relative_Long_Vel_STD of type uint16
 *   OBJ_Rel_Long_Vel_STD_V of type boolean
 *   OBJ_Relative_Lat_Velocity of type uint16
 *   OBJ_Relative_Lat_Velocity_V of type boolean
 *   OBJ_Relative_Lat_Velocity_STD of type uint16
 *   OBJ_Rel_Lat_Vel_STD_V of type boolean
 *   OBJ_Long_Distance of type uint16
 *   OBJ_Long_Distance_V of type boolean
 *   OBJ_Long_Distance_STD of type uint16
 *   OBJ_Long_Distance_STD_V of type boolean
 *   OBJ_Lat_Distance of type uint16
 *   OBJ_Lat_Distance_V of type boolean
 *   OBJ_Lat_Distance_STD of type uint16
 *   OBJ_Lat_Distance_STD_V of type boolean
 *   OBJ_Absolute_Speed of type uint16
 *   OBJ_Absolute_Speed_V of type boolean
 *   OBJ_Absolute_Speed_STD of type uint16
 *   OBJ_Absolute_Speed_STD_V of type boolean
 *   OBJ_Heading of type uint16
 *   OBJ_Heading_V of type boolean
 *   OBJ_Heading_STD of type uint16
 *   OBJ_Heading_STD_V of type boolean
 *   OBJ_Angle_Rate_STD of type uint16
 *   OBJ_Angle_Rate_STD_V of type boolean
 *   OBJ_Angle_Rate of type uint16
 *   OBJ_Angle_Rate_V of type boolean
 *   OBJ_Angle_Right of type uint16
 *   OBJ_Angle_Right_V of type boolean
 *   OBJ_Angle_Right_STD of type uint16
 *   OBJ_Angle_Right_STD_V of type boolean
 *   OBJ_Angle_Left of type uint16
 *   OBJ_Angle_Left_V of type boolean
 *   OBJ_Angle_Left_STD of type uint16
 *   OBJ_Angle_Left_STD_V of type boolean
 *   OBJ_Angle_Side of type uint16
 *   OBJ_Angle_Side_V of type boolean
 *   OBJ_Angle_Side_STD of type uint16
 *   OBJ_Angle_Side_STD_V of type boolean
 *   OBJ_Angle_Mid_V of type boolean
 *   OBJ_Angle_Mid of type uint16
 *   OBJ_Angle_Mid_STD of type uint16
 *   OBJ_Angle_Mid_STD_V of type boolean
 *   OBJ_Angle_Bottom_V of type boolean
 *   OBJ_Angle_Bottom of type uint16
 *   OBJ_Angle_Bottom_STD of type uint16
 *   OBJ_Angle_Bottom_STD_V of type boolean
 *   OBJ_Visibility_Side_V of type boolean
 *   OBJ_Visibility_Side of type uint8
 *   OBJ_Is_In_Drivable_Area of type boolean
 *   OBJ_Is_In_Drivable_Area_V of type boolean
 *   OBJ_Is_VeryClose_V of type boolean
 *   OBJ_Is_VeryClose of type boolean
 *   OBJ_Is_EMERGENCY_VCL of type boolean
 *   OBJ_EMERGENCY_LIGHT_COLOR of type uint8
 *   OBJ_EMERGENCY_V of type boolean
 *   OBJ_Open_Door_Left of type boolean
 *   OBJ_Open_Door_Right of type boolean
 *   OBJ_Visible_Left_or_Right of type uint8
 *   OBJ_Visible_Left_or_Right_V of type boolean
 *   OBJ_2W_Is_Motorbike_Probability of type uint8
 *   OBJ_2W_Is_Bicycle_Probability of type uint8
 *   Obj_partially_in_lane of type boolean
 * VdVruSuppFlagInfo_t: Record with elements
 *   VRU_FCW_PD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_0
 *   VRU_AEB_PD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_1
 *   VD_AEB_VD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_2
 *   VD_FCW_VD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_3
 * ZfAppCameraState_t: Record with elements
 *   CameraState_u8 of type uint8
 *   Camera_SubState_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u8 of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrCA *Rte_Pim_ArrFrCmrCA(void)
 *   ArrFrCmrFcfVd *Rte_Pim_ArrFrCmrFcfVd(void)
 *   ArrFrCmrFcfVru *Rte_Pim_ArrFrCmrFcfVru(void)
 *   ArrFrCmrObj *Rte_Pim_ArrFrCmrObj(void)
 *
 *********************************************************************************************************************/


#define CpApObjt_Core1_START_SEC_CODE
#include "CpApObjt_Core1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrCA
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrCA> of PortPrototype <PP_FrCmrCA>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrCA(ConstructionArea_t *FrCmrCA)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrCA_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrCA_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrCA(P2VAR(ConstructionArea_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrCA) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrCA (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrFcfVd
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFcfVd> of PortPrototype <PP_FrCmrFcfVd>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFcfVd_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrFcfVd_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrFcfVd(P2VAR(FcfVd_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrFcfVd) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrFcfVd (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrFcfVru
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFcfVru> of PortPrototype <PP_FrCmrFcfVru>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFcfVru_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrFcfVru_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrFcfVru(P2VAR(FcfVru_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrFcfVru) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrFcfVru (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrHdrCA
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrCA> of PortPrototype <PP_FrCmrHdrCA>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrHdrCA(FrCmrHdrCA_t *FrCmrHdrCA)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrCA_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrCA_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrHdrCA(P2VAR(FrCmrHdrCA_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrHdrCA) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrCA (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrHdrFcfVd
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFcfVd> of PortPrototype <PP_FrCmrHdrFcfVd>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrHdrFcfVd(FrCmrHdrFcfVd_t *FrCmrHdrFcfVd)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFcfVd_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrFcfVd_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrHdrFcfVd(P2VAR(FrCmrHdrFcfVd_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrHdrFcfVd) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrFcfVd (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrHdrFcfVru
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFcfVru> of PortPrototype <PP_FrCmrHdrFcfVru>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrHdrFcfVru(FrCmrHdrFcfVru_t *FrCmrHdrFcfVru)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFcfVru_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrFcfVru_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrHdrFcfVru(P2VAR(FrCmrHdrFcfVru_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrHdrFcfVru) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrFcfVru (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrHdrObj
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrObj> of PortPrototype <PP_FrCmrHdrObj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrObj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrObj_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrHdrObj) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrHdrObj (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_FrCmrObj
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrObj> of PortPrototype <PP_FrCmrObj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApObjt_Core1_FrCmrObj(Objects_t *FrCmrObj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrObj_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_FrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPOBJT_CORE1_APPL_VAR) FrCmrObj) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_FrCmrObj (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApObjt_Core1_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1Zf_SendDefaultData_DefaultObjectData_u8(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *   Std_ReturnType Rte_Read_RP_VdVruSupp_De_VdVruSuppFlagInfo(VdVruSuppFlagInfo_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(const IsMsgVaildObjtAEBStatus_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Camera_Source(uint16 Index, uint8 *CA_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Existence_Prob(uint16 Index, uint8 *CA_Existence_Prob)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Frame_Age(uint16 Index, uint8 *CA_Frame_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Height(uint16 Index, uint16 *CA_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Height_STD(uint16 Index, uint16 *CA_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_ID(uint16 Index, uint8 *CA_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance(uint16 Index, uint16 *CA_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Lat_Distance_STD(uint16 Index, uint16 *CA_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance(uint16 Index, uint16 *CA_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Long_Distance_STD(uint16 Index, uint16 *CA_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Measurement_Status(uint16 Index, uint8 *CA_Measurement_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Object_Height(uint16 Index, uint16 *CA_Object_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Object_Height_STD(uint16 Index, uint16 *CA_Object_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Object_Type(uint16 Index, uint8 *CA_Object_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Object_Width(uint16 Index, uint16 *CA_Object_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Object_Width_STD(uint16 Index, uint16 *CA_Object_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Objects_Count(uint8 *CA_Objects_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Protocol_Version(uint8 *CA_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Sync_ID(uint8 *CA_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_CA_Type_Confidence(uint16 Index, uint8 *CA_Type_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_2(uint16 Index, uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CONAR_EYEQDG_Get_CONAR_Reserved_7(uint16 Index, uint32 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CONAR_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_FCFVDDYN_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C0(uint8 *FCF_VD_DYN_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C1(uint8 *FCF_VD_DYN_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C2(uint8 *FCF_VD_DYN_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_DYN_Buffer_C3(uint16 Index, uint8 *FCF_VD_DYN_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp(uint16 Index, uint16 *FCF_VD_Dyn_AEB_Supp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_AEB_Supp_FCV(uint16 *FCF_VD_Dyn_AEB_Supp_FCV)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Alert(uint16 Index, uint16 *FCF_VD_Dyn_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_CRC(uint16 Index, uint32 *FCF_VD_Dyn_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Count(uint8 *FCF_VD_Dyn_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Element_Buffer(uint16 Index, uint16 *FCF_VD_Dyn_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_FCW_Supp(uint16 Index, uint32 *FCF_VD_Dyn_FCW_Supp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HW_Supp_Reason(uint16 *FCF_VD_Dyn_HW_Supp_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Alert(uint8 *FCF_VD_Dyn_HeadWay_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_HeadWay_Distance(uint16 *FCF_VD_Dyn_HeadWay_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_Buffer(uint8 *FCF_VD_Dyn_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Header_CRC(uint32 *FCF_VD_Dyn_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID(uint16 Index, uint8 *FCF_VD_Dyn_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_ID_FCV(uint8 *FCF_VD_Dyn_ID_FCV)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Protocol_Version(uint8 *FCF_VD_Dyn_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SET_ID(uint16 Index, uint8 *FCF_VD_Dyn_SET_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Safety_Suppressed(uint16 Index, uint8 *FCF_VD_Dyn_Safety_Suppressed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_Set_Type(uint16 Index, uint8 *FCF_VD_Dyn_Set_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_SyncID(uint8 *FCF_VD_Dyn_SyncID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC(uint16 Index, uint16 *FCF_VD_Dyn_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_FCF_VD_Dyn_TTC_Thresh(uint16 Index, uint16 *FCF_VD_Dyn_TTC_Thresh)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_2(uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_3(uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_4(uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVDDYN_EYEQDG_Get_FCFVDDYN_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVDDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_FCFVRUDYN_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Header_CRC(uint32 *FCF_VRU_DYN_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_Protocol_Version(uint8 *FCF_VRU_DYN_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_DYN_SyncID(uint8 *FCF_VRU_DYN_SyncID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Alert(uint16 Index, uint16 *FCF_VRU_Dyn_Alert)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C0(uint8 *FCF_VRU_Dyn_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Buffer_C1(uint16 Index, uint8 *FCF_VRU_Dyn_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_CRC(uint16 Index, uint32 *FCF_VRU_Dyn_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Count(uint8 *FCF_VRU_Dyn_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Curr_In_Path(uint16 Index, uint8 *FCF_VRU_Dyn_Curr_In_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Element_Buffer(uint16 Index, uint32 *FCF_VRU_Dyn_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Header_Buffer(uint32 *FCF_VRU_Dyn_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Level_ID(uint16 Index, uint8 *FCF_VRU_Dyn_Level_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_PED_ID(uint16 Index, uint8 *FCF_VRU_Dyn_PED_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Pred_In_Path(uint16 Index, uint8 *FCF_VRU_Dyn_Pred_In_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Safety_Suppressed(uint16 Index, uint8 *FCF_VRU_Dyn_Safety_Suppressed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Set_Type(uint16 Index, uint8 *FCF_VRU_Dyn_Set_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_Suppress(uint16 Index, uint8 *FCF_VRU_Dyn_Suppress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC(uint16 Index, uint16 *FCF_VRU_Dyn_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_FCF_VRU_Dyn_TTC_Thresh(uint16 Index, uint16 *FCF_VRU_Dyn_TTC_Thresh)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FCFVRUDYN_EYEQDG_Get_FCFVRUDYN_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FCFVRUDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Bicycle_Probability(uint16 Index, uint8 *OBJ_2W_Is_Bicycle_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_2W_Is_Motorbike_Probability(uint16 Index, uint8 *OBJ_2W_Is_Motorbike_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration(uint16 Index, uint16 *OBJ_Abs_Acceleration)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Acceleration_V(uint16 Index, uint8 *OBJ_Abs_Acceleration_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc(uint16 Index, uint16 *OBJ_Abs_Lat_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Lat_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Lat_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Acc_V(uint16 Index, uint8 *OBJ_Abs_Lat_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Vel_STD_V(uint16 Index, uint8 *OBJ_Abs_Lat_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity(uint16 Index, uint16 *OBJ_Abs_Lat_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_STD(uint16 Index, uint16 *OBJ_Abs_Lat_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Lat_Velocity_V(uint16 Index, uint8 *OBJ_Abs_Lat_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc(uint16 Index, uint16 *OBJ_Abs_Long_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD(uint16 Index, uint16 *OBJ_Abs_Long_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_STD_V(uint16 Index, uint8 *OBJ_Abs_Long_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Acc_V(uint16 Index, uint8 *OBJ_Abs_Long_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Vel_STD_V(uint16 Index, uint8 *OBJ_Abs_Long_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity(uint16 Index, uint16 *OBJ_Abs_Long_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_STD(uint16 Index, uint16 *OBJ_Abs_Long_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Abs_Long_Velocity_V(uint16 Index, uint8 *OBJ_Abs_Long_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed(uint16 Index, uint16 *OBJ_Absolute_Speed)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD(uint16 Index, uint16 *OBJ_Absolute_Speed_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_STD_V(uint16 Index, uint8 *OBJ_Absolute_Speed_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Absolute_Speed_V(uint16 Index, uint8 *OBJ_Absolute_Speed_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds(uint16 Index, uint8 *OBJ_Age_Seconds)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Age_Seconds_V(uint16 Index, uint8 *OBJ_Age_Seconds_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom(uint16 Index, uint16 *OBJ_Angle_Bottom)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD(uint16 Index, uint16 *OBJ_Angle_Bottom_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_STD_V(uint16 Index, uint8 *OBJ_Angle_Bottom_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Bottom_V(uint16 Index, uint8 *OBJ_Angle_Bottom_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left(uint16 Index, uint16 *OBJ_Angle_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD(uint16 Index, uint16 *OBJ_Angle_Left_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_STD_V(uint16 Index, uint8 *OBJ_Angle_Left_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Left_V(uint16 Index, uint8 *OBJ_Angle_Left_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid(uint16 Index, uint16 *OBJ_Angle_Mid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD(uint16 Index, uint16 *OBJ_Angle_Mid_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_STD_V(uint16 Index, uint8 *OBJ_Angle_Mid_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Mid_V(uint16 Index, uint8 *OBJ_Angle_Mid_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate(uint16 Index, uint16 *OBJ_Angle_Rate)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD(uint16 Index, uint16 *OBJ_Angle_Rate_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_STD_V(uint16 Index, uint8 *OBJ_Angle_Rate_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Rate_V(uint16 Index, uint8 *OBJ_Angle_Rate_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right(uint16 Index, uint16 *OBJ_Angle_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD(uint16 Index, uint16 *OBJ_Angle_Right_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_STD_V(uint16 Index, uint8 *OBJ_Angle_Right_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Right_V(uint16 Index, uint8 *OBJ_Angle_Right_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side(uint16 Index, uint16 *OBJ_Angle_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD(uint16 Index, uint16 *OBJ_Angle_Side_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_STD_V(uint16 Index, uint8 *OBJ_Angle_Side_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Angle_Side_V(uint16 Index, uint8 *OBJ_Angle_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Animal_Count(uint8 *OBJ_Animal_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image(uint16 Index, uint8 *OBJ_Bottom_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Bottom_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Bottom_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light(uint16 Index, uint8 *OBJ_Brake_Light)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Brake_Light_Validity(uint16 Index, uint8 *OBJ_Brake_Light_Validity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C0(uint16 Index, uint8 *OBJ_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C1(uint16 Index, uint8 *OBJ_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C10(uint16 Index, uint16 *OBJ_Buffer_C10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C11(uint16 Index, uint8 *OBJ_Buffer_C11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C12(uint16 Index, uint16 *OBJ_Buffer_C12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C13(uint16 Index, uint8 *OBJ_Buffer_C13)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C16(uint8 *OBJ_Buffer_C16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C17(uint8 *OBJ_Buffer_C17)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C2(uint16 Index, uint8 *OBJ_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C20(uint16 Index, uint8 *OBJ_Buffer_C20)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C21(uint16 Index, uint8 *OBJ_Buffer_C21)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C3(uint16 Index, uint8 *OBJ_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C4(uint16 Index, uint8 *OBJ_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C5(uint16 Index, uint8 *OBJ_Buffer_C5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C6(uint16 Index, uint8 *OBJ_Buffer_C6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C7(uint16 Index, uint8 *OBJ_Buffer_C7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C8(uint16 Index, uint16 *OBJ_Buffer_C8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Buffer_C9(uint16 Index, uint16 *OBJ_Buffer_C9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_CRC(uint16 Index, uint32 *OBJ_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Camera_Source(uint16 Index, uint8 *OBJ_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Class_Probability(uint16 Index, uint8 *OBJ_Class_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_LIGHT_COLOR(uint16 Index, uint8 *OBJ_EMERGENCY_LIGHT_COLOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_EMERGENCY_V(uint16 Index, uint8 *OBJ_EMERGENCY_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Existence_Probability(uint16 Index, uint8 *OBJ_Existence_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Fusion_Source(uint16 Index, uint16 *OBJ_Fusion_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_General_OBJ_Count(uint8 *OBJ_General_OBJ_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Lane(uint16 Index, uint8 *OBJ_Has_Cut_Lane)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Has_Cut_Path(uint16 Index, uint8 *OBJ_Has_Cut_Path)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Header_CRC(uint32 *OBJ_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Heading(uint16 Index, uint16 *OBJ_Heading)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD(uint16 Index, uint16 *OBJ_Heading_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_STD_V(uint16 Index, uint8 *OBJ_Heading_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Heading_V(uint16 Index, uint8 *OBJ_Heading_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Height(uint16 Index, uint16 *OBJ_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD(uint16 Index, uint16 *OBJ_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Height_STD_V(uint16 Index, uint8 *OBJ_Height_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Height_V(uint16 Index, uint8 *OBJ_Height_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_ID(uint16 Index, uint8 *OBJ_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC(uint16 Index, uint16 *OBJ_Inv_TTC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD(uint16 Index, uint16 *OBJ_Inv_TTC_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_STD_V(uint16 Index, uint8 *OBJ_Inv_TTC_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Inv_TTC_V(uint16 Index, uint8 *OBJ_Inv_TTC_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Left(uint8 *OBJ_Is_Blocked_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_Blocked_Right(uint8 *OBJ_Is_Blocked_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_EMERGENCY_VCL(uint16 Index, uint8 *OBJ_Is_EMERGENCY_VCL)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area(uint16 Index, uint8 *OBJ_Is_In_Drivable_Area)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_In_Drivable_Area_V(uint16 Index, uint8 *OBJ_Is_In_Drivable_Area_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose(uint16 Index, uint8 *OBJ_Is_VeryClose)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Is_VeryClose_V(uint16 Index, uint8 *OBJ_Is_VeryClose_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment(uint16 Index, uint8 *OBJ_Lane_Assignment)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lane_Assignment_V(uint16 Index, uint8 *OBJ_Lane_Assignment_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance(uint16 Index, uint16 *OBJ_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD(uint16 Index, uint16 *OBJ_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_STD_V(uint16 Index, uint8 *OBJ_Lat_Distance_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Lat_Distance_V(uint16 Index, uint8 *OBJ_Lat_Distance_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image(uint16 Index, uint8 *OBJ_Left_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Left_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Left_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Length(uint16 Index, uint16 *OBJ_Length)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD(uint16 Index, uint16 *OBJ_Length_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Length_STD_V(uint16 Index, uint8 *OBJ_Length_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Length_V(uint16 Index, uint8 *OBJ_Length_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance(uint16 Index, uint16 *OBJ_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD(uint16 Index, uint16 *OBJ_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_STD_V(uint16 Index, uint8 *OBJ_Long_Distance_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Long_Distance_V(uint16 Index, uint8 *OBJ_Long_Distance_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Measuring_Status(uint16 Index, uint8 *OBJ_Measuring_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Category(uint16 Index, uint8 *OBJ_Motion_Category)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Orientation(uint16 Index, uint8 *OBJ_Motion_Orientation)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Motion_Status(uint16 Index, uint8 *OBJ_Motion_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Age(uint16 Index, uint16 *OBJ_Object_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Object_Class(uint16 Index, uint8 *OBJ_Object_Class)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Left(uint16 Index, uint8 *OBJ_Open_Door_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Open_Door_Right(uint16 Index, uint8 *OBJ_Open_Door_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Protocol_Version(uint8 *OBJ_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Radar_ID(uint16 Index, uint8 *OBJ_Radar_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Lat_Vel_STD_V(uint16 Index, uint8 *OBJ_Rel_Lat_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Acc_STD_V(uint16 Index, uint8 *OBJ_Rel_Long_Acc_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Rel_Long_Vel_STD_V(uint16 Index, uint8 *OBJ_Rel_Long_Vel_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity(uint16 Index, uint16 *OBJ_Relative_Lat_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_STD(uint16 Index, uint16 *OBJ_Relative_Lat_Velocity_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Lat_Velocity_V(uint16 Index, uint8 *OBJ_Relative_Lat_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc(uint16 Index, uint16 *OBJ_Relative_Long_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_STD(uint16 Index, uint16 *OBJ_Relative_Long_Acc_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Acc_V(uint16 Index, uint8 *OBJ_Relative_Long_Acc_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Vel_STD(uint16 Index, uint16 *OBJ_Relative_Long_Vel_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity(uint16 Index, uint16 *OBJ_Relative_Long_Velocity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Relative_Long_Velocity_V(uint16 Index, uint8 *OBJ_Relative_Long_Velocity_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image(uint16 Index, uint8 *OBJ_Right_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Right_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Right_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Sync_ID(uint8 *OBJ_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image(uint16 Index, uint8 *OBJ_Top_Out_Of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Top_Out_Of_Image_V(uint16 Index, uint8 *OBJ_Top_Out_Of_Image_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Triggered_SDM(uint16 Index, uint8 *OBJ_Triggered_SDM)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Left(uint16 Index, uint8 *OBJ_Turn_Indicator_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Right(uint16 Index, uint8 *OBJ_Turn_Indicator_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Turn_Indicator_Validity(uint16 Index, uint8 *OBJ_Turn_Indicator_Validity)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Allow_Acc(uint8 *OBJ_VD_Allow_Acc)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_ID(uint8 *OBJ_VD_CIPV_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_CIPV_Lost(uint8 *OBJ_VD_CIPV_Lost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_Count(uint8 *OBJ_VD_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Left(uint8 *OBJ_VD_NIV_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VD_NIV_Right(uint8 *OBJ_VD_NIV_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_VRU_Count(uint8 *OBJ_VRU_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side(uint16 Index, uint8 *OBJ_Visibility_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Visibility_Side_V(uint16 Index, uint8 *OBJ_Visibility_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right(uint16 Index, uint8 *OBJ_Visible_Left_or_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Visible_Left_or_Right_V(uint16 Index, uint8 *OBJ_Visible_Left_or_Right_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Width(uint16 Index, uint16 *OBJ_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD(uint16 Index, uint16 *OBJ_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Width_STD_V(uint16 Index, uint8 *OBJ_Width_STD_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_OBJ_Width_V(uint16 Index, uint8 *OBJ_Width_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Obj_partially_in_lane(uint16 Index, uint8 *Obj_partially_in_lane)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_1(uint32 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_10(uint16 Index, uint8 *Reserved_10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_11(uint16 Index, uint8 *Reserved_11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_12(uint16 Index, uint8 *Reserved_12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_13(uint16 Index, uint16 *Reserved_13)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_14(uint16 Index, uint8 *Reserved_14)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_15(uint16 Index, uint8 *Reserved_15)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_16(uint16 Index, uint8 *Reserved_16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_17(uint16 Index, uint8 *Reserved_17)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_18(uint16 Index, uint8 *Reserved_18)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_19(uint16 Index, uint8 *Reserved_19)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_2(uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_20(uint16 Index, uint8 *Reserved_20)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_21(uint16 Index, uint8 *Reserved_21)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_22(uint16 Index, uint8 *Reserved_22)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_23(uint16 Index, uint8 *Reserved_23)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_24(uint16 Index, uint8 *Reserved_24)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_25(uint16 Index, uint16 *Reserved_25)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_26(uint16 Index, uint8 *Reserved_26)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_27(uint16 Index, uint32 *Reserved_27)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_3(uint32 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_8(uint16 Index, uint16 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_Get_OBJT_Reserved_9(uint16 Index, uint8 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_OBJT_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_OBJT_EYEQDG_OBJT_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_Main_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApObjt_Core1_CODE) Re_CpApObjt_Core1_Main(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApObjt_Core1_Main
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApObjt_Core1_STOP_SEC_CODE
#include "CpApObjt_Core1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApObjt_Core1_20ms_doc)  **************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApObjt_Core1_20ms)  *************************/


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
