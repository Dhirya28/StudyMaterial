/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApVCan.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApVCan
 *  Generation Time:  2023-04-20 13:53:25
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApVCan>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * COM_DT_DATC_OutTempDispC
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * COM_DT_DATC_OutTempDispF
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApVCan.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * ABS_DiagSta: Integer in interval [0...255]
 * ABS_ESC_AlvCnt1Val: Integer in interval [0...255]
 * ABS_ESC_Crc1Val: Integer in interval [0...65535]
 * ADAS_CMD_AlvCnt10Val_1: Integer in interval [0...255]
 * ADAS_CMD_AlvCnt20Val: Integer in interval [0...255]
 * ADAS_CMD_Crc10Val_1: Integer in interval [0...65535]
 * ADAS_CMD_Crc20Val: Integer in interval [0...65535]
 * ADAS_HzrdLmpReqVal: Integer in interval [0...255]
 * BRK_AutoDrvBrkSta: Integer in interval [0...255]
 * COM_DT_AAF_WrnLamp: Boolean
 * COM_DT_ACC_CrsMainSwLmpSta: Integer in interval [0...255]
 * COM_DT_ACC_CrsSetSwLmpSta: Integer in interval [0...255]
 * COM_DT_ACC_DnShftCtrlReq: Integer in interval [0...255]
 * COM_DT_ADAS_ACIAnglTqRedcGainVal: Integer in interval [0...255]
 * COM_DT_ADAS_ActvACILvl2Sta: Integer in interval [0...255]
 * COM_DT_ADAS_ActvACISta: Integer in interval [0...255]
 * COM_DT_ADAS_CMD_AlvCnt21Val: Integer in interval [0...255]
 * COM_DT_ADAS_CMD_AlvCnt30Val: Integer in interval [0...255]
 * COM_DT_ADAS_CMD_AlvCnt31Val: Integer in interval [0...255]
 * COM_DT_ADAS_CMD_AlvCnt35Val: Integer in interval [0...255]
 * COM_DT_ADAS_CMD_Crc21Val: Integer in interval [0...65535]
 * COM_DT_ADAS_CMD_Crc30Val: Integer in interval [0...65535]
 * COM_DT_ADAS_CMD_Crc31Val: Integer in interval [0...65535]
 * COM_DT_ADAS_CMD_Crc35Val: Integer in interval [0...65535]
 * COM_DT_ADAS_DRV_UpDateInfo: Boolean
 * COM_DT_ADAS_Damping_Gain: Integer in interval [0...255]
 * COM_DT_ADAS_INFO_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_ADAS_INFO_Crc1Val: Integer in interval [0...65535]
 * COM_DT_ADAS_PRK_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_ADAS_PRK_Crc3Val: Integer in interval [0...65535]
 * COM_DT_ADAS_StrAnglReqVal: Integer in interval [-32768...32767]
 * COM_DT_ADAS_StrTqReqVal: Integer in interval [0...65535]
 * COM_DT_ADAS_UX_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_ADAS_UX_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_ADAS_UX_Crc1Val: Integer in interval [0...65535]
 * COM_DT_ADAS_UX_Crc2Val: Integer in interval [0...65535]
 * COM_DT_AVH_AlrmReq: Integer in interval [0...255]
 * COM_DT_AVH_CluDis: Integer in interval [0...255]
 * COM_DT_AVH_Sta: Integer in interval [0...255]
 * COM_DT_AVN_RSPA_ModeSelect_1: Integer in interval [0...255]
 * COM_DT_AWD_CltchDtyLimVal: Integer in interval [0...255]
 * COM_DT_BCM_AlvCnt10Val: Integer in interval [0...255]
 * COM_DT_BCM_AlvCnt7Val: Integer in interval [0...255]
 * COM_DT_BCM_AlvCnt8Val: Integer in interval [0...255]
 * COM_DT_BCM_Crc10Val: Integer in interval [0...255]
 * COM_DT_BCM_Crc7Val: Integer in interval [0...255]
 * COM_DT_BCM_Crc8Val: Integer in interval [0...255]
 * COM_DT_BCM_SolSnsrLft: Integer in interval [0...255]
 * COM_DT_BCM_SolSnsrRt: Integer in interval [0...255]
 * COM_DT_BG_HDP_Sta: Integer in interval [0...255]
 * COM_DT_BJD_Flag: Boolean
 * COM_DT_CF_AVN_ProfileIDRValue_1: Integer in interval [0...255]
 * COM_DT_CF_EMS_CltCtrlReq: Integer in interval [0...255]
 * COM_DT_CF_EMS_KEYST: Boolean
 * COM_DT_CF_EMS_NEURALSW: Boolean
 * COM_DT_CLU_AdasWarnSndStat: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt12Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt13Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt14Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt25Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_CLU_AlvCnt4Val: Integer in interval [0...255]
 * COM_DT_CLU_AutoBrightSta: Integer in interval [0...255]
 * COM_DT_CLU_CUSTOMSta_NEW: Integer in interval [0...255]
 * COM_DT_CLU_Crc12Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc13Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc14Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc1Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc25Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc2Val: Integer in interval [0...65535]
 * COM_DT_CLU_Crc4Val: Integer in interval [0...65535]
 * COM_DT_CLU_DTEVal: Integer in interval [0...65535]
 * COM_DT_CLU_DisSpdDcmlVal: Integer in interval [0...255]
 * COM_DT_CLU_DisSpdVal: Integer in interval [0...65535]
 * COM_DT_CLU_DrvngModSwSta: Integer in interval [0...255]
 * COM_DT_CLU_FuelLvlSta: Integer in interval [0...255]
 * COM_DT_CLU_LngSta: Integer in interval [0...255]
 * COM_DT_CLU_OdoVal: Integer in interval [0...4294967295]
 * COM_DT_CLU_OdoVal_1: Integer in interval [0...4294967295]
 * COM_DT_CLU_SWRCCrsSwSta: Integer in interval [0...255]
 * COM_DT_CLU_SpdUnitTyp: Integer in interval [0...255]
 * COM_DT_CLU_TerrainModSwSta: Integer in interval [0...255]
 * COM_DT_DATC_OutTempDispC: Integer in interval [0...255]
 * COM_DT_DATC_OutTempDispF: Integer in interval [0...255]
 * COM_DT_DAW_LVDA_PUDis: Integer in interval [0...255]
 * COM_DT_DAW_SysSta: Integer in interval [0...255]
 * COM_DT_DAW_WrnMsgSta: Integer in interval [0...255]
 * COM_DT_DBC_Sta: Integer in interval [0...255]
 * COM_DT_DCT_BrkSwSta: Integer in interval [0...255]
 * COM_DT_DCT_CrpTqReq: Integer in interval [0...65535]
 * COM_DT_DCT_EngOpSta: Integer in interval [0...255]
 * COM_DT_DCT_MotCrctTqVal: Integer in interval [-32768...32767]
 * COM_DT_DCT_MotIndTqBVal: Integer in interval [-32768...32767]
 * COM_DT_DCT_MotIndTqVal: Integer in interval [-32768...32767]
 * COM_DT_DCT_MotSpdVal: Integer in interval [0...65535]
 * COM_DT_DMIC_AwdModSta: Integer in interval [0...255]
 * COM_DT_DMIC_DrvModFltSta: Integer in interval [0...255]
 * COM_DT_DMIC_DrvModSta: Integer in interval [0...255]
 * COM_DT_DMIC_EcsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_ElsdModSta: Integer in interval [0...255]
 * COM_DT_DMIC_EngModSta: Integer in interval [0...255]
 * COM_DT_DMIC_EscModSta: Integer in interval [0...255]
 * COM_DT_DMIC_EsndModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndAwdModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndEcsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndElsdModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndEngModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndEscModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndEsndModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndMaxVehSpdSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndMdpsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndPrflModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndRevModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndRwsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndTmModSta: Integer in interval [0...255]
 * COM_DT_DMIC_IndVcuModSta: Integer in interval [0...255]
 * COM_DT_DMIC_MdpsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_PrflModSta: Integer in interval [0...255]
 * COM_DT_DMIC_RevModSta: Integer in interval [0...255]
 * COM_DT_DMIC_RwsModSta: Integer in interval [0...255]
 * COM_DT_DMIC_TmModSta: Integer in interval [0...255]
 * COM_DT_DMIC_VcuModSta: Integer in interval [0...255]
 * COM_DT_ELK_SymbDisp: Integer in interval [0...255]
 * COM_DT_ELK_SysFlrSta: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt11Val: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt5Val_2: Integer in interval [0...255]
 * COM_DT_EMS_AlvCnt7Val: Integer in interval [0...255]
 * COM_DT_EMS_BrkReq_Slope: Boolean
 * COM_DT_EMS_Crc11Val: Integer in interval [0...65535]
 * COM_DT_EMS_Crc1Val: Integer in interval [0...65535]
 * COM_DT_EMS_Crc2Val: Integer in interval [0...65535]
 * COM_DT_EMS_Crc3Val: Integer in interval [0...65535]
 * COM_DT_EMS_Crc5Val_2: Integer in interval [0...65535]
 * COM_DT_EMS_Crc7Val: Integer in interval [0...65535]
 * COM_DT_EMS_EngStallDis: Boolean
 * COM_DT_EMS_PendingTrigSta: Boolean
 * COM_DT_EMS_RECTrigDta: Boolean
 * COM_DT_ENG_AccActSta: Integer in interval [0...255]
 * COM_DT_ENG_AccelPdlVal: Integer in interval [0...65535]
 * COM_DT_ENG_Ack4TcsSta: Integer in interval [0...255]
 * COM_DT_ENG_AirCompRlySta: Integer in interval [0...255]
 * COM_DT_ENG_AirconPrsrSnsrVal: Integer in interval [0...255]
 * COM_DT_ENG_AltFdbckLoadVal_1: Integer in interval [0...255]
 * COM_DT_ENG_AmbtTempModelVal: Integer in interval [0...255]
 * COM_DT_ENG_AppAccelPdlSta: Integer in interval [0...255]
 * COM_DT_ENG_AtmsphPrsrVal_1: Integer in interval [0...255]
 * COM_DT_ENG_BattDscnctSta: Integer in interval [0...255]
 * COM_DT_ENG_BattVoltVal_1: Integer in interval [0...255]
 * COM_DT_ENG_BrkCtrlReq: Integer in interval [0...255]
 * COM_DT_ENG_BrkSwSta: Integer in interval [0...255]
 * COM_DT_ENG_BstPrsrVal: Integer in interval [0...65535]
 * COM_DT_ENG_CrctEngTqVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_CrctTqSta: Integer in interval [0...255]
 * COM_DT_ENG_DclBrkCntrlReq: Integer in interval [0...65535]
 * COM_DT_ENG_DpfRgnSta: Boolean
 * COM_DT_ENG_EngClntTempVal: Integer in interval [0...255]
 * COM_DT_ENG_EngDsplceTyp_1: Integer in interval [0...255]
 * COM_DT_ENG_EngOilTempVal: Integer in interval [0...255]
 * COM_DT_ENG_EngSpdVal: Integer in interval [0...65535]
 * COM_DT_ENG_ExtSoakTimeVal_1: Integer in interval [0...255]
 * COM_DT_ENG_FrctTqVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_FuelCnsmptVal: Integer in interval [0...65535]
 * COM_DT_ENG_FuelTempVal_1: Integer in interval [0...255]
 * COM_DT_ENG_FuelTnkPrsrSta: Integer in interval [0...255]
 * COM_DT_ENG_GearPos: Integer in interval [0...65535]
 * COM_DT_ENG_IgnOnSta: Integer in interval [0...255]
 * COM_DT_ENG_IndTqBVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_IndTqVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_Isg2Sta: Integer in interval [0...255]
 * COM_DT_ENG_IsgDispDetail_1: Integer in interval [0...255]
 * COM_DT_ENG_IsgSta: Integer in interval [0...255]
 * COM_DT_ENG_KNK_Warning: Boolean
 * COM_DT_ENG_LV_FUP_ENA_THD: Boolean
 * COM_DT_ENG_MafCrctVal: Integer in interval [0...255]
 * COM_DT_ENG_MaxAirconTqVal: Integer in interval [0...255]
 * COM_DT_ENG_MaxIndTqVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_MinIndTqVal: Integer in interval [-32768...32767]
 * COM_DT_ENG_MotRecupSta: Boolean
 * COM_DT_ENG_ObdFrzFrmSta: Integer in interval [0...255]
 * COM_DT_ENG_OilLifeRatio_1: Integer in interval [0...255]
 * COM_DT_ENG_OilLifeWarn_1: Integer in interval [0...255]
 * COM_DT_ENG_OverDrvOffReq: Integer in interval [0...255]
 * COM_DT_ENG_SldFuncSta: Integer in interval [0...255]
 * COM_DT_ENG_SldSwSta: Integer in interval [0...255]
 * COM_DT_ENG_SoakTimeVal: Integer in interval [0...255]
 * COM_DT_ENG_SprkTimeVal: Integer in interval [0...255]
 * COM_DT_ENG_StndTqRatioVal: Integer in interval [0...255]
 * COM_DT_ENG_SysWarnLmpReq: Boolean
 * COM_DT_ENG_ThrPosVal: Integer in interval [0...255]
 * COM_DT_ENG_TqStndValExt_1: Integer in interval [0...255]
 * COM_DT_ENG_TrgtFuelPmpPrsrVal: Integer in interval [0...255]
 * COM_DT_ENG_TrgtIdleRpmVal: Integer in interval [0...255]
 * COM_DT_ENG_TrgtTqVal: Integer in interval [-32768...32767]
 * COM_DT_EPB_ActlFrcVal: Integer in interval [0...65535]
 * COM_DT_EPB_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_EPB_Crc1Val: Integer in interval [0...65535]
 * COM_DT_EPB_DynmBrkFrcDclReq: Integer in interval [0...255]
 * COM_DT_EPB_DynmBrkFrcReqSigSta: Integer in interval [0...255]
 * COM_DT_EPB_EpbSta4VcuReq: Integer in interval [0...255]
 * COM_DT_EPB_EscReqAckSta: Integer in interval [0...255]
 * COM_DT_EPB_FlrLmpStaDis: Integer in interval [0...255]
 * COM_DT_EPB_FrcErrSta: Integer in interval [0...255]
 * COM_DT_EPB_LmpStaDis: Integer in interval [0...255]
 * COM_DT_EPB_OutDataDis: Integer in interval [0...255]
 * COM_DT_EPB_RrBrkLtActvReq: Integer in interval [0...255]
 * COM_DT_ESC_AccelBasisVal: Integer in interval [0...65535]
 * COM_DT_ESC_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_ESC_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_ESC_BrkCtrlSta: Integer in interval [0...255]
 * COM_DT_ESC_Crc1Val: Integer in interval [0...65535]
 * COM_DT_ESC_Crc3Val: Integer in interval [0...65535]
 * COM_DT_ESC_CylPrsrDiagSta: Integer in interval [0...255]
 * COM_DT_ESC_CylPrsrSta: Integer in interval [0...255]
 * COM_DT_ESC_CylPrsrVal: Integer in interval [0...65535]
 * COM_DT_ESC_DiffBrkFuncSta: Integer in interval [0...255]
 * COM_DT_ESC_DrvBrkSta: Integer in interval [0...255]
 * COM_DT_ESC_HDP_EgSta: Integer in interval [0...255]
 * COM_DT_ESC_HDP_EnblReq: Integer in interval [0...255]
 * COM_DT_ESC_HDP_FltMonSta: Integer in interval [0...255]
 * COM_DT_ESC_IMURstStaAck_1: Boolean
 * COM_DT_ESC_LongAccelOffstCalibPrmtr: Integer in interval [0...65535]
 * COM_DT_ESC_LsdLimMod: Boolean
 * COM_DT_ESC_LsdTqLim: Integer in interval [0...65535]
 * COM_DT_ESC_OffSwSta: Integer in interval [0...255]
 * COM_DT_ESC_RspaCanFlFlag: Integer in interval [0...255]
 * COM_DT_ESC_RspaStandStill: Integer in interval [0...255]
 * COM_DT_ESC_Sta: Integer in interval [0...255]
 * COM_DT_ESC_StrTqReq: Integer in interval [0...65535]
 * COM_DT_ESC_VehAccelVal: Integer in interval [0...65535]
 * COM_DT_ESC_VsmCtrlModSta: Integer in interval [0...255]
 * COM_DT_Eng_OverRun: Boolean
 * COM_DT_FCA_ESA_CtrlSta: Integer in interval [0...255]
 * COM_DT_FCA_ESA_TqBstGainVal: Integer in interval [0...255]
 * COM_DT_FCA_ESA_WrnSta: Integer in interval [0...255]
 * COM_DT_FCA_LO_WrnSta: Integer in interval [0...255]
 * COM_DT_FCA_LS_WrnSta: Integer in interval [0...255]
 * COM_DT_FR_CMR_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_FR_CMR_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_FR_CMR_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_FR_CMR_AlvCnt4Val_1: Integer in interval [0...255]
 * COM_DT_FR_CMR_Crc1Val: Integer in interval [0...65535]
 * COM_DT_FR_CMR_Crc2Val: Integer in interval [0...65535]
 * COM_DT_FR_CMR_Crc3Val: Integer in interval [0...65535]
 * COM_DT_FR_CMR_Crc4Val_1: Integer in interval [0...65535]
 * COM_DT_FR_CMR_FCA_Plus_Sta: Integer in interval [0...255]
 * COM_DT_FR_CMR_FailInfoSta: Integer in interval [0...255]
 * COM_DT_FR_CMR_ReqADASMapMsgVal: Integer in interval [0...65535]
 * COM_DT_FR_CMR_SwVer1Val: Integer in interval [0...255]
 * COM_DT_FR_CMR_SwVer2Val: Integer in interval [0...255]
 * COM_DT_HAC_Sta: Integer in interval [0...255]
 * COM_DT_HBA_SysSta: Integer in interval [0...255]
 * COM_DT_HCU_AcnCompPrmsnPwrVal: Integer in interval [0...65535]
 * COM_DT_HCU_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_HCU_AlvCnt5Val: Integer in interval [0...255]
 * COM_DT_HCU_CcCameraSta: Integer in interval [0...255]
 * COM_DT_HCU_Crc3Val: Integer in interval [0...65535]
 * COM_DT_HCU_Crc5Val: Integer in interval [0...65535]
 * COM_DT_HCU_DptEnaSet2SunSta: Integer in interval [0...255]
 * COM_DT_HCU_DptHrSet1Val: Integer in interval [0...255]
 * COM_DT_HCU_DptHrSet2Val: Integer in interval [0...255]
 * COM_DT_HCU_DptMinSet1Val: Integer in interval [0...255]
 * COM_DT_HCU_DptMinSet2Val: Integer in interval [0...255]
 * COM_DT_HCU_DrvWhlDmndTqNmVal: Integer in interval [-32768...32767]
 * COM_DT_HCU_DucVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgEndHrVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgEndHrWeekendVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgEndMinVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgEndMinWeekendVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgStrtHrVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgStrtHrWeekendVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgStrtMinVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoChrgStrtMinWeekendVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoLvlVal: Integer in interval [0...255]
 * COM_DT_HCU_EcoScoVal: Integer in interval [0...255]
 * COM_DT_HCU_EstAccelPdlPcVal: Integer in interval [0...255]
 * COM_DT_HCU_FuelEcoVal: Integer in interval [0...255]
 * COM_DT_HCU_GearRInhbtSta: Integer in interval [0...255]
 * COM_DT_HCU_LdcCtrlModSta: Integer in interval [0...255]
 * COM_DT_HCU_PaddleCoastCtrlSta: Integer in interval [0...255]
 * COM_DT_HCU_PdlStopCtrlSta: Integer in interval [0...255]
 * COM_DT_HCU_PdlStopReqTqNmVal: Integer in interval [0...65535]
 * COM_DT_HCU_PhevMod: Integer in interval [0...255]
 * COM_DT_HCU_PreFATCOffstTempValHR: Integer in interval [0...255]
 * COM_DT_HCU_RspaCanFailSta: Integer in interval [0...255]
 * COM_DT_HCU_RspaSta: Integer in interval [0...255]
 * COM_DT_HCU_SchedChgEndHrVal: Integer in interval [0...255]
 * COM_DT_HCU_SchedChgEndMinVal: Integer in interval [0...255]
 * COM_DT_HCU_SchedChgStrtHrVal: Integer in interval [0...255]
 * COM_DT_HCU_SchedChgStrtMinVal: Integer in interval [0...255]
 * COM_DT_HCU_SldDrvAlrtDis: Integer in interval [0...255]
 * COM_DT_HCU_SmartRegen_LvlVal: Integer in interval [0...255]
 * COM_DT_HCU_SmartRegen_MapCstActSta: Integer in interval [0...255]
 * COM_DT_HCU_SmartRegen_RdrCstActSta: Integer in interval [0...255]
 * COM_DT_HCU_SmartRegen_WarnMsgSta: Integer in interval [0...255]
 * COM_DT_HCU_SmrtEcoLvlDis: Integer in interval [0...255]
 * COM_DT_HCU_SmrtEcoRngDis: Integer in interval [0...255]
 * COM_DT_HCU_SpdLimDeviceActSta: Integer in interval [0...255]
 * COM_DT_HCU_SpdLimDeviceVehSpdVal: Integer in interval [0...255]
 * COM_DT_HCU_SrvLmpTmpryOnSta: Integer in interval [0...255]
 * COM_DT_HCU_WhlCrpCrpTqNmVal: Integer in interval [-32768...32767]
 * COM_DT_HDA_InfoPUDis: Integer in interval [0...255]
 * COM_DT_HDA_InfoPUDis1: Integer in interval [0...255]
 * COM_DT_HDA_OptUsmSta: Integer in interval [0...255]
 * COM_DT_HDA_TDMRMDclReq: Integer in interval [0...255]
 * COM_DT_HDCT_AddtnlTqLssVal: Integer in interval [0...255]
 * COM_DT_HDCT_CLUEngSpd: Integer in interval [0...65535]
 * COM_DT_HDCT_CLUTrgtGear: Integer in interval [0...255]
 * COM_DT_HDCT_CurrGear: Integer in interval [0...255]
 * COM_DT_HDCT_FltSta: Integer in interval [0...255]
 * COM_DT_HDCT_GearSelDis: Integer in interval [0...255]
 * COM_DT_HDCT_KckDnSkpShftCnt: Integer in interval [0...255]
 * COM_DT_HDCT_OBDSta: Integer in interval [0...255]
 * COM_DT_HDCT_SlipCrnkAllw: Integer in interval [0...255]
 * COM_DT_HDCT_TqIncVal: Integer in interval [0...65535]
 * COM_DT_HDCT_TqRdctnVal: Integer in interval [0...65535]
 * COM_DT_HDCT_TrgtGear: Integer in interval [0...255]
 * COM_DT_HDP_ActvSta: Integer in interval [0...255]
 * COM_DT_HDP_AutoCallReqSta: Integer in interval [0...255]
 * COM_DT_HDP_CtRoadSrfcDistVal: Integer in interval [0...65535]
 * COM_DT_HDP_DispBarSta: Integer in interval [0...255]
 * COM_DT_HDP_InhbtOffDispSta: Integer in interval [0...255]
 * COM_DT_HDP_OptInfoSta: Integer in interval [0...255]
 * COM_DT_HDP_SysSta: Integer in interval [0...255]
 * COM_DT_HEV_AccelPdlVal: Integer in interval [0...65535]
 * COM_DT_HEV_DrvTqVal: Integer in interval [0...65535]
 * COM_DT_HEV_EngSpdVal: Integer in interval [0...65535]
 * COM_DT_HEV_EngTqAvail_FS: Boolean
 * COM_DT_HEV_EngTqVal: Integer in interval [0...65535]
 * COM_DT_HEV_EngTq_Bas: Integer in interval [0...255]
 * COM_DT_HEV_FrctTqVal: Integer in interval [0...65535]
 * COM_DT_HEV_FuelCnsmptVal: Integer in interval [0...65535]
 * COM_DT_HEV_FuelPmpTrgtPrsrVal: Integer in interval [0...255]
 * COM_DT_HEV_FuelTnkPrsrErrSta: Integer in interval [0...255]
 * COM_DT_HEV_FuelTnkPrsrVal: Integer in interval [0...65535]
 * COM_DT_HEV_FueledEngRdy: Boolean
 * COM_DT_HEV_IdlTgtEngSpd: Integer in interval [0...255]
 * COM_DT_HEV_IdleCtrStat_FS: Boolean
 * COM_DT_HEV_IndTqTar: Integer in interval [0...255]
 * COM_DT_HEV_IndTqVal: Integer in interval [0...65535]
 * COM_DT_HEV_IntakeAirTempVal: Integer in interval [0...255]
 * COM_DT_HEV_O2SensHtrAct: Boolean
 * COM_DT_HEV_ObdFrzFrmSta: Integer in interval [0...255]
 * COM_DT_HEV_RdyStat_FS_P: Boolean
 * COM_DT_HEV_ThrPosSta: Integer in interval [0...255]
 * COM_DT_HEV_TqStndVal: Integer in interval [0...255]
 * COM_DT_HPT_StbltWarn1Sta: Integer in interval [0...255]
 * COM_DT_HPT_StrWhlWarn1Sta: Integer in interval [0...255]
 * COM_DT_HTCU_AlvCnt4Val: Integer in interval [0...255]
 * COM_DT_HTCU_AlvCnt5Val: Integer in interval [0...255]
 * COM_DT_HTCU_Crc4Val: Integer in interval [0...65535]
 * COM_DT_HTCU_Crc5Val: Integer in interval [0...65535]
 * COM_DT_HTCU_CurrGearSta: Integer in interval [0...255]
 * COM_DT_HTCU_FltSta: Integer in interval [0...255]
 * COM_DT_HTCU_FsAddtnlTqLssPcVal: Integer in interval [0...255]
 * COM_DT_HTCU_FsEngTqRdctnPcVal: Integer in interval [0...255]
 * COM_DT_HTCU_FsIdleTrgtRpmVal: Integer in interval [0...255]
 * COM_DT_HTCU_GearSlctrDis: Integer in interval [0...255]
 * COM_DT_HTCU_HvOpuSpdCmdRpmVal: Integer in interval [0...255]
 * COM_DT_HTCU_LnPrsBarVal: Integer in interval [0...255]
 * COM_DT_HTCU_SlwTqRdctnPcVal: Integer in interval [0...65535]
 * COM_DT_HTCU_SlwTqRdctnVal: Integer in interval [0...65535]
 * COM_DT_HTCU_TqRdctnPcVal: Integer in interval [0...65535]
 * COM_DT_HTCU_TrgtGearSta: Integer in interval [0...255]
 * COM_DT_HTCU_TrgtShftClsCCanSta: Integer in interval [0...255]
 * COM_DT_HTCU_VehSpdDcmlKphVal: Integer in interval [0...255]
 * COM_DT_HTCU_VehSpdKphVal: Integer in interval [0...255]
 * COM_DT_HU_AMP_EQVariant_1: Integer in interval [0...255]
 * COM_DT_HU_AdasSupport: Integer in interval [0...255]
 * COM_DT_HU_AutoBrightState_New_1: Integer in interval [0...65535]
 * COM_DT_HU_BVM_Display_Message_1: Integer in interval [0...255]
 * COM_DT_HU_DistributeInfo_2: Integer in interval [0...255]
 * COM_DT_HU_LanguageInfo_1: Integer in interval [0...255]
 * COM_DT_HU_NaviCamSettingStatus_2: Integer in interval [0...255]
 * COM_DT_HU_Navi_RspADASMapMsg_2: Integer in interval [0...65535]
 * COM_DT_HU_SVM_View_Display_1: Integer in interval [0...255]
 * COM_DT_HU_Scheduled_Setting_1: Integer in interval [0...255]
 * COM_DT_HU_ThemeType_1: Integer in interval [0...255]
 * COM_DT_HU_Type_2: Integer in interval [0...255]
 * COM_DT_IAU_DISPWrng: Integer in interval [0...255]
 * COM_DT_IAU_DigitalKey2Opt: Integer in interval [0...255]
 * COM_DT_IAU_DigitalKeyExit: Integer in interval [0...255]
 * COM_DT_IAU_DigitalKeyProcessingSta: Integer in interval [0...255]
 * COM_DT_IAU_ProfileIDRVal: Integer in interval [0...255]
 * COM_DT_ICC_HS_AlvCnt4Val: Integer in interval [0...255]
 * COM_DT_ICC_HS_Crc4Val: Integer in interval [0...255]
 * COM_DT_ICC_IntvSDLvlStat: Integer in interval [0...255]
 * COM_DT_ICC_IntvStat: Integer in interval [0...255]
 * COM_DT_ICSC_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_ICSC_Crc2Val: Integer in interval [0...65535]
 * COM_DT_ICU_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_ICU_AlvCnt4Val: Integer in interval [0...255]
 * COM_DT_ICU_AlvCnt7Val: Integer in interval [0...255]
 * COM_DT_ICU_Crc2Val: Integer in interval [0...255]
 * COM_DT_ICU_Crc4Val: Integer in interval [0...255]
 * COM_DT_ICU_Crc7Val: Integer in interval [0...255]
 * COM_DT_ID_CIPV: Integer in interval [0...255]
 * COM_DT_IEB_ActvSta: Integer in interval [0...255]
 * COM_DT_IEB_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_IEB_BrkActvSta: Integer in interval [0...255]
 * COM_DT_IEB_Crc1Val: Integer in interval [0...65535]
 * COM_DT_IEB_DrvWhlSlipFlg_Frnt: Boolean
 * COM_DT_IEB_EstBrkSacFrcNmVal: Integer in interval [0...65535]
 * COM_DT_IEB_EstDpthPcVal: Integer in interval [0...255]
 * COM_DT_IEB_EstTtlBrkFrcNmVal: Integer in interval [0...65535]
 * COM_DT_IEB_RegenTqLimitNmVal_Frnt: Integer in interval [0...65535]
 * COM_DT_IEB_RegenTqLimitNmVal_Rear: Integer in interval [0...65535]
 * COM_DT_IEB_SrvLmpDis: Integer in interval [0...255]
 * COM_DT_IEB_Sta: Integer in interval [0...255]
 * COM_DT_IEB_StrkDpthPcVal: Integer in interval [0...255]
 * COM_DT_IEB_StrkDpthmmVal: Integer in interval [-32768...32767]
 * COM_DT_IEB_TCS_Req: Integer in interval [0...255]
 * COM_DT_IFSref_VehLtAngl10Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl1Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl2Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl3Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl4Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl5Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl6Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl7Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl8Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehLtAngl9Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehNumVal_1: Integer in interval [0...255]
 * COM_DT_IFSref_VehRtAngl10Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl1Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl2Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl3Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl4Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl5Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl6Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl7Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl8Val_1: Integer in interval [0...65535]
 * COM_DT_IFSref_VehRtAngl9Val_1: Integer in interval [0...65535]
 * COM_DT_IMT_CltchPdlPos: Integer in interval [0...255]
 * COM_DT_IMT_EOLstate: Boolean
 * COM_DT_IMU_AcuRstSta: Integer in interval [0...255]
 * COM_DT_IMU_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_IMU_Crc1Val: Integer in interval [0...65535]
 * COM_DT_IMU_LatAccelSigSta: Integer in interval [0...255]
 * COM_DT_IMU_LatAccelVal: Integer in interval [0...65535]
 * COM_DT_IMU_LongAccelSigSta: Integer in interval [0...255]
 * COM_DT_IMU_LongAccelVal: Integer in interval [0...65535]
 * COM_DT_IMU_McuVoltSta: Integer in interval [0...255]
 * COM_DT_IMU_RollRtVal: Integer in interval [0...65535]
 * COM_DT_IMU_RollSigSta: Integer in interval [0...255]
 * COM_DT_IMU_SnsrTempVal: Integer in interval [0...255]
 * COM_DT_IMU_SnsrTyp: Integer in interval [0...255]
 * COM_DT_IMU_VerAccelSigSta: Integer in interval [0...255]
 * COM_DT_IMU_VerAccelVal: Integer in interval [0...65535]
 * COM_DT_IMU_YawRtVal: Integer in interval [0...65535]
 * COM_DT_IMU_YawSigSta: Integer in interval [0...255]
 * COM_DT_ISLA_AddtnlSign: Integer in interval [0...255]
 * COM_DT_ISLA_AutoNModReq: Integer in interval [0...255]
 * COM_DT_ISLA_AutoNModSta: Integer in interval [0...255]
 * COM_DT_ISLA_Cntry: Integer in interval [0...255]
 * COM_DT_ISLA_CondInfoDisp: Integer in interval [0...255]
 * COM_DT_ISLA_EUCntry1USMSta: Integer in interval [0...255]
 * COM_DT_ISLA_EUCntry2USMSta: Integer in interval [0...255]
 * COM_DT_ISLA_EUCntryVerTyp: Integer in interval [0...255]
 * COM_DT_ISLA_IcyWrn: Integer in interval [0...255]
 * COM_DT_ISLA_NACntry1USMSta: Integer in interval [0...255]
 * COM_DT_ISLA_NACntry2USMSta: Integer in interval [0...255]
 * COM_DT_ISLA_NACntryVerTyp: Integer in interval [0...255]
 * COM_DT_ISLA_OptUsmSta: Integer in interval [0...255]
 * COM_DT_ISLA_Popup: Integer in interval [0...255]
 * COM_DT_ISLA_SchoolZone: Integer in interval [0...255]
 * COM_DT_ISLA_SndReqSta: Integer in interval [0...255]
 * COM_DT_ISLA_SpdChgReq: Integer in interval [0...255]
 * COM_DT_ISLA_SpdWrn: Integer in interval [0...255]
 * COM_DT_ISLA_SpdwOffst: Integer in interval [0...255]
 * COM_DT_ISLA_SwIgnoreReq: Integer in interval [0...255]
 * COM_DT_ISLA_SymFlashMod: Integer in interval [0...255]
 * COM_DT_ISLA_TSRSpdLimVal: Integer in interval [0...255]
 * COM_DT_ISLW_NoPassingInfoDis: Integer in interval [0...255]
 * COM_DT_ISLW_SpdCluDisSubCond1: Integer in interval [0...255]
 * COM_DT_ISLW_SpdCluDisSubCond2: Integer in interval [0...255]
 * COM_DT_ISLW_SpdCluMainDis: Integer in interval [0...255]
 * COM_DT_ISLW_SpdNaviDisSubCond1: Integer in interval [0...255]
 * COM_DT_ISLW_SpdNaviDisSubCond2: Integer in interval [0...255]
 * COM_DT_ISLW_SpdNaviMainDis: Integer in interval [0...255]
 * COM_DT_ISLW_SubCondinfoSta1: Integer in interval [0...255]
 * COM_DT_ISLW_SubCondinfoSta2: Integer in interval [0...255]
 * COM_DT_InAirTempVal_1: Integer in interval [0...255]
 * COM_DT_Info_LtLnCrvtrDrvtvVal: Integer in interval [-32768...32767]
 * COM_DT_Info_LtLnCvtrVal: Integer in interval [-32768...32767]
 * COM_DT_Info_LtLnHdingAnglVal: Integer in interval [-32768...32767]
 * COM_DT_Info_LtLnPosVal: Integer in interval [-32768...32767]
 * COM_DT_Info_LtLnQualSta: Integer in interval [0...255]
 * COM_DT_Info_OD_PedDstVal: Integer in interval [0...255]
 * COM_DT_Info_RtLnCrvtrDrvtvVal: Integer in interval [-32768...32767]
 * COM_DT_Info_RtLnCvtrVal: Integer in interval [-32768...32767]
 * COM_DT_Info_RtLnHdingAnglVal: Integer in interval [-32768...32767]
 * COM_DT_Info_RtLnPosVal: Integer in interval [-32768...32767]
 * COM_DT_Info_RtLnQualSta: Integer in interval [0...255]
 * COM_DT_LDM_Sta: Integer in interval [0...255]
 * COM_DT_LHCU_EngCltchTrnsfrTqPcVal_Copy_1: Integer in interval [-32768...32767]
 * COM_DT_LKA_HndsoffSnd: Integer in interval [0...255]
 * COM_DT_LKA_RcgSta: Integer in interval [0...255]
 * COM_DT_LKA_SysWrn: Integer in interval [0...255]
 * COM_DT_Lamp_BLEWelcomeSig: Boolean
 * COM_DT_Lamp_HbaCtrlModTyp: Integer in interval [0...255]
 * COM_DT_Lamp_IFSCtrlModTyp: Integer in interval [0...255]
 * COM_DT_Lamp_LedHdLmpSta: Integer in interval [0...255]
 * COM_DT_Longitudinal_Distance: Integer in interval [0...65535]
 * COM_DT_MCB_CtlSta: Boolean
 * COM_DT_MCB_DefSta: Boolean
 * COM_DT_MCB_ReqBrkAck: Integer in interval [0...255]
 * COM_DT_MDPS_ADASAciActvSta: Integer in interval [0...255]
 * COM_DT_MDPS_ADASAciActvSta_Lv2: Integer in interval [0...255]
 * COM_DT_MDPS_ADAS_AciFltSig_Lv2: Integer in interval [0...255]
 * COM_DT_MDPS_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_MDPS_Crc1Val: Integer in interval [0...65535]
 * COM_DT_MDPS_EstStrAnglVal: Integer in interval [-32768...32767]
 * COM_DT_MDPS_HDPSpprtSWVer: Integer in interval [0...255]
 * COM_DT_MDPS_LkaPlgInSta: Integer in interval [0...255]
 * COM_DT_MDPS_OutTqVal: Integer in interval [0...65535]
 * COM_DT_MDPS_PaModeSta: Integer in interval [0...255]
 * COM_DT_MDPS_PaPlugInSta: Integer in interval [0...255]
 * COM_DT_MDPS_PaStrAnglVal: Integer in interval [-32768...32767]
 * COM_DT_MDPS_StrTqSnsrVal: Integer in interval [0...65535]
 * COM_DT_MDPS_VsmPlgInSta: Integer in interval [0...255]
 * COM_DT_MDPS_WrngLmpSta: Integer in interval [0...255]
 * COM_DT_META_V2_3_CountryCode_1: Integer in interval [0...65535]
 * COM_DT_META_V2_3_CyclicCounter_1: Integer in interval [0...255]
 * COM_DT_META_V2_3_MajorProtocolVersion_1: Integer in interval [0...255]
 * COM_DT_META_V2_3_MinorProtocolVersion_1: Integer in interval [0...255]
 * COM_DT_META_V2_3_RegionCode_1: Integer in interval [0...65535]
 * COM_DT_MFSW_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_MFSW_Crc1Val: Integer in interval [0...255]
 * COM_DT_MSR_TqFlag: Boolean
 * COM_DT_MSR_TqIntrvntnVal: Integer in interval [0...255]
 * COM_DT_MV_CtRoadSrfcDstVal: Integer in interval [0...65535]
 * COM_DT_MV_CtRoadSrfcSta: Integer in interval [0...255]
 * COM_DT_MV_DrvLnCtLnSta: Integer in interval [0...255]
 * COM_DT_MV_DrvLnRdsVal: Integer in interval [0...255]
 * COM_DT_MV_FrLtObjLatPosVal: Integer in interval [0...255]
 * COM_DT_MV_FrLtObjLongPosVal: Integer in interval [0...65535]
 * COM_DT_MV_FrLtObjMvngDirSta: Integer in interval [0...255]
 * COM_DT_MV_FrLtObjSta: Integer in interval [0...255]
 * COM_DT_MV_FrLtRdrWaveSta: Integer in interval [0...255]
 * COM_DT_MV_FrObjLatPosVal: Integer in interval [-128...127]
 * COM_DT_MV_FrObjLongPosVal: Integer in interval [0...65535]
 * COM_DT_MV_FrObjSta: Integer in interval [0...255]
 * COM_DT_MV_FrObstLatPosVal: Integer in interval [-128...127]
 * COM_DT_MV_FrObstLongPosVal: Integer in interval [0...65535]
 * COM_DT_MV_FrObstSta: Integer in interval [0...255]
 * COM_DT_MV_FrRdrWaveSta: Integer in interval [0...255]
 * COM_DT_MV_FrRtObjLatPosVal: Integer in interval [0...255]
 * COM_DT_MV_FrRtObjLongPosVal: Integer in interval [0...65535]
 * COM_DT_MV_FrRtObjMvngDirSta: Integer in interval [0...255]
 * COM_DT_MV_FrRtObjSta: Integer in interval [0...255]
 * COM_DT_MV_FrRtRdrWaveSta: Integer in interval [0...255]
 * COM_DT_MV_HostVeh1Sta: Integer in interval [0...255]
 * COM_DT_MV_LtLCDirSta: Integer in interval [0...255]
 * COM_DT_MV_LtLnOffstVal: Integer in interval [0...255]
 * COM_DT_MV_LtLnSta: Integer in interval [0...255]
 * COM_DT_MV_LtObjLatPosVal: Integer in interval [0...255]
 * COM_DT_MV_LtObjLongPosVal: Integer in interval [0...255]
 * COM_DT_MV_LtObjSta: Integer in interval [0...255]
 * COM_DT_MV_LtRoadSrfcSta: Integer in interval [0...255]
 * COM_DT_MV_RrLtRdrWave1Sta: Integer in interval [0...255]
 * COM_DT_MV_RrRtRdrWave1Sta: Integer in interval [0...255]
 * COM_DT_MV_RtLCDirSta: Integer in interval [0...255]
 * COM_DT_MV_RtLnOffstVal: Integer in interval [0...255]
 * COM_DT_MV_RtLnSta: Integer in interval [0...255]
 * COM_DT_MV_RtObjLatPosVal: Integer in interval [0...255]
 * COM_DT_MV_RtObjLongPosVal: Integer in interval [0...255]
 * COM_DT_MV_RtObjSta: Integer in interval [0...255]
 * COM_DT_MV_RtRoadSrfcSta: Integer in interval [0...255]
 * COM_DT_MV_VehDstSta: Integer in interval [0...255]
 * COM_DT_MV_VehDstVal: Integer in interval [0...65535]
 * COM_DT_OBD_DnmntrCalcVal_1: Integer in interval [0...65535]
 * COM_DT_OBD_IgnCycCntVal_1: Integer in interval [0...65535]
 * COM_DT_OBD_MilConfgVal: Integer in interval [0...255]
 * COM_DT_OBD_RbmInhbtSta_1: Integer in interval [0...255]
 * COM_DT_OBD_RbmSta_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_CurrAltitude1m_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_CurrDirectionLanes_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_CurrFormOfWay_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_CyclicCounter_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_Offset_1: Integer in interval [0...65535]
 * COM_DT_POS_V2_3_PathIndex_1: Integer in interval [0...255]
 * COM_DT_POS_V2_3_RangeAvgSpeed_1: Integer in interval [0...65535]
 * COM_DT_PROLONG_V2_3_CyclicCounter_1: Integer in interval [0...255]
 * COM_DT_PROLONG_V2_3_Offset_1: Integer in interval [0...65535]
 * COM_DT_PROLONG_V2_3_PathIndex_1: Integer in interval [0...255]
 * COM_DT_PROLONG_V2_3_ProfileType_1: Integer in interval [0...255]
 * COM_DT_PROLONG_V2_3_Value_1: Integer in interval [0...4294967295]
 * COM_DT_PROSHORT_V2_3_Accuracy_1: Integer in interval [0...255]
 * COM_DT_PROSHORT_V2_3_CyclicCounter_1: Integer in interval [0...255]
 * COM_DT_PROSHORT_V2_3_Distance_1: Integer in interval [0...65535]
 * COM_DT_PROSHORT_V2_3_Offset_1: Integer in interval [0...65535]
 * COM_DT_PROSHORT_V2_3_PathIndex_1: Integer in interval [0...255]
 * COM_DT_PROSHORT_V2_3_ProfileType_1: Integer in interval [0...255]
 * COM_DT_PROSHORT_V2_3_Value0_1: Integer in interval [0...65535]
 * COM_DT_PROSHORT_V2_3_Value1_1: Integer in interval [0...65535]
 * COM_DT_PU_F_Group1_ADASWarn1_1Sta: Integer in interval [0...255]
 * COM_DT_PU_F_Group1_ADASWarn1_2Sta: Integer in interval [0...255]
 * COM_DT_PU_F_Group4_ADASWarn1_1Sta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_DAW_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_DrvrAsstFlr1Sta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_FwdSdSftyFlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_FwdSftyFlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_HBA_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_HDA_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_HDP_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_ISLA_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_LCA_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_LFA_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_LnSftyFlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_MRM_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_F_Group7_SCC_FlrSta: Integer in interval [0...255]
 * COM_DT_PU_M_Group2_ADASWarn1_1Sta: Integer in interval [0...255]
 * COM_DT_PU_M_Group2_ADASWarn1_2Sta: Integer in interval [0...255]
 * COM_DT_RSC_TqFlag_Frnt: Boolean
 * COM_DT_RSC_TqFlag_Rear: Boolean
 * COM_DT_RSC_TqIntrvntnVal_Frnt: Integer in interval [0...255]
 * COM_DT_RSC_TqIntrvntnVal_Rear: Integer in interval [0...255]
 * COM_DT_RSPA_Actv: Integer in interval [0...255]
 * COM_DT_RSPA_AvnDis: Integer in interval [0...255]
 * COM_DT_RSPA_AvnHmiDis: Integer in interval [0...255]
 * COM_DT_RSPA_AvnModDis: Integer in interval [0...255]
 * COM_DT_RSPA_AvnSubViewDis: Integer in interval [0...255]
 * COM_DT_RSPA_DCTTrgtTqVal: Integer in interval [-32768...32767]
 * COM_DT_RSPA_EvasiveStrBtnDis: Integer in interval [0...255]
 * COM_DT_RSPA_ExtLampReq: Integer in interval [0...255]
 * COM_DT_RSPA_IndBlnkReq: Integer in interval [0...255]
 * COM_DT_RSPA_RmtPrlExitDis: Integer in interval [0...255]
 * COM_DT_RSPA_SelFuncInfo: Integer in interval [0...255]
 * COM_DT_RSPA_SysOff: Boolean
 * COM_DT_RSPA_TrgtTqVal: Integer in interval [-32768...32767]
 * COM_DT_RSPA_TrgtVehSpdVal: Integer in interval [0...65535]
 * COM_DT_RSPA_Var: Integer in interval [0...255]
 * COM_DT_Relative_Velocity: Integer in interval [0...65535]
 * COM_DT_SAS_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_SAS_AnglVal: Integer in interval [-32768...32767]
 * COM_DT_SAS_Crc1Val: Integer in interval [0...65535]
 * COM_DT_SAS_IntSta: Integer in interval [0...255]
 * COM_DT_SAS_SpdVal: Integer in interval [0...255]
 * COM_DT_SCC_Char2Sta: Integer in interval [0...255]
 * COM_DT_SCC_EnblReq: Integer in interval [0...255]
 * COM_DT_SCC_StrtLimFuncSta_1: Integer in interval [0...255]
 * COM_DT_SCC_TqIntrvntnVal: Integer in interval [0...255]
 * COM_DT_SCR_IndcmtExitStaDis_1: Integer in interval [0...255]
 * COM_DT_SCR_LvlWrngMsgDis_1: Integer in interval [0...255]
 * COM_DT_SCR_RmnDstDis_1: Integer in interval [0...65535]
 * COM_DT_SCR_RmnRstrtDis_1: Integer in interval [0...255]
 * COM_DT_SCR_SysErrMsgDis_1: Integer in interval [0...255]
 * COM_DT_SCR_UreaLvlSta_1: Integer in interval [0...255]
 * COM_DT_SEG_V2_3_CyclicCounter_1: Integer in interval [0...255]
 * COM_DT_SEG_V2_3_DirectionLanes_1: Integer in interval [0...255]
 * COM_DT_SEG_V2_3_FormOfWay_1: Integer in interval [0...255]
 * COM_DT_SEG_V2_3_Offset_1: Integer in interval [0...65535]
 * COM_DT_SEG_V2_3_PathIndex_1: Integer in interval [0...255]
 * COM_DT_SEG_V2_3_SpeedLimitUnder5_1: Integer in interval [0...255]
 * COM_DT_SHIFT_IND_LED: Integer in interval [0...255]
 * COM_DT_SMK_AlvCnt2Val: Integer in interval [0...255]
 * COM_DT_SMK_Crc2Val: Integer in interval [0...255]
 * COM_DT_SMK_TrmnlCtrlSta: Integer in interval [0...255]
 * COM_DT_SMV_DrvAsstHUDSymbSta: Integer in interval [0...255]
 * COM_DT_SMV_FrObjSta: Integer in interval [0...255]
 * COM_DT_SMV_HDA_SymbSta: Integer in interval [0...255]
 * COM_DT_SMV_HostVehSta: Integer in interval [0...255]
 * COM_DT_SMV_ISLA_SetSpdSymbSta: Integer in interval [0...255]
 * COM_DT_SMV_LCA_LtSymbSta: Integer in interval [0...255]
 * COM_DT_SMV_LCA_RtSymbSta: Integer in interval [0...255]
 * COM_DT_SMV_LFA_SymbSta: Integer in interval [0...255]
 * COM_DT_SMV_NSCC_SymbSta: Integer in interval [0...255]
 * COM_DT_SMV_SetSpdSta: Integer in interval [0...255]
 * COM_DT_SMV_SetSpdVal: Integer in interval [0...255]
 * COM_DT_SMV_VehDstLvlSta: Integer in interval [0...255]
 * COM_DT_SMV_VehDstLvlVal: Integer in interval [0...255]
 * COM_DT_SND_ADASWarn1_1Sta: Integer in interval [0...255]
 * COM_DT_SND_ADASWarn1_2Sta: Integer in interval [0...255]
 * COM_DT_SND_ADASWarn1_3Sta: Integer in interval [0...255]
 * COM_DT_SND_ADASWarn1_4Sta: Integer in interval [0...255]
 * COM_DT_SND_ADASWarn1_5Sta: Integer in interval [0...255]
 * COM_DT_SSC_CLUEngSpd: Integer in interval [0...65535]
 * COM_DT_SSC_CLUEngSpdFlag: Integer in interval [0...255]
 * COM_DT_SWRC_AlvCnt3Val: Integer in interval [0...255]
 * COM_DT_SWRC_Crc3Val: Integer in interval [0...255]
 * COM_DT_SWRC_CrsSwSta: Integer in interval [0...255]
 * COM_DT_SWRC_HDPSpprtSWVer: Integer in interval [0...255]
 * COM_DT_TCH_EngTrgtGearSta: Integer in interval [0...255]
 * COM_DT_TCS_LmpSta: Integer in interval [0...255]
 * COM_DT_TCS_ManufacturerVal: Integer in interval [0...255]
 * COM_DT_TCS_MtrTrgtRpm_Flag_Frnt: Boolean
 * COM_DT_TCS_MtrTrgtRpm_Flag_Rear: Boolean
 * COM_DT_TCS_MtrTrgtRpm_Frnt: Integer in interval [0...65535]
 * COM_DT_TCS_MtrTrgtRpm_Rear: Integer in interval [0...65535]
 * COM_DT_TCS_OffLmpSta: Integer in interval [0...255]
 * COM_DT_TCS_Req: Integer in interval [0...255]
 * COM_DT_TCS_SlwTqFlag: Boolean
 * COM_DT_TCS_SlwTqIntrvntnVal: Integer in interval [0...255]
 * COM_DT_TCS_Sta: Integer in interval [0...255]
 * COM_DT_TCS_TqFlag: Boolean
 * COM_DT_TCS_TqFlag_Frnt: Boolean
 * COM_DT_TCS_TqFlag_Rear: Boolean
 * COM_DT_TCS_TqIntrvntnVal: Integer in interval [0...255]
 * COM_DT_TCS_TqIntrvntnVal_Frnt: Integer in interval [0...255]
 * COM_DT_TCS_TqIntrvntnVal_Rear: Integer in interval [0...255]
 * COM_DT_TCU_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_TCU_CluTrgtGearSta: Integer in interval [0...255]
 * COM_DT_TCU_Crc1Val: Integer in interval [0...65535]
 * COM_DT_TCU_CurrGearSta: Integer in interval [0...255]
 * COM_DT_TCU_DcmlVehSpdKphVal: Integer in interval [0...255]
 * COM_DT_TCU_EPBReq: Boolean
 * COM_DT_TCU_EngRpmDis: Integer in interval [0...65535]
 * COM_DT_TCU_EngRpmDisSta: Integer in interval [0...255]
 * COM_DT_TCU_EngSpdIncReq: Integer in interval [0...255]
 * COM_DT_TCU_FrtStcShftSta: Integer in interval [0...255]
 * COM_DT_TCU_FuelCutInhbtReq: Integer in interval [0...255]
 * COM_DT_TCU_GearSlctDis: Integer in interval [0...255]
 * COM_DT_TCU_LupTrgtEngSpdVal: Integer in interval [0...255]
 * COM_DT_TCU_ObdSta: Integer in interval [0...255]
 * COM_DT_TCU_SlpVal: Integer in interval [0...255]
 * COM_DT_TCU_SprkRtrdReq: Integer in interval [0...255]
 * COM_DT_TCU_TqGrdntLimVal: Integer in interval [0...255]
 * COM_DT_TCU_TrgtGearSta: Integer in interval [0...255]
 * COM_DT_TCU_VgisInhbtReq: Integer in interval [0...255]
 * COM_DT_TT_DAW_SymbSta: Integer in interval [0...255]
 * COM_DT_TT_EmergStrSymbSta: Integer in interval [0...255]
 * COM_DT_TT_FwdSftySymbSta: Integer in interval [0...255]
 * COM_DT_TT_HBA_SymbSta: Integer in interval [0...255]
 * COM_DT_TT_ISLA_AddtnlTrffcSgnSta: Integer in interval [0...255]
 * COM_DT_TT_ISLA_SpdLimTrffcSgnSta: Integer in interval [0...255]
 * COM_DT_TT_ISLA_SpdLimTrffcSgnVal: Integer in interval [0...255]
 * COM_DT_TT_ISLA_SuppTrffcSgnSta: Integer in interval [0...255]
 * COM_DT_TT_ISLA_TrffcSgnCntryInfoSta: Integer in interval [0...255]
 * COM_DT_TT_LnSftySymbSta: Integer in interval [0...255]
 * COM_DT_TgtEngRPM: Integer in interval [0...65535]
 * COM_DT_USM_AdasBCASetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasBVMSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasDAWModSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasFCASetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasHptWrngSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasISLAEUCntry1SetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasISLANACntry1SetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasISLASetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasLkaModSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasPCA_RrStaSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasRCCANSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasSCCDrvModSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasSCCMLChar1SetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasSCCMLChar2SetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasSCCMLChar3SetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasWarnTimeSetReq: Integer in interval [0...255]
 * COM_DT_USM_AdasWrngTimingSetReq: Integer in interval [0...255]
 * COM_DT_USM_AutoDrLkSetReq2: Integer in interval [0...255]
 * COM_DT_USM_Clu3dDepthSta: Integer in interval [0...255]
 * COM_DT_USM_CluAdasVolSta: Integer in interval [0...255]
 * COM_DT_USM_CluFuelEconomySta: Integer in interval [0...255]
 * COM_DT_USM_IllAlwaysOnwithPSTNSta: Integer in interval [0...255]
 * COM_DT_VAR_Opt1Sta: Integer in interval [0...4294967295]
 * COM_DT_WHL_AlvCnt1Val: Integer in interval [0...255]
 * COM_DT_WHL_Crc1Val: Integer in interval [0...65535]
 * COM_DT_WHL_DirFLVal: Integer in interval [0...255]
 * COM_DT_WHL_DirFRVal: Integer in interval [0...255]
 * COM_DT_WHL_DirRLVal: Integer in interval [0...255]
 * COM_DT_WHL_DirRRVal: Integer in interval [0...255]
 * COM_DT_WHL_PlsFLVal: Integer in interval [0...255]
 * COM_DT_WHL_PlsFRVal: Integer in interval [0...255]
 * COM_DT_WHL_PlsRLVal: Integer in interval [0...255]
 * COM_DT_WHL_PlsRRVal: Integer in interval [0...255]
 * COM_DT_WHL_SpdCalParmtr: Integer in interval [0...65535]
 * COM_DT_WHL_SpdFLVal: Integer in interval [0...65535]
 * COM_DT_WHL_SpdFRVal: Integer in interval [0...65535]
 * COM_DT_WHL_SpdRLVal: Integer in interval [0...65535]
 * COM_DT_WHL_SpdRRVal: Integer in interval [0...65535]
 * COM_DT_Wiper_RainSnsrPartNum: Integer in interval [0...255]
 * CpApDiag_Status: Integer in interval [0...65535]
 * ESS_Sta: Integer in interval [0...255]
 * FCA_DclReqVal_1: Integer in interval [0...255]
 * FCA_RelVel_1: Integer in interval [0...65535]
 * FCA_TimetoCllsn_1: Integer in interval [0...255]
 * ICC_HDPSpprtSWVer: Integer in interval [0...255]
 * ICC_HS_AlvCnt1Val: Integer in interval [0...255]
 * ICC_HS_Crc1Val: Integer in interval [0...255]
 * ICC_MajorSWVer: Integer in interval [0...255]
 * ICC_MinorSWVer: Integer in interval [0...255]
 * ICC_WarningSmblDistStat: Boolean
 * ICC_WarningSmblDrowStat: Boolean
 * ICC_WarningSnd2Stat: Boolean
 * ICC_WarningSndStat: Boolean
 * NSCC_Op2Sta: Integer in interval [0...255]
 * Navi_ISLW_CountryCode: Integer in interval [0...65535]
 * Navi_ISLW_MapSource: Integer in interval [0...255]
 * Navi_ISLW_SpdLimit: Integer in interval [0...255]
 * Navi_ISLW_TimeSpd: Integer in interval [0...255]
 * SCC_AccelLimBandLwrVal: Integer in interval [0...255]
 * SCC_AccelLimBandUppVal: Integer in interval [0...255]
 * SCC_AccelReqRawVal: Integer in interval [0...65535]
 * SCC_AccelReqVal: Integer in interval [0...65535]
 * SCC_DrvAlrtDis: Integer in interval [0...255]
 * SCC_EngStateReq: Integer in interval [0...255]
 * SCC_HeadwayDstSetVal: Integer in interval [0...255]
 * SCC_InfoDis: Integer in interval [0...255]
 * SCC_JrkLwrLimVal: Integer in interval [0...255]
 * SCC_JrkUppLimVal: Integer in interval [0...255]
 * SCC_NSCCInfoPUDis: Integer in interval [0...255]
 * SCC_ObjDstVal: Integer in interval [0...65535]
 * SCC_ObjLatPosVal: Integer in interval [0...65535]
 * SCC_ObjRelSpdVal: Integer in interval [0...65535]
 * SCC_ObjSta: Integer in interval [0...255]
 * SCC_OpSta: Integer in interval [0...255]
 * SCC_SnstvtyModRetVal: Integer in interval [0...255]
 * SCC_TrgtDstVal: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * dtRef_const_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * ABS_ActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ABS_control_inactive (0U)
 *   Cx1_ABS_control_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * ABS_DfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ABS_is_not_defective (0U)
 *   Cx1_ABS_is_defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * ABS_WrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ABS_Warning_lamp_OFF (0U)
 *   Cx1_ABS_Warning_lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * ADAS_DrUnlckReqSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_request (0U)
 *   Cx1_Door_unlock_request (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * ADAS_InhbtOffDispSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Inhibit_off_in_regulationCluster (1U)
 *   Cx2_Inhibit_off_in_regulationHUNIT (2U)
 *   Cx3_Inhibit_off_in_HDP (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * ADAS_TrlOffStaDisp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Auto_Off_by_Trailer_connected (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_ADAS_ActToiSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_De_activate_TOI (0U)
 *   Cx1_Activate_TOI (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ADAS_ToiFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Fault (0U)
 *   Cx1_Fault (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicatorr (3U)
 * COM_DT_AVH_ActvStaLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_On (0U)
 *   Cx1_Lamp_Off (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_AVH_LmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AVH_Off_Lamp_Status (0U)
 *   Cx1_AVH_failure_Lamp_Status (1U)
 *   Cx2_AVH_ACTIVE_Lamp_Status (2U)
 *   Cx3_AVH_READY_Lamp_Status (3U)
 *   Cx4_Lamp_Status (4U)
 *   Cx5_Lamp_Status (5U)
 *   Cx6_Lamp_Status (6U)
 * COM_DT_AVN_RSPA_CancelInput: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Init (0U)
 *   Cx1_No_Input (1U)
 *   Cx2_Cancel_Input (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_AVN_RSPA_Disp_Rdy: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Impossible_to_display (0U)
 *   Cx1_Possible_to_display (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_AWD_CrdnShftTqLimVal: Enumeration of integer in interval [0...65535] with enumerators
 *   CxFFFF_Error (65535U)
 * COM_DT_AWD_FastOpnCrdnShftCltchReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Passive (0U)
 *   Cx1_Clutch_off (1U)
 *   Cx2_Torque_limit (2U)
 *   Cx3_Error (3U)
 * COM_DT_AWD_RrWhlDtyLimReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request_from_ESC (0U)
 *   Cx1_Request_duty_limit_from_ESC (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_AWD_TransmsnTqLimModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Maximum_limitation_mode (0U)
 *   Cx1_Minimum_limitation_mode (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Autocut_DlvryModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Before_Delivery_Welcome_Off_ (0U)
 *   Cx1_After_Delivery_Welcome_On_ (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_BCA_Rear_WrnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Warning (0U)
 *   Cx1_Left_Warning (1U)
 *   Cx2_Right_Warning (2U)
 *   Cx3_Left_Control (3U)
 *   Cx4_Right_Control (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_indicator (7U)
 * COM_DT_BCM_GearPosPSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_P (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_BCM_SunRoofOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Close (0U)
 *   Cx1_Open (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CF_AVN_LKAWrngVolNvalueSet: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CF_ECU_SSC_STAT: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_SSC_OFF_Normal_ (0U)
 *   Cx1_SSC_ON (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Failure_Detected (3U)
 * COM_DT_CF_EMS_SSC_Tgt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_strategy_Normal_Drive_ (0U)
 *   Cx1_IDC_strategy (1U)
 *   Cx2_SSC_strategy (2U)
 * COM_DT_CF_HU_GPSFlt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Fault_operation (1U)
 *   Cx2_TimeOut (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_AdasDAWResetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_ResetReq (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_DisSpdVal_KPH: Enumeration of integer in interval [0...65535] with enumerators
 *   Cx1FF_Error (511U)
 * COM_DT_CLU_DtntOutSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Detent_Off (0U)
 *   Cx1_Detent_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CLU_EngOilChngChkSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Yes (1U)
 *   Cx2_No (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_ISGoperationTimeRstReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Reset_Request (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_IceWrnIndSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CLU_LoFuelWrngSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Low_fuel_Warning_is_off (0U)
 *   Cx1_Low_fuel_Warning_is_on (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_OKSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_PwrAutoOffResetReq_HCU: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Reset_Request (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_RefuelDetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Non_refuel_detected (0U)
 *   Cx1_Refuel_detected (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CLU_RefuelWrnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Refuel_Popup_is_off (0U)
 *   Cx1_Refuel_Popup_is_on (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_RhstaLvlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Reserved (0U)
 *   Cx01_Step_1 (1U)
 *   Cx02_Step_2 (2U)
 *   Cx03_Step_3 (3U)
 *   Cx04_Step_4 (4U)
 *   Cx05_Step_5 (5U)
 *   Cx06_Step_6 (6U)
 *   Cx07_Step_7 (7U)
 *   Cx08_Step_8 (8U)
 *   Cx09_Step_9 (9U)
 *   Cx0A_Step_10 (10U)
 *   Cx0B_Step_11 (11U)
 *   Cx0C_Step_12 (12U)
 *   Cx0D_Step_13 (13U)
 *   Cx0E_Step_14 (14U)
 *   Cx0F_Step_15 (15U)
 *   Cx10_Step_16 (16U)
 *   Cx11_Step_17 (17U)
 *   Cx12_Step_18 (18U)
 *   Cx13_Step_19 (19U)
 *   Cx14_Step_20_Reset_Value_ (20U)
 *   Cx15_Step_21_Detent_ (21U)
 * COM_DT_CLU_SRSWrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_OFF (0U)
 *   Cx1_Lamp_On (1U)
 *   Cx2_Lamp_Flashing (2U)
 *   Cx3_ACU_message_error (3U)
 *   Cx6_Initialization (6U)
 *   Cx7_Lamp_Circuit_Failure (7U)
 * COM_DT_CLU_SWRCCrsMainSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_SWRCLFASwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_SWRCSldMainSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_CLU_TerrainMainSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_On_Road (1U)
 *   Cx2_Off_Road (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_CLU_TripUnitSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Used (0U)
 *   Cx1_km (1U)
 *   Cx2_mile (2U)
 *   Cx3_Invailid (3U)
 * COM_DT_CSC_WrngSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Control_Default_ (0U)
 *   Cx1_Control (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_Exra_EbrakSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_ExtTailLmpLftOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Open_Status (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_ExtTailLmpRtOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Open_Status (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_RearfogAct: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invaild (3U)
 * COM_DT_CTM_StpLmpOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Open_Status (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_TrailerAct: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Connected (0U)
 *   Cx1_Connected (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invaild (3U)
 * COM_DT_CTM_TrnSigLmpLftOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Open_Status (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_CTM_TrnSigLmpRtOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Open_Status (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_C_TeleActiveStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Active (0U)
 *   Cx1_Deactive (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ChildLock_ActnFlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OK (0U)
 *   Cx1_Failed (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DAW_LVDA_OptUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Option_default_ (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_DBC_ClusterDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_DBC_Enabled (0U)
 *   Cx1_DBC_Disabled_by_system_fault (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_DBC_FuncLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_DBC_Function_lamp_OFF (0U)
 *   Cx1_DBC_Function_lamp_ON (1U)
 *   Cx2_DBC_Function_lamp_BLINKING_2Hz_ (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DBC_WrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_DBC_Warning_lamp_OFF (0U)
 *   Cx1_DBC_Warning_lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DCT_CltchState: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Drivetrain_Both_Clutch_Open (0U)
 *   Cx1_Odd_Clutch_Slipping (1U)
 *   Cx2_Even_Clutch_Slipping (2U)
 *   Cx3_Clutch_Locked (3U)
 * COM_DT_DCT_EngIdleReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Idle_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DCT_EngSpdErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_Engine_speed_sensor_defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_DCT_FuelCutReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Fuel_Cut_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DCT_MafErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_Error_on_Torque_Measurement (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_DCT_RegenInhbt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Inhibit (0U)
 *   Cx1_Regen_Inhibit (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DCT_ShftTqReq: Enumeration of integer in interval [-32768...32767] with enumerators
 *   Cx800_reduction_to_0_torque (-2048)
 *   Cx000_No_request (0)
 *   Cx7FF_Max_Increase (2047)
 * COM_DT_DCT_TqIncReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Torque_increase_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_AwdFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_DrvMod2Typ: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Drive_Mode_Case1 (1U)
 *   Cx2_Drive_Mode_Case2 (2U)
 *   Cx3_Drive_Mode_Case3 (3U)
 *   Cx4_Drive_Mode_Case4 (4U)
 *   Cx5_Drive_Mode_Case5 (5U)
 *   Cx6_Drive_Mode_Case6 (6U)
 *   Cx7_Drive_Mode_Case7 (7U)
 *   Cx8_Drive_Mode_Case8 (8U)
 *   Cx9_Drive_Mode_Case9 (9U)
 *   CxA_Drive_Mode_Case10 (10U)
 *   CxB_Drive_Mode_Case11 (11U)
 *   CxC_Drive_Mode_Case12 (12U)
 *   CxD_Drive_Mode_Case13 (13U)
 *   CxE_Drive_Mode_Case14 (14U)
 *   CxF_Invalid (15U)
 * COM_DT_DMIC_DrvModTyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Drive_Mode_Case1 (1U)
 *   Cx2_Drive_Mode_Case2 (2U)
 *   Cx3_Drive_Mode_Case3 (3U)
 *   Cx4_Drive_Mode_Case4 (4U)
 *   Cx5_Drive_Mode_Case5 (5U)
 *   Cx6_Drive_Mode_Case6 (6U)
 *   Cx7_Drive_Mode_Case7 (7U)
 *   Cx8_Drive_Mode_Case8 (8U)
 *   Cx9_Drive_Mode_Case9 (9U)
 *   CxA_Drive_Mode_Case10 (10U)
 *   CxB_Drive_Mode_Case11 (11U)
 *   CxC_Drive_Mode_Case12 (12U)
 *   CxD_Drive_Mode_Case13 (13U)
 *   CxE_Drive_Mode_Case14 (14U)
 *   CxF_Invalid (15U)
 * COM_DT_DMIC_EcsFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_ElsdFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_EngFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_EscFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_EsndFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_IndAccSenSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_used (0U)
 *   Cx1_Step_1 (1U)
 *   Cx2_Step_2 (2U)
 *   Cx3_Step_3 (3U)
 *   Cx4_Step_4 (4U)
 *   Cx5_Step_5 (5U)
 *   Cx6_Step_6 (6U)
 *   Cx7_Step_7 (7U)
 * COM_DT_DMIC_IndDecSenSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_used (0U)
 *   Cx1_Step_1 (1U)
 *   Cx2_Step_2 (2U)
 *   Cx3_Step_3 (3U)
 *   Cx4_Step_4 (4U)
 *   Cx5_Step_5 (5U)
 *   Cx6_Step_6 (6U)
 *   Cx7_Step_7 (7U)
 * COM_DT_DMIC_IndMtrPwrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_used (0U)
 *   Cx1_Step_1 (1U)
 *   Cx2_Step_2 (2U)
 *   Cx3_Step_3 (3U)
 *   Cx4_Step_4 (4U)
 *   Cx5_Step_5 (5U)
 *   Cx6_Step_6 (6U)
 *   Cx7_Step_7 (7U)
 * COM_DT_DMIC_IndWhlDrvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_used (0U)
 *   Cx1_AUTO (1U)
 *   Cx2_2WD (2U)
 *   Cx3_4WD (3U)
 * COM_DT_DMIC_MdpsFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_PrflFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_RevFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_RwsFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_SmtShftModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OFF (0U)
 *   Cx1_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_TmFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DMIC_VcuFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defective (0U)
 *   Cx1_Defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DSL_GlowCtrlReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Glow_plug_off_request (0U)
 *   Cx1_Glow_plug_on_request (1U)
 *   Cx2_System_Error (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_DoorLock_AsstDrUnLkSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lock (0U)
 *   Cx1_Unlock (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DoorLock_DrvKeyLkSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Lock (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DoorLock_DrvKeyUnLkSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Unlock (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DoorLock_RrLftDrUnLkSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lock (0U)
 *   Cx1_Unlock (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_DoorLock_RrRtDrUnLkSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lock (0U)
 *   Cx1_Unlock (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ECD_ActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ECD_is_not_active (0U)
 *   Cx1_ECD_is_active_operating_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_EMS_SCCIsgEna: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ISG_Stop_not_Enable (0U)
 *   Cx1_ISG_Stop_Enable (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error (3U)
 * COM_DT_EMS_SafetyFunctSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Safety_Function_operation (0U)
 *   Cx1_Safety_Function_operation (1U)
 * COM_DT_ENG_48VOpIndiLmpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OFF (0U)
 *   Cx1_display_Boost_by_motor (1U)
 *   Cx2_display_Recuperation (2U)
 *   Cx3_reserved (3U)
 * COM_DT_ENG_AccDrvAlertDisp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Auto_cruise_Disengaged (1U)
 *   Cx2_No_Auto_cruise_Engaged (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_Ack4EngStpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_acknowledgement (0U)
 *   Cx1_Acknowledgement_engine_stopped (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_BattWrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Battery_Warning_Lamp_OFF (0U)
 *   Cx1_Battery_Warning_Lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_CltchOpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Clutch_is_not_operating (0U)
 *   Cx1_Clutch_is_operating (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_DpfWrngSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_DPF_Normal_State (0U)
 *   Cx1_DPF_Warning_State_Level_1 (1U)
 *   Cx2_DPF_Warning_State_Level_2 (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_ENG_DsrGearPosDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_display (0U)
 *   Cx1_Gear_Position_1_display (1U)
 *   Cx2_Gear_Position_2_display (2U)
 *   Cx3_Gear_Position_3_display (3U)
 *   Cx4_Gear_Position_4_display (4U)
 *   Cx5_Gear_Position_5_display (5U)
 *   Cx6_Gear_Position_6_display (6U)
 *   Cx7_Gear_Position_7_display (7U)
 *   Cx8_Gear_Position_8_display (8U)
 *   Cx9_Gear_Position_9_display (9U)
 *   CxA_Gear_Position_10_display (10U)
 *   CxF_Error_indicator (15U)
 * COM_DT_ENG_EcoDrvActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Active_Eco_Drive_is_not_active (0U)
 *   Cx1_Active_Eco_Drive_is_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EngInhbNCC: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_NCC_Inhibition_OFF (0U)
 *   Cx1_NCC_Inhibition_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EngRunSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop_or_Starting_Phase (0U)
 *   Cx1_Engine_Running (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EngSpdErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_Engine_speed_sensor_defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EngSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Fault (7U)
 * COM_DT_ENG_EngTyp1: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_epsilon (0U)
 *   Cx1_gamma (1U)
 *   Cx2_kappa (2U)
 *   Cx3_theta (3U)
 *   Cx4_nu (4U)
 *   Cx5_lambda (5U)
 *   Cx6_tau (6U)
 *   CxA_S (10U)
 *   CxB_A (11U)
 *   CxC_R (12U)
 *   CxD_U (13U)
 *   CxE_D (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_ENG_EngTyp2: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_LPI (0U)
 *   Cx1_MPI (1U)
 *   Cx2_GDI (2U)
 *   Cx3_TGDI (3U)
 *   Cx4_CVVL (4U)
 *   Cx5_CVVD (5U)
 *   Cx6_PDI (6U)
 *   Cx7_FFV (7U)
 *   Cx8_TCI (8U)
 *   Cx9_VGT (9U)
 *   CxA_Turbo (10U)
 *   CxB_E_SC (11U)
 *   CxE_Not_used (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_ENG_EngTyp3: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_FF (0U)
 *   Cx1_FR (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EngTyp4: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Non_ETC (0U)
 *   Cx1_ETC (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_EtcLmphModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_control_is_available (0U)
 *   Cx1_ETC_Limphome_mode_by_ECU (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_FuelCapOpnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Fuel_cap_isn_t_opened (0U)
 *   Cx1_Fuel_cap_is_opened (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_FuelCutOffSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_not_in_fuel_cut_off (0U)
 *   Cx1_Engine_in_fuel_cut_off (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_GearShftDnDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Gear_Shiftdown_Display_Off (0U)
 *   Cx1_Gear_Shiftdown_Display_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_GearShftUpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Gear_Shiftup_Display_Off (0U)
 *   Cx1_Gear_Shiftup_Display_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_GlowLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_Off (0U)
 *   Cx1_Lamp_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_ImmoLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Immobilizer_lamp_OFF (0U)
 *   Cx1_Immobilizer_lamp_ON (1U)
 * COM_DT_ENG_ImmoSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Immobilizer_active (0U)
 *   Cx1_Immobilizer_passive (1U)
 * COM_DT_ENG_IsgBzrReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Request_buzzer_OFF (0U)
 *   Cx1_Request_buzzer_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_IsgEquipped: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ISG_is_not_equipped (0U)
 *   Cx1_ISG_is_equipped (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error (3U)
 * COM_DT_ENG_IsgFuelCnsmptDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_fuel_consumption (0U)
 *   Cx1_Fuel_consumption_1mL_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_IsgInhbtLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ISG_Inhibit_Lamp_OFF (0U)
 *   Cx1_ISG_Inhibit_Lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_LnchCntrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_state (0U)
 *   Cx1_Standby (1U)
 *   Cx2_Ready (2U)
 *   Cx3_Lanch (3U)
 *   Cx4_Error_indicator (4U)
 * COM_DT_ENG_MafErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_Error_on_Torque_Measurement (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_MilSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Check_Engine_lamp_OFF (0U)
 *   Cx1_Check_Engine_lamp_ON (1U)
 * COM_DT_ENG_NCC_STATE: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_NCC_OFF_Normal_ (0U)
 *   Cx1_NCC_ON (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Failure_Detected (3U)
 * COM_DT_ENG_OilLifeEna: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Oil_life_monitoring_Not_applied (0U)
 *   Cx1_Oil_life_monitoring_Applied (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error (3U)
 * COM_DT_ENG_OilLvlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OIL_LEVEL_LAMP_Off (0U)
 *   Cx1_OIL_LEVEL_LAMP_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_OilPrsrWrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Oil_Pressure_Warning_Lamp_OFF (0U)
 *   Cx1_Oil_Pressure_Warning_Lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_PETyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_only (0U)
 *   Cx1_Engine_MHSG_48V_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_used (3U)
 * COM_DT_ENG_S_F: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AMS (0U)
 *   Cx1_ISG (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_ENG_S_F_GEN: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_AMS (0U)
 *   Cx1_1G_Generation_AMS (1U)
 *   Cx2_1_5G_Generation_AMS (2U)
 *   Cx3_2G_Generation_AMS (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Reserved (7U)
 * COM_DT_ENG_SldActnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Positive_action_is_not_active (0U)
 *   Cx1_Positive_action_is_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_SldDrvAlertDisp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_SldDisengaged (1U)
 *   Cx2_NoSldEngaged (2U)
 *   Cx3_ErrorIndicator (3U)
 * COM_DT_ENG_SoakTimeErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure_detected (0U)
 *   Cx1_Failure_detected (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_SpltInjctnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Split_injection_OFF (0U)
 *   Cx1_Split_injection_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ENG_TransmsnTyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_AT_vehicle_Step_Shift_AT_ (0U)
 *   Cx09_E_CLUTCH_vehicle (9U)
 *   Cx0A_CVT_vehicle_CVT_AT_ (10U)
 *   Cx0B_DCT_vehicle_DCT_AT_ (11U)
 *   Cx0E_AMT_vehicle (14U)
 *   Cx0F_MT_vehicle (15U)
 * COM_DT_ENG_VehSpdHiVal: Enumeration of integer in interval [0...65535] with enumerators
 *   Cx1FF_Error_indicator (511U)
 * COM_DT_ENG_VehSpdLimVal: Enumeration of integer in interval [0...65535] with enumerators
 *   Cx1FF_Error_indicator (511U)
 * COM_DT_EPB_ActvReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Release_request (1U)
 *   Cx2_Close_request_in_comfort_mode (2U)
 *   Cx3_Close_request_in_secure_mode (3U)
 * COM_DT_EPB_AlrmReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Comfortable_tone_Sound_once_ (1U)
 *   Cx2_Uncomfortable_tone (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_EPB_DynmBrkFrcReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Dynamic_braking_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_EPB_EmerModReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Emergency_EPB_Mode_Request (1U)
 *   Cx2_Normal_EPB_Mode_Request (2U)
 *   Cx3_Not_Used (3U)
 * COM_DT_EPB_FlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_valid (0U)
 *   Cx1_EPB_No_failure (1U)
 *   Cx2_EPB_Initialization_State (2U)
 *   Cx3_EPB_Diagnostic (3U)
 *   Cx4_EPB_Temporarily_Not_Available (4U)
 *   Cx5_EPB_Permanently_Not_Available (5U)
 * COM_DT_EPB_FrcSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_See_details_in_EPB_FRC_ERR (0U)
 *   Cx1_Released (1U)
 *   Cx2_Clamped (2U)
 *   Cx3_Clamping_in_progress (3U)
 *   Cx4_Releasing_in_progress (4U)
 *   Cx5_Dynamic_braking_via_EPB (5U)
 *   Cx6_Releasing_in_progress_by_switch (6U)
 *   Cx7_Clamping_in_progress_by_switch (7U)
 * COM_DT_EPB_StaReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_REQ_EPB_ACT_signal_is_invalid (0U)
 *   Cx1_REQ_EPB_ACT_signal_is_valid (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_EPB_SwPosSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Neutral_position (0U)
 *   Cx1_Apply_position_pull_ (1U)
 *   Cx2_Release_position_push_ (2U)
 *   Cx3_Switch_failure (3U)
 * COM_DT_ESC_BcaRPlusSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_BCA_R_available (0U)
 *   Cx1_BCA_R_braking_is_started (1U)
 *   Cx2_BCA_R_braking_is_ended (2U)
 *   Cx3_BCA_R_braking_error (3U)
 * COM_DT_ESC_BrkLtReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Activate_brake_lights (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_BrkdFltStndstill: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undetected (0U)
 *   Cx1_Detected (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_used (3U)
 * COM_DT_ESC_CylPrsrFlagSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_DBS_ActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_DBS_control_is_inactive (0U)
 *   Cx1_DBS_control_is_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_used (3U)
 * COM_DT_ESC_DclEnblReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Disable_deceleration_control (0U)
 *   Cx1_Enable_deceleration_control (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_DrvBrkActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Brake_pedal_not_pressed (0U)
 *   Cx1_Brake_pedal_pressed (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_DrvOvrdSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_override (0U)
 *   Cx1_Override_by_acceleration_pedal (1U)
 *   Cx2_Override_by_deceleration (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_FCA_ActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_FCA_Brake_is_not_in_activation (0U)
 *   Cx1_FCA_Pre_Brake (1U)
 *   Cx2_FCA_Full_Brake (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ESC_LsdOpn: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Passive (0U)
 *   Cx1_Fast_Open (1U)
 *   Cx2_Slow_Open (2U)
 *   Cx3_Torque_Limit (3U)
 *   Cx4_eLSD_Fail_OPEN (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Error (7U)
 * COM_DT_ESC_OffTempSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_Mode (0U)
 *   Cx1_Sports_Mode (1U)
 *   Cx2_Off_Mode (2U)
 *   Cx3_ESC_OFF_SW_is_defective_failed_ (3U)
 * COM_DT_ESC_PcaSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_PCA_available (0U)
 *   Cx1_PCA_brake_started (1U)
 *   Cx2_PCA_brake_ended (2U)
 *   Cx3_PCA_disable (3U)
 * COM_DT_ESC_PrkBrkActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Parking_brake_is_not_activated (0U)
 *   Cx1_Parking_brake_is_activated (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_RccaSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_RCCA_availble (0U)
 *   Cx1_RCCA_brake_started (1U)
 *   Cx2_RCCA_braking_is_ended (2U)
 *   Cx3_RCCA_braking_error (3U)
 * COM_DT_ESC_RspaDclActv: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_RspaSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_used (0U)
 *   Cx1_ESC_Initial (1U)
 *   Cx2_ESC_New_Start (2U)
 *   Cx3_ESC_Ready (3U)
 *   Cx4_Not_used (4U)
 *   Cx5_ESC_Assist (5U)
 *   Cx6_ESC_Assist_Fail (6U)
 *   Cx7_ESC_Abort (7U)
 *   Cx8_ESC_Ready_Fail (8U)
 * COM_DT_ESC_SprtLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ESC_Sport_Lamp_OFF (0U)
 *   Cx1_ESC_Sport_Lamp_ON (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_ESC_StdStillVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_stand_still_detected (0U)
 *   Cx1_stand_still_detected (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_VsmActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_VSM_control_inactive (0U)
 *   Cx1_VSM_control_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ESC_VsmDfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_VSM_is_not_defective (0U)
 *   Cx1_VSM_is_defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ExtLamp_HzrdSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ExtLamp_TrnSigLmpLftSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ExtLamp_TrnSigLmpRtSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_FCA_AvlblSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Available (0U)
 *   Cx1_Temporarily_not_available (1U)
 *   Cx2_Permanently_not_available (2U)
 *   Cx3_FCA_Communication_Error (3U)
 * COM_DT_FCA_ESA_ActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_FCA_EquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_FCA_is_not_equipped (0U)
 *   Cx1_FCA_is_equipped (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_Coded (3U)
 * COM_DT_FCA_Equip_FR_CMR: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Coding (0U)
 *   Cx1_Sensor_Fusion_FCA (1U)
 *   Cx2_Camera_only_FCA (2U)
 *   Cx3_No_FCA_Option (3U)
 *   Cx4_ADAS_DRV_Option (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_indicator (7U)
 * COM_DT_FR_CMR_ACANMonSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_A_CANFD_Bus_off (1U)
 *   Cx2_A_CANFD_Timeout (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_FR_CMR_CodingSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Coded (0U)
 *   Cx1_Not_coded (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_FR_CMR_EMTrgtVldSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Valid_EM_Target (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_FR_CMR_FCAEquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_applied (0U)
 *   Cx1_Applied (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_FR_CMR_MDPSCtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_applied (0U)
 *   Cx1_Applied (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_FR_CMR_SCCEquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Applied (0U)
 *   Cx1_Applied (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HBA_IndLmpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_HBA_Indicator_Lamp_Off (0U)
 *   Cx1_HBA_Indicator_Lamp_On_Green_ (1U)
 *   Cx2_HBA_Indicator_Lamp_On_White_ (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HBA_OptUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_HBA_Option_Default_ (0U)
 *   Cx1_HBA_Function_Off (1U)
 *   Cx2_HBA_Function_On (2U)
 *   Cx3_Invalid_Fail_ (3U)
 * COM_DT_HBA_SysOptSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_HBA_Option_Default_ (0U)
 *   Cx1_HBA_Option (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HCU_AafCtrlReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Level_0_Open_ (0U)
 *   Cx1_Level_1 (1U)
 *   Cx2_Level_2 (2U)
 *   Cx3_Levle_3_Close_ (3U)
 * COM_DT_HCU_AcPwrIncSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Impossible (0U)
 *   Cx1_Possible (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_AcnOpPrmssnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Permitted (0U)
 *   Cx1_Permitted (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_BlwOffReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Blower_off_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_BrkLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Lamp_On_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_CcCameraOperSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Act (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_HCU_CcDrvAlrtDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_default (0U)
 *   Cx1_CC_Disengaged (1U)
 *   Cx2_No_CC_Engage_Condition (2U)
 *   Cx3_reserved (3U)
 * COM_DT_HCU_ChrgIncModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_CrsCtrlOnLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_Off (0U)
 *   Cx1_Lamp_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_CrsCtrlSetLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_Off (0U)
 *   Cx1_Lamp_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1FriSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1MonSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1SatSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1SunSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1ThuSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1TueSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet1WedSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2FriSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2MonSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2SatSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2ThuSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2TueSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DptEnaSet2WedSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_DrvModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Eco_mode (0U)
 *   Cx1_Normal_mode (1U)
 *   Cx2_Sport_mode (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HCU_DucUsrSetCluSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_User_DUC_Setting_Page_On (1U)
 *   Cx2_DUC_Setting_Cancel_Page_On (2U)
 *   Cx3_DUC_Setting_Confirm_Page_On (3U)
 *   Cx4_DUC_Setting_Inhibit (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Reserved (7U)
 * COM_DT_HCU_EmissionTestModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_EstApsSelSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_EMS_real_APS_use (0U)
 *   Cx1_HCU_Estimated_APS_use (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_GreenZoneDrvModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_reserved (3U)
 * COM_DT_HCU_GreenZoneLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_GDM_Lamp_Off (0U)
 *   Cx1_GDM_Lamp_On (1U)
 * COM_DT_HCU_HEVRdyDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_READY_LAMP_OFF (0U)
 *   Cx1_READY_LAMP_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_READY_LAMP_BLINKING (3U)
 * COM_DT_HCU_HcuRdySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_HCU_not_Ready (0U)
 *   Cx1_HCU_Control_Board_Ready (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_HevRdySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_HEV_not_ready (0U)
 *   Cx1_HEV_Drivable (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_HevSysModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Vehicle_Stop (1U)
 *   Cx2_EV_Propulsion (2U)
 *   Cx3_Power_Assist (3U)
 *   Cx4_Engine_Only_Propulsion (4U)
 *   Cx5_Engine_Generation (5U)
 *   Cx6_Regeneration (6U)
 *   Cx7_Engine_Brake (7U)
 *   Cx8_Power_Researve (8U)
 *   Cx9_Engine_Generation_Motor_Drive (9U)
 *   CxA_Engine_Generation_Regeneration (10U)
 *   CxB_Engine_Brake_Regeneration (11U)
 * COM_DT_HCU_LdcInhbtReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_LDC_Off_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_LdcUnderVoltCtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_UVC_Off (0U)
 *   Cx1_UVC_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_LimpOffSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Limp_off_the_road (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_MILOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_request (0U)
 *   Cx1_MIL_On_Request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_NccAlrmInfoSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Manual_Resume (1U)
 *   Cx2_Automatic_Resume (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_HCU_PIFailFreezeReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_PaddleCstCtrlWrnMsgSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_SAC_Off_Popup_Request (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_HCU_PaddleStepCtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Paddle_Step_0 (0U)
 *   Cx1_Paddle_Step_1 (1U)
 *   Cx2_Paddle_Step_2 (2U)
 *   Cx3_Paddle_Step_3 (3U)
 *   Cx4_Paddle_Step_4 (4U)
 *   Cx5_reserve (5U)
 *   Cx6_reserve (6U)
 *   Cx7_default (7U)
 * COM_DT_HCU_PhevAutoModOnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AUTO_Mode_Off (0U)
 *   Cx1_AUTO_Mode_On (1U)
 * COM_DT_HCU_PhevDrvModClusterSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Charge_sustaining_CS_mode (0U)
 *   Cx1_Charge_depleting_CD_mode (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_PreFATCHysTempVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Temperature_0_deg (0U)
 *   Cx1_Temperature_1_deg (1U)
 *   Cx2_Temperature_2_deg (2U)
 *   Cx3_Temperature_3_deg (3U)
 * COM_DT_HCU_PreFATCOffstTempVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Temperature_0_deg (0U)
 *   Cx1_Temperature_1_deg (1U)
 *   Cx2_Temperature_2_deg (2U)
 *   Cx3_Temperature_3_deg (3U)
 * COM_DT_HCU_RspaAlvCntVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_counter (0U)
 *   Cx1_counter (1U)
 *   Cx2_counter (2U)
 *   Cx3_counter (3U)
 * COM_DT_HCU_SccDrvOvrdReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Override_clear (0U)
 *   Cx1_Override_set (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SccEnblSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_SCC_Impossible (0U)
 *   Cx1_SCC_Possible (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SchedChgEndDayVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Sun (0U)
 *   Cx1_Mon (1U)
 *   Cx2_Tue (2U)
 *   Cx3_Wed (3U)
 *   Cx4_Thu (4U)
 *   Cx5_Fri (5U)
 *   Cx6_Sat (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_HCU_SchedChgStrtDayVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Sun (0U)
 *   Cx1_Mon (1U)
 *   Cx2_Tue (2U)
 *   Cx3_Wed (3U)
 *   Cx4_Thu (4U)
 *   Cx5_Fri (5U)
 *   Cx6_Sat (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_HCU_SlwDnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Slowdown_state (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SmartRegen_MapEventUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disabled (1U)
 *   Cx2_Enabled (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HCU_SmartRegen_OnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_Manual_ (0U)
 *   Cx1_On_AUTO_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SmartRegen_UsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disabled (1U)
 *   Cx2_Enabled (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HCU_SmartRegen_VehHoldSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Vehicle_Hold_Off (0U)
 *   Cx1_Vehicle_Hold_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SmrtEcoGdDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SpdLimDeviceOperSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Speed_Limiter_Not_Operation (0U)
 *   Cx1_Speed_Limiter_Operation (1U)
 *   Cx2_Speed_Limiter_Standby (2U)
 *   Cx3_Error_Inicator (3U)
 * COM_DT_HCU_SrvLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Service_Lamp_On_Request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SrvModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_made (0U)
 *   Cx1_2WD_Test_mode (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_StrtInhbt2Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Start_Inhibit (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_StrtInhbtSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Start_Inhibit_state (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_SysShtOffReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_request (0U)
 *   Cx1_Request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HCU_VehStrtEnblSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Start_disable (0U)
 *   Cx1_Start_Enable (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDA_CntrlModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_System_OFF_Default_ (0U)
 *   Cx1_System_STANDBY (1U)
 *   Cx2_System_ACTIVE (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_HDA_LFA_SymSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Gray (1U)
 *   Cx2_Green (2U)
 *   Cx3_White_blink (3U)
 * COM_DT_HDA_LFA_WrnSnd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_ (0U)
 *   Cx1_Additional_Warning_Sound (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HDCT_AcnChrgInhbtReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ (0U)
 *   Cx1_Freeze_AC_clutch (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_CLUEngSpdFlag: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_CltchSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Open (0U)
 *   Cx1_Slip (1U)
 *   Cx2_Locked (2U)
 *   Cx3_Locked_Micro_Slip (3U)
 * COM_DT_HDCT_CtrlablSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Ready (0U)
 *   Cx1_Controllable (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_CurrPrgrm: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_SOS (0U)
 *   Cx01_ECO (1U)
 *   Cx02_DS (2U)
 *   Cx03_ECO_LD1 (3U)
 *   Cx04_ECO_LD2 (4U)
 *   Cx05_ECO_LD3 (5U)
 *   Cx06_ECO_LD1_HAT (6U)
 *   Cx07_ECO_LD2_HAT (7U)
 *   Cx08_ECO_LD3_HAT (8U)
 *   Cx09_DS_LD1 (9U)
 *   Cx0A_DS_LD2 (10U)
 *   Cx0B_DS_LD3 (11U)
 *   Cx0C_SOC_L (12U)
 *   Cx0D_SOC_N (13U)
 *   Cx0E_SOC_H (14U)
 *   Cx0F_Highway (15U)
 *   Cx10_ACC_NLD (16U)
 *   Cx11_ACC_LD1 (17U)
 *   Cx12_ACC_LD2 (18U)
 *   Cx13_ACC_LD3 (19U)
 *   Cx14_Manual (20U)
 *   Cx15_Manual_LD (21U)
 *   Cx16_CLT_PRT (22U)
 *   Cx17_TCS_NLD (23U)
 *   Cx18_TCS_LD (24U)
 *   Cx19_NORMAL (25U)
 *   Cx1A_ECO_DLD (26U)
 *   Cx1B_DS_DLD (27U)
 *   Cx1C_EVEN (28U)
 *   Cx1D_ODD (29U)
 *   Cx1E_CD_EV_Mode_ (30U)
 *   Cx1F_Reserve (31U)
 * COM_DT_HDCT_DblCltchSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_CS_Open (0U)
 *   Cx1_CS_TakeUp (1U)
 *   Cx2_CS_Engage (2U)
 *   Cx3_CS_Shift (3U)
 *   Cx4_CS_Drive (4U)
 *   Cx5_CS_Disengage (5U)
 *   Cx6_CS_SpinRequest (6U)
 *   Cx7_CS_TestMode (7U)
 *   Cx8_CS_Initialize (8U)
 *   Cx9_CS_Fail (9U)
 * COM_DT_HDCT_EOLReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_EOL_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_EngCltchLmphmMod: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_FuelCutReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Fuel_Cut_request (0U)
 *   Cx1_Activation_of_Fuel_Cut_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_GSITrgtGear: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Neutral_Initial_Value_ (0U)
 *   Cx1_1st_speed (1U)
 *   Cx2_2nd_speed (2U)
 *   Cx3_3rd_speed (3U)
 *   Cx4_4th_speed (4U)
 *   Cx5_5th_speed (5U)
 *   Cx6_6th_speed (6U)
 *   Cx7_Reserved (7U)
 *   Cx8_Reserved (8U)
 *   Cx9_Reserved (9U)
 *   CxA_Reserved (10U)
 *   CxB_Reserved (11U)
 *   CxC_Reserved (12U)
 *   CxD_Reserved (13U)
 *   CxE_Reserved (14U)
 *   CxF_Reserved (15U)
 * COM_DT_HDCT_GearShftSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_MCUAntJrkInhbt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Anti_jerk_not_inhibit (0U)
 *   Cx1_Anti_jerk_inhibit (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_NCoastDnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_NCoastTrgtGear: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_gN (0U)
 *   Cx1_g1 (1U)
 *   Cx2_g2 (2U)
 *   Cx3_g3 (3U)
 *   Cx4_g4 (4U)
 *   Cx5_g5 (5U)
 *   Cx6_g6 (6U)
 *   Cx7_None (7U)
 *   Cx8_None (8U)
 *   Cx9_None (9U)
 *   CxA_None (10U)
 *   CxB_None (11U)
 *   CxC_None (12U)
 *   CxD_None (13U)
 *   CxE_None (14U)
 *   CxF_gR (15U)
 * COM_DT_HDCT_NetrlCtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_complete (0U)
 *   Cx1_Complete (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_OBDErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_OBD_error (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_ShftPhase: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_No_shift (0U)
 *   Cx01_A0_Prepataion_for_shift_ (1U)
 *   Cx02_A1_Prepataion_for_shift_ (2U)
 *   Cx03_A2_Prepataion_for_shift_ (3U)
 *   Cx04_A3_Prepataion_for_shift_ (4U)
 *   Cx05_B1_Beginning_of_shift_ (5U)
 *   Cx06_B2_Beginning_of_shift_ (6U)
 *   Cx07_B3_Beginning_of_shift_ (7U)
 *   Cx08_B4_Beginning_of_shift_ (8U)
 *   Cx09_C1_Duration_of_actual_shift_ (9U)
 *   Cx0A_C2_Duration_of_actual_shift_ (10U)
 *   Cx0B_C3_Duration_of_actual_shift_ (11U)
 *   Cx0C_D1_Duration_of_actual_shift_ (12U)
 *   Cx0D_E1_Finishing_shift_ (13U)
 *   Cx0E_E2_Finishing_shift_ (14U)
 *   Cx0F_E3_Finishing_shift_ (15U)
 *   Cx10_END_Shift_End_ (16U)
 * COM_DT_HDCT_StcShftLrchCtrl: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_DR_or_RD_lurch_control (0U)
 *   Cx1_DR_lurch_control_active (1U)
 *   Cx2_RD_lurch_control_active (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_TCURdySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_ready (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_TqIncReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Passive (0U)
 *   Cx1_Torque_increase_controls (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HDCT_TrgtShftCls: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_static (0U)
 *   Cx01_Pon_UP (1U)
 *   Cx02_Poff_UP (2U)
 *   Cx03_reserve (3U)
 *   Cx04_Pon_DN (4U)
 *   Cx05_PoffDn_manual_ (5U)
 *   Cx06_NSTP_to_5_4_3_2 (6U)
 *   Cx07_NSTP_to_1 (7U)
 *   Cx08_reserve (8U)
 *   Cx09_reserve (9U)
 *   Cx0A_reserve (10U)
 *   Cx0B_reserve (11U)
 *   Cx0C_reserve (12U)
 *   Cx0D_reserve (13U)
 *   Cx0E_reserve (14U)
 * COM_DT_HDP_FailureMode: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Blockage (1U)
 *   Cx2_Failure (2U)
 * COM_DT_HEV_DrvCycActSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_driving_cycle_active (0U)
 *   Cx1_Driving_cycle_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_EngFulLoadSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Full_Load (0U)
 *   Cx1_Full_Load (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_EngOpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ES_Engine_Stop_ (0U)
 *   Cx1_ST_Start_ (1U)
 *   Cx2_IS_Idle_speed_ (2U)
 *   Cx3_PL_Part_Load_ (3U)
 *   Cx4_PU_Pull_ (4U)
 *   Cx5_PUC_Fuel_Cut_off_ (5U)
 * COM_DT_HEV_EngSpdErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_no_error (0U)
 *   Cx1_engine_speed_sensor_defective (1U)
 * COM_DT_HEV_EtcAppSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Fuel_Gasoline_ETC_No (0U)
 *   Cx1_Fuel_LPI_LPG_ETC_No (1U)
 *   Cx2_Fuel_Diesel_ETC_No (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Fuel_Gasoline_ETC_Applied (4U)
 *   Cx5_Fuel_LPI_LPG_ETC_Applied (5U)
 *   Cx6_Fuel_Diesel_ETC_Applied (6U)
 *   Cx7_GDI_type_engine (7U)
 * COM_DT_HEV_FirstFiringSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_firing (0U)
 *   Cx1_First_firing (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_FuelCutOffInhbtSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Permit (0U)
 *   Cx1_Inhibit (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_FuelCutOffSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Not_in_fuel_cut_off (0U)
 *   Cx1_Engine_in_fuel_cut_off (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_GPF_WrnLamp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_GPF_Normal_State (0U)
 *   Cx1_GPF_Warning_State_Level_1 (1U)
 *   Cx2_GPF_Warning_State_Level_2 (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_HEV_O2SnsrPreHeatSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_LSH_UP_preheating (0U)
 *   Cx1_LSH_UP_preheating_activated (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_RbmDrvCycSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_RBM_driving_cycle_completed (0U)
 *   Cx1_RBM_driving_cycle_completed (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HEV_VehSpdVal: Enumeration of integer in interval [0...255] with enumerators
 *   CxFF_Error_indicator (255U)
 * COM_DT_HEV_WarmupCycSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_warm_up_cycle_completed (0U)
 *   Cx1_Warm_up_cycle_completed (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_HTCU_CtrlablSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_ready (0U)
 *   Cx1_TCU_Controllable (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_FanCtrlReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Request (0U)
 *   Cx1_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_FsCltchLmphmActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_GearChgSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_GearShftDnDisGSI: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Gear_Shiftdown_Display_Off (0U)
 *   Cx1_Gear_Shiftdown_Display_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_GearShftUpDisGSI: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Gear_Shiftup_Display_Off (0U)
 *   Cx1_Gear_Shiftup_Display_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_PrgrmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_PR_NML (0U)
 *   Cx01_PR_MED (1U)
 *   Cx02_PR_SPTY (2U)
 *   Cx03_PR_LD1 (3U)
 *   Cx04_PR_LD2 (4U)
 *   Cx05_PR_LD3 (5U)
 *   Cx06_PR_DLD (6U)
 *   Cx07_PR_LD1_H (7U)
 *   Cx08_PR_LD2_H (8U)
 *   Cx09_PR_LD3_H (9U)
 *   Cx0A_PR_PRT (10U)
 *   Cx0B_PR_WRM_UP (11U)
 *   Cx0C_PR_BLUE (12U)
 *   Cx0D_PR_ECO_ATC (13U)
 *   Cx0E_PR_LD_ATC (14U)
 *   Cx0F_PR_LD_ATC_H (15U)
 *   Cx10_PR_HWY (16U)
 *   Cx11_PR_SOL_L (17U)
 *   Cx12_PR_SOL_M (18U)
 *   Cx13_PR_SOL_H (19U)
 *   Cx14_PR_REGEN (20U)
 *   Cx15_PR_TF_LO (21U)
 *   Cx16_PR_TCS (22U)
 *   Cx17_PR_LD_TCS (23U)
 *   Cx18_PR_DS (24U)
 *   Cx19_PR_EV_BLUE (25U)
 *   Cx1A_PR_EV_NML (26U)
 *   Cx1B_PR_EV_SOC_H (27U)
 *   Cx1C_PR_EV_SOC_L (28U)
 *   Cx1D_PR_EV_HWY (29U)
 *   Cx1E_PR_SOS (30U)
 *   Cx1F_PR_ECO_ATC_EV (31U)
 *   Cx20_PR_LD_ATC_EV (32U)
 *   Cx21_PR_LD_ATC_HI_EV (33U)
 *   Cx22_PR_LD2_ATC (34U)
 *   Cx23_PR_LD3_ATC (35U)
 *   Cx24_PR_LD2_ATC_H (36U)
 *   Cx25_PR_LD3_ATC_H (37U)
 *   Cx26_PR_EC_PRT (38U)
 * COM_DT_HTCU_RapidKDReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_RdySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_ready (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_SolBSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OFF (0U)
 *   Cx1_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HTCU_TrgtGearStaGSI: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ (0U)
 *   Cx1_1st_speed (1U)
 *   Cx2_2nd_speed (2U)
 *   Cx3_3rd_speed (3U)
 *   Cx4_4th_speed (4U)
 *   Cx5_5th_speed (5U)
 *   Cx6_6th_speed (6U)
 *   Cx7_ (7U)
 *   Cx8_ (8U)
 *   Cx9_ (9U)
 * COM_DT_HU_AliveStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Ready (0U)
 *   Cx1_On_Mode (1U)
 *   Cx2_Head_Unit_Update_Mode (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_DayNightState: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Day (1U)
 *   Cx2_Night (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_DistanceUnit: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Km (0U)
 *   Cx1_Mile (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_EVSupport: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_support (0U)
 *   Cx1_Support (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_MicActivity: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Deactivated (0U)
 *   Cx1_Activated (1U)
 *   Cx2_reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_MuteStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Mute_On (1U)
 *   Cx2_reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_NaviDisp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Non_Navi (0U)
 *   Cx1_Navi (1U)
 *   Cx2_reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_NaviHandshakingSupport: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Support (0U)
 *   Cx1_Support (1U)
 *   Cx2_Unknown (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_NaviMapInfo: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Korea (1U)
 *   Cx2_North_America (2U)
 *   Cx3_Europe (3U)
 *   Cx4_Middle_East (4U)
 *   Cx5_Australia (5U)
 *   Cx6_South_America (6U)
 *   Cx7_China (7U)
 *   Cx8_Russia (8U)
 *   Cx9_Turkey (9U)
 *   CxA_India (10U)
 *   CxB_Japan (11U)
 *   CxF_Invalid (15U)
 * COM_DT_HU_NaviStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Booting (0U)
 *   Cx1_Normal_Operation (1U)
 *   Cx2_No_SD_Card_Map_ (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_OptionInfo: Enumeration of integer in interval [0...65535] with enumerators
 *   Cx8000_Invalid (32768U)
 * COM_DT_HU_RTCCheck: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Ready (0U)
 *   Cx1_Checking (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_UsmSupport: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_support (0U)
 *   Cx1_Support (1U)
 *   Cx2_reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_HU_VolumeStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx3F_Invalid (63U)
 * COM_DT_HU_WelcomeReady: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_Haptic_USMCurState_OnOff: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_On (1U)
 *   Cx2_Off (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_HazardFromHUSVM: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_inactive (0U)
 *   Cx1_active (1U)
 *   Cx2_reserved (2U)
 *   Cx3_invalid (3U)
 * COM_DT_IAU_DigitalKeyEnblRVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_IAU_NFCCard1RegRVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_IAU_NFCCard2RegRVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_IAU_OwnerPhnRegRVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_IAUwFPMLearnState: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default_Normal_ (0U)
 *   Cx1_Learning (1U)
 *   Cx2_Neutralizing (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_IAUwFRULearnState: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default_Normal_ (0U)
 *   Cx1_Learning_ (1U)
 *   Cx2_Neutralizing (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_ActivityStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Calling (1U)
 *   Cx2_Smoking (2U)
 *   Cx3_Drinking (3U)
 *   Cx4_RESERVED1 (4U)
 *   Cx5_RESERVED2 (5U)
 *   Cx6_RESERVED3 (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_ICC_AoIStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_On_the_Road (1U)
 *   Cx2_Left_side_Mirror (2U)
 *   Cx3_Right_side_Mirror (3U)
 *   Cx4_Cluster (4U)
 *   Cx5_Avnt (5U)
 *   Cx6_Room_Mirror (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_ICC_DistLvlStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Level0 (0U)
 *   Cx1_Level1 (1U)
 *   Cx2_Level2 (2U)
 *   Cx3_Level3 (3U)
 *   Cx4_Level4 (4U)
 *   Cx5_Level5 (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_ICC_DrwsLvlStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Level0 (0U)
 *   Cx1_Level1 (1U)
 *   Cx2_Level2 (2U)
 *   Cx3_Level3 (3U)
 *   Cx4_Level4 (4U)
 *   Cx5_Level5 (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_ICC_EyeStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Opened (0U)
 *   Cx1_Closed (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_FaceDetectStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Not_detected (1U)
 *   Cx2_Detected (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_FaceFakeStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Real_Face (1U)
 *   Cx2_Fake_Face (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_IntvDrwsLvlStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_KSS_1_4_Alert_Rather_Alert_ (0U)
 *   Cx1_KSS_5_Neither_alert_nor_sleepy_ (1U)
 *   Cx2_KSS_6_Some_sign_of_sleepiness_ (2U)
 *   Cx3_KSS_7_over_Sleepy_ (3U)
 *   Cx4_Microsleep (4U)
 *   Cx5_Sleep (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_RESERVED (7U)
 * COM_DT_ICC_LeftEyeOpenStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Opened (0U)
 *   Cx1_Closed (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_RightEyeOpenStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Opened (0U)
 *   Cx1_Closed (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_TalkStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Talk (0U)
 *   Cx1_Talk (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICC_YawnStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Yawn (0U)
 *   Cx1_Yawn (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICU_HDPSpprtRdy: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_ADAS_Message_Not_Recognized (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_ICU_Haptic_OPT: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_No_option_None_Haptic_Option_ (1U)
 *   Cx2_Option (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ICU_MtGearPosRSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_IEB_AbsNGearReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_N_Gear_position_Request_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_BzrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Buzzer_is_Off (0U)
 *   Cx1_Buzzer_is_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_DfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AHB_is_normal_mode (0U)
 *   Cx1_AHB_is_degraded_mode (1U)
 *   Cx2_AHB_is_defective_mode (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_DiagSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AHB_is_not_diagnostic_mode (0U)
 *   Cx1_AHB_is_diagnostic_mode (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_DriftModeActSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Drift_Mode_ON (1U)
 *   Cx2_Drift_Mode_OFF (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_IEB_DriftModeSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Drift_Mode_Activate_ON_ (1U)
 *   Cx2_Drift_Mode_Deactivate_OFF_ (2U)
 *   Cx3_Defective (3U)
 * COM_DT_IEB_EstBrkPdlValVldSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Invalid (0U)
 *   Cx1_Valid (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_InhbtTrnstnTo4wd_Req: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Inhibit_Transition_To_4WD (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_used (3U)
 * COM_DT_IEB_MILReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_MIL_On_Request (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_IEB_PdlCalibSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_complete (0U)
 *   Cx1_Complete (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_PdlTrvlSnsrFailSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Fail (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_RSC_Req: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_RSC_is_not_active (0U)
 *   Cx1_RSC_is_active (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_IEB_RbsWrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_RBS_Warning_Lamp_OFF (0U)
 *   Cx1_RBS_Warning_Lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_SnsrFailSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Fail (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_VacSysDfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Vacuum_pump_NOT_defective (0U)
 *   Cx1_Vacuum_pump_defective_failed_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IEB_WrngLmpDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_AHB_Warning_Lamp_is_Off (0U)
 *   Cx1_AHB_Warning_Lamp_is_On (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IFSref_FR_CMR_Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_Option_Default_ (0U)
 *   Cx1_Normal (1U)
 *   Cx2_Blockage_Status (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IFSref_ILLAmbtSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Bright (0U)
 *   Cx1_Dark (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_IFSref_VehDst10Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst1Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst2Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst3Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst4Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst5Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst6Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst7Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst8Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IFSref_VehDst9Val: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Value (0U)
 *   Cx1_1_10m (1U)
 *   Cx2_11_20m (2U)
 *   Cx3_21_30m (3U)
 *   Cx4_31_40m (4U)
 *   Cx5_41_50m (5U)
 *   Cx6_51_60m (6U)
 *   Cx7_61_70m (7U)
 *   Cx8_71_80m (8U)
 *   Cx9_81_90m (9U)
 *   CxA_91_100m (10U)
 *   CxB_101_200m (11U)
 *   CxC_201_300m (12U)
 *   CxD_301_400m (13U)
 *   CxE_401m_ (14U)
 *   CxF_Error_indicator (15U)
 * COM_DT_IMT_DisCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Display (0U)
 *   Cx1_Display_Not_blinking_ (1U)
 *   Cx2_Display_blinking_ (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_ISLA_AutoSetSpdSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Auto_Set_Speed_Off (0U)
 *   Cx1_Auto_Set_Speed_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_ISLA_AutoUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_Auto_Function_Delete_Menu_ (0U)
 *   Cx1_Auto_Off (1U)
 *   Cx2_Auto_On (2U)
 *   Cx3_Invalid_GRAY_ (3U)
 * COM_DT_ISLA_NAOffstUSMSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_Offset_Function (0U)
 *   Cx1_10kph_or_10mph (1U)
 *   Cx2_5kph_or_5mph (2U)
 *   Cx3_0kph_or_0mph (3U)
 *   Cx4_5kph_or_5mph (4U)
 *   Cx5_10kph_or_10mph (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid_GRAY_ (7U)
 * COM_DT_ISLA_OffstUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_Offset_Function (0U)
 *   Cx1_10kph_or_5mph (1U)
 *   Cx2_5kph_or_3mph (2U)
 *   Cx3_0kph_or_0mph (3U)
 *   Cx4_5kph_or_3mph (4U)
 *   Cx5_10kph_or_5mph (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid_GRAY_ (7U)
 * COM_DT_ISLA_TSRSpdLimEnfrcmtSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Recognition_Default_ (0U)
 *   Cx1_Recognition (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_ISLW_OptUsmSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_ISLW_Option_Default_ (0U)
 *   Cx1_System_Disabled_by_USM (1U)
 *   Cx2_System_Enable_by_USM (2U)
 *   Cx3_Invalid_ (3U)
 * COM_DT_ISLW_OvrlpSignDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None_Default_ (0U)
 *   Cx1_Overlap_Sign (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_ISLW_SysSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_Default_ (0U)
 *   Cx1_System_Fail (1U)
 *   Cx2_ISLW_Temporary_Unavailable (2U)
 *   Cx3_Off (3U)
 * COM_DT_Info_LtLnDptSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Left_Line_Departure (0U)
 *   Cx1_Left_Line_Departure (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Info_RtLnDptSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Right_Line_Departure (0U)
 *   Cx1_Right_Line_Departure (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_IntLamp_InlTailLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_LKA_LHLnWrnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Warning (0U)
 *   Cx1_Lane_Departure_Warning (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Haptic_Warning_Display (3U)
 * COM_DT_LKA_OnOffEquip2Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_LKA_RHLnWrnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Warning (0U)
 *   Cx1_Lane_Departure_Warning (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Haptic_Warning_Display (3U)
 * COM_DT_LKA_SysIndReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Unavailable_Grey_On_ (1U)
 *   Cx2_Lane_Recognized_Green_On_ (2U)
 *   Cx3_Lane_Departure_Green_Blink_ (3U)
 *   Cx4_System_Fail_Orange_On_ (4U)
 *   Cx5_Not_Calibrated_Orange_Blink_ (5U)
 *   Cx6_Off_for_Regulation_Orange_On_ (6U)
 *   Cx7_Temp_Unavailable_Orange_On_ (7U)
 * COM_DT_LKA_WarnSndUSMSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_USM_Off (1U)
 *   Cx2_USM_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_Lamp_AvTailLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_BLEWlcmCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_BckUpLmpCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_CornerLmpLftOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Direct_Off (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_CornerLmpRtOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Direct_Off (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_DrlOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_ExtLampRSPAMode: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_ExtrnlTailLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_FrFogLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_FrFogLmpSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_HdLmpHiOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_HdLmpHiSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_HdLmpLoOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_HdLmpWlcmCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_HiPrioHzrdReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_High_On (1U)
 *   Cx2_High_Inactive (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reseved (5U)
 *   Cx6_Not_Used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_Lamp_IntTailLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_LaneChgTrnSigLftSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_LaneChgTrnSigLftSwSta_ICU: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_LaneChgTrnSigRtSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_LaneChgTrnSigRtSwSta_ICU: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_LoPrioHzrdReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Low_On (1U)
 *   Cx2_Low_Inactive (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reseved (5U)
 *   Cx6_Not_Used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_Lamp_LtSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Light_Sw_Off (0U)
 *   Cx1_Tail_Sw_On (1U)
 *   Cx2_HeadLamp_Low_Sw_On (2U)
 *   Cx3_AutoLight_Sw_On (3U)
 * COM_DT_Lamp_PassingLmpSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_PuddleLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_RrFogLmpOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_RrFogLmpSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_StcBendingLmpLftOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Direct_Off (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_StcBendingLmpRtOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Direct_Off (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Lamp_TrnSigLftSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_TrnSigLmpLftActiveSt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_Inactive_ (0U)
 *   Cx1_On_Active_ (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_Lamp_TrnSigLmpLftOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active_Off_Flasher_Off_ (1U)
 *   Cx2_Active_On_Flasher_On_ (2U)
 *   Cx3_reserved (3U)
 * COM_DT_Lamp_TrnSigLmpRtActiveSt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_Inactive_ (0U)
 *   Cx1_On_Active_ (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_Lamp_TrnSigLmpRtOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active_Off_Flasher_Off_ (1U)
 *   Cx2_Active_On_Flasher_On_ (2U)
 *   Cx3_reserved (3U)
 * COM_DT_Lamp_TrnSigRtSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Lamp_TrnSigSwNtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_MDPS_ADAS_AciFltSig: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Fault (0U)
 *   Cx1_MDPS_Fault (1U)
 *   Cx2_Fault_Except_MDPS (2U)
 *   Cx3_Both_Fault (3U)
 * COM_DT_MDPS_CurrModVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Comfort_Mode (0U)
 *   Cx1_Sport_Mode (1U)
 *   Cx2_Sport_Mode (2U)
 *   Cx3_Chauffeur_Mode (3U)
 *   Cx4_Mild_Mode (4U)
 *   Cx5_RESERVED (5U)
 *   Cx6_Not_Used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_MDPS_EngIdleRpmReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Current_Consumption_is_Low (0U)
 *   Cx1_Current_Consumption_is_High (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_LkaFailSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_in_fail_state (0U)
 *   Cx1_In_fail_state (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_LkaToiActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Deactivated (0U)
 *   Cx1_Activated (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_LkaToiFltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_fault (0U)
 *   Cx1_Faulty (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_LkaToiUnblSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Available (0U)
 *   Cx1_Unavailable (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_LoamModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Loam_Flag_Warning_Display (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_PaCanfltSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure (0U)
 *   Cx1_Failure_about_Pa_can_message (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_Typ: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_C_MDPS (0U)
 *   Cx1_R_MDPS_Dual_Pinion_ (1U)
 *   Cx2_R_MDPS_Belt_ (2U)
 *   Cx6_Not_Used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_MDPS_VsmActResp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_VSM_Control_inactivated (0U)
 *   Cx1_VSM_Control_Activated (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_MDPS_VsmDfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_MDPS_is_not_defective (0U)
 *   Cx1_MDPS_is_defective (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_MDPS_VsmSigErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_VSM1_signal_is_not_error (0U)
 *   Cx1_VSM_signal_is_error (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_META_V2_3_Country_OptADAS: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Support_Country (0U)
 *   Cx1_Support_Country (1U)
 *   Cx2_Unknown (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_META_V2_3_DrivingSide: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Driving_Side_Left (0U)
 *   Cx1_Driving_Side_Right (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_META_V2_3_MapProvider: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_HERE (1U)
 *   Cx2_TomTom (2U)
 *   Cx3_Zenrin (3U)
 *   Cx4_HMNS (4U)
 *   Cx5_Baidu (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_META_V2_3_SpeedUnit: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Kilometers_per_hour (0U)
 *   Cx1_Mile_per_hour (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_MSR_FuncReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Passive_or_TCS_function (0U)
 *   Cx1_MSR_control_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_OMUOSMirCtrl: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Fold (1U)
 *   Cx2_Unfold (2U)
 *   Cx3_invalid (3U)
 * COM_DT_OTAUIStatus: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Ready (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_POS_V2_3_CurrAltitude100m: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Unknown (0U)
 *   Cx01_Under100m (1U)
 *   Cx02_100m (2U)
 *   Cx03_200m (3U)
 *   Cx04_300m (4U)
 *   Cx05_400m (5U)
 *   Cx06_500m (6U)
 *   Cx07_600m (7U)
 *   Cx08_700m (8U)
 *   Cx09_800m (9U)
 *   Cx0A_900m (10U)
 *   Cx0B_1000m (11U)
 *   Cx0C_1100m (12U)
 *   Cx0D_1200m (13U)
 *   Cx0E_1300m (14U)
 *   Cx0F_1400m (15U)
 *   Cx10_1500m (16U)
 *   Cx11_1600m (17U)
 *   Cx12_1700m (18U)
 *   Cx13_1800m (19U)
 *   Cx14_1900m (20U)
 *   Cx15_2000m (21U)
 *   Cx16_2100m (22U)
 *   Cx17_2200m (23U)
 *   Cx18_2300m (24U)
 *   Cx19_2400m (25U)
 *   Cx1A_2500m (26U)
 *   Cx1B_2600m (27U)
 *   Cx1C_2700m (28U)
 *   Cx1D_2800m (29U)
 *   Cx1E_2900m (30U)
 *   Cx1F_3000m (31U)
 *   Cx20_3100m (32U)
 *   Cx21_3200m (33U)
 *   Cx22_3300m (34U)
 *   Cx23_3400m (35U)
 *   Cx24_3500m (36U)
 *   Cx25_3600m (37U)
 *   Cx26_3700m (38U)
 *   Cx27_3800m (39U)
 *   Cx28_3900m (40U)
 *   Cx29_4000m (41U)
 *   Cx2A_4100m (42U)
 *   Cx2B_4200m (43U)
 *   Cx2C_4300m (44U)
 *   Cx2D_4400m (45U)
 *   Cx2E_4500m (46U)
 *   Cx2F_4600m (47U)
 *   Cx30_4700m (48U)
 *   Cx31_4800m (49U)
 *   Cx32_4900m (50U)
 *   Cx33_5000m (51U)
 *   Cx34_5100m (52U)
 *   Cx35_5200m (53U)
 *   Cx36_5300m (54U)
 *   Cx37_5400m (55U)
 *   Cx38_5500m (56U)
 *   Cx39_5600m (57U)
 *   Cx3A_5700m (58U)
 *   Cx3B_5800m (59U)
 *   Cx3C_5900m (60U)
 *   Cx3D_6000m (61U)
 *   Cx3E_Over6_000m (62U)
 *   Cx3F_Invalid (63U)
 * COM_DT_POS_V2_3_CurrFuncRoadClass: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Freeway (1U)
 *   Cx2_Arterial_Cityfreeway_ (2U)
 *   Cx3_County (3U)
 *   Cx4_Collector (4U)
 *   Cx5_Local (5U)
 *   Cx6_Etc_ferry_unpaved_ (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_POS_V2_3_CurrSpeedLimit: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Unknown (0U)
 *   Cx01_Under_5kph_mph_ (1U)
 *   Cx02_7kph_mph_ (2U)
 *   Cx03_10kph_mph_ (3U)
 *   Cx04_15kph_mph_ (4U)
 *   Cx05_20kph_mph_ (5U)
 *   Cx06_25kph_mph_ (6U)
 *   Cx07_30kph_mph_ (7U)
 *   Cx08_35kph_mph_ (8U)
 *   Cx09_40kph_mph_ (9U)
 *   Cx0A_45kph_mph_ (10U)
 *   Cx0B_50kph_mph_ (11U)
 *   Cx0C_55kph_mph_ (12U)
 *   Cx0D_60kph_mph_ (13U)
 *   Cx0E_65kph_mph_ (14U)
 *   Cx0F_70kph_mph_ (15U)
 *   Cx10_75kph_mph_ (16U)
 *   Cx11_80kph_mph_ (17U)
 *   Cx12_85kph_mph_ (18U)
 *   Cx13_90kph_mph_ (19U)
 *   Cx14_95kph_mph_ (20U)
 *   Cx15_100kph_mph_ (21U)
 *   Cx16_105kph_mph_ (22U)
 *   Cx17_110kph_mph_ (23U)
 *   Cx18_115kph_mph_ (24U)
 *   Cx19_120kph_mph_ (25U)
 *   Cx1A_130kph_mph_ (26U)
 *   Cx1B_140kph_mph_ (27U)
 *   Cx1C_150kph_mph_ (28U)
 *   Cx1D_160kph_mph_ (29U)
 *   Cx1E_Unlimited (30U)
 *   Cx1F_Invalid (31U)
 * COM_DT_POS_V2_3_CurrTrafficSpeed: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Unknown (0U)
 *   Cx01_Under_5kph_mph_ (1U)
 *   Cx02_7kph_mph_ (2U)
 *   Cx03_10kph_mph_ (3U)
 *   Cx04_15kph_mph_ (4U)
 *   Cx05_20kph_mph_ (5U)
 *   Cx06_25kph_mph_ (6U)
 *   Cx07_30kph_mph_ (7U)
 *   Cx08_35kph_mph_ (8U)
 *   Cx09_40kph_mph_ (9U)
 *   Cx0A_45kph_mph_ (10U)
 *   Cx0B_50kph_mph_ (11U)
 *   Cx0C_55kph_mph_ (12U)
 *   Cx0D_60kph_mph_ (13U)
 *   Cx0E_65kph_mph_ (14U)
 *   Cx0F_70kph_mph_ (15U)
 *   Cx10_75kph_mph_ (16U)
 *   Cx11_80kph_mph_ (17U)
 *   Cx12_85kph_mph_ (18U)
 *   Cx13_90kph_mph_ (19U)
 *   Cx14_95kph_mph_ (20U)
 *   Cx15_100kph_mph_ (21U)
 *   Cx16_105kph_mph_ (22U)
 *   Cx17_110kph_mph_ (23U)
 *   Cx18_115kph_mph_ (24U)
 *   Cx19_120kph_mph_ (25U)
 *   Cx1A_130kph_mph_ (26U)
 *   Cx1B_140kph_mph_ (27U)
 *   Cx1C_150kph_mph_ (28U)
 *   Cx1D_160kph_mph_ (29U)
 *   Cx1E_Over160kph_mph_ (30U)
 *   Cx1F_Invalid (31U)
 * COM_DT_PROLONG_V2_3_Update: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_False (0U)
 *   Cx1_True (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_PRVECS_CodedSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_coded (0U)
 *   Cx1_Coded (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_indicator (3U)
 * COM_DT_PWI_STATE: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_nomarl (0U)
 *   Cx1_pad_wear (1U)
 *   Cx2_reserved (2U)
 *   Cx3_invaild_or_Error (3U)
 * COM_DT_RSPA_AddtnlAccelActv: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Active (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_RSPA_CrankingReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Init (0U)
 *   Cx1_to_RSPA_Remote_Cranking (1U)
 *   Cx2_to_Normal_Cranking (2U)
 *   Cx3_to_IG_OFF (3U)
 * COM_DT_RSPA_DccCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Soft_Brake (1U)
 *   Cx2_Hard_1_Brake (2U)
 *   Cx3_Hard_2_Brake (3U)
 * COM_DT_RSPA_EpbReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_release_request (1U)
 *   Cx2_normal_apply (2U)
 * COM_DT_RSPA_HdLmpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Initial_Inactive_ (0U)
 *   Cx1_HeadLamp_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_RSPA_IdOutWarnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Request (0U)
 *   Cx1_Change_Request (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_RSPA_LwrLtTypDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_init (0U)
 *   Cx1_Not_found (1U)
 *   Cx2_Reverse_perpendicular (2U)
 *   Cx3_Reverse_parallel (3U)
 *   Cx4_Reverse_diagonal (4U)
 *   Cx5_Forward_diagonal (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_RSPA_LwrRtTypDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_init (0U)
 *   Cx1_Not_found (1U)
 *   Cx2_Reverse_perpendicular (2U)
 *   Cx3_Reverse_parallel (3U)
 *   Cx4_Reverse_diagonal (4U)
 *   Cx5_Forward_diagonal (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_RSPA_OSMirFoldReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_OS_Mirror_Fold (1U)
 *   Cx2_OS_Mirror_Unfold (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_RSPA_Opt: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_RSPA_not_applied (0U)
 *   Cx1_RSPA_applied (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_RSPA_SelDevInfo: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_default (0U)
 *   Cx1_SmartPhone (1U)
 *   Cx2_Fob (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_RSPA_Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_RSPA_not_recognized (0U)
 *   Cx1_Init (1U)
 *   Cx2_New_Start (2U)
 *   Cx3_Ready_OK (3U)
 *   Cx4_Assist_Req (4U)
 *   Cx5_Assist_OK (5U)
 *   Cx6_Assist_Fail (6U)
 *   Cx7_Abort (7U)
 *   Cx8_Ready_Fail (8U)
 * COM_DT_RSPA_StopReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Stop_control_is_required (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_RSPA_TrgtGearSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Idle (0U)
 *   Cx1_P (1U)
 *   Cx2_R (2U)
 *   Cx3_N (3U)
 *   Cx4_D (4U)
 * COM_DT_RSPA_UppLtTypDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_init (0U)
 *   Cx1_Not_found (1U)
 *   Cx2_Reverse_perpendicular (2U)
 *   Cx3_Reverse_parallel (3U)
 *   Cx4_Reverse_diagonal (4U)
 *   Cx5_Forward_diagonal (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_RSPA_UppRtTypDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_init (0U)
 *   Cx1_Not_found (1U)
 *   Cx2_Reverse_perpendicular (2U)
 *   Cx3_Reverse_parallel (3U)
 *   Cx4_Reverse_diagonal (4U)
 *   Cx5_Forward_diagonal (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_SCC_BrkLtSwFlrDetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure_detected (0U)
 *   Cx1_Failure_detected (1U)
 * COM_DT_SCC_Char1Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Level_1 (1U)
 *   Cx2_Level_2 (2U)
 *   Cx3_Level_3 (3U)
 *   Cx4_Level_4 (4U)
 *   Cx5_Level_5 (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_SCC_Char3Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Level_1 (1U)
 *   Cx2_Level_2 (2U)
 *   Cx3_Level_3 (3U)
 *   Cx4_Level_4 (4U)
 *   Cx5_Level_5 (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_SCC_DrvOvrRidSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Driver_Override (0U)
 *   Cx1_Driver_Override (1U)
 * COM_DT_SCC_FuncFlrDetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure_detected (0U)
 *   Cx1_Failure_detected (1U)
 * COM_DT_SCC_ML_OnOffEquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid_Fail_ (3U)
 * COM_DT_SCC_OptTyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_SCC_is_not_equipped (0U)
 *   Cx1_SCC_is_equipped (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Not_Coded (3U)
 * COM_DT_SCC_ReqLimSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Limited_No_Limitation (1U)
 *   Cx2_Acceleration_Limited (2U)
 *   Cx3_Deceleration_Limited (3U)
 * COM_DT_SCC_SccFlrDetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure_detected (0U)
 *   Cx1_Failure_detected (1U)
 * COM_DT_SCC_SccOffStaDetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_switch_off_condition_detected (0U)
 *   Cx1_Switch_off_condition_detected (1U)
 * COM_DT_SCC_TqReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Enable_SCC_torque_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SCR_LvlWrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_Off (0U)
 *   Cx1_Lamp_ON_UREA_EMPTY_ (1U)
 * COM_DT_SCR_SysWrngLmpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Lamp_Off (0U)
 *   Cx1_Lamp_ON (1U)
 * COM_DT_SEG_V2_3_CalculatedRoute: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Calculated_Route_MPP_ (0U)
 *   Cx1_Part_of_Calculated_Route (1U)
 *   Cx2_Off_Route_or_Recalculating (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SEG_V2_3_DividedRoad: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Part_of_a_divided_road (0U)
 *   Cx1_Not_part_of_a_divided_road (1U)
 *   Cx2_Unknown (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SEG_V2_3_FuncRoadClass: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Freeway (1U)
 *   Cx2_Arterial_City_freeway_ (2U)
 *   Cx3_County (3U)
 *   Cx4_Collector (4U)
 *   Cx5_Local (5U)
 *   Cx6_Etc_ferry_unpaved_ (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_SEG_V2_3_Retransmission: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_False (0U)
 *   Cx1_True (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SEG_V2_3_SpeedLimit: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Unknown (0U)
 *   Cx01_Under_5kph_mph_ (1U)
 *   Cx02_7kph_mph_ (2U)
 *   Cx03_10kph_mph_ (3U)
 *   Cx04_15kph_mph_ (4U)
 *   Cx05_20kph_mph_ (5U)
 *   Cx06_25kph_mph_ (6U)
 *   Cx07_30kph_mph_ (7U)
 *   Cx08_35kph_mph_ (8U)
 *   Cx09_40kph_mph_ (9U)
 *   Cx0A_45kph_mph_ (10U)
 *   Cx0B_50kph_mph_ (11U)
 *   Cx0C_55kph_mph_ (12U)
 *   Cx0D_60kph_mph_ (13U)
 *   Cx0E_65kph_mph_ (14U)
 *   Cx0F_70kph_mph_ (15U)
 *   Cx10_75kph_mph_ (16U)
 *   Cx11_80kph_mph_ (17U)
 *   Cx12_85kph_mph_ (18U)
 *   Cx13_90kph_mph_ (19U)
 *   Cx14_95kph_mph_ (20U)
 *   Cx15_100kph_mph_ (21U)
 *   Cx16_105kph_mph_ (22U)
 *   Cx17_110kph_mph_ (23U)
 *   Cx18_115kph_mph_ (24U)
 *   Cx19_120kph_mph_ (25U)
 *   Cx1A_125kph_mph_ (26U)
 *   Cx1B_130kph_mph_ (27U)
 *   Cx1C_135kph_mph_ (28U)
 *   Cx1D_140kph_mph_ (29U)
 *   Cx1E_Unlimited (30U)
 *   Cx1F_Invalid (31U)
 * COM_DT_SMK_AccInSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ACC_OFF (0U)
 *   Cx1_ACC_ON (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_AccRlySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_AuthSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Auth (0U)
 *   Cx1_Preauthentication (1U)
 *   Cx2_Authentication (2U)
 *   Cx3_Fast_Restart (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reseved (5U)
 *   Cx6_Not_Used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_SMK_CLUAccIndOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Cluster_ACC_Indicator_Off (0U)
 *   Cx1_Cluster_ACC_Indicator_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_Ign1InSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_IGN1_Off (0U)
 *   Cx1_IGN1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_Ign1RlySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_Ign2InSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_IGN2_Off (0U)
 *   Cx1_IGN2_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_Ign2RlySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_RmtKeyCrnkModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_Mode (0U)
 *   Cx1_Remote_Key_Cranking_Mode (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_RmtKeyEngRunSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Remote_Key_Engine_Running (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_SCULckUnlckSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Lock (1U)
 *   Cx2_Unlock (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_StrtFdbckSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_StrtrRlyOutSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Starter_Relay_Output_Off (0U)
 *   Cx1_Starter_Relay_Output_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_TlCrnkModSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_Mode (0U)
 *   Cx1_Tele_Cranking_Mode (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_TlEngRunSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Tele_Engine_Running (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SMK_TrmnlMngrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Off (0U)
 *   Cx01_OFF_TO_START (1U)
 *   Cx02_WAIT_ESCL_UNLOCK_ACC (2U)
 *   Cx03_ACC (3U)
 *   Cx04_ACC_SEARCH (4U)
 *   Cx05_ACC_TO_START (5U)
 *   Cx06_IGN (6U)
 *   Cx07_IGN_SEARCH (7U)
 *   Cx08_WAIT_ESCL_UNLOCK_OFF_TO_START (8U)
 *   Cx09_WAIT_ESCL_UNLOCK_START (9U)
 *   Cx0A_WAIT_IGN1_ACC (10U)
 *   Cx0B_WAIT_IGN1_ACC_SEARCH (11U)
 *   Cx0C_WAIT_IGN1_ACC_TO_START (12U)
 *   Cx0D_WAIT_IGN1_UNLOCK_OFF_TO_START (13U)
 *   Cx0E_WAIT_IGN1_UNLOCK_START (14U)
 *   Cx0F_START (15U)
 *   Cx10_ENGINE_RUNNING (16U)
 *   Cx11_Reserved (17U)
 *   Cx12_Reserved (18U)
 *   Cx13_Reserved (19U)
 *   Cx14_Reserved (20U)
 *   Cx15_Reserved (21U)
 *   Cx16_Reserved (22U)
 *   Cx17_Reserved (23U)
 *   Cx18_Reserved (24U)
 *   Cx19_Reserved (25U)
 *   Cx1A_Reserved (26U)
 *   Cx1B_Reserved (27U)
 *   Cx1C_Reserved (28U)
 *   Cx1D_Reserved (29U)
 *   Cx1E_Not_Used (30U)
 *   Cx1F_Error_Indicator (31U)
 * COM_DT_SMK_VDModeActSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SSB_StrtStpBtnSw1Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Released (0U)
 *   Cx1_Pressed (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SSB_StrtStpBtnSw2Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Released (0U)
 *   Cx1_Pressed (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SWRC_CrsMainSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SWRC_HdpSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SWRC_Info: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_ON_CAN_Type_ (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_SWRC_LFASwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SWRC_PaddleDnSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SWRC_PaddleUpSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SWRC_SldMainSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Key_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_SunRoof_RrBlindErrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_error (0U)
 *   Cx1_Thermal_Protection_Active (1U)
 *   Cx2_Initialized_Status (2U)
 *   Cx3_Undefined_ECU_Error (3U)
 *   Cx4_Switch_Error (4U)
 *   Cx5_Voltage_error (5U)
 *   Cx6_Complex_Error (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_TCS_GearShftCharacteristicVal: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_passive_gear_change_allowed_ (0U)
 *   Cx1_active_gear_change_not_allowed_ (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCS_PreActvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ (0U)
 *   Cx1_Pre_TCS_Active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_BrkOnReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Brake_On_Request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_CdaInhbtReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_CDA_transition_is_available (0U)
 *   Cx1_TCU_prohibits_CDA_transition (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_CluTrgtGearConfg: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_TCU_TrgtGearSta (0U)
 *   Cx1_TCU_CluTrgtGearSta (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_DrvngModDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Normal (1U)
 *   Cx2_Eco (2U)
 *   Cx3_Eco_ (3U)
 *   Cx4_Sport (4U)
 *   Cx5_Sport_ (5U)
 *   Cx6_Snow (6U)
 *   Cx7_Reserved (7U)
 * COM_DT_TCU_DrvngModReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Inactive (0U)
 *   Cx1_Normal (1U)
 *   Cx2_Eco (2U)
 *   Cx3_Eco_ (3U)
 *   Cx4_Sport (4U)
 *   Cx5_Sport_ (5U)
 *   Cx6_Snow (6U)
 *   Cx7_Reserved (7U)
 * COM_DT_TCU_EngTqIncReqVal: Enumeration of integer in interval [-32768...32767] with enumerators
 *   Cx800_reduction_to_0_torque (-2048)
 *   Cx000_No_request (0)
 *   Cx7FF_Max_Increase (2047)
 * COM_DT_TCU_EngTqLimVal: Enumeration of integer in interval [-32768...32767] with enumerators
 *   Cx800_reduction_to_0_torque (-2048)
 *   Cx000_Max_reduction (0)
 *   Cx7FF_No_reduction (2047)
 * COM_DT_TCU_GearLmpBlnkngReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_blink (0U)
 *   Cx1_Request_lamp_blinking (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_GearShftSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_no_gear_change (0U)
 *   Cx1_gear_change_is_active (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_GearStepTyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx3_3_Speed_AT_or_DCT (3U)
 *   Cx4_4_Speed_AT_or_DCT (4U)
 *   Cx5_5_Speed_AT_or_DCT (5U)
 *   Cx6_6_Speed_AT_or_DCT (6U)
 *   Cx7_7_Speed_AT_or_DCT (7U)
 *   Cx8_8_Speed_AT_or_DCT (8U)
 * COM_DT_TCU_IdleUpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_IDLE_UP_request (0U)
 *   Cx1_IDLE_UP_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_IsgInhbtReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_TCU_inhibits_the_ISG_function (0U)
 *   Cx1_ISG_is_available (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_NetrlCtrlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_NC (0U)
 *   Cx1_NC_Entry (1U)
 *   Cx2_NC_Applied (2U)
 *   Cx3_NC_Exit (3U)
 * COM_DT_TCU_ShftPtrnSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal_ECO_ (0U)
 *   Cx1_Uphill_1_Optional_ (1U)
 *   Cx2_Uphill_2_Optional_ (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Downhill_1_Optional_ (4U)
 *   Cx5_Cruise_Optional_ (5U)
 *   Cx6_Cruise_Uphill_1_Optional_ (6U)
 *   Cx7_Cruise_Uphill_2_Optional_ (7U)
 *   Cx8_Active_ECO_Optional_ (8U)
 *   Cx9_Sport_Drive_Optional_ (9U)
 *   CxF_None_of_the_above (15U)
 * COM_DT_TCU_SmrtShftSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Smart_Shift_not_Applied (0U)
 *   Cx1_Smart_Shift_Applied (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_TCU_SprtyIndxSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_Invalid (0U)
 *   Cx01_Step_1 (1U)
 *   Cx02_Step_2 (2U)
 *   Cx03_Step_3 (3U)
 *   Cx04_Step_4 (4U)
 *   Cx05_Step_5 (5U)
 *   Cx06_Step_6 (6U)
 *   Cx07_Step_7 (7U)
 *   Cx08_Step_8 (8U)
 *   Cx09_Step_9 (9U)
 *   Cx0A_Step_10 (10U)
 *   Cx0B_Step_11 (11U)
 *   Cx0C_Step_12 (12U)
 *   Cx0D_Step_13 (13U)
 *   Cx0E_Step_14 (14U)
 *   Cx0F_Step_15 (15U)
 *   Cx10_Step_16 (16U)
 *   Cx11_Step_17 (17U)
 *   Cx12_Step_18 (18U)
 *   Cx13_Step_19 (19U)
 *   Cx14_Step_20 (20U)
 *   Cx15_Step_21 (21U)
 *   Cx16_Step_22 (22U)
 *   Cx17_Step_23 (23U)
 *   Cx18_Step_24 (24U)
 *   Cx19_Step_25 (25U)
 *   Cx1A_Invalid (26U)
 *   Cx1B_Invalid (27U)
 *   Cx1C_Invalid (28U)
 *   Cx1D_Invalid (29U)
 *   Cx1E_Invalid (30U)
 *   Cx1F_Invalid (31U)
 * COM_DT_TCU_TqCnvrtrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_lock_up_control (0U)
 *   Cx1_Slip_lock_up (1U)
 *   Cx2_Fully_lock_up (2U)
 *   Cx3_Off_slip_lock_up (3U)
 * COM_DT_TCU_TqRdctnVal: Enumeration of integer in interval [-32768...32767] with enumerators
 *   Cx800_reduction_to_0_torque (-2048)
 *   Cx000_Max_reduction (0)
 *   Cx7FF_No_reduction (2047)
 * COM_DT_TCU_Typ: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Reserved (0U)
 *   Cx1_Step_A (1U)
 *   Cx2_CVT (2U)
 *   Cx3_DCT (3U)
 *   Cx4_AMT (4U)
 *   Cx5_eClutch_2pedal_ (5U)
 *   Cx6_eClutch_3pedal_ (6U)
 * COM_DT_TCU_VehSpdKphVal: Enumeration of integer in interval [0...255] with enumerators
 *   CxFF_Error_Indicator (255U)
 * COM_DT_TrnLmpSeqEnblCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Reserved (3U)
 * COM_DT_USM_AdasBCA2SetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasBCWSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Warning (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasBCWSndSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasBVM2SetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default_ (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasDAWModNewSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasFCAFrSdSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasFCAFrSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default_NoneFCA_ (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasFCAJcSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasFCAJnctnSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasHDALCFuncSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasHDASetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Function_Off (1U)
 *   Cx2_Function_On (2U)
 *   Cx3_Invalid_Fail_ (3U)
 * COM_DT_USM_AdasHbaSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasISLAAutoSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Auto_off (1U)
 *   Cx2_Auto_on (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasISLAEUCntryTglReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_default (0U)
 *   Cx1_toggle (1U)
 *   Cx2_reserved (2U)
 *   Cx3_invalid (3U)
 * COM_DT_USM_AdasISLANACntryTglReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_toggle (1U)
 *   Cx2_reserved (2U)
 *   Cx3_invalid (3U)
 * COM_DT_USM_AdasISLANAOffstSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_10kph_10mph (1U)
 *   Cx2_5kph_5mph (2U)
 *   Cx3_0kph_0mph (3U)
 *   Cx4_5kph_5mph (4U)
 *   Cx5_10kph_10mph (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_AdasISLWSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasLFASetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Function_Off (1U)
 *   Cx2_Function_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasLKA2SetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasLKAWrngVolSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasLVDASetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasNSCCCamSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasNSCCCrvSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasPDWAutoOnSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasRCCWSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Warning (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSCCMLResetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Reset (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSCCModeSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Drive_mode (1U)
 *   Cx2_SCC_ML (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSEA3SetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSEASetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSEAnewSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Assist (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSEW3SetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSEWnewSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Warning (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasSVMAutoOnSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Disable_Off_ (1U)
 *   Cx2_Enable_On_ (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_AdasUSMResetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Reset (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_ChgGuideMdLvlSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_level_1 (1U)
 *   Cx2_level_2 (2U)
 *   Cx3_level_3 (3U)
 *   Cx4_level_4 (4U)
 *   Cx5_level_5 (5U)
 *   Cx6_Off (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_CluVcAlrmVolSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Level0_mute_ (1U)
 *   Cx2_Level1 (2U)
 *   Cx3_Level2 (3U)
 *   Cx4_Level3 (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_EngOilChaRstSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_reset (0U)
 *   Cx1_Reset_EngineOil_Life_Cycle_ (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_USM_FuelEconomySetSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Driving (2U)
 *   Cx3_Refuel (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_FuncForMdLmpBrgtSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default_Value (0U)
 *   Cx1_Off (1U)
 *   Cx2_step_1 (2U)
 *   Cx3_step_2 (3U)
 *   Cx4_step_3 (4U)
 *   Cx5_step_4 (5U)
 *   Cx6_reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_ISLAOffstSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_10kph_5mph (1U)
 *   Cx2_5kph_3mph (2U)
 *   Cx3_0 (3U)
 *   Cx4_5kph_3mph (4U)
 *   Cx5_10kph_5mph (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * COM_DT_USM_PABArbgNValueSetReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_PAB_Off (1U)
 *   Cx2_PAB_On (2U)
 *   Cx3_Invalid (3U)
 * COM_DT_Warn_AsstDrSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Close (0U)
 *   Cx1_Open (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_AsstStBltSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unbelted (0U)
 *   Cx1_Belted (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_BrkFldSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_DrvDrSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Close (0U)
 *   Cx1_Open (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_DrvStBltSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unbelted (0U)
 *   Cx1_Belted (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_HoodSwMemorySta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_event (0U)
 *   Cx1_hood_open_close (1U)
 *   Cx2_reserved (2U)
 *   Cx3_reserved (3U)
 * COM_DT_Warn_HoodSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_PassStOccSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off_UnSeated_ (0U)
 *   Cx1_On_Seated_ (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_PrkngBrkSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_RrCtrStBltSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unbelted (0U)
 *   Cx1_Belted (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_RrLftDrSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Close (0U)
 *   Cx1_Open (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_RrLftStBltSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unbelted (0U)
 *   Cx1_Belted (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_RrRtDrSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Close (0U)
 *   Cx1_Open (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_RrRtStBltSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unbelted (0U)
 *   Cx1_Belted (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Warn_WshrFldSwSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 * COM_DT_Wiper_AutoWashModeSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Auto_Wash_Mode_Off (0U)
 *   Cx1_Auto_Wash_Mode_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Wiper_HtWshNzzlCmd: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Wiper_PrkngPosSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_else (0U)
 *   Cx1_Parking_Position (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Wiper_RainSnsrOptionTyp: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Non_Rain_Sensor_Option (0U)
 *   Cx1_Rain_Sensor_Option (1U)
 *   Cx2_Not_Used (2U)
 *   Cx3_Error_Indicator (3U)
 * COM_DT_Wiper_RainSnsrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OFF (0U)
 *   Cx1_Rain_Detected (1U)
 *   Cx2_Low (2U)
 *   Cx3_High (3U)
 *   Cx4_Fault_1 (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Reserved (7U)
 *   Cx8_Reserved (8U)
 *   Cx9_Reserved (9U)
 *   CxA_Reserved (10U)
 *   CxB_Reserved (11U)
 *   CxC_Reserved (12U)
 *   CxD_Reserved (13U)
 *   CxE_Not_Used (14U)
 *   CxF_Error_Indicator (15U)
 * COM_DT_Wrn_Snd_AdasVolFdbck: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_level_1 (1U)
 *   Cx2_level_2 (2U)
 *   Cx3_level_3 (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Off (6U)
 *   Cx7_Invalid (7U)
 * EBD_DfctvSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_EBD_is_not_defective (0U)
 *   Cx1_EBD_is_defective (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * EBD_WrngLmpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_EBD_Warning_lamp_OFF (0U)
 *   Cx1_EBD_Warning_lamp_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * EM_WrngLvlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_warning (0U)
 *   Cx1_Prefill_Warning_level1_ (1U)
 *   Cx2_Partial_brake_Warning_level2_ (2U)
 *   Cx3_Full_brake_Warning_level3_ (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Error_indicator (7U)
 * ESC_BrkLtActSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Activate_brake_lights (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * FCA_FrOnOffEquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * FCA_FullActvReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Full_act (0U)
 *   Cx1_Full_act (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * FCA_HydrlcBstAsstReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Standard_threshold (0U)
 *   Cx1_Lowered_threshold_1 (1U)
 *   Cx2_Lowered_threshold_2 (2U)
 *   Cx3_Lowered_threshold_3 (3U)
 * FCA_OnOffEquipSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_Warning (2U)
 *   Cx3_Assist (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * FCA_PartialActvReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Partial_act (0U)
 *   Cx1_Partail_act_ (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * FCA_PrefillActvReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_pre_fill (0U)
 *   Cx1_Pre_fill_act (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * FCA_Regulation: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_warning (0U)
 *   Cx1_FCA_Amber_warning_on (1U)
 *   Cx2_FCA_Red_warning_blinking (2U)
 *   Cx3_Reserved (3U)
 * FCA_StbltActvReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_ReleaseNoalert (0U)
 *   Cx1_Pre_crash_full_retraction (1U)
 *   Cx2_Hapticwarning (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Reserved (7U)
 * FCA_SysFlrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Normal (0U)
 *   Cx1_Sensor_fusion (1U)
 *   Cx2_RadarorSensor_fusion (2U)
 *   Cx3_Service_Required (3U)
 *   Cx4_Camera_only (4U)
 *   Cx5_Sensor_fusion_in_ADAS_DRV (5U)
 *   Cx6_Sensor_fusion_in_Camera (6U)
 *   Cx7_Reserved (7U)
 * FCA_VehStpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Stop_control_is_required (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Error_Indicator (3U)
 * FCA_WarnTimeSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Late (1U)
 *   Cx2_Normal (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Invalid (7U)
 * FCA_WrngLvlSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_warning (0U)
 *   Cx1_Warning_level_1 (1U)
 *   Cx2_Warning_level_2 (2U)
 *   Cx3_Warning_level_3 (3U)
 * FCA_WrngSndSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_warning (0U)
 *   Cx1_Warning_1 (1U)
 *   Cx2_Warning_2 (2U)
 *   Cx3_Warning_3 (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Error_indicator (7U)
 * FCA_WrngTrgtDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx00_None (0U)
 *   Cx01_FCA_Pedestrian (1U)
 *   Cx02_Reserved (2U)
 *   Cx03_FCA_Cyclist (3U)
 *   Cx04_Reserved (4U)
 *   Cx05_FCA_Car (5U)
 *   Cx06_Reserved (6U)
 *   Cx07_FCA_JC_L_ (7U)
 *   Cx08_FCA_JC_R_ (8U)
 *   Cx09_Reserved (9U)
 *   Cx0A_Reserved (10U)
 *   Cx0B_FCA_JT_L_ (11U)
 *   Cx0C_FCA_JT_R_ (12U)
 *   Cx0D_Reserved (13U)
 *   Cx0E_Reserved (14U)
 * HDP_EMOpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On_Not_Active_ (1U)
 *   Cx2_On_Active_ (2U)
 *   Cx3_Reserved (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Error_indicator (7U)
 * ICC_CamBlckdStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Blockage (1U)
 *   Cx2_No_Blockage (2U)
 *   Cx3_Invalid (3U)
 * ICC_CamFailStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure (0U)
 *   Cx1_Camera_Failure (1U)
 *   Cx2_IR_LED_Failure (2U)
 *   Cx3_Invalid (3U)
 * ICC_EcuFailStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure (0U)
 *   Cx1_ECU_Failure (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_Invalid (3U)
 * ICC_OptUsmStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * ICC_ProfilingStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_InProgress (1U)
 *   Cx2_Pause (2U)
 *   Cx3_InUse (3U)
 *   Cx4_RESERVED (4U)
 *   Cx5_RESERVED (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * ICC_SymStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Init (1U)
 *   Cx2_Failure (2U)
 *   Cx3_Off (3U)
 *   Cx4_Ready (4U)
 *   Cx5_Active (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * ICC_UpdateStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Failure (0U)
 *   Cx1_Failure (1U)
 *   Cx2_RESERVED (2U)
 *   Cx3_RESERVED (3U)
 *   Cx4_RESERVED (4U)
 *   Cx5_RESERVED (5U)
 *   Cx6_RESERVED (6U)
 *   Cx7_Invalid (7U)
 * ICC_WarningStat: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Warning (0U)
 *   Cx1_Distraction_Warning (1U)
 *   Cx2_Drowsiness_Warning (2U)
 *   Cx3_RESERVED (3U)
 *   Cx4_RESERVED (4U)
 *   Cx5_Degradation_Warning (5U)
 *   Cx6_Blockage_Warning (6U)
 *   Cx7_Failure_Warning (7U)
 * Navi_ISLA_TImeZone: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Not_in_time_zone (1U)
 *   Cx2_In_time_zone (2U)
 *   Cx3_Invalid (3U)
 * Navi_ISLW_Frwinfo: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Entrance (1U)
 *   Cx2_Exit (2U)
 *   Cx3_Branch (3U)
 *   Cx4_Restarea (4U)
 *   Cx7_Invalid (7U)
 * Navi_ISLW_LinkClass: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Unknown (0U)
 *   Cx1_Freeway (1U)
 *   Cx2_IC (2U)
 *   Cx3_JC (3U)
 *   Cx4_Restarea (4U)
 *   Cx5_Arterial_Country (5U)
 *   Cx6_Roundabout (6U)
 *   Cx7_Invalid (7U)
 * Navi_ISLW_SpdUnit: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_KPH (1U)
 *   Cx2_MPH (2U)
 *   Cx3_Invalid (3U)
 * Navi_ISLW_TollExist: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Normal_Toll (1U)
 *   Cx2_Elect_Toll (2U)
 *   Cx3_Invalid (3U)
 * Navi_ISLW_TunnelExist: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_None (0U)
 *   Cx1_Exist (1U)
 *   Cx2_Reserved (2U)
 *   Cx3_Invalid (3U)
 * Nmode_FCAOff_Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_Applied (0U)
 *   Cx1_Disable (1U)
 *   Cx2_Enable (2U)
 *   Cx3_Invalid (3U)
 * NvM_RequestResultType: Enumeration of integer in interval [0...255] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 * SCC_MainOnOffSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_OFF (0U)
 *   Cx1_ON (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * SCC_NSCCOnOffSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Default (0U)
 *   Cx1_Off (1U)
 *   Cx2_On (2U)
 *   Cx3_Invalid (3U)
 * SCC_NSCCOpSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_Ready (1U)
 *   Cx2_Act (2U)
 *   Cx3_Error_Indicator (3U)
 * SCC_SysFlrSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_System_without_error (0U)
 *   Cx1_Performance_degredation (1U)
 *   Cx2_System_temporairy_unavailable (2U)
 *   Cx3_SCC_Service_Required (3U)
 * SCC_TakeoverReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_takeover_request (0U)
 *   Cx1_Takeover_request (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 * SCC_TrgtSpdSetVal: Enumeration of integer in interval [0...255] with enumerators
 *   CxFF_Error (255U)
 * SCC_VehStpReq: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_request (0U)
 *   Cx1_Stop_control_is_required (1U)
 *   Cx2_Not_used (2U)
 *   Cx3_Error_Indicator (3U)
 *
 * Array Types:
 * ============
 * COM_DT_IMU_SeralNumVal: Array with 6 element(s) of type uint8
 * HKMC_PartNumber_t: Array with 11 element(s) of type uint8
 * HW_Version_t: Array with 4 element(s) of type uint8
 * Reserved_2: Array with 2 element(s) of type uint8
 * Rte_DT_CVD_VehicleTrackWidths_0: Array with 5 element(s) of type Cvd_TrackWidthInput_t
 * SW_Version_t: Array with 4 element(s) of type uint8
 * Supplier_SW_Info_t: Array with 3 element(s) of type uint8
 *
 * Record Types:
 * =============
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * COM_DT_SG_ABS_ESC_01_10ms_SignalGroup: Record with elements
 *   ABS_ActvSta of type ABS_ActvSta
 *   ABS_DfctvSta of type ABS_DfctvSta
 *   ABS_DiagSta of type ABS_DiagSta
 *   ABS_ESC_AlvCnt1Val of type ABS_ESC_AlvCnt1Val
 *   ABS_ESC_Crc1Val of type ABS_ESC_Crc1Val
 *   ABS_WrngLmpSta of type ABS_WrngLmpSta
 *   BRK_AutoDrvBrkSta of type BRK_AutoDrvBrkSta
 *   EBD_DfctvSta of type EBD_DfctvSta
 *   EBD_WrngLmpSta of type EBD_WrngLmpSta
 *   ESC_BrkLtActSta of type ESC_BrkLtActSta
 *   ESS_Sta of type ESS_Sta
 * COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup: Record with elements
 *   ADAS_CMD_AlvCnt10Val of type ADAS_CMD_AlvCnt10Val_1
 *   ADAS_CMD_Crc10Val of type ADAS_CMD_Crc10Val_1
 *   FCA_DclReqVal of type FCA_DclReqVal_1
 *   FCA_FullActvReq of type FCA_FullActvReq
 *   FCA_HydrlcBstAsstReq of type FCA_HydrlcBstAsstReq
 *   FCA_PartialActvReq of type FCA_PartialActvReq
 *   FCA_PrefillActvReq of type FCA_PrefillActvReq
 *   FCA_RelVel of type FCA_RelVel_1
 *   FCA_StbltActvReq of type FCA_StbltActvReq
 *   FCA_SysFlrSta of type FCA_SysFlrSta
 *   FCA_TimetoCllsn of type FCA_TimetoCllsn_1
 *   FCA_VehStpReq of type FCA_VehStpReq
 *   FCA_WrngLvlSta of type FCA_WrngLvlSta
 *   FCA_WrngSndSta of type FCA_WrngSndSta
 *   FCA_WrngTrgtDis of type FCA_WrngTrgtDis
 *   ADAS_InhbtOffDispSta of type ADAS_InhbtOffDispSta
 *   ADAS_TrlOffStaDisp of type ADAS_TrlOffStaDisp
 *   EM_WrngLvlSta of type EM_WrngLvlSta
 *   FCA_FrOnOffEquipSta of type FCA_FrOnOffEquipSta
 *   FCA_Regulation of type FCA_Regulation
 *   FCA_WarnTimeSta of type FCA_WarnTimeSta
 *   HDP_EMOpSta of type HDP_EMOpSta
 *   Nmode_FCAOff_Sta of type Nmode_FCAOff_Sta
 *   FCA_OnOffEquipSta of type FCA_OnOffEquipSta
 * COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup: Record with elements
 *   ADAS_CMD_AlvCnt20Val of type ADAS_CMD_AlvCnt20Val
 *   ADAS_CMD_Crc20Val of type ADAS_CMD_Crc20Val
 *   SCC_AccelLimBandLwrVal of type SCC_AccelLimBandLwrVal
 *   SCC_AccelLimBandUppVal of type SCC_AccelLimBandUppVal
 *   SCC_AccelReqRawVal of type SCC_AccelReqRawVal
 *   SCC_AccelReqVal of type SCC_AccelReqVal
 *   SCC_DrvAlrtDis of type SCC_DrvAlrtDis
 *   SCC_EngStateReq of type SCC_EngStateReq
 *   SCC_HeadwayDstSetVal of type SCC_HeadwayDstSetVal
 *   SCC_InfoDis of type SCC_InfoDis
 *   SCC_JrkLwrLimVal of type SCC_JrkLwrLimVal
 *   SCC_JrkUppLimVal of type SCC_JrkUppLimVal
 *   SCC_MainOnOffSta of type SCC_MainOnOffSta
 *   SCC_NSCCInfoPUDis of type SCC_NSCCInfoPUDis
 *   SCC_NSCCOnOffSta of type SCC_NSCCOnOffSta
 *   SCC_NSCCOpSta of type SCC_NSCCOpSta
 *   SCC_ObjDstVal of type SCC_ObjDstVal
 *   SCC_ObjLatPosVal of type SCC_ObjLatPosVal
 *   SCC_ObjRelSpdVal of type SCC_ObjRelSpdVal
 *   SCC_ObjSta of type SCC_ObjSta
 *   SCC_OpSta of type SCC_OpSta
 *   SCC_SnstvtyModRetVal of type SCC_SnstvtyModRetVal
 *   SCC_SysFlrSta of type SCC_SysFlrSta
 *   SCC_TakeoverReq of type SCC_TakeoverReq
 *   SCC_TrgtDstVal of type SCC_TrgtDstVal
 *   SCC_TrgtSpdSetVal of type SCC_TrgtSpdSetVal
 *   SCC_VehStpReq of type SCC_VehStpReq
 *   ADAS_DrUnlckReqSta of type ADAS_DrUnlckReqSta
 *   ADAS_HzrdLmpReqVal of type ADAS_HzrdLmpReqVal
 *   NSCC_Op2Sta of type NSCC_Op2Sta
 * COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup: Record with elements
 *   ADAS_CMD_AlvCnt21Val of type COM_DT_ADAS_CMD_AlvCnt21Val
 *   ADAS_CMD_Crc21Val of type COM_DT_ADAS_CMD_Crc21Val
 *   SCC_Char1Sta of type COM_DT_SCC_Char1Sta
 *   SCC_Char2Sta of type COM_DT_SCC_Char2Sta
 *   SCC_Char3Sta of type COM_DT_SCC_Char3Sta
 *   SCC_ML_OnOffEquipSta of type COM_DT_SCC_ML_OnOffEquipSta
 * COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup: Record with elements
 *   ADAS_ActToiSta of type COM_DT_ADAS_ActToiSta
 *   ADAS_CMD_AlvCnt30Val of type COM_DT_ADAS_CMD_AlvCnt30Val
 *   ADAS_CMD_Crc30Val of type COM_DT_ADAS_CMD_Crc30Val
 *   ADAS_Damping_Gain of type COM_DT_ADAS_Damping_Gain
 *   ADAS_StrTqReqVal of type COM_DT_ADAS_StrTqReqVal
 *   ADAS_ToiFltSta of type COM_DT_ADAS_ToiFltSta
 *   LKA_HndsoffSnd of type COM_DT_LKA_HndsoffSnd
 *   LKA_LHLnWrnSta of type COM_DT_LKA_LHLnWrnSta
 *   LKA_RcgSta of type COM_DT_LKA_RcgSta
 *   LKA_RHLnWrnSta of type COM_DT_LKA_RHLnWrnSta
 *   LKA_SysIndReq of type COM_DT_LKA_SysIndReq
 *   LKA_SysWrn of type COM_DT_LKA_SysWrn
 *   BCA_Rear_WrnSta of type COM_DT_BCA_Rear_WrnSta
 *   ELK_SymbDisp of type COM_DT_ELK_SymbDisp
 *   ELK_SysFlrSta of type COM_DT_ELK_SysFlrSta
 *   FCA_ESA_CtrlSta of type COM_DT_FCA_ESA_CtrlSta
 *   FCA_ESA_WrnSta of type COM_DT_FCA_ESA_WrnSta
 *   FCA_LO_WrnSta of type COM_DT_FCA_LO_WrnSta
 *   FCA_LS_WrnSta of type COM_DT_FCA_LS_WrnSta
 *   LKA_OnOffEquip2Sta of type COM_DT_LKA_OnOffEquip2Sta
 *   LKA_WarnSndUSMSta of type COM_DT_LKA_WarnSndUSMSta
 * COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup: Record with elements
 *   ADAS_CMD_AlvCnt31Val of type COM_DT_ADAS_CMD_AlvCnt31Val
 *   ADAS_CMD_Crc31Val of type COM_DT_ADAS_CMD_Crc31Val
 *   HDA_CntrlModSta of type COM_DT_HDA_CntrlModSta
 *   HDA_InfoPUDis of type COM_DT_HDA_InfoPUDis
 *   HDA_InfoPUDis1 of type COM_DT_HDA_InfoPUDis1
 *   HDA_LFA_SymSta of type COM_DT_HDA_LFA_SymSta
 *   HDA_LFA_WrnSnd of type COM_DT_HDA_LFA_WrnSnd
 *   HDA_OptUsmSta of type COM_DT_HDA_OptUsmSta
 *   HDA_TDMRMDclReq of type COM_DT_HDA_TDMRMDclReq
 *   ADAS_DRV_UpDateInfo of type COM_DT_ADAS_DRV_UpDateInfo
 *   HDP_ActvSta of type COM_DT_HDP_ActvSta
 *   HDP_AutoCallReqSta of type COM_DT_HDP_AutoCallReqSta
 *   HDP_CtRoadSrfcDistVal of type COM_DT_HDP_CtRoadSrfcDistVal
 *   HDP_DispBarSta of type COM_DT_HDP_DispBarSta
 *   HDP_FailureMode of type COM_DT_HDP_FailureMode
 *   HDP_InhbtOffDispSta of type COM_DT_HDP_InhbtOffDispSta
 *   HDP_OptInfoSta of type COM_DT_HDP_OptInfoSta
 *   HDP_SysSta of type COM_DT_HDP_SysSta
 * COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup: Record with elements
 *   ADAS_ACIAnglTqRedcGainVal of type COM_DT_ADAS_ACIAnglTqRedcGainVal
 *   ADAS_ActvACILvl2Sta of type COM_DT_ADAS_ActvACILvl2Sta
 *   ADAS_ActvACISta of type COM_DT_ADAS_ActvACISta
 *   ADAS_CMD_AlvCnt35Val of type COM_DT_ADAS_CMD_AlvCnt35Val
 *   ADAS_CMD_Crc35Val of type COM_DT_ADAS_CMD_Crc35Val
 *   ADAS_StrAnglReqVal of type COM_DT_ADAS_StrAnglReqVal
 *   FCA_ESA_ActvSta of type COM_DT_FCA_ESA_ActvSta
 *   FCA_ESA_TqBstGainVal of type COM_DT_FCA_ESA_TqBstGainVal
 * COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup: Record with elements
 *   ADAS_INFO_AlvCnt1Val of type COM_DT_ADAS_INFO_AlvCnt1Val
 *   ADAS_INFO_Crc1Val of type COM_DT_ADAS_INFO_Crc1Val
 *   VAR_Opt1Sta of type COM_DT_VAR_Opt1Sta
 * COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup: Record with elements
 *   RSPA_Sta of type COM_DT_RSPA_Sta
 *   ADAS_PRK_AlvCnt3Val of type COM_DT_ADAS_PRK_AlvCnt3Val
 *   ADAS_PRK_Crc3Val of type COM_DT_ADAS_PRK_Crc3Val
 *   RSPA_Actv of type COM_DT_RSPA_Actv
 *   RSPA_AddtnlAccelActv of type COM_DT_RSPA_AddtnlAccelActv
 *   RSPA_AvnDis of type COM_DT_RSPA_AvnDis
 *   RSPA_AvnHmiDis of type COM_DT_RSPA_AvnHmiDis
 *   RSPA_AvnModDis of type COM_DT_RSPA_AvnModDis
 *   RSPA_AvnSubViewDis of type COM_DT_RSPA_AvnSubViewDis
 *   RSPA_CrankingReq of type COM_DT_RSPA_CrankingReq
 *   RSPA_DccCmd of type COM_DT_RSPA_DccCmd
 *   RSPA_DCTTrgtTqVal of type COM_DT_RSPA_DCTTrgtTqVal
 *   RSPA_EpbReq of type COM_DT_RSPA_EpbReq
 *   RSPA_EvasiveStrBtnDis of type COM_DT_RSPA_EvasiveStrBtnDis
 *   RSPA_ExtLampReq of type COM_DT_RSPA_ExtLampReq
 *   RSPA_HdLmpReq of type COM_DT_RSPA_HdLmpReq
 *   RSPA_IdOutWarnReq of type COM_DT_RSPA_IdOutWarnReq
 *   RSPA_IndBlnkReq of type COM_DT_RSPA_IndBlnkReq
 *   RSPA_LwrLtTypDis of type COM_DT_RSPA_LwrLtTypDis
 *   RSPA_LwrRtTypDis of type COM_DT_RSPA_LwrRtTypDis
 *   RSPA_Opt of type COM_DT_RSPA_Opt
 *   RSPA_OSMirFoldReq of type COM_DT_RSPA_OSMirFoldReq
 *   RSPA_RmtPrlExitDis of type COM_DT_RSPA_RmtPrlExitDis
 *   RSPA_SelDevInfo of type COM_DT_RSPA_SelDevInfo
 *   RSPA_SelFuncInfo of type COM_DT_RSPA_SelFuncInfo
 *   RSPA_StopReq of type COM_DT_RSPA_StopReq
 *   RSPA_SysOff of type COM_DT_RSPA_SysOff
 *   RSPA_TrgtGearSta of type COM_DT_RSPA_TrgtGearSta
 *   RSPA_TrgtTqVal of type COM_DT_RSPA_TrgtTqVal
 *   RSPA_TrgtVehSpdVal of type COM_DT_RSPA_TrgtVehSpdVal
 *   RSPA_UppLtTypDis of type COM_DT_RSPA_UppLtTypDis
 *   RSPA_UppRtTypDis of type COM_DT_RSPA_UppRtTypDis
 *   RSPA_Var of type COM_DT_RSPA_Var
 * COM_DT_SG_ADAS_UX_01_50ms_SignalGroup: Record with elements
 *   ADAS_UX_AlvCnt1Val of type COM_DT_ADAS_UX_AlvCnt1Val
 *   ADAS_UX_Crc1Val of type COM_DT_ADAS_UX_Crc1Val
 *   BG_HDP_Sta of type COM_DT_BG_HDP_Sta
 *   MV_CtRoadSrfcDstVal of type COM_DT_MV_CtRoadSrfcDstVal
 *   MV_CtRoadSrfcSta of type COM_DT_MV_CtRoadSrfcSta
 *   MV_DrvLnCtLnSta of type COM_DT_MV_DrvLnCtLnSta
 *   MV_DrvLnRdsVal of type COM_DT_MV_DrvLnRdsVal
 *   MV_FrLtObjMvngDirSta of type COM_DT_MV_FrLtObjMvngDirSta
 *   MV_FrLtRdrWaveSta of type COM_DT_MV_FrLtRdrWaveSta
 *   MV_FrRdrWaveSta of type COM_DT_MV_FrRdrWaveSta
 *   MV_FrRtObjMvngDirSta of type COM_DT_MV_FrRtObjMvngDirSta
 *   MV_FrRtRdrWaveSta of type COM_DT_MV_FrRtRdrWaveSta
 *   MV_HostVeh1Sta of type COM_DT_MV_HostVeh1Sta
 *   MV_LtLCDirSta of type COM_DT_MV_LtLCDirSta
 *   MV_LtLnOffstVal of type COM_DT_MV_LtLnOffstVal
 *   MV_LtLnSta of type COM_DT_MV_LtLnSta
 *   MV_LtRoadSrfcSta of type COM_DT_MV_LtRoadSrfcSta
 *   MV_RrLtRdrWave1Sta of type COM_DT_MV_RrLtRdrWave1Sta
 *   MV_RrRtRdrWave1Sta of type COM_DT_MV_RrRtRdrWave1Sta
 *   MV_RtLCDirSta of type COM_DT_MV_RtLCDirSta
 *   MV_RtLnOffstVal of type COM_DT_MV_RtLnOffstVal
 *   MV_RtLnSta of type COM_DT_MV_RtLnSta
 *   MV_RtRoadSrfcSta of type COM_DT_MV_RtRoadSrfcSta
 *   MV_VehDstSta of type COM_DT_MV_VehDstSta
 *   MV_VehDstVal of type COM_DT_MV_VehDstVal
 *   PU_F_Group1_ADASWarn1_1Sta of type COM_DT_PU_F_Group1_ADASWarn1_1Sta
 *   PU_F_Group1_ADASWarn1_2Sta of type COM_DT_PU_F_Group1_ADASWarn1_2Sta
 *   PU_F_Group4_ADASWarn1_1Sta of type COM_DT_PU_F_Group4_ADASWarn1_1Sta
 *   PU_M_Group2_ADASWarn1_1Sta of type COM_DT_PU_M_Group2_ADASWarn1_1Sta
 *   PU_M_Group2_ADASWarn1_2Sta of type COM_DT_PU_M_Group2_ADASWarn1_2Sta
 *   SMV_DrvAsstHUDSymbSta of type COM_DT_SMV_DrvAsstHUDSymbSta
 *   SMV_FrObjSta of type COM_DT_SMV_FrObjSta
 *   SMV_HDA_SymbSta of type COM_DT_SMV_HDA_SymbSta
 *   SMV_HostVehSta of type COM_DT_SMV_HostVehSta
 *   SMV_ISLA_SetSpdSymbSta of type COM_DT_SMV_ISLA_SetSpdSymbSta
 *   SMV_LCA_LtSymbSta of type COM_DT_SMV_LCA_LtSymbSta
 *   SMV_LCA_RtSymbSta of type COM_DT_SMV_LCA_RtSymbSta
 *   SMV_LFA_SymbSta of type COM_DT_SMV_LFA_SymbSta
 *   SMV_NSCC_SymbSta of type COM_DT_SMV_NSCC_SymbSta
 *   SMV_SetSpdSta of type COM_DT_SMV_SetSpdSta
 *   SMV_SetSpdVal of type COM_DT_SMV_SetSpdVal
 *   SMV_VehDstLvlSta of type COM_DT_SMV_VehDstLvlSta
 *   SMV_VehDstLvlVal of type COM_DT_SMV_VehDstLvlVal
 *   SND_ADASWarn1_1Sta of type COM_DT_SND_ADASWarn1_1Sta
 *   SND_ADASWarn1_2Sta of type COM_DT_SND_ADASWarn1_2Sta
 *   SND_ADASWarn1_3Sta of type COM_DT_SND_ADASWarn1_3Sta
 *   SND_ADASWarn1_4Sta of type COM_DT_SND_ADASWarn1_4Sta
 *   SND_ADASWarn1_5Sta of type COM_DT_SND_ADASWarn1_5Sta
 *   TT_DAW_SymbSta of type COM_DT_TT_DAW_SymbSta
 *   TT_EmergStrSymbSta of type COM_DT_TT_EmergStrSymbSta
 *   TT_FwdSftySymbSta of type COM_DT_TT_FwdSftySymbSta
 *   TT_HBA_SymbSta of type COM_DT_TT_HBA_SymbSta
 *   TT_LnSftySymbSta of type COM_DT_TT_LnSftySymbSta
 * COM_DT_SG_ADAS_UX_02_50ms_SignalGroup: Record with elements
 *   ADAS_UX_AlvCnt2Val of type COM_DT_ADAS_UX_AlvCnt2Val
 *   ADAS_UX_Crc2Val of type COM_DT_ADAS_UX_Crc2Val
 *   HPT_StbltWarn1Sta of type COM_DT_HPT_StbltWarn1Sta
 *   HPT_StrWhlWarn1Sta of type COM_DT_HPT_StrWhlWarn1Sta
 *   MV_FrLtObjLatPosVal of type COM_DT_MV_FrLtObjLatPosVal
 *   MV_FrLtObjLongPosVal of type COM_DT_MV_FrLtObjLongPosVal
 *   MV_FrLtObjSta of type COM_DT_MV_FrLtObjSta
 *   MV_FrObjLatPosVal of type COM_DT_MV_FrObjLatPosVal
 *   MV_FrObjLongPosVal of type COM_DT_MV_FrObjLongPosVal
 *   MV_FrObjSta of type COM_DT_MV_FrObjSta
 *   MV_FrObstLatPosVal of type COM_DT_MV_FrObstLatPosVal
 *   MV_FrObstLongPosVal of type COM_DT_MV_FrObstLongPosVal
 *   MV_FrObstSta of type COM_DT_MV_FrObstSta
 *   MV_FrRtObjLatPosVal of type COM_DT_MV_FrRtObjLatPosVal
 *   MV_FrRtObjLongPosVal of type COM_DT_MV_FrRtObjLongPosVal
 *   MV_FrRtObjSta of type COM_DT_MV_FrRtObjSta
 *   MV_LtObjLatPosVal of type COM_DT_MV_LtObjLatPosVal
 *   MV_LtObjLongPosVal of type COM_DT_MV_LtObjLongPosVal
 *   MV_LtObjSta of type COM_DT_MV_LtObjSta
 *   MV_RtObjLatPosVal of type COM_DT_MV_RtObjLatPosVal
 *   MV_RtObjLongPosVal of type COM_DT_MV_RtObjLongPosVal
 *   MV_RtObjSta of type COM_DT_MV_RtObjSta
 *   PU_F_Group7_DAW_FlrSta of type COM_DT_PU_F_Group7_DAW_FlrSta
 *   PU_F_Group7_DrvrAsstFlr1Sta of type COM_DT_PU_F_Group7_DrvrAsstFlr1Sta
 *   PU_F_Group7_FwdSdSftyFlrSta of type COM_DT_PU_F_Group7_FwdSdSftyFlrSta
 *   PU_F_Group7_FwdSftyFlrSta of type COM_DT_PU_F_Group7_FwdSftyFlrSta
 *   PU_F_Group7_HBA_FlrSta of type COM_DT_PU_F_Group7_HBA_FlrSta
 *   PU_F_Group7_HDA_FlrSta of type COM_DT_PU_F_Group7_HDA_FlrSta
 *   PU_F_Group7_HDP_FlrSta of type COM_DT_PU_F_Group7_HDP_FlrSta
 *   PU_F_Group7_ISLA_FlrSta of type COM_DT_PU_F_Group7_ISLA_FlrSta
 *   PU_F_Group7_LCA_FlrSta of type COM_DT_PU_F_Group7_LCA_FlrSta
 *   PU_F_Group7_LFA_FlrSta of type COM_DT_PU_F_Group7_LFA_FlrSta
 *   PU_F_Group7_LnSftyFlrSta of type COM_DT_PU_F_Group7_LnSftyFlrSta
 *   PU_F_Group7_MRM_FlrSta of type COM_DT_PU_F_Group7_MRM_FlrSta
 *   PU_F_Group7_SCC_FlrSta of type COM_DT_PU_F_Group7_SCC_FlrSta
 *   TT_ISLA_AddtnlTrffcSgnSta of type COM_DT_TT_ISLA_AddtnlTrffcSgnSta
 *   TT_ISLA_SpdLimTrffcSgnSta of type COM_DT_TT_ISLA_SpdLimTrffcSgnSta
 *   TT_ISLA_SpdLimTrffcSgnVal of type COM_DT_TT_ISLA_SpdLimTrffcSgnVal
 *   TT_ISLA_SuppTrffcSgnSta of type COM_DT_TT_ISLA_SuppTrffcSgnSta
 *   TT_ISLA_TrffcSgnCntryInfoSta of type COM_DT_TT_ISLA_TrffcSgnCntryInfoSta
 * COM_DT_SG_BCM_07_200ms_SignalGroup: Record with elements
 *   BCM_AlvCnt7Val of type COM_DT_BCM_AlvCnt7Val
 *   BCM_Crc7Val of type COM_DT_BCM_Crc7Val
 *   Lamp_AvTailLmpSta of type COM_DT_Lamp_AvTailLmpSta
 *   Lamp_BckUpLmpCmd of type COM_DT_Lamp_BckUpLmpCmd
 *   Lamp_DrlOnReq of type COM_DT_Lamp_DrlOnReq
 *   Lamp_ExtrnlTailLmpOnReq of type COM_DT_Lamp_ExtrnlTailLmpOnReq
 *   Lamp_HdLmpHiOnReq of type COM_DT_Lamp_HdLmpHiOnReq
 *   Lamp_HdLmpLoOnReq of type COM_DT_Lamp_HdLmpLoOnReq
 *   Lamp_HiPrioHzrdReq of type COM_DT_Lamp_HiPrioHzrdReq
 *   Lamp_IntTailLmpOnReq of type COM_DT_Lamp_IntTailLmpOnReq
 *   Lamp_LoPrioHzrdReq of type COM_DT_Lamp_LoPrioHzrdReq
 *   USM_IllAlwaysOnwithPSTNSta of type COM_DT_USM_IllAlwaysOnwithPSTNSta
 * COM_DT_SG_BCM_08_200ms_SignalGroup: Record with elements
 *   BCM_AlvCnt8Val of type COM_DT_BCM_AlvCnt8Val
 *   BCM_Crc8Val of type COM_DT_BCM_Crc8Val
 *   Lamp_HbaCtrlModTyp of type COM_DT_Lamp_HbaCtrlModTyp
 *   Lamp_BLEWelcomeSig of type COM_DT_Lamp_BLEWelcomeSig
 *   Lamp_BLEWlcmCmd of type COM_DT_Lamp_BLEWlcmCmd
 *   Lamp_CornerLmpLftOnReq of type COM_DT_Lamp_CornerLmpLftOnReq
 *   Lamp_CornerLmpRtOnReq of type COM_DT_Lamp_CornerLmpRtOnReq
 *   Lamp_ExtLampRSPAMode of type COM_DT_Lamp_ExtLampRSPAMode
 *   Lamp_FrFogLmpOnReq of type COM_DT_Lamp_FrFogLmpOnReq
 *   Lamp_HdLmpWlcmCmd of type COM_DT_Lamp_HdLmpWlcmCmd
 *   Lamp_IFSCtrlModTyp of type COM_DT_Lamp_IFSCtrlModTyp
 *   Lamp_PuddleLmpOnReq of type COM_DT_Lamp_PuddleLmpOnReq
 *   Lamp_RrFogLmpOnReq of type COM_DT_Lamp_RrFogLmpOnReq
 *   Lamp_StcBendingLmpLftOnReq of type COM_DT_Lamp_StcBendingLmpLftOnReq
 *   Lamp_StcBendingLmpRtOnReq of type COM_DT_Lamp_StcBendingLmpRtOnReq
 * COM_DT_SG_BCM_10_200ms_SignalGroup: Record with elements
 *   BCM_AlvCnt10Val of type COM_DT_BCM_AlvCnt10Val
 *   BCM_Crc10Val of type COM_DT_BCM_Crc10Val
 *   Wiper_PrkngPosSta of type COM_DT_Wiper_PrkngPosSta
 *   BCM_GearPosPSta of type COM_DT_BCM_GearPosPSta
 *   BCM_SolSnsrLft of type COM_DT_BCM_SolSnsrLft
 *   BCM_SolSnsrRt of type COM_DT_BCM_SolSnsrRt
 *   BCM_SunRoofOpnSta of type COM_DT_BCM_SunRoofOpnSta
 *   SunRoof_RrBlindErrSta of type COM_DT_SunRoof_RrBlindErrSta
 *   Wiper_AutoWashModeSta of type COM_DT_Wiper_AutoWashModeSta
 *   Wiper_HtWshNzzlCmd of type COM_DT_Wiper_HtWshNzzlCmd
 *   Wiper_RainSnsrOptionTyp of type COM_DT_Wiper_RainSnsrOptionTyp
 *   Wiper_RainSnsrPartNum of type COM_DT_Wiper_RainSnsrPartNum
 *   Wiper_RainSnsrSta of type COM_DT_Wiper_RainSnsrSta
 * COM_DT_SG_BCM_13_200ms_SignalGroup: Record with elements
 *   Haptic_USMCurState_OnOff of type COM_DT_Haptic_USMCurState_OnOff
 * COM_DT_SG_CLU_01_20ms_SignalGroup: Record with elements
 *   CLU_AlvCnt1Val of type COM_DT_CLU_AlvCnt1Val
 *   CLU_Crc1Val of type COM_DT_CLU_Crc1Val
 *   CLU_DisSpdVal of type COM_DT_CLU_DisSpdVal
 *   CLU_SpdUnitTyp of type COM_DT_CLU_SpdUnitTyp
 *   CLU_SWRCCrsMainSwSta of type COM_DT_CLU_SWRCCrsMainSwSta
 *   CLU_SWRCCrsSwSta of type COM_DT_CLU_SWRCCrsSwSta
 *   CLU_SWRCLFASwSta of type COM_DT_CLU_SWRCLFASwSta
 *   CLU_SWRCSldMainSwSta of type COM_DT_CLU_SWRCSldMainSwSta
 *   CLU_AutoBrightSta of type COM_DT_CLU_AutoBrightSta
 *   CLU_CUSTOMSta_NEW of type COM_DT_CLU_CUSTOMSta_NEW
 *   CLU_DisSpdDcmlVal of type COM_DT_CLU_DisSpdDcmlVal
 *   CLU_DisSpdVal_KPH of type COM_DT_CLU_DisSpdVal_KPH
 *   CLU_DtntOutSta of type COM_DT_CLU_DtntOutSta
 *   CLU_OKSwSta of type COM_DT_CLU_OKSwSta
 *   CLU_PwrAutoOffResetReq_HCU of type COM_DT_CLU_PwrAutoOffResetReq_HCU
 *   CLU_RhstaLvlSta of type COM_DT_CLU_RhstaLvlSta
 * COM_DT_SG_CLU_02_100ms_SignalGroup: Record with elements
 *   CLU_AlvCnt2Val of type COM_DT_CLU_AlvCnt2Val
 *   CLU_Crc2Val of type COM_DT_CLU_Crc2Val
 *   CLU_DrvngModSwSta of type COM_DT_CLU_DrvngModSwSta
 *   CLU_IceWrnIndSta of type COM_DT_CLU_IceWrnIndSta
 *   CLU_OdoVal of type COM_DT_CLU_OdoVal_1
 *   CLU_DTEVal of type COM_DT_CLU_DTEVal
 *   CLU_FuelLvlSta of type COM_DT_CLU_FuelLvlSta
 *   CLU_LngSta of type COM_DT_CLU_LngSta
 *   CLU_LoFuelWrngSta of type COM_DT_CLU_LoFuelWrngSta
 *   CLU_RefuelDetSta of type COM_DT_CLU_RefuelDetSta
 *   CLU_RefuelWrnSta of type COM_DT_CLU_RefuelWrnSta
 *   CLU_SRSWrngLmpSta of type COM_DT_CLU_SRSWrngLmpSta
 *   CLU_TerrainMainSwSta of type COM_DT_CLU_TerrainMainSwSta
 *   CLU_TerrainModSwSta of type COM_DT_CLU_TerrainModSwSta
 *   CLU_TripUnitSta of type COM_DT_CLU_TripUnitSta
 * COM_DT_SG_CLU_04_00ms_SignalGroup: Record with elements
 *   CLU_AlvCnt4Val of type COM_DT_CLU_AlvCnt4Val
 *   CLU_Crc4Val of type COM_DT_CLU_Crc4Val
 *   CLU_EngOilChngChkSetReq of type COM_DT_CLU_EngOilChngChkSetReq
 *   CLU_ISGoperationTimeRstReq of type COM_DT_CLU_ISGoperationTimeRstReq
 *   USM_AdasISLAAutoSetReq of type COM_DT_USM_AdasISLAAutoSetReq
 *   USM_AdasISLANAOffstSetReq of type COM_DT_USM_AdasISLANAOffstSetReq
 *   USM_AdasISLASetReq of type COM_DT_USM_AdasISLASetReq
 *   USM_AdasLKAWrngVolSetReq of type COM_DT_USM_AdasLKAWrngVolSetReq
 *   USM_AdasSEAnewSetReq of type COM_DT_USM_AdasSEAnewSetReq
 *   USM_AdasSEWnewSetReq of type COM_DT_USM_AdasSEWnewSetReq
 *   USM_ChgGuideMdLvlSetReq of type COM_DT_USM_ChgGuideMdLvlSetReq
 *   USM_EngOilChaRstSetReq of type COM_DT_USM_EngOilChaRstSetReq
 *   USM_ISLAOffstSetReq of type COM_DT_USM_ISLAOffstSetReq
 * COM_DT_SG_CLU_12_00ms_SignalGroup: Record with elements
 *   CLU_AlvCnt12Val of type COM_DT_CLU_AlvCnt12Val
 *   CLU_Crc12Val of type COM_DT_CLU_Crc12Val
 *   USM_AdasDAWModSetReq of type COM_DT_USM_AdasDAWModSetReq
 *   USM_AdasFCASetReq of type COM_DT_USM_AdasFCASetReq
 *   USM_AdasHDASetReq of type COM_DT_USM_AdasHDASetReq
 *   USM_AdasISLWSetReq of type COM_DT_USM_AdasISLWSetReq
 *   USM_AdasLVDASetReq of type COM_DT_USM_AdasLVDASetReq
 *   USM_AdasNSCCCamSetReq of type COM_DT_USM_AdasNSCCCamSetReq
 *   USM_AdasSCCDrvModSetReq of type COM_DT_USM_AdasSCCDrvModSetReq
 *   USM_AdasUSMResetReq of type COM_DT_USM_AdasUSMResetReq
 *   USM_AdasWrngTimingSetReq of type COM_DT_USM_AdasWrngTimingSetReq
 *   USM_AdasBCASetReq of type COM_DT_USM_AdasBCASetReq
 *   USM_AdasBCWSetReq of type COM_DT_USM_AdasBCWSetReq
 *   USM_AdasBVMSetReq of type COM_DT_USM_AdasBVMSetReq
 *   USM_AdasLFASetReq of type COM_DT_USM_AdasLFASetReq
 *   USM_AdasNSCCCrvSetReq of type COM_DT_USM_AdasNSCCCrvSetReq
 *   USM_AdasRCCANSetReq of type COM_DT_USM_AdasRCCANSetReq
 *   USM_AdasSEASetReq of type COM_DT_USM_AdasSEASetReq
 * COM_DT_SG_CLU_13_00ms_SignalGroup: Record with elements
 *   CLU_AdasDAWResetReq of type COM_DT_CLU_AdasDAWResetReq
 *   CLU_AlvCnt13Val of type COM_DT_CLU_AlvCnt13Val
 *   CLU_Crc13Val of type COM_DT_CLU_Crc13Val
 *   USM_AdasDAWModNewSetReq of type COM_DT_USM_AdasDAWModNewSetReq
 *   USM_AdasHbaSetReq of type COM_DT_USM_AdasHbaSetReq
 *   USM_AdasLkaModSetReq of type COM_DT_USM_AdasLkaModSetReq
 *   USM_AdasBCWSndSetReq of type COM_DT_USM_AdasBCWSndSetReq
 *   USM_AdasFCAJnctnSetReq of type COM_DT_USM_AdasFCAJnctnSetReq
 *   USM_AdasHDALCFuncSetReq of type COM_DT_USM_AdasHDALCFuncSetReq
 *   USM_AdasHptWrngSetReq of type COM_DT_USM_AdasHptWrngSetReq
 *   USM_AdasPCA_RrStaSetReq of type COM_DT_USM_AdasPCA_RrStaSetReq
 *   USM_AdasPDWAutoOnSetReq of type COM_DT_USM_AdasPDWAutoOnSetReq
 *   USM_AdasRCCWSetReq of type COM_DT_USM_AdasRCCWSetReq
 *   USM_AdasSCCMLChar1SetReq of type COM_DT_USM_AdasSCCMLChar1SetReq
 *   USM_AdasSCCMLChar2SetReq of type COM_DT_USM_AdasSCCMLChar2SetReq
 *   USM_AdasSCCMLChar3SetReq of type COM_DT_USM_AdasSCCMLChar3SetReq
 *   USM_AdasSCCMLResetReq of type COM_DT_USM_AdasSCCMLResetReq
 *   USM_AdasSCCModeSetReq of type COM_DT_USM_AdasSCCModeSetReq
 *   USM_AdasSVMAutoOnSetReq of type COM_DT_USM_AdasSVMAutoOnSetReq
 * COM_DT_SG_CLU_14_200ms_SignalGroup: Record with elements
 *   CLU_AdasWarnSndStat of type COM_DT_CLU_AdasWarnSndStat
 *   CLU_AlvCnt14Val of type COM_DT_CLU_AlvCnt14Val
 *   CLU_Crc14Val of type COM_DT_CLU_Crc14Val
 *   USM_Clu3dDepthSta of type COM_DT_USM_Clu3dDepthSta
 *   USM_CluAdasVolSta of type COM_DT_USM_CluAdasVolSta
 *   USM_CluFuelEconomySta of type COM_DT_USM_CluFuelEconomySta
 *   USM_CluVcAlrmVolSta of type COM_DT_USM_CluVcAlrmVolSta
 *   USM_FuelEconomySetSta of type COM_DT_USM_FuelEconomySetSta
 *   Wrn_Snd_AdasVolFdbck of type COM_DT_Wrn_Snd_AdasVolFdbck
 * COM_DT_SG_CLU_25_00ms_SignalGroup: Record with elements
 *   CLU_AlvCnt25Val of type COM_DT_CLU_AlvCnt25Val
 *   CLU_Crc25Val of type COM_DT_CLU_Crc25Val
 *   USM_AdasBCA2SetReq of type COM_DT_USM_AdasBCA2SetReq
 *   USM_AdasBVM2SetReq of type COM_DT_USM_AdasBVM2SetReq
 *   USM_AdasFCAFrSdSetReq of type COM_DT_USM_AdasFCAFrSdSetReq
 *   USM_AdasFCAFrSetReq of type COM_DT_USM_AdasFCAFrSetReq
 *   USM_AdasFCAJcSetReq of type COM_DT_USM_AdasFCAJcSetReq
 *   USM_AdasISLAEUCntry1SetReq of type COM_DT_USM_AdasISLAEUCntry1SetReq
 *   USM_AdasISLAEUCntryTglReq of type COM_DT_USM_AdasISLAEUCntryTglReq
 *   USM_AdasISLANACntry1SetReq of type COM_DT_USM_AdasISLANACntry1SetReq
 *   USM_AdasISLANACntryTglReq of type COM_DT_USM_AdasISLANACntryTglReq
 *   USM_AdasLKA2SetReq of type COM_DT_USM_AdasLKA2SetReq
 *   USM_AdasSEA3SetReq of type COM_DT_USM_AdasSEA3SetReq
 *   USM_AdasSEW3SetReq of type COM_DT_USM_AdasSEW3SetReq
 *   USM_AdasWarnTimeSetReq of type COM_DT_USM_AdasWarnTimeSetReq
 *   USM_AutoDrLkSetReq2 of type COM_DT_USM_AutoDrLkSetReq2
 *   USM_PABArbgNValueSetReq of type COM_DT_USM_PABArbgNValueSetReq
 * COM_DT_SG_CTM_01_200ms_SignalGroup: Record with elements
 *   CTM_Exra_EbrakSta of type COM_DT_CTM_Exra_EbrakSta
 *   CTM_ExtTailLmpLftOpnSta of type COM_DT_CTM_ExtTailLmpLftOpnSta
 *   CTM_ExtTailLmpRtOpnSta of type COM_DT_CTM_ExtTailLmpRtOpnSta
 *   CTM_RearfogAct of type COM_DT_CTM_RearfogAct
 *   CTM_StpLmpOpnSta of type COM_DT_CTM_StpLmpOpnSta
 *   CTM_TrailerAct of type COM_DT_CTM_TrailerAct
 *   CTM_TrnSigLmpLftOpnSta of type COM_DT_CTM_TrnSigLmpLftOpnSta
 *   CTM_TrnSigLmpRtOpnSta of type COM_DT_CTM_TrnSigLmpRtOpnSta
 * COM_DT_SG_DATC_17_200ms_SignalGroup: Record with elements
 *   DATC_OutTempDispC of type COM_DT_DATC_OutTempDispC
 *   DATC_OutTempDispF of type COM_DT_DATC_OutTempDispF
 * COM_DT_SG_EMS_01_10ms_SignalGroup: Record with elements
 *   ENG_EngSpdErrSta of type COM_DT_ENG_EngSpdErrSta
 *   ENG_EngSpdVal of type COM_DT_ENG_EngSpdVal
 *   ENG_IsgSta of type COM_DT_ENG_IsgSta
 *   ENG_SldSwSta of type COM_DT_ENG_SldSwSta
 *   ENG_SldFuncSta of type COM_DT_ENG_SldFuncSta
 *   ENG_VehSpdLimVal of type COM_DT_ENG_VehSpdLimVal
 *   EMS_AlvCnt1Val of type COM_DT_EMS_AlvCnt1Val
 *   EMS_Crc1Val of type COM_DT_EMS_Crc1Val
 *   ENG_Ack4TcsSta of type COM_DT_ENG_Ack4TcsSta
 *   ENG_AirCompRlySta of type COM_DT_ENG_AirCompRlySta
 *   ENG_AirconPrsrSnsrVal of type COM_DT_ENG_AirconPrsrSnsrVal
 *   ENG_CrctEngTqVal of type COM_DT_ENG_CrctEngTqVal
 *   ENG_CrctTqSta of type COM_DT_ENG_CrctTqSta
 *   ENG_DsrGearPosDis of type COM_DT_ENG_DsrGearPosDis
 *   ENG_EcoDrvActvSta of type COM_DT_ENG_EcoDrvActvSta
 *   ENG_EngInhbNCC of type COM_DT_ENG_EngInhbNCC
 *   ENG_EngRunSta of type COM_DT_ENG_EngRunSta
 *   ENG_EtcLmphModSta of type COM_DT_ENG_EtcLmphModSta
 *   ENG_FrctTqVal of type COM_DT_ENG_FrctTqVal
 *   ENG_FuelCapOpnSta of type COM_DT_ENG_FuelCapOpnSta
 *   ENG_FuelCnsmptVal of type COM_DT_ENG_FuelCnsmptVal
 *   ENG_FuelCutOffSta of type COM_DT_ENG_FuelCutOffSta
 *   ENG_FuelTnkPrsrSta of type COM_DT_ENG_FuelTnkPrsrSta
 *   ENG_GearShftDnDis of type COM_DT_ENG_GearShftDnDis
 *   ENG_GearShftUpDis of type COM_DT_ENG_GearShftUpDis
 *   ENG_IgnOnSta of type COM_DT_ENG_IgnOnSta
 *   ENG_IndTqBVal of type COM_DT_ENG_IndTqBVal
 *   ENG_IndTqVal of type COM_DT_ENG_IndTqVal
 *   ENG_Isg2Sta of type COM_DT_ENG_Isg2Sta
 *   ENG_IsgBzrReq of type COM_DT_ENG_IsgBzrReq
 *   ENG_IsgFuelCnsmptDis of type COM_DT_ENG_IsgFuelCnsmptDis
 *   ENG_LnchCntrlSta of type COM_DT_ENG_LnchCntrlSta
 *   ENG_MafErrSta of type COM_DT_ENG_MafErrSta
 *   ENG_MaxAirconTqVal of type COM_DT_ENG_MaxAirconTqVal
 *   ENG_OilLvlSta of type COM_DT_ENG_OilLvlSta
 *   ENG_SldActnSta of type COM_DT_ENG_SldActnSta
 *   ENG_SldDrvAlertDisp of type COM_DT_ENG_SldDrvAlertDisp
 *   ENG_SpltInjctnSta of type COM_DT_ENG_SpltInjctnSta
 *   ENG_StndTqRatioVal of type COM_DT_ENG_StndTqRatioVal
 *   ENG_TrgtFuelPmpPrsrVal of type COM_DT_ENG_TrgtFuelPmpPrsrVal
 *   ENG_TrgtIdleRpmVal of type COM_DT_ENG_TrgtIdleRpmVal
 *   ENG_VehSpdHiVal of type COM_DT_ENG_VehSpdHiVal
 * COM_DT_SG_EMS_02_10ms_SignalGroup: Record with elements
 *   EMS_AlvCnt2Val of type COM_DT_EMS_AlvCnt2Val
 *   EMS_Crc2Val of type COM_DT_EMS_Crc2Val
 *   ENG_AccActSta of type COM_DT_ENG_AccActSta
 *   ENG_AccelPdlVal of type COM_DT_ENG_AccelPdlVal
 *   ENG_AppAccelPdlSta of type COM_DT_ENG_AppAccelPdlSta
 *   ENG_EngSta of type COM_DT_ENG_EngSta
 *   ACC_CrsMainSwLmpSta of type COM_DT_ACC_CrsMainSwLmpSta
 *   ACC_CrsSetSwLmpSta of type COM_DT_ACC_CrsSetSwLmpSta
 *   ACC_DnShftCtrlReq of type COM_DT_ACC_DnShftCtrlReq
 *   DSL_GlowCtrlReq of type COM_DT_DSL_GlowCtrlReq
 *   EMS_BrkReq_Slope of type COM_DT_EMS_BrkReq_Slope
 *   ENG_AccDrvAlertDisp of type COM_DT_ENG_AccDrvAlertDisp
 *   ENG_Ack4EngStpSta of type COM_DT_ENG_Ack4EngStpSta
 *   ENG_AmbtTempModelVal of type COM_DT_ENG_AmbtTempModelVal
 *   ENG_BattDscnctSta of type COM_DT_ENG_BattDscnctSta
 *   ENG_BattWrngLmpSta of type COM_DT_ENG_BattWrngLmpSta
 *   ENG_BrkCtrlReq of type COM_DT_ENG_BrkCtrlReq
 *   ENG_BrkSwSta of type COM_DT_ENG_BrkSwSta
 *   ENG_BstPrsrVal of type COM_DT_ENG_BstPrsrVal
 *   ENG_CltchOpSta of type COM_DT_ENG_CltchOpSta
 *   ENG_DclBrkCntrlReq of type COM_DT_ENG_DclBrkCntrlReq
 *   ENG_DpfWrngSta of type COM_DT_ENG_DpfWrngSta
 *   ENG_EngClntTempVal of type COM_DT_ENG_EngClntTempVal
 *   ENG_EngOilTempVal of type COM_DT_ENG_EngOilTempVal
 *   ENG_GlowLmpSta of type COM_DT_ENG_GlowLmpSta
 *   ENG_IsgInhbtLmpSta of type COM_DT_ENG_IsgInhbtLmpSta
 *   ENG_LV_FUP_ENA_THD of type COM_DT_ENG_LV_FUP_ENA_THD
 *   ENG_MafCrctVal of type COM_DT_ENG_MafCrctVal
 *   ENG_MaxIndTqVal of type COM_DT_ENG_MaxIndTqVal
 *   ENG_MinIndTqVal of type COM_DT_ENG_MinIndTqVal
 *   ENG_ObdFrzFrmSta of type COM_DT_ENG_ObdFrzFrmSta
 *   ENG_OilPrsrWrngLmpSta of type COM_DT_ENG_OilPrsrWrngLmpSta
 *   ENG_OverDrvOffReq of type COM_DT_ENG_OverDrvOffReq
 *   ENG_SoakTimeErrSta of type COM_DT_ENG_SoakTimeErrSta
 *   ENG_SoakTimeVal of type COM_DT_ENG_SoakTimeVal
 *   ENG_SprkTimeVal of type COM_DT_ENG_SprkTimeVal
 *   ENG_ThrPosVal of type COM_DT_ENG_ThrPosVal
 *   ENG_TrgtTqVal of type COM_DT_ENG_TrgtTqVal
 *   OBD_MilConfgVal of type COM_DT_OBD_MilConfgVal
 * COM_DT_SG_EMS_03_10ms_SignalGroup: Record with elements
 *   CF_ECU_SSC_STAT of type COM_DT_CF_ECU_SSC_STAT
 *   EMS_SCCIsgEna of type COM_DT_EMS_SCCIsgEna
 *   CF_EMS_CltCtrlReq of type COM_DT_CF_EMS_CltCtrlReq
 *   CF_EMS_KEYST of type COM_DT_CF_EMS_KEYST
 *   CF_EMS_NEURALSW of type COM_DT_CF_EMS_NEURALSW
 *   CF_EMS_SSC_Tgt of type COM_DT_CF_EMS_SSC_Tgt
 *   DCT_BrkSwSta of type COM_DT_DCT_BrkSwSta
 *   DCT_EngOpSta of type COM_DT_DCT_EngOpSta
 *   DCT_EngSpdErrSta of type COM_DT_DCT_EngSpdErrSta
 *   DCT_MafErrSta of type COM_DT_DCT_MafErrSta
 *   DCT_MotCrctTqVal of type COM_DT_DCT_MotCrctTqVal
 *   DCT_MotIndTqBVal of type COM_DT_DCT_MotIndTqBVal
 *   DCT_MotIndTqVal of type COM_DT_DCT_MotIndTqVal
 *   DCT_MotSpdVal of type COM_DT_DCT_MotSpdVal
 *   EMS_AlvCnt3Val of type COM_DT_EMS_AlvCnt3Val
 *   EMS_Crc3Val of type COM_DT_EMS_Crc3Val
 *   ENG_48VOpIndiLmpReq of type COM_DT_ENG_48VOpIndiLmpReq
 *   ENG_GearPos of type COM_DT_ENG_GearPos
 *   ENG_MotRecupSta of type COM_DT_ENG_MotRecupSta
 *   ENG_NCC_STATE of type COM_DT_ENG_NCC_STATE
 *   Eng_OverRun of type COM_DT_Eng_OverRun
 *   ENG_SysWarnLmpReq of type COM_DT_ENG_SysWarnLmpReq
 *   SHIFT_IND_LED of type COM_DT_SHIFT_IND_LED
 *   SSC_CLUEngSpd of type COM_DT_SSC_CLUEngSpd
 *   SSC_CLUEngSpdFlag of type COM_DT_SSC_CLUEngSpdFlag
 *   TgtEngRPM of type COM_DT_TgtEngRPM
 * COM_DT_SG_EMS_05_100ms_SignalGroup: Record with elements
 *   AAF_WrnLamp of type COM_DT_AAF_WrnLamp
 *   EMS_AlvCnt5Val of type COM_DT_EMS_AlvCnt5Val_2
 *   EMS_Crc5Val of type COM_DT_EMS_Crc5Val_2
 *   EMS_EngStallDis of type COM_DT_EMS_EngStallDis
 *   EMS_PendingTrigSta of type COM_DT_EMS_PendingTrigSta
 *   EMS_RECTrigDta of type COM_DT_EMS_RECTrigDta
 *   EMS_SafetyFunctSta of type COM_DT_EMS_SafetyFunctSta
 *   ENG_AltFdbckLoadVal of type COM_DT_ENG_AltFdbckLoadVal_1
 *   ENG_AtmsphPrsrVal of type COM_DT_ENG_AtmsphPrsrVal_1
 *   ENG_BattVoltVal of type COM_DT_ENG_BattVoltVal_1
 *   ENG_DpfRgnSta of type COM_DT_ENG_DpfRgnSta
 *   ENG_EngDsplceTyp of type COM_DT_ENG_EngDsplceTyp_1
 *   ENG_EngTyp1 of type COM_DT_ENG_EngTyp1
 *   ENG_EngTyp2 of type COM_DT_ENG_EngTyp2
 *   ENG_EngTyp3 of type COM_DT_ENG_EngTyp3
 *   ENG_EngTyp4 of type COM_DT_ENG_EngTyp4
 *   ENG_ExtSoakTimeVal of type COM_DT_ENG_ExtSoakTimeVal_1
 *   ENG_FuelTempVal of type COM_DT_ENG_FuelTempVal_1
 *   ENG_ImmoLmpSta of type COM_DT_ENG_ImmoLmpSta
 *   ENG_ImmoSta of type COM_DT_ENG_ImmoSta
 *   ENG_IsgDispDetail of type COM_DT_ENG_IsgDispDetail_1
 *   ENG_IsgEquipped of type COM_DT_ENG_IsgEquipped
 *   ENG_KNK_Warning of type COM_DT_ENG_KNK_Warning
 *   ENG_MilSta of type COM_DT_ENG_MilSta
 *   ENG_OilLifeEna of type COM_DT_ENG_OilLifeEna
 *   ENG_OilLifeRatio of type COM_DT_ENG_OilLifeRatio_1
 *   ENG_OilLifeWarn of type COM_DT_ENG_OilLifeWarn_1
 *   ENG_PETyp of type COM_DT_ENG_PETyp
 *   ENG_S_F of type COM_DT_ENG_S_F
 *   ENG_S_F_GEN of type COM_DT_ENG_S_F_GEN
 *   ENG_TqStndValExt of type COM_DT_ENG_TqStndValExt_1
 *   ENG_TransmsnTyp of type COM_DT_ENG_TransmsnTyp
 *   InAirTempVal of type COM_DT_InAirTempVal_1
 *   OBD_DnmntrCalcVal of type COM_DT_OBD_DnmntrCalcVal_1
 *   OBD_IgnCycCntVal of type COM_DT_OBD_IgnCycCntVal_1
 *   OBD_RbmInhbtSta of type COM_DT_OBD_RbmInhbtSta_1
 *   OBD_RbmSta of type COM_DT_OBD_RbmSta_1
 *   SCC_BrkLtSwFlrDetSta of type COM_DT_SCC_BrkLtSwFlrDetSta
 *   SCC_DrvOvrRidSta of type COM_DT_SCC_DrvOvrRidSta
 *   SCC_FuncFlrDetSta of type COM_DT_SCC_FuncFlrDetSta
 *   SCC_SccFlrDetSta of type COM_DT_SCC_SccFlrDetSta
 *   SCC_SccOffStaDetSta of type COM_DT_SCC_SccOffStaDetSta
 *   SCC_StrtLimFuncSta of type COM_DT_SCC_StrtLimFuncSta_1
 *   SCR_IndcmtExitStaDis of type COM_DT_SCR_IndcmtExitStaDis_1
 *   SCR_LvlWrngLmpSta of type COM_DT_SCR_LvlWrngLmpSta
 *   SCR_LvlWrngMsgDis of type COM_DT_SCR_LvlWrngMsgDis_1
 *   SCR_RmnDstDis of type COM_DT_SCR_RmnDstDis_1
 *   SCR_RmnRstrtDis of type COM_DT_SCR_RmnRstrtDis_1
 *   SCR_SysErrMsgDis of type COM_DT_SCR_SysErrMsgDis_1
 *   SCR_SysWrngLmpReq of type COM_DT_SCR_SysWrngLmpReq
 *   SCR_UreaLvlSta of type COM_DT_SCR_UreaLvlSta_1
 * COM_DT_SG_EMS_07_10ms_SignalGroup: Record with elements
 *   EMS_AlvCnt7Val of type COM_DT_EMS_AlvCnt7Val
 *   EMS_Crc7Val of type COM_DT_EMS_Crc7Val
 *   HEV_AccelPdlVal of type COM_DT_HEV_AccelPdlVal
 *   HEV_EngSpdVal of type COM_DT_HEV_EngSpdVal
 *   HEV_DrvTqVal of type COM_DT_HEV_DrvTqVal
 *   HEV_EngOpSta of type COM_DT_HEV_EngOpSta
 *   HEV_FrctTqVal of type COM_DT_HEV_FrctTqVal
 *   HEV_IndTqTar of type COM_DT_HEV_IndTqTar
 *   HEV_IndTqVal of type COM_DT_HEV_IndTqVal
 *   HEV_IntakeAirTempVal of type COM_DT_HEV_IntakeAirTempVal
 *   HEV_TqStndVal of type COM_DT_HEV_TqStndVal
 * COM_DT_SG_EMS_11_10ms_SignalGroup: Record with elements
 *   EMS_AlvCnt11Val of type COM_DT_EMS_AlvCnt11Val
 *   EMS_Crc11Val of type COM_DT_EMS_Crc11Val
 *   HEV_EngSpdErrSta of type COM_DT_HEV_EngSpdErrSta
 *   HEV_DrvCycActSta of type COM_DT_HEV_DrvCycActSta
 *   HEV_EngFulLoadSta of type COM_DT_HEV_EngFulLoadSta
 *   HEV_EngTq_Bas of type COM_DT_HEV_EngTq_Bas
 *   HEV_EngTqAvail_FS of type COM_DT_HEV_EngTqAvail_FS
 *   HEV_EngTqVal of type COM_DT_HEV_EngTqVal
 *   HEV_EtcAppSta of type COM_DT_HEV_EtcAppSta
 *   HEV_FirstFiringSta of type COM_DT_HEV_FirstFiringSta
 *   HEV_FuelCnsmptVal of type COM_DT_HEV_FuelCnsmptVal
 *   HEV_FuelCutOffInhbtSta of type COM_DT_HEV_FuelCutOffInhbtSta
 *   HEV_FuelCutOffSta of type COM_DT_HEV_FuelCutOffSta
 *   HEV_FueledEngRdy of type COM_DT_HEV_FueledEngRdy
 *   HEV_FuelPmpTrgtPrsrVal of type COM_DT_HEV_FuelPmpTrgtPrsrVal
 *   HEV_FuelTnkPrsrErrSta of type COM_DT_HEV_FuelTnkPrsrErrSta
 *   HEV_FuelTnkPrsrVal of type COM_DT_HEV_FuelTnkPrsrVal
 *   HEV_GPF_WrnLamp of type COM_DT_HEV_GPF_WrnLamp
 *   HEV_IdleCtrStat_FS of type COM_DT_HEV_IdleCtrStat_FS
 *   HEV_IdlTgtEngSpd of type COM_DT_HEV_IdlTgtEngSpd
 *   HEV_O2SensHtrAct of type COM_DT_HEV_O2SensHtrAct
 *   HEV_O2SnsrPreHeatSta of type COM_DT_HEV_O2SnsrPreHeatSta
 *   HEV_ObdFrzFrmSta of type COM_DT_HEV_ObdFrzFrmSta
 *   HEV_RbmDrvCycSta of type COM_DT_HEV_RbmDrvCycSta
 *   HEV_RdyStat_FS_P of type COM_DT_HEV_RdyStat_FS_P
 *   HEV_ThrPosSta of type COM_DT_HEV_ThrPosSta
 *   HEV_VehSpdVal of type COM_DT_HEV_VehSpdVal
 *   HEV_WarmupCycSta of type COM_DT_HEV_WarmupCycSta
 * COM_DT_SG_EPB_01_50ms_SignalGroup: Record with elements
 *   EPB_AlvCnt1Val of type COM_DT_EPB_AlvCnt1Val
 *   EPB_Crc1Val of type COM_DT_EPB_Crc1Val
 *   EPB_FrcSta of type COM_DT_EPB_FrcSta
 *   EPB_SwPosSta of type COM_DT_EPB_SwPosSta
 *   EPB_ActlFrcVal of type COM_DT_EPB_ActlFrcVal
 *   EPB_AlrmReq of type COM_DT_EPB_AlrmReq
 *   EPB_DynmBrkFrcDclReq of type COM_DT_EPB_DynmBrkFrcDclReq
 *   EPB_DynmBrkFrcReq of type COM_DT_EPB_DynmBrkFrcReq
 *   EPB_DynmBrkFrcReqSigSta of type COM_DT_EPB_DynmBrkFrcReqSigSta
 *   EPB_EmerModReq of type COM_DT_EPB_EmerModReq
 *   EPB_EpbSta4VcuReq of type COM_DT_EPB_EpbSta4VcuReq
 *   EPB_EscReqAckSta of type COM_DT_EPB_EscReqAckSta
 *   EPB_FlrLmpStaDis of type COM_DT_EPB_FlrLmpStaDis
 *   EPB_FlSta of type COM_DT_EPB_FlSta
 *   EPB_FrcErrSta of type COM_DT_EPB_FrcErrSta
 *   EPB_LmpStaDis of type COM_DT_EPB_LmpStaDis
 *   EPB_OutDataDis of type COM_DT_EPB_OutDataDis
 *   EPB_RrBrkLtActvReq of type COM_DT_EPB_RrBrkLtActvReq
 * COM_DT_SG_ESC_01_10ms_SignalGroup: Record with elements
 *   AVH_Sta of type COM_DT_AVH_Sta
 *   ESC_AlvCnt1Val of type COM_DT_ESC_AlvCnt1Val
 *   ESC_Crc1Val of type COM_DT_ESC_Crc1Val
 *   ESC_CylPrsrSta of type COM_DT_ESC_CylPrsrSta
 *   ESC_CylPrsrVal of type COM_DT_ESC_CylPrsrVal
 *   ESC_OffTempSta of type COM_DT_ESC_OffTempSta
 *   ESC_Sta of type COM_DT_ESC_Sta
 *   ESC_VsmActvSta of type COM_DT_ESC_VsmActvSta
 *   TCS_Sta of type COM_DT_TCS_Sta
 *   ESC_IMURstStaAck of type COM_DT_ESC_IMURstStaAck_1
 *   AVH_ActvStaLmpDis of type COM_DT_AVH_ActvStaLmpDis
 *   AVH_AlrmReq of type COM_DT_AVH_AlrmReq
 *   AVH_CluDis of type COM_DT_AVH_CluDis
 *   AVH_LmpDis of type COM_DT_AVH_LmpDis
 *   AWD_CltchDtyLimVal of type COM_DT_AWD_CltchDtyLimVal
 *   AWD_CrdnShftTqLimVal of type COM_DT_AWD_CrdnShftTqLimVal
 *   AWD_FastOpnCrdnShftCltchReq of type COM_DT_AWD_FastOpnCrdnShftCltchReq
 *   AWD_RrWhlDtyLimReq of type COM_DT_AWD_RrWhlDtyLimReq
 *   AWD_TransmsnTqLimModSta of type COM_DT_AWD_TransmsnTqLimModSta
 *   BJD_Flag of type COM_DT_BJD_Flag
 *   DBC_ClusterDis of type COM_DT_DBC_ClusterDis
 *   DBC_FuncLmpSta of type COM_DT_DBC_FuncLmpSta
 *   DBC_Sta of type COM_DT_DBC_Sta
 *   DBC_WrngLmpSta of type COM_DT_DBC_WrngLmpSta
 *   ECD_ActvSta of type COM_DT_ECD_ActvSta
 *   EPB_ActvReq of type COM_DT_EPB_ActvReq
 *   EPB_StaReq of type COM_DT_EPB_StaReq
 *   ESC_BrkCtrlSta of type COM_DT_ESC_BrkCtrlSta
 *   ESC_CylPrsrDiagSta of type COM_DT_ESC_CylPrsrDiagSta
 *   ESC_CylPrsrFlagSta of type COM_DT_ESC_CylPrsrFlagSta
 *   ESC_LongAccelOffstCalibPrmtr of type COM_DT_ESC_LongAccelOffstCalibPrmtr
 *   ESC_OffSwSta of type COM_DT_ESC_OffSwSta
 *   ESC_SprtLmpSta of type COM_DT_ESC_SprtLmpSta
 *   ESC_StrTqReq of type COM_DT_ESC_StrTqReq
 *   ESC_VsmCtrlModSta of type COM_DT_ESC_VsmCtrlModSta
 *   ESC_VsmDfctvSta of type COM_DT_ESC_VsmDfctvSta
 *   HAC_Sta of type COM_DT_HAC_Sta
 *   LDM_Sta of type COM_DT_LDM_Sta
 *   MSR_FuncReq of type COM_DT_MSR_FuncReq
 *   MSR_TqFlag of type COM_DT_MSR_TqFlag
 *   MSR_TqIntrvntnVal of type COM_DT_MSR_TqIntrvntnVal
 *   TCS_GearShftCharacteristicVal of type COM_DT_TCS_GearShftCharacteristicVal
 *   TCS_LmpSta of type COM_DT_TCS_LmpSta
 *   TCS_ManufacturerVal of type COM_DT_TCS_ManufacturerVal
 *   TCS_OffLmpSta of type COM_DT_TCS_OffLmpSta
 *   TCS_PreActvSta of type COM_DT_TCS_PreActvSta
 *   TCS_Req of type COM_DT_TCS_Req
 *   TCS_SlwTqFlag of type COM_DT_TCS_SlwTqFlag
 *   TCS_SlwTqIntrvntnVal of type COM_DT_TCS_SlwTqIntrvntnVal
 *   TCS_TqFlag of type COM_DT_TCS_TqFlag
 *   TCS_TqIntrvntnVal of type COM_DT_TCS_TqIntrvntnVal
 * COM_DT_SG_ESC_03_20ms_SignalGroup: Record with elements
 *   ESC_AlvCnt3Val of type COM_DT_ESC_AlvCnt3Val
 *   ESC_Crc3Val of type COM_DT_ESC_Crc3Val
 *   ESC_DrvBrkActvSta of type COM_DT_ESC_DrvBrkActvSta
 *   ESC_DrvOvrdSta of type COM_DT_ESC_DrvOvrdSta
 *   ESC_PrkBrkActvSta of type COM_DT_ESC_PrkBrkActvSta
 *   ESC_RspaSta of type COM_DT_ESC_RspaSta
 *   ESC_StdStillVal of type COM_DT_ESC_StdStillVal
 *   FCA_AvlblSta of type COM_DT_FCA_AvlblSta
 *   FCA_EquipSta of type COM_DT_FCA_EquipSta
 *   SCC_EnblReq of type COM_DT_SCC_EnblReq
 *   SCC_OptTyp of type COM_DT_SCC_OptTyp
 *   ESC_FCA_ActvSta of type COM_DT_ESC_FCA_ActvSta
 *   ESC_DBS_ActvSta of type COM_DT_ESC_DBS_ActvSta
 *   CSC_WrngSta of type COM_DT_CSC_WrngSta
 *   ESC_AccelBasisVal of type COM_DT_ESC_AccelBasisVal
 *   ESC_BcaRPlusSta of type COM_DT_ESC_BcaRPlusSta
 *   ESC_BrkdFltStndstill of type COM_DT_ESC_BrkdFltStndstill
 *   ESC_BrkLtReq of type COM_DT_ESC_BrkLtReq
 *   ESC_DclEnblReq of type COM_DT_ESC_DclEnblReq
 *   ESC_DiffBrkFuncSta of type COM_DT_ESC_DiffBrkFuncSta
 *   ESC_DrvBrkSta of type COM_DT_ESC_DrvBrkSta
 *   ESC_HDP_EgSta of type COM_DT_ESC_HDP_EgSta
 *   ESC_HDP_EnblReq of type COM_DT_ESC_HDP_EnblReq
 *   ESC_HDP_FltMonSta of type COM_DT_ESC_HDP_FltMonSta
 *   ESC_LsdLimMod of type COM_DT_ESC_LsdLimMod
 *   ESC_LsdOpn of type COM_DT_ESC_LsdOpn
 *   ESC_LsdTqLim of type COM_DT_ESC_LsdTqLim
 *   ESC_PcaSta of type COM_DT_ESC_PcaSta
 *   ESC_RccaSta of type COM_DT_ESC_RccaSta
 *   ESC_RspaCanFlFlag of type COM_DT_ESC_RspaCanFlFlag
 *   ESC_RspaDclActv of type COM_DT_ESC_RspaDclActv
 *   ESC_RspaStandStill of type COM_DT_ESC_RspaStandStill
 *   ESC_VehAccelVal of type COM_DT_ESC_VehAccelVal
 *   MCB_CtlSta of type COM_DT_MCB_CtlSta
 *   MCB_DefSta of type COM_DT_MCB_DefSta
 *   MCB_ReqBrkAck of type COM_DT_MCB_ReqBrkAck
 *   PWI_STATE of type COM_DT_PWI_STATE
 *   SCC_ReqLimSta of type COM_DT_SCC_ReqLimSta
 *   SCC_TqIntrvntnVal of type COM_DT_SCC_TqIntrvntnVal
 *   SCC_TqReq of type COM_DT_SCC_TqReq
 * COM_DT_SG_FR_CMR_01_10ms_SignalGroup: Record with elements
 *   DAW_LVDA_OptUsmSta of type COM_DT_DAW_LVDA_OptUsmSta
 *   DAW_LVDA_PUDis of type COM_DT_DAW_LVDA_PUDis
 *   DAW_SysSta of type COM_DT_DAW_SysSta
 *   DAW_WrnMsgSta of type COM_DT_DAW_WrnMsgSta
 *   FR_CMR_AlvCnt1Val of type COM_DT_FR_CMR_AlvCnt1Val
 *   FR_CMR_Crc1Val of type COM_DT_FR_CMR_Crc1Val
 *   FR_CMR_SCCEquipSta of type COM_DT_FR_CMR_SCCEquipSta
 *   HBA_IndLmpReq of type COM_DT_HBA_IndLmpReq
 *   HBA_OptUsmSta of type COM_DT_HBA_OptUsmSta
 *   HBA_SysOptSta of type COM_DT_HBA_SysOptSta
 *   HBA_SysSta of type COM_DT_HBA_SysSta
 *   FR_CMR_ReqADASMapMsgVal of type COM_DT_FR_CMR_ReqADASMapMsgVal
 *   FR_CMR_SwVer1Val of type COM_DT_FR_CMR_SwVer1Val
 *   FR_CMR_SwVer2Val of type COM_DT_FR_CMR_SwVer2Val
 *   FCA_Equip_FR_CMR of type COM_DT_FCA_Equip_FR_CMR
 *   FR_CMR_ACANMonSta of type COM_DT_FR_CMR_ACANMonSta
 *   FR_CMR_CodingSta of type COM_DT_FR_CMR_CodingSta
 *   FR_CMR_EMTrgtVldSta of type COM_DT_FR_CMR_EMTrgtVldSta
 *   FR_CMR_FailInfoSta of type COM_DT_FR_CMR_FailInfoSta
 *   FR_CMR_FCA_Plus_Sta of type COM_DT_FR_CMR_FCA_Plus_Sta
 *   FR_CMR_FCAEquipSta of type COM_DT_FR_CMR_FCAEquipSta
 *   FR_CMR_MDPSCtrlSta of type COM_DT_FR_CMR_MDPSCtrlSta
 *   Info_OD_PedDstVal of type COM_DT_Info_OD_PedDstVal
 *   PRVECS_CodedSta of type COM_DT_PRVECS_CodedSta
 * COM_DT_SG_FR_CMR_02_100ms_SignalGroup: Record with elements
 *   FR_CMR_AlvCnt2Val of type COM_DT_FR_CMR_AlvCnt2Val
 *   FR_CMR_Crc2Val of type COM_DT_FR_CMR_Crc2Val
 *   ISLA_AddtnlSign of type COM_DT_ISLA_AddtnlSign
 *   ISLA_AutoUsmSta of type COM_DT_ISLA_AutoUsmSta
 *   ISLA_Cntry of type COM_DT_ISLA_Cntry
 *   ISLA_IcyWrn of type COM_DT_ISLA_IcyWrn
 *   ISLA_OffstUsmSta of type COM_DT_ISLA_OffstUsmSta
 *   ISLA_OptUsmSta of type COM_DT_ISLA_OptUsmSta
 *   ISLA_Popup of type COM_DT_ISLA_Popup
 *   ISLA_SchoolZone of type COM_DT_ISLA_SchoolZone
 *   ISLA_SpdChgReq of type COM_DT_ISLA_SpdChgReq
 *   ISLA_SpdwOffst of type COM_DT_ISLA_SpdwOffst
 *   ISLA_SpdWrn of type COM_DT_ISLA_SpdWrn
 *   ISLA_SwIgnoreReq of type COM_DT_ISLA_SwIgnoreReq
 *   ISLA_SymFlashMod of type COM_DT_ISLA_SymFlashMod
 *   ISLW_NoPassingInfoDis of type COM_DT_ISLW_NoPassingInfoDis
 *   ISLW_OptUsmSta of type COM_DT_ISLW_OptUsmSta
 *   ISLW_OvrlpSignDis of type COM_DT_ISLW_OvrlpSignDis
 *   ISLW_SpdCluDisSubCond1 of type COM_DT_ISLW_SpdCluDisSubCond1
 *   ISLW_SpdCluDisSubCond2 of type COM_DT_ISLW_SpdCluDisSubCond2
 *   ISLW_SpdCluMainDis of type COM_DT_ISLW_SpdCluMainDis
 *   ISLW_SpdNaviDisSubCond1 of type COM_DT_ISLW_SpdNaviDisSubCond1
 *   ISLW_SpdNaviDisSubCond2 of type COM_DT_ISLW_SpdNaviDisSubCond2
 *   ISLW_SpdNaviMainDis of type COM_DT_ISLW_SpdNaviMainDis
 *   ISLW_SubCondinfoSta1 of type COM_DT_ISLW_SubCondinfoSta1
 *   ISLW_SubCondinfoSta2 of type COM_DT_ISLW_SubCondinfoSta2
 *   ISLW_SysSta of type COM_DT_ISLW_SysSta
 *   ISLA_AutoNModReq of type COM_DT_ISLA_AutoNModReq
 *   ISLA_AutoNModSta of type COM_DT_ISLA_AutoNModSta
 *   ISLA_AutoSetSpdSta of type COM_DT_ISLA_AutoSetSpdSta
 *   ISLA_CondInfoDisp of type COM_DT_ISLA_CondInfoDisp
 *   ISLA_EUCntry1USMSta of type COM_DT_ISLA_EUCntry1USMSta
 *   ISLA_EUCntry2USMSta of type COM_DT_ISLA_EUCntry2USMSta
 *   ISLA_EUCntryVerTyp of type COM_DT_ISLA_EUCntryVerTyp
 *   ISLA_NACntry1USMSta of type COM_DT_ISLA_NACntry1USMSta
 *   ISLA_NACntry2USMSta of type COM_DT_ISLA_NACntry2USMSta
 *   ISLA_NACntryVerTyp of type COM_DT_ISLA_NACntryVerTyp
 *   ISLA_NAOffstUSMSta of type COM_DT_ISLA_NAOffstUSMSta
 *   ISLA_SndReqSta of type COM_DT_ISLA_SndReqSta
 *   ISLA_TSRSpdLimEnfrcmtSta of type COM_DT_ISLA_TSRSpdLimEnfrcmtSta
 *   ISLA_TSRSpdLimVal of type COM_DT_ISLA_TSRSpdLimVal
 * COM_DT_SG_FR_CMR_03_50ms_SignalGroup: Record with elements
 *   FR_CMR_AlvCnt3Val of type COM_DT_FR_CMR_AlvCnt3Val
 *   FR_CMR_Crc3Val of type COM_DT_FR_CMR_Crc3Val
 *   ID_CIPV of type COM_DT_ID_CIPV
 *   Info_RtLnCrvtrDrvtvVal of type COM_DT_Info_RtLnCrvtrDrvtvVal
 *   Info_RtLnCvtrVal of type COM_DT_Info_RtLnCvtrVal
 *   Info_RtLnDptSta of type COM_DT_Info_RtLnDptSta
 *   Info_RtLnHdingAnglVal of type COM_DT_Info_RtLnHdingAnglVal
 *   Info_RtLnPosVal of type COM_DT_Info_RtLnPosVal
 *   Info_RtLnQualSta of type COM_DT_Info_RtLnQualSta
 *   Longitudinal_Distance of type COM_DT_Longitudinal_Distance
 *   Relative_Velocity of type COM_DT_Relative_Velocity
 *   Info_LtLnCrvtrDrvtvVal of type COM_DT_Info_LtLnCrvtrDrvtvVal
 *   Info_LtLnCvtrVal of type COM_DT_Info_LtLnCvtrVal
 *   Info_LtLnDptSta of type COM_DT_Info_LtLnDptSta
 *   Info_LtLnHdingAnglVal of type COM_DT_Info_LtLnHdingAnglVal
 *   Info_LtLnPosVal of type COM_DT_Info_LtLnPosVal
 *   Info_LtLnQualSta of type COM_DT_Info_LtLnQualSta
 * COM_DT_SG_FR_CMR_04_40ms_SignalGroup: Record with elements
 *   FR_CMR_AlvCnt4Val of type COM_DT_FR_CMR_AlvCnt4Val_1
 *   FR_CMR_Crc4Val of type COM_DT_FR_CMR_Crc4Val_1
 *   IFSref_FR_CMR_Sta of type COM_DT_IFSref_FR_CMR_Sta
 *   IFSref_ILLAmbtSta of type COM_DT_IFSref_ILLAmbtSta
 *   IFSref_VehDst1Val of type COM_DT_IFSref_VehDst1Val
 *   IFSref_VehDst2Val of type COM_DT_IFSref_VehDst2Val
 *   IFSref_VehDst3Val of type COM_DT_IFSref_VehDst3Val
 *   IFSref_VehDst4Val of type COM_DT_IFSref_VehDst4Val
 *   IFSref_VehDst5Val of type COM_DT_IFSref_VehDst5Val
 *   IFSref_VehDst6Val of type COM_DT_IFSref_VehDst6Val
 *   IFSref_VehDst7Val of type COM_DT_IFSref_VehDst7Val
 *   IFSref_VehDst8Val of type COM_DT_IFSref_VehDst8Val
 *   IFSref_VehDst9Val of type COM_DT_IFSref_VehDst9Val
 *   IFSref_VehDst10Val of type COM_DT_IFSref_VehDst10Val
 *   IFSref_VehLtAngl1Val of type COM_DT_IFSref_VehLtAngl1Val_1
 *   IFSref_VehLtAngl2Val of type COM_DT_IFSref_VehLtAngl2Val_1
 *   IFSref_VehLtAngl3Val of type COM_DT_IFSref_VehLtAngl3Val_1
 *   IFSref_VehLtAngl4Val of type COM_DT_IFSref_VehLtAngl4Val_1
 *   IFSref_VehLtAngl5Val of type COM_DT_IFSref_VehLtAngl5Val_1
 *   IFSref_VehLtAngl6Val of type COM_DT_IFSref_VehLtAngl6Val_1
 *   IFSref_VehLtAngl7Val of type COM_DT_IFSref_VehLtAngl7Val_1
 *   IFSref_VehLtAngl8Val of type COM_DT_IFSref_VehLtAngl8Val_1
 *   IFSref_VehLtAngl9Val of type COM_DT_IFSref_VehLtAngl9Val_1
 *   IFSref_VehLtAngl10Val of type COM_DT_IFSref_VehLtAngl10Val_1
 *   IFSref_VehNumVal of type COM_DT_IFSref_VehNumVal_1
 *   IFSref_VehRtAngl1Val of type COM_DT_IFSref_VehRtAngl1Val_1
 *   IFSref_VehRtAngl2Val of type COM_DT_IFSref_VehRtAngl2Val_1
 *   IFSref_VehRtAngl3Val of type COM_DT_IFSref_VehRtAngl3Val_1
 *   IFSref_VehRtAngl4Val of type COM_DT_IFSref_VehRtAngl4Val_1
 *   IFSref_VehRtAngl5Val of type COM_DT_IFSref_VehRtAngl5Val_1
 *   IFSref_VehRtAngl6Val of type COM_DT_IFSref_VehRtAngl6Val_1
 *   IFSref_VehRtAngl7Val of type COM_DT_IFSref_VehRtAngl7Val_1
 *   IFSref_VehRtAngl8Val of type COM_DT_IFSref_VehRtAngl8Val_1
 *   IFSref_VehRtAngl9Val of type COM_DT_IFSref_VehRtAngl9Val_1
 *   IFSref_VehRtAngl10Val of type COM_DT_IFSref_VehRtAngl10Val_1
 * COM_DT_SG_HCU_03_10ms_SignalGroup: Record with elements
 *   HCU_AlvCnt3Val of type COM_DT_HCU_AlvCnt3Val
 *   HCU_Crc3Val of type COM_DT_HCU_Crc3Val
 *   HCU_HevRdySta of type COM_DT_HCU_HevRdySta
 *   HCU_SccEnblSta of type COM_DT_HCU_SccEnblSta
 *   HCU_SpdLimDeviceActSta of type COM_DT_HCU_SpdLimDeviceActSta
 *   HCU_SpdLimDeviceOperSta of type COM_DT_HCU_SpdLimDeviceOperSta
 *   HCU_SpdLimDeviceVehSpdVal of type COM_DT_HCU_SpdLimDeviceVehSpdVal
 *   HCU_BrkLmpOnReq of type COM_DT_HCU_BrkLmpOnReq
 *   HCU_CcDrvAlrtDis of type COM_DT_HCU_CcDrvAlrtDis
 *   HCU_DrvWhlDmndTqNmVal of type COM_DT_HCU_DrvWhlDmndTqNmVal
 *   HCU_DucUsrSetCluSta of type COM_DT_HCU_DucUsrSetCluSta
 *   HCU_DucVal of type COM_DT_HCU_DucVal
 *   HCU_EstAccelPdlPcVal of type COM_DT_HCU_EstAccelPdlPcVal
 *   HCU_EstApsSelSta of type COM_DT_HCU_EstApsSelSta
 *   HCU_GearRInhbtSta of type COM_DT_HCU_GearRInhbtSta
 *   HCU_GreenZoneDrvModSta of type COM_DT_HCU_GreenZoneDrvModSta
 *   HCU_GreenZoneLmpDis of type COM_DT_HCU_GreenZoneLmpDis
 *   HCU_HcuRdySta of type COM_DT_HCU_HcuRdySta
 *   HCU_HEVRdyDis of type COM_DT_HCU_HEVRdyDis
 *   HCU_LimpOffSta of type COM_DT_HCU_LimpOffSta
 *   HCU_MILOnReq of type COM_DT_HCU_MILOnReq
 *   HCU_PdlStopCtrlSta of type COM_DT_HCU_PdlStopCtrlSta
 *   HCU_PdlStopReqTqNmVal of type COM_DT_HCU_PdlStopReqTqNmVal
 *   HCU_PhevAutoModOnSta of type COM_DT_HCU_PhevAutoModOnSta
 *   HCU_RspaAlvCntVal of type COM_DT_HCU_RspaAlvCntVal
 *   HCU_RspaCanFailSta of type COM_DT_HCU_RspaCanFailSta
 *   HCU_RspaSta of type COM_DT_HCU_RspaSta
 *   HCU_SccDrvOvrdReq of type COM_DT_HCU_SccDrvOvrdReq
 *   HCU_SldDrvAlrtDis of type COM_DT_HCU_SldDrvAlrtDis
 *   HCU_SlwDnSta of type COM_DT_HCU_SlwDnSta
 *   HCU_SmrtEcoGdDis of type COM_DT_HCU_SmrtEcoGdDis
 *   HCU_SmrtEcoLvlDis of type COM_DT_HCU_SmrtEcoLvlDis
 *   HCU_SmrtEcoRngDis of type COM_DT_HCU_SmrtEcoRngDis
 *   HCU_SrvModSta of type COM_DT_HCU_SrvModSta
 *   HCU_StrtInhbt2Sta of type COM_DT_HCU_StrtInhbt2Sta
 *   HCU_StrtInhbtSta of type COM_DT_HCU_StrtInhbtSta
 *   HCU_SysShtOffReq of type COM_DT_HCU_SysShtOffReq
 *   HCU_VehStrtEnblSta of type COM_DT_HCU_VehStrtEnblSta
 *   HCU_WhlCrpCrpTqNmVal of type COM_DT_HCU_WhlCrpCrpTqNmVal
 *   LHCU_EngCltchTrnsfrTqPcVal_Copy_1 of type COM_DT_LHCU_EngCltchTrnsfrTqPcVal_Copy_1
 * COM_DT_SG_HCU_05_100ms_SignalGroup: Record with elements
 *   HCU_AafCtrlReq of type COM_DT_HCU_AafCtrlReq
 *   HCU_AcnCompPrmsnPwrVal of type COM_DT_HCU_AcnCompPrmsnPwrVal
 *   HCU_AcnOpPrmssnSta of type COM_DT_HCU_AcnOpPrmssnSta
 *   HCU_AcPwrIncSta of type COM_DT_HCU_AcPwrIncSta
 *   HCU_AlvCnt5Val of type COM_DT_HCU_AlvCnt5Val
 *   HCU_BlwOffReq of type COM_DT_HCU_BlwOffReq
 *   HCU_CcCameraOperSta of type COM_DT_HCU_CcCameraOperSta
 *   HCU_CcCameraSta of type COM_DT_HCU_CcCameraSta
 *   HCU_ChrgIncModSta of type COM_DT_HCU_ChrgIncModSta
 *   HCU_Crc5Val of type COM_DT_HCU_Crc5Val
 *   HCU_CrsCtrlOnLmpDis of type COM_DT_HCU_CrsCtrlOnLmpDis
 *   HCU_CrsCtrlSetLmpDis of type COM_DT_HCU_CrsCtrlSetLmpDis
 *   HCU_DptEnaSet1FriSta of type COM_DT_HCU_DptEnaSet1FriSta
 *   HCU_DptEnaSet1MonSta of type COM_DT_HCU_DptEnaSet1MonSta
 *   HCU_DptEnaSet1SatSta of type COM_DT_HCU_DptEnaSet1SatSta
 *   HCU_DptEnaSet1Sta of type COM_DT_HCU_DptEnaSet1Sta
 *   HCU_DptEnaSet1SunSta of type COM_DT_HCU_DptEnaSet1SunSta
 *   HCU_DptEnaSet1ThuSta of type COM_DT_HCU_DptEnaSet1ThuSta
 *   HCU_DptEnaSet1TueSta of type COM_DT_HCU_DptEnaSet1TueSta
 *   HCU_DptEnaSet1WedSta of type COM_DT_HCU_DptEnaSet1WedSta
 *   HCU_DptEnaSet2FriSta of type COM_DT_HCU_DptEnaSet2FriSta
 *   HCU_DptEnaSet2MonSta of type COM_DT_HCU_DptEnaSet2MonSta
 *   HCU_DptEnaSet2SatSta of type COM_DT_HCU_DptEnaSet2SatSta
 *   HCU_DptEnaSet2Sta of type COM_DT_HCU_DptEnaSet2Sta
 *   HCU_DptEnaSet2SunSta of type COM_DT_HCU_DptEnaSet2SunSta
 *   HCU_DptEnaSet2ThuSta of type COM_DT_HCU_DptEnaSet2ThuSta
 *   HCU_DptEnaSet2TueSta of type COM_DT_HCU_DptEnaSet2TueSta
 *   HCU_DptEnaSet2WedSta of type COM_DT_HCU_DptEnaSet2WedSta
 *   HCU_DptHrSet1Val of type COM_DT_HCU_DptHrSet1Val
 *   HCU_DptHrSet2Val of type COM_DT_HCU_DptHrSet2Val
 *   HCU_DptMinSet1Val of type COM_DT_HCU_DptMinSet1Val
 *   HCU_DptMinSet2Val of type COM_DT_HCU_DptMinSet2Val
 *   HCU_DrvModSta of type COM_DT_HCU_DrvModSta
 *   HCU_EcoChrgEndHrVal of type COM_DT_HCU_EcoChrgEndHrVal
 *   HCU_EcoChrgEndHrWeekendVal of type COM_DT_HCU_EcoChrgEndHrWeekendVal
 *   HCU_EcoChrgEndMinVal of type COM_DT_HCU_EcoChrgEndMinVal
 *   HCU_EcoChrgEndMinWeekendVal of type COM_DT_HCU_EcoChrgEndMinWeekendVal
 *   HCU_EcoChrgStrtHrVal of type COM_DT_HCU_EcoChrgStrtHrVal
 *   HCU_EcoChrgStrtHrWeekendVal of type COM_DT_HCU_EcoChrgStrtHrWeekendVal
 *   HCU_EcoChrgStrtMinVal of type COM_DT_HCU_EcoChrgStrtMinVal
 *   HCU_EcoChrgStrtMinWeekendVal of type COM_DT_HCU_EcoChrgStrtMinWeekendVal
 *   HCU_EcoLvlVal of type COM_DT_HCU_EcoLvlVal
 *   HCU_EcoScoVal of type COM_DT_HCU_EcoScoVal
 *   HCU_EmissionTestModSta of type COM_DT_HCU_EmissionTestModSta
 *   HCU_FuelEcoVal of type COM_DT_HCU_FuelEcoVal
 *   HCU_HevSysModSta of type COM_DT_HCU_HevSysModSta
 *   HCU_LdcCtrlModSta of type COM_DT_HCU_LdcCtrlModSta
 *   HCU_LdcInhbtReq of type COM_DT_HCU_LdcInhbtReq
 *   HCU_LdcUnderVoltCtrlSta of type COM_DT_HCU_LdcUnderVoltCtrlSta
 *   HCU_NccAlrmInfoSta of type COM_DT_HCU_NccAlrmInfoSta
 *   HCU_PaddleCoastCtrlSta of type COM_DT_HCU_PaddleCoastCtrlSta
 *   HCU_PaddleCstCtrlWrnMsgSta of type COM_DT_HCU_PaddleCstCtrlWrnMsgSta
 *   HCU_PaddleStepCtrlSta of type COM_DT_HCU_PaddleStepCtrlSta
 *   HCU_PhevDrvModClusterSta of type COM_DT_HCU_PhevDrvModClusterSta
 *   HCU_PhevMod of type COM_DT_HCU_PhevMod
 *   HCU_PIFailFreezeReq of type COM_DT_HCU_PIFailFreezeReq
 *   HCU_PreFATCHysTempVal of type COM_DT_HCU_PreFATCHysTempVal
 *   HCU_PreFATCOffstTempVal of type COM_DT_HCU_PreFATCOffstTempVal
 *   HCU_PreFATCOffstTempValHR of type COM_DT_HCU_PreFATCOffstTempValHR
 *   HCU_SchedChgEndDayVal of type COM_DT_HCU_SchedChgEndDayVal
 *   HCU_SchedChgEndHrVal of type COM_DT_HCU_SchedChgEndHrVal
 *   HCU_SchedChgEndMinVal of type COM_DT_HCU_SchedChgEndMinVal
 *   HCU_SchedChgStrtDayVal of type COM_DT_HCU_SchedChgStrtDayVal
 *   HCU_SchedChgStrtHrVal of type COM_DT_HCU_SchedChgStrtHrVal
 *   HCU_SchedChgStrtMinVal of type COM_DT_HCU_SchedChgStrtMinVal
 *   HCU_SmartRegen_LvlVal of type COM_DT_HCU_SmartRegen_LvlVal
 *   HCU_SmartRegen_MapCstActSta of type COM_DT_HCU_SmartRegen_MapCstActSta
 *   HCU_SmartRegen_MapEventUsmSta of type COM_DT_HCU_SmartRegen_MapEventUsmSta
 *   HCU_SmartRegen_OnSta of type COM_DT_HCU_SmartRegen_OnSta
 *   HCU_SmartRegen_RdrCstActSta of type COM_DT_HCU_SmartRegen_RdrCstActSta
 *   HCU_SmartRegen_UsmSta of type COM_DT_HCU_SmartRegen_UsmSta
 *   HCU_SmartRegen_VehHoldSta of type COM_DT_HCU_SmartRegen_VehHoldSta
 *   HCU_SmartRegen_WarnMsgSta of type COM_DT_HCU_SmartRegen_WarnMsgSta
 *   HCU_SrvLmpDis of type COM_DT_HCU_SrvLmpDis
 *   HCU_SrvLmpTmpryOnSta of type COM_DT_HCU_SrvLmpTmpryOnSta
 * COM_DT_SG_HTCU_04_10ms_SignalGroup: Record with elements
 *   HTCU_AlvCnt4Val of type COM_DT_HTCU_AlvCnt4Val
 *   HTCU_Crc4Val of type COM_DT_HTCU_Crc4Val
 *   HTCU_GearSlctrDis of type COM_DT_HTCU_GearSlctrDis
 *   HTCU_CtrlablSta of type COM_DT_HTCU_CtrlablSta
 *   HTCU_CurrGearSta of type COM_DT_HTCU_CurrGearSta
 *   HTCU_FanCtrlReq of type COM_DT_HTCU_FanCtrlReq
 *   HTCU_FltSta of type COM_DT_HTCU_FltSta
 *   HTCU_FsAddtnlTqLssPcVal of type COM_DT_HTCU_FsAddtnlTqLssPcVal
 *   HTCU_FsCltchLmphmActvSta of type COM_DT_HTCU_FsCltchLmphmActvSta
 *   HTCU_FsEngTqRdctnPcVal of type COM_DT_HTCU_FsEngTqRdctnPcVal
 *   HTCU_FsIdleTrgtRpmVal of type COM_DT_HTCU_FsIdleTrgtRpmVal
 *   HTCU_GearChgSta of type COM_DT_HTCU_GearChgSta
 *   HTCU_GearShftDnDisGSI of type COM_DT_HTCU_GearShftDnDisGSI
 *   HTCU_GearShftUpDisGSI of type COM_DT_HTCU_GearShftUpDisGSI
 *   HTCU_HvOpuSpdCmdRpmVal of type COM_DT_HTCU_HvOpuSpdCmdRpmVal
 *   HTCU_LnPrsBarVal of type COM_DT_HTCU_LnPrsBarVal
 *   HTCU_PrgrmSta of type COM_DT_HTCU_PrgrmSta
 *   HTCU_RapidKDReq of type COM_DT_HTCU_RapidKDReq
 *   HTCU_RdySta of type COM_DT_HTCU_RdySta
 *   HTCU_SlwTqRdctnPcVal of type COM_DT_HTCU_SlwTqRdctnPcVal
 *   HTCU_SolBSta of type COM_DT_HTCU_SolBSta
 *   HTCU_TqRdctnPcVal of type COM_DT_HTCU_TqRdctnPcVal
 *   HTCU_TrgtGearSta of type COM_DT_HTCU_TrgtGearSta
 *   HTCU_TrgtGearStaGSI of type COM_DT_HTCU_TrgtGearStaGSI
 *   HTCU_TrgtShftClsCCanSta of type COM_DT_HTCU_TrgtShftClsCCanSta
 *   HTCU_VehSpdDcmlKphVal of type COM_DT_HTCU_VehSpdDcmlKphVal
 *   HTCU_VehSpdKphVal of type COM_DT_HTCU_VehSpdKphVal
 * COM_DT_SG_HTCU_05_10ms_SignalGroup: Record with elements
 *   HDCT_AcnChrgInhbtReq of type COM_DT_HDCT_AcnChrgInhbtReq
 *   HDCT_AddtnlTqLssVal of type COM_DT_HDCT_AddtnlTqLssVal
 *   HDCT_CltchSta of type COM_DT_HDCT_CltchSta
 *   HDCT_CLUEngSpd of type COM_DT_HDCT_CLUEngSpd
 *   HDCT_CLUEngSpdFlag of type COM_DT_HDCT_CLUEngSpdFlag
 *   HDCT_CLUTrgtGear of type COM_DT_HDCT_CLUTrgtGear
 *   HDCT_CtrlablSta of type COM_DT_HDCT_CtrlablSta
 *   HDCT_CurrGear of type COM_DT_HDCT_CurrGear
 *   HDCT_CurrPrgrm of type COM_DT_HDCT_CurrPrgrm
 *   HDCT_DblCltchSta of type COM_DT_HDCT_DblCltchSta
 *   HDCT_EngCltchLmphmMod of type COM_DT_HDCT_EngCltchLmphmMod
 *   HDCT_EOLReq of type COM_DT_HDCT_EOLReq
 *   HDCT_FltSta of type COM_DT_HDCT_FltSta
 *   HDCT_FuelCutReq of type COM_DT_HDCT_FuelCutReq
 *   HDCT_GearSelDis of type COM_DT_HDCT_GearSelDis
 *   HDCT_GearShftSta of type COM_DT_HDCT_GearShftSta
 *   HDCT_GSITrgtGear of type COM_DT_HDCT_GSITrgtGear
 *   HDCT_KckDnSkpShftCnt of type COM_DT_HDCT_KckDnSkpShftCnt
 *   HDCT_MCUAntJrkInhbt of type COM_DT_HDCT_MCUAntJrkInhbt
 *   HDCT_NCoastDnReq of type COM_DT_HDCT_NCoastDnReq
 *   HDCT_NCoastTrgtGear of type COM_DT_HDCT_NCoastTrgtGear
 *   HDCT_NetrlCtrlSta of type COM_DT_HDCT_NetrlCtrlSta
 *   HDCT_OBDErrSta of type COM_DT_HDCT_OBDErrSta
 *   HDCT_OBDSta of type COM_DT_HDCT_OBDSta
 *   HDCT_ShftPhase of type COM_DT_HDCT_ShftPhase
 *   HDCT_SlipCrnkAllw of type COM_DT_HDCT_SlipCrnkAllw
 *   HDCT_StcShftLrchCtrl of type COM_DT_HDCT_StcShftLrchCtrl
 *   HDCT_TCURdySta of type COM_DT_HDCT_TCURdySta
 *   HDCT_TqIncReq of type COM_DT_HDCT_TqIncReq
 *   HDCT_TqIncVal of type COM_DT_HDCT_TqIncVal
 *   HDCT_TqRdctnVal of type COM_DT_HDCT_TqRdctnVal
 *   HDCT_TrgtGear of type COM_DT_HDCT_TrgtGear
 *   HDCT_TrgtShftCls of type COM_DT_HDCT_TrgtShftCls
 *   HTCU_AlvCnt5Val of type COM_DT_HTCU_AlvCnt5Val
 *   HTCU_Crc5Val of type COM_DT_HTCU_Crc5Val
 *   HTCU_SlwTqRdctnVal of type COM_DT_HTCU_SlwTqRdctnVal
 * COM_DT_SG_HU_CLU_PE_05_SignalGroup: Record with elements
 *   HU_AutoBrightState_New of type COM_DT_HU_AutoBrightState_New_1
 *   HU_BVM_Display_Message of type COM_DT_HU_BVM_Display_Message_1
 *   HU_DayNightState of type COM_DT_HU_DayNightState
 *   HU_EVSupport of type COM_DT_HU_EVSupport
 *   HU_LanguageInfo of type COM_DT_HU_LanguageInfo_1
 *   HU_MuteStatus of type COM_DT_HU_MuteStatus
 *   HU_NaviCamSettingStatus of type COM_DT_HU_NaviCamSettingStatus_2
 *   HU_NaviDisp of type COM_DT_HU_NaviDisp
 *   HU_NaviStatus of type COM_DT_HU_NaviStatus
 *   HU_SVM_View_Display of type COM_DT_HU_SVM_View_Display_1
 *   HU_UsmSupport of type COM_DT_HU_UsmSupport
 *   HU_VolumeStatus of type COM_DT_HU_VolumeStatus
 *   HU_WelcomeReady of type COM_DT_HU_WelcomeReady
 * COM_DT_SG_HU_GW_PE_01_SignalGroup: Record with elements
 *   AVN_RSPA_CancelInput of type COM_DT_AVN_RSPA_CancelInput
 *   AVN_RSPA_Disp_Rdy of type COM_DT_AVN_RSPA_Disp_Rdy
 *   AVN_RSPA_ModeSelect of type COM_DT_AVN_RSPA_ModeSelect_1
 *   C_TeleActiveStatus of type COM_DT_C_TeleActiveStatus
 *   CF_AVN_ProfileIDRValue of type COM_DT_CF_AVN_ProfileIDRValue_1
 *   CF_HU_GPSFlt of type COM_DT_CF_HU_GPSFlt
 *   HazardFromHUSVM of type COM_DT_HazardFromHUSVM
 *   HU_AliveStatus of type COM_DT_HU_AliveStatus
 *   HU_DistanceUnit of type COM_DT_HU_DistanceUnit
 *   HU_MicActivity of type COM_DT_HU_MicActivity
 *   HU_RTCCheck of type COM_DT_HU_RTCCheck
 *   HU_Scheduled_Setting of type COM_DT_HU_Scheduled_Setting_1
 *   HU_ThemeType of type COM_DT_HU_ThemeType_1
 *   OMUOSMirCtrl of type COM_DT_OMUOSMirCtrl
 *   OTAUIStatus of type COM_DT_OTAUIStatus
 * COM_DT_SG_HU_MON_PE_01_SignalGroup: Record with elements
 *   HU_AdasSupport of type COM_DT_HU_AdasSupport
 *   HU_AMP_EQVariant of type COM_DT_HU_AMP_EQVariant_1
 *   HU_DistributeInfo of type COM_DT_HU_DistributeInfo_2
 *   HU_Navi_RspADASMapMsg of type COM_DT_HU_Navi_RspADASMapMsg_2
 *   HU_NaviHandshakingSupport of type COM_DT_HU_NaviHandshakingSupport
 *   HU_NaviMapInfo of type COM_DT_HU_NaviMapInfo
 *   HU_OptionInfo of type COM_DT_HU_OptionInfo
 *   HU_Type of type COM_DT_HU_Type_2
 * COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup: Record with elements
 *   META_V2_3_Country_OptADAS of type COM_DT_META_V2_3_Country_OptADAS
 *   META_V2_3_CountryCode of type COM_DT_META_V2_3_CountryCode_1
 *   META_V2_3_CyclicCounter of type COM_DT_META_V2_3_CyclicCounter_1
 *   META_V2_3_DrivingSide of type COM_DT_META_V2_3_DrivingSide
 *   META_V2_3_MajorProtocolVersion of type COM_DT_META_V2_3_MajorProtocolVersion_1
 *   META_V2_3_MapProvider of type COM_DT_META_V2_3_MapProvider
 *   META_V2_3_MinorProtocolVersion of type COM_DT_META_V2_3_MinorProtocolVersion_1
 *   META_V2_3_RegionCode of type COM_DT_META_V2_3_RegionCode_1
 *   META_V2_3_SpeedUnit of type COM_DT_META_V2_3_SpeedUnit
 * COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup: Record with elements
 *   POS_V2_3_CurrAltitude1m of type COM_DT_POS_V2_3_CurrAltitude1m_1
 *   POS_V2_3_CurrAltitude100m of type COM_DT_POS_V2_3_CurrAltitude100m
 *   POS_V2_3_CurrDirectionLanes of type COM_DT_POS_V2_3_CurrDirectionLanes_1
 *   POS_V2_3_CurrFormOfWay of type COM_DT_POS_V2_3_CurrFormOfWay_1
 *   POS_V2_3_CurrFuncRoadClass of type COM_DT_POS_V2_3_CurrFuncRoadClass
 *   POS_V2_3_CurrSpeedLimit of type COM_DT_POS_V2_3_CurrSpeedLimit
 *   POS_V2_3_CurrTrafficSpeed of type COM_DT_POS_V2_3_CurrTrafficSpeed
 *   POS_V2_3_CyclicCounter of type COM_DT_POS_V2_3_CyclicCounter_1
 *   POS_V2_3_Offset of type COM_DT_POS_V2_3_Offset_1
 *   POS_V2_3_PathIndex of type COM_DT_POS_V2_3_PathIndex_1
 *   POS_V2_3_RangeAvgSpeed of type COM_DT_POS_V2_3_RangeAvgSpeed_1
 * COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro: Record with elements
 *   PROLONG_V2_3_CyclicCounter of type COM_DT_PROLONG_V2_3_CyclicCounter_1
 *   PROLONG_V2_3_Offset of type COM_DT_PROLONG_V2_3_Offset_1
 *   PROLONG_V2_3_PathIndex of type COM_DT_PROLONG_V2_3_PathIndex_1
 *   PROLONG_V2_3_ProfileType of type COM_DT_PROLONG_V2_3_ProfileType_1
 *   PROLONG_V2_3_Update of type COM_DT_PROLONG_V2_3_Update
 *   PROLONG_V2_3_Value of type COM_DT_PROLONG_V2_3_Value_1
 * COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa: Record with elements
 *   PROSHORT_V2_3_Accuracy of type COM_DT_PROSHORT_V2_3_Accuracy_1
 *   PROSHORT_V2_3_CyclicCounter of type COM_DT_PROSHORT_V2_3_CyclicCounter_1
 *   PROSHORT_V2_3_Distance of type COM_DT_PROSHORT_V2_3_Distance_1
 *   PROSHORT_V2_3_Offset of type COM_DT_PROSHORT_V2_3_Offset_1
 *   PROSHORT_V2_3_PathIndex of type COM_DT_PROSHORT_V2_3_PathIndex_1
 *   PROSHORT_V2_3_ProfileType of type COM_DT_PROSHORT_V2_3_ProfileType_1
 *   PROSHORT_V2_3_Value0 of type COM_DT_PROSHORT_V2_3_Value0_1
 *   PROSHORT_V2_3_Value1 of type COM_DT_PROSHORT_V2_3_Value1_1
 * COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup: Record with elements
 *   SEG_V2_3_CalculatedRoute of type COM_DT_SEG_V2_3_CalculatedRoute
 *   SEG_V2_3_CyclicCounter of type COM_DT_SEG_V2_3_CyclicCounter_1
 *   SEG_V2_3_DirectionLanes of type COM_DT_SEG_V2_3_DirectionLanes_1
 *   SEG_V2_3_DividedRoad of type COM_DT_SEG_V2_3_DividedRoad
 *   SEG_V2_3_FormOfWay of type COM_DT_SEG_V2_3_FormOfWay_1
 *   SEG_V2_3_FuncRoadClass of type COM_DT_SEG_V2_3_FuncRoadClass
 *   SEG_V2_3_Offset of type COM_DT_SEG_V2_3_Offset_1
 *   SEG_V2_3_PathIndex of type COM_DT_SEG_V2_3_PathIndex_1
 *   SEG_V2_3_Retransmission of type COM_DT_SEG_V2_3_Retransmission
 *   SEG_V2_3_SpeedLimit of type COM_DT_SEG_V2_3_SpeedLimit
 *   SEG_V2_3_SpeedLimitUnder5 of type COM_DT_SEG_V2_3_SpeedLimitUnder5_1
 * COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup: Record with elements
 *   Navi_ISLW_CountryCode of type Navi_ISLW_CountryCode
 *   Navi_ISLW_Frwinfo of type Navi_ISLW_Frwinfo
 *   Navi_ISLW_LinkClass of type Navi_ISLW_LinkClass
 *   Navi_ISLW_MapSource of type Navi_ISLW_MapSource
 *   Navi_ISLW_SpdLimit of type Navi_ISLW_SpdLimit
 *   Navi_ISLW_SpdUnit of type Navi_ISLW_SpdUnit
 *   Navi_ISLW_TimeSpd of type Navi_ISLW_TimeSpd
 *   Navi_ISLW_TollExist of type Navi_ISLW_TollExist
 *   Navi_ISLW_TunnelExist of type Navi_ISLW_TunnelExist
 *   Navi_ISLA_TImeZone of type Navi_ISLA_TImeZone
 * COM_DT_SG_HU_USM_E_14_SignalGroup: Record with elements
 *   CF_AVN_LKAWrngVolNvalueSet of type COM_DT_CF_AVN_LKAWrngVolNvalueSet
 * COM_DT_SG_IAU_16_200ms_SignalGroup: Record with elements
 *   IAU_DigitalKey2Opt of type COM_DT_IAU_DigitalKey2Opt
 *   IAU_DigitalKeyEnblRVal of type COM_DT_IAU_DigitalKeyEnblRVal
 *   IAU_DigitalKeyExit of type COM_DT_IAU_DigitalKeyExit
 *   IAU_DigitalKeyProcessingSta of type COM_DT_IAU_DigitalKeyProcessingSta
 *   IAU_DISPWrng of type COM_DT_IAU_DISPWrng
 *   IAU_NFCCard1RegRVal of type COM_DT_IAU_NFCCard1RegRVal
 *   IAU_NFCCard2RegRVal of type COM_DT_IAU_NFCCard2RegRVal
 *   IAU_OwnerPhnRegRVal of type COM_DT_IAU_OwnerPhnRegRVal
 *   IAU_ProfileIDRVal of type COM_DT_IAU_ProfileIDRVal
 *   IAUwFPMLearnState of type COM_DT_IAUwFPMLearnState
 *   IAUwFRULearnState of type COM_DT_IAUwFRULearnState
 * COM_DT_SG_ICC_HS_01_50ms_SignalGroup: Record with elements
 *   ICC_CamBlckdStat of type ICC_CamBlckdStat
 *   ICC_CamFailStat of type ICC_CamFailStat
 *   ICC_EcuFailStat of type ICC_EcuFailStat
 *   ICC_HDPSpprtSWVer of type ICC_HDPSpprtSWVer
 *   ICC_HS_AlvCnt1Val of type ICC_HS_AlvCnt1Val
 *   ICC_HS_Crc1Val of type ICC_HS_Crc1Val
 *   ICC_MajorSWVer of type ICC_MajorSWVer
 *   ICC_MinorSWVer of type ICC_MinorSWVer
 *   ICC_OptUsmStat of type ICC_OptUsmStat
 *   ICC_ProfilingStat of type ICC_ProfilingStat
 *   ICC_SymStat of type ICC_SymStat
 *   ICC_UpdateStat of type ICC_UpdateStat
 *   ICC_WarningSmblDistStat of type ICC_WarningSmblDistStat
 *   ICC_WarningSmblDrowStat of type ICC_WarningSmblDrowStat
 *   ICC_WarningSndStat of type ICC_WarningSndStat
 *   ICC_WarningStat of type ICC_WarningStat
 *   ICC_WarningSnd2Stat of type ICC_WarningSnd2Stat
 * COM_DT_SG_ICC_HS_04_50ms_SignalGroup: Record with elements
 *   ICC_ActivityStat of type COM_DT_ICC_ActivityStat
 *   ICC_AoIStat of type COM_DT_ICC_AoIStat
 *   ICC_DistLvlStat of type COM_DT_ICC_DistLvlStat
 *   ICC_DrwsLvlStat of type COM_DT_ICC_DrwsLvlStat
 *   ICC_EyeStat of type COM_DT_ICC_EyeStat
 *   ICC_FaceDetectStat of type COM_DT_ICC_FaceDetectStat
 *   ICC_FaceFakeStat of type COM_DT_ICC_FaceFakeStat
 *   ICC_HS_AlvCnt4Val of type COM_DT_ICC_HS_AlvCnt4Val
 *   ICC_HS_Crc4Val of type COM_DT_ICC_HS_Crc4Val
 *   ICC_IntvDrwsLvlStat of type COM_DT_ICC_IntvDrwsLvlStat
 *   ICC_IntvSDLvlStat of type COM_DT_ICC_IntvSDLvlStat
 *   ICC_IntvStat of type COM_DT_ICC_IntvStat
 *   ICC_LeftEyeOpenStat of type COM_DT_ICC_LeftEyeOpenStat
 *   ICC_RightEyeOpenStat of type COM_DT_ICC_RightEyeOpenStat
 *   ICC_TalkStat of type COM_DT_ICC_TalkStat
 *   ICC_YawnStat of type COM_DT_ICC_YawnStat
 * COM_DT_SG_ICSC_02_100ms_SignalGroup: Record with elements
 *   DMIC_IndEngModSta of type COM_DT_DMIC_IndEngModSta
 *   DMIC_AwdFltSta of type COM_DT_DMIC_AwdFltSta
 *   DMIC_AwdModSta of type COM_DT_DMIC_AwdModSta
 *   DMIC_DrvMod2Typ of type COM_DT_DMIC_DrvMod2Typ
 *   DMIC_DrvModFltSta of type COM_DT_DMIC_DrvModFltSta
 *   DMIC_DrvModSta of type COM_DT_DMIC_DrvModSta
 *   DMIC_DrvModTyp of type COM_DT_DMIC_DrvModTyp
 *   DMIC_EcsFltSta of type COM_DT_DMIC_EcsFltSta
 *   DMIC_EcsModSta of type COM_DT_DMIC_EcsModSta
 *   DMIC_ElsdFltSta of type COM_DT_DMIC_ElsdFltSta
 *   DMIC_ElsdModSta of type COM_DT_DMIC_ElsdModSta
 *   DMIC_EngFltSta of type COM_DT_DMIC_EngFltSta
 *   DMIC_EngModSta of type COM_DT_DMIC_EngModSta
 *   DMIC_EscFltSta of type COM_DT_DMIC_EscFltSta
 *   DMIC_EscModSta of type COM_DT_DMIC_EscModSta
 *   DMIC_EsndFltSta of type COM_DT_DMIC_EsndFltSta
 *   DMIC_EsndModSta of type COM_DT_DMIC_EsndModSta
 *   DMIC_IndAccSenSta of type COM_DT_DMIC_IndAccSenSta
 *   DMIC_IndAwdModSta of type COM_DT_DMIC_IndAwdModSta
 *   DMIC_IndDecSenSta of type COM_DT_DMIC_IndDecSenSta
 *   DMIC_IndEcsModSta of type COM_DT_DMIC_IndEcsModSta
 *   DMIC_IndElsdModSta of type COM_DT_DMIC_IndElsdModSta
 *   DMIC_IndEscModSta of type COM_DT_DMIC_IndEscModSta
 *   DMIC_IndEsndModSta of type COM_DT_DMIC_IndEsndModSta
 *   DMIC_IndMaxVehSpdSta of type COM_DT_DMIC_IndMaxVehSpdSta
 *   DMIC_IndMdpsModSta of type COM_DT_DMIC_IndMdpsModSta
 *   DMIC_IndMtrPwrSta of type COM_DT_DMIC_IndMtrPwrSta
 *   DMIC_IndPrflModSta of type COM_DT_DMIC_IndPrflModSta
 *   DMIC_IndRevModSta of type COM_DT_DMIC_IndRevModSta
 *   DMIC_IndRwsModSta of type COM_DT_DMIC_IndRwsModSta
 *   DMIC_IndTmModSta of type COM_DT_DMIC_IndTmModSta
 *   DMIC_IndVcuModSta of type COM_DT_DMIC_IndVcuModSta
 *   DMIC_IndWhlDrvSta of type COM_DT_DMIC_IndWhlDrvSta
 *   DMIC_MdpsFltSta of type COM_DT_DMIC_MdpsFltSta
 *   DMIC_MdpsModSta of type COM_DT_DMIC_MdpsModSta
 *   DMIC_PrflFltSta of type COM_DT_DMIC_PrflFltSta
 *   DMIC_PrflModSta of type COM_DT_DMIC_PrflModSta
 *   DMIC_RevFltSta of type COM_DT_DMIC_RevFltSta
 *   DMIC_RevModSta of type COM_DT_DMIC_RevModSta
 *   DMIC_RwsFltSta of type COM_DT_DMIC_RwsFltSta
 *   DMIC_RwsModSta of type COM_DT_DMIC_RwsModSta
 *   DMIC_SmtShftModSta of type COM_DT_DMIC_SmtShftModSta
 *   DMIC_TmFltSta of type COM_DT_DMIC_TmFltSta
 *   DMIC_TmModSta of type COM_DT_DMIC_TmModSta
 *   DMIC_VcuFltSta of type COM_DT_DMIC_VcuFltSta
 *   DMIC_VcuModSta of type COM_DT_DMIC_VcuModSta
 *   ICSC_AlvCnt2Val of type COM_DT_ICSC_AlvCnt2Val
 *   ICSC_Crc2Val of type COM_DT_ICSC_Crc2Val
 * COM_DT_SG_ICU_02_200ms_SignalGroup: Record with elements
 *   ICU_AlvCnt2Val of type COM_DT_ICU_AlvCnt2Val
 *   ICU_Crc2Val of type COM_DT_ICU_Crc2Val
 *   ICU_MtGearPosRSta of type COM_DT_ICU_MtGearPosRSta
 *   Warn_AsstDrSwSta of type COM_DT_Warn_AsstDrSwSta
 *   Warn_DrvDrSwSta of type COM_DT_Warn_DrvDrSwSta
 *   Warn_DrvStBltSwSta of type COM_DT_Warn_DrvStBltSwSta
 *   Warn_RrLftDrSwSta of type COM_DT_Warn_RrLftDrSwSta
 *   Warn_RrRtDrSwSta of type COM_DT_Warn_RrRtDrSwSta
 *   Autocut_DlvryModSta of type COM_DT_Autocut_DlvryModSta
 *   DoorLock_AsstDrUnLkSta of type COM_DT_DoorLock_AsstDrUnLkSta
 *   DoorLock_DrvKeyLkSwSta of type COM_DT_DoorLock_DrvKeyLkSwSta
 *   DoorLock_DrvKeyUnLkSwSta of type COM_DT_DoorLock_DrvKeyUnLkSwSta
 *   DoorLock_RrLftDrUnLkSta of type COM_DT_DoorLock_RrLftDrUnLkSta
 *   DoorLock_RrRtDrUnLkSta of type COM_DT_DoorLock_RrRtDrUnLkSta
 *   ICU_Haptic_OPT of type COM_DT_ICU_Haptic_OPT
 *   Warn_AsstStBltSwSta of type COM_DT_Warn_AsstStBltSwSta
 *   Warn_BrkFldSwSta of type COM_DT_Warn_BrkFldSwSta
 *   Warn_HoodSwMemorySta of type COM_DT_Warn_HoodSwMemorySta
 *   Warn_HoodSwSta of type COM_DT_Warn_HoodSwSta
 *   Warn_PassStOccSta of type COM_DT_Warn_PassStOccSta
 *   Warn_PrkngBrkSwSta of type COM_DT_Warn_PrkngBrkSwSta
 *   Warn_RrCtrStBltSwSta of type COM_DT_Warn_RrCtrStBltSwSta
 *   Warn_RrLftStBltSwSta of type COM_DT_Warn_RrLftStBltSwSta
 *   Warn_RrRtStBltSwSta of type COM_DT_Warn_RrRtStBltSwSta
 *   Warn_WshrFldSwSta of type COM_DT_Warn_WshrFldSwSta
 * COM_DT_SG_ICU_04_200ms_SignalGroup: Record with elements
 *   ExtLamp_HzrdSwSta of type COM_DT_ExtLamp_HzrdSwSta
 *   ICU_AlvCnt4Val of type COM_DT_ICU_AlvCnt4Val
 *   ICU_Crc4Val of type COM_DT_ICU_Crc4Val
 *   ICU_HDPSpprtRdy of type COM_DT_ICU_HDPSpprtRdy
 *   IntLamp_InlTailLmpSta of type COM_DT_IntLamp_InlTailLmpSta
 *   Lamp_LedHdLmpSta of type COM_DT_Lamp_LedHdLmpSta
 *   Lamp_TrnSigLmpLftActiveSt of type COM_DT_Lamp_TrnSigLmpLftActiveSt
 *   Lamp_TrnSigLmpLftOnReq of type COM_DT_Lamp_TrnSigLmpLftOnReq
 *   Lamp_TrnSigLmpRtActiveSt of type COM_DT_Lamp_TrnSigLmpRtActiveSt
 *   Lamp_TrnSigLmpRtOnReq of type COM_DT_Lamp_TrnSigLmpRtOnReq
 *   TrnLmpSeqEnblCmd of type COM_DT_TrnLmpSeqEnblCmd
 * COM_DT_SG_ICU_07_200ms_SignalGroup: Record with elements
 *   ExtLamp_TrnSigLmpLftSwSta of type COM_DT_ExtLamp_TrnSigLmpLftSwSta
 *   ExtLamp_TrnSigLmpRtSwSta of type COM_DT_ExtLamp_TrnSigLmpRtSwSta
 *   ChildLock_ActnFlSta of type COM_DT_ChildLock_ActnFlSta
 *   ICU_AlvCnt7Val of type COM_DT_ICU_AlvCnt7Val
 *   ICU_Crc7Val of type COM_DT_ICU_Crc7Val
 *   Lamp_LaneChgTrnSigLftSwSta_ICU of type COM_DT_Lamp_LaneChgTrnSigLftSwSta_ICU
 *   Lamp_LaneChgTrnSigRtSwSta_ICU of type COM_DT_Lamp_LaneChgTrnSigRtSwSta_ICU
 *   USM_FuncForMdLmpBrgtSta of type COM_DT_USM_FuncForMdLmpBrgtSta
 * COM_DT_SG_IEB_01_10ms_SignalGroup: Record with elements
 *   IEB_StrkDpthmmVal of type COM_DT_IEB_StrkDpthmmVal
 *   IEB_AbsNGearReq of type COM_DT_IEB_AbsNGearReq
 *   IEB_ActvSta of type COM_DT_IEB_ActvSta
 *   IEB_AlvCnt1Val of type COM_DT_IEB_AlvCnt1Val
 *   IEB_BrkActvSta of type COM_DT_IEB_BrkActvSta
 *   IEB_BzrSta of type COM_DT_IEB_BzrSta
 *   IEB_Crc1Val of type COM_DT_IEB_Crc1Val
 *   IEB_DfctvSta of type COM_DT_IEB_DfctvSta
 *   IEB_DiagSta of type COM_DT_IEB_DiagSta
 *   IEB_DriftModeActSta of type COM_DT_IEB_DriftModeActSta
 *   IEB_DriftModeSta of type COM_DT_IEB_DriftModeSta
 *   IEB_DrvWhlSlipFlg_Frnt of type COM_DT_IEB_DrvWhlSlipFlg_Frnt
 *   IEB_EstBrkPdlValVldSta of type COM_DT_IEB_EstBrkPdlValVldSta
 *   IEB_EstBrkSacFrcNmVal of type COM_DT_IEB_EstBrkSacFrcNmVal
 *   IEB_EstDpthPcVal of type COM_DT_IEB_EstDpthPcVal
 *   IEB_EstTtlBrkFrcNmVal of type COM_DT_IEB_EstTtlBrkFrcNmVal
 *   IEB_InhbtTrnstnTo4wd_Req of type COM_DT_IEB_InhbtTrnstnTo4wd_Req
 *   IEB_MILReq of type COM_DT_IEB_MILReq
 *   IEB_PdlCalibSta of type COM_DT_IEB_PdlCalibSta
 *   IEB_PdlTrvlSnsrFailSta of type COM_DT_IEB_PdlTrvlSnsrFailSta
 *   IEB_RbsWrngLmpSta of type COM_DT_IEB_RbsWrngLmpSta
 *   IEB_RegenTqLimitNmVal_Frnt of type COM_DT_IEB_RegenTqLimitNmVal_Frnt
 *   IEB_RegenTqLimitNmVal_Rear of type COM_DT_IEB_RegenTqLimitNmVal_Rear
 *   IEB_RSC_Req of type COM_DT_IEB_RSC_Req
 *   IEB_SnsrFailSta of type COM_DT_IEB_SnsrFailSta
 *   IEB_SrvLmpDis of type COM_DT_IEB_SrvLmpDis
 *   IEB_Sta of type COM_DT_IEB_Sta
 *   IEB_StrkDpthPcVal of type COM_DT_IEB_StrkDpthPcVal
 *   IEB_TCS_Req of type COM_DT_IEB_TCS_Req
 *   IEB_VacSysDfctvSta of type COM_DT_IEB_VacSysDfctvSta
 *   IEB_WrngLmpDis of type COM_DT_IEB_WrngLmpDis
 *   RSC_TqFlag_Frnt of type COM_DT_RSC_TqFlag_Frnt
 *   RSC_TqFlag_Rear of type COM_DT_RSC_TqFlag_Rear
 *   RSC_TqIntrvntnVal_Frnt of type COM_DT_RSC_TqIntrvntnVal_Frnt
 *   RSC_TqIntrvntnVal_Rear of type COM_DT_RSC_TqIntrvntnVal_Rear
 *   TCS_MtrTrgtRpm_Flag_Frnt of type COM_DT_TCS_MtrTrgtRpm_Flag_Frnt
 *   TCS_MtrTrgtRpm_Flag_Rear of type COM_DT_TCS_MtrTrgtRpm_Flag_Rear
 *   TCS_MtrTrgtRpm_Frnt of type COM_DT_TCS_MtrTrgtRpm_Frnt
 *   TCS_MtrTrgtRpm_Rear of type COM_DT_TCS_MtrTrgtRpm_Rear
 *   TCS_TqFlag_Frnt of type COM_DT_TCS_TqFlag_Frnt
 *   TCS_TqFlag_Rear of type COM_DT_TCS_TqFlag_Rear
 *   TCS_TqIntrvntnVal_Frnt of type COM_DT_TCS_TqIntrvntnVal_Frnt
 *   TCS_TqIntrvntnVal_Rear of type COM_DT_TCS_TqIntrvntnVal_Rear
 * COM_DT_SG_IMU_01_10ms_SignalGroup: Record with elements
 *   IMU_AcuRstSta of type COM_DT_IMU_AcuRstSta
 *   IMU_AlvCnt1Val of type COM_DT_IMU_AlvCnt1Val
 *   IMU_Crc1Val of type COM_DT_IMU_Crc1Val
 *   IMU_LatAccelSigSta of type COM_DT_IMU_LatAccelSigSta
 *   IMU_LatAccelVal of type COM_DT_IMU_LatAccelVal
 *   IMU_LongAccelSigSta of type COM_DT_IMU_LongAccelSigSta
 *   IMU_LongAccelVal of type COM_DT_IMU_LongAccelVal
 *   IMU_McuVoltSta of type COM_DT_IMU_McuVoltSta
 *   IMU_RollRtVal of type COM_DT_IMU_RollRtVal
 *   IMU_RollSigSta of type COM_DT_IMU_RollSigSta
 *   IMU_SeralNumVal of type COM_DT_IMU_SeralNumVal
 *   IMU_SnsrTempVal of type COM_DT_IMU_SnsrTempVal
 *   IMU_SnsrTyp of type COM_DT_IMU_SnsrTyp
 *   IMU_VerAccelSigSta of type COM_DT_IMU_VerAccelSigSta
 *   IMU_VerAccelVal of type COM_DT_IMU_VerAccelVal
 *   IMU_YawRtVal of type COM_DT_IMU_YawRtVal
 *   IMU_YawSigSta of type COM_DT_IMU_YawSigSta
 * COM_DT_SG_MDPS_01_10ms_SignalGroup: Record with elements
 *   MDPS_AlvCnt1Val of type COM_DT_MDPS_AlvCnt1Val
 *   MDPS_Crc1Val of type COM_DT_MDPS_Crc1Val
 *   MDPS_LkaPlgInSta of type COM_DT_MDPS_LkaPlgInSta
 *   MDPS_LkaToiActvSta of type COM_DT_MDPS_LkaToiActvSta
 *   MDPS_LkaToiUnblSta of type COM_DT_MDPS_LkaToiUnblSta
 *   MDPS_LkaToiFltSta of type COM_DT_MDPS_LkaToiFltSta
 *   MDPS_PaModeSta of type COM_DT_MDPS_PaModeSta
 *   MDPS_StrTqSnsrVal of type COM_DT_MDPS_StrTqSnsrVal
 *   MDPS_ADAS_AciFltSig of type COM_DT_MDPS_ADAS_AciFltSig
 *   MDPS_ADAS_AciFltSig_Lv2 of type COM_DT_MDPS_ADAS_AciFltSig_Lv2
 *   MDPS_ADASAciActvSta of type COM_DT_MDPS_ADASAciActvSta
 *   MDPS_ADASAciActvSta_Lv2 of type COM_DT_MDPS_ADASAciActvSta_Lv2
 *   MDPS_CurrModVal of type COM_DT_MDPS_CurrModVal
 *   MDPS_EngIdleRpmReq of type COM_DT_MDPS_EngIdleRpmReq
 *   MDPS_EstStrAnglVal of type COM_DT_MDPS_EstStrAnglVal
 *   MDPS_HDPSpprtSWVer of type COM_DT_MDPS_HDPSpprtSWVer
 *   MDPS_LkaFailSta of type COM_DT_MDPS_LkaFailSta
 *   MDPS_LoamModSta of type COM_DT_MDPS_LoamModSta
 *   MDPS_OutTqVal of type COM_DT_MDPS_OutTqVal
 *   MDPS_PaCanfltSta of type COM_DT_MDPS_PaCanfltSta
 *   MDPS_PaPlugInSta of type COM_DT_MDPS_PaPlugInSta
 *   MDPS_PaStrAnglVal of type COM_DT_MDPS_PaStrAnglVal
 *   MDPS_Typ of type COM_DT_MDPS_Typ
 *   MDPS_VsmActResp of type COM_DT_MDPS_VsmActResp
 *   MDPS_VsmDfctvSta of type COM_DT_MDPS_VsmDfctvSta
 *   MDPS_VsmPlgInSta of type COM_DT_MDPS_VsmPlgInSta
 *   MDPS_VsmSigErrSta of type COM_DT_MDPS_VsmSigErrSta
 *   MDPS_WrngLmpSta of type COM_DT_MDPS_WrngLmpSta
 * COM_DT_SG_MFSW_01_200ms_SignalGroup: Record with elements
 *   Lamp_FrFogLmpSwSta of type COM_DT_Lamp_FrFogLmpSwSta
 *   Lamp_HdLmpHiSwSta of type COM_DT_Lamp_HdLmpHiSwSta
 *   Lamp_LaneChgTrnSigLftSwSta of type COM_DT_Lamp_LaneChgTrnSigLftSwSta
 *   Lamp_LaneChgTrnSigRtSwSta of type COM_DT_Lamp_LaneChgTrnSigRtSwSta
 *   Lamp_LtSwSta of type COM_DT_Lamp_LtSwSta
 *   Lamp_PassingLmpSwSta of type COM_DT_Lamp_PassingLmpSwSta
 *   Lamp_RrFogLmpSwSta of type COM_DT_Lamp_RrFogLmpSwSta
 *   Lamp_TrnSigLftSwSta of type COM_DT_Lamp_TrnSigLftSwSta
 *   Lamp_TrnSigRtSwSta of type COM_DT_Lamp_TrnSigRtSwSta
 *   Lamp_TrnSigSwNtrlSta of type COM_DT_Lamp_TrnSigSwNtrlSta
 *   MFSW_AlvCnt1Val of type COM_DT_MFSW_AlvCnt1Val
 *   MFSW_Crc1Val of type COM_DT_MFSW_Crc1Val
 * COM_DT_SG_SAS_01_10ms_SignalGroup: Record with elements
 *   SAS_AlvCnt1Val of type COM_DT_SAS_AlvCnt1Val
 *   SAS_AnglVal of type COM_DT_SAS_AnglVal
 *   SAS_Crc1Val of type COM_DT_SAS_Crc1Val
 *   SAS_IntSta of type COM_DT_SAS_IntSta
 *   SAS_SpdVal of type COM_DT_SAS_SpdVal
 * COM_DT_SG_SMK_02_200ms_SignalGroup: Record with elements
 *   SMK_AccInSta of type COM_DT_SMK_AccInSta
 *   SMK_AccRlySta of type COM_DT_SMK_AccRlySta
 *   SMK_AlvCnt2Val of type COM_DT_SMK_AlvCnt2Val
 *   SMK_AuthSta of type COM_DT_SMK_AuthSta
 *   SMK_CLUAccIndOnReq of type COM_DT_SMK_CLUAccIndOnReq
 *   SMK_Crc2Val of type COM_DT_SMK_Crc2Val
 *   SMK_Ign1InSta of type COM_DT_SMK_Ign1InSta
 *   SMK_Ign1RlySta of type COM_DT_SMK_Ign1RlySta
 *   SMK_Ign2InSta of type COM_DT_SMK_Ign2InSta
 *   SMK_Ign2RlySta of type COM_DT_SMK_Ign2RlySta
 *   SMK_RmtKeyCrnkModSta of type COM_DT_SMK_RmtKeyCrnkModSta
 *   SMK_RmtKeyEngRunSta of type COM_DT_SMK_RmtKeyEngRunSta
 *   SMK_SCULckUnlckSta of type COM_DT_SMK_SCULckUnlckSta
 *   SMK_StrtFdbckSta of type COM_DT_SMK_StrtFdbckSta
 *   SMK_StrtrRlyOutSta of type COM_DT_SMK_StrtrRlyOutSta
 *   SMK_TlCrnkModSta of type COM_DT_SMK_TlCrnkModSta
 *   SMK_TlEngRunSta of type COM_DT_SMK_TlEngRunSta
 *   SMK_TrmnlCtrlSta of type COM_DT_SMK_TrmnlCtrlSta
 *   SMK_TrmnlMngrSta of type COM_DT_SMK_TrmnlMngrSta
 *   SMK_VDModeActSta of type COM_DT_SMK_VDModeActSta
 *   SSB_StrtStpBtnSw1Sta of type COM_DT_SSB_StrtStpBtnSw1Sta
 *   SSB_StrtStpBtnSw2Sta of type COM_DT_SSB_StrtStpBtnSw2Sta
 * COM_DT_SG_SWRC_03_20ms_SignalGroup: Record with elements
 *   SWRC_CrsSwSta of type COM_DT_SWRC_CrsSwSta
 *   SWRC_AlvCnt3Val of type COM_DT_SWRC_AlvCnt3Val
 *   SWRC_Crc3Val of type COM_DT_SWRC_Crc3Val
 *   SWRC_CrsMainSwSta of type COM_DT_SWRC_CrsMainSwSta
 *   SWRC_HDPSpprtSWVer of type COM_DT_SWRC_HDPSpprtSWVer
 *   SWRC_HdpSwSta of type COM_DT_SWRC_HdpSwSta
 *   SWRC_Info of type COM_DT_SWRC_Info
 *   SWRC_LFASwSta of type COM_DT_SWRC_LFASwSta
 *   SWRC_PaddleDnSwSta of type COM_DT_SWRC_PaddleDnSwSta
 *   SWRC_PaddleUpSwSta of type COM_DT_SWRC_PaddleUpSwSta
 *   SWRC_SldMainSwSta of type COM_DT_SWRC_SldMainSwSta
 * COM_DT_SG_TCU_01_10ms_SignalGroup: Record with elements
 *   TCU_AlvCnt1Val of type COM_DT_TCU_AlvCnt1Val
 *   TCU_Crc1Val of type COM_DT_TCU_Crc1Val
 *   TCU_GearSlctDis of type COM_DT_TCU_GearSlctDis
 *   DCT_CltchState of type COM_DT_DCT_CltchState
 *   DCT_CrpTqReq of type COM_DT_DCT_CrpTqReq
 *   DCT_EngIdleReq of type COM_DT_DCT_EngIdleReq
 *   DCT_FuelCutReq of type COM_DT_DCT_FuelCutReq
 *   DCT_RegenInhbt of type COM_DT_DCT_RegenInhbt
 *   DCT_ShftTqReq of type COM_DT_DCT_ShftTqReq
 *   DCT_TqIncReq of type COM_DT_DCT_TqIncReq
 *   IMT_CltchPdlPos of type COM_DT_IMT_CltchPdlPos
 *   IMT_DisCmd of type COM_DT_IMT_DisCmd
 *   IMT_EOLstate of type COM_DT_IMT_EOLstate
 *   TCH_EngTrgtGearSta of type COM_DT_TCH_EngTrgtGearSta
 *   TCU_BrkOnReq of type COM_DT_TCU_BrkOnReq
 *   TCU_CdaInhbtReq of type COM_DT_TCU_CdaInhbtReq
 *   TCU_CluTrgtGearConfg of type COM_DT_TCU_CluTrgtGearConfg
 *   TCU_CluTrgtGearSta of type COM_DT_TCU_CluTrgtGearSta
 *   TCU_CurrGearSta of type COM_DT_TCU_CurrGearSta
 *   TCU_DcmlVehSpdKphVal of type COM_DT_TCU_DcmlVehSpdKphVal
 *   TCU_DrvngModDis of type COM_DT_TCU_DrvngModDis
 *   TCU_DrvngModReq of type COM_DT_TCU_DrvngModReq
 *   TCU_EngRpmDis of type COM_DT_TCU_EngRpmDis
 *   TCU_EngRpmDisSta of type COM_DT_TCU_EngRpmDisSta
 *   TCU_EngSpdIncReq of type COM_DT_TCU_EngSpdIncReq
 *   TCU_EngTqIncReqVal of type COM_DT_TCU_EngTqIncReqVal
 *   TCU_EngTqLimVal of type COM_DT_TCU_EngTqLimVal
 *   TCU_EPBReq of type COM_DT_TCU_EPBReq
 *   TCU_FrtStcShftSta of type COM_DT_TCU_FrtStcShftSta
 *   TCU_FuelCutInhbtReq of type COM_DT_TCU_FuelCutInhbtReq
 *   TCU_GearLmpBlnkngReq of type COM_DT_TCU_GearLmpBlnkngReq
 *   TCU_GearShftSta of type COM_DT_TCU_GearShftSta
 *   TCU_GearStepTyp of type COM_DT_TCU_GearStepTyp
 *   TCU_IdleUpReq of type COM_DT_TCU_IdleUpReq
 *   TCU_IsgInhbtReq of type COM_DT_TCU_IsgInhbtReq
 *   TCU_LupTrgtEngSpdVal of type COM_DT_TCU_LupTrgtEngSpdVal
 *   TCU_NetrlCtrlSta of type COM_DT_TCU_NetrlCtrlSta
 *   TCU_ObdSta of type COM_DT_TCU_ObdSta
 *   TCU_ShftPtrnSta of type COM_DT_TCU_ShftPtrnSta
 *   TCU_SlpVal of type COM_DT_TCU_SlpVal
 *   TCU_SmrtShftSta of type COM_DT_TCU_SmrtShftSta
 *   TCU_SprkRtrdReq of type COM_DT_TCU_SprkRtrdReq
 *   TCU_SprtyIndxSta of type COM_DT_TCU_SprtyIndxSta
 *   TCU_TqCnvrtrSta of type COM_DT_TCU_TqCnvrtrSta
 *   TCU_TqGrdntLimVal of type COM_DT_TCU_TqGrdntLimVal
 *   TCU_TqRdctnVal of type COM_DT_TCU_TqRdctnVal
 *   TCU_TrgtGearSta of type COM_DT_TCU_TrgtGearSta
 *   TCU_Typ of type COM_DT_TCU_Typ
 *   TCU_VehSpdKphVal of type COM_DT_TCU_VehSpdKphVal
 *   TCU_VgisInhbtReq of type COM_DT_TCU_VgisInhbtReq
 * COM_DT_SG_WHL_01_10ms_SignalGroup: Record with elements
 *   WHL_AlvCnt1Val of type COM_DT_WHL_AlvCnt1Val
 *   WHL_Crc1Val of type COM_DT_WHL_Crc1Val
 *   WHL_PlsFLVal of type COM_DT_WHL_PlsFLVal
 *   WHL_PlsFRVal of type COM_DT_WHL_PlsFRVal
 *   WHL_PlsRLVal of type COM_DT_WHL_PlsRLVal
 *   WHL_PlsRRVal of type COM_DT_WHL_PlsRRVal
 *   WHL_SpdFLVal of type COM_DT_WHL_SpdFLVal
 *   WHL_SpdFRVal of type COM_DT_WHL_SpdFRVal
 *   WHL_SpdRLVal of type COM_DT_WHL_SpdRLVal
 *   WHL_SpdRRVal of type COM_DT_WHL_SpdRRVal
 *   WHL_DirFLVal of type COM_DT_WHL_DirFLVal
 *   WHL_DirFRVal of type COM_DT_WHL_DirFRVal
 *   WHL_DirRLVal of type COM_DT_WHL_DirRLVal
 *   WHL_DirRRVal of type COM_DT_WHL_DirRRVal
 *   WHL_SpdCalParmtr of type COM_DT_WHL_SpdCalParmtr
 * CVD_VehicleTrackWidths: Record with elements
 *   RecordElement of type Rte_DT_CVD_VehicleTrackWidths_0
 * CoFcaEDR_t: Record with elements
 *   EgoVeh_Speed of type uint16
 *   TTC of type uint8
 *   RelativeVelocity of type uint16
 *   LongDistance of type uint16
 *   LatDistance of type uint16
 * CoFcaFrCmrOut_t: Record with elements
 *   FCA_Equip_FR_CMR of type uint8
 * CoFcaOutput_t: Record with elements
 *   FCA_FrOnOffEquipSta of type uint8
 *   FCA_SysFlrSta of type uint8
 *   FCA_WrngLvlSta of type uint8
 *   FCA_VehStpReq of type uint8
 *   FCA_StbltActvReq of type uint8
 *   FCA_HydrlcBstAsstReq of type uint8
 *   FCA_DclReqVal of type uint8
 *   FCA_PrefillActvReq of type uint8
 *   FCA_PartialActvReq of type uint8
 *   FCA_FullActvReq of type uint8
 *   FCA_WarnTimeSta of type uint8
 *   FCA_WrngSndSta of type uint8
 *   FCA_RelVel of type uint16
 *   FCA_TimetoCllsn of type uint8
 *   FCA_WrngTrgtDis of type uint8
 *   ADAS_TrlOffStaDisp of type uint8
 *   FCA_Regulation of type uint8
 *   ADAS_InhbtOffDispSta of type uint8
 * CvdInputData_t: Record with elements
 *   CvdIn_WheelSpeedFL of type uint16
 *   CvdIn_WheelSpeedFR of type uint16
 *   CvdIn_WheelSpeedRL of type uint16
 *   CvdIn_WheelSpeedRR of type uint16
 *   CvdIn_VehicleVelocity of type uint16
 *   CvdIn_VehicleVelocityUnitType of type uint8
 *   CvdIn_VehicleVelocityValid of type uint8
 *   CvdIn_SensorYawRate of type uint16
 *   CvdIn_BrakeLight of type uint8
 *   CvdIn_BrakePressure of type uint16
 *   CvdIn_GearboxState of type uint8
 *   CvdIn_DrivingDirection of type uint8
 * CvdOutputData_t: Record with elements
 *   CvdOut_OffsetCompensatedYawRate of type uint16
 *   CvdOut_OffsetCheckOk of type uint8
 * Cvd_TrackWidthInput_t: Record with elements
 *   TrackWidth_Front_f32 of type float32
 *   TrackWidth_Rear_f32 of type float32
 * DawInput_t: Record with elements
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_HDA_LFA_SymSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_DrvAlrtDis of type uint8
 * DawOutput_t: Record with elements
 *   u8_DAW_Status of type uint8
 *   u8_DAW_Warn of type uint8
 *   u8_LVDA_Display of type uint8
 *   u8_LVDA_USM of type uint8
 * EDR_InputData: Record with elements
 *   Odometer_u32 of type uint32
 *   VehicleSpeed_u16 of type uint16
 *   TTC_u8 of type uint8
 *   FCA_WrngTrgtDis_u8 of type uint8
 *   Relative_Velocity_u16 of type uint16
 *   Req_Deceleration_u16 of type uint16
 *   MasterCycl_Pressureu16 of type uint16
 *   Steering_Angle_s16 of type sint16
 *   Long_Accel_u16 of type uint16
 *   WarningStatus_u8 of type uint8
 *   FCA_Control_u8 of type uint8
 *   DBS_requested_Info_u8 of type uint8
 *   DBS_Control_u8 of type uint8
 *   FCA_System_Status_u8 of type uint8
 *   FCA_SensorFusion_Status_u8 of type uint8
 *   FCA_Camera_Status_u8 of type uint8
 *   TurnSignal_Left_u8 of type uint8
 *   TurnSignal_Right_u8 of type uint8
 *   Driver_Accel_Braking_Status_u8 of type uint8
 *   Drvr_Accel_PedPressure_u16 of type uint16
 *   SteeringAng_Velocity_u8 of type uint8
 *   Longitudinal_Distance_u16 of type uint16
 *   Lateral_Distance_u16 of type uint16
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FcaEDR_t: Record with elements
 *   EgoVeh_Speed of type uint16
 *   TTC of type uint8
 *   RelativeVelocity of type uint16
 *   LongDistance of type uint16
 *   LatDistance of type uint16
 * FcaFailSafeInfoTrailerMsgTout_t: Record with elements
 *   u8_TrailerMsgTout of type uint8
 * FcaFrCmrOut_t: Record with elements
 *   FCA_Equip_FR_CMR of type uint8
 * FcaInput_t: Record with elements
 *   SCC_InfoDis of type uint8
 *   SCC_OpSta of type uint8
 * FcaOutput_t: Record with elements
 *   FCA_FrOnOffEquipSta of type uint8
 *   FCA_SysFlrSta of type uint8
 *   FCA_WrngLvlSta of type uint8
 *   FCA_VehStpReq of type uint8
 *   FCA_StbltActvReq of type uint8
 *   FCA_HydrlcBstAsstReq of type uint8
 *   FCA_DclReqVal of type uint8
 *   FCA_PrefillActvReq of type uint8
 *   FCA_PartialActvReq of type uint8
 *   FCA_FullActvReq of type uint8
 *   FCA_WarnTimeSta of type uint8
 *   FCA_WrngSndSta of type uint8
 *   FCA_RelVel of type uint16
 *   FCA_TimetoCllsn of type uint8
 *   FCA_WrngTrgtDis of type uint8
 *   ADAS_TrlOffStaDisp of type uint8
 *   FCA_Regulation of type uint8
 *   ADAS_InhbtOffDispSta of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 * FrCmrHdrObj_t: Record with elements
 *   OBJ_Header_CRC of type uint32
 *   OBJ_Protocol_Version of type uint8
 *   OBJ_Sync_ID of type uint8
 *   OBJ_VRU_Count of type uint8
 *   OBJ_VD_Count of type uint8
 *   OBJ_General_OBJ_Count of type uint8
 *   OBJ_Animal_Count of type uint8
 *   OBJ_VD_NIV_Left of type uint8
 *   OBJ_VD_NIV_Right of type uint8
 *   OBJ_VD_CIPV_ID of type uint8
 *   OBJ_VD_CIPV_Lost of type uint8
 *   OBJ_VD_Allow_Acc of type uint8
 *   OBJ_Is_Blocked_Left of type boolean
 *   OBJ_Is_Blocked_Right of type boolean
 * HKMC_ReleaseInfo_record: Record with elements
 *   HKMC_PartNumber of type HKMC_PartNumber_t
 *   SW_Version of type SW_Version_t
 *   HW_Version of type HW_Version_t
 *   Supplier_SW_Info of type Supplier_SW_Info_t
 *   Reserved of type Reserved_2
 * HbaOutput_t: Record with elements
 *   u8_HBA_Lamp of type uint8
 *   u8_HBA_SysState of type uint8
 *   u8_HBA_Opt of type uint8
 *   u8_HBA_OptUSM of type uint8
 * IslwInput_t: Record with elements
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u16_aReqValue of type uint16
 * IslwOutput_t: Record with elements
 *   u8_ISLW_Status of type uint8
 *   u8_ISLW_Spd_Dis_CLU_Main of type uint8
 *   u8_ISLW_Spd_Dis_NAVI_Main of type uint8
 *   u8_ISLA_SpdwOffst of type uint8
 *   u8_ISLA_SwIgnoreReq of type uint8
 *   u8_ISLA_SpdChgReq of type uint8
 *   u8_ISLA_SpdWrn of type uint8
 *   u8_ISLA_SymFlashMod of type uint8
 *   u8_ISLA_Popup of type uint8
 *   u8_ISLA_OptUsmSta of type uint8
 *   u8_ISLA_OffstUsmSta of type uint8
 *   u8_ISLA_Cntry of type uint8
 *   u8_ISLA_AddtnlSign of type uint8
 *   u8_ISLA_AutoSetSpdSta of type uint8
 *   u8_ISLA_CondInfoDisp of type uint8
 *   u8_ISLA_SndReqSta of type uint8
 *   u8_ISLA_NAOffstUSMSta of type uint8
 *   u8_ISLA_EUCntry1USMSta of type uint8
 *   u8_ISLA_EUCntry2USMSta of type uint8
 *   u8_ISLA_EUCntryVertyp of type uint8
 *   u8_ISLA_NACntry1USMSta of type uint8
 *   u8_ISLA_NACntry2USMSta of type uint8
 *   u8_ISLA_NACntryVertyp of type uint8
 *   u8_ISLA_SpdLimVal of type uint8
 *   u8_ISLA_TSRSpdLimEnfrcmtSta of type uint8
 * IvcHptOutput_t: Record with elements
 *   u8_HPT_StrWhlWarn1Sta of type uint8
 * IvcMv1Output_t: Record with elements
 *   u8_MV_DrvLnCtLnSta of type uint8
 *   u8_MV_LtLnSta of type uint8
 *   u8_MV_RtLnSta of type uint8
 *   u8_MV_DrvLnRdsVal of type uint8
 *   u8_MV_LtLnOffstVal of type uint8
 *   u8_MV_RtLnOffstVal of type uint8
 *   u8_MV_VehDstSta of type uint8
 *   u16_MV_VehDstVal of type uint16
 * IvcMv2Output_t: Record with elements
 *   u8_MV_HostVeh1Sta of type uint8
 *   u8_MV_FrObjSta of type uint8
 *   u16_MV_FrObjLongPosVal of type uint16
 *   s8_MV_FrObjLatPosVal of type sint8
 * IvcPuFOutput_t: Record with elements
 *   u8_PU_F_Group1_ADASWarn1_1Sta of type uint8
 *   u8_PU_F_Group1_ADASWarn1_2Sta of type uint8
 *   u8_PU_F_Group4_ADASWarn1_1Sta of type uint8
 *   u8_PU_F_Group7_FwdSftyFlrSta of type uint8
 *   u8_PU_F_Group7_LnSftyFlrSta of type uint8
 *   u8_PU_F_Group7_ISLA_FlrSta of type uint8
 *   u8_PU_F_Group7_DAW_FlrSta of type uint8
 *   u8_PU_F_Group7_HBA_FlrSta of type uint8
 *   u8_PU_F_Group7_SCC_FlrSta of type uint8
 *   u8_PU_F_Group7_LFA_FlrSta of type uint8
 *   u8_PU_F_Group7_HDA_FlrSta of type uint8
 *   u8_PU_F_Group7_MRM_FlrSta of type uint8
 *   u8_PU_F_Group7_DrvrAsstFlr1Sta of type uint8
 * IvcPuMOutput_t: Record with elements
 *   u8_PU_M_Group2_ADASWarn1_1Sta of type uint8
 * IvcSmvOutput_t: Record with elements
 *   u8_SMV_FrObjSta of type uint8
 *   u8_SMV_VehDstLvlVal of type uint8
 *   u8_SMV_VehDstLvlSta of type uint8
 *   u8_SMV_HostVehSta of type uint8
 *   u8_SMV_SetSpdSta of type uint8
 *   u8_SMV_SetSpdVal of type uint8
 *   u8_SMV_HDA_SymbSta of type uint8
 *   u8_SMV_ISLA_SetSpdSymbSta of type uint8
 *   u8_SMV_NSCC_SymbSta of type uint8
 *   u8_SMV_LFA_SymbSta of type uint8
 *   u8_SMV_DrvAsstHUDSymbSta of type uint8
 * IvcSndOutput_t: Record with elements
 *   u8_SND_ADASWarn1_1Sta of type uint8
 *   u8_SND_ADASWarn1_2Sta of type uint8
 *   u8_SND_ADASWarn1_3Sta of type uint8
 *   u8_SND_ADASWarn1_4Sta of type uint8
 *   u8_SND_ADASWarn1_5Sta of type uint8
 * IvcSymbStaOutput_t: Record with elements
 *   u8_TT_FwdSftySymbSta of type uint8
 *   u8_TT_LnSftySymbSta of type uint8
 *   u8_TT_DAW_SymbSta of type uint8
 *   u8_TT_HBA_SymbSta of type uint8
 * IvcTrffcSgnOutput_t: Record with elements
 *   u8_TT_ISLA_SpdLimTrffcSgnSta of type uint8
 *   u8_TT_ISLA_SpdLimTrffcSgnVal of type uint8
 *   u8_TT_ISLA_TrffcSgnCntryInfoSta of type uint8
 *   u8_TT_ISLA_AddtnlTrffcSgnSta of type uint8
 *   u8_TT_ISLA_SuppTrffcSgnSta of type uint8
 * IvcVarOutput_t: Record with elements
 *   u32_VAR_Opt1Sta of type uint32
 * LDW_t: Record with elements
 *   LDW_Suppression_Reason_Left of type uint32
 *   LDW_Suppression_Reason_Right of type uint32
 *   LDW_Time_To_Warning_Left of type float32
 *   LDW_Time_To_Warning_Right of type float32
 *   LDW_Warning_Status_Left of type uint8
 *   LDW_Warning_Status_Right of type uint8
 * LanesHost_t: Record with elements
 *   LH_CRC of type uint32
 *   LH_Is_Triggered_SDM_Type of type uint8
 *   LH_Is_Triggered_SDM_Model of type uint8
 *   LH_Track_ID of type uint8
 *   LH_Age of type uint8
 *   LH_Confidence of type uint8
 *   LH_Prediction_Reason of type uint8
 *   LH_Availability_State of type uint8
 *   LH_Color of type uint8
 *   LH_Color_Confidence of type uint8
 *   LH_Lanemark_Type of type uint8
 *   LH_DLM_Type of type uint8
 *   LH_DECEL_Type of type uint8
 *   LH_Lanemark_Type_Conf of type uint8
 *   LH_Side of type uint8
 *   LH_Crossing of type boolean
 *   LH_Marker_Width of type uint8
 *   LH_Marker_Width_STD of type uint8
 *   LH_Dash_Average_Available of type boolean
 *   LH_Dash_Average_Length of type uint8
 *   LH_Dash_Average_Gap of type uint8
 *   LH_Is_Multi_Clothoid of type boolean
 *   LH_Line_First_C0 of type float32
 *   LH_Line_First_C1 of type float32
 *   LH_Line_First_C2 of type float32
 *   LH_Line_First_C3 of type float32
 *   LH_First_VR_Start of type uint16
 *   LH_First_VR_End of type uint16
 *   LH_First_Measured_VR_End of type uint16
 *   LH_Second_Measured_VR_End of type uint16
 *   LH_Line_Second_C0 of type float32
 *   LH_Line_Second_C1 of type float32
 *   LH_Line_Second_C2 of type float32
 *   LH_Line_Second_C3 of type float32
 *   LH_Second_VR_Start of type uint16
 *   LH_Second_VR_End of type uint16
 *   LH_Is_Construction_Area of type boolean
 * LssInput_t: Record with elements
 *   b_Uds_LdwFuncValidCmd of type uint8
 *   u8_FCA_Status of type uint8
 *   u8_FCA_FailInfo of type uint8
 *   u8_ACCMode of type uint8
 *   u8_SCC_InfoDisplay of type uint8
 *   u8_SCC_VSetDis of type uint8
 *   u8_SCC_MainMode_ACC of type uint8
 *   u8_SCC_ACCFailInfo of type uint8
 * LssOutput_t: Record with elements
 *   u8_LKA_CF_Lkas_ActToi of type uint8
 *   u8_LKA_CF_Lkas_SysWarning of type uint8
 *   u8_LKA_CF_Lkas_ToiFlt of type uint8
 *   u16_LKA_CR_Lkas_StrToqReq of type uint16
 *   u8_LKA_OnOffEquip2Sta of type uint8
 *   u8_CF_LKA_HandsOff_Snd of type uint8
 *   u8_CF_LKA_SymbolState of type uint8
 *   u8_LKA_WarnSndUSMSta of type uint8
 *   u8_CF_HDA_Opt_USM of type uint8
 *   u8_CF_HDA_Mode of type uint8
 *   u8_CF_HDA_InfoDisplay of type uint8
 *   u8_CF_HDA_LFA_SteeringState of type uint8
 *   u8_CF_LKA_LaneRecogState of type uint8
 *   u8_CF_HDA_InfoDisplay2 of type uint8
 *   u8_CF_HDA_LFA_Wrn_Snd of type uint8
 *   u8_CF_LKA_LHWarning of type uint8
 *   u8_CF_LKA_RHWarning of type uint8
 *   u8_ADAS_Damping_Gain of type uint8
 *   u8_LKA_EmergencyRampDown of type uint8
 *   u8_CF_HDA_TDMRMDecelReq of type uint8
 * MeInputCommData_t: Record with elements
 *   VehicleSpeed_u16 of type uint16
 *   VehicleSpeedValid_u8 of type uint8
 *   YawRate_u16 of type uint16
 *   YawRateValid_u8 of type uint8
 *   LatAccel_u16 of type uint16
 *   LatAccelValid_u8 of type uint8
 *   WiperStatus_u8 of type uint8
 *   WiperStatusValid_u8 of type uint8
 *   ReverseIndicator_u8 of type uint8
 *   ReverseIndicatorValid_u8 of type uint8
 *   SteeringWheelAngle_s16 of type sint16
 *   SteeringWheelAngleValid_u8 of type uint8
 *   AccelPedalValue_u8 of type uint8
 *   AccelPedalValid_u8 of type uint8
 *   AccelRate_u16 of type uint16
 *   AccelRateValid_u8 of type uint8
 *   BrakePedalPressed_u8 of type uint8
 *   BrakePedalPressedValid_u8 of type uint8
 *   VehicleDisplaySpeed_u16 of type uint16
 *   VehicleDisplaySpeedValid_u8 of type uint8
 *   TurnSwitchStatus_u8 of type uint8
 *   HighBeamActive_u8 of type uint8
 *   FogLightActive_u8 of type uint8
 *   VehicleCode_u8 of type uint8
 *   fcaGapSensitivity_u8 of type uint8
 *   fcaGapSensitivityValid_u8 of type uint8
 *   pcwGapSensitivity_u8 of type uint8
 *   pcwGapSensitivityValid_u8 of type uint8
 * Objects_t: Record with elements
 *   OBJ_CRC of type uint32
 *   OBJ_ID of type uint8
 *   OBJ_VD_CIPVFlag of type uint8
 *   OBJ_Existence_Probability of type uint8
 *   OBJ_Fusion_Source of type uint16
 *   OBJ_Triggered_SDM of type uint8
 *   OBJ_Motion_Category of type uint8
 *   OBJ_Object_Age of type uint16
 *   OBJ_Measuring_Status of type uint8
 *   OBJ_Object_Class of type uint8
 *   OBJ_Class_Probability of type uint8
 *   OBJ_Camera_Source of type uint8
 *   OBJ_Motion_Status of type uint8
 *   OBJ_Motion_Orientation of type uint8
 *   OBJ_Has_Cut_Lane of type boolean
 *   OBJ_Has_Cut_Path of type boolean
 *   OBJ_Brake_Light_Validity of type boolean
 *   OBJ_Brake_Light of type boolean
 *   OBJ_Turn_Indicator_Right of type boolean
 *   OBJ_Turn_Indicator_Left of type boolean
 *   OBJ_Turn_Indicator_Validity of type boolean
 *   OBJ_Right_Out_Of_Image of type boolean
 *   OBJ_Left_Out_Of_Image of type boolean
 *   OBJ_Right_Out_Of_Image_V of type boolean
 *   OBJ_Left_Out_Of_Image_V of type boolean
 *   OBJ_Top_Out_Of_Image of type boolean
 *   OBJ_Bottom_Out_Of_Image of type boolean
 *   OBJ_Top_Out_Of_Image_V of type boolean
 *   OBJ_Bottom_Out_Of_Image_V of type boolean
 *   OBJ_Lane_Assignment of type uint8
 *   OBJ_Lane_Assignment_V of type boolean
 *   OBJ_Age_Seconds of type uint8
 *   OBJ_Age_Seconds_V of type boolean
 *   OBJ_Width of type uint16
 *   OBJ_Width_V of type boolean
 *   OBJ_Width_STD of type uint16
 *   OBJ_Width_STD_V of type boolean
 *   OBJ_Length of type uint16
 *   OBJ_Length_V of type boolean
 *   OBJ_Length_STD of type uint16
 *   OBJ_Length_STD_V of type boolean
 *   OBJ_Height of type uint16
 *   OBJ_Height_V of type boolean
 *   OBJ_Height_STD of type uint16
 *   OBJ_Height_STD_V of type boolean
 *   OBJ_Abs_Long_Velocity of type uint16
 *   OBJ_Abs_Long_Velocity_V of type boolean
 *   OBJ_Abs_Long_Velocity_STD of type uint16
 *   OBJ_Abs_Long_Vel_STD_V of type boolean
 *   OBJ_Abs_Lat_Velocity of type uint16
 *   OBJ_Abs_Lat_Velocity_V of type boolean
 *   OBJ_Abs_Lat_Velocity_STD of type uint16
 *   OBJ_Abs_Lat_Vel_STD_V of type boolean
 *   OBJ_Abs_Long_Acc of type uint16
 *   OBJ_Abs_Long_Acc_V of type boolean
 *   OBJ_Abs_Long_Acc_STD of type uint16
 *   OBJ_Abs_Long_Acc_STD_V of type boolean
 *   OBJ_Abs_Lat_Acc of type uint16
 *   OBJ_Abs_Lat_Acc_V of type boolean
 *   OBJ_Abs_Lat_Acc_STD of type uint16
 *   OBJ_Abs_Lat_Acc_STD_V of type boolean
 *   OBJ_Abs_Acceleration of type uint16
 *   OBJ_Abs_Acceleration_V of type boolean
 *   OBJ_Abs_Acc_STD of type uint16
 *   OBJ_Abs_Acc_STD_V of type boolean
 *   OBJ_Inv_TTC of type uint16
 *   OBJ_Inv_TTC_V of type boolean
 *   OBJ_Inv_TTC_STD of type uint16
 *   OBJ_Inv_TTC_STD_V of type boolean
 *   OBJ_Relative_Long_Acc of type uint16
 *   OBJ_Relative_Long_Acc_V of type boolean
 *   OBJ_Relative_Long_Acc_STD of type uint16
 *   OBJ_Rel_Long_Acc_STD_V of type boolean
 *   OBJ_Relative_Long_Velocity of type uint16
 *   OBJ_Relative_Long_Velocity_V of type boolean
 *   OBJ_Relative_Long_Vel_STD of type uint16
 *   OBJ_Rel_Long_Vel_STD_V of type boolean
 *   OBJ_Relative_Lat_Velocity of type uint16
 *   OBJ_Relative_Lat_Velocity_V of type boolean
 *   OBJ_Relative_Lat_Velocity_STD of type uint16
 *   OBJ_Rel_Lat_Vel_STD_V of type boolean
 *   OBJ_Long_Distance of type uint16
 *   OBJ_Long_Distance_V of type boolean
 *   OBJ_Long_Distance_STD of type uint16
 *   OBJ_Long_Distance_STD_V of type boolean
 *   OBJ_Lat_Distance of type uint16
 *   OBJ_Lat_Distance_V of type boolean
 *   OBJ_Lat_Distance_STD of type uint16
 *   OBJ_Lat_Distance_STD_V of type boolean
 *   OBJ_Absolute_Speed of type uint16
 *   OBJ_Absolute_Speed_V of type boolean
 *   OBJ_Absolute_Speed_STD of type uint16
 *   OBJ_Absolute_Speed_STD_V of type boolean
 *   OBJ_Heading of type uint16
 *   OBJ_Heading_V of type boolean
 *   OBJ_Heading_STD of type uint16
 *   OBJ_Heading_STD_V of type boolean
 *   OBJ_Angle_Rate_STD of type uint16
 *   OBJ_Angle_Rate_STD_V of type boolean
 *   OBJ_Angle_Rate of type uint16
 *   OBJ_Angle_Rate_V of type boolean
 *   OBJ_Angle_Right of type uint16
 *   OBJ_Angle_Right_V of type boolean
 *   OBJ_Angle_Right_STD of type uint16
 *   OBJ_Angle_Right_STD_V of type boolean
 *   OBJ_Angle_Left of type uint16
 *   OBJ_Angle_Left_V of type boolean
 *   OBJ_Angle_Left_STD of type uint16
 *   OBJ_Angle_Left_STD_V of type boolean
 *   OBJ_Angle_Side of type uint16
 *   OBJ_Angle_Side_V of type boolean
 *   OBJ_Angle_Side_STD of type uint16
 *   OBJ_Angle_Side_STD_V of type boolean
 *   OBJ_Angle_Mid_V of type boolean
 *   OBJ_Angle_Mid of type uint16
 *   OBJ_Angle_Mid_STD of type uint16
 *   OBJ_Angle_Mid_STD_V of type boolean
 *   OBJ_Angle_Bottom_V of type boolean
 *   OBJ_Angle_Bottom of type uint16
 *   OBJ_Angle_Bottom_STD of type uint16
 *   OBJ_Angle_Bottom_STD_V of type boolean
 *   OBJ_Visibility_Side_V of type boolean
 *   OBJ_Visibility_Side of type uint8
 *   OBJ_Is_In_Drivable_Area of type boolean
 *   OBJ_Is_In_Drivable_Area_V of type boolean
 *   OBJ_Is_VeryClose_V of type boolean
 *   OBJ_Is_VeryClose of type boolean
 *   OBJ_Is_EMERGENCY_VCL of type boolean
 *   OBJ_EMERGENCY_LIGHT_COLOR of type uint8
 *   OBJ_EMERGENCY_V of type boolean
 *   OBJ_Open_Door_Left of type boolean
 *   OBJ_Open_Door_Right of type boolean
 *   OBJ_Visible_Left_or_Right of type uint8
 *   OBJ_Visible_Left_or_Right_V of type boolean
 *   OBJ_2W_Is_Motorbike_Probability of type uint8
 *   OBJ_2W_Is_Bicycle_Probability of type uint8
 *   Obj_partially_in_lane of type boolean
 * SccInputFromVCan_t: Record with elements
 *   u8_HDA_CntrlModSta of type uint8
 *   u8_HDA_TDMRMDclReq of type uint8
 *   u8_ISLA_OptUsmSta of type uint8
 *   u8_ISLA_SpdwOffst of type uint8
 *   u8_ISLA_SwIgnoreReq of type uint8
 *   u8_ISLA_SpdChgReq of type uint8
 *   u8_ISLW_SpdCluMainDis of type uint8
 *   u8_ISLW_SysSta of type uint8
 * SccInput_t: Record with elements
 *   u8_HDA_CntrlModSta of type uint8
 *   u8_HDA_TDMRMDclReq of type uint8
 *   u8_ISLA_SpdwOffst of type uint8
 *   u8_ISLA_SwIgnoreReq of type uint8
 *   u8_ISLA_SpdChgReq of type uint8
 *   u8_FCA_PartialActvReq of type uint8
 *   u8_FCA_FullActvReq of type uint8
 *   u8_FCA_DclReqVal of type uint8
 *   u8_FCA_WrngLvlSta of type uint8
 *   u8_HDA_LFA_SymSta of type uint8
 *   u8_HDA_InfoPUDis of type uint8
 * SccOutput_t: Record with elements
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_DrvAlrtDis of type uint8
 *   u8_SCC_TakeoverReq of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u16_SCC_AccelReqVal of type uint16
 *   u16_SCC_AccelReqRawVal of type uint16
 *   u8_SCC_VehStpReq of type uint8
 *   u8_SCC_HeadwayDstSetVal of type uint8
 *   u8_SCC_AccelLimBandLwrVal of type uint8
 *   u8_SCC_AccelLimBandUppVal of type uint8
 *   u8_SCC_JrkLwrLimVal of type uint8
 *   u8_SCC_JrkUppLimVal of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u16_SCC_ObjDstVal of type uint16
 *   u16_SCC_ObjLatPosVal of type uint16
 *   u16_SCC_ObjRelSpdVal of type uint16
 *   u16_SCC_TrgtDstVal of type uint16
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_NSCCOpSta of type uint8
 *   u8_SCC_NSCCOnOffSta of type uint8
 *   u8_SCC_SnstvtyModRetVal of type uint8
 *   u8_ADAS_CMD_AlvCnt20Val of type uint8
 *   u8_ADAS_CMD_Crc20Val of type uint16
 *   u8_SCC_NSCCInfoPUDis of type uint8
 *   u8_SCC_EngStateReq of type uint8
 *   u8_ADAS_DrUnlckReqSta of type uint8
 *   u8_ADAS_HzrdLmpReqVal of type uint8
 *   u8_NSCC_Op2Sta of type uint8
 *   u8_SCC_Char1Sta of type uint8
 *   u8_SCC_Char2Sta of type uint8
 *   u8_SCC_Char3Sta of type uint8
 * VCan_ENG_EngSta_t: Record with elements
 *   ENG_EngSta of type uint8
 * VCan_ENG_IsgSta_t: Record with elements
 *   ENG_IsgSta of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   CVD_VehicleTrackWidths *Rte_Pim_PIM_Cvd_TrackWidthInputs(void)
 *
 *********************************************************************************************************************/


#define CpApVCan_START_SEC_CODE
#include "CpApVCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_HKMC_ReleaseInfo_getHKMC_ReleaseInfo(HKMC_ReleaseInfo_record *HKMC_ReleaseInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HKMC_ReleaseInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApVCan_CODE) Re_CpApVCanInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(COM_DT_SG_ABS_ESC_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(COM_DT_SG_BCM_07_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(COM_DT_SG_BCM_08_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(COM_DT_SG_BCM_10_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(COM_DT_SG_BCM_13_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(COM_DT_SG_CLU_01_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(COM_DT_SG_CLU_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(COM_DT_SG_CLU_04_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(COM_DT_SG_CLU_12_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(COM_DT_SG_CLU_13_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(COM_DT_SG_CLU_14_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(COM_DT_SG_CLU_25_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(COM_DT_SG_CTM_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(COM_DT_SG_DATC_17_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(COM_DT_SG_EMS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(COM_DT_SG_EMS_02_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(COM_DT_SG_EMS_03_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(COM_DT_SG_EMS_05_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(COM_DT_SG_EMS_07_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(COM_DT_SG_EMS_11_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(COM_DT_SG_EPB_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(COM_DT_SG_ESC_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(COM_DT_SG_ESC_03_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(COM_DT_SG_HCU_03_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(COM_DT_SG_HCU_05_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(COM_DT_SG_HTCU_04_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(COM_DT_SG_HTCU_05_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(COM_DT_SG_HU_CLU_PE_05_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(COM_DT_SG_HU_GW_PE_01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(COM_DT_SG_HU_MON_PE_01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(COM_DT_SG_HU_USM_E_14_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(COM_DT_SG_IAU_16_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(COM_DT_SG_ICC_HS_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(COM_DT_SG_ICC_HS_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(COM_DT_SG_ICSC_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(COM_DT_SG_ICU_02_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(COM_DT_SG_ICU_04_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(COM_DT_SG_ICU_07_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(COM_DT_SG_IEB_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(COM_DT_SG_IMU_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(COM_DT_SG_MDPS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(COM_DT_SG_MFSW_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(COM_DT_SG_SAS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(COM_DT_SG_SMK_02_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(COM_DT_SG_SWRC_03_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(COM_DT_SG_TCU_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(COM_DT_SG_WHL_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_CoFCAEDR_Output_De_EDR_Output(CoFcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(CoFcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaOutput_De_CoFcaOutput(CoFcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CvdOutputData_De_CvdOutputData(CvdOutputData_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutput_De_DawOutput(DawOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_FcaEDR_Output_De_FcaInternalOutToEDR(FcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFrCmrOut_De_FcaFrCmrOut(FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaOutput_De_FcaOutput(FcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaOutput_De_HbaOutput(HbaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwOutput_De_IslwOutput(IslwOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcHptOutput_De_IvcHptOutput(IvcHptOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcMv1Output_De_IvcMv1Output(IvcMv1Output_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcMv2Output_De_IvcMv2Output(IvcMv2Output_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcPuFOutput_De_IvcPuFOutput(IvcPuFOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcPuMOutput_De_IvcPuMOutput(IvcPuMOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSmvOutput_De_IvcSmvOutput(IvcSmvOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSndOutput_De_IvcSndOutput(IvcSndOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSymbStaOutput_De_IvcSymbStaOutput(IvcSymbStaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(IvcTrffcSgnOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcVarOutput_De_IvcVarOutput(IvcVarOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssOutput_De_LssOutput(LssOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_SccOutput_De_SccOutput(SccOutput_t *data)
 *   boolean Rte_IsUpdated_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_RP_CvdOutputData_De_CvdOutputData(void)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CVD_ReadTrackWidth_TrackWidth(const Cvd_TrackWidthInput_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2VCan_CANmsg(const CANmsg_t *data)
 *   Std_ReturnType Rte_Write_PP_CvdInputData_De_CvdInputData(const CvdInputData_t *data)
 *   Std_ReturnType Rte_Write_PP_DawInput_De_DawInput(const DawInput_t *data)
 *   Std_ReturnType Rte_Write_PP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_ENG_EngSta_De_VCan_ENG_EngSta(const VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Write_PP_ENG_IsgSta_De_VCan_ENG_IsgSta(const VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Write_PP_EscActive_De_EscActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(const FcaFailSafeInfoTrailerMsgTout_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaInput_De_FcaInput(const FcaInput_t *data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverse(boolean data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverseValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 data)
 *   Std_ReturnType Rte_Write_PP_IslwInput_De_IslwInput(const IslwInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAcceleration(float32 data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAccelerationValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_LeftIndicatorOn_De_LeftIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_RightIndicatorOn_De_RightIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_MeInputCommData_De_MeInputCommData(const MeInputCommData_t *data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngle(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngleValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_VCan_GetOdoValue_De_OdoVal(COM_DT_CLU_OdoVal data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VsmActive_De_VsmActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_WiperOn_De_WiperOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRate(float32 data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRateValid(boolean data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_RP_VCan_BusOFFStatus_BSW_BswM_MDGP_BswMVCAN_RteModeDclGroup(void)
 *   Modes of Rte_ModeType_BswMVCAN_RteModeDclGroup:
 *   - RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_BUSOFF
 *   - RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_Normal
 *   - RTE_TRANSITION_BswMVCAN_RteModeDclGroup
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApVCan_CODE) Re_CpApVCanMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(CoFcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaOutput_De_CoFcaOutput(CoFcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutput_De_DawOutput(DawOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFrCmrOut_De_FcaFrCmrOut(FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaOutput_De_FcaOutput(FcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaOutput_De_HbaOutput(HbaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwOutput_De_IslwOutput(IslwOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssOutput_De_LssOutput(LssOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccOutput_De_SccOutput(SccOutput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_10_20ms_SignalGroup_COM_SG_ADAS_CMD_10_20ms_SignalGroup(const COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_20_20ms_SignalGroup_COM_SG_ADAS_CMD_20_20ms_SignalGroup(const COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_21_50ms_SignalGroup_COM_SG_ADAS_CMD_21_50ms_SignalGroup(const COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_30_10ms_SignalGroup_COM_SG_ADAS_CMD_30_10ms_SignalGroup(const COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_31_50ms_SignalGroup_COM_SG_ADAS_CMD_31_50ms_SignalGroup(const COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_35_10ms_SignalGroup_COM_SG_ADAS_CMD_35_10ms_SignalGroup(const COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_INFO_01_200ms_SignalGroup_COM_SG_ADAS_INFO_01_200ms_SignalGroup(const COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_UX_01_50ms_SignalGroup_COM_SG_ADAS_UX_01_50ms_SignalGroup(const COM_DT_SG_ADAS_UX_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_UX_02_50ms_SignalGroup_COM_SG_ADAS_UX_02_50ms_SignalGroup(const COM_DT_SG_ADAS_UX_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_01_10ms_SignalGroup_COM_SG_FR_CMR_01_10ms_SignalGroup(const COM_DT_SG_FR_CMR_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_02_100ms_SignalGroup_COM_SG_FR_CMR_02_100ms_SignalGroup(const COM_DT_SG_FR_CMR_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup(const COM_DT_SG_FR_CMR_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_04_40ms_SignalGroup_COM_SG_FR_CMR_04_40ms_SignalGroup(const COM_DT_SG_FR_CMR_04_40ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_PP_ActivateToi_De_ActivateToi(boolean data)
 *   Std_ReturnType Rte_Write_PP_CVD_ReadTrackWidth_TrackWidth(const Cvd_TrackWidthInput_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2VCan_CANmsg(const CANmsg_t *data)
 *   Std_ReturnType Rte_Write_PP_CvdInputData_De_CvdInputData(const CvdInputData_t *data)
 *   Std_ReturnType Rte_Write_PP_DawInput_De_DawInput(const DawInput_t *data)
 *   Std_ReturnType Rte_Write_PP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EDR_Input_Data_EDRInputData(const EDR_InputData *data)
 *   Std_ReturnType Rte_Write_PP_ENG_EngSta_De_VCan_ENG_EngSta(const VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Write_PP_ENG_IsgSta_De_VCan_ENG_IsgSta(const VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Write_PP_EscActive_De_EscActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_FcaInput_De_FcaInput(const FcaInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaWarnLampCond_De_FcaWarnLampCond(uint8 data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverse(boolean data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverseValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 data)
 *   Std_ReturnType Rte_Write_PP_IslwInput_De_IslwInput(const IslwInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAcceleration(float32 data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAccelerationValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_LeftIndicatorOn_De_LeftIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_LkaToiFault_De_LkaToiFault(boolean data)
 *   Std_ReturnType Rte_Write_PP_LssInput_De_LssInput(const LssInput_t *data)
 *   Std_ReturnType Rte_Write_PP_RightIndicatorOn_De_RightIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_MeInputCommData_De_MeInputCommData(const MeInputCommData_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInput_De_SccInput(const SccInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInputFromVCan_De_SccInputFromVCan(const SccInputFromVCan_t *data)
 *   Std_ReturnType Rte_Write_PP_SccWarnLampCond_De_SccWarnLampCond(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngle(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngleValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_VCan_GetOdoValue_De_OdoVal(COM_DT_CLU_OdoVal data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VsmActive_De_VsmActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_WiperOn_De_WiperOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRate(float32 data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRateValid(boolean data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EDR_Trigger_EDR_Trigger_Function(void)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanOut_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApVCan_CODE) Re_CpApVCanOut(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApVCanOut
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EDRInputData_50ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 50ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFCAEDR_Output_De_EDR_Output(CoFcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaEDR_Output_De_FcaInternalOutToEDR(FcaEDR_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_EDR_Input_Data_EDRInputData(const EDR_InputData *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EDRInputData_50ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApVCan_CODE) Re_EDRInputData_50ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EDRInputData_50ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FrCmr03_50ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 50ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup(const COM_DT_SG_FR_CMR_03_50ms_SignalGroup *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FrCmr03_50ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApVCan_CODE) Re_FrCmr03_50ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FrCmr03_50ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_getCanmsg
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getCanmsg> of PortPrototype <PP_CANmsg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_getCanmsg(CANmsg_t *CANmsg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_CANmsg_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_getCanmsg_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApVCan_CODE) Re_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) CANmsg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_getCanmsg (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApVCan_STOP_SEC_CODE
#include "CpApVCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
