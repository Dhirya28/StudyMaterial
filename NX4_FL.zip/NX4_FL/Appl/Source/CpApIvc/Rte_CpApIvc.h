/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApIvc.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIvc
 *  Generation Time:  2023-04-20 13:52:36
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApIvc> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPIVC_H
# define _RTE_CPAPIVC_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApIvc_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApIvc
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApIvc, RTE_CONST, RTE_CONST) Rte_Inst_CpApIvc; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApIvc, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc(P2VAR(CoFcaUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_DawUxOutToIvc_De_DawUxOutToIvc(P2VAR(DawUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_FcaUxOutToIvc_De_FcaUxOutToIvc(P2VAR(FcaUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_HbaUxOutToIvc_De_HbaUxOutToIvc(P2VAR(HbaUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IslaUxOutToIvc_De_IslaUxOutToIvc(P2VAR(IslaUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn01_De_IvcDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn02_De_IvcDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn03_De_IvcDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn04_De_IvcDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn05_De_IvcDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_IvcDbgIn06_De_IvcDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_LssUxOutToIvc_De_LssUxOutToIvc(P2VAR(LssUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_MrmUxOutToIvc_De_MrmUxOutToIvc(P2VAR(MrmUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIvc_RP_SccUxOutToIvc_De_SccUxOutToIvc(P2VAR(SccUxOutToIvc_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcHptOutput_De_IvcHptOutput(P2CONST(IvcHptOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcMv1Output_De_IvcMv1Output(P2CONST(IvcMv1Output_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcMv2Output_De_IvcMv2Output(P2CONST(IvcMv2Output_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcPuFOutput_De_IvcPuFOutput(P2CONST(IvcPuFOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcPuMOutput_De_IvcPuMOutput(P2CONST(IvcPuMOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcSmvOutput_De_IvcSmvOutput(P2CONST(IvcSmvOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcSndOutput_De_IvcSndOutput(P2CONST(IvcSndOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcSymbStaOutput_De_IvcSymbStaOutput(P2CONST(IvcSymbStaOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(P2CONST(IvcTrffcSgnOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApIvc_PP_IvcVarOutput_De_IvcVarOutput(P2CONST(IvcVarOutput_t, AUTOMATIC, RTE_CPAPIVC_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIvc_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIvc_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIvc_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIvc_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIvc_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc Rte_Read_CpApIvc_RP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc
# define Rte_Read_RP_DawUxOutToIvc_De_DawUxOutToIvc Rte_Read_CpApIvc_RP_DawUxOutToIvc_De_DawUxOutToIvc
# define Rte_Read_RP_FcaUxOutToIvc_De_FcaUxOutToIvc Rte_Read_CpApIvc_RP_FcaUxOutToIvc_De_FcaUxOutToIvc
# define Rte_Read_RP_HbaUxOutToIvc_De_HbaUxOutToIvc Rte_Read_CpApIvc_RP_HbaUxOutToIvc_De_HbaUxOutToIvc
# define Rte_Read_RP_IslaUxOutToIvc_De_IslaUxOutToIvc Rte_Read_CpApIvc_RP_IslaUxOutToIvc_De_IslaUxOutToIvc
# define Rte_Read_RP_IvcDbgIn01_De_IvcDbgIn01 Rte_Read_CpApIvc_RP_IvcDbgIn01_De_IvcDbgIn01
# define Rte_Read_RP_IvcDbgIn02_De_IvcDbgIn02 Rte_Read_CpApIvc_RP_IvcDbgIn02_De_IvcDbgIn02
# define Rte_Read_RP_IvcDbgIn03_De_IvcDbgIn03 Rte_Read_CpApIvc_RP_IvcDbgIn03_De_IvcDbgIn03
# define Rte_Read_RP_IvcDbgIn04_De_IvcDbgIn04 Rte_Read_CpApIvc_RP_IvcDbgIn04_De_IvcDbgIn04
# define Rte_Read_RP_IvcDbgIn05_De_IvcDbgIn05 Rte_Read_CpApIvc_RP_IvcDbgIn05_De_IvcDbgIn05
# define Rte_Read_RP_IvcDbgIn06_De_IvcDbgIn06 Rte_Read_CpApIvc_RP_IvcDbgIn06_De_IvcDbgIn06
# define Rte_Read_RP_LssUxOutToIvc_De_LssUxOutToIvc Rte_Read_CpApIvc_RP_LssUxOutToIvc_De_LssUxOutToIvc
# define Rte_Read_RP_MrmUxOutToIvc_De_MrmUxOutToIvc Rte_Read_CpApIvc_RP_MrmUxOutToIvc_De_MrmUxOutToIvc
# define Rte_Read_RP_SccUxOutToIvc_De_SccUxOutToIvc Rte_Read_CpApIvc_RP_SccUxOutToIvc_De_SccUxOutToIvc


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_IvcHptOutput_De_IvcHptOutput Rte_Write_CpApIvc_PP_IvcHptOutput_De_IvcHptOutput
# define Rte_Write_PP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01
# define Rte_Write_PP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02
# define Rte_Write_PP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03
# define Rte_Write_PP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04
# define Rte_Write_PP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05
# define Rte_Write_PP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06
# define Rte_Write_PP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07
# define Rte_Write_PP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08
# define Rte_Write_PP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09
# define Rte_Write_PP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10
# define Rte_Write_PP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11
# define Rte_Write_PP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12
# define Rte_Write_PP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13
# define Rte_Write_PP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14
# define Rte_Write_PP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15
# define Rte_Write_PP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16
# define Rte_Write_PP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17
# define Rte_Write_PP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18
# define Rte_Write_PP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19
# define Rte_Write_PP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20
# define Rte_Write_PP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21 Rte_Write_CpApIvc_PP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21
# define Rte_Write_PP_IvcMv1Output_De_IvcMv1Output Rte_Write_CpApIvc_PP_IvcMv1Output_De_IvcMv1Output
# define Rte_Write_PP_IvcMv2Output_De_IvcMv2Output Rte_Write_CpApIvc_PP_IvcMv2Output_De_IvcMv2Output
# define Rte_Write_PP_IvcPuFOutput_De_IvcPuFOutput Rte_Write_CpApIvc_PP_IvcPuFOutput_De_IvcPuFOutput
# define Rte_Write_PP_IvcPuMOutput_De_IvcPuMOutput Rte_Write_CpApIvc_PP_IvcPuMOutput_De_IvcPuMOutput
# define Rte_Write_PP_IvcSmvOutput_De_IvcSmvOutput Rte_Write_CpApIvc_PP_IvcSmvOutput_De_IvcSmvOutput
# define Rte_Write_PP_IvcSndOutput_De_IvcSndOutput Rte_Write_CpApIvc_PP_IvcSndOutput_De_IvcSndOutput
# define Rte_Write_PP_IvcSymbStaOutput_De_IvcSymbStaOutput Rte_Write_CpApIvc_PP_IvcSymbStaOutput_De_IvcSymbStaOutput
# define Rte_Write_PP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput Rte_Write_CpApIvc_PP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput
# define Rte_Write_PP_IvcVarOutput_De_IvcVarOutput Rte_Write_CpApIvc_PP_IvcVarOutput_De_IvcVarOutput


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApIvc_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApIvc_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApIvc_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApIvc_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApIvc_RP_Os_Service_GetElapsedValue




# define CpApIvc_START_SEC_CODE
# include "CpApIvc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIvcInit Re_CpApIvcInit
FUNC(void, CpApIvc_CODE) Re_CpApIvcInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcMain10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc(CoFcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_DawUxOutToIvc_De_DawUxOutToIvc(DawUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaUxOutToIvc_De_FcaUxOutToIvc(FcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaUxOutToIvc_De_HbaUxOutToIvc(HbaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_IslaUxOutToIvc_De_IslaUxOutToIvc(IslaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn01_De_IvcDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn02_De_IvcDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn03_De_IvcDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn04_De_IvcDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn05_De_IvcDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn06_De_IvcDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssUxOutToIvc_De_LssUxOutToIvc(LssUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_MrmUxOutToIvc_De_MrmUxOutToIvc(MrmUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_SccUxOutToIvc_De_SccUxOutToIvc(SccUxOutToIvc_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_IvcHptOutput_De_IvcHptOutput(const IvcHptOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcMv1Output_De_IvcMv1Output(const IvcMv1Output_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcMv2Output_De_IvcMv2Output(const IvcMv2Output_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcPuFOutput_De_IvcPuFOutput(const IvcPuFOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcPuMOutput_De_IvcPuMOutput(const IvcPuMOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSmvOutput_De_IvcSmvOutput(const IvcSmvOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSndOutput_De_IvcSndOutput(const IvcSndOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSymbStaOutput_De_IvcSymbStaOutput(const IvcSymbStaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(const IvcTrffcSgnOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcVarOutput_De_IvcVarOutput(const IvcVarOutput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIvcMain10ms Re_CpApIvcMain10ms
FUNC(void, CpApIvc_CODE) Re_CpApIvcMain10ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_IvcAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIvcVersionReq(IvcAppVersionInfo_t *IvcAppVersionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IvcAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIvcVersionReq Re_CpApIvcVersionReq
FUNC(Std_ReturnType, CpApIvc_CODE) Re_CpApIvcVersionReq(P2VAR(IvcAppVersionInfo_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) IvcAppVersionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApIvc_STOP_SEC_CODE
# include "CpApIvc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_IvcAppVersionInfo_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPIVC_H */
