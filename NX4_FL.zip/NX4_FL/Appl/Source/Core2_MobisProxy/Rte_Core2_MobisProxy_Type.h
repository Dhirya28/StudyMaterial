/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_Core2_MobisProxy_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  Core2_MobisProxy
 *  Generation Time:  2023-04-20 13:52:18
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <Core2_MobisProxy> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CORE2_MOBISPROXY_TYPE_H
# define _RTE_CORE2_MOBISPROXY_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_ProxyCore2Ready
#  define RTE_MODETYPE_ProxyCore2Ready
typedef uint8 Rte_ModeType_ProxyCore2Ready;
# endif

# define RTE_MODE_Core2_MobisProxy_ProxyCore2Ready_False (0U)
# ifndef RTE_MODE_ProxyCore2Ready_False
#  define RTE_MODE_ProxyCore2Ready_False (0U)
# endif
# define RTE_MODE_Core2_MobisProxy_ProxyCore2Ready_True (1U)
# ifndef RTE_MODE_ProxyCore2Ready_True
#  define RTE_MODE_ProxyCore2Ready_True (1U)
# endif
# define RTE_TRANSITION_Core2_MobisProxy_ProxyCore2Ready (2U)
# ifndef RTE_TRANSITION_ProxyCore2Ready
#  define RTE_TRANSITION_ProxyCore2Ready (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CORE2_MOBISPROXY_TYPE_H */
