/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApHba.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApHba
 *  Generation Time:  2023-04-20 13:52:32
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApHba> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPHBA_H
# define _RTE_CPAPHBA_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApHba_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApHba
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApHba, RTE_CONST, RTE_CONST) Rte_Inst_CpApHba; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApHba, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_Core2ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn01_De_HbaDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn02_De_HbaDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn03_De_HbaDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn04_De_HbaDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn05_De_HbaDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaDbgIn06_De_HbaDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaFailInfo_De_HbaFailInfo(P2VAR(HbaFailInfo_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHba_RP_HbaInput_De_HbaInput(P2VAR(HbaInput_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaOutput_De_HbaOutput(P2CONST(HbaOutput_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHba_PP_HbaUxOutToIvc_De_HbaUxOutToIvc(P2CONST(HbaUxOutToIvc_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FrCmrHdrFS_getFrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_HbaFrqNvData_HbaFrqNvDataRead(P2VAR(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) HbaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_HbaFrqNvData_HbaFrqNvDataWrite(P2CONST(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) HbaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_HbaOccNvData_HbaOccNvDataRead(P2VAR(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) HbaOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_HbaOccNvData_HbaOccNvDataWrite(P2CONST(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBA_APPL_DATA) HbaOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHba_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApHba_RP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_HbaDbgIn01_De_HbaDbgIn01 Rte_Read_CpApHba_RP_HbaDbgIn01_De_HbaDbgIn01
# define Rte_Read_RP_HbaDbgIn02_De_HbaDbgIn02 Rte_Read_CpApHba_RP_HbaDbgIn02_De_HbaDbgIn02
# define Rte_Read_RP_HbaDbgIn03_De_HbaDbgIn03 Rte_Read_CpApHba_RP_HbaDbgIn03_De_HbaDbgIn03
# define Rte_Read_RP_HbaDbgIn04_De_HbaDbgIn04 Rte_Read_CpApHba_RP_HbaDbgIn04_De_HbaDbgIn04
# define Rte_Read_RP_HbaDbgIn05_De_HbaDbgIn05 Rte_Read_CpApHba_RP_HbaDbgIn05_De_HbaDbgIn05
# define Rte_Read_RP_HbaDbgIn06_De_HbaDbgIn06 Rte_Read_CpApHba_RP_HbaDbgIn06_De_HbaDbgIn06
# define Rte_Read_RP_HbaFailInfo_De_HbaFailInfo Rte_Read_CpApHba_RP_HbaFailInfo_De_HbaFailInfo
# define Rte_Read_RP_HbaInput_De_HbaInput Rte_Read_CpApHba_RP_HbaInput_De_HbaInput


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01 Rte_Write_CpApHba_PP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01
# define Rte_Write_PP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02 Rte_Write_CpApHba_PP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02
# define Rte_Write_PP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03 Rte_Write_CpApHba_PP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03
# define Rte_Write_PP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04 Rte_Write_CpApHba_PP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04
# define Rte_Write_PP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05 Rte_Write_CpApHba_PP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05
# define Rte_Write_PP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06 Rte_Write_CpApHba_PP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06
# define Rte_Write_PP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07 Rte_Write_CpApHba_PP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07
# define Rte_Write_PP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08 Rte_Write_CpApHba_PP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08
# define Rte_Write_PP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09 Rte_Write_CpApHba_PP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09
# define Rte_Write_PP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10 Rte_Write_CpApHba_PP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10
# define Rte_Write_PP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11 Rte_Write_CpApHba_PP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11
# define Rte_Write_PP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12 Rte_Write_CpApHba_PP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12
# define Rte_Write_PP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13 Rte_Write_CpApHba_PP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13
# define Rte_Write_PP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14 Rte_Write_CpApHba_PP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14
# define Rte_Write_PP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15 Rte_Write_CpApHba_PP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15
# define Rte_Write_PP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16 Rte_Write_CpApHba_PP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16
# define Rte_Write_PP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17 Rte_Write_CpApHba_PP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17
# define Rte_Write_PP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18 Rte_Write_CpApHba_PP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18
# define Rte_Write_PP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19 Rte_Write_CpApHba_PP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19
# define Rte_Write_PP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20 Rte_Write_CpApHba_PP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20
# define Rte_Write_PP_HbaOutput_De_HbaOutput Rte_Write_CpApHba_PP_HbaOutput_De_HbaOutput
# define Rte_Write_PP_HbaUxOutToIvc_De_HbaUxOutToIvc Rte_Write_CpApHba_PP_HbaUxOutToIvc_De_HbaUxOutToIvc


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApHba_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApHba_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApHba_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApHba_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApHba_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS Rte_Call_CpApHba_RP_FrCmrHdrFS_getFrCmrHdrFS
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApHba_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApHba_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_HbaFrqNvData_HbaFrqNvDataRead Rte_Call_CpApHba_RP_HbaFrqNvData_HbaFrqNvDataRead
# define Rte_Call_RP_HbaFrqNvData_HbaFrqNvDataWrite Rte_Call_CpApHba_RP_HbaFrqNvData_HbaFrqNvDataWrite
# define Rte_Call_RP_HbaOccNvData_HbaOccNvDataRead Rte_Call_CpApHba_RP_HbaOccNvData_HbaOccNvDataRead
# define Rte_Call_RP_HbaOccNvData_HbaOccNvDataWrite Rte_Call_CpApHba_RP_HbaOccNvData_HbaOccNvDataWrite
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApHba_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApHba_RP_Os_Service_GetElapsedValue




# define CpApHba_START_SEC_CODE
# include "CpApHba_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaFrqNvData_HbaFrqNvDataRead(HbaFrqNvData_t *HbaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaOccNvData_HbaOccNvDataRead(HbaOccNvData_t *HbaOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaInit Re_CpApHbaInit
FUNC(void, CpApHba_CODE) Re_CpApHbaInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaMain10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn01_De_HbaDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn02_De_HbaDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn03_De_HbaDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn04_De_HbaDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn05_De_HbaDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaDbgIn06_De_HbaDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaFailInfo_De_HbaFailInfo(HbaFailInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaInput_De_HbaInput(HbaInput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaOutput_De_HbaOutput(const HbaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaUxOutToIvc_De_HbaUxOutToIvc(const HbaUxOutToIvc_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaFrqNvData_HbaFrqNvDataWrite(const HbaFrqNvData_t *HbaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaOccNvData_HbaOccNvDataWrite(const HbaOccNvData_t *HbaOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaOccNvData_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaMain10ms Re_CpApHbaMain10ms
FUNC(void, CpApHba_CODE) Re_CpApHbaMain10ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaVersionReq
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_HbaAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaVersionReq(HbaAppVersionInfo_t *HbaAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaVersionReq Re_CpApHbaVersionReq
FUNC(Std_ReturnType, CpApHba_CODE) Re_CpApHbaVersionReq(P2VAR(HbaAppVersionInfo_t, AUTOMATIC, RTE_CPAPHBA_APPL_VAR) HbaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApHba_STOP_SEC_CODE
# include "CpApHba_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_IF_HbaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_HbaFrqNvData_ReturnType (1U)

# define RTE_E_IF_HbaOccNvData_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPHBA_H */
