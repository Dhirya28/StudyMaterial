/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApDaw.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApDaw
 *  Generation Time:  2023-04-20 13:52:23
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApDaw> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPDAW_H
# define _RTE_CPAPDAW_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApDaw_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApDaw
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApDaw, RTE_CONST, RTE_CONST) Rte_Inst_CpApDaw; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApDaw, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_Core2ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn01_De_DawDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn02_De_DawDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn03_De_DawDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn04_De_DawDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn05_De_DawDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawDbgIn06_De_DawDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawFailInfo_De_DawFailInfo(P2VAR(DawFailInfo_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDaw_RP_DawInput_De_DawInput(P2VAR(DawInput_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput01_De_DawLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput02_De_DawLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput03_De_DawLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput04_De_DawLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput05_De_DawLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput06_De_DawLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput07_De_DawLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput08_De_DawLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput09_De_DawLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput10_De_DawLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput11_De_DawLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput12_De_DawLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput13_De_DawLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput14_De_DawLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput15_De_DawLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput16_De_DawLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput17_De_DawLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput18_De_DawLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput19_De_DawLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawLogicDbgOutput20_De_DawLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawOutToLss_De_DawOutToLss(P2CONST(DawOutToLss_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawOutput_De_DawOutput(P2CONST(DawOutput_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDaw_PP_DawUxOutToIvc_De_DawUxOutToIvc(P2CONST(DawUxOutToIvc_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_DawFrqNvData_DawFrqNvDataRead(P2VAR(DawFrqNvData_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) DawFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_DawFrqNvData_DawFrqNvDataWrite(P2CONST(DawFrqNvData_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) DawFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_DawOccNvData_DawOccNvDataRead(P2VAR(DawOccNvData_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) DawOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_DawOccNvData_DawOccNvDataWrite(P2CONST(DawOccNvData_t, AUTOMATIC, RTE_CPAPDAW_APPL_DATA) DawOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrHdrFS_getFrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(P2VAR(FrCmrHdrLnHost_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrHdrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDaw_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApDaw_RP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_DawDbgIn01_De_DawDbgIn01 Rte_Read_CpApDaw_RP_DawDbgIn01_De_DawDbgIn01
# define Rte_Read_RP_DawDbgIn02_De_DawDbgIn02 Rte_Read_CpApDaw_RP_DawDbgIn02_De_DawDbgIn02
# define Rte_Read_RP_DawDbgIn03_De_DawDbgIn03 Rte_Read_CpApDaw_RP_DawDbgIn03_De_DawDbgIn03
# define Rte_Read_RP_DawDbgIn04_De_DawDbgIn04 Rte_Read_CpApDaw_RP_DawDbgIn04_De_DawDbgIn04
# define Rte_Read_RP_DawDbgIn05_De_DawDbgIn05 Rte_Read_CpApDaw_RP_DawDbgIn05_De_DawDbgIn05
# define Rte_Read_RP_DawDbgIn06_De_DawDbgIn06 Rte_Read_CpApDaw_RP_DawDbgIn06_De_DawDbgIn06
# define Rte_Read_RP_DawFailInfo_De_DawFailInfo Rte_Read_CpApDaw_RP_DawFailInfo_De_DawFailInfo
# define Rte_Read_RP_DawInput_De_DawInput Rte_Read_CpApDaw_RP_DawInput_De_DawInput


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_DawLogicDbgOutput01_De_DawLogicDbgOutput01 Rte_Write_CpApDaw_PP_DawLogicDbgOutput01_De_DawLogicDbgOutput01
# define Rte_Write_PP_DawLogicDbgOutput02_De_DawLogicDbgOutput02 Rte_Write_CpApDaw_PP_DawLogicDbgOutput02_De_DawLogicDbgOutput02
# define Rte_Write_PP_DawLogicDbgOutput03_De_DawLogicDbgOutput03 Rte_Write_CpApDaw_PP_DawLogicDbgOutput03_De_DawLogicDbgOutput03
# define Rte_Write_PP_DawLogicDbgOutput04_De_DawLogicDbgOutput04 Rte_Write_CpApDaw_PP_DawLogicDbgOutput04_De_DawLogicDbgOutput04
# define Rte_Write_PP_DawLogicDbgOutput05_De_DawLogicDbgOutput05 Rte_Write_CpApDaw_PP_DawLogicDbgOutput05_De_DawLogicDbgOutput05
# define Rte_Write_PP_DawLogicDbgOutput06_De_DawLogicDbgOutput06 Rte_Write_CpApDaw_PP_DawLogicDbgOutput06_De_DawLogicDbgOutput06
# define Rte_Write_PP_DawLogicDbgOutput07_De_DawLogicDbgOutput07 Rte_Write_CpApDaw_PP_DawLogicDbgOutput07_De_DawLogicDbgOutput07
# define Rte_Write_PP_DawLogicDbgOutput08_De_DawLogicDbgOutput08 Rte_Write_CpApDaw_PP_DawLogicDbgOutput08_De_DawLogicDbgOutput08
# define Rte_Write_PP_DawLogicDbgOutput09_De_DawLogicDbgOutput09 Rte_Write_CpApDaw_PP_DawLogicDbgOutput09_De_DawLogicDbgOutput09
# define Rte_Write_PP_DawLogicDbgOutput10_De_DawLogicDbgOutput10 Rte_Write_CpApDaw_PP_DawLogicDbgOutput10_De_DawLogicDbgOutput10
# define Rte_Write_PP_DawLogicDbgOutput11_De_DawLogicDbgOutput11 Rte_Write_CpApDaw_PP_DawLogicDbgOutput11_De_DawLogicDbgOutput11
# define Rte_Write_PP_DawLogicDbgOutput12_De_DawLogicDbgOutput12 Rte_Write_CpApDaw_PP_DawLogicDbgOutput12_De_DawLogicDbgOutput12
# define Rte_Write_PP_DawLogicDbgOutput13_De_DawLogicDbgOutput13 Rte_Write_CpApDaw_PP_DawLogicDbgOutput13_De_DawLogicDbgOutput13
# define Rte_Write_PP_DawLogicDbgOutput14_De_DawLogicDbgOutput14 Rte_Write_CpApDaw_PP_DawLogicDbgOutput14_De_DawLogicDbgOutput14
# define Rte_Write_PP_DawLogicDbgOutput15_De_DawLogicDbgOutput15 Rte_Write_CpApDaw_PP_DawLogicDbgOutput15_De_DawLogicDbgOutput15
# define Rte_Write_PP_DawLogicDbgOutput16_De_DawLogicDbgOutput16 Rte_Write_CpApDaw_PP_DawLogicDbgOutput16_De_DawLogicDbgOutput16
# define Rte_Write_PP_DawLogicDbgOutput17_De_DawLogicDbgOutput17 Rte_Write_CpApDaw_PP_DawLogicDbgOutput17_De_DawLogicDbgOutput17
# define Rte_Write_PP_DawLogicDbgOutput18_De_DawLogicDbgOutput18 Rte_Write_CpApDaw_PP_DawLogicDbgOutput18_De_DawLogicDbgOutput18
# define Rte_Write_PP_DawLogicDbgOutput19_De_DawLogicDbgOutput19 Rte_Write_CpApDaw_PP_DawLogicDbgOutput19_De_DawLogicDbgOutput19
# define Rte_Write_PP_DawLogicDbgOutput20_De_DawLogicDbgOutput20 Rte_Write_CpApDaw_PP_DawLogicDbgOutput20_De_DawLogicDbgOutput20
# define Rte_Write_PP_DawOutToLss_De_DawOutToLss Rte_Write_CpApDaw_PP_DawOutToLss_De_DawOutToLss
# define Rte_Write_PP_DawOutput_De_DawOutput Rte_Write_CpApDaw_PP_DawOutput_De_DawOutput
# define Rte_Write_PP_DawUxOutToIvc_De_DawUxOutToIvc Rte_Write_CpApDaw_PP_DawUxOutToIvc_De_DawUxOutToIvc


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApDaw_RP_CANmsg_getCanmsg
# define Rte_Call_RP_DawFrqNvData_DawFrqNvDataRead Rte_Call_CpApDaw_RP_DawFrqNvData_DawFrqNvDataRead
# define Rte_Call_RP_DawFrqNvData_DawFrqNvDataWrite Rte_Call_CpApDaw_RP_DawFrqNvData_DawFrqNvDataWrite
# define Rte_Call_RP_DawOccNvData_DawOccNvDataRead Rte_Call_CpApDaw_RP_DawOccNvData_DawOccNvDataRead
# define Rte_Call_RP_DawOccNvData_DawOccNvDataWrite Rte_Call_CpApDaw_RP_DawOccNvData_DawOccNvDataWrite
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApDaw_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApDaw_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApDaw_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApDaw_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS Rte_Call_CpApDaw_RP_FrCmrHdrFS_getFrCmrHdrFS
# define Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost Rte_Call_CpApDaw_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApDaw_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApDaw_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApDaw_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApDaw_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApDaw_RP_Os_Service_GetElapsedValue




# define CpApDaw_START_SEC_CODE
# include "CpApDaw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDawInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DawFrqNvData_DawFrqNvDataRead(DawFrqNvData_t *DawFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_DawOccNvData_DawOccNvDataRead(DawOccNvData_t *DawOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawOccNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDawInit Re_CpApDawInit
FUNC(void, CpApDaw_CODE) Re_CpApDawInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDawMain10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn01_De_DawDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn02_De_DawDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn03_De_DawDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn04_De_DawDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn05_De_DawDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawDbgIn06_De_DawDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawFailInfo_De_DawFailInfo(DawFailInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_DawInput_De_DawInput(DawInput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput01_De_DawLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput02_De_DawLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput03_De_DawLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput04_De_DawLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput05_De_DawLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput06_De_DawLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput07_De_DawLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput08_De_DawLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput09_De_DawLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput10_De_DawLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput11_De_DawLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput12_De_DawLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput13_De_DawLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput14_De_DawLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput15_De_DawLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput16_De_DawLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput17_De_DawLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput18_De_DawLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput19_De_DawLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawLogicDbgOutput20_De_DawLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawOutToLss_De_DawOutToLss(const DawOutToLss_t *data)
 *   Std_ReturnType Rte_Write_PP_DawOutput_De_DawOutput(const DawOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawUxOutToIvc_De_DawUxOutToIvc(const DawUxOutToIvc_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_DawFrqNvData_DawFrqNvDataWrite(const DawFrqNvData_t *DawFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_DawOccNvData_DawOccNvDataWrite(const DawOccNvData_t *DawOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawOccNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDawMain10ms Re_CpApDawMain10ms
FUNC(void, CpApDaw_CODE) Re_CpApDawMain10ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDawVersionReq
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_DawAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApDawVersionReq(DawAppVersionInfo_t *DawAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_DawAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDawVersionReq Re_CpApDawVersionReq
FUNC(Std_ReturnType, CpApDaw_CODE) Re_CpApDawVersionReq(P2VAR(DawAppVersionInfo_t, AUTOMATIC, RTE_CPAPDAW_APPL_VAR) DawAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApDaw_STOP_SEC_CODE
# include "CpApDaw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_DawAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_DawFrqNvData_ReturnType (1U)

# define RTE_E_IF_DawOccNvData_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPDAW_H */
