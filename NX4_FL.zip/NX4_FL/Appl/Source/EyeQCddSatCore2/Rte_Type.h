/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  EyeQCddSatCore2
 *  Generation Time:  2023-04-20 13:53:11
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Header file containing user defined AUTOSAR types and RTE structures (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_TYPE_H
# define _RTE_TYPE_H

# include "Rte.h"


/**********************************************************************************************************************
 * Data type definitions
 *********************************************************************************************************************/

# define Rte_TypeDef_Rte_DT_EYEQMESP_VehicleCalParams_t_14
typedef uint8 Rte_DT_EYEQMESP_VehicleCalParams_t_14[7];

# define Rte_TypeDef_EYEQMESP_EnvironmentParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint16 LeftWheel_u16;
  uint16 RightWheel_u16;
  uint16 RefPX_Front_Bumper_u16;
  uint16 CamToFrontAxle_u16;
  uint16 CamToRearAxle_u16;
  uint8 WheelWidth_u8;
  uint8 WheelRadius_u8;
  uint16 MinHorizon_u16;
  uint16 MaxHorizon_u16;
  uint16 MinYaw_u16;
  uint16 MaxYaw_u16;
  uint16 MaxRoll_u16;
  uint16 Top_Crop_u16;
  uint16 Bottom_Crop_u16;
  uint16 Steering_Ratio_u16;
  uint16 GPSToCam_dx_u16;
  uint16 GPSToCam_dy_u16;
  uint16 GPSToCam_dz_u16;
  uint8 GPSToCam_dx_V_u8;
  uint8 GPSToCam_dy_V_u8;
  uint8 GPSToCam_dz_V_u8;
  uint8 Top_Crop_V_u8;
  uint8 Steering_Ratio_V_u8;
  uint8 WheelWidth_V_u8;
  uint8 WheelRadius_V_u8;
  uint8 LeftWheel_V_u8;
  uint8 RightWheel_V_u8;
  uint8 RefPX_Front_Bumper_V_u8;
  uint8 CamToFrontAxle_V_u8;
  uint8 CamToRearAxle_V_u8;
  uint8 MinHorizon_V_u8;
  uint8 MaxHorizon_V_u8;
  uint8 MinYaw_V_u8;
  uint8 MaxYaw_V_u8;
  uint8 MaxRoll_V_u8;
  uint8 Bottom_Crop_V_u8;
  uint8 fixedGpsLatency_u8;
  uint8 fixedGpsLatency_V_u8;
  uint8 receiverFrequency_u8;
  uint8 receiverFrequency_V_u8;
  uint16 Reserved_1_u16;
  uint16 CalCRC_u16;
} EYEQMESP_EnvironmentParams_t;

# define Rte_TypeDef_EYEQMESP_VehicleCalParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Region_Code_u8;
  uint8 Driving_Side_u8;
  uint16 Pitch_Base_u16;
  uint16 Yaw_Base_u16;
  uint16 Cam_Height_Base_u16;
  float32 Roll_Angle_Base_f32;
  uint8 HilModeEnable_u8;
  uint8 OverrideActualTargetCalParams_u8;
  uint8 Disable_Ethernet_Logging_u8;
  uint8 Disable_Ethernet_Logging_V_u8;
  uint16 ActivateEDR_u16;
  uint8 ActivateEDR_V_u8;
  Rte_DT_EYEQMESP_VehicleCalParams_t_14 Reserved1_u8;
  uint16 CalCRC_u16;
} EYEQMESP_VehicleCalParams_t;


# ifndef RTE_SUPPRESS_UNUSED_DATATYPES
/**********************************************************************************************************************
 * Unused Data type definitions
 *********************************************************************************************************************/

#  define Rte_TypeDef_ABS_DiagSta
typedef uint8 ABS_DiagSta;

#  define Rte_TypeDef_ABS_ESC_AlvCnt1Val
typedef uint8 ABS_ESC_AlvCnt1Val;

#  define Rte_TypeDef_ABS_ESC_Crc1Val
typedef uint16 ABS_ESC_Crc1Val;

#  define Rte_TypeDef_ADAS101_AlvCntVal
typedef uint8 ADAS101_AlvCntVal;

#  define Rte_TypeDef_ADAS101_AlvCntVal_t_1
typedef uint8 ADAS101_AlvCntVal_t_1;

#  define Rte_TypeDef_ADAS101_CrcVal
typedef uint16 ADAS101_CrcVal;

#  define Rte_TypeDef_ADAS101_CrcVal_t_1
typedef uint16 ADAS101_CrcVal_t_1;

#  define Rte_TypeDef_ADAS_CMD_AlvCnt10Val
typedef uint8 ADAS_CMD_AlvCnt10Val;

#  define Rte_TypeDef_ADAS_CMD_AlvCnt10Val_1
typedef uint8 ADAS_CMD_AlvCnt10Val_1;

#  define Rte_TypeDef_ADAS_CMD_AlvCnt20Val
typedef uint8 ADAS_CMD_AlvCnt20Val;

#  define Rte_TypeDef_ADAS_CMD_Crc10Val
typedef uint16 ADAS_CMD_Crc10Val;

#  define Rte_TypeDef_ADAS_CMD_Crc10Val_1
typedef uint16 ADAS_CMD_Crc10Val_1;

#  define Rte_TypeDef_ADAS_CMD_Crc20Val
typedef uint16 ADAS_CMD_Crc20Val;

#  define Rte_TypeDef_ADAS_HzrdLmpReqVal
typedef uint8 ADAS_HzrdLmpReqVal;

#  define Rte_TypeDef_BRK_AutoDrvBrkSta
typedef uint8 BRK_AutoDrvBrkSta;

#  define Rte_TypeDef_BatteryVoltageHigh
typedef uint8 BatteryVoltageHigh;

#  define Rte_TypeDef_BatteryVoltageLow
typedef uint8 BatteryVoltageLow;

#  define Rte_TypeDef_Blockage_Drv
typedef uint8 Blockage_Drv;

#  define Rte_TypeDef_Blockage_Init
typedef uint8 Blockage_Init;

#  define Rte_TypeDef_CALR
typedef uint16 CALR;

#  define Rte_TypeDef_CALR_t_1
typedef uint16 CALR_t_1;

#  define Rte_TypeDef_COM_DT_AAF_WrnLamp
typedef boolean COM_DT_AAF_WrnLamp;

#  define Rte_TypeDef_COM_DT_ABSDDiagSta
typedef uint8 COM_DT_ABSDDiagSta;

#  define Rte_TypeDef_COM_DT_ABS_ESC_AlvCnt1Val
typedef uint8 COM_DT_ABS_ESC_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_ABS_ESC_Crc1Val
typedef uint16 COM_DT_ABS_ESC_Crc1Val;

#  define Rte_TypeDef_COM_DT_ACC_CrsMainSwLmpSta
typedef uint8 COM_DT_ACC_CrsMainSwLmpSta;

#  define Rte_TypeDef_COM_DT_ACC_CrsSetSwLmpSta
typedef uint8 COM_DT_ACC_CrsSetSwLmpSta;

#  define Rte_TypeDef_COM_DT_ACC_DnShftCtrlReq
typedef uint8 COM_DT_ACC_DnShftCtrlReq;

#  define Rte_TypeDef_COM_DT_ADAS101_AlvCntVal
typedef uint8 COM_DT_ADAS101_AlvCntVal;

#  define Rte_TypeDef_COM_DT_ADAS101_AlvCntVal_1
typedef uint8 COM_DT_ADAS101_AlvCntVal_1;

#  define Rte_TypeDef_COM_DT_ADAS101_CrcVal
typedef uint16 COM_DT_ADAS101_CrcVal;

#  define Rte_TypeDef_COM_DT_ADAS101_CrcVal_1
typedef uint16 COM_DT_ADAS101_CrcVal_1;

#  define Rte_TypeDef_COM_DT_ADAS_ACIAnglTqRedcGainVal
typedef uint8 COM_DT_ADAS_ACIAnglTqRedcGainVal;

#  define Rte_TypeDef_COM_DT_ADAS_ActvACILvl2Sta
typedef uint8 COM_DT_ADAS_ActvACILvl2Sta;

#  define Rte_TypeDef_COM_DT_ADAS_ActvACISta
typedef uint8 COM_DT_ADAS_ActvACISta;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt10Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt10Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt20Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt20Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt21Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt21Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt30Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt30Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt31Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt31Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_AlvCnt35Val
typedef uint8 COM_DT_ADAS_CMD_AlvCnt35Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc10Val
typedef uint16 COM_DT_ADAS_CMD_Crc10Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc20Val
typedef uint16 COM_DT_ADAS_CMD_Crc20Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc21Val
typedef uint16 COM_DT_ADAS_CMD_Crc21Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc30Val
typedef uint16 COM_DT_ADAS_CMD_Crc30Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc31Val
typedef uint16 COM_DT_ADAS_CMD_Crc31Val;

#  define Rte_TypeDef_COM_DT_ADAS_CMD_Crc35Val
typedef uint16 COM_DT_ADAS_CMD_Crc35Val;

#  define Rte_TypeDef_COM_DT_ADAS_DRV_UpDateInfo
typedef boolean COM_DT_ADAS_DRV_UpDateInfo;

#  define Rte_TypeDef_COM_DT_ADAS_Damping_Gain
typedef uint8 COM_DT_ADAS_Damping_Gain;

#  define Rte_TypeDef_COM_DT_ADAS_INFO_AlvCnt1Val
typedef uint8 COM_DT_ADAS_INFO_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_ADAS_INFO_Crc1Val
typedef uint16 COM_DT_ADAS_INFO_Crc1Val;

#  define Rte_TypeDef_COM_DT_ADAS_PRK_AlvCnt3Val
typedef uint8 COM_DT_ADAS_PRK_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_ADAS_PRK_Crc3Val
typedef uint16 COM_DT_ADAS_PRK_Crc3Val;

#  define Rte_TypeDef_COM_DT_ADAS_StrAnglReqVal
typedef sint16 COM_DT_ADAS_StrAnglReqVal;

#  define Rte_TypeDef_COM_DT_ADAS_StrTqReqVal
typedef uint16 COM_DT_ADAS_StrTqReqVal;

#  define Rte_TypeDef_COM_DT_ADAS_UX_AlvCnt1Val
typedef uint8 COM_DT_ADAS_UX_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_ADAS_UX_AlvCnt2Val
typedef uint8 COM_DT_ADAS_UX_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_ADAS_UX_Crc1Val
typedef uint16 COM_DT_ADAS_UX_Crc1Val;

#  define Rte_TypeDef_COM_DT_ADAS_UX_Crc2Val
typedef uint16 COM_DT_ADAS_UX_Crc2Val;

#  define Rte_TypeDef_COM_DT_AVH_AlrmReq
typedef uint8 COM_DT_AVH_AlrmReq;

#  define Rte_TypeDef_COM_DT_AVH_CluDis
typedef uint8 COM_DT_AVH_CluDis;

#  define Rte_TypeDef_COM_DT_AVH_Sta
typedef uint8 COM_DT_AVH_Sta;

#  define Rte_TypeDef_COM_DT_AVN_RSPA_ModeSelect
typedef uint8 COM_DT_AVN_RSPA_ModeSelect;

#  define Rte_TypeDef_COM_DT_AVN_RSPA_ModeSelect_1
typedef uint8 COM_DT_AVN_RSPA_ModeSelect_1;

#  define Rte_TypeDef_COM_DT_AWD_CltchDtyLimVal
typedef uint8 COM_DT_AWD_CltchDtyLimVal;

#  define Rte_TypeDef_COM_DT_BCM_AlvCnt10Val
typedef uint8 COM_DT_BCM_AlvCnt10Val;

#  define Rte_TypeDef_COM_DT_BCM_AlvCnt7Val
typedef uint8 COM_DT_BCM_AlvCnt7Val;

#  define Rte_TypeDef_COM_DT_BCM_AlvCnt8Val
typedef uint8 COM_DT_BCM_AlvCnt8Val;

#  define Rte_TypeDef_COM_DT_BCM_Crc10Val
typedef uint8 COM_DT_BCM_Crc10Val;

#  define Rte_TypeDef_COM_DT_BCM_Crc7Val
typedef uint8 COM_DT_BCM_Crc7Val;

#  define Rte_TypeDef_COM_DT_BCM_Crc8Val
typedef uint8 COM_DT_BCM_Crc8Val;

#  define Rte_TypeDef_COM_DT_BCM_SolSnsrLft
typedef uint8 COM_DT_BCM_SolSnsrLft;

#  define Rte_TypeDef_COM_DT_BCM_SolSnsrRt
typedef uint8 COM_DT_BCM_SolSnsrRt;

#  define Rte_TypeDef_COM_DT_BG_HDP_Sta
typedef uint8 COM_DT_BG_HDP_Sta;

#  define Rte_TypeDef_COM_DT_BJD_Flag
typedef boolean COM_DT_BJD_Flag;

#  define Rte_TypeDef_COM_DT_BatteryVoltageHigh
typedef uint8 COM_DT_BatteryVoltageHigh;

#  define Rte_TypeDef_COM_DT_BatteryVoltageLow
typedef uint8 COM_DT_BatteryVoltageLow;

#  define Rte_TypeDef_COM_DT_Blockage_Drv
typedef uint8 COM_DT_Blockage_Drv;

#  define Rte_TypeDef_COM_DT_Blockage_Init
typedef uint8 COM_DT_Blockage_Init;

#  define Rte_TypeDef_COM_DT_CALR
typedef uint16 COM_DT_CALR;

#  define Rte_TypeDef_COM_DT_CALR_1
typedef uint16 COM_DT_CALR_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_AdasVolumeNValueSet
typedef uint8 COM_DT_CF_AVN_AdasVolumeNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_AdasVolumeNValueSet_1
typedef uint8 COM_DT_CF_AVN_AdasVolumeNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_Clu3dDepthSet
typedef uint8 COM_DT_CF_AVN_Clu3dDepthSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_Clu3dDepthSet_1
typedef uint8 COM_DT_CF_AVN_Clu3dDepthSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluAutoInitFuelEconomy
typedef uint8 COM_DT_CF_AVN_CluAutoInitFuelEconomy;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluAutoInitFuelEconomy_1
typedef uint8 COM_DT_CF_AVN_CluAutoInitFuelEconomy_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluFuelEconUnit_km
typedef uint8 COM_DT_CF_AVN_CluFuelEconUnit_km;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluFuelEconUnit_km_1
typedef uint8 COM_DT_CF_AVN_CluFuelEconUnit_km_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluRheostatLvl
typedef uint8 COM_DT_CF_AVN_CluRheostatLvl;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluRheostatLvl_1
typedef uint8 COM_DT_CF_AVN_CluRheostatLvl_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluUserSettingDistance
typedef uint32 COM_DT_CF_AVN_CluUserSettingDistance;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluUserSettingDistance_1
typedef uint32 COM_DT_CF_AVN_CluUserSettingDistance_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluUserSettingPeriod
typedef uint8 COM_DT_CF_AVN_CluUserSettingPeriod;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluUserSettingPeriod_1
typedef uint8 COM_DT_CF_AVN_CluUserSettingPeriod_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluVoiceVolume
typedef uint8 COM_DT_CF_AVN_CluVoiceVolume;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluVoiceVolume_1
typedef uint8 COM_DT_CF_AVN_CluVoiceVolume_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_IFSActVehSpd_Set
typedef uint8 COM_DT_CF_AVN_IFSActVehSpd_Set;

#  define Rte_TypeDef_COM_DT_CF_AVN_IFSActVehSpd_Set_1
typedef uint8 COM_DT_CF_AVN_IFSActVehSpd_Set_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_ISLANValueSet
typedef uint8 COM_DT_CF_AVN_ISLANValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_ISLANValueSet_1
typedef uint8 COM_DT_CF_AVN_ISLANValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpBlueNValueSet
typedef uint16 COM_DT_CF_AVN_MoodLpBlueNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpBlueNValueSet_1
typedef uint16 COM_DT_CF_AVN_MoodLpBlueNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpBrightNValueSet
typedef uint16 COM_DT_CF_AVN_MoodLpBrightNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpBrightNValueSet_1
typedef uint16 COM_DT_CF_AVN_MoodLpBrightNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpGreenNValueSet
typedef uint16 COM_DT_CF_AVN_MoodLpGreenNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpGreenNValueSet_1
typedef uint16 COM_DT_CF_AVN_MoodLpGreenNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpRedNValueSet
typedef uint16 COM_DT_CF_AVN_MoodLpRedNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_MoodLpRedNValueSet_1
typedef uint16 COM_DT_CF_AVN_MoodLpRedNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_PCANValueSet
typedef uint8 COM_DT_CF_AVN_PCANValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_PCANValueSet_1
typedef uint8 COM_DT_CF_AVN_PCANValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_ProfileIDRValue
typedef uint8 COM_DT_CF_AVN_ProfileIDRValue;

#  define Rte_TypeDef_COM_DT_CF_AVN_ProfileIDRValue_1
typedef uint8 COM_DT_CF_AVN_ProfileIDRValue_1;

#  define Rte_TypeDef_COM_DT_CF_AVN_TirePressUnitNValueSet
typedef uint8 COM_DT_CF_AVN_TirePressUnitNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_TirePressUnitNValueSet_1
typedef uint8 COM_DT_CF_AVN_TirePressUnitNValueSet_1;

#  define Rte_TypeDef_COM_DT_CF_EMS_CltCtrlReq
typedef uint8 COM_DT_CF_EMS_CltCtrlReq;

#  define Rte_TypeDef_COM_DT_CF_EMS_KEYST
typedef boolean COM_DT_CF_EMS_KEYST;

#  define Rte_TypeDef_COM_DT_CF_EMS_NEURALSW
typedef boolean COM_DT_CF_EMS_NEURALSW;

#  define Rte_TypeDef_COM_DT_CLU_AdasWarnSndStat
typedef uint8 COM_DT_CLU_AdasWarnSndStat;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt12Val
typedef uint8 COM_DT_CLU_AlvCnt12Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt13Val
typedef uint8 COM_DT_CLU_AlvCnt13Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt14Val
typedef uint8 COM_DT_CLU_AlvCnt14Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt1Val
typedef uint8 COM_DT_CLU_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt25Val
typedef uint8 COM_DT_CLU_AlvCnt25Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt2Val
typedef uint8 COM_DT_CLU_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_CLU_AlvCnt4Val
typedef uint8 COM_DT_CLU_AlvCnt4Val;

#  define Rte_TypeDef_COM_DT_CLU_AutoBrightSta
typedef uint8 COM_DT_CLU_AutoBrightSta;

#  define Rte_TypeDef_COM_DT_CLU_CUSTOMSta_NEW
typedef uint8 COM_DT_CLU_CUSTOMSta_NEW;

#  define Rte_TypeDef_COM_DT_CLU_Crc12Val
typedef uint16 COM_DT_CLU_Crc12Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc13Val
typedef uint16 COM_DT_CLU_Crc13Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc14Val
typedef uint16 COM_DT_CLU_Crc14Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc1Val
typedef uint16 COM_DT_CLU_Crc1Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc25Val
typedef uint16 COM_DT_CLU_Crc25Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc2Val
typedef uint16 COM_DT_CLU_Crc2Val;

#  define Rte_TypeDef_COM_DT_CLU_Crc4Val
typedef uint16 COM_DT_CLU_Crc4Val;

#  define Rte_TypeDef_COM_DT_CLU_DTEVal
typedef uint16 COM_DT_CLU_DTEVal;

#  define Rte_TypeDef_COM_DT_CLU_DawLastBrkTimeVal
typedef uint8 COM_DT_CLU_DawLastBrkTimeVal;

#  define Rte_TypeDef_COM_DT_CLU_DisSpdDcmlVal
typedef uint8 COM_DT_CLU_DisSpdDcmlVal;

#  define Rte_TypeDef_COM_DT_CLU_DisSpdVal
typedef uint16 COM_DT_CLU_DisSpdVal;

#  define Rte_TypeDef_COM_DT_CLU_DrvngModSwSta
typedef uint8 COM_DT_CLU_DrvngModSwSta;

#  define Rte_TypeDef_COM_DT_CLU_FuelLvlSta
typedef uint8 COM_DT_CLU_FuelLvlSta;

#  define Rte_TypeDef_COM_DT_CLU_LngSta
typedef uint8 COM_DT_CLU_LngSta;

#  define Rte_TypeDef_COM_DT_CLU_OdoVal
typedef uint32 COM_DT_CLU_OdoVal;

#  define Rte_TypeDef_COM_DT_CLU_OdoVal_1
typedef uint32 COM_DT_CLU_OdoVal_1;

#  define Rte_TypeDef_COM_DT_CLU_OutTempCSta
typedef uint8 COM_DT_CLU_OutTempCSta;

#  define Rte_TypeDef_COM_DT_CLU_SWRCCrsSwSta
typedef uint8 COM_DT_CLU_SWRCCrsSwSta;

#  define Rte_TypeDef_COM_DT_CLU_SpdUnitTyp
typedef uint8 COM_DT_CLU_SpdUnitTyp;

#  define Rte_TypeDef_COM_DT_CLU_TerrainModSwSta
typedef uint8 COM_DT_CLU_TerrainModSwSta;

#  define Rte_TypeDef_COM_DT_DAW_LVDA_PUDis
typedef uint8 COM_DT_DAW_LVDA_PUDis;

#  define Rte_TypeDef_COM_DT_DAW_OptUsmSta
typedef uint8 COM_DT_DAW_OptUsmSta;

#  define Rte_TypeDef_COM_DT_DAW_SnstvtyModRetVal
typedef uint8 COM_DT_DAW_SnstvtyModRetVal;

#  define Rte_TypeDef_COM_DT_DAW_SysSta
typedef uint8 COM_DT_DAW_SysSta;

#  define Rte_TypeDef_COM_DT_DAW_WrnMsgSta
typedef uint8 COM_DT_DAW_WrnMsgSta;

#  define Rte_TypeDef_COM_DT_DBC_Sta
typedef uint8 COM_DT_DBC_Sta;

#  define Rte_TypeDef_COM_DT_DCT_BrkSwSta
typedef uint8 COM_DT_DCT_BrkSwSta;

#  define Rte_TypeDef_COM_DT_DCT_CrpTqReq
typedef uint16 COM_DT_DCT_CrpTqReq;

#  define Rte_TypeDef_COM_DT_DCT_EngOpSta
typedef uint8 COM_DT_DCT_EngOpSta;

#  define Rte_TypeDef_COM_DT_DCT_MotCrctTqVal
typedef sint16 COM_DT_DCT_MotCrctTqVal;

#  define Rte_TypeDef_COM_DT_DCT_MotIndTqBVal
typedef sint16 COM_DT_DCT_MotIndTqBVal;

#  define Rte_TypeDef_COM_DT_DCT_MotIndTqVal
typedef sint16 COM_DT_DCT_MotIndTqVal;

#  define Rte_TypeDef_COM_DT_DCT_MotSpdVal
typedef uint16 COM_DT_DCT_MotSpdVal;

#  define Rte_TypeDef_COM_DT_DMIC_AwdModSta
typedef uint8 COM_DT_DMIC_AwdModSta;

#  define Rte_TypeDef_COM_DT_DMIC_DrvModFltSta
typedef uint8 COM_DT_DMIC_DrvModFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_DrvModSta
typedef uint8 COM_DT_DMIC_DrvModSta;

#  define Rte_TypeDef_COM_DT_DMIC_EcsModSta
typedef uint8 COM_DT_DMIC_EcsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_ElsdModSta
typedef uint8 COM_DT_DMIC_ElsdModSta;

#  define Rte_TypeDef_COM_DT_DMIC_EngModSta
typedef uint8 COM_DT_DMIC_EngModSta;

#  define Rte_TypeDef_COM_DT_DMIC_EscModSta
typedef uint8 COM_DT_DMIC_EscModSta;

#  define Rte_TypeDef_COM_DT_DMIC_EsndModSta
typedef uint8 COM_DT_DMIC_EsndModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndAwdModSta
typedef uint8 COM_DT_DMIC_IndAwdModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndEcsModSta
typedef uint8 COM_DT_DMIC_IndEcsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndElsdModSta
typedef uint8 COM_DT_DMIC_IndElsdModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndEngModSta
typedef uint8 COM_DT_DMIC_IndEngModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndEscModSta
typedef uint8 COM_DT_DMIC_IndEscModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndEsndModSta
typedef uint8 COM_DT_DMIC_IndEsndModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndMaxVehSpdSta
typedef uint8 COM_DT_DMIC_IndMaxVehSpdSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndMdpsModSta
typedef uint8 COM_DT_DMIC_IndMdpsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndPrflModSta
typedef uint8 COM_DT_DMIC_IndPrflModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndRevModSta
typedef uint8 COM_DT_DMIC_IndRevModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndRwsModSta
typedef uint8 COM_DT_DMIC_IndRwsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndTmModSta
typedef uint8 COM_DT_DMIC_IndTmModSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndVcuModSta
typedef uint8 COM_DT_DMIC_IndVcuModSta;

#  define Rte_TypeDef_COM_DT_DMIC_MdpsModSta
typedef uint8 COM_DT_DMIC_MdpsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_PrflModSta
typedef uint8 COM_DT_DMIC_PrflModSta;

#  define Rte_TypeDef_COM_DT_DMIC_RevModSta
typedef uint8 COM_DT_DMIC_RevModSta;

#  define Rte_TypeDef_COM_DT_DMIC_RwsModSta
typedef uint8 COM_DT_DMIC_RwsModSta;

#  define Rte_TypeDef_COM_DT_DMIC_TmModSta
typedef uint8 COM_DT_DMIC_TmModSta;

#  define Rte_TypeDef_COM_DT_DMIC_VcuModSta
typedef uint8 COM_DT_DMIC_VcuModSta;

#  define Rte_TypeDef_COM_DT_ELK_SymbDisp
typedef uint8 COM_DT_ELK_SymbDisp;

#  define Rte_TypeDef_COM_DT_ELK_SysFlrSta
typedef uint8 COM_DT_ELK_SysFlrSta;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt11Val
typedef uint8 COM_DT_EMS_AlvCnt11Val;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt1Val
typedef uint8 COM_DT_EMS_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt2Val
typedef uint8 COM_DT_EMS_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt3Val
typedef uint8 COM_DT_EMS_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt5Val
typedef uint8 COM_DT_EMS_AlvCnt5Val;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt5Val_1
typedef uint8 COM_DT_EMS_AlvCnt5Val_1;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt5Val_2
typedef uint8 COM_DT_EMS_AlvCnt5Val_2;

#  define Rte_TypeDef_COM_DT_EMS_AlvCnt7Val
typedef uint8 COM_DT_EMS_AlvCnt7Val;

#  define Rte_TypeDef_COM_DT_EMS_BrkReq_Slope
typedef boolean COM_DT_EMS_BrkReq_Slope;

#  define Rte_TypeDef_COM_DT_EMS_Crc11Val
typedef uint16 COM_DT_EMS_Crc11Val;

#  define Rte_TypeDef_COM_DT_EMS_Crc1Val
typedef uint16 COM_DT_EMS_Crc1Val;

#  define Rte_TypeDef_COM_DT_EMS_Crc2Val
typedef uint16 COM_DT_EMS_Crc2Val;

#  define Rte_TypeDef_COM_DT_EMS_Crc3Val
typedef uint16 COM_DT_EMS_Crc3Val;

#  define Rte_TypeDef_COM_DT_EMS_Crc5Val
typedef uint16 COM_DT_EMS_Crc5Val;

#  define Rte_TypeDef_COM_DT_EMS_Crc5Val_1
typedef uint16 COM_DT_EMS_Crc5Val_1;

#  define Rte_TypeDef_COM_DT_EMS_Crc5Val_2
typedef uint16 COM_DT_EMS_Crc5Val_2;

#  define Rte_TypeDef_COM_DT_EMS_Crc7Val
typedef uint16 COM_DT_EMS_Crc7Val;

#  define Rte_TypeDef_COM_DT_EMS_EngStallDis
typedef boolean COM_DT_EMS_EngStallDis;

#  define Rte_TypeDef_COM_DT_EMS_PendingTrigSta
typedef boolean COM_DT_EMS_PendingTrigSta;

#  define Rte_TypeDef_COM_DT_EMS_RECTrigDta
typedef boolean COM_DT_EMS_RECTrigDta;

#  define Rte_TypeDef_COM_DT_ENG_AccActSta
typedef uint8 COM_DT_ENG_AccActSta;

#  define Rte_TypeDef_COM_DT_ENG_AccelPdlVal
typedef uint16 COM_DT_ENG_AccelPdlVal;

#  define Rte_TypeDef_COM_DT_ENG_Ack4TcsSta
typedef uint8 COM_DT_ENG_Ack4TcsSta;

#  define Rte_TypeDef_COM_DT_ENG_AirCompRlySta
typedef uint8 COM_DT_ENG_AirCompRlySta;

#  define Rte_TypeDef_COM_DT_ENG_AirconPrsrSnsrVal
typedef uint8 COM_DT_ENG_AirconPrsrSnsrVal;

#  define Rte_TypeDef_COM_DT_ENG_AltFdbckLoadVal
typedef uint8 COM_DT_ENG_AltFdbckLoadVal;

#  define Rte_TypeDef_COM_DT_ENG_AltFdbckLoadVal_1
typedef uint8 COM_DT_ENG_AltFdbckLoadVal_1;

#  define Rte_TypeDef_COM_DT_ENG_AmbtTempModelVal
typedef uint8 COM_DT_ENG_AmbtTempModelVal;

#  define Rte_TypeDef_COM_DT_ENG_AppAccelPdlSta
typedef uint8 COM_DT_ENG_AppAccelPdlSta;

#  define Rte_TypeDef_COM_DT_ENG_AtmsphPrsrVal
typedef uint8 COM_DT_ENG_AtmsphPrsrVal;

#  define Rte_TypeDef_COM_DT_ENG_AtmsphPrsrVal_1
typedef uint8 COM_DT_ENG_AtmsphPrsrVal_1;

#  define Rte_TypeDef_COM_DT_ENG_BattDscnctSta
typedef uint8 COM_DT_ENG_BattDscnctSta;

#  define Rte_TypeDef_COM_DT_ENG_BattVoltVal
typedef uint8 COM_DT_ENG_BattVoltVal;

#  define Rte_TypeDef_COM_DT_ENG_BattVoltVal_1
typedef uint8 COM_DT_ENG_BattVoltVal_1;

#  define Rte_TypeDef_COM_DT_ENG_BrkCtrlReq
typedef uint8 COM_DT_ENG_BrkCtrlReq;

#  define Rte_TypeDef_COM_DT_ENG_BrkSwSta
typedef uint8 COM_DT_ENG_BrkSwSta;

#  define Rte_TypeDef_COM_DT_ENG_BstPrsrVal
typedef uint16 COM_DT_ENG_BstPrsrVal;

#  define Rte_TypeDef_COM_DT_ENG_CrctEngTqVal
typedef sint16 COM_DT_ENG_CrctEngTqVal;

#  define Rte_TypeDef_COM_DT_ENG_CrctTqSta
typedef uint8 COM_DT_ENG_CrctTqSta;

#  define Rte_TypeDef_COM_DT_ENG_DclBrkCntrlReq
typedef uint16 COM_DT_ENG_DclBrkCntrlReq;

#  define Rte_TypeDef_COM_DT_ENG_DpfRgnSta
typedef boolean COM_DT_ENG_DpfRgnSta;

#  define Rte_TypeDef_COM_DT_ENG_EngClntTempVal
typedef uint8 COM_DT_ENG_EngClntTempVal;

#  define Rte_TypeDef_COM_DT_ENG_EngDsplceTyp
typedef uint8 COM_DT_ENG_EngDsplceTyp;

#  define Rte_TypeDef_COM_DT_ENG_EngDsplceTyp_1
typedef uint8 COM_DT_ENG_EngDsplceTyp_1;

#  define Rte_TypeDef_COM_DT_ENG_EngOilTempVal
typedef uint8 COM_DT_ENG_EngOilTempVal;

#  define Rte_TypeDef_COM_DT_ENG_EngSpdVal
typedef uint16 COM_DT_ENG_EngSpdVal;

#  define Rte_TypeDef_COM_DT_ENG_ExtSoakTimeVal
typedef uint8 COM_DT_ENG_ExtSoakTimeVal;

#  define Rte_TypeDef_COM_DT_ENG_ExtSoakTimeVal_1
typedef uint8 COM_DT_ENG_ExtSoakTimeVal_1;

#  define Rte_TypeDef_COM_DT_ENG_FrctTqVal
typedef sint16 COM_DT_ENG_FrctTqVal;

#  define Rte_TypeDef_COM_DT_ENG_FuelCnsmptVal
typedef uint16 COM_DT_ENG_FuelCnsmptVal;

#  define Rte_TypeDef_COM_DT_ENG_FuelTempVal
typedef uint8 COM_DT_ENG_FuelTempVal;

#  define Rte_TypeDef_COM_DT_ENG_FuelTempVal_1
typedef uint8 COM_DT_ENG_FuelTempVal_1;

#  define Rte_TypeDef_COM_DT_ENG_FuelTnkPrsrSta
typedef uint8 COM_DT_ENG_FuelTnkPrsrSta;

#  define Rte_TypeDef_COM_DT_ENG_GearPos
typedef uint16 COM_DT_ENG_GearPos;

#  define Rte_TypeDef_COM_DT_ENG_IgnOnSta
typedef uint8 COM_DT_ENG_IgnOnSta;

#  define Rte_TypeDef_COM_DT_ENG_IndTqBVal
typedef sint16 COM_DT_ENG_IndTqBVal;

#  define Rte_TypeDef_COM_DT_ENG_IndTqVal
typedef sint16 COM_DT_ENG_IndTqVal;

#  define Rte_TypeDef_COM_DT_ENG_Isg2Sta
typedef uint8 COM_DT_ENG_Isg2Sta;

#  define Rte_TypeDef_COM_DT_ENG_IsgDispDetail
typedef uint8 COM_DT_ENG_IsgDispDetail;

#  define Rte_TypeDef_COM_DT_ENG_IsgDispDetail_1
typedef uint8 COM_DT_ENG_IsgDispDetail_1;

#  define Rte_TypeDef_COM_DT_ENG_IsgSta
typedef uint8 COM_DT_ENG_IsgSta;

#  define Rte_TypeDef_COM_DT_ENG_KNK_Warning
typedef boolean COM_DT_ENG_KNK_Warning;

#  define Rte_TypeDef_COM_DT_ENG_LV_FUP_ENA_THD
typedef boolean COM_DT_ENG_LV_FUP_ENA_THD;

#  define Rte_TypeDef_COM_DT_ENG_MafCrctVal
typedef uint8 COM_DT_ENG_MafCrctVal;

#  define Rte_TypeDef_COM_DT_ENG_MaxAirconTqVal
typedef uint8 COM_DT_ENG_MaxAirconTqVal;

#  define Rte_TypeDef_COM_DT_ENG_MaxIndTqVal
typedef sint16 COM_DT_ENG_MaxIndTqVal;

#  define Rte_TypeDef_COM_DT_ENG_MinIndTqVal
typedef sint16 COM_DT_ENG_MinIndTqVal;

#  define Rte_TypeDef_COM_DT_ENG_MotRecupSta
typedef boolean COM_DT_ENG_MotRecupSta;

#  define Rte_TypeDef_COM_DT_ENG_ObdFrzFrmSta
typedef uint8 COM_DT_ENG_ObdFrzFrmSta;

#  define Rte_TypeDef_COM_DT_ENG_OilLifeRatio
typedef uint8 COM_DT_ENG_OilLifeRatio;

#  define Rte_TypeDef_COM_DT_ENG_OilLifeRatio_1
typedef uint8 COM_DT_ENG_OilLifeRatio_1;

#  define Rte_TypeDef_COM_DT_ENG_OilLifeWarn
typedef uint8 COM_DT_ENG_OilLifeWarn;

#  define Rte_TypeDef_COM_DT_ENG_OilLifeWarn_1
typedef uint8 COM_DT_ENG_OilLifeWarn_1;

#  define Rte_TypeDef_COM_DT_ENG_OverDrvOffReq
typedef uint8 COM_DT_ENG_OverDrvOffReq;

#  define Rte_TypeDef_COM_DT_ENG_SldFuncSta
typedef uint8 COM_DT_ENG_SldFuncSta;

#  define Rte_TypeDef_COM_DT_ENG_SldSwSta
typedef uint8 COM_DT_ENG_SldSwSta;

#  define Rte_TypeDef_COM_DT_ENG_SoakTimeVal
typedef uint8 COM_DT_ENG_SoakTimeVal;

#  define Rte_TypeDef_COM_DT_ENG_SprkTimeVal
typedef uint8 COM_DT_ENG_SprkTimeVal;

#  define Rte_TypeDef_COM_DT_ENG_StndTqRatioVal
typedef uint8 COM_DT_ENG_StndTqRatioVal;

#  define Rte_TypeDef_COM_DT_ENG_SysWarnLmpReq
typedef boolean COM_DT_ENG_SysWarnLmpReq;

#  define Rte_TypeDef_COM_DT_ENG_ThrPosVal
typedef uint8 COM_DT_ENG_ThrPosVal;

#  define Rte_TypeDef_COM_DT_ENG_TqStndValExt
typedef uint8 COM_DT_ENG_TqStndValExt;

#  define Rte_TypeDef_COM_DT_ENG_TqStndValExt_1
typedef uint8 COM_DT_ENG_TqStndValExt_1;

#  define Rte_TypeDef_COM_DT_ENG_TrgtFuelPmpPrsrVal
typedef uint8 COM_DT_ENG_TrgtFuelPmpPrsrVal;

#  define Rte_TypeDef_COM_DT_ENG_TrgtIdleRpmVal
typedef uint8 COM_DT_ENG_TrgtIdleRpmVal;

#  define Rte_TypeDef_COM_DT_ENG_TrgtTqVal
typedef sint16 COM_DT_ENG_TrgtTqVal;

#  define Rte_TypeDef_COM_DT_EPB_ActlFrcVal
typedef uint16 COM_DT_EPB_ActlFrcVal;

#  define Rte_TypeDef_COM_DT_EPB_AlvCnt1Val
typedef uint8 COM_DT_EPB_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_EPB_Crc1Val
typedef uint16 COM_DT_EPB_Crc1Val;

#  define Rte_TypeDef_COM_DT_EPB_DynmBrkFrcDclReq
typedef uint8 COM_DT_EPB_DynmBrkFrcDclReq;

#  define Rte_TypeDef_COM_DT_EPB_DynmBrkFrcReqSigSta
typedef uint8 COM_DT_EPB_DynmBrkFrcReqSigSta;

#  define Rte_TypeDef_COM_DT_EPB_EpbSta4VcuReq
typedef uint8 COM_DT_EPB_EpbSta4VcuReq;

#  define Rte_TypeDef_COM_DT_EPB_EscReqAckSta
typedef uint8 COM_DT_EPB_EscReqAckSta;

#  define Rte_TypeDef_COM_DT_EPB_FlrLmpStaDis
typedef uint8 COM_DT_EPB_FlrLmpStaDis;

#  define Rte_TypeDef_COM_DT_EPB_FrcErrSta
typedef uint8 COM_DT_EPB_FrcErrSta;

#  define Rte_TypeDef_COM_DT_EPB_LmpStaDis
typedef uint8 COM_DT_EPB_LmpStaDis;

#  define Rte_TypeDef_COM_DT_EPB_OutDataDis
typedef uint8 COM_DT_EPB_OutDataDis;

#  define Rte_TypeDef_COM_DT_EPB_RrBrkLtActvReq
typedef uint8 COM_DT_EPB_RrBrkLtActvReq;

#  define Rte_TypeDef_COM_DT_ESC_AccelBasisVal
typedef uint16 COM_DT_ESC_AccelBasisVal;

#  define Rte_TypeDef_COM_DT_ESC_AlvCnt1Val
typedef uint8 COM_DT_ESC_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_ESC_AlvCnt3Val
typedef uint8 COM_DT_ESC_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_ESC_BrkCtrlSta
typedef uint8 COM_DT_ESC_BrkCtrlSta;

#  define Rte_TypeDef_COM_DT_ESC_Crc1Val
typedef uint16 COM_DT_ESC_Crc1Val;

#  define Rte_TypeDef_COM_DT_ESC_Crc3Val
typedef uint16 COM_DT_ESC_Crc3Val;

#  define Rte_TypeDef_COM_DT_ESC_CylPrsrDiagSta
typedef uint8 COM_DT_ESC_CylPrsrDiagSta;

#  define Rte_TypeDef_COM_DT_ESC_CylPrsrSta
typedef uint8 COM_DT_ESC_CylPrsrSta;

#  define Rte_TypeDef_COM_DT_ESC_CylPrsrVal
typedef uint16 COM_DT_ESC_CylPrsrVal;

#  define Rte_TypeDef_COM_DT_ESC_DiffBrkFuncSta
typedef uint8 COM_DT_ESC_DiffBrkFuncSta;

#  define Rte_TypeDef_COM_DT_ESC_DrvBrkSta
typedef uint8 COM_DT_ESC_DrvBrkSta;

#  define Rte_TypeDef_COM_DT_ESC_HDP_EgSta
typedef uint8 COM_DT_ESC_HDP_EgSta;

#  define Rte_TypeDef_COM_DT_ESC_HDP_EnblReq
typedef uint8 COM_DT_ESC_HDP_EnblReq;

#  define Rte_TypeDef_COM_DT_ESC_HDP_FltMonSta
typedef uint8 COM_DT_ESC_HDP_FltMonSta;

#  define Rte_TypeDef_COM_DT_ESC_IMURstStaAck_1
typedef boolean COM_DT_ESC_IMURstStaAck_1;

#  define Rte_TypeDef_COM_DT_ESC_LongAccelOffstCalibPrmtr
typedef uint16 COM_DT_ESC_LongAccelOffstCalibPrmtr;

#  define Rte_TypeDef_COM_DT_ESC_LsdLimMod
typedef boolean COM_DT_ESC_LsdLimMod;

#  define Rte_TypeDef_COM_DT_ESC_LsdTqLim
typedef uint16 COM_DT_ESC_LsdTqLim;

#  define Rte_TypeDef_COM_DT_ESC_OffSwSta
typedef uint8 COM_DT_ESC_OffSwSta;

#  define Rte_TypeDef_COM_DT_ESC_RspaCanFlFlag
typedef uint8 COM_DT_ESC_RspaCanFlFlag;

#  define Rte_TypeDef_COM_DT_ESC_RspaStandStill
typedef uint8 COM_DT_ESC_RspaStandStill;

#  define Rte_TypeDef_COM_DT_ESC_Sta
typedef uint8 COM_DT_ESC_Sta;

#  define Rte_TypeDef_COM_DT_ESC_StrTqReq
typedef uint16 COM_DT_ESC_StrTqReq;

#  define Rte_TypeDef_COM_DT_ESC_VehAccelVal
typedef uint16 COM_DT_ESC_VehAccelVal;

#  define Rte_TypeDef_COM_DT_ESC_VsmCtrlModSta
typedef uint8 COM_DT_ESC_VsmCtrlModSta;

#  define Rte_TypeDef_COM_DT_Eng_OverRun
typedef boolean COM_DT_Eng_OverRun;

#  define Rte_TypeDef_COM_DT_FCA_DclReqVal
typedef uint8 COM_DT_FCA_DclReqVal;

#  define Rte_TypeDef_COM_DT_FCA_ESA_CtrlSta
typedef uint8 COM_DT_FCA_ESA_CtrlSta;

#  define Rte_TypeDef_COM_DT_FCA_ESA_TqBstGainVal
typedef uint8 COM_DT_FCA_ESA_TqBstGainVal;

#  define Rte_TypeDef_COM_DT_FCA_ESA_WrnSta
typedef uint8 COM_DT_FCA_ESA_WrnSta;

#  define Rte_TypeDef_COM_DT_FCA_LO_WrnSta
typedef uint8 COM_DT_FCA_LO_WrnSta;

#  define Rte_TypeDef_COM_DT_FCA_LS_WrnSta
typedef uint8 COM_DT_FCA_LS_WrnSta;

#  define Rte_TypeDef_COM_DT_FCA_OnOffEquipSta
typedef uint8 COM_DT_FCA_OnOffEquipSta;

#  define Rte_TypeDef_COM_DT_FCA_RelVel
typedef uint16 COM_DT_FCA_RelVel;

#  define Rte_TypeDef_COM_DT_FCA_SnstvtyModRetVal
typedef uint8 COM_DT_FCA_SnstvtyModRetVal;

#  define Rte_TypeDef_COM_DT_FCA_StbltActvReq
typedef uint8 COM_DT_FCA_StbltActvReq;

#  define Rte_TypeDef_COM_DT_FCA_SysFlrSta
typedef uint8 COM_DT_FCA_SysFlrSta;

#  define Rte_TypeDef_COM_DT_FCA_TimetoCllsn
typedef uint8 COM_DT_FCA_TimetoCllsn;

#  define Rte_TypeDef_COM_DT_FCA_WrngSndSta
typedef uint8 COM_DT_FCA_WrngSndSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_AlvCnt1Val
typedef uint8 COM_DT_FR_CMR_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_AlvCnt2Val
typedef uint8 COM_DT_FR_CMR_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_AlvCnt3Val
typedef uint8 COM_DT_FR_CMR_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_AlvCnt4Val
typedef uint8 COM_DT_FR_CMR_AlvCnt4Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_AlvCnt4Val_1
typedef uint8 COM_DT_FR_CMR_AlvCnt4Val_1;

#  define Rte_TypeDef_COM_DT_FR_CMR_Crc1Val
typedef uint16 COM_DT_FR_CMR_Crc1Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_Crc2Val
typedef uint16 COM_DT_FR_CMR_Crc2Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_Crc3Val
typedef uint16 COM_DT_FR_CMR_Crc3Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_Crc4Val
typedef uint16 COM_DT_FR_CMR_Crc4Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_Crc4Val_1
typedef uint16 COM_DT_FR_CMR_Crc4Val_1;

#  define Rte_TypeDef_COM_DT_FR_CMR_FCA_Plus_Sta
typedef uint8 COM_DT_FR_CMR_FCA_Plus_Sta;

#  define Rte_TypeDef_COM_DT_FR_CMR_FailInfoSta
typedef uint8 COM_DT_FR_CMR_FailInfoSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_ReqADASMapMsgVal
typedef uint16 COM_DT_FR_CMR_ReqADASMapMsgVal;

#  define Rte_TypeDef_COM_DT_FR_CMR_SwVer1Val
typedef uint8 COM_DT_FR_CMR_SwVer1Val;

#  define Rte_TypeDef_COM_DT_FR_CMR_SwVer2Val
typedef uint8 COM_DT_FR_CMR_SwVer2Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_CrcVal
typedef uint16 COM_DT_FR_RDR_CrcVal;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt01Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt02Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt03Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt04Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt05Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt06Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt07Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt08Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt09Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt10Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt11Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt12Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt13Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt14Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt15Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AlvCnt16Val
typedef uint8 COM_DT_FR_RDR_Det_AlvCnt16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed01
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed02
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed03
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed04
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed05
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed06
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed07
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed08
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed09
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed10
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed11
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed12
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed13
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed14
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed15
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed16
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed17
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed18
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed19
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed20
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed21
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed22
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed23
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed24
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed25
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed26
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed27
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed28
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed29
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed30
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed31
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed32
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed33
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed34
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed35
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed36
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed37
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed38
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed39
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed40
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed41
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed42
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed43
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed44
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed45
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed46
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed47
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed48
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed49
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed50
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed51
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed52
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed53
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed54
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed55
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed56
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed57
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed58
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed59
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed60
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed61
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed62
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed63
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AmbigSpeed64
typedef sint16 COM_DT_FR_RDR_Det_AmbigSpeed64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag01
typedef uint8 COM_DT_FR_RDR_Det_AssignTag01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag02
typedef uint8 COM_DT_FR_RDR_Det_AssignTag02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag03
typedef uint8 COM_DT_FR_RDR_Det_AssignTag03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag04
typedef uint8 COM_DT_FR_RDR_Det_AssignTag04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag05
typedef uint8 COM_DT_FR_RDR_Det_AssignTag05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag06
typedef uint8 COM_DT_FR_RDR_Det_AssignTag06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag07
typedef uint8 COM_DT_FR_RDR_Det_AssignTag07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag08
typedef uint8 COM_DT_FR_RDR_Det_AssignTag08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag09
typedef uint8 COM_DT_FR_RDR_Det_AssignTag09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag10
typedef uint8 COM_DT_FR_RDR_Det_AssignTag10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag11
typedef uint8 COM_DT_FR_RDR_Det_AssignTag11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag12
typedef uint8 COM_DT_FR_RDR_Det_AssignTag12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag13
typedef uint8 COM_DT_FR_RDR_Det_AssignTag13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag14
typedef uint8 COM_DT_FR_RDR_Det_AssignTag14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag15
typedef uint8 COM_DT_FR_RDR_Det_AssignTag15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag16
typedef uint8 COM_DT_FR_RDR_Det_AssignTag16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag17
typedef uint8 COM_DT_FR_RDR_Det_AssignTag17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag18
typedef uint8 COM_DT_FR_RDR_Det_AssignTag18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag19
typedef uint8 COM_DT_FR_RDR_Det_AssignTag19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag20
typedef uint8 COM_DT_FR_RDR_Det_AssignTag20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag21
typedef uint8 COM_DT_FR_RDR_Det_AssignTag21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag22
typedef uint8 COM_DT_FR_RDR_Det_AssignTag22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag23
typedef uint8 COM_DT_FR_RDR_Det_AssignTag23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag24
typedef uint8 COM_DT_FR_RDR_Det_AssignTag24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag25
typedef uint8 COM_DT_FR_RDR_Det_AssignTag25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag26
typedef uint8 COM_DT_FR_RDR_Det_AssignTag26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag27
typedef uint8 COM_DT_FR_RDR_Det_AssignTag27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag28
typedef uint8 COM_DT_FR_RDR_Det_AssignTag28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag29
typedef uint8 COM_DT_FR_RDR_Det_AssignTag29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag30
typedef uint8 COM_DT_FR_RDR_Det_AssignTag30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag31
typedef uint8 COM_DT_FR_RDR_Det_AssignTag31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag32
typedef uint8 COM_DT_FR_RDR_Det_AssignTag32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag33
typedef uint8 COM_DT_FR_RDR_Det_AssignTag33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag34
typedef uint8 COM_DT_FR_RDR_Det_AssignTag34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag35
typedef uint8 COM_DT_FR_RDR_Det_AssignTag35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag36
typedef uint8 COM_DT_FR_RDR_Det_AssignTag36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag37
typedef uint8 COM_DT_FR_RDR_Det_AssignTag37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag38
typedef uint8 COM_DT_FR_RDR_Det_AssignTag38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag39
typedef uint8 COM_DT_FR_RDR_Det_AssignTag39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag40
typedef uint8 COM_DT_FR_RDR_Det_AssignTag40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag41
typedef uint8 COM_DT_FR_RDR_Det_AssignTag41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag42
typedef uint8 COM_DT_FR_RDR_Det_AssignTag42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag43
typedef uint8 COM_DT_FR_RDR_Det_AssignTag43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag44
typedef uint8 COM_DT_FR_RDR_Det_AssignTag44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag45
typedef uint8 COM_DT_FR_RDR_Det_AssignTag45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag46
typedef uint8 COM_DT_FR_RDR_Det_AssignTag46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag47
typedef uint8 COM_DT_FR_RDR_Det_AssignTag47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag48
typedef uint8 COM_DT_FR_RDR_Det_AssignTag48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag49
typedef uint8 COM_DT_FR_RDR_Det_AssignTag49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag50
typedef uint8 COM_DT_FR_RDR_Det_AssignTag50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag51
typedef uint8 COM_DT_FR_RDR_Det_AssignTag51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag52
typedef uint8 COM_DT_FR_RDR_Det_AssignTag52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag53
typedef uint8 COM_DT_FR_RDR_Det_AssignTag53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag54
typedef uint8 COM_DT_FR_RDR_Det_AssignTag54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag55
typedef uint8 COM_DT_FR_RDR_Det_AssignTag55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag56
typedef uint8 COM_DT_FR_RDR_Det_AssignTag56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag57
typedef uint8 COM_DT_FR_RDR_Det_AssignTag57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag58
typedef uint8 COM_DT_FR_RDR_Det_AssignTag58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag59
typedef uint8 COM_DT_FR_RDR_Det_AssignTag59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag60
typedef uint8 COM_DT_FR_RDR_Det_AssignTag60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag61
typedef uint8 COM_DT_FR_RDR_Det_AssignTag61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag62
typedef uint8 COM_DT_FR_RDR_Det_AssignTag62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag63
typedef uint8 COM_DT_FR_RDR_Det_AssignTag63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_AssignTag64
typedef uint8 COM_DT_FR_RDR_Det_AssignTag64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute01
typedef uint8 COM_DT_FR_RDR_Det_Attribute01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute02
typedef uint8 COM_DT_FR_RDR_Det_Attribute02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute03
typedef uint8 COM_DT_FR_RDR_Det_Attribute03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute04
typedef uint8 COM_DT_FR_RDR_Det_Attribute04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute05
typedef uint8 COM_DT_FR_RDR_Det_Attribute05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute06
typedef uint8 COM_DT_FR_RDR_Det_Attribute06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute07
typedef uint8 COM_DT_FR_RDR_Det_Attribute07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute08
typedef uint8 COM_DT_FR_RDR_Det_Attribute08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute09
typedef uint8 COM_DT_FR_RDR_Det_Attribute09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute10
typedef uint8 COM_DT_FR_RDR_Det_Attribute10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute11
typedef uint8 COM_DT_FR_RDR_Det_Attribute11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute12
typedef uint8 COM_DT_FR_RDR_Det_Attribute12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute13
typedef uint8 COM_DT_FR_RDR_Det_Attribute13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute14
typedef uint8 COM_DT_FR_RDR_Det_Attribute14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute15
typedef uint8 COM_DT_FR_RDR_Det_Attribute15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute16
typedef uint8 COM_DT_FR_RDR_Det_Attribute16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute17
typedef uint8 COM_DT_FR_RDR_Det_Attribute17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute18
typedef uint8 COM_DT_FR_RDR_Det_Attribute18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute19
typedef uint8 COM_DT_FR_RDR_Det_Attribute19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute20
typedef uint8 COM_DT_FR_RDR_Det_Attribute20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute21
typedef uint8 COM_DT_FR_RDR_Det_Attribute21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute22
typedef uint8 COM_DT_FR_RDR_Det_Attribute22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute23
typedef uint8 COM_DT_FR_RDR_Det_Attribute23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute24
typedef uint8 COM_DT_FR_RDR_Det_Attribute24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute25
typedef uint8 COM_DT_FR_RDR_Det_Attribute25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute26
typedef uint8 COM_DT_FR_RDR_Det_Attribute26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute27
typedef uint8 COM_DT_FR_RDR_Det_Attribute27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute28
typedef uint8 COM_DT_FR_RDR_Det_Attribute28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute29
typedef uint8 COM_DT_FR_RDR_Det_Attribute29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute30
typedef uint8 COM_DT_FR_RDR_Det_Attribute30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute31
typedef uint8 COM_DT_FR_RDR_Det_Attribute31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute32
typedef uint8 COM_DT_FR_RDR_Det_Attribute32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute33
typedef uint8 COM_DT_FR_RDR_Det_Attribute33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute34
typedef uint8 COM_DT_FR_RDR_Det_Attribute34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute35
typedef uint8 COM_DT_FR_RDR_Det_Attribute35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute36
typedef uint8 COM_DT_FR_RDR_Det_Attribute36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute37
typedef uint8 COM_DT_FR_RDR_Det_Attribute37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute38
typedef uint8 COM_DT_FR_RDR_Det_Attribute38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute39
typedef uint8 COM_DT_FR_RDR_Det_Attribute39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute40
typedef uint8 COM_DT_FR_RDR_Det_Attribute40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute41
typedef uint8 COM_DT_FR_RDR_Det_Attribute41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute42
typedef uint8 COM_DT_FR_RDR_Det_Attribute42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute43
typedef uint8 COM_DT_FR_RDR_Det_Attribute43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute44
typedef uint8 COM_DT_FR_RDR_Det_Attribute44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute45
typedef uint8 COM_DT_FR_RDR_Det_Attribute45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute46
typedef uint8 COM_DT_FR_RDR_Det_Attribute46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute47
typedef uint8 COM_DT_FR_RDR_Det_Attribute47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute48
typedef uint8 COM_DT_FR_RDR_Det_Attribute48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute49
typedef uint8 COM_DT_FR_RDR_Det_Attribute49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute50
typedef uint8 COM_DT_FR_RDR_Det_Attribute50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute51
typedef uint8 COM_DT_FR_RDR_Det_Attribute51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute52
typedef uint8 COM_DT_FR_RDR_Det_Attribute52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute53
typedef uint8 COM_DT_FR_RDR_Det_Attribute53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute54
typedef uint8 COM_DT_FR_RDR_Det_Attribute54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute55
typedef uint8 COM_DT_FR_RDR_Det_Attribute55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute56
typedef uint8 COM_DT_FR_RDR_Det_Attribute56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute57
typedef uint8 COM_DT_FR_RDR_Det_Attribute57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute58
typedef uint8 COM_DT_FR_RDR_Det_Attribute58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute59
typedef uint8 COM_DT_FR_RDR_Det_Attribute59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute60
typedef uint8 COM_DT_FR_RDR_Det_Attribute60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute61
typedef uint8 COM_DT_FR_RDR_Det_Attribute61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute62
typedef uint8 COM_DT_FR_RDR_Det_Attribute62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute63
typedef uint8 COM_DT_FR_RDR_Det_Attribute63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Attribute64
typedef uint8 COM_DT_FR_RDR_Det_Attribute64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC01Val
typedef uint16 COM_DT_FR_RDR_Det_CRC01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC02Val
typedef uint16 COM_DT_FR_RDR_Det_CRC02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC03Val
typedef uint16 COM_DT_FR_RDR_Det_CRC03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC04Val
typedef uint16 COM_DT_FR_RDR_Det_CRC04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC05Val
typedef uint16 COM_DT_FR_RDR_Det_CRC05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC06Val
typedef uint16 COM_DT_FR_RDR_Det_CRC06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC07Val
typedef uint16 COM_DT_FR_RDR_Det_CRC07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC08Val
typedef uint16 COM_DT_FR_RDR_Det_CRC08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC09Val
typedef uint16 COM_DT_FR_RDR_Det_CRC09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC10Val
typedef uint16 COM_DT_FR_RDR_Det_CRC10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC11Val
typedef uint16 COM_DT_FR_RDR_Det_CRC11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC12Val
typedef uint16 COM_DT_FR_RDR_Det_CRC12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC13Val
typedef uint16 COM_DT_FR_RDR_Det_CRC13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC14Val
typedef uint16 COM_DT_FR_RDR_Det_CRC14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC15Val
typedef uint16 COM_DT_FR_RDR_Det_CRC15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_CRC16Val
typedef uint16 COM_DT_FR_RDR_Det_CRC16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID01
typedef uint8 COM_DT_FR_RDR_Det_ClusterID01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID02
typedef uint8 COM_DT_FR_RDR_Det_ClusterID02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID03
typedef uint8 COM_DT_FR_RDR_Det_ClusterID03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID04
typedef uint8 COM_DT_FR_RDR_Det_ClusterID04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID05
typedef uint8 COM_DT_FR_RDR_Det_ClusterID05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID06
typedef uint8 COM_DT_FR_RDR_Det_ClusterID06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID07
typedef uint8 COM_DT_FR_RDR_Det_ClusterID07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID08
typedef uint8 COM_DT_FR_RDR_Det_ClusterID08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID09
typedef uint8 COM_DT_FR_RDR_Det_ClusterID09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID10
typedef uint8 COM_DT_FR_RDR_Det_ClusterID10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID11
typedef uint8 COM_DT_FR_RDR_Det_ClusterID11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID12
typedef uint8 COM_DT_FR_RDR_Det_ClusterID12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID13
typedef uint8 COM_DT_FR_RDR_Det_ClusterID13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID14
typedef uint8 COM_DT_FR_RDR_Det_ClusterID14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID15
typedef uint8 COM_DT_FR_RDR_Det_ClusterID15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID16
typedef uint8 COM_DT_FR_RDR_Det_ClusterID16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID17
typedef uint8 COM_DT_FR_RDR_Det_ClusterID17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID18
typedef uint8 COM_DT_FR_RDR_Det_ClusterID18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID19
typedef uint8 COM_DT_FR_RDR_Det_ClusterID19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID20
typedef uint8 COM_DT_FR_RDR_Det_ClusterID20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID21
typedef uint8 COM_DT_FR_RDR_Det_ClusterID21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID22
typedef uint8 COM_DT_FR_RDR_Det_ClusterID22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID23
typedef uint8 COM_DT_FR_RDR_Det_ClusterID23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID24
typedef uint8 COM_DT_FR_RDR_Det_ClusterID24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID25
typedef uint8 COM_DT_FR_RDR_Det_ClusterID25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID26
typedef uint8 COM_DT_FR_RDR_Det_ClusterID26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID27
typedef uint8 COM_DT_FR_RDR_Det_ClusterID27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID28
typedef uint8 COM_DT_FR_RDR_Det_ClusterID28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID29
typedef uint8 COM_DT_FR_RDR_Det_ClusterID29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID30
typedef uint8 COM_DT_FR_RDR_Det_ClusterID30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID31
typedef uint8 COM_DT_FR_RDR_Det_ClusterID31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID32
typedef uint8 COM_DT_FR_RDR_Det_ClusterID32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID33
typedef uint8 COM_DT_FR_RDR_Det_ClusterID33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID34
typedef uint8 COM_DT_FR_RDR_Det_ClusterID34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID35
typedef uint8 COM_DT_FR_RDR_Det_ClusterID35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID36
typedef uint8 COM_DT_FR_RDR_Det_ClusterID36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID37
typedef uint8 COM_DT_FR_RDR_Det_ClusterID37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID38
typedef uint8 COM_DT_FR_RDR_Det_ClusterID38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID39
typedef uint8 COM_DT_FR_RDR_Det_ClusterID39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID40
typedef uint8 COM_DT_FR_RDR_Det_ClusterID40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID41
typedef uint8 COM_DT_FR_RDR_Det_ClusterID41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID42
typedef uint8 COM_DT_FR_RDR_Det_ClusterID42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID43
typedef uint8 COM_DT_FR_RDR_Det_ClusterID43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID44
typedef uint8 COM_DT_FR_RDR_Det_ClusterID44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID45
typedef uint8 COM_DT_FR_RDR_Det_ClusterID45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID46
typedef uint8 COM_DT_FR_RDR_Det_ClusterID46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID47
typedef uint8 COM_DT_FR_RDR_Det_ClusterID47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID48
typedef uint8 COM_DT_FR_RDR_Det_ClusterID48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID49
typedef uint8 COM_DT_FR_RDR_Det_ClusterID49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID50
typedef uint8 COM_DT_FR_RDR_Det_ClusterID50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID51
typedef uint8 COM_DT_FR_RDR_Det_ClusterID51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID52
typedef uint8 COM_DT_FR_RDR_Det_ClusterID52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID53
typedef uint8 COM_DT_FR_RDR_Det_ClusterID53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID54
typedef uint8 COM_DT_FR_RDR_Det_ClusterID54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID55
typedef uint8 COM_DT_FR_RDR_Det_ClusterID55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID56
typedef uint8 COM_DT_FR_RDR_Det_ClusterID56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID57
typedef uint8 COM_DT_FR_RDR_Det_ClusterID57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID58
typedef uint8 COM_DT_FR_RDR_Det_ClusterID58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID59
typedef uint8 COM_DT_FR_RDR_Det_ClusterID59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID60
typedef uint8 COM_DT_FR_RDR_Det_ClusterID60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID61
typedef uint8 COM_DT_FR_RDR_Det_ClusterID61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID62
typedef uint8 COM_DT_FR_RDR_Det_ClusterID62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID63
typedef uint8 COM_DT_FR_RDR_Det_ClusterID63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_ClusterID64
typedef uint8 COM_DT_FR_RDR_Det_ClusterID64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height01
typedef sint8 COM_DT_FR_RDR_Det_Height01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height02
typedef sint8 COM_DT_FR_RDR_Det_Height02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height03
typedef sint8 COM_DT_FR_RDR_Det_Height03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height04
typedef sint8 COM_DT_FR_RDR_Det_Height04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height05
typedef sint8 COM_DT_FR_RDR_Det_Height05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height06
typedef sint8 COM_DT_FR_RDR_Det_Height06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height07
typedef sint8 COM_DT_FR_RDR_Det_Height07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height08
typedef sint8 COM_DT_FR_RDR_Det_Height08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height09
typedef sint8 COM_DT_FR_RDR_Det_Height09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height10
typedef sint8 COM_DT_FR_RDR_Det_Height10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height11
typedef sint8 COM_DT_FR_RDR_Det_Height11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height12
typedef sint8 COM_DT_FR_RDR_Det_Height12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height13
typedef sint8 COM_DT_FR_RDR_Det_Height13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height14
typedef sint8 COM_DT_FR_RDR_Det_Height14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height15
typedef sint8 COM_DT_FR_RDR_Det_Height15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height16
typedef sint8 COM_DT_FR_RDR_Det_Height16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height17
typedef sint8 COM_DT_FR_RDR_Det_Height17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height18
typedef sint8 COM_DT_FR_RDR_Det_Height18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height19
typedef sint8 COM_DT_FR_RDR_Det_Height19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height20
typedef sint8 COM_DT_FR_RDR_Det_Height20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height21
typedef sint8 COM_DT_FR_RDR_Det_Height21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height22
typedef sint8 COM_DT_FR_RDR_Det_Height22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height23
typedef sint8 COM_DT_FR_RDR_Det_Height23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height24
typedef sint8 COM_DT_FR_RDR_Det_Height24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height25
typedef sint8 COM_DT_FR_RDR_Det_Height25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height26
typedef sint8 COM_DT_FR_RDR_Det_Height26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height27
typedef sint8 COM_DT_FR_RDR_Det_Height27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height28
typedef sint8 COM_DT_FR_RDR_Det_Height28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height29
typedef sint8 COM_DT_FR_RDR_Det_Height29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height30
typedef sint8 COM_DT_FR_RDR_Det_Height30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height31
typedef sint8 COM_DT_FR_RDR_Det_Height31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height32
typedef sint8 COM_DT_FR_RDR_Det_Height32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height33
typedef sint8 COM_DT_FR_RDR_Det_Height33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height34
typedef sint8 COM_DT_FR_RDR_Det_Height34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height35
typedef sint8 COM_DT_FR_RDR_Det_Height35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height36
typedef sint8 COM_DT_FR_RDR_Det_Height36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height37
typedef sint8 COM_DT_FR_RDR_Det_Height37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height38
typedef sint8 COM_DT_FR_RDR_Det_Height38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height39
typedef sint8 COM_DT_FR_RDR_Det_Height39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height40
typedef sint8 COM_DT_FR_RDR_Det_Height40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height41
typedef sint8 COM_DT_FR_RDR_Det_Height41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height42
typedef sint8 COM_DT_FR_RDR_Det_Height42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height43
typedef sint8 COM_DT_FR_RDR_Det_Height43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height44
typedef sint8 COM_DT_FR_RDR_Det_Height44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height45
typedef sint8 COM_DT_FR_RDR_Det_Height45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height46
typedef sint8 COM_DT_FR_RDR_Det_Height46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height47
typedef sint8 COM_DT_FR_RDR_Det_Height47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height48
typedef sint8 COM_DT_FR_RDR_Det_Height48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height49
typedef sint8 COM_DT_FR_RDR_Det_Height49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height50
typedef sint8 COM_DT_FR_RDR_Det_Height50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height51
typedef sint8 COM_DT_FR_RDR_Det_Height51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height52
typedef sint8 COM_DT_FR_RDR_Det_Height52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height53
typedef sint8 COM_DT_FR_RDR_Det_Height53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height54
typedef sint8 COM_DT_FR_RDR_Det_Height54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height55
typedef sint8 COM_DT_FR_RDR_Det_Height55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height56
typedef sint8 COM_DT_FR_RDR_Det_Height56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height57
typedef sint8 COM_DT_FR_RDR_Det_Height57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height58
typedef sint8 COM_DT_FR_RDR_Det_Height58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height59
typedef sint8 COM_DT_FR_RDR_Det_Height59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height60
typedef sint8 COM_DT_FR_RDR_Det_Height60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height61
typedef sint8 COM_DT_FR_RDR_Det_Height61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height62
typedef sint8 COM_DT_FR_RDR_Det_Height62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height63
typedef sint8 COM_DT_FR_RDR_Det_Height63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Height64
typedef sint8 COM_DT_FR_RDR_Det_Height64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat01
typedef sint16 COM_DT_FR_RDR_Det_Lat01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat02
typedef sint16 COM_DT_FR_RDR_Det_Lat02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat03
typedef sint16 COM_DT_FR_RDR_Det_Lat03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat04
typedef sint16 COM_DT_FR_RDR_Det_Lat04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat05
typedef sint16 COM_DT_FR_RDR_Det_Lat05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat06
typedef sint16 COM_DT_FR_RDR_Det_Lat06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat07
typedef sint16 COM_DT_FR_RDR_Det_Lat07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat08
typedef sint16 COM_DT_FR_RDR_Det_Lat08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat09
typedef sint16 COM_DT_FR_RDR_Det_Lat09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat10
typedef sint16 COM_DT_FR_RDR_Det_Lat10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat11
typedef sint16 COM_DT_FR_RDR_Det_Lat11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat12
typedef sint16 COM_DT_FR_RDR_Det_Lat12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat13
typedef sint16 COM_DT_FR_RDR_Det_Lat13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat14
typedef sint16 COM_DT_FR_RDR_Det_Lat14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat15
typedef sint16 COM_DT_FR_RDR_Det_Lat15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat16
typedef sint16 COM_DT_FR_RDR_Det_Lat16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat17
typedef sint16 COM_DT_FR_RDR_Det_Lat17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat18
typedef sint16 COM_DT_FR_RDR_Det_Lat18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat19
typedef sint16 COM_DT_FR_RDR_Det_Lat19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat20
typedef sint16 COM_DT_FR_RDR_Det_Lat20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat21
typedef sint16 COM_DT_FR_RDR_Det_Lat21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat22
typedef sint16 COM_DT_FR_RDR_Det_Lat22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat23
typedef sint16 COM_DT_FR_RDR_Det_Lat23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat24
typedef sint16 COM_DT_FR_RDR_Det_Lat24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat25
typedef sint16 COM_DT_FR_RDR_Det_Lat25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat26
typedef sint16 COM_DT_FR_RDR_Det_Lat26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat27
typedef sint16 COM_DT_FR_RDR_Det_Lat27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat28
typedef sint16 COM_DT_FR_RDR_Det_Lat28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat29
typedef sint16 COM_DT_FR_RDR_Det_Lat29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat30
typedef sint16 COM_DT_FR_RDR_Det_Lat30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat31
typedef sint16 COM_DT_FR_RDR_Det_Lat31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat32
typedef sint16 COM_DT_FR_RDR_Det_Lat32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat33
typedef sint16 COM_DT_FR_RDR_Det_Lat33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat34
typedef sint16 COM_DT_FR_RDR_Det_Lat34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat35
typedef sint16 COM_DT_FR_RDR_Det_Lat35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat36
typedef sint16 COM_DT_FR_RDR_Det_Lat36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat37
typedef sint16 COM_DT_FR_RDR_Det_Lat37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat38
typedef sint16 COM_DT_FR_RDR_Det_Lat38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat39
typedef sint16 COM_DT_FR_RDR_Det_Lat39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat40
typedef sint16 COM_DT_FR_RDR_Det_Lat40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat41
typedef sint16 COM_DT_FR_RDR_Det_Lat41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat42
typedef sint16 COM_DT_FR_RDR_Det_Lat42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat43
typedef sint16 COM_DT_FR_RDR_Det_Lat43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat44
typedef sint16 COM_DT_FR_RDR_Det_Lat44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat45
typedef sint16 COM_DT_FR_RDR_Det_Lat45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat46
typedef sint16 COM_DT_FR_RDR_Det_Lat46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat47
typedef sint16 COM_DT_FR_RDR_Det_Lat47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat48
typedef sint16 COM_DT_FR_RDR_Det_Lat48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat49
typedef sint16 COM_DT_FR_RDR_Det_Lat49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat50
typedef sint16 COM_DT_FR_RDR_Det_Lat50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat51
typedef sint16 COM_DT_FR_RDR_Det_Lat51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat52
typedef sint16 COM_DT_FR_RDR_Det_Lat52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat53
typedef sint16 COM_DT_FR_RDR_Det_Lat53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat54
typedef sint16 COM_DT_FR_RDR_Det_Lat54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat55
typedef sint16 COM_DT_FR_RDR_Det_Lat55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat56
typedef sint16 COM_DT_FR_RDR_Det_Lat56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat57
typedef sint16 COM_DT_FR_RDR_Det_Lat57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat58
typedef sint16 COM_DT_FR_RDR_Det_Lat58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat59
typedef sint16 COM_DT_FR_RDR_Det_Lat59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat60
typedef sint16 COM_DT_FR_RDR_Det_Lat60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat61
typedef sint16 COM_DT_FR_RDR_Det_Lat61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat62
typedef sint16 COM_DT_FR_RDR_Det_Lat62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat63
typedef sint16 COM_DT_FR_RDR_Det_Lat63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Lat64
typedef sint16 COM_DT_FR_RDR_Det_Lat64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long01
typedef uint16 COM_DT_FR_RDR_Det_Long01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long02
typedef uint16 COM_DT_FR_RDR_Det_Long02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long03
typedef uint16 COM_DT_FR_RDR_Det_Long03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long04
typedef uint16 COM_DT_FR_RDR_Det_Long04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long05
typedef uint16 COM_DT_FR_RDR_Det_Long05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long06
typedef uint16 COM_DT_FR_RDR_Det_Long06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long07
typedef uint16 COM_DT_FR_RDR_Det_Long07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long08
typedef uint16 COM_DT_FR_RDR_Det_Long08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long09
typedef uint16 COM_DT_FR_RDR_Det_Long09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long10
typedef uint16 COM_DT_FR_RDR_Det_Long10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long11
typedef uint16 COM_DT_FR_RDR_Det_Long11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long12
typedef uint16 COM_DT_FR_RDR_Det_Long12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long13
typedef uint16 COM_DT_FR_RDR_Det_Long13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long14
typedef uint16 COM_DT_FR_RDR_Det_Long14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long15
typedef uint16 COM_DT_FR_RDR_Det_Long15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long16
typedef uint16 COM_DT_FR_RDR_Det_Long16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long17
typedef uint16 COM_DT_FR_RDR_Det_Long17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long18
typedef uint16 COM_DT_FR_RDR_Det_Long18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long19
typedef uint16 COM_DT_FR_RDR_Det_Long19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long20
typedef uint16 COM_DT_FR_RDR_Det_Long20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long21
typedef uint16 COM_DT_FR_RDR_Det_Long21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long22
typedef uint16 COM_DT_FR_RDR_Det_Long22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long23
typedef uint16 COM_DT_FR_RDR_Det_Long23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long24
typedef uint16 COM_DT_FR_RDR_Det_Long24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long25
typedef uint16 COM_DT_FR_RDR_Det_Long25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long26
typedef uint16 COM_DT_FR_RDR_Det_Long26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long27
typedef uint16 COM_DT_FR_RDR_Det_Long27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long28
typedef uint16 COM_DT_FR_RDR_Det_Long28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long29
typedef uint16 COM_DT_FR_RDR_Det_Long29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long30
typedef uint16 COM_DT_FR_RDR_Det_Long30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long31
typedef uint16 COM_DT_FR_RDR_Det_Long31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long32
typedef uint16 COM_DT_FR_RDR_Det_Long32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long33
typedef uint16 COM_DT_FR_RDR_Det_Long33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long34
typedef uint16 COM_DT_FR_RDR_Det_Long34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long35
typedef uint16 COM_DT_FR_RDR_Det_Long35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long36
typedef uint16 COM_DT_FR_RDR_Det_Long36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long37
typedef uint16 COM_DT_FR_RDR_Det_Long37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long38
typedef uint16 COM_DT_FR_RDR_Det_Long38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long39
typedef uint16 COM_DT_FR_RDR_Det_Long39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long40
typedef uint16 COM_DT_FR_RDR_Det_Long40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long41
typedef uint16 COM_DT_FR_RDR_Det_Long41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long42
typedef uint16 COM_DT_FR_RDR_Det_Long42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long43
typedef uint16 COM_DT_FR_RDR_Det_Long43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long44
typedef uint16 COM_DT_FR_RDR_Det_Long44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long45
typedef uint16 COM_DT_FR_RDR_Det_Long45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long46
typedef uint16 COM_DT_FR_RDR_Det_Long46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long47
typedef uint16 COM_DT_FR_RDR_Det_Long47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long48
typedef uint16 COM_DT_FR_RDR_Det_Long48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long49
typedef uint16 COM_DT_FR_RDR_Det_Long49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long50
typedef uint16 COM_DT_FR_RDR_Det_Long50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long51
typedef uint16 COM_DT_FR_RDR_Det_Long51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long52
typedef uint16 COM_DT_FR_RDR_Det_Long52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long53
typedef uint16 COM_DT_FR_RDR_Det_Long53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long54
typedef uint16 COM_DT_FR_RDR_Det_Long54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long55
typedef uint16 COM_DT_FR_RDR_Det_Long55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long56
typedef uint16 COM_DT_FR_RDR_Det_Long56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long57
typedef uint16 COM_DT_FR_RDR_Det_Long57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long58
typedef uint16 COM_DT_FR_RDR_Det_Long58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long59
typedef uint16 COM_DT_FR_RDR_Det_Long59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long60
typedef uint16 COM_DT_FR_RDR_Det_Long60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long61
typedef uint16 COM_DT_FR_RDR_Det_Long61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long62
typedef uint16 COM_DT_FR_RDR_Det_Long62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long63
typedef uint16 COM_DT_FR_RDR_Det_Long63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Long64
typedef uint16 COM_DT_FR_RDR_Det_Long64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov01
typedef boolean COM_DT_FR_RDR_Det_Mov01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov02
typedef boolean COM_DT_FR_RDR_Det_Mov02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov03
typedef boolean COM_DT_FR_RDR_Det_Mov03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov04
typedef boolean COM_DT_FR_RDR_Det_Mov04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov05
typedef boolean COM_DT_FR_RDR_Det_Mov05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov06
typedef boolean COM_DT_FR_RDR_Det_Mov06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov07
typedef boolean COM_DT_FR_RDR_Det_Mov07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov08
typedef boolean COM_DT_FR_RDR_Det_Mov08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov09
typedef boolean COM_DT_FR_RDR_Det_Mov09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov10
typedef boolean COM_DT_FR_RDR_Det_Mov10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov11
typedef boolean COM_DT_FR_RDR_Det_Mov11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov12
typedef boolean COM_DT_FR_RDR_Det_Mov12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov13
typedef boolean COM_DT_FR_RDR_Det_Mov13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov14
typedef boolean COM_DT_FR_RDR_Det_Mov14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov15
typedef boolean COM_DT_FR_RDR_Det_Mov15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov16
typedef boolean COM_DT_FR_RDR_Det_Mov16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov17
typedef boolean COM_DT_FR_RDR_Det_Mov17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov18
typedef boolean COM_DT_FR_RDR_Det_Mov18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov19
typedef boolean COM_DT_FR_RDR_Det_Mov19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov20
typedef boolean COM_DT_FR_RDR_Det_Mov20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov21
typedef boolean COM_DT_FR_RDR_Det_Mov21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov22
typedef boolean COM_DT_FR_RDR_Det_Mov22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov23
typedef boolean COM_DT_FR_RDR_Det_Mov23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov24
typedef boolean COM_DT_FR_RDR_Det_Mov24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov25
typedef boolean COM_DT_FR_RDR_Det_Mov25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov26
typedef boolean COM_DT_FR_RDR_Det_Mov26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov27
typedef boolean COM_DT_FR_RDR_Det_Mov27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov28
typedef boolean COM_DT_FR_RDR_Det_Mov28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov29
typedef boolean COM_DT_FR_RDR_Det_Mov29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov30
typedef boolean COM_DT_FR_RDR_Det_Mov30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov31
typedef boolean COM_DT_FR_RDR_Det_Mov31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov32
typedef boolean COM_DT_FR_RDR_Det_Mov32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov33
typedef boolean COM_DT_FR_RDR_Det_Mov33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov34
typedef boolean COM_DT_FR_RDR_Det_Mov34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov35
typedef boolean COM_DT_FR_RDR_Det_Mov35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov36
typedef boolean COM_DT_FR_RDR_Det_Mov36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov37
typedef boolean COM_DT_FR_RDR_Det_Mov37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov38
typedef boolean COM_DT_FR_RDR_Det_Mov38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov39
typedef boolean COM_DT_FR_RDR_Det_Mov39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov40
typedef boolean COM_DT_FR_RDR_Det_Mov40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov41
typedef boolean COM_DT_FR_RDR_Det_Mov41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov42
typedef boolean COM_DT_FR_RDR_Det_Mov42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov43
typedef boolean COM_DT_FR_RDR_Det_Mov43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov44
typedef boolean COM_DT_FR_RDR_Det_Mov44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov45
typedef boolean COM_DT_FR_RDR_Det_Mov45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov46
typedef boolean COM_DT_FR_RDR_Det_Mov46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov47
typedef boolean COM_DT_FR_RDR_Det_Mov47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov48
typedef boolean COM_DT_FR_RDR_Det_Mov48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov49
typedef boolean COM_DT_FR_RDR_Det_Mov49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov50
typedef boolean COM_DT_FR_RDR_Det_Mov50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov51
typedef boolean COM_DT_FR_RDR_Det_Mov51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov52
typedef boolean COM_DT_FR_RDR_Det_Mov52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov53
typedef boolean COM_DT_FR_RDR_Det_Mov53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov54
typedef boolean COM_DT_FR_RDR_Det_Mov54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov55
typedef boolean COM_DT_FR_RDR_Det_Mov55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov56
typedef boolean COM_DT_FR_RDR_Det_Mov56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov57
typedef boolean COM_DT_FR_RDR_Det_Mov57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov58
typedef boolean COM_DT_FR_RDR_Det_Mov58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov59
typedef boolean COM_DT_FR_RDR_Det_Mov59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov60
typedef boolean COM_DT_FR_RDR_Det_Mov60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov61
typedef boolean COM_DT_FR_RDR_Det_Mov61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov62
typedef boolean COM_DT_FR_RDR_Det_Mov62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov63
typedef boolean COM_DT_FR_RDR_Det_Mov63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Mov64
typedef boolean COM_DT_FR_RDR_Det_Mov64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR01
typedef uint16 COM_DT_FR_RDR_Det_SNR01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR02
typedef uint16 COM_DT_FR_RDR_Det_SNR02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR03
typedef uint16 COM_DT_FR_RDR_Det_SNR03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR04
typedef uint16 COM_DT_FR_RDR_Det_SNR04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR05
typedef uint16 COM_DT_FR_RDR_Det_SNR05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR06
typedef uint16 COM_DT_FR_RDR_Det_SNR06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR07
typedef uint16 COM_DT_FR_RDR_Det_SNR07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR08
typedef uint16 COM_DT_FR_RDR_Det_SNR08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR09
typedef uint16 COM_DT_FR_RDR_Det_SNR09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR10
typedef uint16 COM_DT_FR_RDR_Det_SNR10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR11
typedef uint16 COM_DT_FR_RDR_Det_SNR11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR12
typedef uint16 COM_DT_FR_RDR_Det_SNR12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR13
typedef uint16 COM_DT_FR_RDR_Det_SNR13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR14
typedef uint16 COM_DT_FR_RDR_Det_SNR14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR15
typedef uint16 COM_DT_FR_RDR_Det_SNR15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR16
typedef uint16 COM_DT_FR_RDR_Det_SNR16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR17
typedef uint16 COM_DT_FR_RDR_Det_SNR17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR18
typedef uint16 COM_DT_FR_RDR_Det_SNR18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR19
typedef uint16 COM_DT_FR_RDR_Det_SNR19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR20
typedef uint16 COM_DT_FR_RDR_Det_SNR20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR21
typedef uint16 COM_DT_FR_RDR_Det_SNR21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR22
typedef uint16 COM_DT_FR_RDR_Det_SNR22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR23
typedef uint16 COM_DT_FR_RDR_Det_SNR23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR24
typedef uint16 COM_DT_FR_RDR_Det_SNR24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR25
typedef uint16 COM_DT_FR_RDR_Det_SNR25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR26
typedef uint16 COM_DT_FR_RDR_Det_SNR26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR27
typedef uint16 COM_DT_FR_RDR_Det_SNR27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR28
typedef uint16 COM_DT_FR_RDR_Det_SNR28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR29
typedef uint16 COM_DT_FR_RDR_Det_SNR29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR30
typedef uint16 COM_DT_FR_RDR_Det_SNR30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR31
typedef uint16 COM_DT_FR_RDR_Det_SNR31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR32
typedef uint16 COM_DT_FR_RDR_Det_SNR32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR33
typedef uint16 COM_DT_FR_RDR_Det_SNR33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR34
typedef uint16 COM_DT_FR_RDR_Det_SNR34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR35
typedef uint16 COM_DT_FR_RDR_Det_SNR35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR36
typedef uint16 COM_DT_FR_RDR_Det_SNR36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR37
typedef uint16 COM_DT_FR_RDR_Det_SNR37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR38
typedef uint16 COM_DT_FR_RDR_Det_SNR38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR39
typedef uint16 COM_DT_FR_RDR_Det_SNR39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR40
typedef uint16 COM_DT_FR_RDR_Det_SNR40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR41
typedef uint16 COM_DT_FR_RDR_Det_SNR41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR42
typedef uint16 COM_DT_FR_RDR_Det_SNR42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR43
typedef uint16 COM_DT_FR_RDR_Det_SNR43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR44
typedef uint16 COM_DT_FR_RDR_Det_SNR44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR45
typedef uint16 COM_DT_FR_RDR_Det_SNR45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR46
typedef uint16 COM_DT_FR_RDR_Det_SNR46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR47
typedef uint16 COM_DT_FR_RDR_Det_SNR47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR48
typedef uint16 COM_DT_FR_RDR_Det_SNR48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR49
typedef uint16 COM_DT_FR_RDR_Det_SNR49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR50
typedef uint16 COM_DT_FR_RDR_Det_SNR50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR51
typedef uint16 COM_DT_FR_RDR_Det_SNR51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR52
typedef uint16 COM_DT_FR_RDR_Det_SNR52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR53
typedef uint16 COM_DT_FR_RDR_Det_SNR53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR54
typedef uint16 COM_DT_FR_RDR_Det_SNR54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR55
typedef uint16 COM_DT_FR_RDR_Det_SNR55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR56
typedef uint16 COM_DT_FR_RDR_Det_SNR56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR57
typedef uint16 COM_DT_FR_RDR_Det_SNR57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR58
typedef uint16 COM_DT_FR_RDR_Det_SNR58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR59
typedef uint16 COM_DT_FR_RDR_Det_SNR59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR60
typedef uint16 COM_DT_FR_RDR_Det_SNR60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR61
typedef uint16 COM_DT_FR_RDR_Det_SNR61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR62
typedef uint16 COM_DT_FR_RDR_Det_SNR62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR63
typedef uint16 COM_DT_FR_RDR_Det_SNR63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_SNR64
typedef uint16 COM_DT_FR_RDR_Det_SNR64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed01
typedef sint16 COM_DT_FR_RDR_Det_Speed01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed02
typedef sint16 COM_DT_FR_RDR_Det_Speed02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed03
typedef sint16 COM_DT_FR_RDR_Det_Speed03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed04
typedef sint16 COM_DT_FR_RDR_Det_Speed04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed05
typedef sint16 COM_DT_FR_RDR_Det_Speed05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed06
typedef sint16 COM_DT_FR_RDR_Det_Speed06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed07
typedef sint16 COM_DT_FR_RDR_Det_Speed07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed08
typedef sint16 COM_DT_FR_RDR_Det_Speed08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed09
typedef sint16 COM_DT_FR_RDR_Det_Speed09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed10
typedef sint16 COM_DT_FR_RDR_Det_Speed10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed11
typedef sint16 COM_DT_FR_RDR_Det_Speed11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed12
typedef sint16 COM_DT_FR_RDR_Det_Speed12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed13
typedef sint16 COM_DT_FR_RDR_Det_Speed13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed14
typedef sint16 COM_DT_FR_RDR_Det_Speed14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed15
typedef sint16 COM_DT_FR_RDR_Det_Speed15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed16
typedef sint16 COM_DT_FR_RDR_Det_Speed16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed17
typedef sint16 COM_DT_FR_RDR_Det_Speed17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed18
typedef sint16 COM_DT_FR_RDR_Det_Speed18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed19
typedef sint16 COM_DT_FR_RDR_Det_Speed19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed20
typedef sint16 COM_DT_FR_RDR_Det_Speed20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed21
typedef sint16 COM_DT_FR_RDR_Det_Speed21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed22
typedef sint16 COM_DT_FR_RDR_Det_Speed22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed23
typedef sint16 COM_DT_FR_RDR_Det_Speed23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed24
typedef sint16 COM_DT_FR_RDR_Det_Speed24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed25
typedef sint16 COM_DT_FR_RDR_Det_Speed25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed26
typedef sint16 COM_DT_FR_RDR_Det_Speed26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed27
typedef sint16 COM_DT_FR_RDR_Det_Speed27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed28
typedef sint16 COM_DT_FR_RDR_Det_Speed28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed29
typedef sint16 COM_DT_FR_RDR_Det_Speed29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed30
typedef sint16 COM_DT_FR_RDR_Det_Speed30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed31
typedef sint16 COM_DT_FR_RDR_Det_Speed31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed32
typedef sint16 COM_DT_FR_RDR_Det_Speed32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed33
typedef sint16 COM_DT_FR_RDR_Det_Speed33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed34
typedef sint16 COM_DT_FR_RDR_Det_Speed34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed35
typedef sint16 COM_DT_FR_RDR_Det_Speed35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed36
typedef sint16 COM_DT_FR_RDR_Det_Speed36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed37
typedef sint16 COM_DT_FR_RDR_Det_Speed37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed38
typedef sint16 COM_DT_FR_RDR_Det_Speed38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed39
typedef sint16 COM_DT_FR_RDR_Det_Speed39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed40
typedef sint16 COM_DT_FR_RDR_Det_Speed40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed41
typedef sint16 COM_DT_FR_RDR_Det_Speed41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed42
typedef sint16 COM_DT_FR_RDR_Det_Speed42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed43
typedef sint16 COM_DT_FR_RDR_Det_Speed43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed44
typedef sint16 COM_DT_FR_RDR_Det_Speed44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed45
typedef sint16 COM_DT_FR_RDR_Det_Speed45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed46
typedef sint16 COM_DT_FR_RDR_Det_Speed46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed47
typedef sint16 COM_DT_FR_RDR_Det_Speed47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed48
typedef sint16 COM_DT_FR_RDR_Det_Speed48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed49
typedef sint16 COM_DT_FR_RDR_Det_Speed49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed50
typedef sint16 COM_DT_FR_RDR_Det_Speed50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed51
typedef sint16 COM_DT_FR_RDR_Det_Speed51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed52
typedef sint16 COM_DT_FR_RDR_Det_Speed52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed53
typedef sint16 COM_DT_FR_RDR_Det_Speed53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed54
typedef sint16 COM_DT_FR_RDR_Det_Speed54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed55
typedef sint16 COM_DT_FR_RDR_Det_Speed55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed56
typedef sint16 COM_DT_FR_RDR_Det_Speed56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed57
typedef sint16 COM_DT_FR_RDR_Det_Speed57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed58
typedef sint16 COM_DT_FR_RDR_Det_Speed58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed59
typedef sint16 COM_DT_FR_RDR_Det_Speed59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed60
typedef sint16 COM_DT_FR_RDR_Det_Speed60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed61
typedef sint16 COM_DT_FR_RDR_Det_Speed61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed62
typedef sint16 COM_DT_FR_RDR_Det_Speed62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed63
typedef sint16 COM_DT_FR_RDR_Det_Speed63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Speed64
typedef sint16 COM_DT_FR_RDR_Det_Speed64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA01
typedef uint8 COM_DT_FR_RDR_Det_TrustA01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA02
typedef uint8 COM_DT_FR_RDR_Det_TrustA02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA03
typedef uint8 COM_DT_FR_RDR_Det_TrustA03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA04
typedef uint8 COM_DT_FR_RDR_Det_TrustA04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA05
typedef uint8 COM_DT_FR_RDR_Det_TrustA05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA06
typedef uint8 COM_DT_FR_RDR_Det_TrustA06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA07
typedef uint8 COM_DT_FR_RDR_Det_TrustA07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA08
typedef uint8 COM_DT_FR_RDR_Det_TrustA08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA09
typedef uint8 COM_DT_FR_RDR_Det_TrustA09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA10
typedef uint8 COM_DT_FR_RDR_Det_TrustA10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA11
typedef uint8 COM_DT_FR_RDR_Det_TrustA11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA12
typedef uint8 COM_DT_FR_RDR_Det_TrustA12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA13
typedef uint8 COM_DT_FR_RDR_Det_TrustA13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA14
typedef uint8 COM_DT_FR_RDR_Det_TrustA14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA15
typedef uint8 COM_DT_FR_RDR_Det_TrustA15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA16
typedef uint8 COM_DT_FR_RDR_Det_TrustA16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA17
typedef uint8 COM_DT_FR_RDR_Det_TrustA17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA18
typedef uint8 COM_DT_FR_RDR_Det_TrustA18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA19
typedef uint8 COM_DT_FR_RDR_Det_TrustA19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA20
typedef uint8 COM_DT_FR_RDR_Det_TrustA20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA21
typedef uint8 COM_DT_FR_RDR_Det_TrustA21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA22
typedef uint8 COM_DT_FR_RDR_Det_TrustA22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA23
typedef uint8 COM_DT_FR_RDR_Det_TrustA23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA24
typedef uint8 COM_DT_FR_RDR_Det_TrustA24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA25
typedef uint8 COM_DT_FR_RDR_Det_TrustA25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA26
typedef uint8 COM_DT_FR_RDR_Det_TrustA26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA27
typedef uint8 COM_DT_FR_RDR_Det_TrustA27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA28
typedef uint8 COM_DT_FR_RDR_Det_TrustA28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA29
typedef uint8 COM_DT_FR_RDR_Det_TrustA29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA30
typedef uint8 COM_DT_FR_RDR_Det_TrustA30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA31
typedef uint8 COM_DT_FR_RDR_Det_TrustA31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA32
typedef uint8 COM_DT_FR_RDR_Det_TrustA32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA33
typedef uint8 COM_DT_FR_RDR_Det_TrustA33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA34
typedef uint8 COM_DT_FR_RDR_Det_TrustA34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA35
typedef uint8 COM_DT_FR_RDR_Det_TrustA35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA36
typedef uint8 COM_DT_FR_RDR_Det_TrustA36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA37
typedef uint8 COM_DT_FR_RDR_Det_TrustA37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA38
typedef uint8 COM_DT_FR_RDR_Det_TrustA38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA39
typedef uint8 COM_DT_FR_RDR_Det_TrustA39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA40
typedef uint8 COM_DT_FR_RDR_Det_TrustA40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA41
typedef uint8 COM_DT_FR_RDR_Det_TrustA41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA42
typedef uint8 COM_DT_FR_RDR_Det_TrustA42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA43
typedef uint8 COM_DT_FR_RDR_Det_TrustA43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA44
typedef uint8 COM_DT_FR_RDR_Det_TrustA44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA45
typedef uint8 COM_DT_FR_RDR_Det_TrustA45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA46
typedef uint8 COM_DT_FR_RDR_Det_TrustA46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA47
typedef uint8 COM_DT_FR_RDR_Det_TrustA47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA48
typedef uint8 COM_DT_FR_RDR_Det_TrustA48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA49
typedef uint8 COM_DT_FR_RDR_Det_TrustA49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA50
typedef uint8 COM_DT_FR_RDR_Det_TrustA50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA51
typedef uint8 COM_DT_FR_RDR_Det_TrustA51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA52
typedef uint8 COM_DT_FR_RDR_Det_TrustA52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA53
typedef uint8 COM_DT_FR_RDR_Det_TrustA53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA54
typedef uint8 COM_DT_FR_RDR_Det_TrustA54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA55
typedef uint8 COM_DT_FR_RDR_Det_TrustA55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA56
typedef uint8 COM_DT_FR_RDR_Det_TrustA56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA57
typedef uint8 COM_DT_FR_RDR_Det_TrustA57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA58
typedef uint8 COM_DT_FR_RDR_Det_TrustA58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA59
typedef uint8 COM_DT_FR_RDR_Det_TrustA59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA60
typedef uint8 COM_DT_FR_RDR_Det_TrustA60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA61
typedef uint8 COM_DT_FR_RDR_Det_TrustA61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA62
typedef uint8 COM_DT_FR_RDR_Det_TrustA62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA63
typedef uint8 COM_DT_FR_RDR_Det_TrustA63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustA64
typedef uint8 COM_DT_FR_RDR_Det_TrustA64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV01
typedef uint8 COM_DT_FR_RDR_Det_TrustV01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV02
typedef uint8 COM_DT_FR_RDR_Det_TrustV02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV03
typedef uint8 COM_DT_FR_RDR_Det_TrustV03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV04
typedef uint8 COM_DT_FR_RDR_Det_TrustV04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV05
typedef uint8 COM_DT_FR_RDR_Det_TrustV05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV06
typedef uint8 COM_DT_FR_RDR_Det_TrustV06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV07
typedef uint8 COM_DT_FR_RDR_Det_TrustV07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV08
typedef uint8 COM_DT_FR_RDR_Det_TrustV08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV09
typedef uint8 COM_DT_FR_RDR_Det_TrustV09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV10
typedef uint8 COM_DT_FR_RDR_Det_TrustV10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV11
typedef uint8 COM_DT_FR_RDR_Det_TrustV11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV12
typedef uint8 COM_DT_FR_RDR_Det_TrustV12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV13
typedef uint8 COM_DT_FR_RDR_Det_TrustV13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV14
typedef uint8 COM_DT_FR_RDR_Det_TrustV14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV15
typedef uint8 COM_DT_FR_RDR_Det_TrustV15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV16
typedef uint8 COM_DT_FR_RDR_Det_TrustV16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV17
typedef uint8 COM_DT_FR_RDR_Det_TrustV17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV18
typedef uint8 COM_DT_FR_RDR_Det_TrustV18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV19
typedef uint8 COM_DT_FR_RDR_Det_TrustV19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV20
typedef uint8 COM_DT_FR_RDR_Det_TrustV20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV21
typedef uint8 COM_DT_FR_RDR_Det_TrustV21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV22
typedef uint8 COM_DT_FR_RDR_Det_TrustV22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV23
typedef uint8 COM_DT_FR_RDR_Det_TrustV23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV24
typedef uint8 COM_DT_FR_RDR_Det_TrustV24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV25
typedef uint8 COM_DT_FR_RDR_Det_TrustV25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV26
typedef uint8 COM_DT_FR_RDR_Det_TrustV26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV27
typedef uint8 COM_DT_FR_RDR_Det_TrustV27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV28
typedef uint8 COM_DT_FR_RDR_Det_TrustV28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV29
typedef uint8 COM_DT_FR_RDR_Det_TrustV29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV30
typedef uint8 COM_DT_FR_RDR_Det_TrustV30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV31
typedef uint8 COM_DT_FR_RDR_Det_TrustV31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV32
typedef uint8 COM_DT_FR_RDR_Det_TrustV32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV33
typedef uint8 COM_DT_FR_RDR_Det_TrustV33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV34
typedef uint8 COM_DT_FR_RDR_Det_TrustV34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV35
typedef uint8 COM_DT_FR_RDR_Det_TrustV35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV36
typedef uint8 COM_DT_FR_RDR_Det_TrustV36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV37
typedef uint8 COM_DT_FR_RDR_Det_TrustV37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV38
typedef uint8 COM_DT_FR_RDR_Det_TrustV38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV39
typedef uint8 COM_DT_FR_RDR_Det_TrustV39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV40
typedef uint8 COM_DT_FR_RDR_Det_TrustV40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV41
typedef uint8 COM_DT_FR_RDR_Det_TrustV41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV42
typedef uint8 COM_DT_FR_RDR_Det_TrustV42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV43
typedef uint8 COM_DT_FR_RDR_Det_TrustV43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV44
typedef uint8 COM_DT_FR_RDR_Det_TrustV44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV45
typedef uint8 COM_DT_FR_RDR_Det_TrustV45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV46
typedef uint8 COM_DT_FR_RDR_Det_TrustV46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV47
typedef uint8 COM_DT_FR_RDR_Det_TrustV47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV48
typedef uint8 COM_DT_FR_RDR_Det_TrustV48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV49
typedef uint8 COM_DT_FR_RDR_Det_TrustV49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV50
typedef uint8 COM_DT_FR_RDR_Det_TrustV50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV51
typedef uint8 COM_DT_FR_RDR_Det_TrustV51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV52
typedef uint8 COM_DT_FR_RDR_Det_TrustV52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV53
typedef uint8 COM_DT_FR_RDR_Det_TrustV53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV54
typedef uint8 COM_DT_FR_RDR_Det_TrustV54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV55
typedef uint8 COM_DT_FR_RDR_Det_TrustV55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV56
typedef uint8 COM_DT_FR_RDR_Det_TrustV56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV57
typedef uint8 COM_DT_FR_RDR_Det_TrustV57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV58
typedef uint8 COM_DT_FR_RDR_Det_TrustV58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV59
typedef uint8 COM_DT_FR_RDR_Det_TrustV59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV60
typedef uint8 COM_DT_FR_RDR_Det_TrustV60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV61
typedef uint8 COM_DT_FR_RDR_Det_TrustV61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV62
typedef uint8 COM_DT_FR_RDR_Det_TrustV62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV63
typedef uint8 COM_DT_FR_RDR_Det_TrustV63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_TrustV64
typedef uint8 COM_DT_FR_RDR_Det_TrustV64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid01
typedef boolean COM_DT_FR_RDR_Det_Valid01;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid02
typedef boolean COM_DT_FR_RDR_Det_Valid02;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid03
typedef boolean COM_DT_FR_RDR_Det_Valid03;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid04
typedef boolean COM_DT_FR_RDR_Det_Valid04;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid05
typedef boolean COM_DT_FR_RDR_Det_Valid05;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid06
typedef boolean COM_DT_FR_RDR_Det_Valid06;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid07
typedef boolean COM_DT_FR_RDR_Det_Valid07;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid08
typedef boolean COM_DT_FR_RDR_Det_Valid08;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid09
typedef boolean COM_DT_FR_RDR_Det_Valid09;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid10
typedef boolean COM_DT_FR_RDR_Det_Valid10;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid11
typedef boolean COM_DT_FR_RDR_Det_Valid11;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid12
typedef boolean COM_DT_FR_RDR_Det_Valid12;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid13
typedef boolean COM_DT_FR_RDR_Det_Valid13;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid14
typedef boolean COM_DT_FR_RDR_Det_Valid14;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid15
typedef boolean COM_DT_FR_RDR_Det_Valid15;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid16
typedef boolean COM_DT_FR_RDR_Det_Valid16;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid17
typedef boolean COM_DT_FR_RDR_Det_Valid17;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid18
typedef boolean COM_DT_FR_RDR_Det_Valid18;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid19
typedef boolean COM_DT_FR_RDR_Det_Valid19;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid20
typedef boolean COM_DT_FR_RDR_Det_Valid20;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid21
typedef boolean COM_DT_FR_RDR_Det_Valid21;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid22
typedef boolean COM_DT_FR_RDR_Det_Valid22;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid23
typedef boolean COM_DT_FR_RDR_Det_Valid23;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid24
typedef boolean COM_DT_FR_RDR_Det_Valid24;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid25
typedef boolean COM_DT_FR_RDR_Det_Valid25;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid26
typedef boolean COM_DT_FR_RDR_Det_Valid26;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid27
typedef boolean COM_DT_FR_RDR_Det_Valid27;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid28
typedef boolean COM_DT_FR_RDR_Det_Valid28;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid29
typedef boolean COM_DT_FR_RDR_Det_Valid29;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid30
typedef boolean COM_DT_FR_RDR_Det_Valid30;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid31
typedef boolean COM_DT_FR_RDR_Det_Valid31;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid32
typedef boolean COM_DT_FR_RDR_Det_Valid32;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid33
typedef boolean COM_DT_FR_RDR_Det_Valid33;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid34
typedef boolean COM_DT_FR_RDR_Det_Valid34;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid35
typedef boolean COM_DT_FR_RDR_Det_Valid35;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid36
typedef boolean COM_DT_FR_RDR_Det_Valid36;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid37
typedef boolean COM_DT_FR_RDR_Det_Valid37;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid38
typedef boolean COM_DT_FR_RDR_Det_Valid38;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid39
typedef boolean COM_DT_FR_RDR_Det_Valid39;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid40
typedef boolean COM_DT_FR_RDR_Det_Valid40;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid41
typedef boolean COM_DT_FR_RDR_Det_Valid41;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid42
typedef boolean COM_DT_FR_RDR_Det_Valid42;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid43
typedef boolean COM_DT_FR_RDR_Det_Valid43;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid44
typedef boolean COM_DT_FR_RDR_Det_Valid44;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid45
typedef boolean COM_DT_FR_RDR_Det_Valid45;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid46
typedef boolean COM_DT_FR_RDR_Det_Valid46;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid47
typedef boolean COM_DT_FR_RDR_Det_Valid47;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid48
typedef boolean COM_DT_FR_RDR_Det_Valid48;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid49
typedef boolean COM_DT_FR_RDR_Det_Valid49;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid50
typedef boolean COM_DT_FR_RDR_Det_Valid50;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid51
typedef boolean COM_DT_FR_RDR_Det_Valid51;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid52
typedef boolean COM_DT_FR_RDR_Det_Valid52;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid53
typedef boolean COM_DT_FR_RDR_Det_Valid53;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid54
typedef boolean COM_DT_FR_RDR_Det_Valid54;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid55
typedef boolean COM_DT_FR_RDR_Det_Valid55;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid56
typedef boolean COM_DT_FR_RDR_Det_Valid56;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid57
typedef boolean COM_DT_FR_RDR_Det_Valid57;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid58
typedef boolean COM_DT_FR_RDR_Det_Valid58;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid59
typedef boolean COM_DT_FR_RDR_Det_Valid59;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid60
typedef boolean COM_DT_FR_RDR_Det_Valid60;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid61
typedef boolean COM_DT_FR_RDR_Det_Valid61;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid62
typedef boolean COM_DT_FR_RDR_Det_Valid62;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid63
typedef boolean COM_DT_FR_RDR_Det_Valid63;

#  define Rte_TypeDef_COM_DT_FR_RDR_Det_Valid64
typedef boolean COM_DT_FR_RDR_Det_Valid64;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge01Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge02Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge03Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge04Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge05Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge06Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge07Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge08Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge09Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge10Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge11Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge12Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge13Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge14Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge15Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge16Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge17Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge18Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge19Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge20Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge21Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge22Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge23Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge24Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge25Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge26Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge27Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge28Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge29Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge30Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge31Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvAge32Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvAge32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt01Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt02Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt03Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt04Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt05Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt06Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt07Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt08Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt09Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt10Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt11Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt12Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt13Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt14Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt15Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_AlvCnt16Val
typedef uint8 COM_DT_FR_RDR_Obj_AlvCnt16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC01Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC02Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC03Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC04Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC05Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC06Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC07Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC08Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC09Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC10Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC11Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC12Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC13Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC14Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC15Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CRC16Val
typedef uint16 COM_DT_FR_RDR_Obj_CRC16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge01Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge02Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge03Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge04Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge05Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge06Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge07Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge08Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge09Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge10Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge11Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge12Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge13Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge14Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge15Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge16Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge17Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge18Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge19Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge20Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge21Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge22Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge23Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge24Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge25Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge26Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge27Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge28Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge29Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge30Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge31Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_CoastAge32Val
typedef uint8 COM_DT_FR_RDR_Obj_CoastAge32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod01Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod02Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod03Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod04Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod05Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod06Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod07Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod08Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod09Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod10Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod11Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod12Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod13Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod14Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod15Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod16Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod17Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod18Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod19Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod20Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod21Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod22Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod23Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod24Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod25Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod26Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod27Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod28Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod29Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod30Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod31Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MedRangeMod32Val
typedef uint8 COM_DT_FR_RDR_Obj_MedRangeMod32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl01Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl01Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl02Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl02Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl03Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl03Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl04Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl04Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl05Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl05Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl06Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl06Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl07Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl07Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl08Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl08Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl09Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl09Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl10Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl10Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl11Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl11Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl12Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl12Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl13Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl13Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl14Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl14Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl15Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl15Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl16Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl16Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl17Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl17Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl18Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl18Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl19Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl19Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl20Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl20Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl21Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl21Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl22Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl22Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl23Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl23Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl24Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl24Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl25Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl25Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl26Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl26Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl27Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl27Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl28Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl28Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl29Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl29Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl30Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl30Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl31Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl31Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_QualLvl32Sta
typedef uint8 COM_DT_FR_RDR_Obj_QualLvl32Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID01Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID02Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID03Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID04Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID05Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID06Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID07Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID08Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID09Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID10Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID11Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID12Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID13Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID14Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID15Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID16Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID17Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID18Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID19Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID20Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID21Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID22Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID23Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID24Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID25Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID26Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID27Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID28Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID29Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID30Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID31Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RefObjID32Val
typedef uint8 COM_DT_FR_RDR_Obj_RefObjID32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX01Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX02Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX03Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX04Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX05Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX06Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX07Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX08Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX09Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX10Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX11Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX12Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX13Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX14Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX15Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX16Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX17Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX18Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX19Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX20Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX21Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX22Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX23Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX24Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX25Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX26Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX27Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX28Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX29Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX30Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX31Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelAccelX32Val
typedef sint16 COM_DT_FR_RDR_Obj_RelAccelX32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX01Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX02Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX03Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX04Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX05Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX06Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX07Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX08Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX09Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX10Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX11Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX12Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX13Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX14Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX15Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX16Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX17Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX18Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX19Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX20Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX21Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX22Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX23Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX24Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX25Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX26Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX27Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX28Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX29Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX30Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX31Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosX32Val
typedef uint16 COM_DT_FR_RDR_Obj_RelPosX32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY01Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY02Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY03Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY04Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY05Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY06Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY07Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY08Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY09Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY10Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY11Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY12Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY13Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY14Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY15Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY16Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY17Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY18Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY19Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY20Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY21Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY22Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY23Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY24Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY25Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY26Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY27Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY28Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY29Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY30Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY31Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelPosY32Val
typedef sint16 COM_DT_FR_RDR_Obj_RelPosY32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX01Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX02Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX03Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX04Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX05Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX06Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX07Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX08Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX09Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX10Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX11Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX12Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX13Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX14Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX15Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX16Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX17Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX18Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX19Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX20Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX21Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX22Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX23Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX24Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX25Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX26Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX27Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX28Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX29Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX30Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX31Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelX32Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelX32Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY01Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY01Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY02Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY02Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY03Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY03Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY04Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY04Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY05Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY05Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY06Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY06Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY07Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY07Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY08Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY08Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY09Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY09Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY10Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY10Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY11Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY11Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY12Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY12Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY13Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY13Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY14Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY14Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY15Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY15Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY16Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY16Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY17Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY17Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY18Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY18Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY19Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY19Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY20Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY20Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY21Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY21Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY22Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY22Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY23Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY23Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY24Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY24Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY25Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY25Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY26Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY26Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY27Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY27Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY28Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY28Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY29Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY29Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY30Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY30Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY31Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY31Val;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_RelVelY32Val
typedef sint16 COM_DT_FR_RDR_Obj_RelVelY32Val;

#  define Rte_TypeDef_COM_DT_HAC_Sta
typedef uint8 COM_DT_HAC_Sta;

#  define Rte_TypeDef_COM_DT_HBA_SysSta
typedef uint8 COM_DT_HBA_SysSta;

#  define Rte_TypeDef_COM_DT_HCU_AcnCompPrmsnPwrVal
typedef uint16 COM_DT_HCU_AcnCompPrmsnPwrVal;

#  define Rte_TypeDef_COM_DT_HCU_AlvCnt3Val
typedef uint8 COM_DT_HCU_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_HCU_AlvCnt5Val
typedef uint8 COM_DT_HCU_AlvCnt5Val;

#  define Rte_TypeDef_COM_DT_HCU_CcCameraSta
typedef uint8 COM_DT_HCU_CcCameraSta;

#  define Rte_TypeDef_COM_DT_HCU_Crc3Val
typedef uint16 COM_DT_HCU_Crc3Val;

#  define Rte_TypeDef_COM_DT_HCU_Crc5Val
typedef uint16 COM_DT_HCU_Crc5Val;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2SunSta
typedef uint8 COM_DT_HCU_DptEnaSet2SunSta;

#  define Rte_TypeDef_COM_DT_HCU_DptHrSet1Val
typedef uint8 COM_DT_HCU_DptHrSet1Val;

#  define Rte_TypeDef_COM_DT_HCU_DptHrSet2Val
typedef uint8 COM_DT_HCU_DptHrSet2Val;

#  define Rte_TypeDef_COM_DT_HCU_DptMinSet1Val
typedef uint8 COM_DT_HCU_DptMinSet1Val;

#  define Rte_TypeDef_COM_DT_HCU_DptMinSet2Val
typedef uint8 COM_DT_HCU_DptMinSet2Val;

#  define Rte_TypeDef_COM_DT_HCU_DrvWhlDmndTqNmVal
typedef sint16 COM_DT_HCU_DrvWhlDmndTqNmVal;

#  define Rte_TypeDef_COM_DT_HCU_DucVal
typedef uint8 COM_DT_HCU_DucVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgEndHrVal
typedef uint8 COM_DT_HCU_EcoChrgEndHrVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgEndHrWeekendVal
typedef uint8 COM_DT_HCU_EcoChrgEndHrWeekendVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgEndMinVal
typedef uint8 COM_DT_HCU_EcoChrgEndMinVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgEndMinWeekendVal
typedef uint8 COM_DT_HCU_EcoChrgEndMinWeekendVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgStrtHrVal
typedef uint8 COM_DT_HCU_EcoChrgStrtHrVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgStrtHrWeekendVal
typedef uint8 COM_DT_HCU_EcoChrgStrtHrWeekendVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgStrtMinVal
typedef uint8 COM_DT_HCU_EcoChrgStrtMinVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoChrgStrtMinWeekendVal
typedef uint8 COM_DT_HCU_EcoChrgStrtMinWeekendVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoLvlVal
typedef uint8 COM_DT_HCU_EcoLvlVal;

#  define Rte_TypeDef_COM_DT_HCU_EcoScoVal
typedef uint8 COM_DT_HCU_EcoScoVal;

#  define Rte_TypeDef_COM_DT_HCU_EstAccelPdlPcVal
typedef uint8 COM_DT_HCU_EstAccelPdlPcVal;

#  define Rte_TypeDef_COM_DT_HCU_FuelEcoVal
typedef uint8 COM_DT_HCU_FuelEcoVal;

#  define Rte_TypeDef_COM_DT_HCU_GearRInhbtSta
typedef uint8 COM_DT_HCU_GearRInhbtSta;

#  define Rte_TypeDef_COM_DT_HCU_LdcCtrlModSta
typedef uint8 COM_DT_HCU_LdcCtrlModSta;

#  define Rte_TypeDef_COM_DT_HCU_PaddleCoastCtrlSta
typedef uint8 COM_DT_HCU_PaddleCoastCtrlSta;

#  define Rte_TypeDef_COM_DT_HCU_PdlStopCtrlSta
typedef uint8 COM_DT_HCU_PdlStopCtrlSta;

#  define Rte_TypeDef_COM_DT_HCU_PdlStopReqTqNmVal
typedef uint16 COM_DT_HCU_PdlStopReqTqNmVal;

#  define Rte_TypeDef_COM_DT_HCU_PhevMod
typedef uint8 COM_DT_HCU_PhevMod;

#  define Rte_TypeDef_COM_DT_HCU_PreFATCOffstTempValHR
typedef uint8 COM_DT_HCU_PreFATCOffstTempValHR;

#  define Rte_TypeDef_COM_DT_HCU_RspaCanFailSta
typedef uint8 COM_DT_HCU_RspaCanFailSta;

#  define Rte_TypeDef_COM_DT_HCU_RspaSta
typedef uint8 COM_DT_HCU_RspaSta;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgEndHrVal
typedef uint8 COM_DT_HCU_SchedChgEndHrVal;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgEndMinVal
typedef uint8 COM_DT_HCU_SchedChgEndMinVal;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgStrtHrVal
typedef uint8 COM_DT_HCU_SchedChgStrtHrVal;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgStrtMinVal
typedef uint8 COM_DT_HCU_SchedChgStrtMinVal;

#  define Rte_TypeDef_COM_DT_HCU_SldDrvAlrtDis
typedef uint8 COM_DT_HCU_SldDrvAlrtDis;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_LvlVal
typedef uint8 COM_DT_HCU_SmartRegen_LvlVal;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_MapCstActSta
typedef uint8 COM_DT_HCU_SmartRegen_MapCstActSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_RdrCstActSta
typedef uint8 COM_DT_HCU_SmartRegen_RdrCstActSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_WarnMsgSta
typedef uint8 COM_DT_HCU_SmartRegen_WarnMsgSta;

#  define Rte_TypeDef_COM_DT_HCU_SmrtEcoLvlDis
typedef uint8 COM_DT_HCU_SmrtEcoLvlDis;

#  define Rte_TypeDef_COM_DT_HCU_SmrtEcoRngDis
typedef uint8 COM_DT_HCU_SmrtEcoRngDis;

#  define Rte_TypeDef_COM_DT_HCU_SpdLimDeviceActSta
typedef uint8 COM_DT_HCU_SpdLimDeviceActSta;

#  define Rte_TypeDef_COM_DT_HCU_SpdLimDeviceVehSpdVal
typedef uint8 COM_DT_HCU_SpdLimDeviceVehSpdVal;

#  define Rte_TypeDef_COM_DT_HCU_SrvLmpTmpryOnSta
typedef uint8 COM_DT_HCU_SrvLmpTmpryOnSta;

#  define Rte_TypeDef_COM_DT_HCU_WhlCrpCrpTqNmVal
typedef sint16 COM_DT_HCU_WhlCrpCrpTqNmVal;

#  define Rte_TypeDef_COM_DT_HDA_InfoPUDis
typedef uint8 COM_DT_HDA_InfoPUDis;

#  define Rte_TypeDef_COM_DT_HDA_InfoPUDis1
typedef uint8 COM_DT_HDA_InfoPUDis1;

#  define Rte_TypeDef_COM_DT_HDA_OptUsmSta
typedef uint8 COM_DT_HDA_OptUsmSta;

#  define Rte_TypeDef_COM_DT_HDA_TDMRMDclReq
typedef uint8 COM_DT_HDA_TDMRMDclReq;

#  define Rte_TypeDef_COM_DT_HDCT_AddtnlTqLssVal
typedef uint8 COM_DT_HDCT_AddtnlTqLssVal;

#  define Rte_TypeDef_COM_DT_HDCT_CLUEngSpd
typedef uint16 COM_DT_HDCT_CLUEngSpd;

#  define Rte_TypeDef_COM_DT_HDCT_CLUTrgtGear
typedef uint8 COM_DT_HDCT_CLUTrgtGear;

#  define Rte_TypeDef_COM_DT_HDCT_CurrGear
typedef uint8 COM_DT_HDCT_CurrGear;

#  define Rte_TypeDef_COM_DT_HDCT_FltSta
typedef uint8 COM_DT_HDCT_FltSta;

#  define Rte_TypeDef_COM_DT_HDCT_GearSelDis
typedef uint8 COM_DT_HDCT_GearSelDis;

#  define Rte_TypeDef_COM_DT_HDCT_KckDnSkpShftCnt
typedef uint8 COM_DT_HDCT_KckDnSkpShftCnt;

#  define Rte_TypeDef_COM_DT_HDCT_OBDSta
typedef uint8 COM_DT_HDCT_OBDSta;

#  define Rte_TypeDef_COM_DT_HDCT_SlipCrnkAllw
typedef uint8 COM_DT_HDCT_SlipCrnkAllw;

#  define Rte_TypeDef_COM_DT_HDCT_TqIncVal
typedef uint16 COM_DT_HDCT_TqIncVal;

#  define Rte_TypeDef_COM_DT_HDCT_TqRdctnVal
typedef uint16 COM_DT_HDCT_TqRdctnVal;

#  define Rte_TypeDef_COM_DT_HDCT_TrgtGear
typedef uint8 COM_DT_HDCT_TrgtGear;

#  define Rte_TypeDef_COM_DT_HDP_ActvSta
typedef uint8 COM_DT_HDP_ActvSta;

#  define Rte_TypeDef_COM_DT_HDP_AutoCallReqSta
typedef uint8 COM_DT_HDP_AutoCallReqSta;

#  define Rte_TypeDef_COM_DT_HDP_CtRoadSrfcDistVal
typedef uint16 COM_DT_HDP_CtRoadSrfcDistVal;

#  define Rte_TypeDef_COM_DT_HDP_DispBarSta
typedef uint8 COM_DT_HDP_DispBarSta;

#  define Rte_TypeDef_COM_DT_HDP_InhbtOffDispSta
typedef uint8 COM_DT_HDP_InhbtOffDispSta;

#  define Rte_TypeDef_COM_DT_HDP_OptInfoSta
typedef uint8 COM_DT_HDP_OptInfoSta;

#  define Rte_TypeDef_COM_DT_HDP_SysSta
typedef uint8 COM_DT_HDP_SysSta;

#  define Rte_TypeDef_COM_DT_HEV_AccelPdlVal
typedef uint16 COM_DT_HEV_AccelPdlVal;

#  define Rte_TypeDef_COM_DT_HEV_DrvTqVal
typedef uint16 COM_DT_HEV_DrvTqVal;

#  define Rte_TypeDef_COM_DT_HEV_EngSpdVal
typedef uint16 COM_DT_HEV_EngSpdVal;

#  define Rte_TypeDef_COM_DT_HEV_EngTqAvail_FS
typedef boolean COM_DT_HEV_EngTqAvail_FS;

#  define Rte_TypeDef_COM_DT_HEV_EngTqVal
typedef uint16 COM_DT_HEV_EngTqVal;

#  define Rte_TypeDef_COM_DT_HEV_EngTq_Bas
typedef uint8 COM_DT_HEV_EngTq_Bas;

#  define Rte_TypeDef_COM_DT_HEV_FrctTqVal
typedef uint16 COM_DT_HEV_FrctTqVal;

#  define Rte_TypeDef_COM_DT_HEV_FuelCnsmptVal
typedef uint16 COM_DT_HEV_FuelCnsmptVal;

#  define Rte_TypeDef_COM_DT_HEV_FuelPmpTrgtPrsrVal
typedef uint8 COM_DT_HEV_FuelPmpTrgtPrsrVal;

#  define Rte_TypeDef_COM_DT_HEV_FuelTnkPrsrErrSta
typedef uint8 COM_DT_HEV_FuelTnkPrsrErrSta;

#  define Rte_TypeDef_COM_DT_HEV_FuelTnkPrsrVal
typedef uint16 COM_DT_HEV_FuelTnkPrsrVal;

#  define Rte_TypeDef_COM_DT_HEV_FueledEngRdy
typedef boolean COM_DT_HEV_FueledEngRdy;

#  define Rte_TypeDef_COM_DT_HEV_IdlTgtEngSpd
typedef uint8 COM_DT_HEV_IdlTgtEngSpd;

#  define Rte_TypeDef_COM_DT_HEV_IdleCtrStat_FS
typedef boolean COM_DT_HEV_IdleCtrStat_FS;

#  define Rte_TypeDef_COM_DT_HEV_IndTqTar
typedef uint8 COM_DT_HEV_IndTqTar;

#  define Rte_TypeDef_COM_DT_HEV_IndTqVal
typedef uint16 COM_DT_HEV_IndTqVal;

#  define Rte_TypeDef_COM_DT_HEV_IntakeAirTempVal
typedef uint8 COM_DT_HEV_IntakeAirTempVal;

#  define Rte_TypeDef_COM_DT_HEV_O2SensHtrAct
typedef boolean COM_DT_HEV_O2SensHtrAct;

#  define Rte_TypeDef_COM_DT_HEV_ObdFrzFrmSta
typedef uint8 COM_DT_HEV_ObdFrzFrmSta;

#  define Rte_TypeDef_COM_DT_HEV_RdyStat_FS_P
typedef boolean COM_DT_HEV_RdyStat_FS_P;

#  define Rte_TypeDef_COM_DT_HEV_ThrPosSta
typedef uint8 COM_DT_HEV_ThrPosSta;

#  define Rte_TypeDef_COM_DT_HEV_TqStndVal
typedef uint8 COM_DT_HEV_TqStndVal;

#  define Rte_TypeDef_COM_DT_HPT_StbltWarn1Sta
typedef uint8 COM_DT_HPT_StbltWarn1Sta;

#  define Rte_TypeDef_COM_DT_HPT_StrWhlWarn1Sta
typedef uint8 COM_DT_HPT_StrWhlWarn1Sta;

#  define Rte_TypeDef_COM_DT_HTCU_AlvCnt4Val
typedef uint8 COM_DT_HTCU_AlvCnt4Val;

#  define Rte_TypeDef_COM_DT_HTCU_AlvCnt5Val
typedef uint8 COM_DT_HTCU_AlvCnt5Val;

#  define Rte_TypeDef_COM_DT_HTCU_Crc4Val
typedef uint16 COM_DT_HTCU_Crc4Val;

#  define Rte_TypeDef_COM_DT_HTCU_Crc5Val
typedef uint16 COM_DT_HTCU_Crc5Val;

#  define Rte_TypeDef_COM_DT_HTCU_CurrGearSta
typedef uint8 COM_DT_HTCU_CurrGearSta;

#  define Rte_TypeDef_COM_DT_HTCU_FltSta
typedef uint8 COM_DT_HTCU_FltSta;

#  define Rte_TypeDef_COM_DT_HTCU_FsAddtnlTqLssPcVal
typedef uint8 COM_DT_HTCU_FsAddtnlTqLssPcVal;

#  define Rte_TypeDef_COM_DT_HTCU_FsEngTqRdctnPcVal
typedef uint8 COM_DT_HTCU_FsEngTqRdctnPcVal;

#  define Rte_TypeDef_COM_DT_HTCU_FsIdleTrgtRpmVal
typedef uint8 COM_DT_HTCU_FsIdleTrgtRpmVal;

#  define Rte_TypeDef_COM_DT_HTCU_GearSlctrDis
typedef uint8 COM_DT_HTCU_GearSlctrDis;

#  define Rte_TypeDef_COM_DT_HTCU_HvOpuSpdCmdRpmVal
typedef uint8 COM_DT_HTCU_HvOpuSpdCmdRpmVal;

#  define Rte_TypeDef_COM_DT_HTCU_LnPrsBarVal
typedef uint8 COM_DT_HTCU_LnPrsBarVal;

#  define Rte_TypeDef_COM_DT_HTCU_SlwTqRdctnPcVal
typedef uint16 COM_DT_HTCU_SlwTqRdctnPcVal;

#  define Rte_TypeDef_COM_DT_HTCU_SlwTqRdctnVal
typedef uint16 COM_DT_HTCU_SlwTqRdctnVal;

#  define Rte_TypeDef_COM_DT_HTCU_TqRdctnPcVal
typedef uint16 COM_DT_HTCU_TqRdctnPcVal;

#  define Rte_TypeDef_COM_DT_HTCU_TrgtGearSta
typedef uint8 COM_DT_HTCU_TrgtGearSta;

#  define Rte_TypeDef_COM_DT_HTCU_TrgtShftClsCCanSta
typedef uint8 COM_DT_HTCU_TrgtShftClsCCanSta;

#  define Rte_TypeDef_COM_DT_HTCU_VehSpdDcmlKphVal
typedef uint8 COM_DT_HTCU_VehSpdDcmlKphVal;

#  define Rte_TypeDef_COM_DT_HTCU_VehSpdKphVal
typedef uint8 COM_DT_HTCU_VehSpdKphVal;

#  define Rte_TypeDef_COM_DT_HU_AMP_EQVariant
typedef uint8 COM_DT_HU_AMP_EQVariant;

#  define Rte_TypeDef_COM_DT_HU_AMP_EQVariant_1
typedef uint8 COM_DT_HU_AMP_EQVariant_1;

#  define Rte_TypeDef_COM_DT_HU_AdasSupport
typedef uint8 COM_DT_HU_AdasSupport;

#  define Rte_TypeDef_COM_DT_HU_AutoBrightState_New
typedef uint16 COM_DT_HU_AutoBrightState_New;

#  define Rte_TypeDef_COM_DT_HU_AutoBrightState_New_1
typedef uint16 COM_DT_HU_AutoBrightState_New_1;

#  define Rte_TypeDef_COM_DT_HU_BVM_Display_Message
typedef uint8 COM_DT_HU_BVM_Display_Message;

#  define Rte_TypeDef_COM_DT_HU_BVM_Display_Message_1
typedef uint8 COM_DT_HU_BVM_Display_Message_1;

#  define Rte_TypeDef_COM_DT_HU_DistributeInfo
typedef uint8 COM_DT_HU_DistributeInfo;

#  define Rte_TypeDef_COM_DT_HU_DistributeInfo_1
typedef uint8 COM_DT_HU_DistributeInfo_1;

#  define Rte_TypeDef_COM_DT_HU_DistributeInfo_2
typedef uint8 COM_DT_HU_DistributeInfo_2;

#  define Rte_TypeDef_COM_DT_HU_LanguageInfo
typedef uint8 COM_DT_HU_LanguageInfo;

#  define Rte_TypeDef_COM_DT_HU_LanguageInfo_1
typedef uint8 COM_DT_HU_LanguageInfo_1;

#  define Rte_TypeDef_COM_DT_HU_NaviCamSettingStatus
typedef uint8 COM_DT_HU_NaviCamSettingStatus;

#  define Rte_TypeDef_COM_DT_HU_NaviCamSettingStatus_1
typedef uint8 COM_DT_HU_NaviCamSettingStatus_1;

#  define Rte_TypeDef_COM_DT_HU_NaviCamSettingStatus_2
typedef uint8 COM_DT_HU_NaviCamSettingStatus_2;

#  define Rte_TypeDef_COM_DT_HU_Navi_RspADASMapMsg
typedef uint16 COM_DT_HU_Navi_RspADASMapMsg;

#  define Rte_TypeDef_COM_DT_HU_Navi_RspADASMapMsg_1
typedef uint16 COM_DT_HU_Navi_RspADASMapMsg_1;

#  define Rte_TypeDef_COM_DT_HU_Navi_RspADASMapMsg_2
typedef uint16 COM_DT_HU_Navi_RspADASMapMsg_2;

#  define Rte_TypeDef_COM_DT_HU_SVM_View_Display
typedef uint8 COM_DT_HU_SVM_View_Display;

#  define Rte_TypeDef_COM_DT_HU_SVM_View_Display_1
typedef uint8 COM_DT_HU_SVM_View_Display_1;

#  define Rte_TypeDef_COM_DT_HU_Scheduled_Setting
typedef uint8 COM_DT_HU_Scheduled_Setting;

#  define Rte_TypeDef_COM_DT_HU_Scheduled_Setting_1
typedef uint8 COM_DT_HU_Scheduled_Setting_1;

#  define Rte_TypeDef_COM_DT_HU_ThemeType
typedef uint8 COM_DT_HU_ThemeType;

#  define Rte_TypeDef_COM_DT_HU_ThemeType_1
typedef uint8 COM_DT_HU_ThemeType_1;

#  define Rte_TypeDef_COM_DT_HU_Type
typedef uint8 COM_DT_HU_Type;

#  define Rte_TypeDef_COM_DT_HU_Type_1
typedef uint8 COM_DT_HU_Type_1;

#  define Rte_TypeDef_COM_DT_HU_Type_2
typedef uint8 COM_DT_HU_Type_2;

#  define Rte_TypeDef_COM_DT_IAU_DISPWrng
typedef uint8 COM_DT_IAU_DISPWrng;

#  define Rte_TypeDef_COM_DT_IAU_DigitalKey2Opt
typedef uint8 COM_DT_IAU_DigitalKey2Opt;

#  define Rte_TypeDef_COM_DT_IAU_DigitalKeyExit
typedef uint8 COM_DT_IAU_DigitalKeyExit;

#  define Rte_TypeDef_COM_DT_IAU_DigitalKeyProcessingSta
typedef uint8 COM_DT_IAU_DigitalKeyProcessingSta;

#  define Rte_TypeDef_COM_DT_IAU_ProfileIDRVal
typedef uint8 COM_DT_IAU_ProfileIDRVal;

#  define Rte_TypeDef_COM_DT_ICC_HDPSpprtSWVer
typedef uint8 COM_DT_ICC_HDPSpprtSWVer;

#  define Rte_TypeDef_COM_DT_ICC_HS_AlvCnt1Val
typedef uint8 COM_DT_ICC_HS_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_ICC_HS_AlvCnt4Val
typedef uint8 COM_DT_ICC_HS_AlvCnt4Val;

#  define Rte_TypeDef_COM_DT_ICC_HS_Crc1Val
typedef uint8 COM_DT_ICC_HS_Crc1Val;

#  define Rte_TypeDef_COM_DT_ICC_HS_Crc4Val
typedef uint8 COM_DT_ICC_HS_Crc4Val;

#  define Rte_TypeDef_COM_DT_ICC_IntvSDLvlStat
typedef uint8 COM_DT_ICC_IntvSDLvlStat;

#  define Rte_TypeDef_COM_DT_ICC_IntvStat
typedef uint8 COM_DT_ICC_IntvStat;

#  define Rte_TypeDef_COM_DT_ICC_MajorSWVer
typedef uint8 COM_DT_ICC_MajorSWVer;

#  define Rte_TypeDef_COM_DT_ICC_MinorSWVer
typedef uint8 COM_DT_ICC_MinorSWVer;

#  define Rte_TypeDef_COM_DT_ICC_WarningSmblDistStat
typedef boolean COM_DT_ICC_WarningSmblDistStat;

#  define Rte_TypeDef_COM_DT_ICC_WarningSmblDrowStat
typedef boolean COM_DT_ICC_WarningSmblDrowStat;

#  define Rte_TypeDef_COM_DT_ICC_WarningSndStat
typedef boolean COM_DT_ICC_WarningSndStat;

#  define Rte_TypeDef_COM_DT_ICSC_AlvCnt2Val
typedef uint8 COM_DT_ICSC_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_ICSC_Crc2Val
typedef uint16 COM_DT_ICSC_Crc2Val;

#  define Rte_TypeDef_COM_DT_ICU_AlvCnt2Val
typedef uint8 COM_DT_ICU_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_ICU_AlvCnt4Val
typedef uint8 COM_DT_ICU_AlvCnt4Val;

#  define Rte_TypeDef_COM_DT_ICU_AlvCnt7Val
typedef uint8 COM_DT_ICU_AlvCnt7Val;

#  define Rte_TypeDef_COM_DT_ICU_Crc2Val
typedef uint8 COM_DT_ICU_Crc2Val;

#  define Rte_TypeDef_COM_DT_ICU_Crc4Val
typedef uint8 COM_DT_ICU_Crc4Val;

#  define Rte_TypeDef_COM_DT_ICU_Crc7Val
typedef uint8 COM_DT_ICU_Crc7Val;

#  define Rte_TypeDef_COM_DT_ID_CIPV
typedef uint8 COM_DT_ID_CIPV;

#  define Rte_TypeDef_COM_DT_IEB_ActvSta
typedef uint8 COM_DT_IEB_ActvSta;

#  define Rte_TypeDef_COM_DT_IEB_AlvCnt1Val
typedef uint8 COM_DT_IEB_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_IEB_BrkActvSta
typedef uint8 COM_DT_IEB_BrkActvSta;

#  define Rte_TypeDef_COM_DT_IEB_Crc1Val
typedef uint16 COM_DT_IEB_Crc1Val;

#  define Rte_TypeDef_COM_DT_IEB_DrvWhlSlipFlg_Frnt
typedef boolean COM_DT_IEB_DrvWhlSlipFlg_Frnt;

#  define Rte_TypeDef_COM_DT_IEB_EstBrkSacFrcNmVal
typedef uint16 COM_DT_IEB_EstBrkSacFrcNmVal;

#  define Rte_TypeDef_COM_DT_IEB_EstDpthPcVal
typedef uint8 COM_DT_IEB_EstDpthPcVal;

#  define Rte_TypeDef_COM_DT_IEB_EstTtlBrkFrcNmVal
typedef uint16 COM_DT_IEB_EstTtlBrkFrcNmVal;

#  define Rte_TypeDef_COM_DT_IEB_RegenTqLimitNmVal_Frnt
typedef uint16 COM_DT_IEB_RegenTqLimitNmVal_Frnt;

#  define Rte_TypeDef_COM_DT_IEB_RegenTqLimitNmVal_Rear
typedef uint16 COM_DT_IEB_RegenTqLimitNmVal_Rear;

#  define Rte_TypeDef_COM_DT_IEB_SrvLmpDis
typedef uint8 COM_DT_IEB_SrvLmpDis;

#  define Rte_TypeDef_COM_DT_IEB_Sta
typedef uint8 COM_DT_IEB_Sta;

#  define Rte_TypeDef_COM_DT_IEB_StrkDpthPcVal
typedef uint8 COM_DT_IEB_StrkDpthPcVal;

#  define Rte_TypeDef_COM_DT_IEB_StrkDpthmmVal
typedef sint16 COM_DT_IEB_StrkDpthmmVal;

#  define Rte_TypeDef_COM_DT_IEB_TCS_Req
typedef uint8 COM_DT_IEB_TCS_Req;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl10Val
typedef uint16 COM_DT_IFSref_VehLtAngl10Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl10Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl10Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl1Val
typedef uint16 COM_DT_IFSref_VehLtAngl1Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl1Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl1Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl2Val
typedef uint16 COM_DT_IFSref_VehLtAngl2Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl2Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl2Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl3Val
typedef uint16 COM_DT_IFSref_VehLtAngl3Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl3Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl3Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl4Val
typedef uint16 COM_DT_IFSref_VehLtAngl4Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl4Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl4Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl5Val
typedef uint16 COM_DT_IFSref_VehLtAngl5Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl5Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl5Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl6Val
typedef uint16 COM_DT_IFSref_VehLtAngl6Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl6Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl6Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl7Val
typedef uint16 COM_DT_IFSref_VehLtAngl7Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl7Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl7Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl8Val
typedef uint16 COM_DT_IFSref_VehLtAngl8Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl8Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl8Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl9Val
typedef uint16 COM_DT_IFSref_VehLtAngl9Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehLtAngl9Val_1
typedef uint16 COM_DT_IFSref_VehLtAngl9Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehNumVal
typedef uint8 COM_DT_IFSref_VehNumVal;

#  define Rte_TypeDef_COM_DT_IFSref_VehNumVal_1
typedef uint8 COM_DT_IFSref_VehNumVal_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl10Val
typedef uint16 COM_DT_IFSref_VehRtAngl10Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl10Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl10Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl1Val
typedef uint16 COM_DT_IFSref_VehRtAngl1Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl1Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl1Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl2Val
typedef uint16 COM_DT_IFSref_VehRtAngl2Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl2Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl2Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl3Val
typedef uint16 COM_DT_IFSref_VehRtAngl3Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl3Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl3Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl4Val
typedef uint16 COM_DT_IFSref_VehRtAngl4Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl4Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl4Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl5Val
typedef uint16 COM_DT_IFSref_VehRtAngl5Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl5Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl5Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl6Val
typedef uint16 COM_DT_IFSref_VehRtAngl6Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl6Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl6Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl7Val
typedef uint16 COM_DT_IFSref_VehRtAngl7Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl7Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl7Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl8Val
typedef uint16 COM_DT_IFSref_VehRtAngl8Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl8Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl8Val_1;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl9Val
typedef uint16 COM_DT_IFSref_VehRtAngl9Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehRtAngl9Val_1
typedef uint16 COM_DT_IFSref_VehRtAngl9Val_1;

#  define Rte_TypeDef_COM_DT_IMT_CltchPdlPos
typedef uint8 COM_DT_IMT_CltchPdlPos;

#  define Rte_TypeDef_COM_DT_IMT_EOLstate
typedef boolean COM_DT_IMT_EOLstate;

#  define Rte_TypeDef_COM_DT_IMU_AcuRstSta
typedef uint8 COM_DT_IMU_AcuRstSta;

#  define Rte_TypeDef_COM_DT_IMU_AlvCnt1Val
typedef uint8 COM_DT_IMU_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_IMU_Crc1Val
typedef uint16 COM_DT_IMU_Crc1Val;

#  define Rte_TypeDef_COM_DT_IMU_LatAccelSigSta
typedef uint8 COM_DT_IMU_LatAccelSigSta;

#  define Rte_TypeDef_COM_DT_IMU_LatAccelVal
typedef uint16 COM_DT_IMU_LatAccelVal;

#  define Rte_TypeDef_COM_DT_IMU_LongAccelSigSta
typedef uint8 COM_DT_IMU_LongAccelSigSta;

#  define Rte_TypeDef_COM_DT_IMU_LongAccelVal
typedef uint16 COM_DT_IMU_LongAccelVal;

#  define Rte_TypeDef_COM_DT_IMU_McuVoltSta
typedef uint8 COM_DT_IMU_McuVoltSta;

#  define Rte_TypeDef_COM_DT_IMU_RollRtVal
typedef uint16 COM_DT_IMU_RollRtVal;

#  define Rte_TypeDef_COM_DT_IMU_RollSigSta
typedef uint8 COM_DT_IMU_RollSigSta;

#  define Rte_TypeDef_COM_DT_IMU_SnsrTempVal
typedef uint8 COM_DT_IMU_SnsrTempVal;

#  define Rte_TypeDef_COM_DT_IMU_SnsrTyp
typedef uint8 COM_DT_IMU_SnsrTyp;

#  define Rte_TypeDef_COM_DT_IMU_VerAccelSigSta
typedef uint8 COM_DT_IMU_VerAccelSigSta;

#  define Rte_TypeDef_COM_DT_IMU_VerAccelVal
typedef uint16 COM_DT_IMU_VerAccelVal;

#  define Rte_TypeDef_COM_DT_IMU_YawRtVal
typedef uint16 COM_DT_IMU_YawRtVal;

#  define Rte_TypeDef_COM_DT_IMU_YawSigSta
typedef uint8 COM_DT_IMU_YawSigSta;

#  define Rte_TypeDef_COM_DT_ISLA_AddtnlSign
typedef uint8 COM_DT_ISLA_AddtnlSign;

#  define Rte_TypeDef_COM_DT_ISLA_AutoNModReq
typedef uint8 COM_DT_ISLA_AutoNModReq;

#  define Rte_TypeDef_COM_DT_ISLA_AutoNModSta
typedef uint8 COM_DT_ISLA_AutoNModSta;

#  define Rte_TypeDef_COM_DT_ISLA_Cntry
typedef uint8 COM_DT_ISLA_Cntry;

#  define Rte_TypeDef_COM_DT_ISLA_CondInfoDisp
typedef uint8 COM_DT_ISLA_CondInfoDisp;

#  define Rte_TypeDef_COM_DT_ISLA_EUCntry1USMSta
typedef uint8 COM_DT_ISLA_EUCntry1USMSta;

#  define Rte_TypeDef_COM_DT_ISLA_EUCntry2USMSta
typedef uint8 COM_DT_ISLA_EUCntry2USMSta;

#  define Rte_TypeDef_COM_DT_ISLA_EUCntryVerTyp
typedef uint8 COM_DT_ISLA_EUCntryVerTyp;

#  define Rte_TypeDef_COM_DT_ISLA_IcyWrn
typedef uint8 COM_DT_ISLA_IcyWrn;

#  define Rte_TypeDef_COM_DT_ISLA_NACntry1USMSta
typedef uint8 COM_DT_ISLA_NACntry1USMSta;

#  define Rte_TypeDef_COM_DT_ISLA_NACntry2USMSta
typedef uint8 COM_DT_ISLA_NACntry2USMSta;

#  define Rte_TypeDef_COM_DT_ISLA_NACntryVerTyp
typedef uint8 COM_DT_ISLA_NACntryVerTyp;

#  define Rte_TypeDef_COM_DT_ISLA_OptUsmSta
typedef uint8 COM_DT_ISLA_OptUsmSta;

#  define Rte_TypeDef_COM_DT_ISLA_Popup
typedef uint8 COM_DT_ISLA_Popup;

#  define Rte_TypeDef_COM_DT_ISLA_SchoolZone
typedef uint8 COM_DT_ISLA_SchoolZone;

#  define Rte_TypeDef_COM_DT_ISLA_SndReqSta
typedef uint8 COM_DT_ISLA_SndReqSta;

#  define Rte_TypeDef_COM_DT_ISLA_SpdChgReq
typedef uint8 COM_DT_ISLA_SpdChgReq;

#  define Rte_TypeDef_COM_DT_ISLA_SpdWrn
typedef uint8 COM_DT_ISLA_SpdWrn;

#  define Rte_TypeDef_COM_DT_ISLA_SpdwOffst
typedef uint8 COM_DT_ISLA_SpdwOffst;

#  define Rte_TypeDef_COM_DT_ISLA_SwIgnoreReq
typedef uint8 COM_DT_ISLA_SwIgnoreReq;

#  define Rte_TypeDef_COM_DT_ISLA_SymFlashMod
typedef uint8 COM_DT_ISLA_SymFlashMod;

#  define Rte_TypeDef_COM_DT_ISLA_TSRSpdLimVal
typedef uint8 COM_DT_ISLA_TSRSpdLimVal;

#  define Rte_TypeDef_COM_DT_ISLW_NoPassingInfoDis
typedef uint8 COM_DT_ISLW_NoPassingInfoDis;

#  define Rte_TypeDef_COM_DT_ISLW_SpdCluDisSubCond1
typedef uint8 COM_DT_ISLW_SpdCluDisSubCond1;

#  define Rte_TypeDef_COM_DT_ISLW_SpdCluDisSubCond2
typedef uint8 COM_DT_ISLW_SpdCluDisSubCond2;

#  define Rte_TypeDef_COM_DT_ISLW_SpdCluMainDis
typedef uint8 COM_DT_ISLW_SpdCluMainDis;

#  define Rte_TypeDef_COM_DT_ISLW_SpdCluSubMainDis
typedef uint8 COM_DT_ISLW_SpdCluSubMainDis;

#  define Rte_TypeDef_COM_DT_ISLW_SpdNaviDisSubCond1
typedef uint8 COM_DT_ISLW_SpdNaviDisSubCond1;

#  define Rte_TypeDef_COM_DT_ISLW_SpdNaviDisSubCond2
typedef uint8 COM_DT_ISLW_SpdNaviDisSubCond2;

#  define Rte_TypeDef_COM_DT_ISLW_SpdNaviMainDis
typedef uint8 COM_DT_ISLW_SpdNaviMainDis;

#  define Rte_TypeDef_COM_DT_ISLW_SpdNaviSubMainDis
typedef uint8 COM_DT_ISLW_SpdNaviSubMainDis;

#  define Rte_TypeDef_COM_DT_ISLW_SubCondinfoSta1
typedef uint8 COM_DT_ISLW_SubCondinfoSta1;

#  define Rte_TypeDef_COM_DT_ISLW_SubCondinfoSta2
typedef uint8 COM_DT_ISLW_SubCondinfoSta2;

#  define Rte_TypeDef_COM_DT_InAirTempVal
typedef uint8 COM_DT_InAirTempVal;

#  define Rte_TypeDef_COM_DT_InAirTempVal_1
typedef uint8 COM_DT_InAirTempVal_1;

#  define Rte_TypeDef_COM_DT_Info_LftLnCrvtrDrvtvVal
typedef uint16 COM_DT_Info_LftLnCrvtrDrvtvVal;

#  define Rte_TypeDef_COM_DT_Info_LftLnCvtrVal
typedef uint16 COM_DT_Info_LftLnCvtrVal;

#  define Rte_TypeDef_COM_DT_Info_LftLnHdingAnglVal
typedef uint16 COM_DT_Info_LftLnHdingAnglVal;

#  define Rte_TypeDef_COM_DT_Info_LftLnPosVal
typedef uint16 COM_DT_Info_LftLnPosVal;

#  define Rte_TypeDef_COM_DT_Info_LftLnQualSta
typedef uint8 COM_DT_Info_LftLnQualSta;

#  define Rte_TypeDef_COM_DT_Info_LtLnCrvtrDrvtvVal
typedef sint16 COM_DT_Info_LtLnCrvtrDrvtvVal;

#  define Rte_TypeDef_COM_DT_Info_LtLnCvtrVal
typedef sint16 COM_DT_Info_LtLnCvtrVal;

#  define Rte_TypeDef_COM_DT_Info_LtLnHdingAnglVal
typedef sint16 COM_DT_Info_LtLnHdingAnglVal;

#  define Rte_TypeDef_COM_DT_Info_LtLnPosVal
typedef sint16 COM_DT_Info_LtLnPosVal;

#  define Rte_TypeDef_COM_DT_Info_LtLnQualSta
typedef uint8 COM_DT_Info_LtLnQualSta;

#  define Rte_TypeDef_COM_DT_Info_OD_PedDstVal
typedef uint8 COM_DT_Info_OD_PedDstVal;

#  define Rte_TypeDef_COM_DT_Info_RtLnCrvtrDrvtvVal
typedef sint16 COM_DT_Info_RtLnCrvtrDrvtvVal;

#  define Rte_TypeDef_COM_DT_Info_RtLnCvtrVal
typedef uint16 COM_DT_Info_RtLnCvtrVal;

#  define Rte_TypeDef_COM_DT_Info_RtLnHdingAnglVal
typedef uint16 COM_DT_Info_RtLnHdingAnglVal;

#  define Rte_TypeDef_COM_DT_Info_RtLnPosVal
typedef uint16 COM_DT_Info_RtLnPosVal;

#  define Rte_TypeDef_COM_DT_Info_RtLnQualSta
typedef uint8 COM_DT_Info_RtLnQualSta;

#  define Rte_TypeDef_COM_DT_LDM_Sta
typedef uint8 COM_DT_LDM_Sta;

#  define Rte_TypeDef_COM_DT_LHCU_EngCltchTrnsfrTqPcVal_Copy_1
typedef sint16 COM_DT_LHCU_EngCltchTrnsfrTqPcVal_Copy_1;

#  define Rte_TypeDef_COM_DT_LKA_HndsoffSnd
typedef uint8 COM_DT_LKA_HndsoffSnd;

#  define Rte_TypeDef_COM_DT_LKA_LHLnWrnSta
typedef uint8 COM_DT_LKA_LHLnWrnSta;

#  define Rte_TypeDef_COM_DT_LKA_OptUsmSta
typedef uint8 COM_DT_LKA_OptUsmSta;

#  define Rte_TypeDef_COM_DT_LKA_RHLnWrnSta
typedef uint8 COM_DT_LKA_RHLnWrnSta;

#  define Rte_TypeDef_COM_DT_LKA_RcgSta
typedef uint8 COM_DT_LKA_RcgSta;

#  define Rte_TypeDef_COM_DT_LKA_StrSnd
typedef uint8 COM_DT_LKA_StrSnd;

#  define Rte_TypeDef_COM_DT_LKA_SysWrn
typedef uint8 COM_DT_LKA_SysWrn;

#  define Rte_TypeDef_COM_DT_Lamp_BLEWelcomeSig
typedef boolean COM_DT_Lamp_BLEWelcomeSig;

#  define Rte_TypeDef_COM_DT_Lamp_HbaCtrlModTyp
typedef uint8 COM_DT_Lamp_HbaCtrlModTyp;

#  define Rte_TypeDef_COM_DT_Lamp_IFSCtrlModTyp
typedef uint8 COM_DT_Lamp_IFSCtrlModTyp;

#  define Rte_TypeDef_COM_DT_Lamp_LedHdLmpSta
typedef uint8 COM_DT_Lamp_LedHdLmpSta;

#  define Rte_TypeDef_COM_DT_Longitudinal_Distance
typedef uint16 COM_DT_Longitudinal_Distance;

#  define Rte_TypeDef_COM_DT_MCB_CtlSta
typedef boolean COM_DT_MCB_CtlSta;

#  define Rte_TypeDef_COM_DT_MCB_DefSta
typedef boolean COM_DT_MCB_DefSta;

#  define Rte_TypeDef_COM_DT_MCB_ReqBrkAck
typedef uint8 COM_DT_MCB_ReqBrkAck;

#  define Rte_TypeDef_COM_DT_MDPS_ADASAciActvSta
typedef uint8 COM_DT_MDPS_ADASAciActvSta;

#  define Rte_TypeDef_COM_DT_MDPS_ADASAciActvSta_Lv2
typedef uint8 COM_DT_MDPS_ADASAciActvSta_Lv2;

#  define Rte_TypeDef_COM_DT_MDPS_ADAS_AciFltSig_Lv2
typedef uint8 COM_DT_MDPS_ADAS_AciFltSig_Lv2;

#  define Rte_TypeDef_COM_DT_MDPS_AlvCnt1Val
typedef uint8 COM_DT_MDPS_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_MDPS_Crc1Val
typedef uint16 COM_DT_MDPS_Crc1Val;

#  define Rte_TypeDef_COM_DT_MDPS_EstStrAnglVal
typedef sint16 COM_DT_MDPS_EstStrAnglVal;

#  define Rte_TypeDef_COM_DT_MDPS_HDPSpprtSWVer
typedef uint8 COM_DT_MDPS_HDPSpprtSWVer;

#  define Rte_TypeDef_COM_DT_MDPS_LkaPlgInSta
typedef uint8 COM_DT_MDPS_LkaPlgInSta;

#  define Rte_TypeDef_COM_DT_MDPS_OutTqVal
typedef uint16 COM_DT_MDPS_OutTqVal;

#  define Rte_TypeDef_COM_DT_MDPS_PaModeSta
typedef uint8 COM_DT_MDPS_PaModeSta;

#  define Rte_TypeDef_COM_DT_MDPS_PaPlugInSta
typedef uint8 COM_DT_MDPS_PaPlugInSta;

#  define Rte_TypeDef_COM_DT_MDPS_PaStrAnglVal
typedef sint16 COM_DT_MDPS_PaStrAnglVal;

#  define Rte_TypeDef_COM_DT_MDPS_StrTqSnsrVal
typedef uint16 COM_DT_MDPS_StrTqSnsrVal;

#  define Rte_TypeDef_COM_DT_MDPS_VsmPlgInSta
typedef uint8 COM_DT_MDPS_VsmPlgInSta;

#  define Rte_TypeDef_COM_DT_MDPS_WrngLmpSta
typedef uint8 COM_DT_MDPS_WrngLmpSta;

#  define Rte_TypeDef_COM_DT_META_V2_3_CountryCode
typedef uint16 COM_DT_META_V2_3_CountryCode;

#  define Rte_TypeDef_COM_DT_META_V2_3_CountryCode_1
typedef uint16 COM_DT_META_V2_3_CountryCode_1;

#  define Rte_TypeDef_COM_DT_META_V2_3_CyclicCounter
typedef uint8 COM_DT_META_V2_3_CyclicCounter;

#  define Rte_TypeDef_COM_DT_META_V2_3_CyclicCounter_1
typedef uint8 COM_DT_META_V2_3_CyclicCounter_1;

#  define Rte_TypeDef_COM_DT_META_V2_3_MajorProtocolVersion
typedef uint8 COM_DT_META_V2_3_MajorProtocolVersion;

#  define Rte_TypeDef_COM_DT_META_V2_3_MajorProtocolVersion_1
typedef uint8 COM_DT_META_V2_3_MajorProtocolVersion_1;

#  define Rte_TypeDef_COM_DT_META_V2_3_MinorProtocolVersion
typedef uint8 COM_DT_META_V2_3_MinorProtocolVersion;

#  define Rte_TypeDef_COM_DT_META_V2_3_MinorProtocolVersion_1
typedef uint8 COM_DT_META_V2_3_MinorProtocolVersion_1;

#  define Rte_TypeDef_COM_DT_META_V2_3_RegionCode
typedef uint16 COM_DT_META_V2_3_RegionCode;

#  define Rte_TypeDef_COM_DT_META_V2_3_RegionCode_1
typedef uint16 COM_DT_META_V2_3_RegionCode_1;

#  define Rte_TypeDef_COM_DT_MFSW_AlvCnt1Val
typedef uint8 COM_DT_MFSW_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_MFSW_Crc1Val
typedef uint8 COM_DT_MFSW_Crc1Val;

#  define Rte_TypeDef_COM_DT_MSR_TqFlag
typedef boolean COM_DT_MSR_TqFlag;

#  define Rte_TypeDef_COM_DT_MSR_TqIntrvntnVal
typedef uint8 COM_DT_MSR_TqIntrvntnVal;

#  define Rte_TypeDef_COM_DT_MV_CtRoadSrfcDstVal
typedef uint16 COM_DT_MV_CtRoadSrfcDstVal;

#  define Rte_TypeDef_COM_DT_MV_CtRoadSrfcSta
typedef uint8 COM_DT_MV_CtRoadSrfcSta;

#  define Rte_TypeDef_COM_DT_MV_DrvLnCtLnSta
typedef uint8 COM_DT_MV_DrvLnCtLnSta;

#  define Rte_TypeDef_COM_DT_MV_DrvLnRdsVal
typedef uint8 COM_DT_MV_DrvLnRdsVal;

#  define Rte_TypeDef_COM_DT_MV_FrLtObjLatPosVal
typedef uint8 COM_DT_MV_FrLtObjLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrLtObjLongPosVal
typedef uint16 COM_DT_MV_FrLtObjLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrLtObjMvngDirSta
typedef uint8 COM_DT_MV_FrLtObjMvngDirSta;

#  define Rte_TypeDef_COM_DT_MV_FrLtObjSta
typedef uint8 COM_DT_MV_FrLtObjSta;

#  define Rte_TypeDef_COM_DT_MV_FrLtRdrWaveSta
typedef uint8 COM_DT_MV_FrLtRdrWaveSta;

#  define Rte_TypeDef_COM_DT_MV_FrObjLatPosVal
typedef sint8 COM_DT_MV_FrObjLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrObjLongPosVal
typedef uint16 COM_DT_MV_FrObjLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrObjSta
typedef uint8 COM_DT_MV_FrObjSta;

#  define Rte_TypeDef_COM_DT_MV_FrObstLatPosVal
typedef sint8 COM_DT_MV_FrObstLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrObstLongPosVal
typedef uint16 COM_DT_MV_FrObstLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrObstSta
typedef uint8 COM_DT_MV_FrObstSta;

#  define Rte_TypeDef_COM_DT_MV_FrRdrWaveSta
typedef uint8 COM_DT_MV_FrRdrWaveSta;

#  define Rte_TypeDef_COM_DT_MV_FrRtObjLatPosVal
typedef uint8 COM_DT_MV_FrRtObjLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrRtObjLongPosVal
typedef uint16 COM_DT_MV_FrRtObjLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_FrRtObjMvngDirSta
typedef uint8 COM_DT_MV_FrRtObjMvngDirSta;

#  define Rte_TypeDef_COM_DT_MV_FrRtObjSta
typedef uint8 COM_DT_MV_FrRtObjSta;

#  define Rte_TypeDef_COM_DT_MV_FrRtRdrWaveSta
typedef uint8 COM_DT_MV_FrRtRdrWaveSta;

#  define Rte_TypeDef_COM_DT_MV_HostVeh1Sta
typedef uint8 COM_DT_MV_HostVeh1Sta;

#  define Rte_TypeDef_COM_DT_MV_LtLCDirSta
typedef uint8 COM_DT_MV_LtLCDirSta;

#  define Rte_TypeDef_COM_DT_MV_LtLnOffstVal
typedef uint8 COM_DT_MV_LtLnOffstVal;

#  define Rte_TypeDef_COM_DT_MV_LtLnSta
typedef uint8 COM_DT_MV_LtLnSta;

#  define Rte_TypeDef_COM_DT_MV_LtObjLatPosVal
typedef uint8 COM_DT_MV_LtObjLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_LtObjLongPosVal
typedef uint8 COM_DT_MV_LtObjLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_LtObjSta
typedef uint8 COM_DT_MV_LtObjSta;

#  define Rte_TypeDef_COM_DT_MV_LtRoadSrfcSta
typedef uint8 COM_DT_MV_LtRoadSrfcSta;

#  define Rte_TypeDef_COM_DT_MV_RrLtRdrWave1Sta
typedef uint8 COM_DT_MV_RrLtRdrWave1Sta;

#  define Rte_TypeDef_COM_DT_MV_RrRtRdrWave1Sta
typedef uint8 COM_DT_MV_RrRtRdrWave1Sta;

#  define Rte_TypeDef_COM_DT_MV_RtLCDirSta
typedef uint8 COM_DT_MV_RtLCDirSta;

#  define Rte_TypeDef_COM_DT_MV_RtLnOffstVal
typedef uint8 COM_DT_MV_RtLnOffstVal;

#  define Rte_TypeDef_COM_DT_MV_RtLnSta
typedef uint8 COM_DT_MV_RtLnSta;

#  define Rte_TypeDef_COM_DT_MV_RtObjLatPosVal
typedef uint8 COM_DT_MV_RtObjLatPosVal;

#  define Rte_TypeDef_COM_DT_MV_RtObjLongPosVal
typedef uint8 COM_DT_MV_RtObjLongPosVal;

#  define Rte_TypeDef_COM_DT_MV_RtObjSta
typedef uint8 COM_DT_MV_RtObjSta;

#  define Rte_TypeDef_COM_DT_MV_RtRoadSrfcSta
typedef uint8 COM_DT_MV_RtRoadSrfcSta;

#  define Rte_TypeDef_COM_DT_MV_VehDstSta
typedef uint8 COM_DT_MV_VehDstSta;

#  define Rte_TypeDef_COM_DT_MV_VehDstVal
typedef uint16 COM_DT_MV_VehDstVal;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_CountryCode
typedef uint16 COM_DT_Navi_ISLW_CountryCode;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_CountryCode_1
typedef uint16 COM_DT_Navi_ISLW_CountryCode_1;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_CountryCode_2
typedef uint16 COM_DT_Navi_ISLW_CountryCode_2;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_MapSource
typedef uint8 COM_DT_Navi_ISLW_MapSource;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_MapSource_1
typedef uint8 COM_DT_Navi_ISLW_MapSource_1;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_MapSource_2
typedef uint8 COM_DT_Navi_ISLW_MapSource_2;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_SpdLimit
typedef uint8 COM_DT_Navi_ISLW_SpdLimit;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_SpdLimit_1
typedef uint8 COM_DT_Navi_ISLW_SpdLimit_1;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_SpdLimit_2
typedef uint8 COM_DT_Navi_ISLW_SpdLimit_2;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_TimeSpd
typedef uint8 COM_DT_Navi_ISLW_TimeSpd;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_TimeSpd_1
typedef uint8 COM_DT_Navi_ISLW_TimeSpd_1;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_TimeSpd_2
typedef uint8 COM_DT_Navi_ISLW_TimeSpd_2;

#  define Rte_TypeDef_COM_DT_OBD_DnmntrCalcVal
typedef uint16 COM_DT_OBD_DnmntrCalcVal;

#  define Rte_TypeDef_COM_DT_OBD_DnmntrCalcVal_1
typedef uint16 COM_DT_OBD_DnmntrCalcVal_1;

#  define Rte_TypeDef_COM_DT_OBD_IgnCycCntVal
typedef uint16 COM_DT_OBD_IgnCycCntVal;

#  define Rte_TypeDef_COM_DT_OBD_IgnCycCntVal_1
typedef uint16 COM_DT_OBD_IgnCycCntVal_1;

#  define Rte_TypeDef_COM_DT_OBD_MilConfgVal
typedef uint8 COM_DT_OBD_MilConfgVal;

#  define Rte_TypeDef_COM_DT_OBD_RbmInhbtSta
typedef uint8 COM_DT_OBD_RbmInhbtSta;

#  define Rte_TypeDef_COM_DT_OBD_RbmInhbtSta_1
typedef uint8 COM_DT_OBD_RbmInhbtSta_1;

#  define Rte_TypeDef_COM_DT_OBD_RbmSta
typedef uint8 COM_DT_OBD_RbmSta;

#  define Rte_TypeDef_COM_DT_OBD_RbmSta_1
typedef uint8 COM_DT_OBD_RbmSta_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrAltitude1m
typedef uint8 COM_DT_POS_V2_3_CurrAltitude1m;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrAltitude1m_1
typedef uint8 COM_DT_POS_V2_3_CurrAltitude1m_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrDirectionLanes
typedef uint8 COM_DT_POS_V2_3_CurrDirectionLanes;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrDirectionLanes_1
typedef uint8 COM_DT_POS_V2_3_CurrDirectionLanes_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrFormOfWay
typedef uint8 COM_DT_POS_V2_3_CurrFormOfWay;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrFormOfWay_1
typedef uint8 COM_DT_POS_V2_3_CurrFormOfWay_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CyclicCounter
typedef uint8 COM_DT_POS_V2_3_CyclicCounter;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CyclicCounter_1
typedef uint8 COM_DT_POS_V2_3_CyclicCounter_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_Offset
typedef uint16 COM_DT_POS_V2_3_Offset;

#  define Rte_TypeDef_COM_DT_POS_V2_3_Offset_1
typedef uint16 COM_DT_POS_V2_3_Offset_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_PathIndex
typedef uint8 COM_DT_POS_V2_3_PathIndex;

#  define Rte_TypeDef_COM_DT_POS_V2_3_PathIndex_1
typedef uint8 COM_DT_POS_V2_3_PathIndex_1;

#  define Rte_TypeDef_COM_DT_POS_V2_3_RangeAvgSpeed
typedef uint16 COM_DT_POS_V2_3_RangeAvgSpeed;

#  define Rte_TypeDef_COM_DT_POS_V2_3_RangeAvgSpeed_1
typedef uint16 COM_DT_POS_V2_3_RangeAvgSpeed_1;

#  define Rte_TypeDef_COM_DT_POS_V2_CyclicCounter
typedef uint8 COM_DT_POS_V2_CyclicCounter;

#  define Rte_TypeDef_COM_DT_POS_V2_Offset
typedef uint16 COM_DT_POS_V2_Offset;

#  define Rte_TypeDef_COM_DT_POS_V2_RangeAvgSpeed
typedef uint16 COM_DT_POS_V2_RangeAvgSpeed;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_CyclicCounter
typedef uint8 COM_DT_PROLONG_V2_3_CyclicCounter;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_CyclicCounter_1
typedef uint8 COM_DT_PROLONG_V2_3_CyclicCounter_1;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_Offset
typedef uint16 COM_DT_PROLONG_V2_3_Offset;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_Offset_1
typedef uint16 COM_DT_PROLONG_V2_3_Offset_1;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_PathIndex
typedef uint8 COM_DT_PROLONG_V2_3_PathIndex;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_PathIndex_1
typedef uint8 COM_DT_PROLONG_V2_3_PathIndex_1;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_ProfileType
typedef uint8 COM_DT_PROLONG_V2_3_ProfileType;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_ProfileType_1
typedef uint8 COM_DT_PROLONG_V2_3_ProfileType_1;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_Value
typedef uint32 COM_DT_PROLONG_V2_3_Value;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_Value_1
typedef uint32 COM_DT_PROLONG_V2_3_Value_1;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_CyclicCounter
typedef uint8 COM_DT_PROLONG_V2_CyclicCounter;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_Offset
typedef uint16 COM_DT_PROLONG_V2_Offset;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_ProfileType
typedef uint8 COM_DT_PROLONG_V2_ProfileType;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_Update
typedef boolean COM_DT_PROLONG_V2_Update;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_Value
typedef uint32 COM_DT_PROLONG_V2_Value;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Accuracy
typedef uint8 COM_DT_PROSHORT_V2_3_Accuracy;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Accuracy_1
typedef uint8 COM_DT_PROSHORT_V2_3_Accuracy_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_CyclicCounter
typedef uint8 COM_DT_PROSHORT_V2_3_CyclicCounter;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_CyclicCounter_1
typedef uint8 COM_DT_PROSHORT_V2_3_CyclicCounter_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Distance
typedef uint16 COM_DT_PROSHORT_V2_3_Distance;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Distance_1
typedef uint16 COM_DT_PROSHORT_V2_3_Distance_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Offset
typedef uint16 COM_DT_PROSHORT_V2_3_Offset;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Offset_1
typedef uint16 COM_DT_PROSHORT_V2_3_Offset_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_PathIndex
typedef uint8 COM_DT_PROSHORT_V2_3_PathIndex;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_PathIndex_1
typedef uint8 COM_DT_PROSHORT_V2_3_PathIndex_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_ProfileType
typedef uint8 COM_DT_PROSHORT_V2_3_ProfileType;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_ProfileType_1
typedef uint8 COM_DT_PROSHORT_V2_3_ProfileType_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Value0
typedef uint16 COM_DT_PROSHORT_V2_3_Value0;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Value0_1
typedef uint16 COM_DT_PROSHORT_V2_3_Value0_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Value1
typedef uint16 COM_DT_PROSHORT_V2_3_Value1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_3_Value1_1
typedef uint16 COM_DT_PROSHORT_V2_3_Value1_1;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_CyclicCounter
typedef uint8 COM_DT_PROSHORT_V2_CyclicCounter;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_Distance
typedef uint16 COM_DT_PROSHORT_V2_Distance;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_Offset
typedef uint16 COM_DT_PROSHORT_V2_Offset;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_ProfileType
typedef uint8 COM_DT_PROSHORT_V2_ProfileType;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_Value0
typedef uint16 COM_DT_PROSHORT_V2_Value0;

#  define Rte_TypeDef_COM_DT_PROSHORT_V2_Value1
typedef uint16 COM_DT_PROSHORT_V2_Value1;

#  define Rte_TypeDef_COM_DT_PU_F_Group1_ADASWarn1_1Sta
typedef uint8 COM_DT_PU_F_Group1_ADASWarn1_1Sta;

#  define Rte_TypeDef_COM_DT_PU_F_Group1_ADASWarn1_2Sta
typedef uint8 COM_DT_PU_F_Group1_ADASWarn1_2Sta;

#  define Rte_TypeDef_COM_DT_PU_F_Group4_ADASWarn1_1Sta
typedef uint8 COM_DT_PU_F_Group4_ADASWarn1_1Sta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_DAW_FlrSta
typedef uint8 COM_DT_PU_F_Group7_DAW_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_DrvrAsstFlr1Sta
typedef uint8 COM_DT_PU_F_Group7_DrvrAsstFlr1Sta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_FwdSdSftyFlrSta
typedef uint8 COM_DT_PU_F_Group7_FwdSdSftyFlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_FwdSftyFlrSta
typedef uint8 COM_DT_PU_F_Group7_FwdSftyFlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_HBA_FlrSta
typedef uint8 COM_DT_PU_F_Group7_HBA_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_HDA_FlrSta
typedef uint8 COM_DT_PU_F_Group7_HDA_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_HDP_FlrSta
typedef uint8 COM_DT_PU_F_Group7_HDP_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_ISLA_FlrSta
typedef uint8 COM_DT_PU_F_Group7_ISLA_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_LCA_FlrSta
typedef uint8 COM_DT_PU_F_Group7_LCA_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_LFA_FlrSta
typedef uint8 COM_DT_PU_F_Group7_LFA_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_LnSftyFlrSta
typedef uint8 COM_DT_PU_F_Group7_LnSftyFlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_MRM_FlrSta
typedef uint8 COM_DT_PU_F_Group7_MRM_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_F_Group7_SCC_FlrSta
typedef uint8 COM_DT_PU_F_Group7_SCC_FlrSta;

#  define Rte_TypeDef_COM_DT_PU_M_Group2_ADASWarn1_1Sta
typedef uint8 COM_DT_PU_M_Group2_ADASWarn1_1Sta;

#  define Rte_TypeDef_COM_DT_PU_M_Group2_ADASWarn1_2Sta
typedef uint8 COM_DT_PU_M_Group2_ADASWarn1_2Sta;

#  define Rte_TypeDef_COM_DT_RD_DTC_AlvCntVal
typedef uint8 COM_DT_RD_DTC_AlvCntVal;

#  define Rte_TypeDef_COM_DT_RSC_TqFlag_Frnt
typedef boolean COM_DT_RSC_TqFlag_Frnt;

#  define Rte_TypeDef_COM_DT_RSC_TqFlag_Rear
typedef boolean COM_DT_RSC_TqFlag_Rear;

#  define Rte_TypeDef_COM_DT_RSC_TqIntrvntnVal_Frnt
typedef uint8 COM_DT_RSC_TqIntrvntnVal_Frnt;

#  define Rte_TypeDef_COM_DT_RSC_TqIntrvntnVal_Rear
typedef uint8 COM_DT_RSC_TqIntrvntnVal_Rear;

#  define Rte_TypeDef_COM_DT_RSPA_Actv
typedef uint8 COM_DT_RSPA_Actv;

#  define Rte_TypeDef_COM_DT_RSPA_AvnDis
typedef uint8 COM_DT_RSPA_AvnDis;

#  define Rte_TypeDef_COM_DT_RSPA_AvnHmiDis
typedef uint8 COM_DT_RSPA_AvnHmiDis;

#  define Rte_TypeDef_COM_DT_RSPA_AvnModDis
typedef uint8 COM_DT_RSPA_AvnModDis;

#  define Rte_TypeDef_COM_DT_RSPA_AvnSubViewDis
typedef uint8 COM_DT_RSPA_AvnSubViewDis;

#  define Rte_TypeDef_COM_DT_RSPA_DCTTrgtTqVal
typedef sint16 COM_DT_RSPA_DCTTrgtTqVal;

#  define Rte_TypeDef_COM_DT_RSPA_EvasiveStrBtnDis
typedef uint8 COM_DT_RSPA_EvasiveStrBtnDis;

#  define Rte_TypeDef_COM_DT_RSPA_ExtLampReq
typedef uint8 COM_DT_RSPA_ExtLampReq;

#  define Rte_TypeDef_COM_DT_RSPA_IndBlnkReq
typedef uint8 COM_DT_RSPA_IndBlnkReq;

#  define Rte_TypeDef_COM_DT_RSPA_RmtPrlExitDis
typedef uint8 COM_DT_RSPA_RmtPrlExitDis;

#  define Rte_TypeDef_COM_DT_RSPA_SelFuncInfo
typedef uint8 COM_DT_RSPA_SelFuncInfo;

#  define Rte_TypeDef_COM_DT_RSPA_SysOff
typedef boolean COM_DT_RSPA_SysOff;

#  define Rte_TypeDef_COM_DT_RSPA_TrgtTqVal
typedef sint16 COM_DT_RSPA_TrgtTqVal;

#  define Rte_TypeDef_COM_DT_RSPA_TrgtVehSpdVal
typedef uint16 COM_DT_RSPA_TrgtVehSpdVal;

#  define Rte_TypeDef_COM_DT_RSPA_Var
typedef uint8 COM_DT_RSPA_Var;

#  define Rte_TypeDef_COM_DT_RadarCANCommError
typedef uint8 COM_DT_RadarCANCommError;

#  define Rte_TypeDef_COM_DT_RadarErrorCode_No1
typedef uint16 COM_DT_RadarErrorCode_No1;

#  define Rte_TypeDef_COM_DT_RadarErrorCode_No2
typedef uint16 COM_DT_RadarErrorCode_No2;

#  define Rte_TypeDef_COM_DT_RadarHwError
typedef uint8 COM_DT_RadarHwError;

#  define Rte_TypeDef_COM_DT_RadarHwTempCondition_High
typedef uint8 COM_DT_RadarHwTempCondition_High;

#  define Rte_TypeDef_COM_DT_RadarHwTempCondition_Low
typedef uint8 COM_DT_RadarHwTempCondition_Low;

#  define Rte_TypeDef_COM_DT_Relative_Velocity
typedef uint16 COM_DT_Relative_Velocity;

#  define Rte_TypeDef_COM_DT_SAS_AlvCnt1Val
typedef uint8 COM_DT_SAS_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_SAS_AnglVal
typedef sint16 COM_DT_SAS_AnglVal;

#  define Rte_TypeDef_COM_DT_SAS_Crc1Val
typedef uint16 COM_DT_SAS_Crc1Val;

#  define Rte_TypeDef_COM_DT_SAS_IntSta
typedef uint8 COM_DT_SAS_IntSta;

#  define Rte_TypeDef_COM_DT_SAS_SpdVal
typedef uint8 COM_DT_SAS_SpdVal;

#  define Rte_TypeDef_COM_DT_SCC_AccelLimBandLwrVal
typedef uint8 COM_DT_SCC_AccelLimBandLwrVal;

#  define Rte_TypeDef_COM_DT_SCC_AccelLimBandUppVal
typedef uint8 COM_DT_SCC_AccelLimBandUppVal;

#  define Rte_TypeDef_COM_DT_SCC_AccelReqRawVal
typedef uint16 COM_DT_SCC_AccelReqRawVal;

#  define Rte_TypeDef_COM_DT_SCC_AccelReqVal
typedef uint16 COM_DT_SCC_AccelReqVal;

#  define Rte_TypeDef_COM_DT_SCC_Char2Sta
typedef uint8 COM_DT_SCC_Char2Sta;

#  define Rte_TypeDef_COM_DT_SCC_DrvAlrtDis
typedef uint8 COM_DT_SCC_DrvAlrtDis;

#  define Rte_TypeDef_COM_DT_SCC_EnblReq
typedef uint8 COM_DT_SCC_EnblReq;

#  define Rte_TypeDef_COM_DT_SCC_EngStateReq
typedef uint8 COM_DT_SCC_EngStateReq;

#  define Rte_TypeDef_COM_DT_SCC_HeadwayDstSetVal
typedef uint8 COM_DT_SCC_HeadwayDstSetVal;

#  define Rte_TypeDef_COM_DT_SCC_InfoDis
typedef uint8 COM_DT_SCC_InfoDis;

#  define Rte_TypeDef_COM_DT_SCC_JrkLwrLimVal
typedef uint8 COM_DT_SCC_JrkLwrLimVal;

#  define Rte_TypeDef_COM_DT_SCC_JrkUppLimVal
typedef uint8 COM_DT_SCC_JrkUppLimVal;

#  define Rte_TypeDef_COM_DT_SCC_NSCCInfoPUDis
typedef uint8 COM_DT_SCC_NSCCInfoPUDis;

#  define Rte_TypeDef_COM_DT_SCC_ObjDstLvlVal
typedef uint8 COM_DT_SCC_ObjDstLvlVal;

#  define Rte_TypeDef_COM_DT_SCC_ObjDstVal
typedef uint16 COM_DT_SCC_ObjDstVal;

#  define Rte_TypeDef_COM_DT_SCC_ObjLatPosVal
typedef uint16 COM_DT_SCC_ObjLatPosVal;

#  define Rte_TypeDef_COM_DT_SCC_ObjRelSpdVal
typedef uint16 COM_DT_SCC_ObjRelSpdVal;

#  define Rte_TypeDef_COM_DT_SCC_ObjSta
typedef uint8 COM_DT_SCC_ObjSta;

#  define Rte_TypeDef_COM_DT_SCC_OpSta
typedef uint8 COM_DT_SCC_OpSta;

#  define Rte_TypeDef_COM_DT_SCC_SnstvtyModRetVal
typedef uint8 COM_DT_SCC_SnstvtyModRetVal;

#  define Rte_TypeDef_COM_DT_SCC_StrtLimFuncSta
typedef uint8 COM_DT_SCC_StrtLimFuncSta;

#  define Rte_TypeDef_COM_DT_SCC_StrtLimFuncSta_1
typedef uint8 COM_DT_SCC_StrtLimFuncSta_1;

#  define Rte_TypeDef_COM_DT_SCC_TqIntrvntnVal
typedef uint8 COM_DT_SCC_TqIntrvntnVal;

#  define Rte_TypeDef_COM_DT_SCC_TrgtDstVal
typedef uint16 COM_DT_SCC_TrgtDstVal;

#  define Rte_TypeDef_COM_DT_SCR_IndcmtExitStaDis
typedef uint8 COM_DT_SCR_IndcmtExitStaDis;

#  define Rte_TypeDef_COM_DT_SCR_IndcmtExitStaDis_1
typedef uint8 COM_DT_SCR_IndcmtExitStaDis_1;

#  define Rte_TypeDef_COM_DT_SCR_LvlWrngMsgDis
typedef uint8 COM_DT_SCR_LvlWrngMsgDis;

#  define Rte_TypeDef_COM_DT_SCR_LvlWrngMsgDis_1
typedef uint8 COM_DT_SCR_LvlWrngMsgDis_1;

#  define Rte_TypeDef_COM_DT_SCR_RmnDstDis
typedef uint16 COM_DT_SCR_RmnDstDis;

#  define Rte_TypeDef_COM_DT_SCR_RmnDstDis_1
typedef uint16 COM_DT_SCR_RmnDstDis_1;

#  define Rte_TypeDef_COM_DT_SCR_RmnRstrtDis
typedef uint8 COM_DT_SCR_RmnRstrtDis;

#  define Rte_TypeDef_COM_DT_SCR_RmnRstrtDis_1
typedef uint8 COM_DT_SCR_RmnRstrtDis_1;

#  define Rte_TypeDef_COM_DT_SCR_SysErrMsgDis
typedef uint8 COM_DT_SCR_SysErrMsgDis;

#  define Rte_TypeDef_COM_DT_SCR_SysErrMsgDis_1
typedef uint8 COM_DT_SCR_SysErrMsgDis_1;

#  define Rte_TypeDef_COM_DT_SCR_UreaLvlSta
typedef uint8 COM_DT_SCR_UreaLvlSta;

#  define Rte_TypeDef_COM_DT_SCR_UreaLvlSta_1
typedef uint8 COM_DT_SCR_UreaLvlSta_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_CyclicCounter
typedef uint8 COM_DT_SEG_V2_3_CyclicCounter;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_CyclicCounter_1
typedef uint8 COM_DT_SEG_V2_3_CyclicCounter_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_DirectionLanes
typedef uint8 COM_DT_SEG_V2_3_DirectionLanes;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_DirectionLanes_1
typedef uint8 COM_DT_SEG_V2_3_DirectionLanes_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_FormOfWay
typedef uint8 COM_DT_SEG_V2_3_FormOfWay;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_FormOfWay_1
typedef uint8 COM_DT_SEG_V2_3_FormOfWay_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_Offset
typedef uint16 COM_DT_SEG_V2_3_Offset;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_Offset_1
typedef uint16 COM_DT_SEG_V2_3_Offset_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_PathIndex
typedef uint8 COM_DT_SEG_V2_3_PathIndex;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_PathIndex_1
typedef uint8 COM_DT_SEG_V2_3_PathIndex_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_SpeedLimitUnder5
typedef uint8 COM_DT_SEG_V2_3_SpeedLimitUnder5;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_SpeedLimitUnder5_1
typedef uint8 COM_DT_SEG_V2_3_SpeedLimitUnder5_1;

#  define Rte_TypeDef_COM_DT_SEG_V2_CyclicCounter
typedef uint8 COM_DT_SEG_V2_CyclicCounter;

#  define Rte_TypeDef_COM_DT_SEG_V2_DirectionLanes
typedef uint8 COM_DT_SEG_V2_DirectionLanes;

#  define Rte_TypeDef_COM_DT_SEG_V2_FormOfWay
typedef uint8 COM_DT_SEG_V2_FormOfWay;

#  define Rte_TypeDef_COM_DT_SEG_V2_Offset
typedef uint16 COM_DT_SEG_V2_Offset;

#  define Rte_TypeDef_COM_DT_SEG_V2_Retransmission
typedef boolean COM_DT_SEG_V2_Retransmission;

#  define Rte_TypeDef_COM_DT_SEG_V2_SpeedLimitUnder5
typedef uint8 COM_DT_SEG_V2_SpeedLimitUnder5;

#  define Rte_TypeDef_COM_DT_SHIFT_IND_LED
typedef uint8 COM_DT_SHIFT_IND_LED;

#  define Rte_TypeDef_COM_DT_SMK_AlvCnt2Val
typedef uint8 COM_DT_SMK_AlvCnt2Val;

#  define Rte_TypeDef_COM_DT_SMK_Crc2Val
typedef uint8 COM_DT_SMK_Crc2Val;

#  define Rte_TypeDef_COM_DT_SMK_TrmnlCtrlSta
typedef uint8 COM_DT_SMK_TrmnlCtrlSta;

#  define Rte_TypeDef_COM_DT_SMV_DrvAsstHUDSymbSta
typedef uint8 COM_DT_SMV_DrvAsstHUDSymbSta;

#  define Rte_TypeDef_COM_DT_SMV_FrObjSta
typedef uint8 COM_DT_SMV_FrObjSta;

#  define Rte_TypeDef_COM_DT_SMV_HDA_SymbSta
typedef uint8 COM_DT_SMV_HDA_SymbSta;

#  define Rte_TypeDef_COM_DT_SMV_HostVehSta
typedef uint8 COM_DT_SMV_HostVehSta;

#  define Rte_TypeDef_COM_DT_SMV_ISLA_SetSpdSymbSta
typedef uint8 COM_DT_SMV_ISLA_SetSpdSymbSta;

#  define Rte_TypeDef_COM_DT_SMV_LCA_LtSymbSta
typedef uint8 COM_DT_SMV_LCA_LtSymbSta;

#  define Rte_TypeDef_COM_DT_SMV_LCA_RtSymbSta
typedef uint8 COM_DT_SMV_LCA_RtSymbSta;

#  define Rte_TypeDef_COM_DT_SMV_LFA_SymbSta
typedef uint8 COM_DT_SMV_LFA_SymbSta;

#  define Rte_TypeDef_COM_DT_SMV_NSCC_SymbSta
typedef uint8 COM_DT_SMV_NSCC_SymbSta;

#  define Rte_TypeDef_COM_DT_SMV_SetSpdSta
typedef uint8 COM_DT_SMV_SetSpdSta;

#  define Rte_TypeDef_COM_DT_SMV_SetSpdVal
typedef uint8 COM_DT_SMV_SetSpdVal;

#  define Rte_TypeDef_COM_DT_SMV_VehDstLvlSta
typedef uint8 COM_DT_SMV_VehDstLvlSta;

#  define Rte_TypeDef_COM_DT_SMV_VehDstLvlVal
typedef uint8 COM_DT_SMV_VehDstLvlVal;

#  define Rte_TypeDef_COM_DT_SND_ADASWarn1_1Sta
typedef uint8 COM_DT_SND_ADASWarn1_1Sta;

#  define Rte_TypeDef_COM_DT_SND_ADASWarn1_2Sta
typedef uint8 COM_DT_SND_ADASWarn1_2Sta;

#  define Rte_TypeDef_COM_DT_SND_ADASWarn1_3Sta
typedef uint8 COM_DT_SND_ADASWarn1_3Sta;

#  define Rte_TypeDef_COM_DT_SND_ADASWarn1_4Sta
typedef uint8 COM_DT_SND_ADASWarn1_4Sta;

#  define Rte_TypeDef_COM_DT_SND_ADASWarn1_5Sta
typedef uint8 COM_DT_SND_ADASWarn1_5Sta;

#  define Rte_TypeDef_COM_DT_SSC_CLUEngSpd
typedef uint16 COM_DT_SSC_CLUEngSpd;

#  define Rte_TypeDef_COM_DT_SSC_CLUEngSpdFlag
typedef uint8 COM_DT_SSC_CLUEngSpdFlag;

#  define Rte_TypeDef_COM_DT_SWRC_AlvCnt3Val
typedef uint8 COM_DT_SWRC_AlvCnt3Val;

#  define Rte_TypeDef_COM_DT_SWRC_Crc3Val
typedef uint8 COM_DT_SWRC_Crc3Val;

#  define Rte_TypeDef_COM_DT_SWRC_CrsSwSta
typedef uint8 COM_DT_SWRC_CrsSwSta;

#  define Rte_TypeDef_COM_DT_SWRC_HDPSpprtSWVer
typedef uint8 COM_DT_SWRC_HDPSpprtSWVer;

#  define Rte_TypeDef_COM_DT_SystemOutOfCalibration_DRV
typedef uint8 COM_DT_SystemOutOfCalibration_DRV;

#  define Rte_TypeDef_COM_DT_SystemOutOfCalibration_EOL
typedef uint8 COM_DT_SystemOutOfCalibration_EOL;

#  define Rte_TypeDef_COM_DT_TCH_EngTrgtGearSta
typedef uint8 COM_DT_TCH_EngTrgtGearSta;

#  define Rte_TypeDef_COM_DT_TCS_LmpSta
typedef uint8 COM_DT_TCS_LmpSta;

#  define Rte_TypeDef_COM_DT_TCS_ManufacturerVal
typedef uint8 COM_DT_TCS_ManufacturerVal;

#  define Rte_TypeDef_COM_DT_TCS_MtrTrgtRpm_Flag_Frnt
typedef boolean COM_DT_TCS_MtrTrgtRpm_Flag_Frnt;

#  define Rte_TypeDef_COM_DT_TCS_MtrTrgtRpm_Flag_Rear
typedef boolean COM_DT_TCS_MtrTrgtRpm_Flag_Rear;

#  define Rte_TypeDef_COM_DT_TCS_MtrTrgtRpm_Frnt
typedef uint16 COM_DT_TCS_MtrTrgtRpm_Frnt;

#  define Rte_TypeDef_COM_DT_TCS_MtrTrgtRpm_Rear
typedef uint16 COM_DT_TCS_MtrTrgtRpm_Rear;

#  define Rte_TypeDef_COM_DT_TCS_OffLmpSta
typedef uint8 COM_DT_TCS_OffLmpSta;

#  define Rte_TypeDef_COM_DT_TCS_Req
typedef uint8 COM_DT_TCS_Req;

#  define Rte_TypeDef_COM_DT_TCS_SlwTqFlag
typedef boolean COM_DT_TCS_SlwTqFlag;

#  define Rte_TypeDef_COM_DT_TCS_SlwTqIntrvntnVal
typedef uint8 COM_DT_TCS_SlwTqIntrvntnVal;

#  define Rte_TypeDef_COM_DT_TCS_Sta
typedef uint8 COM_DT_TCS_Sta;

#  define Rte_TypeDef_COM_DT_TCS_TqFlag
typedef boolean COM_DT_TCS_TqFlag;

#  define Rte_TypeDef_COM_DT_TCS_TqFlag_Frnt
typedef boolean COM_DT_TCS_TqFlag_Frnt;

#  define Rte_TypeDef_COM_DT_TCS_TqFlag_Rear
typedef boolean COM_DT_TCS_TqFlag_Rear;

#  define Rte_TypeDef_COM_DT_TCS_TqIntrvntnVal
typedef uint8 COM_DT_TCS_TqIntrvntnVal;

#  define Rte_TypeDef_COM_DT_TCS_TqIntrvntnVal_Frnt
typedef uint8 COM_DT_TCS_TqIntrvntnVal_Frnt;

#  define Rte_TypeDef_COM_DT_TCS_TqIntrvntnVal_Rear
typedef uint8 COM_DT_TCS_TqIntrvntnVal_Rear;

#  define Rte_TypeDef_COM_DT_TCU_AlvCnt1Val
typedef uint8 COM_DT_TCU_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_TCU_CluTrgtGearSta
typedef uint8 COM_DT_TCU_CluTrgtGearSta;

#  define Rte_TypeDef_COM_DT_TCU_Crc1Val
typedef uint16 COM_DT_TCU_Crc1Val;

#  define Rte_TypeDef_COM_DT_TCU_CurrGearSta
typedef uint8 COM_DT_TCU_CurrGearSta;

#  define Rte_TypeDef_COM_DT_TCU_DcmlVehSpdKphVal
typedef uint8 COM_DT_TCU_DcmlVehSpdKphVal;

#  define Rte_TypeDef_COM_DT_TCU_EPBReq
typedef boolean COM_DT_TCU_EPBReq;

#  define Rte_TypeDef_COM_DT_TCU_EngRpmDis
typedef uint16 COM_DT_TCU_EngRpmDis;

#  define Rte_TypeDef_COM_DT_TCU_EngRpmDisSta
typedef uint8 COM_DT_TCU_EngRpmDisSta;

#  define Rte_TypeDef_COM_DT_TCU_EngSpdIncReq
typedef uint8 COM_DT_TCU_EngSpdIncReq;

#  define Rte_TypeDef_COM_DT_TCU_FrtStcShftSta
typedef uint8 COM_DT_TCU_FrtStcShftSta;

#  define Rte_TypeDef_COM_DT_TCU_FuelCutInhbtReq
typedef uint8 COM_DT_TCU_FuelCutInhbtReq;

#  define Rte_TypeDef_COM_DT_TCU_GearSlctDis
typedef uint8 COM_DT_TCU_GearSlctDis;

#  define Rte_TypeDef_COM_DT_TCU_LupTrgtEngSpdVal
typedef uint8 COM_DT_TCU_LupTrgtEngSpdVal;

#  define Rte_TypeDef_COM_DT_TCU_ObdSta
typedef uint8 COM_DT_TCU_ObdSta;

#  define Rte_TypeDef_COM_DT_TCU_SlpVal
typedef uint8 COM_DT_TCU_SlpVal;

#  define Rte_TypeDef_COM_DT_TCU_SprkRtrdReq
typedef uint8 COM_DT_TCU_SprkRtrdReq;

#  define Rte_TypeDef_COM_DT_TCU_TqGrdntLimVal
typedef uint8 COM_DT_TCU_TqGrdntLimVal;

#  define Rte_TypeDef_COM_DT_TCU_TrgtGearSta
typedef uint8 COM_DT_TCU_TrgtGearSta;

#  define Rte_TypeDef_COM_DT_TCU_VgisInhbtReq
typedef uint8 COM_DT_TCU_VgisInhbtReq;

#  define Rte_TypeDef_COM_DT_TT_DAW_SymbSta
typedef uint8 COM_DT_TT_DAW_SymbSta;

#  define Rte_TypeDef_COM_DT_TT_EmergStrSymbSta
typedef uint8 COM_DT_TT_EmergStrSymbSta;

#  define Rte_TypeDef_COM_DT_TT_FwdSftySymbSta
typedef uint8 COM_DT_TT_FwdSftySymbSta;

#  define Rte_TypeDef_COM_DT_TT_HBA_SymbSta
typedef uint8 COM_DT_TT_HBA_SymbSta;

#  define Rte_TypeDef_COM_DT_TT_ISLA_AddtnlTrffcSgnSta
typedef uint8 COM_DT_TT_ISLA_AddtnlTrffcSgnSta;

#  define Rte_TypeDef_COM_DT_TT_ISLA_SpdLimTrffcSgnSta
typedef uint8 COM_DT_TT_ISLA_SpdLimTrffcSgnSta;

#  define Rte_TypeDef_COM_DT_TT_ISLA_SpdLimTrffcSgnVal
typedef uint8 COM_DT_TT_ISLA_SpdLimTrffcSgnVal;

#  define Rte_TypeDef_COM_DT_TT_ISLA_SuppTrffcSgnSta
typedef uint8 COM_DT_TT_ISLA_SuppTrffcSgnSta;

#  define Rte_TypeDef_COM_DT_TT_ISLA_TrffcSgnCntryInfoSta
typedef uint8 COM_DT_TT_ISLA_TrffcSgnCntryInfoSta;

#  define Rte_TypeDef_COM_DT_TT_LnSftySymbSta
typedef uint8 COM_DT_TT_LnSftySymbSta;

#  define Rte_TypeDef_COM_DT_TgtEngRPM
typedef uint16 COM_DT_TgtEngRPM;

#  define Rte_TypeDef_COM_DT_USM_AdasBCASetReq
typedef uint8 COM_DT_USM_AdasBCASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasBVMSetReq
typedef uint8 COM_DT_USM_AdasBVMSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasDAWModSetReq
typedef uint8 COM_DT_USM_AdasDAWModSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasFCASetReq
typedef uint8 COM_DT_USM_AdasFCASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasHptWrngSetReq
typedef uint8 COM_DT_USM_AdasHptWrngSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLAEUCntry1SetReq
typedef uint8 COM_DT_USM_AdasISLAEUCntry1SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLANACntry1SetReq
typedef uint8 COM_DT_USM_AdasISLANACntry1SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLASetReq
typedef uint8 COM_DT_USM_AdasISLASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasLkaModSetReq
typedef uint8 COM_DT_USM_AdasLkaModSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasPCA_RrStaSetReq
typedef uint8 COM_DT_USM_AdasPCA_RrStaSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasRCCANSetReq
typedef uint8 COM_DT_USM_AdasRCCANSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCDrvModSetReq
typedef uint8 COM_DT_USM_AdasSCCDrvModSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCMLChar1SetReq
typedef uint8 COM_DT_USM_AdasSCCMLChar1SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCMLChar2SetReq
typedef uint8 COM_DT_USM_AdasSCCMLChar2SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCMLChar3SetReq
typedef uint8 COM_DT_USM_AdasSCCMLChar3SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasWarnTimeSetReq
typedef uint8 COM_DT_USM_AdasWarnTimeSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasWrngTimingSetReq
typedef uint8 COM_DT_USM_AdasWrngTimingSetReq;

#  define Rte_TypeDef_COM_DT_USM_AutoDrLkSetReq2
typedef uint8 COM_DT_USM_AutoDrLkSetReq2;

#  define Rte_TypeDef_COM_DT_USM_Clu3dDepthSta
typedef uint8 COM_DT_USM_Clu3dDepthSta;

#  define Rte_TypeDef_COM_DT_USM_CluAdasVolSta
typedef uint8 COM_DT_USM_CluAdasVolSta;

#  define Rte_TypeDef_COM_DT_USM_CluFuelEconomySta
typedef uint8 COM_DT_USM_CluFuelEconomySta;

#  define Rte_TypeDef_COM_DT_USM_IllAlwaysOnwithPSTNSta
typedef uint8 COM_DT_USM_IllAlwaysOnwithPSTNSta;

#  define Rte_TypeDef_COM_DT_VAR_Opt1Sta
typedef uint32 COM_DT_VAR_Opt1Sta;

#  define Rte_TypeDef_COM_DT_VN
typedef uint16 COM_DT_VN;

#  define Rte_TypeDef_COM_DT_VN_1
typedef uint16 COM_DT_VN_1;

#  define Rte_TypeDef_COM_DT_WHL_AlvCnt1Val
typedef uint8 COM_DT_WHL_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_WHL_Crc1Val
typedef uint16 COM_DT_WHL_Crc1Val;

#  define Rte_TypeDef_COM_DT_WHL_DirFLVal
typedef uint8 COM_DT_WHL_DirFLVal;

#  define Rte_TypeDef_COM_DT_WHL_DirFRVal
typedef uint8 COM_DT_WHL_DirFRVal;

#  define Rte_TypeDef_COM_DT_WHL_DirRLVal
typedef uint8 COM_DT_WHL_DirRLVal;

#  define Rte_TypeDef_COM_DT_WHL_DirRRVal
typedef uint8 COM_DT_WHL_DirRRVal;

#  define Rte_TypeDef_COM_DT_WHL_PlsFLVal
typedef uint8 COM_DT_WHL_PlsFLVal;

#  define Rte_TypeDef_COM_DT_WHL_PlsFRVal
typedef uint8 COM_DT_WHL_PlsFRVal;

#  define Rte_TypeDef_COM_DT_WHL_PlsRLVal
typedef uint8 COM_DT_WHL_PlsRLVal;

#  define Rte_TypeDef_COM_DT_WHL_PlsRRVal
typedef uint8 COM_DT_WHL_PlsRRVal;

#  define Rte_TypeDef_COM_DT_WHL_SpdCalParmtr
typedef uint16 COM_DT_WHL_SpdCalParmtr;

#  define Rte_TypeDef_COM_DT_WHL_SpdFLVal
typedef uint16 COM_DT_WHL_SpdFLVal;

#  define Rte_TypeDef_COM_DT_WHL_SpdFRVal
typedef uint16 COM_DT_WHL_SpdFRVal;

#  define Rte_TypeDef_COM_DT_WHL_SpdRLVal
typedef uint16 COM_DT_WHL_SpdRLVal;

#  define Rte_TypeDef_COM_DT_WHL_SpdRRVal
typedef uint16 COM_DT_WHL_SpdRRVal;

#  define Rte_TypeDef_COM_DT_Wiper_RainSnsrPartNum
typedef uint8 COM_DT_Wiper_RainSnsrPartNum;

#  define Rte_TypeDef_COM_DT_YRS_AlvCnt1Val
typedef uint8 COM_DT_YRS_AlvCnt1Val;

#  define Rte_TypeDef_COM_DT_YRS_Crc1Val
typedef uint16 COM_DT_YRS_Crc1Val;

#  define Rte_TypeDef_COM_DT_YRS_LatAccelSigSta
typedef uint8 COM_DT_YRS_LatAccelSigSta;

#  define Rte_TypeDef_COM_DT_YRS_LatAccelVal
typedef uint16 COM_DT_YRS_LatAccelVal;

#  define Rte_TypeDef_COM_DT_YRS_LongAccelSigSta
typedef uint8 COM_DT_YRS_LongAccelSigSta;

#  define Rte_TypeDef_COM_DT_YRS_LongAccelVal
typedef uint16 COM_DT_YRS_LongAccelVal;

#  define Rte_TypeDef_COM_DT_YRS_YawRtVal
typedef uint16 COM_DT_YRS_YawRtVal;

#  define Rte_TypeDef_COM_DT_YRS_YawSigSta
typedef uint8 COM_DT_YRS_YawSigSta;

#  define Rte_TypeDef_COM_DT_p_ABS_DiagSta
typedef uint8 COM_DT_p_ABS_DiagSta;

#  define Rte_TypeDef_COM_DT_p_CLU_OutTempCSta
typedef uint8 COM_DT_p_CLU_OutTempCSta;

#  define Rte_TypeDef_COM_DT_p_CLU_OutTempCSta_1
typedef uint8 COM_DT_p_CLU_OutTempCSta_1;

#  define Rte_TypeDef_COM_DT_p_HCU_HevRdySta
typedef uint8 COM_DT_p_HCU_HevRdySta;

#  define Rte_TypeDef_COM_DT_p_SAS_AnglVal
typedef sint16 COM_DT_p_SAS_AnglVal;

#  define Rte_TypeDef_COM_DT_p_SAS_AnglVal_1
typedef sint16 COM_DT_p_SAS_AnglVal_1;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdFLVal
typedef uint16 COM_DT_p_WHL_SpdFLVal;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdFLVal_1
typedef uint16 COM_DT_p_WHL_SpdFLVal_1;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdFRVal
typedef uint16 COM_DT_p_WHL_SpdFRVal;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdFRVal_1
typedef uint16 COM_DT_p_WHL_SpdFRVal_1;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdRLVal
typedef uint16 COM_DT_p_WHL_SpdRLVal;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdRLVal_1
typedef uint16 COM_DT_p_WHL_SpdRLVal_1;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdRRVal
typedef uint16 COM_DT_p_WHL_SpdRRVal;

#  define Rte_TypeDef_COM_DT_p_WHL_SpdRRVal_1
typedef uint16 COM_DT_p_WHL_SpdRRVal_1;

#  define Rte_TypeDef_COM_DT_p_YRS_YawRtVal
typedef uint16 COM_DT_p_YRS_YawRtVal;

#  define Rte_TypeDef_COM_DT_p_YRS_YawRtVal_1
typedef uint16 COM_DT_p_YRS_YawRtVal_1;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_01
typedef uint32 COM_DT_u32_DbgDataIn_01;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_02
typedef uint32 COM_DT_u32_DbgDataIn_02;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_03
typedef uint32 COM_DT_u32_DbgDataIn_03;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_04
typedef uint32 COM_DT_u32_DbgDataIn_04;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_05
typedef uint32 COM_DT_u32_DbgDataIn_05;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_06
typedef uint32 COM_DT_u32_DbgDataIn_06;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_07
typedef uint32 COM_DT_u32_DbgDataIn_07;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_08
typedef uint32 COM_DT_u32_DbgDataIn_08;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_09
typedef uint32 COM_DT_u32_DbgDataIn_09;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_10
typedef uint32 COM_DT_u32_DbgDataIn_10;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_11
typedef uint32 COM_DT_u32_DbgDataIn_11;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_12
typedef uint32 COM_DT_u32_DbgDataIn_12;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_13
typedef uint32 COM_DT_u32_DbgDataIn_13;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_14
typedef uint32 COM_DT_u32_DbgDataIn_14;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_15
typedef uint32 COM_DT_u32_DbgDataIn_15;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_16
typedef uint32 COM_DT_u32_DbgDataIn_16;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_17
typedef uint32 COM_DT_u32_DbgDataIn_17;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_18
typedef uint32 COM_DT_u32_DbgDataIn_18;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_19
typedef uint32 COM_DT_u32_DbgDataIn_19;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_2
typedef uint32 COM_DT_u32_DbgDataIn_2;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_20
typedef uint32 COM_DT_u32_DbgDataIn_20;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_21
typedef uint32 COM_DT_u32_DbgDataIn_21;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_22
typedef uint32 COM_DT_u32_DbgDataIn_22;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_23
typedef uint32 COM_DT_u32_DbgDataIn_23;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_24
typedef uint32 COM_DT_u32_DbgDataIn_24;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_25
typedef uint32 COM_DT_u32_DbgDataIn_25;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_26
typedef uint32 COM_DT_u32_DbgDataIn_26;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_27
typedef uint32 COM_DT_u32_DbgDataIn_27;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_28
typedef uint32 COM_DT_u32_DbgDataIn_28;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_29
typedef uint32 COM_DT_u32_DbgDataIn_29;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_3
typedef uint32 COM_DT_u32_DbgDataIn_3;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_30
typedef uint32 COM_DT_u32_DbgDataIn_30;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_31
typedef uint32 COM_DT_u32_DbgDataIn_31;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_32
typedef uint32 COM_DT_u32_DbgDataIn_32;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_33
typedef uint32 COM_DT_u32_DbgDataIn_33;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_34
typedef uint32 COM_DT_u32_DbgDataIn_34;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_35
typedef uint32 COM_DT_u32_DbgDataIn_35;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_36
typedef uint32 COM_DT_u32_DbgDataIn_36;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_37
typedef uint32 COM_DT_u32_DbgDataIn_37;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_38
typedef uint32 COM_DT_u32_DbgDataIn_38;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_39
typedef uint32 COM_DT_u32_DbgDataIn_39;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_4
typedef uint32 COM_DT_u32_DbgDataIn_4;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_40
typedef uint32 COM_DT_u32_DbgDataIn_40;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_41
typedef uint32 COM_DT_u32_DbgDataIn_41;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_42
typedef uint32 COM_DT_u32_DbgDataIn_42;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_43
typedef uint32 COM_DT_u32_DbgDataIn_43;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_44
typedef uint32 COM_DT_u32_DbgDataIn_44;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_45
typedef uint32 COM_DT_u32_DbgDataIn_45;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_46
typedef uint32 COM_DT_u32_DbgDataIn_46;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_47
typedef uint32 COM_DT_u32_DbgDataIn_47;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_48
typedef uint32 COM_DT_u32_DbgDataIn_48;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_49
typedef uint32 COM_DT_u32_DbgDataIn_49;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_5
typedef uint32 COM_DT_u32_DbgDataIn_5;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_50
typedef uint32 COM_DT_u32_DbgDataIn_50;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_51
typedef uint32 COM_DT_u32_DbgDataIn_51;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_52
typedef uint32 COM_DT_u32_DbgDataIn_52;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_53
typedef uint32 COM_DT_u32_DbgDataIn_53;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_54
typedef uint32 COM_DT_u32_DbgDataIn_54;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_55
typedef uint32 COM_DT_u32_DbgDataIn_55;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_56
typedef uint32 COM_DT_u32_DbgDataIn_56;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_57
typedef uint32 COM_DT_u32_DbgDataIn_57;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_58
typedef uint32 COM_DT_u32_DbgDataIn_58;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_59
typedef uint32 COM_DT_u32_DbgDataIn_59;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_6
typedef uint32 COM_DT_u32_DbgDataIn_6;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_60
typedef uint32 COM_DT_u32_DbgDataIn_60;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_61
typedef uint32 COM_DT_u32_DbgDataIn_61;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_62
typedef uint32 COM_DT_u32_DbgDataIn_62;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_63
typedef uint32 COM_DT_u32_DbgDataIn_63;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_64
typedef uint32 COM_DT_u32_DbgDataIn_64;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_65
typedef uint32 COM_DT_u32_DbgDataIn_65;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_66
typedef uint32 COM_DT_u32_DbgDataIn_66;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_67
typedef uint32 COM_DT_u32_DbgDataIn_67;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_68
typedef uint32 COM_DT_u32_DbgDataIn_68;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_69
typedef uint32 COM_DT_u32_DbgDataIn_69;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_7
typedef uint32 COM_DT_u32_DbgDataIn_7;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_70
typedef uint32 COM_DT_u32_DbgDataIn_70;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_71
typedef uint32 COM_DT_u32_DbgDataIn_71;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_72
typedef uint32 COM_DT_u32_DbgDataIn_72;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_73
typedef uint32 COM_DT_u32_DbgDataIn_73;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_74
typedef uint32 COM_DT_u32_DbgDataIn_74;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_75
typedef uint32 COM_DT_u32_DbgDataIn_75;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_76
typedef uint32 COM_DT_u32_DbgDataIn_76;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_77
typedef uint32 COM_DT_u32_DbgDataIn_77;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_78
typedef uint32 COM_DT_u32_DbgDataIn_78;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_79
typedef uint32 COM_DT_u32_DbgDataIn_79;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_8
typedef uint32 COM_DT_u32_DbgDataIn_8;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_80
typedef uint32 COM_DT_u32_DbgDataIn_80;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_81
typedef uint32 COM_DT_u32_DbgDataIn_81;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_82
typedef uint32 COM_DT_u32_DbgDataIn_82;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_83
typedef uint32 COM_DT_u32_DbgDataIn_83;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_84
typedef uint32 COM_DT_u32_DbgDataIn_84;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_85
typedef uint32 COM_DT_u32_DbgDataIn_85;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_86
typedef uint32 COM_DT_u32_DbgDataIn_86;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_87
typedef uint32 COM_DT_u32_DbgDataIn_87;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_88
typedef uint32 COM_DT_u32_DbgDataIn_88;

#  define Rte_TypeDef_COM_DT_u32_DbgDataIn_9
typedef uint32 COM_DT_u32_DbgDataIn_9;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_01
typedef uint32 COM_DT_u32_DbgDataOut_01;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_02
typedef uint32 COM_DT_u32_DbgDataOut_02;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_03
typedef uint32 COM_DT_u32_DbgDataOut_03;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_04
typedef uint32 COM_DT_u32_DbgDataOut_04;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_05
typedef uint32 COM_DT_u32_DbgDataOut_05;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_06
typedef uint32 COM_DT_u32_DbgDataOut_06;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_07
typedef uint32 COM_DT_u32_DbgDataOut_07;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_08
typedef uint32 COM_DT_u32_DbgDataOut_08;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_09
typedef uint32 COM_DT_u32_DbgDataOut_09;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_10
typedef uint32 COM_DT_u32_DbgDataOut_10;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_100
typedef uint32 COM_DT_u32_DbgDataOut_100;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_101
typedef uint32 COM_DT_u32_DbgDataOut_101;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_102
typedef uint32 COM_DT_u32_DbgDataOut_102;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_103
typedef uint32 COM_DT_u32_DbgDataOut_103;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_104
typedef uint32 COM_DT_u32_DbgDataOut_104;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_105
typedef uint32 COM_DT_u32_DbgDataOut_105;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_106
typedef uint32 COM_DT_u32_DbgDataOut_106;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_107
typedef uint32 COM_DT_u32_DbgDataOut_107;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_108
typedef uint32 COM_DT_u32_DbgDataOut_108;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_109
typedef uint32 COM_DT_u32_DbgDataOut_109;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_11
typedef uint32 COM_DT_u32_DbgDataOut_11;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_110
typedef uint32 COM_DT_u32_DbgDataOut_110;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_111
typedef uint32 COM_DT_u32_DbgDataOut_111;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_112
typedef uint32 COM_DT_u32_DbgDataOut_112;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_113
typedef uint32 COM_DT_u32_DbgDataOut_113;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_114
typedef uint32 COM_DT_u32_DbgDataOut_114;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_115
typedef uint32 COM_DT_u32_DbgDataOut_115;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_116
typedef uint32 COM_DT_u32_DbgDataOut_116;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_117
typedef uint32 COM_DT_u32_DbgDataOut_117;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_118
typedef uint32 COM_DT_u32_DbgDataOut_118;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_119
typedef uint32 COM_DT_u32_DbgDataOut_119;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_12
typedef uint32 COM_DT_u32_DbgDataOut_12;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_120
typedef uint32 COM_DT_u32_DbgDataOut_120;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_121
typedef uint32 COM_DT_u32_DbgDataOut_121;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_122
typedef uint32 COM_DT_u32_DbgDataOut_122;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_123
typedef uint32 COM_DT_u32_DbgDataOut_123;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_124
typedef uint32 COM_DT_u32_DbgDataOut_124;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_125
typedef uint32 COM_DT_u32_DbgDataOut_125;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_126
typedef uint32 COM_DT_u32_DbgDataOut_126;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_127
typedef uint32 COM_DT_u32_DbgDataOut_127;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_128
typedef uint32 COM_DT_u32_DbgDataOut_128;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_129
typedef uint32 COM_DT_u32_DbgDataOut_129;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_13
typedef uint32 COM_DT_u32_DbgDataOut_13;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_130
typedef uint32 COM_DT_u32_DbgDataOut_130;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_131
typedef uint32 COM_DT_u32_DbgDataOut_131;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_132
typedef uint32 COM_DT_u32_DbgDataOut_132;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_133
typedef uint32 COM_DT_u32_DbgDataOut_133;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_134
typedef uint32 COM_DT_u32_DbgDataOut_134;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_135
typedef uint32 COM_DT_u32_DbgDataOut_135;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_136
typedef uint32 COM_DT_u32_DbgDataOut_136;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_137
typedef uint32 COM_DT_u32_DbgDataOut_137;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_138
typedef uint32 COM_DT_u32_DbgDataOut_138;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_139
typedef uint32 COM_DT_u32_DbgDataOut_139;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_14
typedef uint32 COM_DT_u32_DbgDataOut_14;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_140
typedef uint32 COM_DT_u32_DbgDataOut_140;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_141
typedef uint32 COM_DT_u32_DbgDataOut_141;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_142
typedef uint32 COM_DT_u32_DbgDataOut_142;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_143
typedef uint32 COM_DT_u32_DbgDataOut_143;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_144
typedef uint32 COM_DT_u32_DbgDataOut_144;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_145
typedef uint32 COM_DT_u32_DbgDataOut_145;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_146
typedef uint32 COM_DT_u32_DbgDataOut_146;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_147
typedef uint32 COM_DT_u32_DbgDataOut_147;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_148
typedef uint32 COM_DT_u32_DbgDataOut_148;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_149
typedef uint32 COM_DT_u32_DbgDataOut_149;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_15
typedef uint32 COM_DT_u32_DbgDataOut_15;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_150
typedef uint32 COM_DT_u32_DbgDataOut_150;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_151
typedef uint32 COM_DT_u32_DbgDataOut_151;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_152
typedef uint32 COM_DT_u32_DbgDataOut_152;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_153
typedef uint32 COM_DT_u32_DbgDataOut_153;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_154
typedef uint32 COM_DT_u32_DbgDataOut_154;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_155
typedef uint32 COM_DT_u32_DbgDataOut_155;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_156
typedef uint32 COM_DT_u32_DbgDataOut_156;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_157
typedef uint32 COM_DT_u32_DbgDataOut_157;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_158
typedef uint32 COM_DT_u32_DbgDataOut_158;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_159
typedef uint32 COM_DT_u32_DbgDataOut_159;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_16
typedef uint32 COM_DT_u32_DbgDataOut_16;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_160
typedef uint32 COM_DT_u32_DbgDataOut_160;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_161
typedef uint32 COM_DT_u32_DbgDataOut_161;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_162
typedef uint32 COM_DT_u32_DbgDataOut_162;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_163
typedef uint32 COM_DT_u32_DbgDataOut_163;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_164
typedef uint32 COM_DT_u32_DbgDataOut_164;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_165
typedef uint32 COM_DT_u32_DbgDataOut_165;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_166
typedef uint32 COM_DT_u32_DbgDataOut_166;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_167
typedef uint32 COM_DT_u32_DbgDataOut_167;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_168
typedef uint32 COM_DT_u32_DbgDataOut_168;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_169
typedef uint32 COM_DT_u32_DbgDataOut_169;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_17
typedef uint32 COM_DT_u32_DbgDataOut_17;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_170
typedef uint32 COM_DT_u32_DbgDataOut_170;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_171
typedef uint32 COM_DT_u32_DbgDataOut_171;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_172
typedef uint32 COM_DT_u32_DbgDataOut_172;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_173
typedef uint32 COM_DT_u32_DbgDataOut_173;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_174
typedef uint32 COM_DT_u32_DbgDataOut_174;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_175
typedef uint32 COM_DT_u32_DbgDataOut_175;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_176
typedef uint32 COM_DT_u32_DbgDataOut_176;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_177
typedef uint32 COM_DT_u32_DbgDataOut_177;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_178
typedef uint32 COM_DT_u32_DbgDataOut_178;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_179
typedef uint32 COM_DT_u32_DbgDataOut_179;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_18
typedef uint32 COM_DT_u32_DbgDataOut_18;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_180
typedef uint32 COM_DT_u32_DbgDataOut_180;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_181
typedef uint32 COM_DT_u32_DbgDataOut_181;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_182
typedef uint32 COM_DT_u32_DbgDataOut_182;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_183
typedef uint32 COM_DT_u32_DbgDataOut_183;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_184
typedef uint32 COM_DT_u32_DbgDataOut_184;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_185
typedef uint32 COM_DT_u32_DbgDataOut_185;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_186
typedef uint32 COM_DT_u32_DbgDataOut_186;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_187
typedef uint32 COM_DT_u32_DbgDataOut_187;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_188
typedef uint32 COM_DT_u32_DbgDataOut_188;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_189
typedef uint32 COM_DT_u32_DbgDataOut_189;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_19
typedef uint32 COM_DT_u32_DbgDataOut_19;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_190
typedef uint32 COM_DT_u32_DbgDataOut_190;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_191
typedef uint32 COM_DT_u32_DbgDataOut_191;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_192
typedef uint32 COM_DT_u32_DbgDataOut_192;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_193
typedef uint32 COM_DT_u32_DbgDataOut_193;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_194
typedef uint32 COM_DT_u32_DbgDataOut_194;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_195
typedef uint32 COM_DT_u32_DbgDataOut_195;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_196
typedef uint32 COM_DT_u32_DbgDataOut_196;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_197
typedef uint32 COM_DT_u32_DbgDataOut_197;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_198
typedef uint32 COM_DT_u32_DbgDataOut_198;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_199
typedef uint32 COM_DT_u32_DbgDataOut_199;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_2
typedef uint32 COM_DT_u32_DbgDataOut_2;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_20
typedef uint32 COM_DT_u32_DbgDataOut_20;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_200
typedef uint32 COM_DT_u32_DbgDataOut_200;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_201
typedef uint32 COM_DT_u32_DbgDataOut_201;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_202
typedef uint32 COM_DT_u32_DbgDataOut_202;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_203
typedef uint32 COM_DT_u32_DbgDataOut_203;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_204
typedef uint32 COM_DT_u32_DbgDataOut_204;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_205
typedef uint32 COM_DT_u32_DbgDataOut_205;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_206
typedef uint32 COM_DT_u32_DbgDataOut_206;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_207
typedef uint32 COM_DT_u32_DbgDataOut_207;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_208
typedef uint32 COM_DT_u32_DbgDataOut_208;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_209
typedef uint32 COM_DT_u32_DbgDataOut_209;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_21
typedef uint32 COM_DT_u32_DbgDataOut_21;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_210
typedef uint32 COM_DT_u32_DbgDataOut_210;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_211
typedef uint32 COM_DT_u32_DbgDataOut_211;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_212
typedef uint32 COM_DT_u32_DbgDataOut_212;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_213
typedef uint32 COM_DT_u32_DbgDataOut_213;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_214
typedef uint32 COM_DT_u32_DbgDataOut_214;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_215
typedef uint32 COM_DT_u32_DbgDataOut_215;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_216
typedef uint32 COM_DT_u32_DbgDataOut_216;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_217
typedef uint32 COM_DT_u32_DbgDataOut_217;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_218
typedef uint32 COM_DT_u32_DbgDataOut_218;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_219
typedef uint32 COM_DT_u32_DbgDataOut_219;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_22
typedef uint32 COM_DT_u32_DbgDataOut_22;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_220
typedef uint32 COM_DT_u32_DbgDataOut_220;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_221
typedef uint32 COM_DT_u32_DbgDataOut_221;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_222
typedef uint32 COM_DT_u32_DbgDataOut_222;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_223
typedef uint32 COM_DT_u32_DbgDataOut_223;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_224
typedef uint32 COM_DT_u32_DbgDataOut_224;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_225
typedef uint32 COM_DT_u32_DbgDataOut_225;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_226
typedef uint32 COM_DT_u32_DbgDataOut_226;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_227
typedef uint32 COM_DT_u32_DbgDataOut_227;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_228
typedef uint32 COM_DT_u32_DbgDataOut_228;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_229
typedef uint32 COM_DT_u32_DbgDataOut_229;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_23
typedef uint32 COM_DT_u32_DbgDataOut_23;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_230
typedef uint32 COM_DT_u32_DbgDataOut_230;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_231
typedef uint32 COM_DT_u32_DbgDataOut_231;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_232
typedef uint32 COM_DT_u32_DbgDataOut_232;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_233
typedef uint32 COM_DT_u32_DbgDataOut_233;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_234
typedef uint32 COM_DT_u32_DbgDataOut_234;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_235
typedef uint32 COM_DT_u32_DbgDataOut_235;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_236
typedef uint32 COM_DT_u32_DbgDataOut_236;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_237
typedef uint32 COM_DT_u32_DbgDataOut_237;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_238
typedef uint32 COM_DT_u32_DbgDataOut_238;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_239
typedef uint32 COM_DT_u32_DbgDataOut_239;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_24
typedef uint32 COM_DT_u32_DbgDataOut_24;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_240
typedef uint32 COM_DT_u32_DbgDataOut_240;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_241
typedef uint32 COM_DT_u32_DbgDataOut_241;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_242
typedef uint32 COM_DT_u32_DbgDataOut_242;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_243
typedef uint32 COM_DT_u32_DbgDataOut_243;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_244
typedef uint32 COM_DT_u32_DbgDataOut_244;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_245
typedef uint32 COM_DT_u32_DbgDataOut_245;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_246
typedef uint32 COM_DT_u32_DbgDataOut_246;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_247
typedef uint32 COM_DT_u32_DbgDataOut_247;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_248
typedef uint32 COM_DT_u32_DbgDataOut_248;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_249
typedef uint32 COM_DT_u32_DbgDataOut_249;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_25
typedef uint32 COM_DT_u32_DbgDataOut_25;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_250
typedef uint32 COM_DT_u32_DbgDataOut_250;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_251
typedef uint32 COM_DT_u32_DbgDataOut_251;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_252
typedef uint32 COM_DT_u32_DbgDataOut_252;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_253
typedef uint32 COM_DT_u32_DbgDataOut_253;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_254
typedef uint32 COM_DT_u32_DbgDataOut_254;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_255
typedef uint32 COM_DT_u32_DbgDataOut_255;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_256
typedef uint32 COM_DT_u32_DbgDataOut_256;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_257
typedef uint32 COM_DT_u32_DbgDataOut_257;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_258
typedef uint32 COM_DT_u32_DbgDataOut_258;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_259
typedef uint32 COM_DT_u32_DbgDataOut_259;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_26
typedef uint32 COM_DT_u32_DbgDataOut_26;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_260
typedef uint32 COM_DT_u32_DbgDataOut_260;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_261
typedef uint32 COM_DT_u32_DbgDataOut_261;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_262
typedef uint32 COM_DT_u32_DbgDataOut_262;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_263
typedef uint32 COM_DT_u32_DbgDataOut_263;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_264
typedef uint32 COM_DT_u32_DbgDataOut_264;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_265
typedef uint32 COM_DT_u32_DbgDataOut_265;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_266
typedef uint32 COM_DT_u32_DbgDataOut_266;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_267
typedef uint32 COM_DT_u32_DbgDataOut_267;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_268
typedef uint32 COM_DT_u32_DbgDataOut_268;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_269
typedef uint32 COM_DT_u32_DbgDataOut_269;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_27
typedef uint32 COM_DT_u32_DbgDataOut_27;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_270
typedef uint32 COM_DT_u32_DbgDataOut_270;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_271
typedef uint32 COM_DT_u32_DbgDataOut_271;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_272
typedef uint32 COM_DT_u32_DbgDataOut_272;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_273
typedef uint32 COM_DT_u32_DbgDataOut_273;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_274
typedef uint32 COM_DT_u32_DbgDataOut_274;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_275
typedef uint32 COM_DT_u32_DbgDataOut_275;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_276
typedef uint32 COM_DT_u32_DbgDataOut_276;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_277
typedef uint32 COM_DT_u32_DbgDataOut_277;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_278
typedef uint32 COM_DT_u32_DbgDataOut_278;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_279
typedef uint32 COM_DT_u32_DbgDataOut_279;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_28
typedef uint32 COM_DT_u32_DbgDataOut_28;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_280
typedef uint32 COM_DT_u32_DbgDataOut_280;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_281
typedef uint32 COM_DT_u32_DbgDataOut_281;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_282
typedef uint32 COM_DT_u32_DbgDataOut_282;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_283
typedef uint32 COM_DT_u32_DbgDataOut_283;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_284
typedef uint32 COM_DT_u32_DbgDataOut_284;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_285
typedef uint32 COM_DT_u32_DbgDataOut_285;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_286
typedef uint32 COM_DT_u32_DbgDataOut_286;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_287
typedef uint32 COM_DT_u32_DbgDataOut_287;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_288
typedef uint32 COM_DT_u32_DbgDataOut_288;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_289
typedef uint32 COM_DT_u32_DbgDataOut_289;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_29
typedef uint32 COM_DT_u32_DbgDataOut_29;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_290
typedef uint32 COM_DT_u32_DbgDataOut_290;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_291
typedef uint32 COM_DT_u32_DbgDataOut_291;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_292
typedef uint32 COM_DT_u32_DbgDataOut_292;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_293
typedef uint32 COM_DT_u32_DbgDataOut_293;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_294
typedef uint32 COM_DT_u32_DbgDataOut_294;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_295
typedef uint32 COM_DT_u32_DbgDataOut_295;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_296
typedef uint32 COM_DT_u32_DbgDataOut_296;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_297
typedef uint32 COM_DT_u32_DbgDataOut_297;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_298
typedef uint32 COM_DT_u32_DbgDataOut_298;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_299
typedef uint32 COM_DT_u32_DbgDataOut_299;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_3
typedef uint32 COM_DT_u32_DbgDataOut_3;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_30
typedef uint32 COM_DT_u32_DbgDataOut_30;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_300
typedef uint32 COM_DT_u32_DbgDataOut_300;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_301
typedef uint32 COM_DT_u32_DbgDataOut_301;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_302
typedef uint32 COM_DT_u32_DbgDataOut_302;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_303
typedef uint32 COM_DT_u32_DbgDataOut_303;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_304
typedef uint32 COM_DT_u32_DbgDataOut_304;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_305
typedef uint32 COM_DT_u32_DbgDataOut_305;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_306
typedef uint32 COM_DT_u32_DbgDataOut_306;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_307
typedef uint32 COM_DT_u32_DbgDataOut_307;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_308
typedef uint32 COM_DT_u32_DbgDataOut_308;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_309
typedef uint32 COM_DT_u32_DbgDataOut_309;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_31
typedef uint32 COM_DT_u32_DbgDataOut_31;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_310
typedef uint32 COM_DT_u32_DbgDataOut_310;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_311
typedef uint32 COM_DT_u32_DbgDataOut_311;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_312
typedef uint32 COM_DT_u32_DbgDataOut_312;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_313
typedef uint32 COM_DT_u32_DbgDataOut_313;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_314
typedef uint32 COM_DT_u32_DbgDataOut_314;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_315
typedef uint32 COM_DT_u32_DbgDataOut_315;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_316
typedef uint32 COM_DT_u32_DbgDataOut_316;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_317
typedef uint32 COM_DT_u32_DbgDataOut_317;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_318
typedef uint32 COM_DT_u32_DbgDataOut_318;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_319
typedef uint32 COM_DT_u32_DbgDataOut_319;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_32
typedef uint32 COM_DT_u32_DbgDataOut_32;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_320
typedef uint32 COM_DT_u32_DbgDataOut_320;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_321
typedef uint32 COM_DT_u32_DbgDataOut_321;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_322
typedef uint32 COM_DT_u32_DbgDataOut_322;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_323
typedef uint32 COM_DT_u32_DbgDataOut_323;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_324
typedef uint32 COM_DT_u32_DbgDataOut_324;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_325
typedef uint32 COM_DT_u32_DbgDataOut_325;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_326
typedef uint32 COM_DT_u32_DbgDataOut_326;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_327
typedef uint32 COM_DT_u32_DbgDataOut_327;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_328
typedef uint32 COM_DT_u32_DbgDataOut_328;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_33
typedef uint32 COM_DT_u32_DbgDataOut_33;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_34
typedef uint32 COM_DT_u32_DbgDataOut_34;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_35
typedef uint32 COM_DT_u32_DbgDataOut_35;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_36
typedef uint32 COM_DT_u32_DbgDataOut_36;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_37
typedef uint32 COM_DT_u32_DbgDataOut_37;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_38
typedef uint32 COM_DT_u32_DbgDataOut_38;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_39
typedef uint32 COM_DT_u32_DbgDataOut_39;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_4
typedef uint32 COM_DT_u32_DbgDataOut_4;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_40
typedef uint32 COM_DT_u32_DbgDataOut_40;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_41
typedef uint32 COM_DT_u32_DbgDataOut_41;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_42
typedef uint32 COM_DT_u32_DbgDataOut_42;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_43
typedef uint32 COM_DT_u32_DbgDataOut_43;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_44
typedef uint32 COM_DT_u32_DbgDataOut_44;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_45
typedef uint32 COM_DT_u32_DbgDataOut_45;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_46
typedef uint32 COM_DT_u32_DbgDataOut_46;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_47
typedef uint32 COM_DT_u32_DbgDataOut_47;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_48
typedef uint32 COM_DT_u32_DbgDataOut_48;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_49
typedef uint32 COM_DT_u32_DbgDataOut_49;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_5
typedef uint32 COM_DT_u32_DbgDataOut_5;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_50
typedef uint32 COM_DT_u32_DbgDataOut_50;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_51
typedef uint32 COM_DT_u32_DbgDataOut_51;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_52
typedef uint32 COM_DT_u32_DbgDataOut_52;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_53
typedef uint32 COM_DT_u32_DbgDataOut_53;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_54
typedef uint32 COM_DT_u32_DbgDataOut_54;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_55
typedef uint32 COM_DT_u32_DbgDataOut_55;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_56
typedef uint32 COM_DT_u32_DbgDataOut_56;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_57
typedef uint32 COM_DT_u32_DbgDataOut_57;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_58
typedef uint32 COM_DT_u32_DbgDataOut_58;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_59
typedef uint32 COM_DT_u32_DbgDataOut_59;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_6
typedef uint32 COM_DT_u32_DbgDataOut_6;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_60
typedef uint32 COM_DT_u32_DbgDataOut_60;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_61
typedef uint32 COM_DT_u32_DbgDataOut_61;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_62
typedef uint32 COM_DT_u32_DbgDataOut_62;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_63
typedef uint32 COM_DT_u32_DbgDataOut_63;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_64
typedef uint32 COM_DT_u32_DbgDataOut_64;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_65
typedef uint32 COM_DT_u32_DbgDataOut_65;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_66
typedef uint32 COM_DT_u32_DbgDataOut_66;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_67
typedef uint32 COM_DT_u32_DbgDataOut_67;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_68
typedef uint32 COM_DT_u32_DbgDataOut_68;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_69
typedef uint32 COM_DT_u32_DbgDataOut_69;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_7
typedef uint32 COM_DT_u32_DbgDataOut_7;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_70
typedef uint32 COM_DT_u32_DbgDataOut_70;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_71
typedef uint32 COM_DT_u32_DbgDataOut_71;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_72
typedef uint32 COM_DT_u32_DbgDataOut_72;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_73
typedef uint32 COM_DT_u32_DbgDataOut_73;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_74
typedef uint32 COM_DT_u32_DbgDataOut_74;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_75
typedef uint32 COM_DT_u32_DbgDataOut_75;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_76
typedef uint32 COM_DT_u32_DbgDataOut_76;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_77
typedef uint32 COM_DT_u32_DbgDataOut_77;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_78
typedef uint32 COM_DT_u32_DbgDataOut_78;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_79
typedef uint32 COM_DT_u32_DbgDataOut_79;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_8
typedef uint32 COM_DT_u32_DbgDataOut_8;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_80
typedef uint32 COM_DT_u32_DbgDataOut_80;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_81
typedef uint32 COM_DT_u32_DbgDataOut_81;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_82
typedef uint32 COM_DT_u32_DbgDataOut_82;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_83
typedef uint32 COM_DT_u32_DbgDataOut_83;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_84
typedef uint32 COM_DT_u32_DbgDataOut_84;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_85
typedef uint32 COM_DT_u32_DbgDataOut_85;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_86
typedef uint32 COM_DT_u32_DbgDataOut_86;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_87
typedef uint32 COM_DT_u32_DbgDataOut_87;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_88
typedef uint32 COM_DT_u32_DbgDataOut_88;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_89
typedef uint32 COM_DT_u32_DbgDataOut_89;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_9
typedef uint32 COM_DT_u32_DbgDataOut_9;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_90
typedef uint32 COM_DT_u32_DbgDataOut_90;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_91
typedef uint32 COM_DT_u32_DbgDataOut_91;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_92
typedef uint32 COM_DT_u32_DbgDataOut_92;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_93
typedef uint32 COM_DT_u32_DbgDataOut_93;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_94
typedef uint32 COM_DT_u32_DbgDataOut_94;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_95
typedef uint32 COM_DT_u32_DbgDataOut_95;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_96
typedef uint32 COM_DT_u32_DbgDataOut_96;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_97
typedef uint32 COM_DT_u32_DbgDataOut_97;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_98
typedef uint32 COM_DT_u32_DbgDataOut_98;

#  define Rte_TypeDef_COM_DT_u32_DbgDataOut_99
typedef uint32 COM_DT_u32_DbgDataOut_99;

#  define Rte_TypeDef_ESS_Sta
typedef uint8 ESS_Sta;

#  define Rte_TypeDef_FCA_DclReqVal
typedef uint8 FCA_DclReqVal;

#  define Rte_TypeDef_FCA_DclReqVal_1
typedef uint8 FCA_DclReqVal_1;

#  define Rte_TypeDef_FCA_RelVel
typedef uint16 FCA_RelVel;

#  define Rte_TypeDef_FCA_RelVel_1
typedef uint16 FCA_RelVel_1;

#  define Rte_TypeDef_FCA_TimetoCllsn
typedef uint8 FCA_TimetoCllsn;

#  define Rte_TypeDef_FCA_TimetoCllsn_1
typedef uint8 FCA_TimetoCllsn_1;

#  define Rte_TypeDef_FR_RDR_HW_Reset
typedef uint8 FR_RDR_HW_Reset;

#  define Rte_TypeDef_FR_RDR_SW_Reset
typedef uint8 FR_RDR_SW_Reset;

#  define Rte_TypeDef_ICC_HDPSpprtSWVer
typedef uint8 ICC_HDPSpprtSWVer;

#  define Rte_TypeDef_ICC_HS_AlvCnt1Val
typedef uint8 ICC_HS_AlvCnt1Val;

#  define Rte_TypeDef_ICC_HS_Crc1Val
typedef uint8 ICC_HS_Crc1Val;

#  define Rte_TypeDef_ICC_MajorSWVer
typedef uint8 ICC_MajorSWVer;

#  define Rte_TypeDef_ICC_MinorSWVer
typedef uint8 ICC_MinorSWVer;

#  define Rte_TypeDef_ICC_WarningSmblDistStat
typedef boolean ICC_WarningSmblDistStat;

#  define Rte_TypeDef_ICC_WarningSmblDrowStat
typedef boolean ICC_WarningSmblDrowStat;

#  define Rte_TypeDef_ICC_WarningSnd2Stat
typedef boolean ICC_WarningSnd2Stat;

#  define Rte_TypeDef_ICC_WarningSndStat
typedef boolean ICC_WarningSndStat;

#  define Rte_TypeDef_Ls_Is_Construction_Area
typedef uint8 Ls_Is_Construction_Area;

#  define Rte_TypeDef_NSCC_Op2Sta
typedef uint8 NSCC_Op2Sta;

#  define Rte_TypeDef_Navi_ISLW_CountryCode
typedef uint16 Navi_ISLW_CountryCode;

#  define Rte_TypeDef_Navi_ISLW_MapSource
typedef uint8 Navi_ISLW_MapSource;

#  define Rte_TypeDef_Navi_ISLW_SpdLimit
typedef uint8 Navi_ISLW_SpdLimit;

#  define Rte_TypeDef_Navi_ISLW_TimeSpd
typedef uint8 Navi_ISLW_TimeSpd;

#  define Rte_TypeDef_RD_DTC_AlvCntVal
typedef uint8 RD_DTC_AlvCntVal;

#  define Rte_TypeDef_RD_DTC_CRCVal
typedef uint16 RD_DTC_CRCVal;

#  define Rte_TypeDef_RadarCANCommError
typedef uint8 RadarCANCommError;

#  define Rte_TypeDef_RadarErrorCode_No1
typedef uint16 RadarErrorCode_No1;

#  define Rte_TypeDef_RadarErrorCode_No2
typedef uint16 RadarErrorCode_No2;

#  define Rte_TypeDef_RadarHwError
typedef uint8 RadarHwError;

#  define Rte_TypeDef_RadarHwTempCondition_High
typedef uint8 RadarHwTempCondition_High;

#  define Rte_TypeDef_RadarHwTempCondition_Low
typedef uint8 RadarHwTempCondition_Low;

#  define Rte_TypeDef_Rte_DT_NvMVersionDataRead_0_0
typedef uint8 Rte_DT_NvMVersionDataRead_0_0;

#  define Rte_TypeDef_SCC_AccelLimBandLwrVal
typedef uint8 SCC_AccelLimBandLwrVal;

#  define Rte_TypeDef_SCC_AccelLimBandUppVal
typedef uint8 SCC_AccelLimBandUppVal;

#  define Rte_TypeDef_SCC_AccelReqRawVal
typedef uint16 SCC_AccelReqRawVal;

#  define Rte_TypeDef_SCC_AccelReqVal
typedef uint16 SCC_AccelReqVal;

#  define Rte_TypeDef_SCC_DrvAlrtDis
typedef uint8 SCC_DrvAlrtDis;

#  define Rte_TypeDef_SCC_EngStateReq
typedef uint8 SCC_EngStateReq;

#  define Rte_TypeDef_SCC_HeadwayDstSetVal
typedef uint8 SCC_HeadwayDstSetVal;

#  define Rte_TypeDef_SCC_InfoDis
typedef uint8 SCC_InfoDis;

#  define Rte_TypeDef_SCC_JrkLwrLimVal
typedef uint8 SCC_JrkLwrLimVal;

#  define Rte_TypeDef_SCC_JrkUppLimVal
typedef uint8 SCC_JrkUppLimVal;

#  define Rte_TypeDef_SCC_NSCCInfoPUDis
typedef uint8 SCC_NSCCInfoPUDis;

#  define Rte_TypeDef_SCC_ObjDstVal
typedef uint16 SCC_ObjDstVal;

#  define Rte_TypeDef_SCC_ObjLatPosVal
typedef uint16 SCC_ObjLatPosVal;

#  define Rte_TypeDef_SCC_ObjRelSpdVal
typedef uint16 SCC_ObjRelSpdVal;

#  define Rte_TypeDef_SCC_ObjSta
typedef uint8 SCC_ObjSta;

#  define Rte_TypeDef_SCC_OpSta
typedef uint8 SCC_OpSta;

#  define Rte_TypeDef_SCC_SnstvtyModRetVal
typedef uint8 SCC_SnstvtyModRetVal;

#  define Rte_TypeDef_SCC_TrgtDstVal
typedef uint16 SCC_TrgtDstVal;

#  define Rte_TypeDef_SystemOutOfCalibration_DRV
typedef uint8 SystemOutOfCalibration_DRV;

#  define Rte_TypeDef_SystemOutOfCalibration_EOL
typedef uint8 SystemOutOfCalibration_EOL;

#  define Rte_TypeDef_VN
typedef uint16 VN;

#  define Rte_TypeDef_VN_t_2
typedef uint16 VN_t_2;

#  define Rte_TypeDef_dtRef_VOID
typedef void * dtRef_VOID;

#  define Rte_TypeDef_dtRef_const_VOID
typedef const void * dtRef_const_VOID;

#  define Rte_TypeDef_p_CF_Gway_InhibitRMT_t_1
typedef uint8 p_CF_Gway_InhibitRMT_t_1;

#  define Rte_TypeDef_p_CLU_OutTempCSta
typedef uint8 p_CLU_OutTempCSta;

#  define Rte_TypeDef_p_CR_Fatc_OutTemp_t_1
typedef uint8 p_CR_Fatc_OutTemp_t_1;

#  define Rte_TypeDef_p_HCU_HevRdySta
typedef uint8 p_HCU_HevRdySta;

#  define Rte_TypeDef_p_SAS_AnglVal
typedef sint16 p_SAS_AnglVal;

#  define Rte_TypeDef_p_SAS_Angle_t
typedef sint16 p_SAS_Angle_t;

#  define Rte_TypeDef_p_WHL_SpdFLVal
typedef uint16 p_WHL_SpdFLVal;

#  define Rte_TypeDef_p_WHL_SpdFL_t_1
typedef uint16 p_WHL_SpdFL_t_1;

#  define Rte_TypeDef_p_WHL_SpdFRVal
typedef uint16 p_WHL_SpdFRVal;

#  define Rte_TypeDef_p_WHL_SpdFR_t_1
typedef uint16 p_WHL_SpdFR_t_1;

#  define Rte_TypeDef_p_WHL_SpdRLVal
typedef uint16 p_WHL_SpdRLVal;

#  define Rte_TypeDef_p_WHL_SpdRL_t_1
typedef uint16 p_WHL_SpdRL_t_1;

#  define Rte_TypeDef_p_WHL_SpdRRVal
typedef uint16 p_WHL_SpdRRVal;

#  define Rte_TypeDef_p_WHL_SpdRR_t_1
typedef uint16 p_WHL_SpdRR_t_1;

#  define Rte_TypeDef_p_YRS_YawRtVal
typedef uint16 p_YRS_YawRtVal;

#  define Rte_TypeDef_p_Yaw_rate_t_1
typedef uint16 p_Yaw_rate_t_1;

#  define Rte_TypeDef_uint8_ptr_t
typedef uint8 * uint8_ptr_t;

#  define Rte_TypeDef_ABS_ActvSta
typedef uint8 ABS_ActvSta;

#  define Rte_TypeDef_ABS_DfctvSta
typedef uint8 ABS_DfctvSta;

#  define Rte_TypeDef_ABS_WrngLmpSta
typedef uint8 ABS_WrngLmpSta;

#  define Rte_TypeDef_ADAS_DrUnlckReqSta
typedef uint8 ADAS_DrUnlckReqSta;

#  define Rte_TypeDef_ADAS_InhbtOffDispSta
typedef uint8 ADAS_InhbtOffDispSta;

#  define Rte_TypeDef_ADAS_TrlOffStaDisp
typedef uint8 ADAS_TrlOffStaDisp;

#  define Rte_TypeDef_COM_DT_ABSDActvSta
typedef uint8 COM_DT_ABSDActvSta;

#  define Rte_TypeDef_COM_DT_ABSDDfctvSta
typedef uint8 COM_DT_ABSDDfctvSta;

#  define Rte_TypeDef_COM_DT_ADAS_ActToiSta
typedef uint8 COM_DT_ADAS_ActToiSta;

#  define Rte_TypeDef_COM_DT_ADAS_ToiFltSta
typedef uint8 COM_DT_ADAS_ToiFltSta;

#  define Rte_TypeDef_COM_DT_AVH_ActvStaLmpDis
typedef uint8 COM_DT_AVH_ActvStaLmpDis;

#  define Rte_TypeDef_COM_DT_AVH_LmpDis
typedef uint8 COM_DT_AVH_LmpDis;

#  define Rte_TypeDef_COM_DT_AVN_RSPA_CancelInput
typedef uint8 COM_DT_AVN_RSPA_CancelInput;

#  define Rte_TypeDef_COM_DT_AVN_RSPA_Disp_Rdy
typedef uint8 COM_DT_AVN_RSPA_Disp_Rdy;

#  define Rte_TypeDef_COM_DT_AWD_CrdnShftTqLimVal
typedef uint16 COM_DT_AWD_CrdnShftTqLimVal;

#  define Rte_TypeDef_COM_DT_AWD_FastOpnCrdnShftCltchReq
typedef uint8 COM_DT_AWD_FastOpnCrdnShftCltchReq;

#  define Rte_TypeDef_COM_DT_AWD_RrWhlDtyLimReq
typedef uint8 COM_DT_AWD_RrWhlDtyLimReq;

#  define Rte_TypeDef_COM_DT_AWD_TransmsnTqLimModSta
typedef uint8 COM_DT_AWD_TransmsnTqLimModSta;

#  define Rte_TypeDef_COM_DT_Autocut_DlvryModSta
typedef uint8 COM_DT_Autocut_DlvryModSta;

#  define Rte_TypeDef_COM_DT_BCA_Rear_WrnSta
typedef uint8 COM_DT_BCA_Rear_WrnSta;

#  define Rte_TypeDef_COM_DT_BCAref_FrCmrSta
typedef uint8 COM_DT_BCAref_FrCmrSta;

#  define Rte_TypeDef_COM_DT_BCM_GearPosPSta
typedef uint8 COM_DT_BCM_GearPosPSta;

#  define Rte_TypeDef_COM_DT_BCM_SunRoofOpnSta
typedef uint8 COM_DT_BCM_SunRoofOpnSta;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluFuelEconUnit_mi
typedef uint8 COM_DT_CF_AVN_CluFuelEconUnit_mi;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluRoadInfoGuide
typedef uint8 COM_DT_CF_AVN_CluRoadInfoGuide;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluServiceReminderReset
typedef uint8 COM_DT_CF_AVN_CluServiceReminderReset;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluServiceReminderSet
typedef uint8 COM_DT_CF_AVN_CluServiceReminderSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluTransmissionDisp
typedef uint8 COM_DT_CF_AVN_CluTransmissionDisp;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluUSMReset
typedef uint8 COM_DT_CF_AVN_CluUSMReset;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluWelcomeSnd
typedef uint8 COM_DT_CF_AVN_CluWelcomeSnd;

#  define Rte_TypeDef_COM_DT_CF_AVN_CluWiperLight
typedef uint8 COM_DT_CF_AVN_CluWiperLight;

#  define Rte_TypeDef_COM_DT_CF_AVN_DAW_LVDANValueSet
typedef uint8 COM_DT_CF_AVN_DAW_LVDANValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_EVReset
typedef uint8 COM_DT_CF_AVN_EVReset;

#  define Rte_TypeDef_COM_DT_CF_AVN_HBANValueSet
typedef uint8 COM_DT_CF_AVN_HBANValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_HDANValueSet
typedef uint8 COM_DT_CF_AVN_HDANValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_ISLAAutoNValueSet
typedef uint8 COM_DT_CF_AVN_ISLAAutoNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_ISLAOffstNValueSet
typedef uint8 COM_DT_CF_AVN_ISLAOffstNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_ISLWNValueSet
typedef uint8 COM_DT_CF_AVN_ISLWNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_IcyRoadWarn
typedef uint8 COM_DT_CF_AVN_IcyRoadWarn;

#  define Rte_TypeDef_COM_DT_CF_AVN_LKAWrngVolNvalueSet
typedef uint8 COM_DT_CF_AVN_LKAWrngVolNvalueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_NCC_USM_set
typedef uint8 COM_DT_CF_AVN_NCC_USM_set;

#  define Rte_TypeDef_COM_DT_CF_AVN_NSCCCamNValueSet
typedef uint8 COM_DT_CF_AVN_NSCCCamNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_PDWAutoOnNValueSet
typedef uint8 COM_DT_CF_AVN_PDWAutoOnNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_RCCWNValueSet
typedef uint8 COM_DT_CF_AVN_RCCWNValueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_SVMAutoOnNvalueSet
typedef uint8 COM_DT_CF_AVN_SVMAutoOnNvalueSet;

#  define Rte_TypeDef_COM_DT_CF_AVN_UnitReset
typedef uint8 COM_DT_CF_AVN_UnitReset;

#  define Rte_TypeDef_COM_DT_CF_ECU_SSC_STAT
typedef uint8 COM_DT_CF_ECU_SSC_STAT;

#  define Rte_TypeDef_COM_DT_CF_EMS_SSC_Tgt
typedef uint8 COM_DT_CF_EMS_SSC_Tgt;

#  define Rte_TypeDef_COM_DT_CF_HU_GPSFlt
typedef uint8 COM_DT_CF_HU_GPSFlt;

#  define Rte_TypeDef_COM_DT_CLU_AdasDAWResetReq
typedef uint8 COM_DT_CLU_AdasDAWResetReq;

#  define Rte_TypeDef_COM_DT_CLU_DisSpdVal_KPH
typedef uint16 COM_DT_CLU_DisSpdVal_KPH;

#  define Rte_TypeDef_COM_DT_CLU_DtntOutSta
typedef uint8 COM_DT_CLU_DtntOutSta;

#  define Rte_TypeDef_COM_DT_CLU_EngOilChngChkSetReq
typedef uint8 COM_DT_CLU_EngOilChngChkSetReq;

#  define Rte_TypeDef_COM_DT_CLU_ISGoperationTimeRstReq
typedef uint8 COM_DT_CLU_ISGoperationTimeRstReq;

#  define Rte_TypeDef_COM_DT_CLU_IceWrnIndSta
typedef uint8 COM_DT_CLU_IceWrnIndSta;

#  define Rte_TypeDef_COM_DT_CLU_LoFuelWrngSta
typedef uint8 COM_DT_CLU_LoFuelWrngSta;

#  define Rte_TypeDef_COM_DT_CLU_OKSwSta
typedef uint8 COM_DT_CLU_OKSwSta;

#  define Rte_TypeDef_COM_DT_CLU_PwrAutoOffResetReq_HCU
typedef uint8 COM_DT_CLU_PwrAutoOffResetReq_HCU;

#  define Rte_TypeDef_COM_DT_CLU_RefuelDetSta
typedef uint8 COM_DT_CLU_RefuelDetSta;

#  define Rte_TypeDef_COM_DT_CLU_RefuelWrnSta
typedef uint8 COM_DT_CLU_RefuelWrnSta;

#  define Rte_TypeDef_COM_DT_CLU_RhstaLvlSta
typedef uint8 COM_DT_CLU_RhstaLvlSta;

#  define Rte_TypeDef_COM_DT_CLU_SRSWrngLmpSta
typedef uint8 COM_DT_CLU_SRSWrngLmpSta;

#  define Rte_TypeDef_COM_DT_CLU_SWRCCrsMainSwSta
typedef uint8 COM_DT_CLU_SWRCCrsMainSwSta;

#  define Rte_TypeDef_COM_DT_CLU_SWRCLFASwSta
typedef uint8 COM_DT_CLU_SWRCLFASwSta;

#  define Rte_TypeDef_COM_DT_CLU_SWRCSldMainSwSta
typedef uint8 COM_DT_CLU_SWRCSldMainSwSta;

#  define Rte_TypeDef_COM_DT_CLU_TerrainMainSwSta
typedef uint8 COM_DT_CLU_TerrainMainSwSta;

#  define Rte_TypeDef_COM_DT_CLU_TripUnitSta
typedef uint8 COM_DT_CLU_TripUnitSta;

#  define Rte_TypeDef_COM_DT_CSC_WrngSta
typedef uint8 COM_DT_CSC_WrngSta;

#  define Rte_TypeDef_COM_DT_CTM_Exra_EbrakSta
typedef uint8 COM_DT_CTM_Exra_EbrakSta;

#  define Rte_TypeDef_COM_DT_CTM_ExtTailLmpLftOpnSta
typedef uint8 COM_DT_CTM_ExtTailLmpLftOpnSta;

#  define Rte_TypeDef_COM_DT_CTM_ExtTailLmpRtOpnSta
typedef uint8 COM_DT_CTM_ExtTailLmpRtOpnSta;

#  define Rte_TypeDef_COM_DT_CTM_RearfogAct
typedef uint8 COM_DT_CTM_RearfogAct;

#  define Rte_TypeDef_COM_DT_CTM_StpLmpOpnSta
typedef uint8 COM_DT_CTM_StpLmpOpnSta;

#  define Rte_TypeDef_COM_DT_CTM_TrailerAct
typedef uint8 COM_DT_CTM_TrailerAct;

#  define Rte_TypeDef_COM_DT_CTM_TrnSigLmpLftOpnSta
typedef uint8 COM_DT_CTM_TrnSigLmpLftOpnSta;

#  define Rte_TypeDef_COM_DT_CTM_TrnSigLmpRtOpnSta
typedef uint8 COM_DT_CTM_TrnSigLmpRtOpnSta;

#  define Rte_TypeDef_COM_DT_C_MoodLPDrivemodeNValue
typedef uint8 COM_DT_C_MoodLPDrivemodeNValue;

#  define Rte_TypeDef_COM_DT_C_MoodLpDrivingNValue
typedef uint8 COM_DT_C_MoodLpDrivingNValue;

#  define Rte_TypeDef_COM_DT_C_MoodLpFadeNValue
typedef uint8 COM_DT_C_MoodLpFadeNValue;

#  define Rte_TypeDef_COM_DT_C_TeleActiveStatus
typedef uint8 COM_DT_C_TeleActiveStatus;

#  define Rte_TypeDef_COM_DT_C_TempUnit
typedef uint8 COM_DT_C_TempUnit;

#  define Rte_TypeDef_COM_DT_ChildLock_ActnFlSta
typedef uint8 COM_DT_ChildLock_ActnFlSta;

#  define Rte_TypeDef_COM_DT_DAW_LVDA_OptUsmSta
typedef uint8 COM_DT_DAW_LVDA_OptUsmSta;

#  define Rte_TypeDef_COM_DT_DAW_TimeRstReq
typedef uint8 COM_DT_DAW_TimeRstReq;

#  define Rte_TypeDef_COM_DT_DBC_ClusterDis
typedef uint8 COM_DT_DBC_ClusterDis;

#  define Rte_TypeDef_COM_DT_DBC_FuncLmpSta
typedef uint8 COM_DT_DBC_FuncLmpSta;

#  define Rte_TypeDef_COM_DT_DBC_WrngLmpSta
typedef uint8 COM_DT_DBC_WrngLmpSta;

#  define Rte_TypeDef_COM_DT_DCT_CltchState
typedef uint8 COM_DT_DCT_CltchState;

#  define Rte_TypeDef_COM_DT_DCT_EngIdleReq
typedef uint8 COM_DT_DCT_EngIdleReq;

#  define Rte_TypeDef_COM_DT_DCT_EngSpdErrSta
typedef uint8 COM_DT_DCT_EngSpdErrSta;

#  define Rte_TypeDef_COM_DT_DCT_FuelCutReq
typedef uint8 COM_DT_DCT_FuelCutReq;

#  define Rte_TypeDef_COM_DT_DCT_MafErrSta
typedef uint8 COM_DT_DCT_MafErrSta;

#  define Rte_TypeDef_COM_DT_DCT_RegenInhbt
typedef uint8 COM_DT_DCT_RegenInhbt;

#  define Rte_TypeDef_COM_DT_DCT_ShftTqReq
typedef sint16 COM_DT_DCT_ShftTqReq;

#  define Rte_TypeDef_COM_DT_DCT_TqIncReq
typedef uint8 COM_DT_DCT_TqIncReq;

#  define Rte_TypeDef_COM_DT_DMIC_AwdFltSta
typedef uint8 COM_DT_DMIC_AwdFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_DrvMod2Typ
typedef uint8 COM_DT_DMIC_DrvMod2Typ;

#  define Rte_TypeDef_COM_DT_DMIC_DrvModTyp
typedef uint8 COM_DT_DMIC_DrvModTyp;

#  define Rte_TypeDef_COM_DT_DMIC_EcsFltSta
typedef uint8 COM_DT_DMIC_EcsFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_ElsdFltSta
typedef uint8 COM_DT_DMIC_ElsdFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_EngFltSta
typedef uint8 COM_DT_DMIC_EngFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_EscFltSta
typedef uint8 COM_DT_DMIC_EscFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_EsndFltSta
typedef uint8 COM_DT_DMIC_EsndFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndAccSenSta
typedef uint8 COM_DT_DMIC_IndAccSenSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndDecSenSta
typedef uint8 COM_DT_DMIC_IndDecSenSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndMtrPwrSta
typedef uint8 COM_DT_DMIC_IndMtrPwrSta;

#  define Rte_TypeDef_COM_DT_DMIC_IndWhlDrvSta
typedef uint8 COM_DT_DMIC_IndWhlDrvSta;

#  define Rte_TypeDef_COM_DT_DMIC_MdpsFltSta
typedef uint8 COM_DT_DMIC_MdpsFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_PrflFltSta
typedef uint8 COM_DT_DMIC_PrflFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_RevFltSta
typedef uint8 COM_DT_DMIC_RevFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_RwsFltSta
typedef uint8 COM_DT_DMIC_RwsFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_SmtShftModSta
typedef uint8 COM_DT_DMIC_SmtShftModSta;

#  define Rte_TypeDef_COM_DT_DMIC_TmFltSta
typedef uint8 COM_DT_DMIC_TmFltSta;

#  define Rte_TypeDef_COM_DT_DMIC_VcuFltSta
typedef uint8 COM_DT_DMIC_VcuFltSta;

#  define Rte_TypeDef_COM_DT_DSL_GlowCtrlReq
typedef uint8 COM_DT_DSL_GlowCtrlReq;

#  define Rte_TypeDef_COM_DT_DoorLock_AsstDrUnLkSta
typedef uint8 COM_DT_DoorLock_AsstDrUnLkSta;

#  define Rte_TypeDef_COM_DT_DoorLock_DrvKeyLkSwSta
typedef uint8 COM_DT_DoorLock_DrvKeyLkSwSta;

#  define Rte_TypeDef_COM_DT_DoorLock_DrvKeyUnLkSwSta
typedef uint8 COM_DT_DoorLock_DrvKeyUnLkSwSta;

#  define Rte_TypeDef_COM_DT_DoorLock_RrLftDrUnLkSta
typedef uint8 COM_DT_DoorLock_RrLftDrUnLkSta;

#  define Rte_TypeDef_COM_DT_DoorLock_RrRtDrUnLkSta
typedef uint8 COM_DT_DoorLock_RrRtDrUnLkSta;

#  define Rte_TypeDef_COM_DT_ECD_ActvSta
typedef uint8 COM_DT_ECD_ActvSta;

#  define Rte_TypeDef_COM_DT_EMS_SCCIsgEna
typedef uint8 COM_DT_EMS_SCCIsgEna;

#  define Rte_TypeDef_COM_DT_EMS_SafetyFunctSta
typedef uint8 COM_DT_EMS_SafetyFunctSta;

#  define Rte_TypeDef_COM_DT_ENG_48VOpIndiLmpReq
typedef uint8 COM_DT_ENG_48VOpIndiLmpReq;

#  define Rte_TypeDef_COM_DT_ENG_AccDrvAlertDisp
typedef uint8 COM_DT_ENG_AccDrvAlertDisp;

#  define Rte_TypeDef_COM_DT_ENG_Ack4EngStpSta
typedef uint8 COM_DT_ENG_Ack4EngStpSta;

#  define Rte_TypeDef_COM_DT_ENG_BattWrngLmpSta
typedef uint8 COM_DT_ENG_BattWrngLmpSta;

#  define Rte_TypeDef_COM_DT_ENG_CltchOpSta
typedef uint8 COM_DT_ENG_CltchOpSta;

#  define Rte_TypeDef_COM_DT_ENG_DpfWrngSta
typedef uint8 COM_DT_ENG_DpfWrngSta;

#  define Rte_TypeDef_COM_DT_ENG_DsrGearPosDis
typedef uint8 COM_DT_ENG_DsrGearPosDis;

#  define Rte_TypeDef_COM_DT_ENG_EcoDrvActvSta
typedef uint8 COM_DT_ENG_EcoDrvActvSta;

#  define Rte_TypeDef_COM_DT_ENG_EngInhbNCC
typedef uint8 COM_DT_ENG_EngInhbNCC;

#  define Rte_TypeDef_COM_DT_ENG_EngRunSta
typedef uint8 COM_DT_ENG_EngRunSta;

#  define Rte_TypeDef_COM_DT_ENG_EngSpdErrSta
typedef uint8 COM_DT_ENG_EngSpdErrSta;

#  define Rte_TypeDef_COM_DT_ENG_EngSta
typedef uint8 COM_DT_ENG_EngSta;

#  define Rte_TypeDef_COM_DT_ENG_EngTyp1
typedef uint8 COM_DT_ENG_EngTyp1;

#  define Rte_TypeDef_COM_DT_ENG_EngTyp2
typedef uint8 COM_DT_ENG_EngTyp2;

#  define Rte_TypeDef_COM_DT_ENG_EngTyp3
typedef uint8 COM_DT_ENG_EngTyp3;

#  define Rte_TypeDef_COM_DT_ENG_EngTyp4
typedef uint8 COM_DT_ENG_EngTyp4;

#  define Rte_TypeDef_COM_DT_ENG_EtcLmphModSta
typedef uint8 COM_DT_ENG_EtcLmphModSta;

#  define Rte_TypeDef_COM_DT_ENG_FuelCapOpnSta
typedef uint8 COM_DT_ENG_FuelCapOpnSta;

#  define Rte_TypeDef_COM_DT_ENG_FuelCutOffSta
typedef uint8 COM_DT_ENG_FuelCutOffSta;

#  define Rte_TypeDef_COM_DT_ENG_GearShftDnDis
typedef uint8 COM_DT_ENG_GearShftDnDis;

#  define Rte_TypeDef_COM_DT_ENG_GearShftUpDis
typedef uint8 COM_DT_ENG_GearShftUpDis;

#  define Rte_TypeDef_COM_DT_ENG_GlowLmpSta
typedef uint8 COM_DT_ENG_GlowLmpSta;

#  define Rte_TypeDef_COM_DT_ENG_ImmoLmpSta
typedef uint8 COM_DT_ENG_ImmoLmpSta;

#  define Rte_TypeDef_COM_DT_ENG_ImmoSta
typedef uint8 COM_DT_ENG_ImmoSta;

#  define Rte_TypeDef_COM_DT_ENG_IsgBzrReq
typedef uint8 COM_DT_ENG_IsgBzrReq;

#  define Rte_TypeDef_COM_DT_ENG_IsgEquipped
typedef uint8 COM_DT_ENG_IsgEquipped;

#  define Rte_TypeDef_COM_DT_ENG_IsgFuelCnsmptDis
typedef uint8 COM_DT_ENG_IsgFuelCnsmptDis;

#  define Rte_TypeDef_COM_DT_ENG_IsgInhbtLmpSta
typedef uint8 COM_DT_ENG_IsgInhbtLmpSta;

#  define Rte_TypeDef_COM_DT_ENG_LnchCntrlSta
typedef uint8 COM_DT_ENG_LnchCntrlSta;

#  define Rte_TypeDef_COM_DT_ENG_MafErrSta
typedef uint8 COM_DT_ENG_MafErrSta;

#  define Rte_TypeDef_COM_DT_ENG_MilSta
typedef uint8 COM_DT_ENG_MilSta;

#  define Rte_TypeDef_COM_DT_ENG_NCC_STATE
typedef uint8 COM_DT_ENG_NCC_STATE;

#  define Rte_TypeDef_COM_DT_ENG_OilLifeEna
typedef uint8 COM_DT_ENG_OilLifeEna;

#  define Rte_TypeDef_COM_DT_ENG_OilLvlSta
typedef uint8 COM_DT_ENG_OilLvlSta;

#  define Rte_TypeDef_COM_DT_ENG_OilPrsrWrngLmpSta
typedef uint8 COM_DT_ENG_OilPrsrWrngLmpSta;

#  define Rte_TypeDef_COM_DT_ENG_PETyp
typedef uint8 COM_DT_ENG_PETyp;

#  define Rte_TypeDef_COM_DT_ENG_S_F
typedef uint8 COM_DT_ENG_S_F;

#  define Rte_TypeDef_COM_DT_ENG_S_F_GEN
typedef uint8 COM_DT_ENG_S_F_GEN;

#  define Rte_TypeDef_COM_DT_ENG_SldActnSta
typedef uint8 COM_DT_ENG_SldActnSta;

#  define Rte_TypeDef_COM_DT_ENG_SldDrvAlertDisp
typedef uint8 COM_DT_ENG_SldDrvAlertDisp;

#  define Rte_TypeDef_COM_DT_ENG_SoakTimeErrSta
typedef uint8 COM_DT_ENG_SoakTimeErrSta;

#  define Rte_TypeDef_COM_DT_ENG_SpltInjctnSta
typedef uint8 COM_DT_ENG_SpltInjctnSta;

#  define Rte_TypeDef_COM_DT_ENG_TransmsnTyp
typedef uint8 COM_DT_ENG_TransmsnTyp;

#  define Rte_TypeDef_COM_DT_ENG_VehSpdHiVal
typedef uint16 COM_DT_ENG_VehSpdHiVal;

#  define Rte_TypeDef_COM_DT_ENG_VehSpdLimVal
typedef uint16 COM_DT_ENG_VehSpdLimVal;

#  define Rte_TypeDef_COM_DT_EPB_ActvReq
typedef uint8 COM_DT_EPB_ActvReq;

#  define Rte_TypeDef_COM_DT_EPB_AlrmReq
typedef uint8 COM_DT_EPB_AlrmReq;

#  define Rte_TypeDef_COM_DT_EPB_DynmBrkFrcReq
typedef uint8 COM_DT_EPB_DynmBrkFrcReq;

#  define Rte_TypeDef_COM_DT_EPB_EmerModReq
typedef uint8 COM_DT_EPB_EmerModReq;

#  define Rte_TypeDef_COM_DT_EPB_FlSta
typedef uint8 COM_DT_EPB_FlSta;

#  define Rte_TypeDef_COM_DT_EPB_FrcSta
typedef uint8 COM_DT_EPB_FrcSta;

#  define Rte_TypeDef_COM_DT_EPB_StaReq
typedef uint8 COM_DT_EPB_StaReq;

#  define Rte_TypeDef_COM_DT_EPB_SwPosSta
typedef uint8 COM_DT_EPB_SwPosSta;

#  define Rte_TypeDef_COM_DT_ESC_BcaRPlusSta
typedef uint8 COM_DT_ESC_BcaRPlusSta;

#  define Rte_TypeDef_COM_DT_ESC_BrkLtReq
typedef uint8 COM_DT_ESC_BrkLtReq;

#  define Rte_TypeDef_COM_DT_ESC_BrkdFltStndstill
typedef uint8 COM_DT_ESC_BrkdFltStndstill;

#  define Rte_TypeDef_COM_DT_ESC_CylPrsrFlagSta
typedef uint8 COM_DT_ESC_CylPrsrFlagSta;

#  define Rte_TypeDef_COM_DT_ESC_DBS_ActvSta
typedef uint8 COM_DT_ESC_DBS_ActvSta;

#  define Rte_TypeDef_COM_DT_ESC_DclEnblReq
typedef uint8 COM_DT_ESC_DclEnblReq;

#  define Rte_TypeDef_COM_DT_ESC_DrvBrkActvSta
typedef uint8 COM_DT_ESC_DrvBrkActvSta;

#  define Rte_TypeDef_COM_DT_ESC_DrvOvrdSta
typedef uint8 COM_DT_ESC_DrvOvrdSta;

#  define Rte_TypeDef_COM_DT_ESC_FCA_ActvSta
typedef uint8 COM_DT_ESC_FCA_ActvSta;

#  define Rte_TypeDef_COM_DT_ESC_LsdOpn
typedef uint8 COM_DT_ESC_LsdOpn;

#  define Rte_TypeDef_COM_DT_ESC_OffTempSta
typedef uint8 COM_DT_ESC_OffTempSta;

#  define Rte_TypeDef_COM_DT_ESC_PcaSta
typedef uint8 COM_DT_ESC_PcaSta;

#  define Rte_TypeDef_COM_DT_ESC_PrkBrkActvSta
typedef uint8 COM_DT_ESC_PrkBrkActvSta;

#  define Rte_TypeDef_COM_DT_ESC_RccaSta
typedef uint8 COM_DT_ESC_RccaSta;

#  define Rte_TypeDef_COM_DT_ESC_RspaDclActv
typedef uint8 COM_DT_ESC_RspaDclActv;

#  define Rte_TypeDef_COM_DT_ESC_RspaSta
typedef uint8 COM_DT_ESC_RspaSta;

#  define Rte_TypeDef_COM_DT_ESC_SprtLmpSta
typedef uint8 COM_DT_ESC_SprtLmpSta;

#  define Rte_TypeDef_COM_DT_ESC_StdStillVal
typedef uint8 COM_DT_ESC_StdStillVal;

#  define Rte_TypeDef_COM_DT_ESC_VsmActvSta
typedef uint8 COM_DT_ESC_VsmActvSta;

#  define Rte_TypeDef_COM_DT_ESC_VsmDfctvSta
typedef uint8 COM_DT_ESC_VsmDfctvSta;

#  define Rte_TypeDef_COM_DT_ExtLamp_HzrdSwSta
typedef uint8 COM_DT_ExtLamp_HzrdSwSta;

#  define Rte_TypeDef_COM_DT_ExtLamp_TrnSigLmpLftBlnkngSta
typedef uint8 COM_DT_ExtLamp_TrnSigLmpLftBlnkngSta;

#  define Rte_TypeDef_COM_DT_ExtLamp_TrnSigLmpLftSwSta
typedef uint8 COM_DT_ExtLamp_TrnSigLmpLftSwSta;

#  define Rte_TypeDef_COM_DT_ExtLamp_TrnSigLmpRtBlnkngSta
typedef uint8 COM_DT_ExtLamp_TrnSigLmpRtBlnkngSta;

#  define Rte_TypeDef_COM_DT_ExtLamp_TrnSigLmpRtSwSta
typedef uint8 COM_DT_ExtLamp_TrnSigLmpRtSwSta;

#  define Rte_TypeDef_COM_DT_FCA_AvlblSta
typedef uint8 COM_DT_FCA_AvlblSta;

#  define Rte_TypeDef_COM_DT_FCA_ESA_ActvSta
typedef uint8 COM_DT_FCA_ESA_ActvSta;

#  define Rte_TypeDef_COM_DT_FCA_EquipSta
typedef uint8 COM_DT_FCA_EquipSta;

#  define Rte_TypeDef_COM_DT_FCA_Equip_FR_CMR
typedef uint8 COM_DT_FCA_Equip_FR_CMR;

#  define Rte_TypeDef_COM_DT_FCA_Equip_MFC
typedef uint8 COM_DT_FCA_Equip_MFC;

#  define Rte_TypeDef_COM_DT_FCA_FullActvReq
typedef uint8 COM_DT_FCA_FullActvReq;

#  define Rte_TypeDef_COM_DT_FCA_HydrlcBstAsstReq
typedef uint8 COM_DT_FCA_HydrlcBstAsstReq;

#  define Rte_TypeDef_COM_DT_FCA_PartialActvReq
typedef uint8 COM_DT_FCA_PartialActvReq;

#  define Rte_TypeDef_COM_DT_FCA_PrefillActvReq
typedef uint8 COM_DT_FCA_PrefillActvReq;

#  define Rte_TypeDef_COM_DT_FCA_VehStpReq
typedef uint8 COM_DT_FCA_VehStpReq;

#  define Rte_TypeDef_COM_DT_FCA_WrngLvlSta
typedef uint8 COM_DT_FCA_WrngLvlSta;

#  define Rte_TypeDef_COM_DT_FCA_WrngTrgtDis
typedef uint8 COM_DT_FCA_WrngTrgtDis;

#  define Rte_TypeDef_COM_DT_FR_CMR_ACANMonSta
typedef uint8 COM_DT_FR_CMR_ACANMonSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_CodingSta
typedef uint8 COM_DT_FR_CMR_CodingSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_EMTrgtVldSta
typedef uint8 COM_DT_FR_CMR_EMTrgtVldSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_FCAEquipSta
typedef uint8 COM_DT_FR_CMR_FCAEquipSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_MDPSCtrlSta
typedef uint8 COM_DT_FR_CMR_MDPSCtrlSta;

#  define Rte_TypeDef_COM_DT_FR_CMR_SCCEquipSta
typedef uint8 COM_DT_FR_CMR_SCCEquipSta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag01Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag01Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag02Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag02Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag03Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag03Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag04Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag04Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag05Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag05Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag06Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag06Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag07Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag07Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag08Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag08Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag09Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag09Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag10Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag10Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag11Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag11Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag12Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag12Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag13Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag13Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag14Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag14Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag15Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag15Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag16Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag16Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag17Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag17Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag18Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag18Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag19Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag19Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag20Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag20Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag21Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag21Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag22Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag22Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag23Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag23Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag24Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag24Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag25Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag25Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag26Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag26Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag27Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag27Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag28Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag28Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag29Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag29Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag30Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag30Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag31Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag31Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_MvngFlag32Sta
typedef uint8 COM_DT_FR_RDR_Obj_MvngFlag32Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta01Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta01Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta02Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta02Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta03Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta03Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta04Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta04Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta05Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta05Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta06Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta06Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta07Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta07Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta08Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta08Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta09Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta09Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta10Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta10Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta11Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta11Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta12Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta12Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta13Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta13Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta14Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta14Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta15Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta15Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta16Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta16Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta17Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta17Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta18Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta18Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta19Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta19Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta20Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta20Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta21Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta21Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta22Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta22Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta23Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta23Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta24Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta24Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta25Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta25Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta26Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta26Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta27Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta27Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta28Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta28Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta29Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta29Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta30Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta30Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta31Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta31Sta;

#  define Rte_TypeDef_COM_DT_FR_RDR_Obj_TrkSta32Sta
typedef uint8 COM_DT_FR_RDR_Obj_TrkSta32Sta;

#  define Rte_TypeDef_COM_DT_HBA_IndLmpReq
typedef uint8 COM_DT_HBA_IndLmpReq;

#  define Rte_TypeDef_COM_DT_HBA_OptUsmSta
typedef uint8 COM_DT_HBA_OptUsmSta;

#  define Rte_TypeDef_COM_DT_HBA_SysOptSta
typedef uint8 COM_DT_HBA_SysOptSta;

#  define Rte_TypeDef_COM_DT_HCU_AafCtrlReq
typedef uint8 COM_DT_HCU_AafCtrlReq;

#  define Rte_TypeDef_COM_DT_HCU_AcPwrIncSta
typedef uint8 COM_DT_HCU_AcPwrIncSta;

#  define Rte_TypeDef_COM_DT_HCU_AcnOpPrmssnSta
typedef uint8 COM_DT_HCU_AcnOpPrmssnSta;

#  define Rte_TypeDef_COM_DT_HCU_BlwOffReq
typedef uint8 COM_DT_HCU_BlwOffReq;

#  define Rte_TypeDef_COM_DT_HCU_BrkLmpOnReq
typedef uint8 COM_DT_HCU_BrkLmpOnReq;

#  define Rte_TypeDef_COM_DT_HCU_CcCameraOperSta
typedef uint8 COM_DT_HCU_CcCameraOperSta;

#  define Rte_TypeDef_COM_DT_HCU_CcDrvAlrtDis
typedef uint8 COM_DT_HCU_CcDrvAlrtDis;

#  define Rte_TypeDef_COM_DT_HCU_ChrgIncModSta
typedef uint8 COM_DT_HCU_ChrgIncModSta;

#  define Rte_TypeDef_COM_DT_HCU_CrsCtrlOnLmpDis
typedef uint8 COM_DT_HCU_CrsCtrlOnLmpDis;

#  define Rte_TypeDef_COM_DT_HCU_CrsCtrlSetLmpDis
typedef uint8 COM_DT_HCU_CrsCtrlSetLmpDis;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1FriSta
typedef uint8 COM_DT_HCU_DptEnaSet1FriSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1MonSta
typedef uint8 COM_DT_HCU_DptEnaSet1MonSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1SatSta
typedef uint8 COM_DT_HCU_DptEnaSet1SatSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1Sta
typedef uint8 COM_DT_HCU_DptEnaSet1Sta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1SunSta
typedef uint8 COM_DT_HCU_DptEnaSet1SunSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1ThuSta
typedef uint8 COM_DT_HCU_DptEnaSet1ThuSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1TueSta
typedef uint8 COM_DT_HCU_DptEnaSet1TueSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet1WedSta
typedef uint8 COM_DT_HCU_DptEnaSet1WedSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2FriSta
typedef uint8 COM_DT_HCU_DptEnaSet2FriSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2MonSta
typedef uint8 COM_DT_HCU_DptEnaSet2MonSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2SatSta
typedef uint8 COM_DT_HCU_DptEnaSet2SatSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2Sta
typedef uint8 COM_DT_HCU_DptEnaSet2Sta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2ThuSta
typedef uint8 COM_DT_HCU_DptEnaSet2ThuSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2TueSta
typedef uint8 COM_DT_HCU_DptEnaSet2TueSta;

#  define Rte_TypeDef_COM_DT_HCU_DptEnaSet2WedSta
typedef uint8 COM_DT_HCU_DptEnaSet2WedSta;

#  define Rte_TypeDef_COM_DT_HCU_DrvModSta
typedef uint8 COM_DT_HCU_DrvModSta;

#  define Rte_TypeDef_COM_DT_HCU_DucUsrSetCluSta
typedef uint8 COM_DT_HCU_DucUsrSetCluSta;

#  define Rte_TypeDef_COM_DT_HCU_EmissionTestModSta
typedef uint8 COM_DT_HCU_EmissionTestModSta;

#  define Rte_TypeDef_COM_DT_HCU_EstApsSelSta
typedef uint8 COM_DT_HCU_EstApsSelSta;

#  define Rte_TypeDef_COM_DT_HCU_GreenZoneDrvModSta
typedef uint8 COM_DT_HCU_GreenZoneDrvModSta;

#  define Rte_TypeDef_COM_DT_HCU_GreenZoneLmpDis
typedef uint8 COM_DT_HCU_GreenZoneLmpDis;

#  define Rte_TypeDef_COM_DT_HCU_HEVRdyDis
typedef uint8 COM_DT_HCU_HEVRdyDis;

#  define Rte_TypeDef_COM_DT_HCU_HcuRdySta
typedef uint8 COM_DT_HCU_HcuRdySta;

#  define Rte_TypeDef_COM_DT_HCU_HevRdySta
typedef uint8 COM_DT_HCU_HevRdySta;

#  define Rte_TypeDef_COM_DT_HCU_HevSysModSta
typedef uint8 COM_DT_HCU_HevSysModSta;

#  define Rte_TypeDef_COM_DT_HCU_LdcInhbtReq
typedef uint8 COM_DT_HCU_LdcInhbtReq;

#  define Rte_TypeDef_COM_DT_HCU_LdcUnderVoltCtrlSta
typedef uint8 COM_DT_HCU_LdcUnderVoltCtrlSta;

#  define Rte_TypeDef_COM_DT_HCU_LimpOffSta
typedef uint8 COM_DT_HCU_LimpOffSta;

#  define Rte_TypeDef_COM_DT_HCU_MILOnReq
typedef uint8 COM_DT_HCU_MILOnReq;

#  define Rte_TypeDef_COM_DT_HCU_NccAlrmInfoSta
typedef uint8 COM_DT_HCU_NccAlrmInfoSta;

#  define Rte_TypeDef_COM_DT_HCU_PIFailFreezeReq
typedef uint8 COM_DT_HCU_PIFailFreezeReq;

#  define Rte_TypeDef_COM_DT_HCU_PaddleCstCtrlWrnMsgSta
typedef uint8 COM_DT_HCU_PaddleCstCtrlWrnMsgSta;

#  define Rte_TypeDef_COM_DT_HCU_PaddleStepCtrlSta
typedef uint8 COM_DT_HCU_PaddleStepCtrlSta;

#  define Rte_TypeDef_COM_DT_HCU_PhevAutoModOnSta
typedef uint8 COM_DT_HCU_PhevAutoModOnSta;

#  define Rte_TypeDef_COM_DT_HCU_PhevDrvModClusterSta
typedef uint8 COM_DT_HCU_PhevDrvModClusterSta;

#  define Rte_TypeDef_COM_DT_HCU_PreFATCHysTempVal
typedef uint8 COM_DT_HCU_PreFATCHysTempVal;

#  define Rte_TypeDef_COM_DT_HCU_PreFATCOffstTempVal
typedef uint8 COM_DT_HCU_PreFATCOffstTempVal;

#  define Rte_TypeDef_COM_DT_HCU_RspaAlvCntVal
typedef uint8 COM_DT_HCU_RspaAlvCntVal;

#  define Rte_TypeDef_COM_DT_HCU_SccDrvOvrdReq
typedef uint8 COM_DT_HCU_SccDrvOvrdReq;

#  define Rte_TypeDef_COM_DT_HCU_SccEnblSta
typedef uint8 COM_DT_HCU_SccEnblSta;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgEndDayVal
typedef uint8 COM_DT_HCU_SchedChgEndDayVal;

#  define Rte_TypeDef_COM_DT_HCU_SchedChgStrtDayVal
typedef uint8 COM_DT_HCU_SchedChgStrtDayVal;

#  define Rte_TypeDef_COM_DT_HCU_SlwDnSta
typedef uint8 COM_DT_HCU_SlwDnSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_MapEventUsmSta
typedef uint8 COM_DT_HCU_SmartRegen_MapEventUsmSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_OnSta
typedef uint8 COM_DT_HCU_SmartRegen_OnSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_UsmSta
typedef uint8 COM_DT_HCU_SmartRegen_UsmSta;

#  define Rte_TypeDef_COM_DT_HCU_SmartRegen_VehHoldSta
typedef uint8 COM_DT_HCU_SmartRegen_VehHoldSta;

#  define Rte_TypeDef_COM_DT_HCU_SmrtEcoGdDis
typedef uint8 COM_DT_HCU_SmrtEcoGdDis;

#  define Rte_TypeDef_COM_DT_HCU_SpdLimDeviceOperSta
typedef uint8 COM_DT_HCU_SpdLimDeviceOperSta;

#  define Rte_TypeDef_COM_DT_HCU_SrvLmpDis
typedef uint8 COM_DT_HCU_SrvLmpDis;

#  define Rte_TypeDef_COM_DT_HCU_SrvModSta
typedef uint8 COM_DT_HCU_SrvModSta;

#  define Rte_TypeDef_COM_DT_HCU_StrtInhbt2Sta
typedef uint8 COM_DT_HCU_StrtInhbt2Sta;

#  define Rte_TypeDef_COM_DT_HCU_StrtInhbtSta
typedef uint8 COM_DT_HCU_StrtInhbtSta;

#  define Rte_TypeDef_COM_DT_HCU_SysShtOffReq
typedef uint8 COM_DT_HCU_SysShtOffReq;

#  define Rte_TypeDef_COM_DT_HCU_VehStrtEnblSta
typedef uint8 COM_DT_HCU_VehStrtEnblSta;

#  define Rte_TypeDef_COM_DT_HDA_CntrlModSta
typedef uint8 COM_DT_HDA_CntrlModSta;

#  define Rte_TypeDef_COM_DT_HDA_LFA_SymSta
typedef uint8 COM_DT_HDA_LFA_SymSta;

#  define Rte_TypeDef_COM_DT_HDA_LFA_WrnSnd
typedef uint8 COM_DT_HDA_LFA_WrnSnd;

#  define Rte_TypeDef_COM_DT_HDCT_AcnChrgInhbtReq
typedef uint8 COM_DT_HDCT_AcnChrgInhbtReq;

#  define Rte_TypeDef_COM_DT_HDCT_CLUEngSpdFlag
typedef uint8 COM_DT_HDCT_CLUEngSpdFlag;

#  define Rte_TypeDef_COM_DT_HDCT_CltchSta
typedef uint8 COM_DT_HDCT_CltchSta;

#  define Rte_TypeDef_COM_DT_HDCT_CtrlablSta
typedef uint8 COM_DT_HDCT_CtrlablSta;

#  define Rte_TypeDef_COM_DT_HDCT_CurrPrgrm
typedef uint8 COM_DT_HDCT_CurrPrgrm;

#  define Rte_TypeDef_COM_DT_HDCT_DblCltchSta
typedef uint8 COM_DT_HDCT_DblCltchSta;

#  define Rte_TypeDef_COM_DT_HDCT_EOLReq
typedef uint8 COM_DT_HDCT_EOLReq;

#  define Rte_TypeDef_COM_DT_HDCT_EngCltchLmphmMod
typedef uint8 COM_DT_HDCT_EngCltchLmphmMod;

#  define Rte_TypeDef_COM_DT_HDCT_FuelCutReq
typedef uint8 COM_DT_HDCT_FuelCutReq;

#  define Rte_TypeDef_COM_DT_HDCT_GSITrgtGear
typedef uint8 COM_DT_HDCT_GSITrgtGear;

#  define Rte_TypeDef_COM_DT_HDCT_GearShftSta
typedef uint8 COM_DT_HDCT_GearShftSta;

#  define Rte_TypeDef_COM_DT_HDCT_MCUAntJrkInhbt
typedef uint8 COM_DT_HDCT_MCUAntJrkInhbt;

#  define Rte_TypeDef_COM_DT_HDCT_NCoastDnReq
typedef uint8 COM_DT_HDCT_NCoastDnReq;

#  define Rte_TypeDef_COM_DT_HDCT_NCoastTrgtGear
typedef uint8 COM_DT_HDCT_NCoastTrgtGear;

#  define Rte_TypeDef_COM_DT_HDCT_NetrlCtrlSta
typedef uint8 COM_DT_HDCT_NetrlCtrlSta;

#  define Rte_TypeDef_COM_DT_HDCT_OBDErrSta
typedef uint8 COM_DT_HDCT_OBDErrSta;

#  define Rte_TypeDef_COM_DT_HDCT_ShftPhase
typedef uint8 COM_DT_HDCT_ShftPhase;

#  define Rte_TypeDef_COM_DT_HDCT_StcShftLrchCtrl
typedef uint8 COM_DT_HDCT_StcShftLrchCtrl;

#  define Rte_TypeDef_COM_DT_HDCT_TCURdySta
typedef uint8 COM_DT_HDCT_TCURdySta;

#  define Rte_TypeDef_COM_DT_HDCT_TqIncReq
typedef uint8 COM_DT_HDCT_TqIncReq;

#  define Rte_TypeDef_COM_DT_HDCT_TrgtShftCls
typedef uint8 COM_DT_HDCT_TrgtShftCls;

#  define Rte_TypeDef_COM_DT_HDP_FailureMode
typedef uint8 COM_DT_HDP_FailureMode;

#  define Rte_TypeDef_COM_DT_HEV_DrvCycActSta
typedef uint8 COM_DT_HEV_DrvCycActSta;

#  define Rte_TypeDef_COM_DT_HEV_EngFulLoadSta
typedef uint8 COM_DT_HEV_EngFulLoadSta;

#  define Rte_TypeDef_COM_DT_HEV_EngOpSta
typedef uint8 COM_DT_HEV_EngOpSta;

#  define Rte_TypeDef_COM_DT_HEV_EngSpdErrSta
typedef uint8 COM_DT_HEV_EngSpdErrSta;

#  define Rte_TypeDef_COM_DT_HEV_EtcAppSta
typedef uint8 COM_DT_HEV_EtcAppSta;

#  define Rte_TypeDef_COM_DT_HEV_FirstFiringSta
typedef uint8 COM_DT_HEV_FirstFiringSta;

#  define Rte_TypeDef_COM_DT_HEV_FuelCutOffInhbtSta
typedef uint8 COM_DT_HEV_FuelCutOffInhbtSta;

#  define Rte_TypeDef_COM_DT_HEV_FuelCutOffSta
typedef uint8 COM_DT_HEV_FuelCutOffSta;

#  define Rte_TypeDef_COM_DT_HEV_GPF_WrnLamp
typedef uint8 COM_DT_HEV_GPF_WrnLamp;

#  define Rte_TypeDef_COM_DT_HEV_O2SnsrPreHeatSta
typedef uint8 COM_DT_HEV_O2SnsrPreHeatSta;

#  define Rte_TypeDef_COM_DT_HEV_RbmDrvCycSta
typedef uint8 COM_DT_HEV_RbmDrvCycSta;

#  define Rte_TypeDef_COM_DT_HEV_VehSpdVal
typedef uint8 COM_DT_HEV_VehSpdVal;

#  define Rte_TypeDef_COM_DT_HEV_WarmupCycSta
typedef uint8 COM_DT_HEV_WarmupCycSta;

#  define Rte_TypeDef_COM_DT_HTCU_CtrlablSta
typedef uint8 COM_DT_HTCU_CtrlablSta;

#  define Rte_TypeDef_COM_DT_HTCU_FanCtrlReq
typedef uint8 COM_DT_HTCU_FanCtrlReq;

#  define Rte_TypeDef_COM_DT_HTCU_FsCltchLmphmActvSta
typedef uint8 COM_DT_HTCU_FsCltchLmphmActvSta;

#  define Rte_TypeDef_COM_DT_HTCU_GearChgSta
typedef uint8 COM_DT_HTCU_GearChgSta;

#  define Rte_TypeDef_COM_DT_HTCU_GearShftDnDisGSI
typedef uint8 COM_DT_HTCU_GearShftDnDisGSI;

#  define Rte_TypeDef_COM_DT_HTCU_GearShftUpDisGSI
typedef uint8 COM_DT_HTCU_GearShftUpDisGSI;

#  define Rte_TypeDef_COM_DT_HTCU_PrgrmSta
typedef uint8 COM_DT_HTCU_PrgrmSta;

#  define Rte_TypeDef_COM_DT_HTCU_RapidKDReq
typedef uint8 COM_DT_HTCU_RapidKDReq;

#  define Rte_TypeDef_COM_DT_HTCU_RdySta
typedef uint8 COM_DT_HTCU_RdySta;

#  define Rte_TypeDef_COM_DT_HTCU_SolBSta
typedef uint8 COM_DT_HTCU_SolBSta;

#  define Rte_TypeDef_COM_DT_HTCU_TrgtGearStaGSI
typedef uint8 COM_DT_HTCU_TrgtGearStaGSI;

#  define Rte_TypeDef_COM_DT_HU_AliveStatus
typedef uint8 COM_DT_HU_AliveStatus;

#  define Rte_TypeDef_COM_DT_HU_DayNightState
typedef uint8 COM_DT_HU_DayNightState;

#  define Rte_TypeDef_COM_DT_HU_DistanceUnit
typedef uint8 COM_DT_HU_DistanceUnit;

#  define Rte_TypeDef_COM_DT_HU_EVSupport
typedef uint8 COM_DT_HU_EVSupport;

#  define Rte_TypeDef_COM_DT_HU_MicActivity
typedef uint8 COM_DT_HU_MicActivity;

#  define Rte_TypeDef_COM_DT_HU_MuteStatus
typedef uint8 COM_DT_HU_MuteStatus;

#  define Rte_TypeDef_COM_DT_HU_NaviDisp
typedef uint8 COM_DT_HU_NaviDisp;

#  define Rte_TypeDef_COM_DT_HU_NaviHandshakingSupport
typedef uint8 COM_DT_HU_NaviHandshakingSupport;

#  define Rte_TypeDef_COM_DT_HU_NaviMapInfo
typedef uint8 COM_DT_HU_NaviMapInfo;

#  define Rte_TypeDef_COM_DT_HU_NaviStatus
typedef uint8 COM_DT_HU_NaviStatus;

#  define Rte_TypeDef_COM_DT_HU_OptionInfo
typedef uint16 COM_DT_HU_OptionInfo;

#  define Rte_TypeDef_COM_DT_HU_RTCCheck
typedef uint8 COM_DT_HU_RTCCheck;

#  define Rte_TypeDef_COM_DT_HU_UsmSupport
typedef uint8 COM_DT_HU_UsmSupport;

#  define Rte_TypeDef_COM_DT_HU_VolumeStatus
typedef uint8 COM_DT_HU_VolumeStatus;

#  define Rte_TypeDef_COM_DT_HU_WelcomeReady
typedef uint8 COM_DT_HU_WelcomeReady;

#  define Rte_TypeDef_COM_DT_Haptic_USMCurState_OnOff
typedef uint8 COM_DT_Haptic_USMCurState_OnOff;

#  define Rte_TypeDef_COM_DT_HazardFromHUSVM
typedef uint8 COM_DT_HazardFromHUSVM;

#  define Rte_TypeDef_COM_DT_IAU_DigitalKeyEnblRVal
typedef uint8 COM_DT_IAU_DigitalKeyEnblRVal;

#  define Rte_TypeDef_COM_DT_IAU_NFCCard1RegRVal
typedef uint8 COM_DT_IAU_NFCCard1RegRVal;

#  define Rte_TypeDef_COM_DT_IAU_NFCCard2RegRVal
typedef uint8 COM_DT_IAU_NFCCard2RegRVal;

#  define Rte_TypeDef_COM_DT_IAU_OwnerPhnRegRVal
typedef uint8 COM_DT_IAU_OwnerPhnRegRVal;

#  define Rte_TypeDef_COM_DT_IAUwFPMLearnState
typedef uint8 COM_DT_IAUwFPMLearnState;

#  define Rte_TypeDef_COM_DT_IAUwFRULearnState
typedef uint8 COM_DT_IAUwFRULearnState;

#  define Rte_TypeDef_COM_DT_ICC_ActivityStat
typedef uint8 COM_DT_ICC_ActivityStat;

#  define Rte_TypeDef_COM_DT_ICC_AoIStat
typedef uint8 COM_DT_ICC_AoIStat;

#  define Rte_TypeDef_COM_DT_ICC_CamBlckdStat
typedef uint8 COM_DT_ICC_CamBlckdStat;

#  define Rte_TypeDef_COM_DT_ICC_CamFailStat
typedef uint8 COM_DT_ICC_CamFailStat;

#  define Rte_TypeDef_COM_DT_ICC_DistLvlStat
typedef uint8 COM_DT_ICC_DistLvlStat;

#  define Rte_TypeDef_COM_DT_ICC_DrwsLvlStat
typedef uint8 COM_DT_ICC_DrwsLvlStat;

#  define Rte_TypeDef_COM_DT_ICC_EcuFailStat
typedef uint8 COM_DT_ICC_EcuFailStat;

#  define Rte_TypeDef_COM_DT_ICC_EyeStat
typedef uint8 COM_DT_ICC_EyeStat;

#  define Rte_TypeDef_COM_DT_ICC_FaceDetectStat
typedef uint8 COM_DT_ICC_FaceDetectStat;

#  define Rte_TypeDef_COM_DT_ICC_FaceFakeStat
typedef uint8 COM_DT_ICC_FaceFakeStat;

#  define Rte_TypeDef_COM_DT_ICC_IntvDrwsLvlStat
typedef uint8 COM_DT_ICC_IntvDrwsLvlStat;

#  define Rte_TypeDef_COM_DT_ICC_LeftEyeOpenStat
typedef uint8 COM_DT_ICC_LeftEyeOpenStat;

#  define Rte_TypeDef_COM_DT_ICC_OptUsmStat
typedef uint8 COM_DT_ICC_OptUsmStat;

#  define Rte_TypeDef_COM_DT_ICC_ProfilingStat
typedef uint8 COM_DT_ICC_ProfilingStat;

#  define Rte_TypeDef_COM_DT_ICC_RightEyeOpenStat
typedef uint8 COM_DT_ICC_RightEyeOpenStat;

#  define Rte_TypeDef_COM_DT_ICC_SymStat
typedef uint8 COM_DT_ICC_SymStat;

#  define Rte_TypeDef_COM_DT_ICC_TalkStat
typedef uint8 COM_DT_ICC_TalkStat;

#  define Rte_TypeDef_COM_DT_ICC_UpdateStat
typedef uint8 COM_DT_ICC_UpdateStat;

#  define Rte_TypeDef_COM_DT_ICC_WarningStat
typedef uint8 COM_DT_ICC_WarningStat;

#  define Rte_TypeDef_COM_DT_ICC_YawnStat
typedef uint8 COM_DT_ICC_YawnStat;

#  define Rte_TypeDef_COM_DT_ICU_HDPSpprtRdy
typedef uint8 COM_DT_ICU_HDPSpprtRdy;

#  define Rte_TypeDef_COM_DT_ICU_Haptic_OPT
typedef uint8 COM_DT_ICU_Haptic_OPT;

#  define Rte_TypeDef_COM_DT_ICU_MtGearPosRSta
typedef uint8 COM_DT_ICU_MtGearPosRSta;

#  define Rte_TypeDef_COM_DT_IEB_AbsNGearReq
typedef uint8 COM_DT_IEB_AbsNGearReq;

#  define Rte_TypeDef_COM_DT_IEB_BzrSta
typedef uint8 COM_DT_IEB_BzrSta;

#  define Rte_TypeDef_COM_DT_IEB_DfctvSta
typedef uint8 COM_DT_IEB_DfctvSta;

#  define Rte_TypeDef_COM_DT_IEB_DiagSta
typedef uint8 COM_DT_IEB_DiagSta;

#  define Rte_TypeDef_COM_DT_IEB_DriftModeActSta
typedef uint8 COM_DT_IEB_DriftModeActSta;

#  define Rte_TypeDef_COM_DT_IEB_DriftModeSta
typedef uint8 COM_DT_IEB_DriftModeSta;

#  define Rte_TypeDef_COM_DT_IEB_EstBrkPdlValVldSta
typedef uint8 COM_DT_IEB_EstBrkPdlValVldSta;

#  define Rte_TypeDef_COM_DT_IEB_InhbtTrnstnTo4wd_Req
typedef uint8 COM_DT_IEB_InhbtTrnstnTo4wd_Req;

#  define Rte_TypeDef_COM_DT_IEB_MILReq
typedef uint8 COM_DT_IEB_MILReq;

#  define Rte_TypeDef_COM_DT_IEB_PdlCalibSta
typedef uint8 COM_DT_IEB_PdlCalibSta;

#  define Rte_TypeDef_COM_DT_IEB_PdlTrvlSnsrFailSta
typedef uint8 COM_DT_IEB_PdlTrvlSnsrFailSta;

#  define Rte_TypeDef_COM_DT_IEB_RSC_Req
typedef uint8 COM_DT_IEB_RSC_Req;

#  define Rte_TypeDef_COM_DT_IEB_RbsWrngLmpSta
typedef uint8 COM_DT_IEB_RbsWrngLmpSta;

#  define Rte_TypeDef_COM_DT_IEB_SnsrFailSta
typedef uint8 COM_DT_IEB_SnsrFailSta;

#  define Rte_TypeDef_COM_DT_IEB_VacSysDfctvSta
typedef uint8 COM_DT_IEB_VacSysDfctvSta;

#  define Rte_TypeDef_COM_DT_IEB_WrngLmpDis
typedef uint8 COM_DT_IEB_WrngLmpDis;

#  define Rte_TypeDef_COM_DT_IFSref_FR_CMR_Sta
typedef uint8 COM_DT_IFSref_FR_CMR_Sta;

#  define Rte_TypeDef_COM_DT_IFSref_ILLAmbtSta
typedef uint8 COM_DT_IFSref_ILLAmbtSta;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst10Val
typedef uint8 COM_DT_IFSref_VehDst10Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst1Val
typedef uint8 COM_DT_IFSref_VehDst1Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst2Val
typedef uint8 COM_DT_IFSref_VehDst2Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst3Val
typedef uint8 COM_DT_IFSref_VehDst3Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst4Val
typedef uint8 COM_DT_IFSref_VehDst4Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst5Val
typedef uint8 COM_DT_IFSref_VehDst5Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst6Val
typedef uint8 COM_DT_IFSref_VehDst6Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst7Val
typedef uint8 COM_DT_IFSref_VehDst7Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst8Val
typedef uint8 COM_DT_IFSref_VehDst8Val;

#  define Rte_TypeDef_COM_DT_IFSref_VehDst9Val
typedef uint8 COM_DT_IFSref_VehDst9Val;

#  define Rte_TypeDef_COM_DT_IMT_DisCmd
typedef uint8 COM_DT_IMT_DisCmd;

#  define Rte_TypeDef_COM_DT_ISLA_AutoSetSpdSta
typedef uint8 COM_DT_ISLA_AutoSetSpdSta;

#  define Rte_TypeDef_COM_DT_ISLA_AutoUsmSta
typedef uint8 COM_DT_ISLA_AutoUsmSta;

#  define Rte_TypeDef_COM_DT_ISLA_NAOffstUSMSta
typedef uint8 COM_DT_ISLA_NAOffstUSMSta;

#  define Rte_TypeDef_COM_DT_ISLA_OffstUsmSta
typedef uint8 COM_DT_ISLA_OffstUsmSta;

#  define Rte_TypeDef_COM_DT_ISLA_TSRSpdLimEnfrcmtSta
typedef uint8 COM_DT_ISLA_TSRSpdLimEnfrcmtSta;

#  define Rte_TypeDef_COM_DT_ISLW_OptUsmSta
typedef uint8 COM_DT_ISLW_OptUsmSta;

#  define Rte_TypeDef_COM_DT_ISLW_OvrlpSignDis
typedef uint8 COM_DT_ISLW_OvrlpSignDis;

#  define Rte_TypeDef_COM_DT_ISLW_SysSta
typedef uint8 COM_DT_ISLW_SysSta;

#  define Rte_TypeDef_COM_DT_Info_LftLnDptSta
typedef uint8 COM_DT_Info_LftLnDptSta;

#  define Rte_TypeDef_COM_DT_Info_LtLnDptSta
typedef uint8 COM_DT_Info_LtLnDptSta;

#  define Rte_TypeDef_COM_DT_Info_RtLnDptSta
typedef uint8 COM_DT_Info_RtLnDptSta;

#  define Rte_TypeDef_COM_DT_IntLamp_InlTailLmpSta
typedef uint8 COM_DT_IntLamp_InlTailLmpSta;

#  define Rte_TypeDef_COM_DT_LKA_OnOffEquip2Sta
typedef uint8 COM_DT_LKA_OnOffEquip2Sta;

#  define Rte_TypeDef_COM_DT_LKA_SysIndReq
typedef uint8 COM_DT_LKA_SysIndReq;

#  define Rte_TypeDef_COM_DT_LKA_UsmMod
typedef uint8 COM_DT_LKA_UsmMod;

#  define Rte_TypeDef_COM_DT_LKA_WarnSndUSMSta
typedef uint8 COM_DT_LKA_WarnSndUSMSta;

#  define Rte_TypeDef_COM_DT_Lamp_AvTailLmpSta
typedef uint8 COM_DT_Lamp_AvTailLmpSta;

#  define Rte_TypeDef_COM_DT_Lamp_BLEWlcmCmd
typedef uint8 COM_DT_Lamp_BLEWlcmCmd;

#  define Rte_TypeDef_COM_DT_Lamp_BckUpLmpCmd
typedef uint8 COM_DT_Lamp_BckUpLmpCmd;

#  define Rte_TypeDef_COM_DT_Lamp_CornerLmpLftOnReq
typedef uint8 COM_DT_Lamp_CornerLmpLftOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_CornerLmpRtOnReq
typedef uint8 COM_DT_Lamp_CornerLmpRtOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_DrlOnReq
typedef uint8 COM_DT_Lamp_DrlOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_ExtLampRSPAMode
typedef uint8 COM_DT_Lamp_ExtLampRSPAMode;

#  define Rte_TypeDef_COM_DT_Lamp_ExtrnlTailLmpOnReq
typedef uint8 COM_DT_Lamp_ExtrnlTailLmpOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_FrFogLmpOnReq
typedef uint8 COM_DT_Lamp_FrFogLmpOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_FrFogLmpSwSta
typedef uint8 COM_DT_Lamp_FrFogLmpSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_HdLmpHiOnReq
typedef uint8 COM_DT_Lamp_HdLmpHiOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_HdLmpHiSta
typedef uint8 COM_DT_Lamp_HdLmpHiSta;

#  define Rte_TypeDef_COM_DT_Lamp_HdLmpHiSwSta
typedef uint8 COM_DT_Lamp_HdLmpHiSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_HdLmpLoOnReq
typedef uint8 COM_DT_Lamp_HdLmpLoOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_HdLmpWlcmCmd
typedef uint8 COM_DT_Lamp_HdLmpWlcmCmd;

#  define Rte_TypeDef_COM_DT_Lamp_HiPrioHzrdReq
typedef uint8 COM_DT_Lamp_HiPrioHzrdReq;

#  define Rte_TypeDef_COM_DT_Lamp_IntTailLmpOnReq
typedef uint8 COM_DT_Lamp_IntTailLmpOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_LaneChgTrnSigLftSwSta
typedef uint8 COM_DT_Lamp_LaneChgTrnSigLftSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_LaneChgTrnSigLftSwSta_ICU
typedef uint8 COM_DT_Lamp_LaneChgTrnSigLftSwSta_ICU;

#  define Rte_TypeDef_COM_DT_Lamp_LaneChgTrnSigRtSwSta
typedef uint8 COM_DT_Lamp_LaneChgTrnSigRtSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_LaneChgTrnSigRtSwSta_ICU
typedef uint8 COM_DT_Lamp_LaneChgTrnSigRtSwSta_ICU;

#  define Rte_TypeDef_COM_DT_Lamp_LoPrioHzrdReq
typedef uint8 COM_DT_Lamp_LoPrioHzrdReq;

#  define Rte_TypeDef_COM_DT_Lamp_LtSwSta
typedef uint8 COM_DT_Lamp_LtSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_PassingLmpSwSta
typedef uint8 COM_DT_Lamp_PassingLmpSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_PuddleLmpOnReq
typedef uint8 COM_DT_Lamp_PuddleLmpOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_RrFogLmpOnReq
typedef uint8 COM_DT_Lamp_RrFogLmpOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_RrFogLmpSwSta
typedef uint8 COM_DT_Lamp_RrFogLmpSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_StcBendingLmpLftOnReq
typedef uint8 COM_DT_Lamp_StcBendingLmpLftOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_StcBendingLmpRtOnReq
typedef uint8 COM_DT_Lamp_StcBendingLmpRtOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigLftSwSta
typedef uint8 COM_DT_Lamp_TrnSigLftSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigLmpLftActiveSt
typedef uint8 COM_DT_Lamp_TrnSigLmpLftActiveSt;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigLmpLftOnReq
typedef uint8 COM_DT_Lamp_TrnSigLmpLftOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigLmpRtActiveSt
typedef uint8 COM_DT_Lamp_TrnSigLmpRtActiveSt;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigLmpRtOnReq
typedef uint8 COM_DT_Lamp_TrnSigLmpRtOnReq;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigRtSwSta
typedef uint8 COM_DT_Lamp_TrnSigRtSwSta;

#  define Rte_TypeDef_COM_DT_Lamp_TrnSigSwNtrlSta
typedef uint8 COM_DT_Lamp_TrnSigSwNtrlSta;

#  define Rte_TypeDef_COM_DT_MDPS_ADAS_AciFltSig
typedef uint8 COM_DT_MDPS_ADAS_AciFltSig;

#  define Rte_TypeDef_COM_DT_MDPS_CurrModVal
typedef uint8 COM_DT_MDPS_CurrModVal;

#  define Rte_TypeDef_COM_DT_MDPS_EngIdleRpmReq
typedef uint8 COM_DT_MDPS_EngIdleRpmReq;

#  define Rte_TypeDef_COM_DT_MDPS_LkaFailSta
typedef uint8 COM_DT_MDPS_LkaFailSta;

#  define Rte_TypeDef_COM_DT_MDPS_LkaToiActvSta
typedef uint8 COM_DT_MDPS_LkaToiActvSta;

#  define Rte_TypeDef_COM_DT_MDPS_LkaToiFltSta
typedef uint8 COM_DT_MDPS_LkaToiFltSta;

#  define Rte_TypeDef_COM_DT_MDPS_LkaToiUnblSta
typedef uint8 COM_DT_MDPS_LkaToiUnblSta;

#  define Rte_TypeDef_COM_DT_MDPS_LoamModSta
typedef uint8 COM_DT_MDPS_LoamModSta;

#  define Rte_TypeDef_COM_DT_MDPS_PaCanfltSta
typedef uint8 COM_DT_MDPS_PaCanfltSta;

#  define Rte_TypeDef_COM_DT_MDPS_Typ
typedef uint8 COM_DT_MDPS_Typ;

#  define Rte_TypeDef_COM_DT_MDPS_VsmActResp
typedef uint8 COM_DT_MDPS_VsmActResp;

#  define Rte_TypeDef_COM_DT_MDPS_VsmDfctvSta
typedef uint8 COM_DT_MDPS_VsmDfctvSta;

#  define Rte_TypeDef_COM_DT_MDPS_VsmSigErrSta
typedef uint8 COM_DT_MDPS_VsmSigErrSta;

#  define Rte_TypeDef_COM_DT_META_V2_3_Country_OptADAS
typedef uint8 COM_DT_META_V2_3_Country_OptADAS;

#  define Rte_TypeDef_COM_DT_META_V2_3_DrivingSide
typedef uint8 COM_DT_META_V2_3_DrivingSide;

#  define Rte_TypeDef_COM_DT_META_V2_3_MapProvider
typedef uint8 COM_DT_META_V2_3_MapProvider;

#  define Rte_TypeDef_COM_DT_META_V2_3_SpeedUnit
typedef uint8 COM_DT_META_V2_3_SpeedUnit;

#  define Rte_TypeDef_COM_DT_META_V2_Country_OptADAS
typedef uint8 COM_DT_META_V2_Country_OptADAS;

#  define Rte_TypeDef_COM_DT_MSR_FuncReq
typedef uint8 COM_DT_MSR_FuncReq;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_Frwinfo
typedef uint8 COM_DT_Navi_ISLW_Frwinfo;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_LinkClass
typedef uint8 COM_DT_Navi_ISLW_LinkClass;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_SpdUnit
typedef uint8 COM_DT_Navi_ISLW_SpdUnit;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_TollExist
typedef uint8 COM_DT_Navi_ISLW_TollExist;

#  define Rte_TypeDef_COM_DT_Navi_ISLW_TunnelExist
typedef uint8 COM_DT_Navi_ISLW_TunnelExist;

#  define Rte_TypeDef_COM_DT_OMUOSMirCtrl
typedef uint8 COM_DT_OMUOSMirCtrl;

#  define Rte_TypeDef_COM_DT_OTAUIStatus
typedef uint8 COM_DT_OTAUIStatus;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrAltitude100m
typedef uint8 COM_DT_POS_V2_3_CurrAltitude100m;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrFuncRoadClass
typedef uint8 COM_DT_POS_V2_3_CurrFuncRoadClass;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrSpeedLimit
typedef uint8 COM_DT_POS_V2_3_CurrSpeedLimit;

#  define Rte_TypeDef_COM_DT_POS_V2_3_CurrTrafficSpeed
typedef uint8 COM_DT_POS_V2_3_CurrTrafficSpeed;

#  define Rte_TypeDef_COM_DT_PROLONG_V2_3_Update
typedef uint8 COM_DT_PROLONG_V2_3_Update;

#  define Rte_TypeDef_COM_DT_PRVECS_CodedSta
typedef uint8 COM_DT_PRVECS_CodedSta;

#  define Rte_TypeDef_COM_DT_PWI_STATE
typedef uint8 COM_DT_PWI_STATE;

#  define Rte_TypeDef_COM_DT_RSPA_AddtnlAccelActv
typedef uint8 COM_DT_RSPA_AddtnlAccelActv;

#  define Rte_TypeDef_COM_DT_RSPA_CrankingReq
typedef uint8 COM_DT_RSPA_CrankingReq;

#  define Rte_TypeDef_COM_DT_RSPA_DccCmd
typedef uint8 COM_DT_RSPA_DccCmd;

#  define Rte_TypeDef_COM_DT_RSPA_EpbReq
typedef uint8 COM_DT_RSPA_EpbReq;

#  define Rte_TypeDef_COM_DT_RSPA_HdLmpReq
typedef uint8 COM_DT_RSPA_HdLmpReq;

#  define Rte_TypeDef_COM_DT_RSPA_IdOutWarnReq
typedef uint8 COM_DT_RSPA_IdOutWarnReq;

#  define Rte_TypeDef_COM_DT_RSPA_LwrLtTypDis
typedef uint8 COM_DT_RSPA_LwrLtTypDis;

#  define Rte_TypeDef_COM_DT_RSPA_LwrRtTypDis
typedef uint8 COM_DT_RSPA_LwrRtTypDis;

#  define Rte_TypeDef_COM_DT_RSPA_OSMirFoldReq
typedef uint8 COM_DT_RSPA_OSMirFoldReq;

#  define Rte_TypeDef_COM_DT_RSPA_Opt
typedef uint8 COM_DT_RSPA_Opt;

#  define Rte_TypeDef_COM_DT_RSPA_SelDevInfo
typedef uint8 COM_DT_RSPA_SelDevInfo;

#  define Rte_TypeDef_COM_DT_RSPA_Sta
typedef uint8 COM_DT_RSPA_Sta;

#  define Rte_TypeDef_COM_DT_RSPA_StopReq
typedef uint8 COM_DT_RSPA_StopReq;

#  define Rte_TypeDef_COM_DT_RSPA_TrgtGearSta
typedef uint8 COM_DT_RSPA_TrgtGearSta;

#  define Rte_TypeDef_COM_DT_RSPA_UppLtTypDis
typedef uint8 COM_DT_RSPA_UppLtTypDis;

#  define Rte_TypeDef_COM_DT_RSPA_UppRtTypDis
typedef uint8 COM_DT_RSPA_UppRtTypDis;

#  define Rte_TypeDef_COM_DT_SCC_BrkLtSwFlrDetSta
typedef uint8 COM_DT_SCC_BrkLtSwFlrDetSta;

#  define Rte_TypeDef_COM_DT_SCC_Char1Sta
typedef uint8 COM_DT_SCC_Char1Sta;

#  define Rte_TypeDef_COM_DT_SCC_Char3Sta
typedef uint8 COM_DT_SCC_Char3Sta;

#  define Rte_TypeDef_COM_DT_SCC_DrvOvrRidSta
typedef uint8 COM_DT_SCC_DrvOvrRidSta;

#  define Rte_TypeDef_COM_DT_SCC_FuncFlrDetSta
typedef uint8 COM_DT_SCC_FuncFlrDetSta;

#  define Rte_TypeDef_COM_DT_SCC_ML_OnOffEquipSta
typedef uint8 COM_DT_SCC_ML_OnOffEquipSta;

#  define Rte_TypeDef_COM_DT_SCC_MainOnOffSta
typedef uint8 COM_DT_SCC_MainOnOffSta;

#  define Rte_TypeDef_COM_DT_SCC_NSCCAutoSetSpdSta
typedef uint8 COM_DT_SCC_NSCCAutoSetSpdSta;

#  define Rte_TypeDef_COM_DT_SCC_NSCCAutoSetSpdUpdtSta
typedef uint8 COM_DT_SCC_NSCCAutoSetSpdUpdtSta;

#  define Rte_TypeDef_COM_DT_SCC_NSCCOnOffSta
typedef uint8 COM_DT_SCC_NSCCOnOffSta;

#  define Rte_TypeDef_COM_DT_SCC_NSCCOpSta
typedef uint8 COM_DT_SCC_NSCCOpSta;

#  define Rte_TypeDef_COM_DT_SCC_OptTyp
typedef uint8 COM_DT_SCC_OptTyp;

#  define Rte_TypeDef_COM_DT_SCC_ReqLimSta
typedef uint8 COM_DT_SCC_ReqLimSta;

#  define Rte_TypeDef_COM_DT_SCC_SccFlrDetSta
typedef uint8 COM_DT_SCC_SccFlrDetSta;

#  define Rte_TypeDef_COM_DT_SCC_SccOffStaDetSta
typedef uint8 COM_DT_SCC_SccOffStaDetSta;

#  define Rte_TypeDef_COM_DT_SCC_SysFlrSta
typedef uint8 COM_DT_SCC_SysFlrSta;

#  define Rte_TypeDef_COM_DT_SCC_TakeoverReq
typedef uint8 COM_DT_SCC_TakeoverReq;

#  define Rte_TypeDef_COM_DT_SCC_TqReq
typedef uint8 COM_DT_SCC_TqReq;

#  define Rte_TypeDef_COM_DT_SCC_TrgtSpdSetVal
typedef uint8 COM_DT_SCC_TrgtSpdSetVal;

#  define Rte_TypeDef_COM_DT_SCC_VehStpReq
typedef uint8 COM_DT_SCC_VehStpReq;

#  define Rte_TypeDef_COM_DT_SCR_LvlWrngLmpSta
typedef uint8 COM_DT_SCR_LvlWrngLmpSta;

#  define Rte_TypeDef_COM_DT_SCR_SysWrngLmpReq
typedef uint8 COM_DT_SCR_SysWrngLmpReq;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_CalculatedRoute
typedef uint8 COM_DT_SEG_V2_3_CalculatedRoute;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_DividedRoad
typedef uint8 COM_DT_SEG_V2_3_DividedRoad;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_FuncRoadClass
typedef uint8 COM_DT_SEG_V2_3_FuncRoadClass;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_Retransmission
typedef uint8 COM_DT_SEG_V2_3_Retransmission;

#  define Rte_TypeDef_COM_DT_SEG_V2_3_SpeedLimit
typedef uint8 COM_DT_SEG_V2_3_SpeedLimit;

#  define Rte_TypeDef_COM_DT_SEG_V2_CalculatedRoute
typedef uint8 COM_DT_SEG_V2_CalculatedRoute;

#  define Rte_TypeDef_COM_DT_SEG_V2_FuncRoadClass
typedef uint8 COM_DT_SEG_V2_FuncRoadClass;

#  define Rte_TypeDef_COM_DT_SEG_V2_SpeedLimit
typedef uint8 COM_DT_SEG_V2_SpeedLimit;

#  define Rte_TypeDef_COM_DT_SMK_AccInSta
typedef uint8 COM_DT_SMK_AccInSta;

#  define Rte_TypeDef_COM_DT_SMK_AccRlySta
typedef uint8 COM_DT_SMK_AccRlySta;

#  define Rte_TypeDef_COM_DT_SMK_AuthSta
typedef uint8 COM_DT_SMK_AuthSta;

#  define Rte_TypeDef_COM_DT_SMK_CLUAccIndOnReq
typedef uint8 COM_DT_SMK_CLUAccIndOnReq;

#  define Rte_TypeDef_COM_DT_SMK_Ign1InSta
typedef uint8 COM_DT_SMK_Ign1InSta;

#  define Rte_TypeDef_COM_DT_SMK_Ign1RlySta
typedef uint8 COM_DT_SMK_Ign1RlySta;

#  define Rte_TypeDef_COM_DT_SMK_Ign2InSta
typedef uint8 COM_DT_SMK_Ign2InSta;

#  define Rte_TypeDef_COM_DT_SMK_Ign2RlySta
typedef uint8 COM_DT_SMK_Ign2RlySta;

#  define Rte_TypeDef_COM_DT_SMK_RmtKeyCrnkModSta
typedef uint8 COM_DT_SMK_RmtKeyCrnkModSta;

#  define Rte_TypeDef_COM_DT_SMK_RmtKeyEngRunSta
typedef uint8 COM_DT_SMK_RmtKeyEngRunSta;

#  define Rte_TypeDef_COM_DT_SMK_SCULckUnlckSta
typedef uint8 COM_DT_SMK_SCULckUnlckSta;

#  define Rte_TypeDef_COM_DT_SMK_StrtFdbckSta
typedef uint8 COM_DT_SMK_StrtFdbckSta;

#  define Rte_TypeDef_COM_DT_SMK_StrtrRlyOutSta
typedef uint8 COM_DT_SMK_StrtrRlyOutSta;

#  define Rte_TypeDef_COM_DT_SMK_TlCrnkModSta
typedef uint8 COM_DT_SMK_TlCrnkModSta;

#  define Rte_TypeDef_COM_DT_SMK_TlEngRunSta
typedef uint8 COM_DT_SMK_TlEngRunSta;

#  define Rte_TypeDef_COM_DT_SMK_TrmnlMngrSta
typedef uint8 COM_DT_SMK_TrmnlMngrSta;

#  define Rte_TypeDef_COM_DT_SMK_VDModeActSta
typedef uint8 COM_DT_SMK_VDModeActSta;

#  define Rte_TypeDef_COM_DT_SSB_StrtStpBtnSw1Sta
typedef uint8 COM_DT_SSB_StrtStpBtnSw1Sta;

#  define Rte_TypeDef_COM_DT_SSB_StrtStpBtnSw2Sta
typedef uint8 COM_DT_SSB_StrtStpBtnSw2Sta;

#  define Rte_TypeDef_COM_DT_SWRC_CrsMainSwSta
typedef uint8 COM_DT_SWRC_CrsMainSwSta;

#  define Rte_TypeDef_COM_DT_SWRC_HdpSwSta
typedef uint8 COM_DT_SWRC_HdpSwSta;

#  define Rte_TypeDef_COM_DT_SWRC_Info
typedef uint8 COM_DT_SWRC_Info;

#  define Rte_TypeDef_COM_DT_SWRC_LFASwSta
typedef uint8 COM_DT_SWRC_LFASwSta;

#  define Rte_TypeDef_COM_DT_SWRC_PaddleDnSwSta
typedef uint8 COM_DT_SWRC_PaddleDnSwSta;

#  define Rte_TypeDef_COM_DT_SWRC_PaddleUpSwSta
typedef uint8 COM_DT_SWRC_PaddleUpSwSta;

#  define Rte_TypeDef_COM_DT_SWRC_SldMainSwSta
typedef uint8 COM_DT_SWRC_SldMainSwSta;

#  define Rte_TypeDef_COM_DT_SunRoof_RrBlindErrSta
typedef uint8 COM_DT_SunRoof_RrBlindErrSta;

#  define Rte_TypeDef_COM_DT_TCS_GearShftCharacteristicVal
typedef uint8 COM_DT_TCS_GearShftCharacteristicVal;

#  define Rte_TypeDef_COM_DT_TCS_PreActvSta
typedef uint8 COM_DT_TCS_PreActvSta;

#  define Rte_TypeDef_COM_DT_TCU_BrkOnReq
typedef uint8 COM_DT_TCU_BrkOnReq;

#  define Rte_TypeDef_COM_DT_TCU_CdaInhbtReq
typedef uint8 COM_DT_TCU_CdaInhbtReq;

#  define Rte_TypeDef_COM_DT_TCU_CluTrgtGearConfg
typedef uint8 COM_DT_TCU_CluTrgtGearConfg;

#  define Rte_TypeDef_COM_DT_TCU_DrvngModDis
typedef uint8 COM_DT_TCU_DrvngModDis;

#  define Rte_TypeDef_COM_DT_TCU_DrvngModReq
typedef uint8 COM_DT_TCU_DrvngModReq;

#  define Rte_TypeDef_COM_DT_TCU_EngTqIncReqVal
typedef sint16 COM_DT_TCU_EngTqIncReqVal;

#  define Rte_TypeDef_COM_DT_TCU_EngTqLimVal
typedef sint16 COM_DT_TCU_EngTqLimVal;

#  define Rte_TypeDef_COM_DT_TCU_GearLmpBlnkngReq
typedef uint8 COM_DT_TCU_GearLmpBlnkngReq;

#  define Rte_TypeDef_COM_DT_TCU_GearShftSta
typedef uint8 COM_DT_TCU_GearShftSta;

#  define Rte_TypeDef_COM_DT_TCU_GearStepTyp
typedef uint8 COM_DT_TCU_GearStepTyp;

#  define Rte_TypeDef_COM_DT_TCU_IdleUpReq
typedef uint8 COM_DT_TCU_IdleUpReq;

#  define Rte_TypeDef_COM_DT_TCU_IsgInhbtReq
typedef uint8 COM_DT_TCU_IsgInhbtReq;

#  define Rte_TypeDef_COM_DT_TCU_NetrlCtrlSta
typedef uint8 COM_DT_TCU_NetrlCtrlSta;

#  define Rte_TypeDef_COM_DT_TCU_ShftPtrnSta
typedef uint8 COM_DT_TCU_ShftPtrnSta;

#  define Rte_TypeDef_COM_DT_TCU_SmrtShftSta
typedef uint8 COM_DT_TCU_SmrtShftSta;

#  define Rte_TypeDef_COM_DT_TCU_SprtyIndxSta
typedef uint8 COM_DT_TCU_SprtyIndxSta;

#  define Rte_TypeDef_COM_DT_TCU_TqCnvrtrSta
typedef uint8 COM_DT_TCU_TqCnvrtrSta;

#  define Rte_TypeDef_COM_DT_TCU_TqRdctnVal
typedef sint16 COM_DT_TCU_TqRdctnVal;

#  define Rte_TypeDef_COM_DT_TCU_Typ
typedef uint8 COM_DT_TCU_Typ;

#  define Rte_TypeDef_COM_DT_TCU_VehSpdKphVal
typedef uint8 COM_DT_TCU_VehSpdKphVal;

#  define Rte_TypeDef_COM_DT_TrnLmpSeqEnblCmd
typedef uint8 COM_DT_TrnLmpSeqEnblCmd;

#  define Rte_TypeDef_COM_DT_USM_AdasBCA2SetReq
typedef uint8 COM_DT_USM_AdasBCA2SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasBCWSetReq
typedef uint8 COM_DT_USM_AdasBCWSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasBCWSndSetReq
typedef uint8 COM_DT_USM_AdasBCWSndSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasBVM2SetReq
typedef uint8 COM_DT_USM_AdasBVM2SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasDAWModNewSetReq
typedef uint8 COM_DT_USM_AdasDAWModNewSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasFCAFrSdSetReq
typedef uint8 COM_DT_USM_AdasFCAFrSdSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasFCAFrSetReq
typedef uint8 COM_DT_USM_AdasFCAFrSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasFCAJcSetReq
typedef uint8 COM_DT_USM_AdasFCAJcSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasFCAJnctnSetReq
typedef uint8 COM_DT_USM_AdasFCAJnctnSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasHDALCFuncSetReq
typedef uint8 COM_DT_USM_AdasHDALCFuncSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasHDASetReq
typedef uint8 COM_DT_USM_AdasHDASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasHbaSetReq
typedef uint8 COM_DT_USM_AdasHbaSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLAAutoSetReq
typedef uint8 COM_DT_USM_AdasISLAAutoSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLAEUCntryTglReq
typedef uint8 COM_DT_USM_AdasISLAEUCntryTglReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLANACntryTglReq
typedef uint8 COM_DT_USM_AdasISLANACntryTglReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLANAOffstSetReq
typedef uint8 COM_DT_USM_AdasISLANAOffstSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasISLWSetReq
typedef uint8 COM_DT_USM_AdasISLWSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasLFASetReq
typedef uint8 COM_DT_USM_AdasLFASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasLKA2SetReq
typedef uint8 COM_DT_USM_AdasLKA2SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasLKAWrngVolSetReq
typedef uint8 COM_DT_USM_AdasLKAWrngVolSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasLVDASetReq
typedef uint8 COM_DT_USM_AdasLVDASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasNSCCCamSetReq
typedef uint8 COM_DT_USM_AdasNSCCCamSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasNSCCCrvSetReq
typedef uint8 COM_DT_USM_AdasNSCCCrvSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasPDWAutoOnSetReq
typedef uint8 COM_DT_USM_AdasPDWAutoOnSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasRCCWSetReq
typedef uint8 COM_DT_USM_AdasRCCWSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCMLResetReq
typedef uint8 COM_DT_USM_AdasSCCMLResetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSCCModeSetReq
typedef uint8 COM_DT_USM_AdasSCCModeSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSEA3SetReq
typedef uint8 COM_DT_USM_AdasSEA3SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSEASetReq
typedef uint8 COM_DT_USM_AdasSEASetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSEAnewSetReq
typedef uint8 COM_DT_USM_AdasSEAnewSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSEW3SetReq
typedef uint8 COM_DT_USM_AdasSEW3SetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSEWnewSetReq
typedef uint8 COM_DT_USM_AdasSEWnewSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasSVMAutoOnSetReq
typedef uint8 COM_DT_USM_AdasSVMAutoOnSetReq;

#  define Rte_TypeDef_COM_DT_USM_AdasUSMResetReq
typedef uint8 COM_DT_USM_AdasUSMResetReq;

#  define Rte_TypeDef_COM_DT_USM_ChgGuideMdLvlSetReq
typedef uint8 COM_DT_USM_ChgGuideMdLvlSetReq;

#  define Rte_TypeDef_COM_DT_USM_CluVcAlrmVolSta
typedef uint8 COM_DT_USM_CluVcAlrmVolSta;

#  define Rte_TypeDef_COM_DT_USM_EngOilChaRstSetReq
typedef uint8 COM_DT_USM_EngOilChaRstSetReq;

#  define Rte_TypeDef_COM_DT_USM_FuelEconomySetSta
typedef uint8 COM_DT_USM_FuelEconomySetSta;

#  define Rte_TypeDef_COM_DT_USM_FuncForMdLmpBrgtSta
typedef uint8 COM_DT_USM_FuncForMdLmpBrgtSta;

#  define Rte_TypeDef_COM_DT_USM_ISLAOffstSetReq
typedef uint8 COM_DT_USM_ISLAOffstSetReq;

#  define Rte_TypeDef_COM_DT_USM_PABArbgNValueSetReq
typedef uint8 COM_DT_USM_PABArbgNValueSetReq;

#  define Rte_TypeDef_COM_DT_Usm_RpmSNOWSet
typedef uint8 COM_DT_Usm_RpmSNOWSet;

#  define Rte_TypeDef_COM_DT_Usm_RpmTERRAINAUTO
typedef uint8 COM_DT_Usm_RpmTERRAINAUTO;

#  define Rte_TypeDef_COM_DT_Warn_AsstDrSwSta
typedef uint8 COM_DT_Warn_AsstDrSwSta;

#  define Rte_TypeDef_COM_DT_Warn_AsstStBltSwSta
typedef uint8 COM_DT_Warn_AsstStBltSwSta;

#  define Rte_TypeDef_COM_DT_Warn_BrkFldSwSta
typedef uint8 COM_DT_Warn_BrkFldSwSta;

#  define Rte_TypeDef_COM_DT_Warn_DrvDrSwSta
typedef uint8 COM_DT_Warn_DrvDrSwSta;

#  define Rte_TypeDef_COM_DT_Warn_DrvStBltSwSta
typedef uint8 COM_DT_Warn_DrvStBltSwSta;

#  define Rte_TypeDef_COM_DT_Warn_HoodSwMemorySta
typedef uint8 COM_DT_Warn_HoodSwMemorySta;

#  define Rte_TypeDef_COM_DT_Warn_HoodSwSta
typedef uint8 COM_DT_Warn_HoodSwSta;

#  define Rte_TypeDef_COM_DT_Warn_PassStOccSta
typedef uint8 COM_DT_Warn_PassStOccSta;

#  define Rte_TypeDef_COM_DT_Warn_PrkngBrkSwSta
typedef uint8 COM_DT_Warn_PrkngBrkSwSta;

#  define Rte_TypeDef_COM_DT_Warn_RrCtrStBltSwSta
typedef uint8 COM_DT_Warn_RrCtrStBltSwSta;

#  define Rte_TypeDef_COM_DT_Warn_RrLftDrSwSta
typedef uint8 COM_DT_Warn_RrLftDrSwSta;

#  define Rte_TypeDef_COM_DT_Warn_RrLftStBltSwSta
typedef uint8 COM_DT_Warn_RrLftStBltSwSta;

#  define Rte_TypeDef_COM_DT_Warn_RrRtDrSwSta
typedef uint8 COM_DT_Warn_RrRtDrSwSta;

#  define Rte_TypeDef_COM_DT_Warn_RrRtStBltSwSta
typedef uint8 COM_DT_Warn_RrRtStBltSwSta;

#  define Rte_TypeDef_COM_DT_Warn_WshrFldSwSta
typedef uint8 COM_DT_Warn_WshrFldSwSta;

#  define Rte_TypeDef_COM_DT_Wiper_AutoWashModeSta
typedef uint8 COM_DT_Wiper_AutoWashModeSta;

#  define Rte_TypeDef_COM_DT_Wiper_HtWshNzzlCmd
typedef uint8 COM_DT_Wiper_HtWshNzzlCmd;

#  define Rte_TypeDef_COM_DT_Wiper_PrkngPosSta
typedef uint8 COM_DT_Wiper_PrkngPosSta;

#  define Rte_TypeDef_COM_DT_Wiper_RainSnsrOptionTyp
typedef uint8 COM_DT_Wiper_RainSnsrOptionTyp;

#  define Rte_TypeDef_COM_DT_Wiper_RainSnsrSta
typedef uint8 COM_DT_Wiper_RainSnsrSta;

#  define Rte_TypeDef_COM_DT_Wrn_Snd_AdasVolFdbck
typedef uint8 COM_DT_Wrn_Snd_AdasVolFdbck;

#  define Rte_TypeDef_COM_DT_p_CF_ECU_SSC_STAT
typedef uint8 COM_DT_p_CF_ECU_SSC_STAT;

#  define Rte_TypeDef_COM_DT_p_ENG_EngSta
typedef uint8 COM_DT_p_ENG_EngSta;

#  define Rte_TypeDef_COM_DT_p_ENG_IsgSta
typedef uint8 COM_DT_p_ENG_IsgSta;

#  define Rte_TypeDef_COM_DT_p_ICU_MtGearPosRSta
typedef uint8 COM_DT_p_ICU_MtGearPosRSta;

#  define Rte_TypeDef_COM_DT_p_TCU_GearSlctDis
typedef uint8 COM_DT_p_TCU_GearSlctDis;

#  define Rte_TypeDef_COM_DT_u8_VehicleType
typedef uint8 COM_DT_u8_VehicleType;

#  define Rte_TypeDef_EBD_DfctvSta
typedef uint8 EBD_DfctvSta;

#  define Rte_TypeDef_EBD_WrngLmpSta
typedef uint8 EBD_WrngLmpSta;

#  define Rte_TypeDef_EM_WrngLvlSta
typedef uint8 EM_WrngLvlSta;

#  define Rte_TypeDef_ESC_BrkLtActSta
typedef uint8 ESC_BrkLtActSta;

#  define Rte_TypeDef_FCA_FrOnOffEquipSta
typedef uint8 FCA_FrOnOffEquipSta;

#  define Rte_TypeDef_FCA_FullActvReq
typedef uint8 FCA_FullActvReq;

#  define Rte_TypeDef_FCA_HydrlcBstAsstReq
typedef uint8 FCA_HydrlcBstAsstReq;

#  define Rte_TypeDef_FCA_OnOffEquipSta
typedef uint8 FCA_OnOffEquipSta;

#  define Rte_TypeDef_FCA_PartialActvReq
typedef uint8 FCA_PartialActvReq;

#  define Rte_TypeDef_FCA_PrefillActvReq
typedef uint8 FCA_PrefillActvReq;

#  define Rte_TypeDef_FCA_Regulation
typedef uint8 FCA_Regulation;

#  define Rte_TypeDef_FCA_StbltActvReq
typedef uint8 FCA_StbltActvReq;

#  define Rte_TypeDef_FCA_SysFlrSta
typedef uint8 FCA_SysFlrSta;

#  define Rte_TypeDef_FCA_VehStpReq
typedef uint8 FCA_VehStpReq;

#  define Rte_TypeDef_FCA_WarnTimeSta
typedef uint8 FCA_WarnTimeSta;

#  define Rte_TypeDef_FCA_WrngLvlSta
typedef uint8 FCA_WrngLvlSta;

#  define Rte_TypeDef_FCA_WrngSndSta
typedef uint8 FCA_WrngSndSta;

#  define Rte_TypeDef_FCA_WrngTrgtDis
typedef uint8 FCA_WrngTrgtDis;

#  define Rte_TypeDef_HDP_EMOpSta
typedef uint8 HDP_EMOpSta;

#  define Rte_TypeDef_ICC_CamBlckdStat
typedef uint8 ICC_CamBlckdStat;

#  define Rte_TypeDef_ICC_CamFailStat
typedef uint8 ICC_CamFailStat;

#  define Rte_TypeDef_ICC_EcuFailStat
typedef uint8 ICC_EcuFailStat;

#  define Rte_TypeDef_ICC_OptUsmStat
typedef uint8 ICC_OptUsmStat;

#  define Rte_TypeDef_ICC_ProfilingStat
typedef uint8 ICC_ProfilingStat;

#  define Rte_TypeDef_ICC_SymStat
typedef uint8 ICC_SymStat;

#  define Rte_TypeDef_ICC_UpdateStat
typedef uint8 ICC_UpdateStat;

#  define Rte_TypeDef_ICC_WarningStat
typedef uint8 ICC_WarningStat;

#  define Rte_TypeDef_Navi_ISLA_TImeZone
typedef uint8 Navi_ISLA_TImeZone;

#  define Rte_TypeDef_Navi_ISLW_Frwinfo
typedef uint8 Navi_ISLW_Frwinfo;

#  define Rte_TypeDef_Navi_ISLW_LinkClass
typedef uint8 Navi_ISLW_LinkClass;

#  define Rte_TypeDef_Navi_ISLW_SpdUnit
typedef uint8 Navi_ISLW_SpdUnit;

#  define Rte_TypeDef_Navi_ISLW_TollExist
typedef uint8 Navi_ISLW_TollExist;

#  define Rte_TypeDef_Navi_ISLW_TunnelExist
typedef uint8 Navi_ISLW_TunnelExist;

#  define Rte_TypeDef_Nmode_FCAOff_Sta
typedef uint8 Nmode_FCAOff_Sta;

#  define Rte_TypeDef_SCC_MainOnOffSta
typedef uint8 SCC_MainOnOffSta;

#  define Rte_TypeDef_SCC_NSCCOnOffSta
typedef uint8 SCC_NSCCOnOffSta;

#  define Rte_TypeDef_SCC_NSCCOpSta
typedef uint8 SCC_NSCCOpSta;

#  define Rte_TypeDef_SCC_SysFlrSta
typedef uint8 SCC_SysFlrSta;

#  define Rte_TypeDef_SCC_TakeoverReq
typedef uint8 SCC_TakeoverReq;

#  define Rte_TypeDef_SCC_TrgtSpdSetVal
typedef uint8 SCC_TrgtSpdSetVal;

#  define Rte_TypeDef_SCC_VehStpReq
typedef uint8 SCC_VehStpReq;

#  define Rte_TypeDef_p_CF_ECU_SSC_STAT
typedef uint8 p_CF_ECU_SSC_STAT;

#  define Rte_TypeDef_p_CF_ECU_SSC_STAT_t
typedef uint8 p_CF_ECU_SSC_STAT_t;

#  define Rte_TypeDef_p_CF_Ems_IsgStat_t
typedef uint8 p_CF_Ems_IsgStat_t;

#  define Rte_TypeDef_p_ENG_EngSta
typedef uint8 p_ENG_EngSta;

#  define Rte_TypeDef_p_ENG_IsgSta
typedef uint8 p_ENG_IsgSta;

#  define Rte_TypeDef_p_ENG_Stat_t
typedef uint8 p_ENG_Stat_t;

#  define Rte_TypeDef_p_G_Sel_Disp_t
typedef uint8 p_G_Sel_Disp_t;

#  define Rte_TypeDef_p_ICU_MtGearPosRSta
typedef uint8 p_ICU_MtGearPosRSta;

#  define Rte_TypeDef_p_TCU_GearSlctDis
typedef uint8 p_TCU_GearSlctDis;

#  define Rte_TypeDef_COM_DT_IMU_SeralNumVal
typedef uint8 COM_DT_IMU_SeralNumVal[6];

#  define Rte_TypeDef_CoFca_u16_16
typedef uint16 CoFca_u16_16[16];

#  define Rte_TypeDef_CoFca_u32_15
typedef uint32 CoFca_u32_15[15];

#  define Rte_TypeDef_CoFca_u8_15
typedef uint8 CoFca_u8_15[15];

#  define Rte_TypeDef_Dcm_Data10ByteType
typedef uint8 Dcm_Data10ByteType[10];

#  define Rte_TypeDef_Dcm_Data11ByteType
typedef uint8 Dcm_Data11ByteType[11];

#  define Rte_TypeDef_Dcm_Data12ByteType
typedef uint8 Dcm_Data12ByteType[12];

#  define Rte_TypeDef_Dcm_Data136ByteType
typedef uint8 Dcm_Data136ByteType[136];

#  define Rte_TypeDef_Dcm_Data14ByteType
typedef uint8 Dcm_Data14ByteType[14];

#  define Rte_TypeDef_Dcm_Data15ByteType
typedef uint8 Dcm_Data15ByteType[15];

#  define Rte_TypeDef_Dcm_Data17ByteType
typedef uint8 Dcm_Data17ByteType[17];

#  define Rte_TypeDef_Dcm_Data1ByteType
typedef uint8 Dcm_Data1ByteType[1];

#  define Rte_TypeDef_Dcm_Data20ByteType
typedef uint8 Dcm_Data20ByteType[20];

#  define Rte_TypeDef_Dcm_Data22ByteType
typedef uint8 Dcm_Data22ByteType[22];

#  define Rte_TypeDef_Dcm_Data2ByteType
typedef uint8 Dcm_Data2ByteType[2];

#  define Rte_TypeDef_Dcm_Data30ByteType
typedef uint8 Dcm_Data30ByteType[30];

#  define Rte_TypeDef_Dcm_Data32ByteType
typedef uint8 Dcm_Data32ByteType[32];

#  define Rte_TypeDef_Dcm_Data33ByteType
typedef uint8 Dcm_Data33ByteType[33];

#  define Rte_TypeDef_Dcm_Data3ByteType
typedef uint8 Dcm_Data3ByteType[3];

#  define Rte_TypeDef_Dcm_Data4000ByteType
typedef uint8 Dcm_Data4000ByteType[4000];

#  define Rte_TypeDef_Dcm_Data40ByteType
typedef uint8 Dcm_Data40ByteType[40];

#  define Rte_TypeDef_Dcm_Data47ByteType
typedef uint8 Dcm_Data47ByteType[47];

#  define Rte_TypeDef_Dcm_Data48ByteType
typedef uint8 Dcm_Data48ByteType[48];

#  define Rte_TypeDef_Dcm_Data4ByteType
typedef uint8 Dcm_Data4ByteType[4];

#  define Rte_TypeDef_Dcm_Data59ByteType
typedef uint8 Dcm_Data59ByteType[59];

#  define Rte_TypeDef_Dcm_Data5ByteType
typedef uint8 Dcm_Data5ByteType[5];

#  define Rte_TypeDef_Dcm_Data67ByteType
typedef uint8 Dcm_Data67ByteType[67];

#  define Rte_TypeDef_Dcm_Data6ByteType
typedef uint8 Dcm_Data6ByteType[6];

#  define Rte_TypeDef_Dcm_Data8ByteType
typedef uint8 Dcm_Data8ByteType[8];

#  define Rte_TypeDef_Dem_MaxDataValueType
typedef uint8 Dem_MaxDataValueType[2];

#  define Rte_TypeDef_EYEQCAM_CamEEPROMDataType
typedef uint8 EYEQCAM_CamEEPROMDataType[2048];

#  define Rte_TypeDef_EYEQEDR_DataBufSizeType
typedef uint8 EYEQEDR_DataBufSizeType[2];

#  define Rte_TypeDef_EYEQEDR_DescBufSizeType
typedef uint8 EYEQEDR_DescBufSizeType[256];

#  define Rte_TypeDef_EYEQMESP_CodingBufferType
typedef uint8 EYEQMESP_CodingBufferType[300];

#  define Rte_TypeDef_EYEQMESP_FuseIdType
typedef uint8 EYEQMESP_FuseIdType[16];

#  define Rte_TypeDef_EYEQMESP_SFRBufferType
typedef uint8 EYEQMESP_SFRBufferType[112];

#  define Rte_TypeDef_EYEQMESP_SPBufferType
typedef uint8 EYEQMESP_SPBufferType[4992];

#  define Rte_TypeDef_EyeQMCD_MiniCoreDumpDataType
typedef uint8 EyeQMCD_MiniCoreDumpDataType[512];

#  define Rte_TypeDef_EyeQSecurity_PasswordType
typedef uint8 EyeQSecurity_PasswordType[8];

#  define Rte_TypeDef_HKMC_PartNumber_t
typedef uint8 HKMC_PartNumber_t[11];

#  define Rte_TypeDef_HW_Version_t
typedef uint8 HW_Version_t[4];

#  define Rte_TypeDef_JTAG_EncDbgKeyType
typedef uint8 JTAG_EncDbgKeyType[256];

#  define Rte_TypeDef_JTAG_PasswordType
typedef uint8 JTAG_PasswordType[32];

#  define Rte_TypeDef_MAN_BootModeStatusType
typedef uint8 MAN_BootModeStatusType[8];

#  define Rte_TypeDef_MAN_CoreSwVersionType
typedef uint8 MAN_CoreSwVersionType[26];

#  define Rte_TypeDef_MAN_PCBSerialNumberType
typedef uint8 MAN_PCBSerialNumberType[16];

#  define Rte_TypeDef_MAN_UniqueImagerIDOTPDataType
typedef uint8 MAN_UniqueImagerIDOTPDataType[32];

#  define Rte_TypeDef_PlatformCode
typedef uint8 PlatformCode[3];

#  define Rte_TypeDef_Reserved_2
typedef uint8 Reserved_2[2];

#  define Rte_TypeDef_Rte_DT_DawOccNvData_t_11
typedef uint8 Rte_DT_DawOccNvData_t_11[3];

#  define Rte_TypeDef_Rte_DT_DtcFaultSts_t_0
typedef uint8 Rte_DT_DtcFaultSts_t_0[130];

#  define Rte_TypeDef_Rte_DT_EDR_NvData_t_0
typedef uint8 Rte_DT_EDR_NvData_t_0[600];

#  define Rte_TypeDef_Rte_DT_EYEQCAM_CamHwCalParams_t_2
typedef uint8 Rte_DT_EYEQCAM_CamHwCalParams_t_2[32];

#  define Rte_TypeDef_Rte_DT_EYEQCAM_CamHwCalParams_t_3
typedef uint8 Rte_DT_EYEQCAM_CamHwCalParams_t_3[2];

#  define Rte_TypeDef_Rte_DT_EYEQCAM_CamHwCalParams_t_4
typedef uint8 Rte_DT_EYEQCAM_CamHwCalParams_t_4[12];

#  define Rte_TypeDef_Rte_DT_EYEQDG_InputSignals_t_136
typedef uint8 Rte_DT_EYEQDG_InputSignals_t_136[2];

#  define Rte_TypeDef_Rte_DT_EYEQDG_LastFSDataRcd_t_10
typedef uint16 Rte_DT_EYEQDG_LastFSDataRcd_t_10[7];

#  define Rte_TypeDef_Rte_DT_EYEQDG_SafetyFuncConfig_t_12
typedef uint16 Rte_DT_EYEQDG_SafetyFuncConfig_t_12[8];

#  define Rte_TypeDef_Rte_DT_EYEQEDR_BBQueryResParams_t_7
typedef uint8 Rte_DT_EYEQEDR_BBQueryResParams_t_7[8];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_AutoFixCalData_t_8
typedef uint8 Rte_DT_EYEQMESP_AutoFixCalData_t_8[14];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_CamDistorParams_t_29
typedef uint16 Rte_DT_EYEQMESP_CamDistorParams_t_29[6];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_CameraFocused_t_6
typedef uint8 Rte_DT_EYEQMESP_CameraFocused_t_6[22];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_SPCalibration_t_28
typedef uint16 Rte_DT_EYEQMESP_SPCalibration_t_28[6];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_TargetCalParamsLimits_t_10
typedef uint16 Rte_DT_EYEQMESP_TargetCalParamsLimits_t_10[10];

#  define Rte_TypeDef_Rte_DT_EYEQMESP_TargetCalibData_t_8
typedef uint8 Rte_DT_EYEQMESP_TargetCalibData_t_8[14];

#  define Rte_TypeDef_Rte_DT_EYEQ_SysCfgFlgsRcd_t_2
typedef uint8 Rte_DT_EYEQ_SysCfgFlgsRcd_t_2[14];

#  define Rte_TypeDef_Rte_DT_EyeQDG_SafetyCriticalFuncConfig_t_8
typedef uint16 Rte_DT_EyeQDG_SafetyCriticalFuncConfig_t_8[10];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_AppendImageRequestParams_t_2
typedef uint8 Rte_DT_EyeQEdrEnhd_AppendImageRequestParams_t_2[12];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_AppendRequests_t_3
typedef uint8 Rte_DT_EyeQEdrEnhd_AppendRequests_t_3[12];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_BbGetDescReplyParams_t_0
typedef uint8 Rte_DT_EyeQEdrEnhd_BbGetDescReplyParams_t_0[256];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_13
typedef uint8 Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_13[64];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_25
typedef uint8 Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_25[256];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_27
typedef uint8 Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_27[12];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_MultipleAppendImageReplyParams_t_3
typedef uint32 Rte_DT_EyeQEdrEnhd_MultipleAppendImageReplyParams_t_3[10];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_MultipleTriggerEventReplyParams_t_3
typedef uint32 Rte_DT_EyeQEdrEnhd_MultipleTriggerEventReplyParams_t_3[10];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_5
typedef uint8 Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_5[4];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_1
typedef uint8 Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_1[10];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_3
typedef uint8 Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_3[76];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_8
typedef uint8 Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_8[12];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_9
typedef uint8 Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_9[4];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_TriggerRequestsParams_t_9
typedef uint8 Rte_DT_EyeQEdrEnhd_TriggerRequestsParams_t_9[12];

#  define Rte_TypeDef_Rte_DT_EyeQFOTA_BlackBoxData_t_1
typedef uint8 Rte_DT_EyeQFOTA_BlackBoxData_t_1[172];

#  define Rte_TypeDef_Rte_DT_EyeQFOTA_Hash_t_1
typedef uint8 Rte_DT_EyeQFOTA_Hash_t_1[32];

#  define Rte_TypeDef_Rte_DT_EyeQFOTA_MiniBlock_t_1
typedef uint8 Rte_DT_EyeQFOTA_MiniBlock_t_1[2048];

#  define Rte_TypeDef_Rte_DT_EyeQFfsSrvc_FfsHash_t_2
typedef uint8 Rte_DT_EyeQFfsSrvc_FfsHash_t_2[32];

#  define Rte_TypeDef_Rte_DT_EyeQFfsSrvc_SerialIDReplyData_t_1
typedef uint8 Rte_DT_EyeQFfsSrvc_SerialIDReplyData_t_1[8];

#  define Rte_TypeDef_Rte_DT_EyeQIDMGRC_SerialNumberPCB_t_2
typedef uint8 Rte_DT_EyeQIDMGRC_SerialNumberPCB_t_2[16];

#  define Rte_TypeDef_Rte_DT_HKMC_TraceabilityInformation_t_1
typedef uint8 Rte_DT_HKMC_TraceabilityInformation_t_1[6];

#  define Rte_TypeDef_Rte_DT_HKMC_TraceabilityInformation_t_7
typedef uint8 Rte_DT_HKMC_TraceabilityInformation_t_7[9];

#  define Rte_TypeDef_Rte_DT_IslwFrqNvData_t_24_0
typedef uint8 Rte_DT_IslwFrqNvData_t_24_0[1];

#  define Rte_TypeDef_Rte_DT_NvMVersionDataRead_0
typedef Rte_DT_NvMVersionDataRead_0_0 Rte_DT_NvMVersionDataRead_0[30];

#  define Rte_TypeDef_Rte_DT_PtmEepDumpRecord_t_0
typedef uint8 Rte_DT_PtmEepDumpRecord_t_0[32];

#  define Rte_TypeDef_Rte_DT_SECURITY_RNGInitCount_t_3
typedef uint8 Rte_DT_SECURITY_RNGInitCount_t_3[2];

#  define Rte_TypeDef_Rte_DT_SccNvmData_t_19
typedef uint8 Rte_DT_SccNvmData_t_19[3];

#  define Rte_TypeDef_Rte_DT_ZFECUHwNrDataId_t_0
typedef uint8 Rte_DT_ZFECUHwNrDataId_t_0[16];

#  define Rte_TypeDef_Rte_DT_ZFECUHwVerNrDataId_t_0
typedef uint8 Rte_DT_ZFECUHwVerNrDataId_t_0[16];

#  define Rte_TypeDef_Rte_DT_ZFManfrECUSerialNr_t_0
typedef uint8 Rte_DT_ZFManfrECUSerialNr_t_0[16];

#  define Rte_TypeDef_SECURITY_Hash_SHA256_Type
typedef uint8 SECURITY_Hash_SHA256_Type[256];

#  define Rte_TypeDef_SECURITY_RandomNumberType
typedef uint8 SECURITY_RandomNumberType[256];

#  define Rte_TypeDef_SW_Version_t
typedef uint8 SW_Version_t[4];

#  define Rte_TypeDef_Supplier_SW_Info_t
typedef uint8 Supplier_SW_Info_t[3];

#  define Rte_TypeDef_VehicleName
typedef uint8 VehicleName[8];

#  define Rte_TypeDef_s16_array_11
typedef sint16 s16_array_11[11];

#  define Rte_TypeDef_s16_array_12
typedef sint16 s16_array_12[12];

#  define Rte_TypeDef_s16_array_2
typedef sint16 s16_array_2[2];

#  define Rte_TypeDef_s16_array_3
typedef sint16 s16_array_3[3];

#  define Rte_TypeDef_s16_array_4
typedef sint16 s16_array_4[4];

#  define Rte_TypeDef_s16_array_5
typedef sint16 s16_array_5[5];

#  define Rte_TypeDef_s16_array_6
typedef sint16 s16_array_6[6];

#  define Rte_TypeDef_s16_array_7
typedef sint16 s16_array_7[7];

#  define Rte_TypeDef_s16_array_8
typedef sint16 s16_array_8[8];

#  define Rte_TypeDef_s16_array_9
typedef sint16 s16_array_9[9];

#  define Rte_TypeDef_s32_array_11
typedef sint32 s32_array_11[11];

#  define Rte_TypeDef_s32_array_13
typedef sint32 s32_array_13[13];

#  define Rte_TypeDef_s32_array_2
typedef sint32 s32_array_2[2];

#  define Rte_TypeDef_s32_array_21
typedef sint32 s32_array_21[21];

#  define Rte_TypeDef_s32_array_3
typedef sint32 s32_array_3[3];

#  define Rte_TypeDef_s32_array_4
typedef sint32 s32_array_4[4];

#  define Rte_TypeDef_s32_array_48
typedef sint32 s32_array_48[48];

#  define Rte_TypeDef_s32_array_5
typedef sint32 s32_array_5[5];

#  define Rte_TypeDef_s32_array_6
typedef sint32 s32_array_6[6];

#  define Rte_TypeDef_s32_array_7
typedef sint32 s32_array_7[7];

#  define Rte_TypeDef_s32_array_8
typedef sint32 s32_array_8[8];

#  define Rte_TypeDef_s32_array_9
typedef sint32 s32_array_9[9];

#  define Rte_TypeDef_s8_array_2
typedef sint8 s8_array_2[2];

#  define Rte_TypeDef_s8_array_7
typedef sint8 s8_array_7[7];

#  define Rte_TypeDef_u16_array_10
typedef uint16 u16_array_10[10];

#  define Rte_TypeDef_u16_array_11
typedef uint16 u16_array_11[11];

#  define Rte_TypeDef_u16_array_12
typedef uint16 u16_array_12[12];

#  define Rte_TypeDef_u16_array_14
typedef uint16 u16_array_14[14];

#  define Rte_TypeDef_u16_array_16
typedef uint16 u16_array_16[16];

#  define Rte_TypeDef_u16_array_2
typedef uint16 u16_array_2[2];

#  define Rte_TypeDef_u16_array_20
typedef uint16 u16_array_20[20];

#  define Rte_TypeDef_u16_array_21
typedef uint16 u16_array_21[21];

#  define Rte_TypeDef_u16_array_24
typedef uint16 u16_array_24[24];

#  define Rte_TypeDef_u16_array_25
typedef uint16 u16_array_25[25];

#  define Rte_TypeDef_u16_array_3
typedef uint16 u16_array_3[3];

#  define Rte_TypeDef_u16_array_30
typedef uint16 u16_array_30[30];

#  define Rte_TypeDef_u16_array_32
typedef uint16 u16_array_32[32];

#  define Rte_TypeDef_u16_array_4
typedef uint16 u16_array_4[4];

#  define Rte_TypeDef_u16_array_42
typedef uint16 u16_array_42[42];

#  define Rte_TypeDef_u16_array_48
typedef uint16 u16_array_48[48];

#  define Rte_TypeDef_u16_array_5
typedef uint16 u16_array_5[5];

#  define Rte_TypeDef_u16_array_56
typedef uint16 u16_array_56[56];

#  define Rte_TypeDef_u16_array_6
typedef uint16 u16_array_6[6];

#  define Rte_TypeDef_u16_array_7
typedef uint16 u16_array_7[7];

#  define Rte_TypeDef_u16_array_8
typedef uint16 u16_array_8[8];

#  define Rte_TypeDef_u16_array_9
typedef uint16 u16_array_9[9];

#  define Rte_TypeDef_u32_array_10
typedef uint32 u32_array_10[10];

#  define Rte_TypeDef_u32_array_11
typedef uint32 u32_array_11[11];

#  define Rte_TypeDef_u32_array_13
typedef uint32 u32_array_13[13];

#  define Rte_TypeDef_u32_array_2
typedef uint32 u32_array_2[2];

#  define Rte_TypeDef_u32_array_3
typedef uint32 u32_array_3[3];

#  define Rte_TypeDef_u32_array_37
typedef uint32 u32_array_37[37];

#  define Rte_TypeDef_u32_array_4
typedef uint32 u32_array_4[4];

#  define Rte_TypeDef_u32_array_42
typedef uint32 u32_array_42[42];

#  define Rte_TypeDef_u32_array_5
typedef uint32 u32_array_5[5];

#  define Rte_TypeDef_u32_array_6
typedef uint32 u32_array_6[6];

#  define Rte_TypeDef_u32_array_7
typedef uint32 u32_array_7[7];

#  define Rte_TypeDef_u32_array_78
typedef uint32 u32_array_78[78];

#  define Rte_TypeDef_u32_array_8
typedef uint32 u32_array_8[8];

#  define Rte_TypeDef_u32_array_9
typedef uint32 u32_array_9[9];

#  define Rte_TypeDef_u8_array_12
typedef uint8 u8_array_12[12];

#  define Rte_TypeDef_u8_array_16
typedef uint8 u8_array_16[16];

#  define Rte_TypeDef_u8_array_2
typedef uint8 u8_array_2[2];

#  define Rte_TypeDef_u8_array_28
typedef uint8 u8_array_28[28];

#  define Rte_TypeDef_u8_array_3
typedef uint8 u8_array_3[3];

#  define Rte_TypeDef_u8_array_32
typedef uint8 u8_array_32[32];

#  define Rte_TypeDef_u8_array_4
typedef uint8 u8_array_4[4];

#  define Rte_TypeDef_u8_array_5
typedef uint8 u8_array_5[5];

#  define Rte_TypeDef_u8_array_6
typedef uint8 u8_array_6[6];

#  define Rte_TypeDef_u8_array_7
typedef uint8 u8_array_7[7];

#  define Rte_TypeDef_u8_array_9
typedef uint8 u8_array_9[9];

#  define Rte_TypeDef_ADAS101_t
typedef struct
{
  uint16 CALR;
  uint16 VN;
  uint16 p_YRS_YawRtVal;
  uint8 p_OutTempCSta;
  uint16 p_WHL_SpdFLVal;
  uint16 p_WHL_SpdFRVal;
  uint16 p_WHL_SpdRLVal;
  uint16 p_WHL_SpdRRVal;
  sint16 p_SAS_AnglVal;
  uint8 p_TCU_GearSlctDis;
  uint8 p_ICU_MtGearPosRSta;
  uint8 p_ENG_EngSta;
  uint8 p_ENG_IsgSta;
  uint8 p_CF_ECU_SSC_STAT;
  uint8 p_HCU_HevRdySta;
  uint8 p_ABS_DiagSta;
} ADAS101_t;

#  define Rte_TypeDef_Adas101SuperSet_t
typedef struct
{
  uint16 CALR;
  uint16 VN;
  uint16 YawRate;
  uint8 OutTemp;
  uint16 WHL_SPD_FL;
  uint16 WHL_SPD_FR;
  uint16 WHL_SPD_RL;
  uint16 WHL_SPD_RR;
  sint16 SAS_Angle;
  uint8 GearSelection;
  uint8 GearPosition;
  uint8 EngStat;
  uint8 EngIsgStat;
  uint8 ECU_SSC_Stat;
  uint8 HCU_HevRdySta;
} Adas101SuperSet_t;

#  define Rte_TypeDef_BattMonData_t
typedef struct
{
  uint16 rawvolt_u16;
  uint16 faultstatus_u16;
} BattMonData_t;

#  define Rte_TypeDef_CANmsg_t
typedef struct
{
  uint8 u8_FCA_SysFlrSta;
  uint8 u8_ADAS_ActToiSta;
  uint8 u8_LKA_LHLnWrnSta;
  uint8 u8_LKA_RcgSta;
  uint8 u8_LKA_RHLnWrnSta;
  uint8 u8_LKA_SysIndReq;
  uint8 u8_Lamp_HbaCtrlModTyp;
  uint8 u8_Wiper_PrkngPosSta;
  uint8 u8_CTM_TrailerAct;
  uint16 u16_CLU_DisSpdVal;
  uint8 u8_CLU_DisSpdDcmlVal;
  uint8 u8_CLU_SpdUnitTyp;
  uint8 u8_SWRC_CrsMainSwSta;
  uint8 u8_SWRC_CrsSwSta;
  uint8 u8_SWRC_SldMainSwSta;
  uint8 u8_CLU_DrvngModSwSta;
  uint8 u8_CLU_IceWrnIndSta;
  uint8 u8_USM_AdasISLASetReq;
  uint8 u8_USM_ISLAOffstSetReq;
  uint8 u8_USM_AdasISLANAOffstSetReq;
  uint8 u8_USM_AdasFCAFrSetReq;
  uint8 u8_USM_AdasLKA2SetReq;
  uint8 u8_USM_AdasHDASetReq;
  uint8 u8_USM_AdasISLWSetReq;
  uint8 u8_USM_AdasLVDASetReq;
  uint8 u8_USM_AdasNSCCCamSetReq;
  uint8 u8_USM_AdasSCCDrvModSetReq;
  uint8 u8_USM_AdasUSMResetReq;
  uint8 u8_USM_AdasWarnTimeSetReq;
  uint8 u8_USM_AdasSCCMLResetReq;
  uint8 u8_USM_AdasSCCMLChar1SetReq;
  uint8 u8_USM_AdasSCCMLChar2SetReq;
  uint8 u8_USM_AdasSCCMLChar3SetReq;
  uint8 u8_USM_AdasHbaSetReq;
  uint8 u8_USM_AdasLkaModSetReq;
  uint8 u8_USM_AdasISLAEUCntry1SetReq;
  uint8 u8_USM_AdasISLAEUCntryTglReq;
  uint8 u8_USM_AdasISLANACntry1SetReq;
  uint8 u8_USM_AdasISLANACntryTglReq;
  uint8 u8_HDP_ActvSta;
  uint16 u16_VehSpdLimVal;
  uint16 u16_ENG_EngSpdVal;
  uint8 u8_ACC_CrsSetSwLmpSta;
  uint8 u8_HCU_CrsCtrlOnLmpDis;
  uint8 u8_HCU_CrsCtrlSetLmpDis;
  uint8 u8_ESC_DrvBrkActvSta;
  uint8 u8_ENG_IsgSta;
  uint8 u8_ENG_SldFuncSta;
  uint8 u8_HCU_SpdLimDeviceActSta;
  uint8 u8_ENG_SldSwSta;
  uint8 u8_HCU_SpdLimDeviceOperSta;
  uint16 u16_AccelPdlVal;
  uint8 u8_ENG_AppAccelPdlSta;
  uint8 u8_ENG_EngSta;
  uint8 u8_HCU_HevRdySta;
  uint8 u8_EMS_SCCIsgEna;
  uint8 u8_CF_ECU_SSC_STAT;
  uint8 u8_EPB_SwPosSta;
  uint8 u8_EPB_FrcSta;
  uint8 u8_ABS_ActvSta;
  uint8 u8_ABS_DiagSta;
  uint8 u8_AVH_Sta;
  uint8 u8_ESC_Sta;
  uint8 u8_ESC_CylPrsrSta;
  uint16 u16_ESC_CylPrsrVal;
  sint16 s16_IEB_StrkDpthmmVal;
  uint8 u8_ESC_VsmActvSta;
  uint8 u8_TCS_Sta;
  uint8 u8_ESC_OffTempSta;
  uint8 u8_ESC_DrvOvrdSta;
  uint8 u8_ESC_PrkBrkActvSta;
  uint8 u8_ESC_StdStillVal;
  uint8 u8_FCA_AvlblSta;
  uint8 u8_FCA_EquipSta;
  uint8 u8_SCC_EnblReq;
  uint8 u8_HU_NaviCamSettingStatus;
  uint8 u8_HU_NaviStatus;
  uint8 u8_HU_AliveStatus;
  uint8 u8_HU_AdasSupport;
  uint8 u8_HU_DistributeInfo;
  uint8 u8_HU_Type;
  uint16 u16_HU_OptionInfo;
  uint16 u16_Navi_ISLW_CountryCode;
  uint8 u8_Navi_ISLW_Frwinfo;
  uint8 u8_Navi_ISLW_LinkClass;
  uint8 u8_Navi_ISLW_MapSource;
  uint8 u8_Navi_ISLW_SpdLimit;
  uint8 u8_Navi_ISLW_SpdUnit;
  uint8 u8_Navi_ISLW_TimeSpd;
  uint8 u8_Navi_ISLW_TollExist;
  uint8 u8_Navi_ISLW_TunnelExist;
  uint8 u8_POS_CyclicCounter;
  uint16 u16_POS_Offset;
  uint16 u16_POS_RangeAvgSpeed;
  uint8 u8_POS_PathIndex;
  uint8 u8_POS_CurrAltitude100m;
  uint8 u8_POS_CurrAltitude1m;
  uint8 u8_POS_CurrFuncRoadClass;
  uint8 u8_POS_CurrFormOfWay;
  uint8 u8_POS_CurrDirectionLanes;
  uint8 u8_POS_CurrSpeedLimit;
  uint8 u8_POS_CurrTrafficSpeed;
  uint8 u8_PROLONG_CyclicCounter;
  uint16 u16_PROLONG_Offset;
  uint8 u8_PROLONG_ProfileType;
  uint8 u8_PROLONG_Update;
  uint32 u32_PROLONG_Value;
  uint8 u8_PROLONG_PathIndex;
  uint8 u8_PROSHORT_CyclicCounter;
  uint16 u16_PROSHORT_Distance;
  uint16 u16_PROSHORT_Offset;
  uint8 u8_PROSHORT_ProfileType;
  uint16 u16_PROSHORT_Value0;
  uint16 u16_PROSHORT_Value1;
  uint8 u8_PROSHORT_PathIndex;
  uint8 u8_PROSHORT_Accuracy;
  uint8 u8_SEG_CalculatedRoute;
  uint8 u8_SEG_CyclicCounter;
  uint8 u8_SEG_DirectionLanes;
  uint8 u8_SEG_FormOfWay;
  uint8 u8_SEG_FuncRoadClass;
  uint16 u16_SEG_Offset;
  uint8 u8_SEG_Retransmission;
  uint8 u8_SEG_SpeedLimit;
  uint8 u8_SEG_SpeedLimitUnder5;
  uint8 u8_SEG_PathIndex;
  uint8 u8_Warn_AsstDrSwSta;
  uint8 u8_Warn_DrvDrSwSta;
  uint8 u8_Warn_DrvStBltSwSta;
  uint8 u8_Warn_RrLftDrSwSta;
  uint8 u8_Warn_RrRtDrSwSta;
  uint8 u8_ExtLamp_HzrdSwSta;
  uint8 u8_Lamp_TrnSigLmpLftActiveSt;
  uint8 u8_Lamp_TrnSigLmpRtActiveSt;
  uint8 u8_ExtLamp_TrnSigLmpLftSwSta;
  uint8 u8_ExtLamp_TrnSigLmpRtSwSta;
  uint8 u8_MDPS_LkaToiUnblSta;
  uint8 u8_MDPS_LkaToiFltSta;
  uint16 u16_MDPS_StrTqSnsrVal;
  uint8 u8_MDPS_LkaToiActvSta;
  sint16 s16_SAS_AnglVal;
  uint8 u8_SAS_IntSta;
  uint8 u8_SAS_SpdVal;
  uint8 u8_SWRC_LFASwSta;
  uint8 u8_GearSlctDis;
  uint16 u16_WHL_SpdFLVal;
  uint16 u16_WHL_SpdFRVal;
  uint16 u16_WHL_SpdRLVal;
  uint16 u16_WHL_SpdRRVal;
  uint8 u8_WHL_PlsFLVal;
  uint8 u8_WHL_PlsFRVal;
  uint8 u8_WHL_PlsRLVal;
  uint8 u8_WHL_PlsRRVal;
  uint8 u8_YRS_YawSigSta;
  uint8 u8_YRS_LatAccelSigSta;
  uint8 u8_YRS_LongAccelSigSta;
  uint8 u8_YRS_AcuRstSta;
  uint16 u16_YRS_YawRtVal;
  uint16 u16_YRS_LatAccelVal;
  uint16 u16_YRS_LongAccelVal;
  uint8 u8_ICU_MtGearPosRSta;
  uint8 u8_FCA_FrOnOffEquipSta;
  uint8 u8_SCC_OpSta;
  uint8 u8_SCC_InfoDis;
  uint8 u8_SCC_ObjSta;
  uint8 u8_SCC_TrgtSpdSetVal;
  uint8 u8_SCC_MainOnOffSta;
  uint8 u8_SCC_SysFlrSta;
  uint8 u8_RSPA_Sta;
  uint8 u8_RSPA_Actv;
  uint8 u8_ESC_RspaSta;
  uint8 u8_DMIC_IndEngModSta;
  uint8 u8_MDPS_PaModeSta;
  uint8 u8_META_Country_OptADAS;
  uint8 u8_META_CyclicCounter;
  uint8 u8_ENG_TransmsnTyp;
  uint8 u8_HCU_SccEnblSta;
  uint8 u8_ESC_IMURstStaAck;
  uint8 u8_IAU_ProfileIDRVal;
  uint8 u8_CF_AVN_ProfileIDRValue;
  uint8 u8_ICC_WarningStat;
  uint8 u8_ICC_DistLvlStat;
  uint8 u8_ICC_IntvStat;
  uint8 u8_ICC_IntvSDLvlStat;
  uint8 u8_ICC_IntvDrwsLvlStat;
  uint8 u8_ICC_SymStat;
  uint8 u8_Haptic_USMCurState_OnOff;
  uint8 u8_USM_AdasLKAWrngVolSetReq;
  uint8 u8_USM_CluAdasVolSta;
  uint8 u8_DATC_OutTempDispC;
  uint8 u8_DATC_OutTempDispF;
  uint8 u8_CF_AVN_LKAWrngVolNvalueSet;
  uint8 u8_ICC_WarningSmblDistStat;
  uint8 u8_ICC_WarningSndStat;
  uint8 u8_ICC_WarningSnd2Stat;
  uint8 u8_ICC_AoIStat;
  uint8 u8_Navi_ISLA_TImeZone;
} CANmsg_t;

#  define Rte_TypeDef_COM_DT_SG_ABS_ESC_01_10ms_SignalGroup
typedef struct
{
  ABS_ActvSta ABS_ActvSta;
  ABS_DfctvSta ABS_DfctvSta;
  ABS_DiagSta ABS_DiagSta;
  ABS_ESC_AlvCnt1Val ABS_ESC_AlvCnt1Val;
  ABS_ESC_Crc1Val ABS_ESC_Crc1Val;
  ABS_WrngLmpSta ABS_WrngLmpSta;
  BRK_AutoDrvBrkSta BRK_AutoDrvBrkSta;
  EBD_DfctvSta EBD_DfctvSta;
  EBD_WrngLmpSta EBD_WrngLmpSta;
  ESC_BrkLtActSta ESC_BrkLtActSta;
  ESS_Sta ESS_Sta;
} COM_DT_SG_ABS_ESC_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS101_2Gen_SignalGroup
typedef struct
{
  ADAS101_AlvCntVal_t_1 ADAS101_AlvCntVal;
  ADAS101_CrcVal_t_1 ADAS101_CrcVal;
  CALR_t_1 CALR;
  p_CF_ECU_SSC_STAT_t p_CF_ECU_SSC_STAT;
  p_CF_Ems_IsgStat_t p_CF_Ems_IsgStat;
  p_CF_Gway_InhibitRMT_t_1 p_CF_Gway_InhibitRMT;
  p_CR_Fatc_OutTemp_t_1 p_CR_Fatc_OutTemp;
  p_ENG_Stat_t p_Eng_Stat;
  p_G_Sel_Disp_t p_G_Sel_Disp;
  p_SAS_Angle_t p_SAS_Angle;
  p_WHL_SpdFL_t_1 p_WHL_SpdFL;
  p_WHL_SpdFR_t_1 p_WHL_SpdFR;
  p_WHL_SpdRL_t_1 p_WHL_SpdRL;
  p_WHL_SpdRR_t_1 p_WHL_SpdRR;
  p_Yaw_rate_t_1 p_Yaw_rate;
  VN_t_2 VN;
} COM_DT_SG_ADAS101_2Gen_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS101_3Gen_SignalGroup
typedef struct
{
  COM_DT_ADAS101_AlvCntVal_1 ADAS101_AlvCntVal;
  COM_DT_ADAS101_CrcVal_1 ADAS101_CrcVal;
  COM_DT_CALR_1 CALR;
  COM_DT_p_ABS_DiagSta p_ABS_DiagSta;
  COM_DT_p_CF_ECU_SSC_STAT p_CF_ECU_SSC_STAT;
  COM_DT_p_CLU_OutTempCSta_1 p_CLU_OutTempCSta;
  COM_DT_p_ENG_EngSta p_ENG_EngSta;
  COM_DT_p_ENG_IsgSta p_ENG_IsgSta;
  COM_DT_p_HCU_HevRdySta p_HCU_HevRdySta;
  COM_DT_p_ICU_MtGearPosRSta p_ICU_MtGearPosRSta;
  COM_DT_p_SAS_AnglVal_1 p_SAS_AnglVal;
  COM_DT_p_TCU_GearSlctDis p_TCU_GearSlctDis;
  COM_DT_p_WHL_SpdFLVal_1 p_WHL_SpdFLVal;
  COM_DT_p_WHL_SpdFRVal_1 p_WHL_SpdFRVal;
  COM_DT_p_WHL_SpdRLVal_1 p_WHL_SpdRLVal;
  COM_DT_p_WHL_SpdRRVal_1 p_WHL_SpdRRVal;
  COM_DT_p_YRS_YawRtVal_1 p_YRS_YawRtVal;
  COM_DT_VN_1 VN;
} COM_DT_SG_ADAS101_3Gen_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup
typedef struct
{
  ADAS_CMD_AlvCnt10Val_1 ADAS_CMD_AlvCnt10Val;
  ADAS_CMD_Crc10Val_1 ADAS_CMD_Crc10Val;
  FCA_DclReqVal_1 FCA_DclReqVal;
  FCA_FullActvReq FCA_FullActvReq;
  FCA_HydrlcBstAsstReq FCA_HydrlcBstAsstReq;
  FCA_PartialActvReq FCA_PartialActvReq;
  FCA_PrefillActvReq FCA_PrefillActvReq;
  FCA_RelVel_1 FCA_RelVel;
  FCA_StbltActvReq FCA_StbltActvReq;
  FCA_SysFlrSta FCA_SysFlrSta;
  FCA_TimetoCllsn_1 FCA_TimetoCllsn;
  FCA_VehStpReq FCA_VehStpReq;
  FCA_WrngLvlSta FCA_WrngLvlSta;
  FCA_WrngSndSta FCA_WrngSndSta;
  FCA_WrngTrgtDis FCA_WrngTrgtDis;
  ADAS_InhbtOffDispSta ADAS_InhbtOffDispSta;
  ADAS_TrlOffStaDisp ADAS_TrlOffStaDisp;
  EM_WrngLvlSta EM_WrngLvlSta;
  FCA_FrOnOffEquipSta FCA_FrOnOffEquipSta;
  FCA_Regulation FCA_Regulation;
  FCA_WarnTimeSta FCA_WarnTimeSta;
  HDP_EMOpSta HDP_EMOpSta;
  Nmode_FCAOff_Sta Nmode_FCAOff_Sta;
  FCA_OnOffEquipSta FCA_OnOffEquipSta;
} COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup
typedef struct
{
  ADAS_CMD_AlvCnt20Val ADAS_CMD_AlvCnt20Val;
  ADAS_CMD_Crc20Val ADAS_CMD_Crc20Val;
  SCC_AccelLimBandLwrVal SCC_AccelLimBandLwrVal;
  SCC_AccelLimBandUppVal SCC_AccelLimBandUppVal;
  SCC_AccelReqRawVal SCC_AccelReqRawVal;
  SCC_AccelReqVal SCC_AccelReqVal;
  SCC_DrvAlrtDis SCC_DrvAlrtDis;
  SCC_EngStateReq SCC_EngStateReq;
  SCC_HeadwayDstSetVal SCC_HeadwayDstSetVal;
  SCC_InfoDis SCC_InfoDis;
  SCC_JrkLwrLimVal SCC_JrkLwrLimVal;
  SCC_JrkUppLimVal SCC_JrkUppLimVal;
  SCC_MainOnOffSta SCC_MainOnOffSta;
  SCC_NSCCInfoPUDis SCC_NSCCInfoPUDis;
  SCC_NSCCOnOffSta SCC_NSCCOnOffSta;
  SCC_NSCCOpSta SCC_NSCCOpSta;
  SCC_ObjDstVal SCC_ObjDstVal;
  SCC_ObjLatPosVal SCC_ObjLatPosVal;
  SCC_ObjRelSpdVal SCC_ObjRelSpdVal;
  SCC_ObjSta SCC_ObjSta;
  SCC_OpSta SCC_OpSta;
  SCC_SnstvtyModRetVal SCC_SnstvtyModRetVal;
  SCC_SysFlrSta SCC_SysFlrSta;
  SCC_TakeoverReq SCC_TakeoverReq;
  SCC_TrgtDstVal SCC_TrgtDstVal;
  SCC_TrgtSpdSetVal SCC_TrgtSpdSetVal;
  SCC_VehStpReq SCC_VehStpReq;
  ADAS_DrUnlckReqSta ADAS_DrUnlckReqSta;
  ADAS_HzrdLmpReqVal ADAS_HzrdLmpReqVal;
  NSCC_Op2Sta NSCC_Op2Sta;
} COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_CMD_AlvCnt21Val ADAS_CMD_AlvCnt21Val;
  COM_DT_ADAS_CMD_Crc21Val ADAS_CMD_Crc21Val;
  COM_DT_SCC_Char1Sta SCC_Char1Sta;
  COM_DT_SCC_Char2Sta SCC_Char2Sta;
  COM_DT_SCC_Char3Sta SCC_Char3Sta;
  COM_DT_SCC_ML_OnOffEquipSta SCC_ML_OnOffEquipSta;
} COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_ActToiSta ADAS_ActToiSta;
  COM_DT_ADAS_CMD_AlvCnt30Val ADAS_CMD_AlvCnt30Val;
  COM_DT_ADAS_CMD_Crc30Val ADAS_CMD_Crc30Val;
  COM_DT_ADAS_Damping_Gain ADAS_Damping_Gain;
  COM_DT_ADAS_StrTqReqVal ADAS_StrTqReqVal;
  COM_DT_ADAS_ToiFltSta ADAS_ToiFltSta;
  COM_DT_LKA_HndsoffSnd LKA_HndsoffSnd;
  COM_DT_LKA_LHLnWrnSta LKA_LHLnWrnSta;
  COM_DT_LKA_RcgSta LKA_RcgSta;
  COM_DT_LKA_RHLnWrnSta LKA_RHLnWrnSta;
  COM_DT_LKA_SysIndReq LKA_SysIndReq;
  COM_DT_LKA_SysWrn LKA_SysWrn;
  COM_DT_BCA_Rear_WrnSta BCA_Rear_WrnSta;
  COM_DT_ELK_SymbDisp ELK_SymbDisp;
  COM_DT_ELK_SysFlrSta ELK_SysFlrSta;
  COM_DT_FCA_ESA_CtrlSta FCA_ESA_CtrlSta;
  COM_DT_FCA_ESA_WrnSta FCA_ESA_WrnSta;
  COM_DT_FCA_LO_WrnSta FCA_LO_WrnSta;
  COM_DT_FCA_LS_WrnSta FCA_LS_WrnSta;
  COM_DT_LKA_OnOffEquip2Sta LKA_OnOffEquip2Sta;
  COM_DT_LKA_WarnSndUSMSta LKA_WarnSndUSMSta;
} COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_CMD_AlvCnt31Val ADAS_CMD_AlvCnt31Val;
  COM_DT_ADAS_CMD_Crc31Val ADAS_CMD_Crc31Val;
  COM_DT_HDA_CntrlModSta HDA_CntrlModSta;
  COM_DT_HDA_InfoPUDis HDA_InfoPUDis;
  COM_DT_HDA_InfoPUDis1 HDA_InfoPUDis1;
  COM_DT_HDA_LFA_SymSta HDA_LFA_SymSta;
  COM_DT_HDA_LFA_WrnSnd HDA_LFA_WrnSnd;
  COM_DT_HDA_OptUsmSta HDA_OptUsmSta;
  COM_DT_HDA_TDMRMDclReq HDA_TDMRMDclReq;
  COM_DT_ADAS_DRV_UpDateInfo ADAS_DRV_UpDateInfo;
  COM_DT_HDP_ActvSta HDP_ActvSta;
  COM_DT_HDP_AutoCallReqSta HDP_AutoCallReqSta;
  COM_DT_HDP_CtRoadSrfcDistVal HDP_CtRoadSrfcDistVal;
  COM_DT_HDP_DispBarSta HDP_DispBarSta;
  COM_DT_HDP_FailureMode HDP_FailureMode;
  COM_DT_HDP_InhbtOffDispSta HDP_InhbtOffDispSta;
  COM_DT_HDP_OptInfoSta HDP_OptInfoSta;
  COM_DT_HDP_SysSta HDP_SysSta;
} COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_ACIAnglTqRedcGainVal ADAS_ACIAnglTqRedcGainVal;
  COM_DT_ADAS_ActvACILvl2Sta ADAS_ActvACILvl2Sta;
  COM_DT_ADAS_ActvACISta ADAS_ActvACISta;
  COM_DT_ADAS_CMD_AlvCnt35Val ADAS_CMD_AlvCnt35Val;
  COM_DT_ADAS_CMD_Crc35Val ADAS_CMD_Crc35Val;
  COM_DT_ADAS_StrAnglReqVal ADAS_StrAnglReqVal;
  COM_DT_FCA_ESA_ActvSta FCA_ESA_ActvSta;
  COM_DT_FCA_ESA_TqBstGainVal FCA_ESA_TqBstGainVal;
} COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_INFO_AlvCnt1Val ADAS_INFO_AlvCnt1Val;
  COM_DT_ADAS_INFO_Crc1Val ADAS_INFO_Crc1Val;
  COM_DT_VAR_Opt1Sta VAR_Opt1Sta;
} COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup
typedef struct
{
  COM_DT_RSPA_Sta RSPA_Sta;
  COM_DT_ADAS_PRK_AlvCnt3Val ADAS_PRK_AlvCnt3Val;
  COM_DT_ADAS_PRK_Crc3Val ADAS_PRK_Crc3Val;
  COM_DT_RSPA_Actv RSPA_Actv;
  COM_DT_RSPA_AddtnlAccelActv RSPA_AddtnlAccelActv;
  COM_DT_RSPA_AvnDis RSPA_AvnDis;
  COM_DT_RSPA_AvnHmiDis RSPA_AvnHmiDis;
  COM_DT_RSPA_AvnModDis RSPA_AvnModDis;
  COM_DT_RSPA_AvnSubViewDis RSPA_AvnSubViewDis;
  COM_DT_RSPA_CrankingReq RSPA_CrankingReq;
  COM_DT_RSPA_DccCmd RSPA_DccCmd;
  COM_DT_RSPA_DCTTrgtTqVal RSPA_DCTTrgtTqVal;
  COM_DT_RSPA_EpbReq RSPA_EpbReq;
  COM_DT_RSPA_EvasiveStrBtnDis RSPA_EvasiveStrBtnDis;
  COM_DT_RSPA_ExtLampReq RSPA_ExtLampReq;
  COM_DT_RSPA_HdLmpReq RSPA_HdLmpReq;
  COM_DT_RSPA_IdOutWarnReq RSPA_IdOutWarnReq;
  COM_DT_RSPA_IndBlnkReq RSPA_IndBlnkReq;
  COM_DT_RSPA_LwrLtTypDis RSPA_LwrLtTypDis;
  COM_DT_RSPA_LwrRtTypDis RSPA_LwrRtTypDis;
  COM_DT_RSPA_Opt RSPA_Opt;
  COM_DT_RSPA_OSMirFoldReq RSPA_OSMirFoldReq;
  COM_DT_RSPA_RmtPrlExitDis RSPA_RmtPrlExitDis;
  COM_DT_RSPA_SelDevInfo RSPA_SelDevInfo;
  COM_DT_RSPA_SelFuncInfo RSPA_SelFuncInfo;
  COM_DT_RSPA_StopReq RSPA_StopReq;
  COM_DT_RSPA_SysOff RSPA_SysOff;
  COM_DT_RSPA_TrgtGearSta RSPA_TrgtGearSta;
  COM_DT_RSPA_TrgtTqVal RSPA_TrgtTqVal;
  COM_DT_RSPA_TrgtVehSpdVal RSPA_TrgtVehSpdVal;
  COM_DT_RSPA_UppLtTypDis RSPA_UppLtTypDis;
  COM_DT_RSPA_UppRtTypDis RSPA_UppRtTypDis;
  COM_DT_RSPA_Var RSPA_Var;
} COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_UX_01_50ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_UX_AlvCnt1Val ADAS_UX_AlvCnt1Val;
  COM_DT_ADAS_UX_Crc1Val ADAS_UX_Crc1Val;
  COM_DT_BG_HDP_Sta BG_HDP_Sta;
  COM_DT_MV_CtRoadSrfcDstVal MV_CtRoadSrfcDstVal;
  COM_DT_MV_CtRoadSrfcSta MV_CtRoadSrfcSta;
  COM_DT_MV_DrvLnCtLnSta MV_DrvLnCtLnSta;
  COM_DT_MV_DrvLnRdsVal MV_DrvLnRdsVal;
  COM_DT_MV_FrLtObjMvngDirSta MV_FrLtObjMvngDirSta;
  COM_DT_MV_FrLtRdrWaveSta MV_FrLtRdrWaveSta;
  COM_DT_MV_FrRdrWaveSta MV_FrRdrWaveSta;
  COM_DT_MV_FrRtObjMvngDirSta MV_FrRtObjMvngDirSta;
  COM_DT_MV_FrRtRdrWaveSta MV_FrRtRdrWaveSta;
  COM_DT_MV_HostVeh1Sta MV_HostVeh1Sta;
  COM_DT_MV_LtLCDirSta MV_LtLCDirSta;
  COM_DT_MV_LtLnOffstVal MV_LtLnOffstVal;
  COM_DT_MV_LtLnSta MV_LtLnSta;
  COM_DT_MV_LtRoadSrfcSta MV_LtRoadSrfcSta;
  COM_DT_MV_RrLtRdrWave1Sta MV_RrLtRdrWave1Sta;
  COM_DT_MV_RrRtRdrWave1Sta MV_RrRtRdrWave1Sta;
  COM_DT_MV_RtLCDirSta MV_RtLCDirSta;
  COM_DT_MV_RtLnOffstVal MV_RtLnOffstVal;
  COM_DT_MV_RtLnSta MV_RtLnSta;
  COM_DT_MV_RtRoadSrfcSta MV_RtRoadSrfcSta;
  COM_DT_MV_VehDstSta MV_VehDstSta;
  COM_DT_MV_VehDstVal MV_VehDstVal;
  COM_DT_PU_F_Group1_ADASWarn1_1Sta PU_F_Group1_ADASWarn1_1Sta;
  COM_DT_PU_F_Group1_ADASWarn1_2Sta PU_F_Group1_ADASWarn1_2Sta;
  COM_DT_PU_F_Group4_ADASWarn1_1Sta PU_F_Group4_ADASWarn1_1Sta;
  COM_DT_PU_M_Group2_ADASWarn1_1Sta PU_M_Group2_ADASWarn1_1Sta;
  COM_DT_PU_M_Group2_ADASWarn1_2Sta PU_M_Group2_ADASWarn1_2Sta;
  COM_DT_SMV_DrvAsstHUDSymbSta SMV_DrvAsstHUDSymbSta;
  COM_DT_SMV_FrObjSta SMV_FrObjSta;
  COM_DT_SMV_HDA_SymbSta SMV_HDA_SymbSta;
  COM_DT_SMV_HostVehSta SMV_HostVehSta;
  COM_DT_SMV_ISLA_SetSpdSymbSta SMV_ISLA_SetSpdSymbSta;
  COM_DT_SMV_LCA_LtSymbSta SMV_LCA_LtSymbSta;
  COM_DT_SMV_LCA_RtSymbSta SMV_LCA_RtSymbSta;
  COM_DT_SMV_LFA_SymbSta SMV_LFA_SymbSta;
  COM_DT_SMV_NSCC_SymbSta SMV_NSCC_SymbSta;
  COM_DT_SMV_SetSpdSta SMV_SetSpdSta;
  COM_DT_SMV_SetSpdVal SMV_SetSpdVal;
  COM_DT_SMV_VehDstLvlSta SMV_VehDstLvlSta;
  COM_DT_SMV_VehDstLvlVal SMV_VehDstLvlVal;
  COM_DT_SND_ADASWarn1_1Sta SND_ADASWarn1_1Sta;
  COM_DT_SND_ADASWarn1_2Sta SND_ADASWarn1_2Sta;
  COM_DT_SND_ADASWarn1_3Sta SND_ADASWarn1_3Sta;
  COM_DT_SND_ADASWarn1_4Sta SND_ADASWarn1_4Sta;
  COM_DT_SND_ADASWarn1_5Sta SND_ADASWarn1_5Sta;
  COM_DT_TT_DAW_SymbSta TT_DAW_SymbSta;
  COM_DT_TT_EmergStrSymbSta TT_EmergStrSymbSta;
  COM_DT_TT_FwdSftySymbSta TT_FwdSftySymbSta;
  COM_DT_TT_HBA_SymbSta TT_HBA_SymbSta;
  COM_DT_TT_LnSftySymbSta TT_LnSftySymbSta;
} COM_DT_SG_ADAS_UX_01_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ADAS_UX_02_50ms_SignalGroup
typedef struct
{
  COM_DT_ADAS_UX_AlvCnt2Val ADAS_UX_AlvCnt2Val;
  COM_DT_ADAS_UX_Crc2Val ADAS_UX_Crc2Val;
  COM_DT_HPT_StbltWarn1Sta HPT_StbltWarn1Sta;
  COM_DT_HPT_StrWhlWarn1Sta HPT_StrWhlWarn1Sta;
  COM_DT_MV_FrLtObjLatPosVal MV_FrLtObjLatPosVal;
  COM_DT_MV_FrLtObjLongPosVal MV_FrLtObjLongPosVal;
  COM_DT_MV_FrLtObjSta MV_FrLtObjSta;
  COM_DT_MV_FrObjLatPosVal MV_FrObjLatPosVal;
  COM_DT_MV_FrObjLongPosVal MV_FrObjLongPosVal;
  COM_DT_MV_FrObjSta MV_FrObjSta;
  COM_DT_MV_FrObstLatPosVal MV_FrObstLatPosVal;
  COM_DT_MV_FrObstLongPosVal MV_FrObstLongPosVal;
  COM_DT_MV_FrObstSta MV_FrObstSta;
  COM_DT_MV_FrRtObjLatPosVal MV_FrRtObjLatPosVal;
  COM_DT_MV_FrRtObjLongPosVal MV_FrRtObjLongPosVal;
  COM_DT_MV_FrRtObjSta MV_FrRtObjSta;
  COM_DT_MV_LtObjLatPosVal MV_LtObjLatPosVal;
  COM_DT_MV_LtObjLongPosVal MV_LtObjLongPosVal;
  COM_DT_MV_LtObjSta MV_LtObjSta;
  COM_DT_MV_RtObjLatPosVal MV_RtObjLatPosVal;
  COM_DT_MV_RtObjLongPosVal MV_RtObjLongPosVal;
  COM_DT_MV_RtObjSta MV_RtObjSta;
  COM_DT_PU_F_Group7_DAW_FlrSta PU_F_Group7_DAW_FlrSta;
  COM_DT_PU_F_Group7_DrvrAsstFlr1Sta PU_F_Group7_DrvrAsstFlr1Sta;
  COM_DT_PU_F_Group7_FwdSdSftyFlrSta PU_F_Group7_FwdSdSftyFlrSta;
  COM_DT_PU_F_Group7_FwdSftyFlrSta PU_F_Group7_FwdSftyFlrSta;
  COM_DT_PU_F_Group7_HBA_FlrSta PU_F_Group7_HBA_FlrSta;
  COM_DT_PU_F_Group7_HDA_FlrSta PU_F_Group7_HDA_FlrSta;
  COM_DT_PU_F_Group7_HDP_FlrSta PU_F_Group7_HDP_FlrSta;
  COM_DT_PU_F_Group7_ISLA_FlrSta PU_F_Group7_ISLA_FlrSta;
  COM_DT_PU_F_Group7_LCA_FlrSta PU_F_Group7_LCA_FlrSta;
  COM_DT_PU_F_Group7_LFA_FlrSta PU_F_Group7_LFA_FlrSta;
  COM_DT_PU_F_Group7_LnSftyFlrSta PU_F_Group7_LnSftyFlrSta;
  COM_DT_PU_F_Group7_MRM_FlrSta PU_F_Group7_MRM_FlrSta;
  COM_DT_PU_F_Group7_SCC_FlrSta PU_F_Group7_SCC_FlrSta;
  COM_DT_TT_ISLA_AddtnlTrffcSgnSta TT_ISLA_AddtnlTrffcSgnSta;
  COM_DT_TT_ISLA_SpdLimTrffcSgnSta TT_ISLA_SpdLimTrffcSgnSta;
  COM_DT_TT_ISLA_SpdLimTrffcSgnVal TT_ISLA_SpdLimTrffcSgnVal;
  COM_DT_TT_ISLA_SuppTrffcSgnSta TT_ISLA_SuppTrffcSgnSta;
  COM_DT_TT_ISLA_TrffcSgnCntryInfoSta TT_ISLA_TrffcSgnCntryInfoSta;
} COM_DT_SG_ADAS_UX_02_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_BCM_07_200ms_SignalGroup
typedef struct
{
  COM_DT_BCM_AlvCnt7Val BCM_AlvCnt7Val;
  COM_DT_BCM_Crc7Val BCM_Crc7Val;
  COM_DT_Lamp_AvTailLmpSta Lamp_AvTailLmpSta;
  COM_DT_Lamp_BckUpLmpCmd Lamp_BckUpLmpCmd;
  COM_DT_Lamp_DrlOnReq Lamp_DrlOnReq;
  COM_DT_Lamp_ExtrnlTailLmpOnReq Lamp_ExtrnlTailLmpOnReq;
  COM_DT_Lamp_HdLmpHiOnReq Lamp_HdLmpHiOnReq;
  COM_DT_Lamp_HdLmpLoOnReq Lamp_HdLmpLoOnReq;
  COM_DT_Lamp_HiPrioHzrdReq Lamp_HiPrioHzrdReq;
  COM_DT_Lamp_IntTailLmpOnReq Lamp_IntTailLmpOnReq;
  COM_DT_Lamp_LoPrioHzrdReq Lamp_LoPrioHzrdReq;
  COM_DT_USM_IllAlwaysOnwithPSTNSta USM_IllAlwaysOnwithPSTNSta;
} COM_DT_SG_BCM_07_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_BCM_08_200ms_SignalGroup
typedef struct
{
  COM_DT_BCM_AlvCnt8Val BCM_AlvCnt8Val;
  COM_DT_BCM_Crc8Val BCM_Crc8Val;
  COM_DT_Lamp_HbaCtrlModTyp Lamp_HbaCtrlModTyp;
  COM_DT_Lamp_BLEWelcomeSig Lamp_BLEWelcomeSig;
  COM_DT_Lamp_BLEWlcmCmd Lamp_BLEWlcmCmd;
  COM_DT_Lamp_CornerLmpLftOnReq Lamp_CornerLmpLftOnReq;
  COM_DT_Lamp_CornerLmpRtOnReq Lamp_CornerLmpRtOnReq;
  COM_DT_Lamp_ExtLampRSPAMode Lamp_ExtLampRSPAMode;
  COM_DT_Lamp_FrFogLmpOnReq Lamp_FrFogLmpOnReq;
  COM_DT_Lamp_HdLmpWlcmCmd Lamp_HdLmpWlcmCmd;
  COM_DT_Lamp_IFSCtrlModTyp Lamp_IFSCtrlModTyp;
  COM_DT_Lamp_PuddleLmpOnReq Lamp_PuddleLmpOnReq;
  COM_DT_Lamp_RrFogLmpOnReq Lamp_RrFogLmpOnReq;
  COM_DT_Lamp_StcBendingLmpLftOnReq Lamp_StcBendingLmpLftOnReq;
  COM_DT_Lamp_StcBendingLmpRtOnReq Lamp_StcBendingLmpRtOnReq;
} COM_DT_SG_BCM_08_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_BCM_10_200ms_SignalGroup
typedef struct
{
  COM_DT_BCM_AlvCnt10Val BCM_AlvCnt10Val;
  COM_DT_BCM_Crc10Val BCM_Crc10Val;
  COM_DT_Wiper_PrkngPosSta Wiper_PrkngPosSta;
  COM_DT_BCM_GearPosPSta BCM_GearPosPSta;
  COM_DT_BCM_SolSnsrLft BCM_SolSnsrLft;
  COM_DT_BCM_SolSnsrRt BCM_SolSnsrRt;
  COM_DT_BCM_SunRoofOpnSta BCM_SunRoofOpnSta;
  COM_DT_SunRoof_RrBlindErrSta SunRoof_RrBlindErrSta;
  COM_DT_Wiper_AutoWashModeSta Wiper_AutoWashModeSta;
  COM_DT_Wiper_HtWshNzzlCmd Wiper_HtWshNzzlCmd;
  COM_DT_Wiper_RainSnsrOptionTyp Wiper_RainSnsrOptionTyp;
  COM_DT_Wiper_RainSnsrPartNum Wiper_RainSnsrPartNum;
  COM_DT_Wiper_RainSnsrSta Wiper_RainSnsrSta;
} COM_DT_SG_BCM_10_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_BCM_13_200ms_SignalGroup
typedef struct
{
  COM_DT_Haptic_USMCurState_OnOff Haptic_USMCurState_OnOff;
} COM_DT_SG_BCM_13_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_01_20ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AlvCnt1Val CLU_AlvCnt1Val;
  COM_DT_CLU_Crc1Val CLU_Crc1Val;
  COM_DT_CLU_DisSpdVal CLU_DisSpdVal;
  COM_DT_CLU_SpdUnitTyp CLU_SpdUnitTyp;
  COM_DT_CLU_SWRCCrsMainSwSta CLU_SWRCCrsMainSwSta;
  COM_DT_CLU_SWRCCrsSwSta CLU_SWRCCrsSwSta;
  COM_DT_CLU_SWRCLFASwSta CLU_SWRCLFASwSta;
  COM_DT_CLU_SWRCSldMainSwSta CLU_SWRCSldMainSwSta;
  COM_DT_CLU_AutoBrightSta CLU_AutoBrightSta;
  COM_DT_CLU_CUSTOMSta_NEW CLU_CUSTOMSta_NEW;
  COM_DT_CLU_DisSpdDcmlVal CLU_DisSpdDcmlVal;
  COM_DT_CLU_DisSpdVal_KPH CLU_DisSpdVal_KPH;
  COM_DT_CLU_DtntOutSta CLU_DtntOutSta;
  COM_DT_CLU_OKSwSta CLU_OKSwSta;
  COM_DT_CLU_PwrAutoOffResetReq_HCU CLU_PwrAutoOffResetReq_HCU;
  COM_DT_CLU_RhstaLvlSta CLU_RhstaLvlSta;
} COM_DT_SG_CLU_01_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_02_100ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AlvCnt2Val CLU_AlvCnt2Val;
  COM_DT_CLU_Crc2Val CLU_Crc2Val;
  COM_DT_CLU_DrvngModSwSta CLU_DrvngModSwSta;
  COM_DT_CLU_IceWrnIndSta CLU_IceWrnIndSta;
  COM_DT_CLU_OdoVal_1 CLU_OdoVal;
  COM_DT_CLU_DTEVal CLU_DTEVal;
  COM_DT_CLU_FuelLvlSta CLU_FuelLvlSta;
  COM_DT_CLU_LngSta CLU_LngSta;
  COM_DT_CLU_LoFuelWrngSta CLU_LoFuelWrngSta;
  COM_DT_CLU_RefuelDetSta CLU_RefuelDetSta;
  COM_DT_CLU_RefuelWrnSta CLU_RefuelWrnSta;
  COM_DT_CLU_SRSWrngLmpSta CLU_SRSWrngLmpSta;
  COM_DT_CLU_TerrainMainSwSta CLU_TerrainMainSwSta;
  COM_DT_CLU_TerrainModSwSta CLU_TerrainModSwSta;
  COM_DT_CLU_TripUnitSta CLU_TripUnitSta;
} COM_DT_SG_CLU_02_100ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_04_00ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AlvCnt4Val CLU_AlvCnt4Val;
  COM_DT_CLU_Crc4Val CLU_Crc4Val;
  COM_DT_CLU_EngOilChngChkSetReq CLU_EngOilChngChkSetReq;
  COM_DT_CLU_ISGoperationTimeRstReq CLU_ISGoperationTimeRstReq;
  COM_DT_USM_AdasISLAAutoSetReq USM_AdasISLAAutoSetReq;
  COM_DT_USM_AdasISLANAOffstSetReq USM_AdasISLANAOffstSetReq;
  COM_DT_USM_AdasISLASetReq USM_AdasISLASetReq;
  COM_DT_USM_AdasLKAWrngVolSetReq USM_AdasLKAWrngVolSetReq;
  COM_DT_USM_AdasSEAnewSetReq USM_AdasSEAnewSetReq;
  COM_DT_USM_AdasSEWnewSetReq USM_AdasSEWnewSetReq;
  COM_DT_USM_ChgGuideMdLvlSetReq USM_ChgGuideMdLvlSetReq;
  COM_DT_USM_EngOilChaRstSetReq USM_EngOilChaRstSetReq;
  COM_DT_USM_ISLAOffstSetReq USM_ISLAOffstSetReq;
} COM_DT_SG_CLU_04_00ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_12_00ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AlvCnt12Val CLU_AlvCnt12Val;
  COM_DT_CLU_Crc12Val CLU_Crc12Val;
  COM_DT_USM_AdasDAWModSetReq USM_AdasDAWModSetReq;
  COM_DT_USM_AdasFCASetReq USM_AdasFCASetReq;
  COM_DT_USM_AdasHDASetReq USM_AdasHDASetReq;
  COM_DT_USM_AdasISLWSetReq USM_AdasISLWSetReq;
  COM_DT_USM_AdasLVDASetReq USM_AdasLVDASetReq;
  COM_DT_USM_AdasNSCCCamSetReq USM_AdasNSCCCamSetReq;
  COM_DT_USM_AdasSCCDrvModSetReq USM_AdasSCCDrvModSetReq;
  COM_DT_USM_AdasUSMResetReq USM_AdasUSMResetReq;
  COM_DT_USM_AdasWrngTimingSetReq USM_AdasWrngTimingSetReq;
  COM_DT_USM_AdasBCASetReq USM_AdasBCASetReq;
  COM_DT_USM_AdasBCWSetReq USM_AdasBCWSetReq;
  COM_DT_USM_AdasBVMSetReq USM_AdasBVMSetReq;
  COM_DT_USM_AdasLFASetReq USM_AdasLFASetReq;
  COM_DT_USM_AdasNSCCCrvSetReq USM_AdasNSCCCrvSetReq;
  COM_DT_USM_AdasRCCANSetReq USM_AdasRCCANSetReq;
  COM_DT_USM_AdasSEASetReq USM_AdasSEASetReq;
} COM_DT_SG_CLU_12_00ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_13_00ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AdasDAWResetReq CLU_AdasDAWResetReq;
  COM_DT_CLU_AlvCnt13Val CLU_AlvCnt13Val;
  COM_DT_CLU_Crc13Val CLU_Crc13Val;
  COM_DT_USM_AdasDAWModNewSetReq USM_AdasDAWModNewSetReq;
  COM_DT_USM_AdasHbaSetReq USM_AdasHbaSetReq;
  COM_DT_USM_AdasLkaModSetReq USM_AdasLkaModSetReq;
  COM_DT_USM_AdasBCWSndSetReq USM_AdasBCWSndSetReq;
  COM_DT_USM_AdasFCAJnctnSetReq USM_AdasFCAJnctnSetReq;
  COM_DT_USM_AdasHDALCFuncSetReq USM_AdasHDALCFuncSetReq;
  COM_DT_USM_AdasHptWrngSetReq USM_AdasHptWrngSetReq;
  COM_DT_USM_AdasPCA_RrStaSetReq USM_AdasPCA_RrStaSetReq;
  COM_DT_USM_AdasPDWAutoOnSetReq USM_AdasPDWAutoOnSetReq;
  COM_DT_USM_AdasRCCWSetReq USM_AdasRCCWSetReq;
  COM_DT_USM_AdasSCCMLChar1SetReq USM_AdasSCCMLChar1SetReq;
  COM_DT_USM_AdasSCCMLChar2SetReq USM_AdasSCCMLChar2SetReq;
  COM_DT_USM_AdasSCCMLChar3SetReq USM_AdasSCCMLChar3SetReq;
  COM_DT_USM_AdasSCCMLResetReq USM_AdasSCCMLResetReq;
  COM_DT_USM_AdasSCCModeSetReq USM_AdasSCCModeSetReq;
  COM_DT_USM_AdasSVMAutoOnSetReq USM_AdasSVMAutoOnSetReq;
} COM_DT_SG_CLU_13_00ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_14_200ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AdasWarnSndStat CLU_AdasWarnSndStat;
  COM_DT_CLU_AlvCnt14Val CLU_AlvCnt14Val;
  COM_DT_CLU_Crc14Val CLU_Crc14Val;
  COM_DT_USM_Clu3dDepthSta USM_Clu3dDepthSta;
  COM_DT_USM_CluAdasVolSta USM_CluAdasVolSta;
  COM_DT_USM_CluFuelEconomySta USM_CluFuelEconomySta;
  COM_DT_USM_CluVcAlrmVolSta USM_CluVcAlrmVolSta;
  COM_DT_USM_FuelEconomySetSta USM_FuelEconomySetSta;
  COM_DT_Wrn_Snd_AdasVolFdbck Wrn_Snd_AdasVolFdbck;
} COM_DT_SG_CLU_14_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CLU_25_00ms_SignalGroup
typedef struct
{
  COM_DT_CLU_AlvCnt25Val CLU_AlvCnt25Val;
  COM_DT_CLU_Crc25Val CLU_Crc25Val;
  COM_DT_USM_AdasBCA2SetReq USM_AdasBCA2SetReq;
  COM_DT_USM_AdasBVM2SetReq USM_AdasBVM2SetReq;
  COM_DT_USM_AdasFCAFrSdSetReq USM_AdasFCAFrSdSetReq;
  COM_DT_USM_AdasFCAFrSetReq USM_AdasFCAFrSetReq;
  COM_DT_USM_AdasFCAJcSetReq USM_AdasFCAJcSetReq;
  COM_DT_USM_AdasISLAEUCntry1SetReq USM_AdasISLAEUCntry1SetReq;
  COM_DT_USM_AdasISLAEUCntryTglReq USM_AdasISLAEUCntryTglReq;
  COM_DT_USM_AdasISLANACntry1SetReq USM_AdasISLANACntry1SetReq;
  COM_DT_USM_AdasISLANACntryTglReq USM_AdasISLANACntryTglReq;
  COM_DT_USM_AdasLKA2SetReq USM_AdasLKA2SetReq;
  COM_DT_USM_AdasSEA3SetReq USM_AdasSEA3SetReq;
  COM_DT_USM_AdasSEW3SetReq USM_AdasSEW3SetReq;
  COM_DT_USM_AdasWarnTimeSetReq USM_AdasWarnTimeSetReq;
  COM_DT_USM_AutoDrLkSetReq2 USM_AutoDrLkSetReq2;
  COM_DT_USM_PABArbgNValueSetReq USM_PABArbgNValueSetReq;
} COM_DT_SG_CLU_25_00ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CTM_01_200ms_SignalGroup
typedef struct
{
  COM_DT_CTM_Exra_EbrakSta CTM_Exra_EbrakSta;
  COM_DT_CTM_ExtTailLmpLftOpnSta CTM_ExtTailLmpLftOpnSta;
  COM_DT_CTM_ExtTailLmpRtOpnSta CTM_ExtTailLmpRtOpnSta;
  COM_DT_CTM_RearfogAct CTM_RearfogAct;
  COM_DT_CTM_StpLmpOpnSta CTM_StpLmpOpnSta;
  COM_DT_CTM_TrailerAct CTM_TrailerAct;
  COM_DT_CTM_TrnSigLmpLftOpnSta CTM_TrnSigLmpLftOpnSta;
  COM_DT_CTM_TrnSigLmpRtOpnSta CTM_TrnSigLmpRtOpnSta;
} COM_DT_SG_CTM_01_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_CodingForRadar
typedef struct
{
  COM_DT_u8_VehicleType u8_VehicleType;
} COM_DT_SG_CodingForRadar;

#  define Rte_TypeDef_COM_DT_SG_EMS_01_10ms_SignalGroup
typedef struct
{
  COM_DT_ENG_EngSpdErrSta ENG_EngSpdErrSta;
  COM_DT_ENG_EngSpdVal ENG_EngSpdVal;
  COM_DT_ENG_IsgSta ENG_IsgSta;
  COM_DT_ENG_SldSwSta ENG_SldSwSta;
  COM_DT_ENG_SldFuncSta ENG_SldFuncSta;
  COM_DT_ENG_VehSpdLimVal ENG_VehSpdLimVal;
  COM_DT_EMS_AlvCnt1Val EMS_AlvCnt1Val;
  COM_DT_EMS_Crc1Val EMS_Crc1Val;
  COM_DT_ENG_Ack4TcsSta ENG_Ack4TcsSta;
  COM_DT_ENG_AirCompRlySta ENG_AirCompRlySta;
  COM_DT_ENG_AirconPrsrSnsrVal ENG_AirconPrsrSnsrVal;
  COM_DT_ENG_CrctEngTqVal ENG_CrctEngTqVal;
  COM_DT_ENG_CrctTqSta ENG_CrctTqSta;
  COM_DT_ENG_DsrGearPosDis ENG_DsrGearPosDis;
  COM_DT_ENG_EcoDrvActvSta ENG_EcoDrvActvSta;
  COM_DT_ENG_EngInhbNCC ENG_EngInhbNCC;
  COM_DT_ENG_EngRunSta ENG_EngRunSta;
  COM_DT_ENG_EtcLmphModSta ENG_EtcLmphModSta;
  COM_DT_ENG_FrctTqVal ENG_FrctTqVal;
  COM_DT_ENG_FuelCapOpnSta ENG_FuelCapOpnSta;
  COM_DT_ENG_FuelCnsmptVal ENG_FuelCnsmptVal;
  COM_DT_ENG_FuelCutOffSta ENG_FuelCutOffSta;
  COM_DT_ENG_FuelTnkPrsrSta ENG_FuelTnkPrsrSta;
  COM_DT_ENG_GearShftDnDis ENG_GearShftDnDis;
  COM_DT_ENG_GearShftUpDis ENG_GearShftUpDis;
  COM_DT_ENG_IgnOnSta ENG_IgnOnSta;
  COM_DT_ENG_IndTqBVal ENG_IndTqBVal;
  COM_DT_ENG_IndTqVal ENG_IndTqVal;
  COM_DT_ENG_Isg2Sta ENG_Isg2Sta;
  COM_DT_ENG_IsgBzrReq ENG_IsgBzrReq;
  COM_DT_ENG_IsgFuelCnsmptDis ENG_IsgFuelCnsmptDis;
  COM_DT_ENG_LnchCntrlSta ENG_LnchCntrlSta;
  COM_DT_ENG_MafErrSta ENG_MafErrSta;
  COM_DT_ENG_MaxAirconTqVal ENG_MaxAirconTqVal;
  COM_DT_ENG_OilLvlSta ENG_OilLvlSta;
  COM_DT_ENG_SldActnSta ENG_SldActnSta;
  COM_DT_ENG_SldDrvAlertDisp ENG_SldDrvAlertDisp;
  COM_DT_ENG_SpltInjctnSta ENG_SpltInjctnSta;
  COM_DT_ENG_StndTqRatioVal ENG_StndTqRatioVal;
  COM_DT_ENG_TrgtFuelPmpPrsrVal ENG_TrgtFuelPmpPrsrVal;
  COM_DT_ENG_TrgtIdleRpmVal ENG_TrgtIdleRpmVal;
  COM_DT_ENG_VehSpdHiVal ENG_VehSpdHiVal;
} COM_DT_SG_EMS_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EMS_02_10ms_SignalGroup
typedef struct
{
  COM_DT_EMS_AlvCnt2Val EMS_AlvCnt2Val;
  COM_DT_EMS_Crc2Val EMS_Crc2Val;
  COM_DT_ENG_AccActSta ENG_AccActSta;
  COM_DT_ENG_AccelPdlVal ENG_AccelPdlVal;
  COM_DT_ENG_AppAccelPdlSta ENG_AppAccelPdlSta;
  COM_DT_ENG_EngSta ENG_EngSta;
  COM_DT_ACC_CrsMainSwLmpSta ACC_CrsMainSwLmpSta;
  COM_DT_ACC_CrsSetSwLmpSta ACC_CrsSetSwLmpSta;
  COM_DT_ACC_DnShftCtrlReq ACC_DnShftCtrlReq;
  COM_DT_DSL_GlowCtrlReq DSL_GlowCtrlReq;
  COM_DT_EMS_BrkReq_Slope EMS_BrkReq_Slope;
  COM_DT_ENG_AccDrvAlertDisp ENG_AccDrvAlertDisp;
  COM_DT_ENG_Ack4EngStpSta ENG_Ack4EngStpSta;
  COM_DT_ENG_AmbtTempModelVal ENG_AmbtTempModelVal;
  COM_DT_ENG_BattDscnctSta ENG_BattDscnctSta;
  COM_DT_ENG_BattWrngLmpSta ENG_BattWrngLmpSta;
  COM_DT_ENG_BrkCtrlReq ENG_BrkCtrlReq;
  COM_DT_ENG_BrkSwSta ENG_BrkSwSta;
  COM_DT_ENG_BstPrsrVal ENG_BstPrsrVal;
  COM_DT_ENG_CltchOpSta ENG_CltchOpSta;
  COM_DT_ENG_DclBrkCntrlReq ENG_DclBrkCntrlReq;
  COM_DT_ENG_DpfWrngSta ENG_DpfWrngSta;
  COM_DT_ENG_EngClntTempVal ENG_EngClntTempVal;
  COM_DT_ENG_EngOilTempVal ENG_EngOilTempVal;
  COM_DT_ENG_GlowLmpSta ENG_GlowLmpSta;
  COM_DT_ENG_IsgInhbtLmpSta ENG_IsgInhbtLmpSta;
  COM_DT_ENG_LV_FUP_ENA_THD ENG_LV_FUP_ENA_THD;
  COM_DT_ENG_MafCrctVal ENG_MafCrctVal;
  COM_DT_ENG_MaxIndTqVal ENG_MaxIndTqVal;
  COM_DT_ENG_MinIndTqVal ENG_MinIndTqVal;
  COM_DT_ENG_ObdFrzFrmSta ENG_ObdFrzFrmSta;
  COM_DT_ENG_OilPrsrWrngLmpSta ENG_OilPrsrWrngLmpSta;
  COM_DT_ENG_OverDrvOffReq ENG_OverDrvOffReq;
  COM_DT_ENG_SoakTimeErrSta ENG_SoakTimeErrSta;
  COM_DT_ENG_SoakTimeVal ENG_SoakTimeVal;
  COM_DT_ENG_SprkTimeVal ENG_SprkTimeVal;
  COM_DT_ENG_ThrPosVal ENG_ThrPosVal;
  COM_DT_ENG_TrgtTqVal ENG_TrgtTqVal;
  COM_DT_OBD_MilConfgVal OBD_MilConfgVal;
} COM_DT_SG_EMS_02_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EMS_03_10ms_SignalGroup
typedef struct
{
  COM_DT_CF_ECU_SSC_STAT CF_ECU_SSC_STAT;
  COM_DT_EMS_SCCIsgEna EMS_SCCIsgEna;
  COM_DT_CF_EMS_CltCtrlReq CF_EMS_CltCtrlReq;
  COM_DT_CF_EMS_KEYST CF_EMS_KEYST;
  COM_DT_CF_EMS_NEURALSW CF_EMS_NEURALSW;
  COM_DT_CF_EMS_SSC_Tgt CF_EMS_SSC_Tgt;
  COM_DT_DCT_BrkSwSta DCT_BrkSwSta;
  COM_DT_DCT_EngOpSta DCT_EngOpSta;
  COM_DT_DCT_EngSpdErrSta DCT_EngSpdErrSta;
  COM_DT_DCT_MafErrSta DCT_MafErrSta;
  COM_DT_DCT_MotCrctTqVal DCT_MotCrctTqVal;
  COM_DT_DCT_MotIndTqBVal DCT_MotIndTqBVal;
  COM_DT_DCT_MotIndTqVal DCT_MotIndTqVal;
  COM_DT_DCT_MotSpdVal DCT_MotSpdVal;
  COM_DT_EMS_AlvCnt3Val EMS_AlvCnt3Val;
  COM_DT_EMS_Crc3Val EMS_Crc3Val;
  COM_DT_ENG_48VOpIndiLmpReq ENG_48VOpIndiLmpReq;
  COM_DT_ENG_GearPos ENG_GearPos;
  COM_DT_ENG_MotRecupSta ENG_MotRecupSta;
  COM_DT_ENG_NCC_STATE ENG_NCC_STATE;
  COM_DT_Eng_OverRun Eng_OverRun;
  COM_DT_ENG_SysWarnLmpReq ENG_SysWarnLmpReq;
  COM_DT_SHIFT_IND_LED SHIFT_IND_LED;
  COM_DT_SSC_CLUEngSpd SSC_CLUEngSpd;
  COM_DT_SSC_CLUEngSpdFlag SSC_CLUEngSpdFlag;
  COM_DT_TgtEngRPM TgtEngRPM;
} COM_DT_SG_EMS_03_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EMS_05_100ms_SignalGroup
typedef struct
{
  COM_DT_AAF_WrnLamp AAF_WrnLamp;
  COM_DT_EMS_AlvCnt5Val_2 EMS_AlvCnt5Val;
  COM_DT_EMS_Crc5Val_2 EMS_Crc5Val;
  COM_DT_EMS_EngStallDis EMS_EngStallDis;
  COM_DT_EMS_PendingTrigSta EMS_PendingTrigSta;
  COM_DT_EMS_RECTrigDta EMS_RECTrigDta;
  COM_DT_EMS_SafetyFunctSta EMS_SafetyFunctSta;
  COM_DT_ENG_AltFdbckLoadVal_1 ENG_AltFdbckLoadVal;
  COM_DT_ENG_AtmsphPrsrVal_1 ENG_AtmsphPrsrVal;
  COM_DT_ENG_BattVoltVal_1 ENG_BattVoltVal;
  COM_DT_ENG_DpfRgnSta ENG_DpfRgnSta;
  COM_DT_ENG_EngDsplceTyp_1 ENG_EngDsplceTyp;
  COM_DT_ENG_EngTyp1 ENG_EngTyp1;
  COM_DT_ENG_EngTyp2 ENG_EngTyp2;
  COM_DT_ENG_EngTyp3 ENG_EngTyp3;
  COM_DT_ENG_EngTyp4 ENG_EngTyp4;
  COM_DT_ENG_ExtSoakTimeVal_1 ENG_ExtSoakTimeVal;
  COM_DT_ENG_FuelTempVal_1 ENG_FuelTempVal;
  COM_DT_ENG_ImmoLmpSta ENG_ImmoLmpSta;
  COM_DT_ENG_ImmoSta ENG_ImmoSta;
  COM_DT_ENG_IsgDispDetail_1 ENG_IsgDispDetail;
  COM_DT_ENG_IsgEquipped ENG_IsgEquipped;
  COM_DT_ENG_KNK_Warning ENG_KNK_Warning;
  COM_DT_ENG_MilSta ENG_MilSta;
  COM_DT_ENG_OilLifeEna ENG_OilLifeEna;
  COM_DT_ENG_OilLifeRatio_1 ENG_OilLifeRatio;
  COM_DT_ENG_OilLifeWarn_1 ENG_OilLifeWarn;
  COM_DT_ENG_PETyp ENG_PETyp;
  COM_DT_ENG_S_F ENG_S_F;
  COM_DT_ENG_S_F_GEN ENG_S_F_GEN;
  COM_DT_ENG_TqStndValExt_1 ENG_TqStndValExt;
  COM_DT_ENG_TransmsnTyp ENG_TransmsnTyp;
  COM_DT_InAirTempVal_1 InAirTempVal;
  COM_DT_OBD_DnmntrCalcVal_1 OBD_DnmntrCalcVal;
  COM_DT_OBD_IgnCycCntVal_1 OBD_IgnCycCntVal;
  COM_DT_OBD_RbmInhbtSta_1 OBD_RbmInhbtSta;
  COM_DT_OBD_RbmSta_1 OBD_RbmSta;
  COM_DT_SCC_BrkLtSwFlrDetSta SCC_BrkLtSwFlrDetSta;
  COM_DT_SCC_DrvOvrRidSta SCC_DrvOvrRidSta;
  COM_DT_SCC_FuncFlrDetSta SCC_FuncFlrDetSta;
  COM_DT_SCC_SccFlrDetSta SCC_SccFlrDetSta;
  COM_DT_SCC_SccOffStaDetSta SCC_SccOffStaDetSta;
  COM_DT_SCC_StrtLimFuncSta_1 SCC_StrtLimFuncSta;
  COM_DT_SCR_IndcmtExitStaDis_1 SCR_IndcmtExitStaDis;
  COM_DT_SCR_LvlWrngLmpSta SCR_LvlWrngLmpSta;
  COM_DT_SCR_LvlWrngMsgDis_1 SCR_LvlWrngMsgDis;
  COM_DT_SCR_RmnDstDis_1 SCR_RmnDstDis;
  COM_DT_SCR_RmnRstrtDis_1 SCR_RmnRstrtDis;
  COM_DT_SCR_SysErrMsgDis_1 SCR_SysErrMsgDis;
  COM_DT_SCR_SysWrngLmpReq SCR_SysWrngLmpReq;
  COM_DT_SCR_UreaLvlSta_1 SCR_UreaLvlSta;
} COM_DT_SG_EMS_05_100ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EMS_07_10ms_SignalGroup
typedef struct
{
  COM_DT_EMS_AlvCnt7Val EMS_AlvCnt7Val;
  COM_DT_EMS_Crc7Val EMS_Crc7Val;
  COM_DT_HEV_AccelPdlVal HEV_AccelPdlVal;
  COM_DT_HEV_EngSpdVal HEV_EngSpdVal;
  COM_DT_HEV_DrvTqVal HEV_DrvTqVal;
  COM_DT_HEV_EngOpSta HEV_EngOpSta;
  COM_DT_HEV_FrctTqVal HEV_FrctTqVal;
  COM_DT_HEV_IndTqTar HEV_IndTqTar;
  COM_DT_HEV_IndTqVal HEV_IndTqVal;
  COM_DT_HEV_IntakeAirTempVal HEV_IntakeAirTempVal;
  COM_DT_HEV_TqStndVal HEV_TqStndVal;
} COM_DT_SG_EMS_07_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EMS_11_10ms_SignalGroup
typedef struct
{
  COM_DT_EMS_AlvCnt11Val EMS_AlvCnt11Val;
  COM_DT_EMS_Crc11Val EMS_Crc11Val;
  COM_DT_HEV_EngSpdErrSta HEV_EngSpdErrSta;
  COM_DT_HEV_DrvCycActSta HEV_DrvCycActSta;
  COM_DT_HEV_EngFulLoadSta HEV_EngFulLoadSta;
  COM_DT_HEV_EngTq_Bas HEV_EngTq_Bas;
  COM_DT_HEV_EngTqAvail_FS HEV_EngTqAvail_FS;
  COM_DT_HEV_EngTqVal HEV_EngTqVal;
  COM_DT_HEV_EtcAppSta HEV_EtcAppSta;
  COM_DT_HEV_FirstFiringSta HEV_FirstFiringSta;
  COM_DT_HEV_FuelCnsmptVal HEV_FuelCnsmptVal;
  COM_DT_HEV_FuelCutOffInhbtSta HEV_FuelCutOffInhbtSta;
  COM_DT_HEV_FuelCutOffSta HEV_FuelCutOffSta;
  COM_DT_HEV_FueledEngRdy HEV_FueledEngRdy;
  COM_DT_HEV_FuelPmpTrgtPrsrVal HEV_FuelPmpTrgtPrsrVal;
  COM_DT_HEV_FuelTnkPrsrErrSta HEV_FuelTnkPrsrErrSta;
  COM_DT_HEV_FuelTnkPrsrVal HEV_FuelTnkPrsrVal;
  COM_DT_HEV_GPF_WrnLamp HEV_GPF_WrnLamp;
  COM_DT_HEV_IdleCtrStat_FS HEV_IdleCtrStat_FS;
  COM_DT_HEV_IdlTgtEngSpd HEV_IdlTgtEngSpd;
  COM_DT_HEV_O2SensHtrAct HEV_O2SensHtrAct;
  COM_DT_HEV_O2SnsrPreHeatSta HEV_O2SnsrPreHeatSta;
  COM_DT_HEV_ObdFrzFrmSta HEV_ObdFrzFrmSta;
  COM_DT_HEV_RbmDrvCycSta HEV_RbmDrvCycSta;
  COM_DT_HEV_RdyStat_FS_P HEV_RdyStat_FS_P;
  COM_DT_HEV_ThrPosSta HEV_ThrPosSta;
  COM_DT_HEV_VehSpdVal HEV_VehSpdVal;
  COM_DT_HEV_WarmupCycSta HEV_WarmupCycSta;
} COM_DT_SG_EMS_11_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_EPB_01_50ms_SignalGroup
typedef struct
{
  COM_DT_EPB_AlvCnt1Val EPB_AlvCnt1Val;
  COM_DT_EPB_Crc1Val EPB_Crc1Val;
  COM_DT_EPB_FrcSta EPB_FrcSta;
  COM_DT_EPB_SwPosSta EPB_SwPosSta;
  COM_DT_EPB_ActlFrcVal EPB_ActlFrcVal;
  COM_DT_EPB_AlrmReq EPB_AlrmReq;
  COM_DT_EPB_DynmBrkFrcDclReq EPB_DynmBrkFrcDclReq;
  COM_DT_EPB_DynmBrkFrcReq EPB_DynmBrkFrcReq;
  COM_DT_EPB_DynmBrkFrcReqSigSta EPB_DynmBrkFrcReqSigSta;
  COM_DT_EPB_EmerModReq EPB_EmerModReq;
  COM_DT_EPB_EpbSta4VcuReq EPB_EpbSta4VcuReq;
  COM_DT_EPB_EscReqAckSta EPB_EscReqAckSta;
  COM_DT_EPB_FlrLmpStaDis EPB_FlrLmpStaDis;
  COM_DT_EPB_FlSta EPB_FlSta;
  COM_DT_EPB_FrcErrSta EPB_FrcErrSta;
  COM_DT_EPB_LmpStaDis EPB_LmpStaDis;
  COM_DT_EPB_OutDataDis EPB_OutDataDis;
  COM_DT_EPB_RrBrkLtActvReq EPB_RrBrkLtActvReq;
} COM_DT_SG_EPB_01_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ESC_01_10ms_SignalGroup
typedef struct
{
  COM_DT_AVH_Sta AVH_Sta;
  COM_DT_ESC_AlvCnt1Val ESC_AlvCnt1Val;
  COM_DT_ESC_Crc1Val ESC_Crc1Val;
  COM_DT_ESC_CylPrsrSta ESC_CylPrsrSta;
  COM_DT_ESC_CylPrsrVal ESC_CylPrsrVal;
  COM_DT_ESC_OffTempSta ESC_OffTempSta;
  COM_DT_ESC_Sta ESC_Sta;
  COM_DT_ESC_VsmActvSta ESC_VsmActvSta;
  COM_DT_TCS_Sta TCS_Sta;
  COM_DT_ESC_IMURstStaAck_1 ESC_IMURstStaAck;
  COM_DT_AVH_ActvStaLmpDis AVH_ActvStaLmpDis;
  COM_DT_AVH_AlrmReq AVH_AlrmReq;
  COM_DT_AVH_CluDis AVH_CluDis;
  COM_DT_AVH_LmpDis AVH_LmpDis;
  COM_DT_AWD_CltchDtyLimVal AWD_CltchDtyLimVal;
  COM_DT_AWD_CrdnShftTqLimVal AWD_CrdnShftTqLimVal;
  COM_DT_AWD_FastOpnCrdnShftCltchReq AWD_FastOpnCrdnShftCltchReq;
  COM_DT_AWD_RrWhlDtyLimReq AWD_RrWhlDtyLimReq;
  COM_DT_AWD_TransmsnTqLimModSta AWD_TransmsnTqLimModSta;
  COM_DT_BJD_Flag BJD_Flag;
  COM_DT_DBC_ClusterDis DBC_ClusterDis;
  COM_DT_DBC_FuncLmpSta DBC_FuncLmpSta;
  COM_DT_DBC_Sta DBC_Sta;
  COM_DT_DBC_WrngLmpSta DBC_WrngLmpSta;
  COM_DT_ECD_ActvSta ECD_ActvSta;
  COM_DT_EPB_ActvReq EPB_ActvReq;
  COM_DT_EPB_StaReq EPB_StaReq;
  COM_DT_ESC_BrkCtrlSta ESC_BrkCtrlSta;
  COM_DT_ESC_CylPrsrDiagSta ESC_CylPrsrDiagSta;
  COM_DT_ESC_CylPrsrFlagSta ESC_CylPrsrFlagSta;
  COM_DT_ESC_LongAccelOffstCalibPrmtr ESC_LongAccelOffstCalibPrmtr;
  COM_DT_ESC_OffSwSta ESC_OffSwSta;
  COM_DT_ESC_SprtLmpSta ESC_SprtLmpSta;
  COM_DT_ESC_StrTqReq ESC_StrTqReq;
  COM_DT_ESC_VsmCtrlModSta ESC_VsmCtrlModSta;
  COM_DT_ESC_VsmDfctvSta ESC_VsmDfctvSta;
  COM_DT_HAC_Sta HAC_Sta;
  COM_DT_LDM_Sta LDM_Sta;
  COM_DT_MSR_FuncReq MSR_FuncReq;
  COM_DT_MSR_TqFlag MSR_TqFlag;
  COM_DT_MSR_TqIntrvntnVal MSR_TqIntrvntnVal;
  COM_DT_TCS_GearShftCharacteristicVal TCS_GearShftCharacteristicVal;
  COM_DT_TCS_LmpSta TCS_LmpSta;
  COM_DT_TCS_ManufacturerVal TCS_ManufacturerVal;
  COM_DT_TCS_OffLmpSta TCS_OffLmpSta;
  COM_DT_TCS_PreActvSta TCS_PreActvSta;
  COM_DT_TCS_Req TCS_Req;
  COM_DT_TCS_SlwTqFlag TCS_SlwTqFlag;
  COM_DT_TCS_SlwTqIntrvntnVal TCS_SlwTqIntrvntnVal;
  COM_DT_TCS_TqFlag TCS_TqFlag;
  COM_DT_TCS_TqIntrvntnVal TCS_TqIntrvntnVal;
} COM_DT_SG_ESC_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ESC_03_20ms_SignalGroup
typedef struct
{
  COM_DT_ESC_AlvCnt3Val ESC_AlvCnt3Val;
  COM_DT_ESC_Crc3Val ESC_Crc3Val;
  COM_DT_ESC_DrvBrkActvSta ESC_DrvBrkActvSta;
  COM_DT_ESC_DrvOvrdSta ESC_DrvOvrdSta;
  COM_DT_ESC_PrkBrkActvSta ESC_PrkBrkActvSta;
  COM_DT_ESC_RspaSta ESC_RspaSta;
  COM_DT_ESC_StdStillVal ESC_StdStillVal;
  COM_DT_FCA_AvlblSta FCA_AvlblSta;
  COM_DT_FCA_EquipSta FCA_EquipSta;
  COM_DT_SCC_EnblReq SCC_EnblReq;
  COM_DT_SCC_OptTyp SCC_OptTyp;
  COM_DT_ESC_FCA_ActvSta ESC_FCA_ActvSta;
  COM_DT_ESC_DBS_ActvSta ESC_DBS_ActvSta;
  COM_DT_CSC_WrngSta CSC_WrngSta;
  COM_DT_ESC_AccelBasisVal ESC_AccelBasisVal;
  COM_DT_ESC_BcaRPlusSta ESC_BcaRPlusSta;
  COM_DT_ESC_BrkdFltStndstill ESC_BrkdFltStndstill;
  COM_DT_ESC_BrkLtReq ESC_BrkLtReq;
  COM_DT_ESC_DclEnblReq ESC_DclEnblReq;
  COM_DT_ESC_DiffBrkFuncSta ESC_DiffBrkFuncSta;
  COM_DT_ESC_DrvBrkSta ESC_DrvBrkSta;
  COM_DT_ESC_HDP_EgSta ESC_HDP_EgSta;
  COM_DT_ESC_HDP_EnblReq ESC_HDP_EnblReq;
  COM_DT_ESC_HDP_FltMonSta ESC_HDP_FltMonSta;
  COM_DT_ESC_LsdLimMod ESC_LsdLimMod;
  COM_DT_ESC_LsdOpn ESC_LsdOpn;
  COM_DT_ESC_LsdTqLim ESC_LsdTqLim;
  COM_DT_ESC_PcaSta ESC_PcaSta;
  COM_DT_ESC_RccaSta ESC_RccaSta;
  COM_DT_ESC_RspaCanFlFlag ESC_RspaCanFlFlag;
  COM_DT_ESC_RspaDclActv ESC_RspaDclActv;
  COM_DT_ESC_RspaStandStill ESC_RspaStandStill;
  COM_DT_ESC_VehAccelVal ESC_VehAccelVal;
  COM_DT_MCB_CtlSta MCB_CtlSta;
  COM_DT_MCB_DefSta MCB_DefSta;
  COM_DT_MCB_ReqBrkAck MCB_ReqBrkAck;
  COM_DT_PWI_STATE PWI_STATE;
  COM_DT_SCC_ReqLimSta SCC_ReqLimSta;
  COM_DT_SCC_TqIntrvntnVal SCC_TqIntrvntnVal;
  COM_DT_SCC_TqReq SCC_TqReq;
} COM_DT_SG_ESC_03_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_FR_CMR_01_10ms_SignalGroup
typedef struct
{
  COM_DT_DAW_LVDA_OptUsmSta DAW_LVDA_OptUsmSta;
  COM_DT_DAW_LVDA_PUDis DAW_LVDA_PUDis;
  COM_DT_DAW_SysSta DAW_SysSta;
  COM_DT_DAW_WrnMsgSta DAW_WrnMsgSta;
  COM_DT_FR_CMR_AlvCnt1Val FR_CMR_AlvCnt1Val;
  COM_DT_FR_CMR_Crc1Val FR_CMR_Crc1Val;
  COM_DT_FR_CMR_SCCEquipSta FR_CMR_SCCEquipSta;
  COM_DT_HBA_IndLmpReq HBA_IndLmpReq;
  COM_DT_HBA_OptUsmSta HBA_OptUsmSta;
  COM_DT_HBA_SysOptSta HBA_SysOptSta;
  COM_DT_HBA_SysSta HBA_SysSta;
  COM_DT_FR_CMR_ReqADASMapMsgVal FR_CMR_ReqADASMapMsgVal;
  COM_DT_FR_CMR_SwVer1Val FR_CMR_SwVer1Val;
  COM_DT_FR_CMR_SwVer2Val FR_CMR_SwVer2Val;
  COM_DT_FCA_Equip_FR_CMR FCA_Equip_FR_CMR;
  COM_DT_FR_CMR_ACANMonSta FR_CMR_ACANMonSta;
  COM_DT_FR_CMR_CodingSta FR_CMR_CodingSta;
  COM_DT_FR_CMR_EMTrgtVldSta FR_CMR_EMTrgtVldSta;
  COM_DT_FR_CMR_FailInfoSta FR_CMR_FailInfoSta;
  COM_DT_FR_CMR_FCA_Plus_Sta FR_CMR_FCA_Plus_Sta;
  COM_DT_FR_CMR_FCAEquipSta FR_CMR_FCAEquipSta;
  COM_DT_FR_CMR_MDPSCtrlSta FR_CMR_MDPSCtrlSta;
  COM_DT_Info_OD_PedDstVal Info_OD_PedDstVal;
  COM_DT_PRVECS_CodedSta PRVECS_CodedSta;
} COM_DT_SG_FR_CMR_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_FR_CMR_02_100ms_SignalGroup
typedef struct
{
  COM_DT_FR_CMR_AlvCnt2Val FR_CMR_AlvCnt2Val;
  COM_DT_FR_CMR_Crc2Val FR_CMR_Crc2Val;
  COM_DT_ISLA_AddtnlSign ISLA_AddtnlSign;
  COM_DT_ISLA_AutoUsmSta ISLA_AutoUsmSta;
  COM_DT_ISLA_Cntry ISLA_Cntry;
  COM_DT_ISLA_IcyWrn ISLA_IcyWrn;
  COM_DT_ISLA_OffstUsmSta ISLA_OffstUsmSta;
  COM_DT_ISLA_OptUsmSta ISLA_OptUsmSta;
  COM_DT_ISLA_Popup ISLA_Popup;
  COM_DT_ISLA_SchoolZone ISLA_SchoolZone;
  COM_DT_ISLA_SpdChgReq ISLA_SpdChgReq;
  COM_DT_ISLA_SpdwOffst ISLA_SpdwOffst;
  COM_DT_ISLA_SpdWrn ISLA_SpdWrn;
  COM_DT_ISLA_SwIgnoreReq ISLA_SwIgnoreReq;
  COM_DT_ISLA_SymFlashMod ISLA_SymFlashMod;
  COM_DT_ISLW_NoPassingInfoDis ISLW_NoPassingInfoDis;
  COM_DT_ISLW_OptUsmSta ISLW_OptUsmSta;
  COM_DT_ISLW_OvrlpSignDis ISLW_OvrlpSignDis;
  COM_DT_ISLW_SpdCluDisSubCond1 ISLW_SpdCluDisSubCond1;
  COM_DT_ISLW_SpdCluDisSubCond2 ISLW_SpdCluDisSubCond2;
  COM_DT_ISLW_SpdCluMainDis ISLW_SpdCluMainDis;
  COM_DT_ISLW_SpdNaviDisSubCond1 ISLW_SpdNaviDisSubCond1;
  COM_DT_ISLW_SpdNaviDisSubCond2 ISLW_SpdNaviDisSubCond2;
  COM_DT_ISLW_SpdNaviMainDis ISLW_SpdNaviMainDis;
  COM_DT_ISLW_SubCondinfoSta1 ISLW_SubCondinfoSta1;
  COM_DT_ISLW_SubCondinfoSta2 ISLW_SubCondinfoSta2;
  COM_DT_ISLW_SysSta ISLW_SysSta;
  COM_DT_ISLA_AutoNModReq ISLA_AutoNModReq;
  COM_DT_ISLA_AutoNModSta ISLA_AutoNModSta;
  COM_DT_ISLA_AutoSetSpdSta ISLA_AutoSetSpdSta;
  COM_DT_ISLA_CondInfoDisp ISLA_CondInfoDisp;
  COM_DT_ISLA_EUCntry1USMSta ISLA_EUCntry1USMSta;
  COM_DT_ISLA_EUCntry2USMSta ISLA_EUCntry2USMSta;
  COM_DT_ISLA_EUCntryVerTyp ISLA_EUCntryVerTyp;
  COM_DT_ISLA_NACntry1USMSta ISLA_NACntry1USMSta;
  COM_DT_ISLA_NACntry2USMSta ISLA_NACntry2USMSta;
  COM_DT_ISLA_NACntryVerTyp ISLA_NACntryVerTyp;
  COM_DT_ISLA_NAOffstUSMSta ISLA_NAOffstUSMSta;
  COM_DT_ISLA_SndReqSta ISLA_SndReqSta;
  COM_DT_ISLA_TSRSpdLimEnfrcmtSta ISLA_TSRSpdLimEnfrcmtSta;
  COM_DT_ISLA_TSRSpdLimVal ISLA_TSRSpdLimVal;
} COM_DT_SG_FR_CMR_02_100ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_FR_CMR_03_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_CMR_AlvCnt3Val FR_CMR_AlvCnt3Val;
  COM_DT_FR_CMR_Crc3Val FR_CMR_Crc3Val;
  COM_DT_ID_CIPV ID_CIPV;
  COM_DT_Info_RtLnCrvtrDrvtvVal Info_RtLnCrvtrDrvtvVal;
  COM_DT_Info_RtLnCvtrVal Info_RtLnCvtrVal;
  COM_DT_Info_RtLnDptSta Info_RtLnDptSta;
  COM_DT_Info_RtLnHdingAnglVal Info_RtLnHdingAnglVal;
  COM_DT_Info_RtLnPosVal Info_RtLnPosVal;
  COM_DT_Info_RtLnQualSta Info_RtLnQualSta;
  COM_DT_Longitudinal_Distance Longitudinal_Distance;
  COM_DT_Relative_Velocity Relative_Velocity;
  COM_DT_Info_LtLnCrvtrDrvtvVal Info_LtLnCrvtrDrvtvVal;
  COM_DT_Info_LtLnCvtrVal Info_LtLnCvtrVal;
  COM_DT_Info_LtLnDptSta Info_LtLnDptSta;
  COM_DT_Info_LtLnHdingAnglVal Info_LtLnHdingAnglVal;
  COM_DT_Info_LtLnPosVal Info_LtLnPosVal;
  COM_DT_Info_LtLnQualSta Info_LtLnQualSta;
} COM_DT_SG_FR_CMR_03_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_FR_CMR_04_40ms_SignalGroup
typedef struct
{
  COM_DT_FR_CMR_AlvCnt4Val_1 FR_CMR_AlvCnt4Val;
  COM_DT_FR_CMR_Crc4Val_1 FR_CMR_Crc4Val;
  COM_DT_IFSref_FR_CMR_Sta IFSref_FR_CMR_Sta;
  COM_DT_IFSref_ILLAmbtSta IFSref_ILLAmbtSta;
  COM_DT_IFSref_VehDst1Val IFSref_VehDst1Val;
  COM_DT_IFSref_VehDst2Val IFSref_VehDst2Val;
  COM_DT_IFSref_VehDst3Val IFSref_VehDst3Val;
  COM_DT_IFSref_VehDst4Val IFSref_VehDst4Val;
  COM_DT_IFSref_VehDst5Val IFSref_VehDst5Val;
  COM_DT_IFSref_VehDst6Val IFSref_VehDst6Val;
  COM_DT_IFSref_VehDst7Val IFSref_VehDst7Val;
  COM_DT_IFSref_VehDst8Val IFSref_VehDst8Val;
  COM_DT_IFSref_VehDst9Val IFSref_VehDst9Val;
  COM_DT_IFSref_VehDst10Val IFSref_VehDst10Val;
  COM_DT_IFSref_VehLtAngl1Val_1 IFSref_VehLtAngl1Val;
  COM_DT_IFSref_VehLtAngl2Val_1 IFSref_VehLtAngl2Val;
  COM_DT_IFSref_VehLtAngl3Val_1 IFSref_VehLtAngl3Val;
  COM_DT_IFSref_VehLtAngl4Val_1 IFSref_VehLtAngl4Val;
  COM_DT_IFSref_VehLtAngl5Val_1 IFSref_VehLtAngl5Val;
  COM_DT_IFSref_VehLtAngl6Val_1 IFSref_VehLtAngl6Val;
  COM_DT_IFSref_VehLtAngl7Val_1 IFSref_VehLtAngl7Val;
  COM_DT_IFSref_VehLtAngl8Val_1 IFSref_VehLtAngl8Val;
  COM_DT_IFSref_VehLtAngl9Val_1 IFSref_VehLtAngl9Val;
  COM_DT_IFSref_VehLtAngl10Val_1 IFSref_VehLtAngl10Val;
  COM_DT_IFSref_VehNumVal_1 IFSref_VehNumVal;
  COM_DT_IFSref_VehRtAngl1Val_1 IFSref_VehRtAngl1Val;
  COM_DT_IFSref_VehRtAngl2Val_1 IFSref_VehRtAngl2Val;
  COM_DT_IFSref_VehRtAngl3Val_1 IFSref_VehRtAngl3Val;
  COM_DT_IFSref_VehRtAngl4Val_1 IFSref_VehRtAngl4Val;
  COM_DT_IFSref_VehRtAngl5Val_1 IFSref_VehRtAngl5Val;
  COM_DT_IFSref_VehRtAngl6Val_1 IFSref_VehRtAngl6Val;
  COM_DT_IFSref_VehRtAngl7Val_1 IFSref_VehRtAngl7Val;
  COM_DT_IFSref_VehRtAngl8Val_1 IFSref_VehRtAngl8Val;
  COM_DT_IFSref_VehRtAngl9Val_1 IFSref_VehRtAngl9Val;
  COM_DT_IFSref_VehRtAngl10Val_1 IFSref_VehRtAngl10Val;
} COM_DT_SG_FR_CMR_04_40ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HCU_03_10ms_SignalGroup
typedef struct
{
  COM_DT_HCU_AlvCnt3Val HCU_AlvCnt3Val;
  COM_DT_HCU_Crc3Val HCU_Crc3Val;
  COM_DT_HCU_HevRdySta HCU_HevRdySta;
  COM_DT_HCU_SccEnblSta HCU_SccEnblSta;
  COM_DT_HCU_SpdLimDeviceActSta HCU_SpdLimDeviceActSta;
  COM_DT_HCU_SpdLimDeviceOperSta HCU_SpdLimDeviceOperSta;
  COM_DT_HCU_SpdLimDeviceVehSpdVal HCU_SpdLimDeviceVehSpdVal;
  COM_DT_HCU_BrkLmpOnReq HCU_BrkLmpOnReq;
  COM_DT_HCU_CcDrvAlrtDis HCU_CcDrvAlrtDis;
  COM_DT_HCU_DrvWhlDmndTqNmVal HCU_DrvWhlDmndTqNmVal;
  COM_DT_HCU_DucUsrSetCluSta HCU_DucUsrSetCluSta;
  COM_DT_HCU_DucVal HCU_DucVal;
  COM_DT_HCU_EstAccelPdlPcVal HCU_EstAccelPdlPcVal;
  COM_DT_HCU_EstApsSelSta HCU_EstApsSelSta;
  COM_DT_HCU_GearRInhbtSta HCU_GearRInhbtSta;
  COM_DT_HCU_GreenZoneDrvModSta HCU_GreenZoneDrvModSta;
  COM_DT_HCU_GreenZoneLmpDis HCU_GreenZoneLmpDis;
  COM_DT_HCU_HcuRdySta HCU_HcuRdySta;
  COM_DT_HCU_HEVRdyDis HCU_HEVRdyDis;
  COM_DT_HCU_LimpOffSta HCU_LimpOffSta;
  COM_DT_HCU_MILOnReq HCU_MILOnReq;
  COM_DT_HCU_PdlStopCtrlSta HCU_PdlStopCtrlSta;
  COM_DT_HCU_PdlStopReqTqNmVal HCU_PdlStopReqTqNmVal;
  COM_DT_HCU_PhevAutoModOnSta HCU_PhevAutoModOnSta;
  COM_DT_HCU_RspaAlvCntVal HCU_RspaAlvCntVal;
  COM_DT_HCU_RspaCanFailSta HCU_RspaCanFailSta;
  COM_DT_HCU_RspaSta HCU_RspaSta;
  COM_DT_HCU_SccDrvOvrdReq HCU_SccDrvOvrdReq;
  COM_DT_HCU_SldDrvAlrtDis HCU_SldDrvAlrtDis;
  COM_DT_HCU_SlwDnSta HCU_SlwDnSta;
  COM_DT_HCU_SmrtEcoGdDis HCU_SmrtEcoGdDis;
  COM_DT_HCU_SmrtEcoLvlDis HCU_SmrtEcoLvlDis;
  COM_DT_HCU_SmrtEcoRngDis HCU_SmrtEcoRngDis;
  COM_DT_HCU_SrvModSta HCU_SrvModSta;
  COM_DT_HCU_StrtInhbt2Sta HCU_StrtInhbt2Sta;
  COM_DT_HCU_StrtInhbtSta HCU_StrtInhbtSta;
  COM_DT_HCU_SysShtOffReq HCU_SysShtOffReq;
  COM_DT_HCU_VehStrtEnblSta HCU_VehStrtEnblSta;
  COM_DT_HCU_WhlCrpCrpTqNmVal HCU_WhlCrpCrpTqNmVal;
  COM_DT_LHCU_EngCltchTrnsfrTqPcVal_Copy_1 LHCU_EngCltchTrnsfrTqPcVal_Copy_1;
} COM_DT_SG_HCU_03_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HCU_05_100ms_SignalGroup
typedef struct
{
  COM_DT_HCU_AafCtrlReq HCU_AafCtrlReq;
  COM_DT_HCU_AcnCompPrmsnPwrVal HCU_AcnCompPrmsnPwrVal;
  COM_DT_HCU_AcnOpPrmssnSta HCU_AcnOpPrmssnSta;
  COM_DT_HCU_AcPwrIncSta HCU_AcPwrIncSta;
  COM_DT_HCU_AlvCnt5Val HCU_AlvCnt5Val;
  COM_DT_HCU_BlwOffReq HCU_BlwOffReq;
  COM_DT_HCU_CcCameraOperSta HCU_CcCameraOperSta;
  COM_DT_HCU_CcCameraSta HCU_CcCameraSta;
  COM_DT_HCU_ChrgIncModSta HCU_ChrgIncModSta;
  COM_DT_HCU_Crc5Val HCU_Crc5Val;
  COM_DT_HCU_CrsCtrlOnLmpDis HCU_CrsCtrlOnLmpDis;
  COM_DT_HCU_CrsCtrlSetLmpDis HCU_CrsCtrlSetLmpDis;
  COM_DT_HCU_DptEnaSet1FriSta HCU_DptEnaSet1FriSta;
  COM_DT_HCU_DptEnaSet1MonSta HCU_DptEnaSet1MonSta;
  COM_DT_HCU_DptEnaSet1SatSta HCU_DptEnaSet1SatSta;
  COM_DT_HCU_DptEnaSet1Sta HCU_DptEnaSet1Sta;
  COM_DT_HCU_DptEnaSet1SunSta HCU_DptEnaSet1SunSta;
  COM_DT_HCU_DptEnaSet1ThuSta HCU_DptEnaSet1ThuSta;
  COM_DT_HCU_DptEnaSet1TueSta HCU_DptEnaSet1TueSta;
  COM_DT_HCU_DptEnaSet1WedSta HCU_DptEnaSet1WedSta;
  COM_DT_HCU_DptEnaSet2FriSta HCU_DptEnaSet2FriSta;
  COM_DT_HCU_DptEnaSet2MonSta HCU_DptEnaSet2MonSta;
  COM_DT_HCU_DptEnaSet2SatSta HCU_DptEnaSet2SatSta;
  COM_DT_HCU_DptEnaSet2Sta HCU_DptEnaSet2Sta;
  COM_DT_HCU_DptEnaSet2SunSta HCU_DptEnaSet2SunSta;
  COM_DT_HCU_DptEnaSet2ThuSta HCU_DptEnaSet2ThuSta;
  COM_DT_HCU_DptEnaSet2TueSta HCU_DptEnaSet2TueSta;
  COM_DT_HCU_DptEnaSet2WedSta HCU_DptEnaSet2WedSta;
  COM_DT_HCU_DptHrSet1Val HCU_DptHrSet1Val;
  COM_DT_HCU_DptHrSet2Val HCU_DptHrSet2Val;
  COM_DT_HCU_DptMinSet1Val HCU_DptMinSet1Val;
  COM_DT_HCU_DptMinSet2Val HCU_DptMinSet2Val;
  COM_DT_HCU_DrvModSta HCU_DrvModSta;
  COM_DT_HCU_EcoChrgEndHrVal HCU_EcoChrgEndHrVal;
  COM_DT_HCU_EcoChrgEndHrWeekendVal HCU_EcoChrgEndHrWeekendVal;
  COM_DT_HCU_EcoChrgEndMinVal HCU_EcoChrgEndMinVal;
  COM_DT_HCU_EcoChrgEndMinWeekendVal HCU_EcoChrgEndMinWeekendVal;
  COM_DT_HCU_EcoChrgStrtHrVal HCU_EcoChrgStrtHrVal;
  COM_DT_HCU_EcoChrgStrtHrWeekendVal HCU_EcoChrgStrtHrWeekendVal;
  COM_DT_HCU_EcoChrgStrtMinVal HCU_EcoChrgStrtMinVal;
  COM_DT_HCU_EcoChrgStrtMinWeekendVal HCU_EcoChrgStrtMinWeekendVal;
  COM_DT_HCU_EcoLvlVal HCU_EcoLvlVal;
  COM_DT_HCU_EcoScoVal HCU_EcoScoVal;
  COM_DT_HCU_EmissionTestModSta HCU_EmissionTestModSta;
  COM_DT_HCU_FuelEcoVal HCU_FuelEcoVal;
  COM_DT_HCU_HevSysModSta HCU_HevSysModSta;
  COM_DT_HCU_LdcCtrlModSta HCU_LdcCtrlModSta;
  COM_DT_HCU_LdcInhbtReq HCU_LdcInhbtReq;
  COM_DT_HCU_LdcUnderVoltCtrlSta HCU_LdcUnderVoltCtrlSta;
  COM_DT_HCU_NccAlrmInfoSta HCU_NccAlrmInfoSta;
  COM_DT_HCU_PaddleCoastCtrlSta HCU_PaddleCoastCtrlSta;
  COM_DT_HCU_PaddleCstCtrlWrnMsgSta HCU_PaddleCstCtrlWrnMsgSta;
  COM_DT_HCU_PaddleStepCtrlSta HCU_PaddleStepCtrlSta;
  COM_DT_HCU_PhevDrvModClusterSta HCU_PhevDrvModClusterSta;
  COM_DT_HCU_PhevMod HCU_PhevMod;
  COM_DT_HCU_PIFailFreezeReq HCU_PIFailFreezeReq;
  COM_DT_HCU_PreFATCHysTempVal HCU_PreFATCHysTempVal;
  COM_DT_HCU_PreFATCOffstTempVal HCU_PreFATCOffstTempVal;
  COM_DT_HCU_PreFATCOffstTempValHR HCU_PreFATCOffstTempValHR;
  COM_DT_HCU_SchedChgEndDayVal HCU_SchedChgEndDayVal;
  COM_DT_HCU_SchedChgEndHrVal HCU_SchedChgEndHrVal;
  COM_DT_HCU_SchedChgEndMinVal HCU_SchedChgEndMinVal;
  COM_DT_HCU_SchedChgStrtDayVal HCU_SchedChgStrtDayVal;
  COM_DT_HCU_SchedChgStrtHrVal HCU_SchedChgStrtHrVal;
  COM_DT_HCU_SchedChgStrtMinVal HCU_SchedChgStrtMinVal;
  COM_DT_HCU_SmartRegen_LvlVal HCU_SmartRegen_LvlVal;
  COM_DT_HCU_SmartRegen_MapCstActSta HCU_SmartRegen_MapCstActSta;
  COM_DT_HCU_SmartRegen_MapEventUsmSta HCU_SmartRegen_MapEventUsmSta;
  COM_DT_HCU_SmartRegen_OnSta HCU_SmartRegen_OnSta;
  COM_DT_HCU_SmartRegen_RdrCstActSta HCU_SmartRegen_RdrCstActSta;
  COM_DT_HCU_SmartRegen_UsmSta HCU_SmartRegen_UsmSta;
  COM_DT_HCU_SmartRegen_VehHoldSta HCU_SmartRegen_VehHoldSta;
  COM_DT_HCU_SmartRegen_WarnMsgSta HCU_SmartRegen_WarnMsgSta;
  COM_DT_HCU_SrvLmpDis HCU_SrvLmpDis;
  COM_DT_HCU_SrvLmpTmpryOnSta HCU_SrvLmpTmpryOnSta;
} COM_DT_SG_HCU_05_100ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HTCU_04_10ms_SignalGroup
typedef struct
{
  COM_DT_HTCU_AlvCnt4Val HTCU_AlvCnt4Val;
  COM_DT_HTCU_Crc4Val HTCU_Crc4Val;
  COM_DT_HTCU_GearSlctrDis HTCU_GearSlctrDis;
  COM_DT_HTCU_CtrlablSta HTCU_CtrlablSta;
  COM_DT_HTCU_CurrGearSta HTCU_CurrGearSta;
  COM_DT_HTCU_FanCtrlReq HTCU_FanCtrlReq;
  COM_DT_HTCU_FltSta HTCU_FltSta;
  COM_DT_HTCU_FsAddtnlTqLssPcVal HTCU_FsAddtnlTqLssPcVal;
  COM_DT_HTCU_FsCltchLmphmActvSta HTCU_FsCltchLmphmActvSta;
  COM_DT_HTCU_FsEngTqRdctnPcVal HTCU_FsEngTqRdctnPcVal;
  COM_DT_HTCU_FsIdleTrgtRpmVal HTCU_FsIdleTrgtRpmVal;
  COM_DT_HTCU_GearChgSta HTCU_GearChgSta;
  COM_DT_HTCU_GearShftDnDisGSI HTCU_GearShftDnDisGSI;
  COM_DT_HTCU_GearShftUpDisGSI HTCU_GearShftUpDisGSI;
  COM_DT_HTCU_HvOpuSpdCmdRpmVal HTCU_HvOpuSpdCmdRpmVal;
  COM_DT_HTCU_LnPrsBarVal HTCU_LnPrsBarVal;
  COM_DT_HTCU_PrgrmSta HTCU_PrgrmSta;
  COM_DT_HTCU_RapidKDReq HTCU_RapidKDReq;
  COM_DT_HTCU_RdySta HTCU_RdySta;
  COM_DT_HTCU_SlwTqRdctnPcVal HTCU_SlwTqRdctnPcVal;
  COM_DT_HTCU_SolBSta HTCU_SolBSta;
  COM_DT_HTCU_TqRdctnPcVal HTCU_TqRdctnPcVal;
  COM_DT_HTCU_TrgtGearSta HTCU_TrgtGearSta;
  COM_DT_HTCU_TrgtGearStaGSI HTCU_TrgtGearStaGSI;
  COM_DT_HTCU_TrgtShftClsCCanSta HTCU_TrgtShftClsCCanSta;
  COM_DT_HTCU_VehSpdDcmlKphVal HTCU_VehSpdDcmlKphVal;
  COM_DT_HTCU_VehSpdKphVal HTCU_VehSpdKphVal;
} COM_DT_SG_HTCU_04_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HTCU_05_10ms_SignalGroup
typedef struct
{
  COM_DT_HDCT_AcnChrgInhbtReq HDCT_AcnChrgInhbtReq;
  COM_DT_HDCT_AddtnlTqLssVal HDCT_AddtnlTqLssVal;
  COM_DT_HDCT_CltchSta HDCT_CltchSta;
  COM_DT_HDCT_CLUEngSpd HDCT_CLUEngSpd;
  COM_DT_HDCT_CLUEngSpdFlag HDCT_CLUEngSpdFlag;
  COM_DT_HDCT_CLUTrgtGear HDCT_CLUTrgtGear;
  COM_DT_HDCT_CtrlablSta HDCT_CtrlablSta;
  COM_DT_HDCT_CurrGear HDCT_CurrGear;
  COM_DT_HDCT_CurrPrgrm HDCT_CurrPrgrm;
  COM_DT_HDCT_DblCltchSta HDCT_DblCltchSta;
  COM_DT_HDCT_EngCltchLmphmMod HDCT_EngCltchLmphmMod;
  COM_DT_HDCT_EOLReq HDCT_EOLReq;
  COM_DT_HDCT_FltSta HDCT_FltSta;
  COM_DT_HDCT_FuelCutReq HDCT_FuelCutReq;
  COM_DT_HDCT_GearSelDis HDCT_GearSelDis;
  COM_DT_HDCT_GearShftSta HDCT_GearShftSta;
  COM_DT_HDCT_GSITrgtGear HDCT_GSITrgtGear;
  COM_DT_HDCT_KckDnSkpShftCnt HDCT_KckDnSkpShftCnt;
  COM_DT_HDCT_MCUAntJrkInhbt HDCT_MCUAntJrkInhbt;
  COM_DT_HDCT_NCoastDnReq HDCT_NCoastDnReq;
  COM_DT_HDCT_NCoastTrgtGear HDCT_NCoastTrgtGear;
  COM_DT_HDCT_NetrlCtrlSta HDCT_NetrlCtrlSta;
  COM_DT_HDCT_OBDErrSta HDCT_OBDErrSta;
  COM_DT_HDCT_OBDSta HDCT_OBDSta;
  COM_DT_HDCT_ShftPhase HDCT_ShftPhase;
  COM_DT_HDCT_SlipCrnkAllw HDCT_SlipCrnkAllw;
  COM_DT_HDCT_StcShftLrchCtrl HDCT_StcShftLrchCtrl;
  COM_DT_HDCT_TCURdySta HDCT_TCURdySta;
  COM_DT_HDCT_TqIncReq HDCT_TqIncReq;
  COM_DT_HDCT_TqIncVal HDCT_TqIncVal;
  COM_DT_HDCT_TqRdctnVal HDCT_TqRdctnVal;
  COM_DT_HDCT_TrgtGear HDCT_TrgtGear;
  COM_DT_HDCT_TrgtShftCls HDCT_TrgtShftCls;
  COM_DT_HTCU_AlvCnt5Val HTCU_AlvCnt5Val;
  COM_DT_HTCU_Crc5Val HTCU_Crc5Val;
  COM_DT_HTCU_SlwTqRdctnVal HTCU_SlwTqRdctnVal;
} COM_DT_SG_HTCU_05_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_CLU_PE_05_SignalGroup
typedef struct
{
  COM_DT_HU_AutoBrightState_New_1 HU_AutoBrightState_New;
  COM_DT_HU_BVM_Display_Message_1 HU_BVM_Display_Message;
  COM_DT_HU_DayNightState HU_DayNightState;
  COM_DT_HU_EVSupport HU_EVSupport;
  COM_DT_HU_LanguageInfo_1 HU_LanguageInfo;
  COM_DT_HU_MuteStatus HU_MuteStatus;
  COM_DT_HU_NaviCamSettingStatus_2 HU_NaviCamSettingStatus;
  COM_DT_HU_NaviDisp HU_NaviDisp;
  COM_DT_HU_NaviStatus HU_NaviStatus;
  COM_DT_HU_SVM_View_Display_1 HU_SVM_View_Display;
  COM_DT_HU_UsmSupport HU_UsmSupport;
  COM_DT_HU_VolumeStatus HU_VolumeStatus;
  COM_DT_HU_WelcomeReady HU_WelcomeReady;
} COM_DT_SG_HU_CLU_PE_05_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_GW_PE_01_SignalGroup
typedef struct
{
  COM_DT_AVN_RSPA_CancelInput AVN_RSPA_CancelInput;
  COM_DT_AVN_RSPA_Disp_Rdy AVN_RSPA_Disp_Rdy;
  COM_DT_AVN_RSPA_ModeSelect_1 AVN_RSPA_ModeSelect;
  COM_DT_C_TeleActiveStatus C_TeleActiveStatus;
  COM_DT_CF_AVN_ProfileIDRValue_1 CF_AVN_ProfileIDRValue;
  COM_DT_CF_HU_GPSFlt CF_HU_GPSFlt;
  COM_DT_HazardFromHUSVM HazardFromHUSVM;
  COM_DT_HU_AliveStatus HU_AliveStatus;
  COM_DT_HU_DistanceUnit HU_DistanceUnit;
  COM_DT_HU_MicActivity HU_MicActivity;
  COM_DT_HU_RTCCheck HU_RTCCheck;
  COM_DT_HU_Scheduled_Setting_1 HU_Scheduled_Setting;
  COM_DT_HU_ThemeType_1 HU_ThemeType;
  COM_DT_OMUOSMirCtrl OMUOSMirCtrl;
  COM_DT_OTAUIStatus OTAUIStatus;
} COM_DT_SG_HU_GW_PE_01_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_MON_PE_01_SignalGroup
typedef struct
{
  COM_DT_HU_AdasSupport HU_AdasSupport;
  COM_DT_HU_AMP_EQVariant_1 HU_AMP_EQVariant;
  COM_DT_HU_DistributeInfo_2 HU_DistributeInfo;
  COM_DT_HU_Navi_RspADASMapMsg_2 HU_Navi_RspADASMapMsg;
  COM_DT_HU_NaviHandshakingSupport HU_NaviHandshakingSupport;
  COM_DT_HU_NaviMapInfo HU_NaviMapInfo;
  COM_DT_HU_OptionInfo HU_OptionInfo;
  COM_DT_HU_Type_2 HU_Type;
} COM_DT_SG_HU_MON_PE_01_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup
typedef struct
{
  COM_DT_META_V2_3_Country_OptADAS META_V2_3_Country_OptADAS;
  COM_DT_META_V2_3_CountryCode_1 META_V2_3_CountryCode;
  COM_DT_META_V2_3_CyclicCounter_1 META_V2_3_CyclicCounter;
  COM_DT_META_V2_3_DrivingSide META_V2_3_DrivingSide;
  COM_DT_META_V2_3_MajorProtocolVersion_1 META_V2_3_MajorProtocolVersion;
  COM_DT_META_V2_3_MapProvider META_V2_3_MapProvider;
  COM_DT_META_V2_3_MinorProtocolVersion_1 META_V2_3_MinorProtocolVersion;
  COM_DT_META_V2_3_RegionCode_1 META_V2_3_RegionCode;
  COM_DT_META_V2_3_SpeedUnit META_V2_3_SpeedUnit;
} COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup
typedef struct
{
  COM_DT_POS_V2_3_CurrAltitude1m_1 POS_V2_3_CurrAltitude1m;
  COM_DT_POS_V2_3_CurrAltitude100m POS_V2_3_CurrAltitude100m;
  COM_DT_POS_V2_3_CurrDirectionLanes_1 POS_V2_3_CurrDirectionLanes;
  COM_DT_POS_V2_3_CurrFormOfWay_1 POS_V2_3_CurrFormOfWay;
  COM_DT_POS_V2_3_CurrFuncRoadClass POS_V2_3_CurrFuncRoadClass;
  COM_DT_POS_V2_3_CurrSpeedLimit POS_V2_3_CurrSpeedLimit;
  COM_DT_POS_V2_3_CurrTrafficSpeed POS_V2_3_CurrTrafficSpeed;
  COM_DT_POS_V2_3_CyclicCounter_1 POS_V2_3_CyclicCounter;
  COM_DT_POS_V2_3_Offset_1 POS_V2_3_Offset;
  COM_DT_POS_V2_3_PathIndex_1 POS_V2_3_PathIndex;
  COM_DT_POS_V2_3_RangeAvgSpeed_1 POS_V2_3_RangeAvgSpeed;
} COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro
typedef struct
{
  COM_DT_PROLONG_V2_3_CyclicCounter_1 PROLONG_V2_3_CyclicCounter;
  COM_DT_PROLONG_V2_3_Offset_1 PROLONG_V2_3_Offset;
  COM_DT_PROLONG_V2_3_PathIndex_1 PROLONG_V2_3_PathIndex;
  COM_DT_PROLONG_V2_3_ProfileType_1 PROLONG_V2_3_ProfileType;
  COM_DT_PROLONG_V2_3_Update PROLONG_V2_3_Update;
  COM_DT_PROLONG_V2_3_Value_1 PROLONG_V2_3_Value;
} COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro;

#  define Rte_TypeDef_COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa
typedef struct
{
  COM_DT_PROSHORT_V2_3_Accuracy_1 PROSHORT_V2_3_Accuracy;
  COM_DT_PROSHORT_V2_3_CyclicCounter_1 PROSHORT_V2_3_CyclicCounter;
  COM_DT_PROSHORT_V2_3_Distance_1 PROSHORT_V2_3_Distance;
  COM_DT_PROSHORT_V2_3_Offset_1 PROSHORT_V2_3_Offset;
  COM_DT_PROSHORT_V2_3_PathIndex_1 PROSHORT_V2_3_PathIndex;
  COM_DT_PROSHORT_V2_3_ProfileType_1 PROSHORT_V2_3_ProfileType;
  COM_DT_PROSHORT_V2_3_Value0_1 PROSHORT_V2_3_Value0;
  COM_DT_PROSHORT_V2_3_Value1_1 PROSHORT_V2_3_Value1;
} COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa;

#  define Rte_TypeDef_COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup
typedef struct
{
  COM_DT_SEG_V2_3_CalculatedRoute SEG_V2_3_CalculatedRoute;
  COM_DT_SEG_V2_3_CyclicCounter_1 SEG_V2_3_CyclicCounter;
  COM_DT_SEG_V2_3_DirectionLanes_1 SEG_V2_3_DirectionLanes;
  COM_DT_SEG_V2_3_DividedRoad SEG_V2_3_DividedRoad;
  COM_DT_SEG_V2_3_FormOfWay_1 SEG_V2_3_FormOfWay;
  COM_DT_SEG_V2_3_FuncRoadClass SEG_V2_3_FuncRoadClass;
  COM_DT_SEG_V2_3_Offset_1 SEG_V2_3_Offset;
  COM_DT_SEG_V2_3_PathIndex_1 SEG_V2_3_PathIndex;
  COM_DT_SEG_V2_3_Retransmission SEG_V2_3_Retransmission;
  COM_DT_SEG_V2_3_SpeedLimit SEG_V2_3_SpeedLimit;
  COM_DT_SEG_V2_3_SpeedLimitUnder5_1 SEG_V2_3_SpeedLimitUnder5;
} COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup
typedef struct
{
  Navi_ISLW_CountryCode Navi_ISLW_CountryCode;
  Navi_ISLW_Frwinfo Navi_ISLW_Frwinfo;
  Navi_ISLW_LinkClass Navi_ISLW_LinkClass;
  Navi_ISLW_MapSource Navi_ISLW_MapSource;
  Navi_ISLW_SpdLimit Navi_ISLW_SpdLimit;
  Navi_ISLW_SpdUnit Navi_ISLW_SpdUnit;
  Navi_ISLW_TimeSpd Navi_ISLW_TimeSpd;
  Navi_ISLW_TollExist Navi_ISLW_TollExist;
  Navi_ISLW_TunnelExist Navi_ISLW_TunnelExist;
  Navi_ISLA_TImeZone Navi_ISLA_TImeZone;
} COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_HU_USM_E_14_SignalGroup
typedef struct
{
  COM_DT_CF_AVN_LKAWrngVolNvalueSet CF_AVN_LKAWrngVolNvalueSet;
} COM_DT_SG_HU_USM_E_14_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_IAU_16_200ms_SignalGroup
typedef struct
{
  COM_DT_IAU_DigitalKey2Opt IAU_DigitalKey2Opt;
  COM_DT_IAU_DigitalKeyEnblRVal IAU_DigitalKeyEnblRVal;
  COM_DT_IAU_DigitalKeyExit IAU_DigitalKeyExit;
  COM_DT_IAU_DigitalKeyProcessingSta IAU_DigitalKeyProcessingSta;
  COM_DT_IAU_DISPWrng IAU_DISPWrng;
  COM_DT_IAU_NFCCard1RegRVal IAU_NFCCard1RegRVal;
  COM_DT_IAU_NFCCard2RegRVal IAU_NFCCard2RegRVal;
  COM_DT_IAU_OwnerPhnRegRVal IAU_OwnerPhnRegRVal;
  COM_DT_IAU_ProfileIDRVal IAU_ProfileIDRVal;
  COM_DT_IAUwFPMLearnState IAUwFPMLearnState;
  COM_DT_IAUwFRULearnState IAUwFRULearnState;
} COM_DT_SG_IAU_16_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICC_HS_01_50ms_SignalGroup
typedef struct
{
  ICC_CamBlckdStat ICC_CamBlckdStat;
  ICC_CamFailStat ICC_CamFailStat;
  ICC_EcuFailStat ICC_EcuFailStat;
  ICC_HDPSpprtSWVer ICC_HDPSpprtSWVer;
  ICC_HS_AlvCnt1Val ICC_HS_AlvCnt1Val;
  ICC_HS_Crc1Val ICC_HS_Crc1Val;
  ICC_MajorSWVer ICC_MajorSWVer;
  ICC_MinorSWVer ICC_MinorSWVer;
  ICC_OptUsmStat ICC_OptUsmStat;
  ICC_ProfilingStat ICC_ProfilingStat;
  ICC_SymStat ICC_SymStat;
  ICC_UpdateStat ICC_UpdateStat;
  ICC_WarningSmblDistStat ICC_WarningSmblDistStat;
  ICC_WarningSmblDrowStat ICC_WarningSmblDrowStat;
  ICC_WarningSndStat ICC_WarningSndStat;
  ICC_WarningStat ICC_WarningStat;
  ICC_WarningSnd2Stat ICC_WarningSnd2Stat;
} COM_DT_SG_ICC_HS_01_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICC_HS_04_50ms_SignalGroup
typedef struct
{
  COM_DT_ICC_ActivityStat ICC_ActivityStat;
  COM_DT_ICC_AoIStat ICC_AoIStat;
  COM_DT_ICC_DistLvlStat ICC_DistLvlStat;
  COM_DT_ICC_DrwsLvlStat ICC_DrwsLvlStat;
  COM_DT_ICC_EyeStat ICC_EyeStat;
  COM_DT_ICC_FaceDetectStat ICC_FaceDetectStat;
  COM_DT_ICC_FaceFakeStat ICC_FaceFakeStat;
  COM_DT_ICC_HS_AlvCnt4Val ICC_HS_AlvCnt4Val;
  COM_DT_ICC_HS_Crc4Val ICC_HS_Crc4Val;
  COM_DT_ICC_IntvDrwsLvlStat ICC_IntvDrwsLvlStat;
  COM_DT_ICC_IntvSDLvlStat ICC_IntvSDLvlStat;
  COM_DT_ICC_IntvStat ICC_IntvStat;
  COM_DT_ICC_LeftEyeOpenStat ICC_LeftEyeOpenStat;
  COM_DT_ICC_RightEyeOpenStat ICC_RightEyeOpenStat;
  COM_DT_ICC_TalkStat ICC_TalkStat;
  COM_DT_ICC_YawnStat ICC_YawnStat;
} COM_DT_SG_ICC_HS_04_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICSC_02_100ms_SignalGroup
typedef struct
{
  COM_DT_DMIC_IndEngModSta DMIC_IndEngModSta;
  COM_DT_DMIC_AwdFltSta DMIC_AwdFltSta;
  COM_DT_DMIC_AwdModSta DMIC_AwdModSta;
  COM_DT_DMIC_DrvMod2Typ DMIC_DrvMod2Typ;
  COM_DT_DMIC_DrvModFltSta DMIC_DrvModFltSta;
  COM_DT_DMIC_DrvModSta DMIC_DrvModSta;
  COM_DT_DMIC_DrvModTyp DMIC_DrvModTyp;
  COM_DT_DMIC_EcsFltSta DMIC_EcsFltSta;
  COM_DT_DMIC_EcsModSta DMIC_EcsModSta;
  COM_DT_DMIC_ElsdFltSta DMIC_ElsdFltSta;
  COM_DT_DMIC_ElsdModSta DMIC_ElsdModSta;
  COM_DT_DMIC_EngFltSta DMIC_EngFltSta;
  COM_DT_DMIC_EngModSta DMIC_EngModSta;
  COM_DT_DMIC_EscFltSta DMIC_EscFltSta;
  COM_DT_DMIC_EscModSta DMIC_EscModSta;
  COM_DT_DMIC_EsndFltSta DMIC_EsndFltSta;
  COM_DT_DMIC_EsndModSta DMIC_EsndModSta;
  COM_DT_DMIC_IndAccSenSta DMIC_IndAccSenSta;
  COM_DT_DMIC_IndAwdModSta DMIC_IndAwdModSta;
  COM_DT_DMIC_IndDecSenSta DMIC_IndDecSenSta;
  COM_DT_DMIC_IndEcsModSta DMIC_IndEcsModSta;
  COM_DT_DMIC_IndElsdModSta DMIC_IndElsdModSta;
  COM_DT_DMIC_IndEscModSta DMIC_IndEscModSta;
  COM_DT_DMIC_IndEsndModSta DMIC_IndEsndModSta;
  COM_DT_DMIC_IndMaxVehSpdSta DMIC_IndMaxVehSpdSta;
  COM_DT_DMIC_IndMdpsModSta DMIC_IndMdpsModSta;
  COM_DT_DMIC_IndMtrPwrSta DMIC_IndMtrPwrSta;
  COM_DT_DMIC_IndPrflModSta DMIC_IndPrflModSta;
  COM_DT_DMIC_IndRevModSta DMIC_IndRevModSta;
  COM_DT_DMIC_IndRwsModSta DMIC_IndRwsModSta;
  COM_DT_DMIC_IndTmModSta DMIC_IndTmModSta;
  COM_DT_DMIC_IndVcuModSta DMIC_IndVcuModSta;
  COM_DT_DMIC_IndWhlDrvSta DMIC_IndWhlDrvSta;
  COM_DT_DMIC_MdpsFltSta DMIC_MdpsFltSta;
  COM_DT_DMIC_MdpsModSta DMIC_MdpsModSta;
  COM_DT_DMIC_PrflFltSta DMIC_PrflFltSta;
  COM_DT_DMIC_PrflModSta DMIC_PrflModSta;
  COM_DT_DMIC_RevFltSta DMIC_RevFltSta;
  COM_DT_DMIC_RevModSta DMIC_RevModSta;
  COM_DT_DMIC_RwsFltSta DMIC_RwsFltSta;
  COM_DT_DMIC_RwsModSta DMIC_RwsModSta;
  COM_DT_DMIC_SmtShftModSta DMIC_SmtShftModSta;
  COM_DT_DMIC_TmFltSta DMIC_TmFltSta;
  COM_DT_DMIC_TmModSta DMIC_TmModSta;
  COM_DT_DMIC_VcuFltSta DMIC_VcuFltSta;
  COM_DT_DMIC_VcuModSta DMIC_VcuModSta;
  COM_DT_ICSC_AlvCnt2Val ICSC_AlvCnt2Val;
  COM_DT_ICSC_Crc2Val ICSC_Crc2Val;
} COM_DT_SG_ICSC_02_100ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICU_02_200ms_SignalGroup
typedef struct
{
  COM_DT_ICU_AlvCnt2Val ICU_AlvCnt2Val;
  COM_DT_ICU_Crc2Val ICU_Crc2Val;
  COM_DT_ICU_MtGearPosRSta ICU_MtGearPosRSta;
  COM_DT_Warn_AsstDrSwSta Warn_AsstDrSwSta;
  COM_DT_Warn_DrvDrSwSta Warn_DrvDrSwSta;
  COM_DT_Warn_DrvStBltSwSta Warn_DrvStBltSwSta;
  COM_DT_Warn_RrLftDrSwSta Warn_RrLftDrSwSta;
  COM_DT_Warn_RrRtDrSwSta Warn_RrRtDrSwSta;
  COM_DT_Autocut_DlvryModSta Autocut_DlvryModSta;
  COM_DT_DoorLock_AsstDrUnLkSta DoorLock_AsstDrUnLkSta;
  COM_DT_DoorLock_DrvKeyLkSwSta DoorLock_DrvKeyLkSwSta;
  COM_DT_DoorLock_DrvKeyUnLkSwSta DoorLock_DrvKeyUnLkSwSta;
  COM_DT_DoorLock_RrLftDrUnLkSta DoorLock_RrLftDrUnLkSta;
  COM_DT_DoorLock_RrRtDrUnLkSta DoorLock_RrRtDrUnLkSta;
  COM_DT_ICU_Haptic_OPT ICU_Haptic_OPT;
  COM_DT_Warn_AsstStBltSwSta Warn_AsstStBltSwSta;
  COM_DT_Warn_BrkFldSwSta Warn_BrkFldSwSta;
  COM_DT_Warn_HoodSwMemorySta Warn_HoodSwMemorySta;
  COM_DT_Warn_HoodSwSta Warn_HoodSwSta;
  COM_DT_Warn_PassStOccSta Warn_PassStOccSta;
  COM_DT_Warn_PrkngBrkSwSta Warn_PrkngBrkSwSta;
  COM_DT_Warn_RrCtrStBltSwSta Warn_RrCtrStBltSwSta;
  COM_DT_Warn_RrLftStBltSwSta Warn_RrLftStBltSwSta;
  COM_DT_Warn_RrRtStBltSwSta Warn_RrRtStBltSwSta;
  COM_DT_Warn_WshrFldSwSta Warn_WshrFldSwSta;
} COM_DT_SG_ICU_02_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICU_04_200ms_SignalGroup
typedef struct
{
  COM_DT_ExtLamp_HzrdSwSta ExtLamp_HzrdSwSta;
  COM_DT_ICU_AlvCnt4Val ICU_AlvCnt4Val;
  COM_DT_ICU_Crc4Val ICU_Crc4Val;
  COM_DT_ICU_HDPSpprtRdy ICU_HDPSpprtRdy;
  COM_DT_IntLamp_InlTailLmpSta IntLamp_InlTailLmpSta;
  COM_DT_Lamp_LedHdLmpSta Lamp_LedHdLmpSta;
  COM_DT_Lamp_TrnSigLmpLftActiveSt Lamp_TrnSigLmpLftActiveSt;
  COM_DT_Lamp_TrnSigLmpLftOnReq Lamp_TrnSigLmpLftOnReq;
  COM_DT_Lamp_TrnSigLmpRtActiveSt Lamp_TrnSigLmpRtActiveSt;
  COM_DT_Lamp_TrnSigLmpRtOnReq Lamp_TrnSigLmpRtOnReq;
  COM_DT_TrnLmpSeqEnblCmd TrnLmpSeqEnblCmd;
} COM_DT_SG_ICU_04_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_ICU_07_200ms_SignalGroup
typedef struct
{
  COM_DT_ExtLamp_TrnSigLmpLftSwSta ExtLamp_TrnSigLmpLftSwSta;
  COM_DT_ExtLamp_TrnSigLmpRtSwSta ExtLamp_TrnSigLmpRtSwSta;
  COM_DT_ChildLock_ActnFlSta ChildLock_ActnFlSta;
  COM_DT_ICU_AlvCnt7Val ICU_AlvCnt7Val;
  COM_DT_ICU_Crc7Val ICU_Crc7Val;
  COM_DT_Lamp_LaneChgTrnSigLftSwSta_ICU Lamp_LaneChgTrnSigLftSwSta_ICU;
  COM_DT_Lamp_LaneChgTrnSigRtSwSta_ICU Lamp_LaneChgTrnSigRtSwSta_ICU;
  COM_DT_USM_FuncForMdLmpBrgtSta USM_FuncForMdLmpBrgtSta;
} COM_DT_SG_ICU_07_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_IEB_01_10ms_SignalGroup
typedef struct
{
  COM_DT_IEB_StrkDpthmmVal IEB_StrkDpthmmVal;
  COM_DT_IEB_AbsNGearReq IEB_AbsNGearReq;
  COM_DT_IEB_ActvSta IEB_ActvSta;
  COM_DT_IEB_AlvCnt1Val IEB_AlvCnt1Val;
  COM_DT_IEB_BrkActvSta IEB_BrkActvSta;
  COM_DT_IEB_BzrSta IEB_BzrSta;
  COM_DT_IEB_Crc1Val IEB_Crc1Val;
  COM_DT_IEB_DfctvSta IEB_DfctvSta;
  COM_DT_IEB_DiagSta IEB_DiagSta;
  COM_DT_IEB_DriftModeActSta IEB_DriftModeActSta;
  COM_DT_IEB_DriftModeSta IEB_DriftModeSta;
  COM_DT_IEB_DrvWhlSlipFlg_Frnt IEB_DrvWhlSlipFlg_Frnt;
  COM_DT_IEB_EstBrkPdlValVldSta IEB_EstBrkPdlValVldSta;
  COM_DT_IEB_EstBrkSacFrcNmVal IEB_EstBrkSacFrcNmVal;
  COM_DT_IEB_EstDpthPcVal IEB_EstDpthPcVal;
  COM_DT_IEB_EstTtlBrkFrcNmVal IEB_EstTtlBrkFrcNmVal;
  COM_DT_IEB_InhbtTrnstnTo4wd_Req IEB_InhbtTrnstnTo4wd_Req;
  COM_DT_IEB_MILReq IEB_MILReq;
  COM_DT_IEB_PdlCalibSta IEB_PdlCalibSta;
  COM_DT_IEB_PdlTrvlSnsrFailSta IEB_PdlTrvlSnsrFailSta;
  COM_DT_IEB_RbsWrngLmpSta IEB_RbsWrngLmpSta;
  COM_DT_IEB_RegenTqLimitNmVal_Frnt IEB_RegenTqLimitNmVal_Frnt;
  COM_DT_IEB_RegenTqLimitNmVal_Rear IEB_RegenTqLimitNmVal_Rear;
  COM_DT_IEB_RSC_Req IEB_RSC_Req;
  COM_DT_IEB_SnsrFailSta IEB_SnsrFailSta;
  COM_DT_IEB_SrvLmpDis IEB_SrvLmpDis;
  COM_DT_IEB_Sta IEB_Sta;
  COM_DT_IEB_StrkDpthPcVal IEB_StrkDpthPcVal;
  COM_DT_IEB_TCS_Req IEB_TCS_Req;
  COM_DT_IEB_VacSysDfctvSta IEB_VacSysDfctvSta;
  COM_DT_IEB_WrngLmpDis IEB_WrngLmpDis;
  COM_DT_RSC_TqFlag_Frnt RSC_TqFlag_Frnt;
  COM_DT_RSC_TqFlag_Rear RSC_TqFlag_Rear;
  COM_DT_RSC_TqIntrvntnVal_Frnt RSC_TqIntrvntnVal_Frnt;
  COM_DT_RSC_TqIntrvntnVal_Rear RSC_TqIntrvntnVal_Rear;
  COM_DT_TCS_MtrTrgtRpm_Flag_Frnt TCS_MtrTrgtRpm_Flag_Frnt;
  COM_DT_TCS_MtrTrgtRpm_Flag_Rear TCS_MtrTrgtRpm_Flag_Rear;
  COM_DT_TCS_MtrTrgtRpm_Frnt TCS_MtrTrgtRpm_Frnt;
  COM_DT_TCS_MtrTrgtRpm_Rear TCS_MtrTrgtRpm_Rear;
  COM_DT_TCS_TqFlag_Frnt TCS_TqFlag_Frnt;
  COM_DT_TCS_TqFlag_Rear TCS_TqFlag_Rear;
  COM_DT_TCS_TqIntrvntnVal_Frnt TCS_TqIntrvntnVal_Frnt;
  COM_DT_TCS_TqIntrvntnVal_Rear TCS_TqIntrvntnVal_Rear;
} COM_DT_SG_IEB_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt01Val FR_RDR_Det_AlvCnt01Val;
  COM_DT_FR_RDR_Det_AmbigSpeed01 FR_RDR_Det_AmbigSpeed01;
  COM_DT_FR_RDR_Det_AmbigSpeed02 FR_RDR_Det_AmbigSpeed02;
  COM_DT_FR_RDR_Det_AmbigSpeed03 FR_RDR_Det_AmbigSpeed03;
  COM_DT_FR_RDR_Det_AmbigSpeed04 FR_RDR_Det_AmbigSpeed04;
  COM_DT_FR_RDR_Det_AssignTag01 FR_RDR_Det_AssignTag01;
  COM_DT_FR_RDR_Det_AssignTag02 FR_RDR_Det_AssignTag02;
  COM_DT_FR_RDR_Det_AssignTag03 FR_RDR_Det_AssignTag03;
  COM_DT_FR_RDR_Det_AssignTag04 FR_RDR_Det_AssignTag04;
  COM_DT_FR_RDR_Det_Attribute01 FR_RDR_Det_Attribute01;
  COM_DT_FR_RDR_Det_Attribute02 FR_RDR_Det_Attribute02;
  COM_DT_FR_RDR_Det_Attribute03 FR_RDR_Det_Attribute03;
  COM_DT_FR_RDR_Det_Attribute04 FR_RDR_Det_Attribute04;
  COM_DT_FR_RDR_Det_ClusterID01 FR_RDR_Det_ClusterID01;
  COM_DT_FR_RDR_Det_ClusterID02 FR_RDR_Det_ClusterID02;
  COM_DT_FR_RDR_Det_ClusterID03 FR_RDR_Det_ClusterID03;
  COM_DT_FR_RDR_Det_ClusterID04 FR_RDR_Det_ClusterID04;
  COM_DT_FR_RDR_Det_CRC01Val FR_RDR_Det_CRC01Val;
  COM_DT_FR_RDR_Det_Height01 FR_RDR_Det_Height01;
  COM_DT_FR_RDR_Det_Height02 FR_RDR_Det_Height02;
  COM_DT_FR_RDR_Det_Height03 FR_RDR_Det_Height03;
  COM_DT_FR_RDR_Det_Height04 FR_RDR_Det_Height04;
  COM_DT_FR_RDR_Det_Lat01 FR_RDR_Det_Lat01;
  COM_DT_FR_RDR_Det_Lat02 FR_RDR_Det_Lat02;
  COM_DT_FR_RDR_Det_Lat03 FR_RDR_Det_Lat03;
  COM_DT_FR_RDR_Det_Lat04 FR_RDR_Det_Lat04;
  COM_DT_FR_RDR_Det_Long01 FR_RDR_Det_Long01;
  COM_DT_FR_RDR_Det_Long02 FR_RDR_Det_Long02;
  COM_DT_FR_RDR_Det_Long03 FR_RDR_Det_Long03;
  COM_DT_FR_RDR_Det_Long04 FR_RDR_Det_Long04;
  COM_DT_FR_RDR_Det_Mov01 FR_RDR_Det_Mov01;
  COM_DT_FR_RDR_Det_Mov02 FR_RDR_Det_Mov02;
  COM_DT_FR_RDR_Det_Mov03 FR_RDR_Det_Mov03;
  COM_DT_FR_RDR_Det_Mov04 FR_RDR_Det_Mov04;
  COM_DT_FR_RDR_Det_SNR01 FR_RDR_Det_SNR01;
  COM_DT_FR_RDR_Det_SNR02 FR_RDR_Det_SNR02;
  COM_DT_FR_RDR_Det_SNR03 FR_RDR_Det_SNR03;
  COM_DT_FR_RDR_Det_SNR04 FR_RDR_Det_SNR04;
  COM_DT_FR_RDR_Det_Speed01 FR_RDR_Det_Speed01;
  COM_DT_FR_RDR_Det_Speed02 FR_RDR_Det_Speed02;
  COM_DT_FR_RDR_Det_Speed03 FR_RDR_Det_Speed03;
  COM_DT_FR_RDR_Det_Speed04 FR_RDR_Det_Speed04;
  COM_DT_FR_RDR_Det_TrustA01 FR_RDR_Det_TrustA01;
  COM_DT_FR_RDR_Det_TrustA02 FR_RDR_Det_TrustA02;
  COM_DT_FR_RDR_Det_TrustA03 FR_RDR_Det_TrustA03;
  COM_DT_FR_RDR_Det_TrustA04 FR_RDR_Det_TrustA04;
  COM_DT_FR_RDR_Det_TrustV01 FR_RDR_Det_TrustV01;
  COM_DT_FR_RDR_Det_TrustV02 FR_RDR_Det_TrustV02;
  COM_DT_FR_RDR_Det_TrustV03 FR_RDR_Det_TrustV03;
  COM_DT_FR_RDR_Det_TrustV04 FR_RDR_Det_TrustV04;
  COM_DT_FR_RDR_Det_Valid01 FR_RDR_Det_Valid01;
  COM_DT_FR_RDR_Det_Valid02 FR_RDR_Det_Valid02;
  COM_DT_FR_RDR_Det_Valid03 FR_RDR_Det_Valid03;
  COM_DT_FR_RDR_Det_Valid04 FR_RDR_Det_Valid04;
} COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt02Val FR_RDR_Det_AlvCnt02Val;
  COM_DT_FR_RDR_Det_AmbigSpeed05 FR_RDR_Det_AmbigSpeed05;
  COM_DT_FR_RDR_Det_AmbigSpeed06 FR_RDR_Det_AmbigSpeed06;
  COM_DT_FR_RDR_Det_AmbigSpeed07 FR_RDR_Det_AmbigSpeed07;
  COM_DT_FR_RDR_Det_AmbigSpeed08 FR_RDR_Det_AmbigSpeed08;
  COM_DT_FR_RDR_Det_AssignTag05 FR_RDR_Det_AssignTag05;
  COM_DT_FR_RDR_Det_AssignTag06 FR_RDR_Det_AssignTag06;
  COM_DT_FR_RDR_Det_AssignTag07 FR_RDR_Det_AssignTag07;
  COM_DT_FR_RDR_Det_AssignTag08 FR_RDR_Det_AssignTag08;
  COM_DT_FR_RDR_Det_Attribute05 FR_RDR_Det_Attribute05;
  COM_DT_FR_RDR_Det_Attribute06 FR_RDR_Det_Attribute06;
  COM_DT_FR_RDR_Det_Attribute07 FR_RDR_Det_Attribute07;
  COM_DT_FR_RDR_Det_Attribute08 FR_RDR_Det_Attribute08;
  COM_DT_FR_RDR_Det_ClusterID05 FR_RDR_Det_ClusterID05;
  COM_DT_FR_RDR_Det_ClusterID06 FR_RDR_Det_ClusterID06;
  COM_DT_FR_RDR_Det_ClusterID07 FR_RDR_Det_ClusterID07;
  COM_DT_FR_RDR_Det_ClusterID08 FR_RDR_Det_ClusterID08;
  COM_DT_FR_RDR_Det_CRC02Val FR_RDR_Det_CRC02Val;
  COM_DT_FR_RDR_Det_Height05 FR_RDR_Det_Height05;
  COM_DT_FR_RDR_Det_Height06 FR_RDR_Det_Height06;
  COM_DT_FR_RDR_Det_Height07 FR_RDR_Det_Height07;
  COM_DT_FR_RDR_Det_Height08 FR_RDR_Det_Height08;
  COM_DT_FR_RDR_Det_Lat05 FR_RDR_Det_Lat05;
  COM_DT_FR_RDR_Det_Lat06 FR_RDR_Det_Lat06;
  COM_DT_FR_RDR_Det_Lat07 FR_RDR_Det_Lat07;
  COM_DT_FR_RDR_Det_Lat08 FR_RDR_Det_Lat08;
  COM_DT_FR_RDR_Det_Long05 FR_RDR_Det_Long05;
  COM_DT_FR_RDR_Det_Long06 FR_RDR_Det_Long06;
  COM_DT_FR_RDR_Det_Long07 FR_RDR_Det_Long07;
  COM_DT_FR_RDR_Det_Long08 FR_RDR_Det_Long08;
  COM_DT_FR_RDR_Det_Mov05 FR_RDR_Det_Mov05;
  COM_DT_FR_RDR_Det_Mov06 FR_RDR_Det_Mov06;
  COM_DT_FR_RDR_Det_Mov07 FR_RDR_Det_Mov07;
  COM_DT_FR_RDR_Det_Mov08 FR_RDR_Det_Mov08;
  COM_DT_FR_RDR_Det_SNR05 FR_RDR_Det_SNR05;
  COM_DT_FR_RDR_Det_SNR06 FR_RDR_Det_SNR06;
  COM_DT_FR_RDR_Det_SNR07 FR_RDR_Det_SNR07;
  COM_DT_FR_RDR_Det_SNR08 FR_RDR_Det_SNR08;
  COM_DT_FR_RDR_Det_Speed05 FR_RDR_Det_Speed05;
  COM_DT_FR_RDR_Det_Speed06 FR_RDR_Det_Speed06;
  COM_DT_FR_RDR_Det_Speed07 FR_RDR_Det_Speed07;
  COM_DT_FR_RDR_Det_Speed08 FR_RDR_Det_Speed08;
  COM_DT_FR_RDR_Det_TrustA05 FR_RDR_Det_TrustA05;
  COM_DT_FR_RDR_Det_TrustA06 FR_RDR_Det_TrustA06;
  COM_DT_FR_RDR_Det_TrustA07 FR_RDR_Det_TrustA07;
  COM_DT_FR_RDR_Det_TrustA08 FR_RDR_Det_TrustA08;
  COM_DT_FR_RDR_Det_TrustV05 FR_RDR_Det_TrustV05;
  COM_DT_FR_RDR_Det_TrustV06 FR_RDR_Det_TrustV06;
  COM_DT_FR_RDR_Det_TrustV07 FR_RDR_Det_TrustV07;
  COM_DT_FR_RDR_Det_TrustV08 FR_RDR_Det_TrustV08;
  COM_DT_FR_RDR_Det_Valid05 FR_RDR_Det_Valid05;
  COM_DT_FR_RDR_Det_Valid06 FR_RDR_Det_Valid06;
  COM_DT_FR_RDR_Det_Valid07 FR_RDR_Det_Valid07;
  COM_DT_FR_RDR_Det_Valid08 FR_RDR_Det_Valid08;
} COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt03Val FR_RDR_Det_AlvCnt03Val;
  COM_DT_FR_RDR_Det_AmbigSpeed09 FR_RDR_Det_AmbigSpeed09;
  COM_DT_FR_RDR_Det_AmbigSpeed10 FR_RDR_Det_AmbigSpeed10;
  COM_DT_FR_RDR_Det_AmbigSpeed11 FR_RDR_Det_AmbigSpeed11;
  COM_DT_FR_RDR_Det_AmbigSpeed12 FR_RDR_Det_AmbigSpeed12;
  COM_DT_FR_RDR_Det_AssignTag09 FR_RDR_Det_AssignTag09;
  COM_DT_FR_RDR_Det_AssignTag10 FR_RDR_Det_AssignTag10;
  COM_DT_FR_RDR_Det_AssignTag11 FR_RDR_Det_AssignTag11;
  COM_DT_FR_RDR_Det_AssignTag12 FR_RDR_Det_AssignTag12;
  COM_DT_FR_RDR_Det_Attribute09 FR_RDR_Det_Attribute09;
  COM_DT_FR_RDR_Det_Attribute10 FR_RDR_Det_Attribute10;
  COM_DT_FR_RDR_Det_Attribute11 FR_RDR_Det_Attribute11;
  COM_DT_FR_RDR_Det_Attribute12 FR_RDR_Det_Attribute12;
  COM_DT_FR_RDR_Det_ClusterID09 FR_RDR_Det_ClusterID09;
  COM_DT_FR_RDR_Det_ClusterID10 FR_RDR_Det_ClusterID10;
  COM_DT_FR_RDR_Det_ClusterID11 FR_RDR_Det_ClusterID11;
  COM_DT_FR_RDR_Det_ClusterID12 FR_RDR_Det_ClusterID12;
  COM_DT_FR_RDR_Det_CRC03Val FR_RDR_Det_CRC03Val;
  COM_DT_FR_RDR_Det_Height09 FR_RDR_Det_Height09;
  COM_DT_FR_RDR_Det_Height10 FR_RDR_Det_Height10;
  COM_DT_FR_RDR_Det_Height11 FR_RDR_Det_Height11;
  COM_DT_FR_RDR_Det_Height12 FR_RDR_Det_Height12;
  COM_DT_FR_RDR_Det_Lat09 FR_RDR_Det_Lat09;
  COM_DT_FR_RDR_Det_Lat10 FR_RDR_Det_Lat10;
  COM_DT_FR_RDR_Det_Lat11 FR_RDR_Det_Lat11;
  COM_DT_FR_RDR_Det_Lat12 FR_RDR_Det_Lat12;
  COM_DT_FR_RDR_Det_Long09 FR_RDR_Det_Long09;
  COM_DT_FR_RDR_Det_Long10 FR_RDR_Det_Long10;
  COM_DT_FR_RDR_Det_Long11 FR_RDR_Det_Long11;
  COM_DT_FR_RDR_Det_Long12 FR_RDR_Det_Long12;
  COM_DT_FR_RDR_Det_Mov09 FR_RDR_Det_Mov09;
  COM_DT_FR_RDR_Det_Mov10 FR_RDR_Det_Mov10;
  COM_DT_FR_RDR_Det_Mov11 FR_RDR_Det_Mov11;
  COM_DT_FR_RDR_Det_Mov12 FR_RDR_Det_Mov12;
  COM_DT_FR_RDR_Det_SNR09 FR_RDR_Det_SNR09;
  COM_DT_FR_RDR_Det_SNR10 FR_RDR_Det_SNR10;
  COM_DT_FR_RDR_Det_SNR11 FR_RDR_Det_SNR11;
  COM_DT_FR_RDR_Det_SNR12 FR_RDR_Det_SNR12;
  COM_DT_FR_RDR_Det_Speed09 FR_RDR_Det_Speed09;
  COM_DT_FR_RDR_Det_Speed10 FR_RDR_Det_Speed10;
  COM_DT_FR_RDR_Det_Speed11 FR_RDR_Det_Speed11;
  COM_DT_FR_RDR_Det_Speed12 FR_RDR_Det_Speed12;
  COM_DT_FR_RDR_Det_TrustA09 FR_RDR_Det_TrustA09;
  COM_DT_FR_RDR_Det_TrustA10 FR_RDR_Det_TrustA10;
  COM_DT_FR_RDR_Det_TrustA11 FR_RDR_Det_TrustA11;
  COM_DT_FR_RDR_Det_TrustA12 FR_RDR_Det_TrustA12;
  COM_DT_FR_RDR_Det_TrustV09 FR_RDR_Det_TrustV09;
  COM_DT_FR_RDR_Det_TrustV10 FR_RDR_Det_TrustV10;
  COM_DT_FR_RDR_Det_TrustV11 FR_RDR_Det_TrustV11;
  COM_DT_FR_RDR_Det_TrustV12 FR_RDR_Det_TrustV12;
  COM_DT_FR_RDR_Det_Valid09 FR_RDR_Det_Valid09;
  COM_DT_FR_RDR_Det_Valid10 FR_RDR_Det_Valid10;
  COM_DT_FR_RDR_Det_Valid11 FR_RDR_Det_Valid11;
  COM_DT_FR_RDR_Det_Valid12 FR_RDR_Det_Valid12;
} COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt04Val FR_RDR_Det_AlvCnt04Val;
  COM_DT_FR_RDR_Det_AmbigSpeed13 FR_RDR_Det_AmbigSpeed13;
  COM_DT_FR_RDR_Det_AmbigSpeed14 FR_RDR_Det_AmbigSpeed14;
  COM_DT_FR_RDR_Det_AmbigSpeed15 FR_RDR_Det_AmbigSpeed15;
  COM_DT_FR_RDR_Det_AmbigSpeed16 FR_RDR_Det_AmbigSpeed16;
  COM_DT_FR_RDR_Det_AssignTag13 FR_RDR_Det_AssignTag13;
  COM_DT_FR_RDR_Det_AssignTag14 FR_RDR_Det_AssignTag14;
  COM_DT_FR_RDR_Det_AssignTag15 FR_RDR_Det_AssignTag15;
  COM_DT_FR_RDR_Det_AssignTag16 FR_RDR_Det_AssignTag16;
  COM_DT_FR_RDR_Det_Attribute13 FR_RDR_Det_Attribute13;
  COM_DT_FR_RDR_Det_Attribute14 FR_RDR_Det_Attribute14;
  COM_DT_FR_RDR_Det_Attribute15 FR_RDR_Det_Attribute15;
  COM_DT_FR_RDR_Det_Attribute16 FR_RDR_Det_Attribute16;
  COM_DT_FR_RDR_Det_ClusterID13 FR_RDR_Det_ClusterID13;
  COM_DT_FR_RDR_Det_ClusterID14 FR_RDR_Det_ClusterID14;
  COM_DT_FR_RDR_Det_ClusterID15 FR_RDR_Det_ClusterID15;
  COM_DT_FR_RDR_Det_ClusterID16 FR_RDR_Det_ClusterID16;
  COM_DT_FR_RDR_Det_CRC04Val FR_RDR_Det_CRC04Val;
  COM_DT_FR_RDR_Det_Height13 FR_RDR_Det_Height13;
  COM_DT_FR_RDR_Det_Height14 FR_RDR_Det_Height14;
  COM_DT_FR_RDR_Det_Height15 FR_RDR_Det_Height15;
  COM_DT_FR_RDR_Det_Height16 FR_RDR_Det_Height16;
  COM_DT_FR_RDR_Det_Lat13 FR_RDR_Det_Lat13;
  COM_DT_FR_RDR_Det_Lat14 FR_RDR_Det_Lat14;
  COM_DT_FR_RDR_Det_Lat15 FR_RDR_Det_Lat15;
  COM_DT_FR_RDR_Det_Lat16 FR_RDR_Det_Lat16;
  COM_DT_FR_RDR_Det_Long13 FR_RDR_Det_Long13;
  COM_DT_FR_RDR_Det_Long14 FR_RDR_Det_Long14;
  COM_DT_FR_RDR_Det_Long15 FR_RDR_Det_Long15;
  COM_DT_FR_RDR_Det_Long16 FR_RDR_Det_Long16;
  COM_DT_FR_RDR_Det_Mov13 FR_RDR_Det_Mov13;
  COM_DT_FR_RDR_Det_Mov14 FR_RDR_Det_Mov14;
  COM_DT_FR_RDR_Det_Mov15 FR_RDR_Det_Mov15;
  COM_DT_FR_RDR_Det_Mov16 FR_RDR_Det_Mov16;
  COM_DT_FR_RDR_Det_SNR13 FR_RDR_Det_SNR13;
  COM_DT_FR_RDR_Det_SNR14 FR_RDR_Det_SNR14;
  COM_DT_FR_RDR_Det_SNR15 FR_RDR_Det_SNR15;
  COM_DT_FR_RDR_Det_SNR16 FR_RDR_Det_SNR16;
  COM_DT_FR_RDR_Det_Speed13 FR_RDR_Det_Speed13;
  COM_DT_FR_RDR_Det_Speed14 FR_RDR_Det_Speed14;
  COM_DT_FR_RDR_Det_Speed15 FR_RDR_Det_Speed15;
  COM_DT_FR_RDR_Det_Speed16 FR_RDR_Det_Speed16;
  COM_DT_FR_RDR_Det_TrustA13 FR_RDR_Det_TrustA13;
  COM_DT_FR_RDR_Det_TrustA14 FR_RDR_Det_TrustA14;
  COM_DT_FR_RDR_Det_TrustA15 FR_RDR_Det_TrustA15;
  COM_DT_FR_RDR_Det_TrustA16 FR_RDR_Det_TrustA16;
  COM_DT_FR_RDR_Det_TrustV13 FR_RDR_Det_TrustV13;
  COM_DT_FR_RDR_Det_TrustV14 FR_RDR_Det_TrustV14;
  COM_DT_FR_RDR_Det_TrustV15 FR_RDR_Det_TrustV15;
  COM_DT_FR_RDR_Det_TrustV16 FR_RDR_Det_TrustV16;
  COM_DT_FR_RDR_Det_Valid13 FR_RDR_Det_Valid13;
  COM_DT_FR_RDR_Det_Valid14 FR_RDR_Det_Valid14;
  COM_DT_FR_RDR_Det_Valid15 FR_RDR_Det_Valid15;
  COM_DT_FR_RDR_Det_Valid16 FR_RDR_Det_Valid16;
} COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt05Val FR_RDR_Det_AlvCnt05Val;
  COM_DT_FR_RDR_Det_AmbigSpeed17 FR_RDR_Det_AmbigSpeed17;
  COM_DT_FR_RDR_Det_AmbigSpeed18 FR_RDR_Det_AmbigSpeed18;
  COM_DT_FR_RDR_Det_AmbigSpeed19 FR_RDR_Det_AmbigSpeed19;
  COM_DT_FR_RDR_Det_AmbigSpeed20 FR_RDR_Det_AmbigSpeed20;
  COM_DT_FR_RDR_Det_AssignTag17 FR_RDR_Det_AssignTag17;
  COM_DT_FR_RDR_Det_AssignTag18 FR_RDR_Det_AssignTag18;
  COM_DT_FR_RDR_Det_AssignTag19 FR_RDR_Det_AssignTag19;
  COM_DT_FR_RDR_Det_AssignTag20 FR_RDR_Det_AssignTag20;
  COM_DT_FR_RDR_Det_Attribute17 FR_RDR_Det_Attribute17;
  COM_DT_FR_RDR_Det_Attribute18 FR_RDR_Det_Attribute18;
  COM_DT_FR_RDR_Det_Attribute19 FR_RDR_Det_Attribute19;
  COM_DT_FR_RDR_Det_Attribute20 FR_RDR_Det_Attribute20;
  COM_DT_FR_RDR_Det_ClusterID17 FR_RDR_Det_ClusterID17;
  COM_DT_FR_RDR_Det_ClusterID18 FR_RDR_Det_ClusterID18;
  COM_DT_FR_RDR_Det_ClusterID19 FR_RDR_Det_ClusterID19;
  COM_DT_FR_RDR_Det_ClusterID20 FR_RDR_Det_ClusterID20;
  COM_DT_FR_RDR_Det_CRC05Val FR_RDR_Det_CRC05Val;
  COM_DT_FR_RDR_Det_Height17 FR_RDR_Det_Height17;
  COM_DT_FR_RDR_Det_Height18 FR_RDR_Det_Height18;
  COM_DT_FR_RDR_Det_Height19 FR_RDR_Det_Height19;
  COM_DT_FR_RDR_Det_Height20 FR_RDR_Det_Height20;
  COM_DT_FR_RDR_Det_Lat17 FR_RDR_Det_Lat17;
  COM_DT_FR_RDR_Det_Lat18 FR_RDR_Det_Lat18;
  COM_DT_FR_RDR_Det_Lat19 FR_RDR_Det_Lat19;
  COM_DT_FR_RDR_Det_Lat20 FR_RDR_Det_Lat20;
  COM_DT_FR_RDR_Det_Long17 FR_RDR_Det_Long17;
  COM_DT_FR_RDR_Det_Long18 FR_RDR_Det_Long18;
  COM_DT_FR_RDR_Det_Long19 FR_RDR_Det_Long19;
  COM_DT_FR_RDR_Det_Long20 FR_RDR_Det_Long20;
  COM_DT_FR_RDR_Det_Mov17 FR_RDR_Det_Mov17;
  COM_DT_FR_RDR_Det_Mov18 FR_RDR_Det_Mov18;
  COM_DT_FR_RDR_Det_Mov19 FR_RDR_Det_Mov19;
  COM_DT_FR_RDR_Det_Mov20 FR_RDR_Det_Mov20;
  COM_DT_FR_RDR_Det_SNR17 FR_RDR_Det_SNR17;
  COM_DT_FR_RDR_Det_SNR18 FR_RDR_Det_SNR18;
  COM_DT_FR_RDR_Det_SNR19 FR_RDR_Det_SNR19;
  COM_DT_FR_RDR_Det_SNR20 FR_RDR_Det_SNR20;
  COM_DT_FR_RDR_Det_Speed17 FR_RDR_Det_Speed17;
  COM_DT_FR_RDR_Det_Speed18 FR_RDR_Det_Speed18;
  COM_DT_FR_RDR_Det_Speed19 FR_RDR_Det_Speed19;
  COM_DT_FR_RDR_Det_Speed20 FR_RDR_Det_Speed20;
  COM_DT_FR_RDR_Det_TrustA17 FR_RDR_Det_TrustA17;
  COM_DT_FR_RDR_Det_TrustA18 FR_RDR_Det_TrustA18;
  COM_DT_FR_RDR_Det_TrustA19 FR_RDR_Det_TrustA19;
  COM_DT_FR_RDR_Det_TrustA20 FR_RDR_Det_TrustA20;
  COM_DT_FR_RDR_Det_TrustV17 FR_RDR_Det_TrustV17;
  COM_DT_FR_RDR_Det_TrustV18 FR_RDR_Det_TrustV18;
  COM_DT_FR_RDR_Det_TrustV19 FR_RDR_Det_TrustV19;
  COM_DT_FR_RDR_Det_TrustV20 FR_RDR_Det_TrustV20;
  COM_DT_FR_RDR_Det_Valid17 FR_RDR_Det_Valid17;
  COM_DT_FR_RDR_Det_Valid18 FR_RDR_Det_Valid18;
  COM_DT_FR_RDR_Det_Valid19 FR_RDR_Det_Valid19;
  COM_DT_FR_RDR_Det_Valid20 FR_RDR_Det_Valid20;
} COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt06Val FR_RDR_Det_AlvCnt06Val;
  COM_DT_FR_RDR_Det_AmbigSpeed21 FR_RDR_Det_AmbigSpeed21;
  COM_DT_FR_RDR_Det_AmbigSpeed22 FR_RDR_Det_AmbigSpeed22;
  COM_DT_FR_RDR_Det_AmbigSpeed23 FR_RDR_Det_AmbigSpeed23;
  COM_DT_FR_RDR_Det_AmbigSpeed24 FR_RDR_Det_AmbigSpeed24;
  COM_DT_FR_RDR_Det_AssignTag21 FR_RDR_Det_AssignTag21;
  COM_DT_FR_RDR_Det_AssignTag22 FR_RDR_Det_AssignTag22;
  COM_DT_FR_RDR_Det_AssignTag23 FR_RDR_Det_AssignTag23;
  COM_DT_FR_RDR_Det_AssignTag24 FR_RDR_Det_AssignTag24;
  COM_DT_FR_RDR_Det_Attribute21 FR_RDR_Det_Attribute21;
  COM_DT_FR_RDR_Det_Attribute22 FR_RDR_Det_Attribute22;
  COM_DT_FR_RDR_Det_Attribute23 FR_RDR_Det_Attribute23;
  COM_DT_FR_RDR_Det_Attribute24 FR_RDR_Det_Attribute24;
  COM_DT_FR_RDR_Det_ClusterID21 FR_RDR_Det_ClusterID21;
  COM_DT_FR_RDR_Det_ClusterID22 FR_RDR_Det_ClusterID22;
  COM_DT_FR_RDR_Det_ClusterID23 FR_RDR_Det_ClusterID23;
  COM_DT_FR_RDR_Det_ClusterID24 FR_RDR_Det_ClusterID24;
  COM_DT_FR_RDR_Det_CRC06Val FR_RDR_Det_CRC06Val;
  COM_DT_FR_RDR_Det_Height21 FR_RDR_Det_Height21;
  COM_DT_FR_RDR_Det_Height22 FR_RDR_Det_Height22;
  COM_DT_FR_RDR_Det_Height23 FR_RDR_Det_Height23;
  COM_DT_FR_RDR_Det_Height24 FR_RDR_Det_Height24;
  COM_DT_FR_RDR_Det_Lat21 FR_RDR_Det_Lat21;
  COM_DT_FR_RDR_Det_Lat22 FR_RDR_Det_Lat22;
  COM_DT_FR_RDR_Det_Lat23 FR_RDR_Det_Lat23;
  COM_DT_FR_RDR_Det_Lat24 FR_RDR_Det_Lat24;
  COM_DT_FR_RDR_Det_Long21 FR_RDR_Det_Long21;
  COM_DT_FR_RDR_Det_Long22 FR_RDR_Det_Long22;
  COM_DT_FR_RDR_Det_Long23 FR_RDR_Det_Long23;
  COM_DT_FR_RDR_Det_Long24 FR_RDR_Det_Long24;
  COM_DT_FR_RDR_Det_Mov21 FR_RDR_Det_Mov21;
  COM_DT_FR_RDR_Det_Mov22 FR_RDR_Det_Mov22;
  COM_DT_FR_RDR_Det_Mov23 FR_RDR_Det_Mov23;
  COM_DT_FR_RDR_Det_Mov24 FR_RDR_Det_Mov24;
  COM_DT_FR_RDR_Det_SNR21 FR_RDR_Det_SNR21;
  COM_DT_FR_RDR_Det_SNR22 FR_RDR_Det_SNR22;
  COM_DT_FR_RDR_Det_SNR23 FR_RDR_Det_SNR23;
  COM_DT_FR_RDR_Det_SNR24 FR_RDR_Det_SNR24;
  COM_DT_FR_RDR_Det_Speed21 FR_RDR_Det_Speed21;
  COM_DT_FR_RDR_Det_Speed22 FR_RDR_Det_Speed22;
  COM_DT_FR_RDR_Det_Speed23 FR_RDR_Det_Speed23;
  COM_DT_FR_RDR_Det_Speed24 FR_RDR_Det_Speed24;
  COM_DT_FR_RDR_Det_TrustA21 FR_RDR_Det_TrustA21;
  COM_DT_FR_RDR_Det_TrustA22 FR_RDR_Det_TrustA22;
  COM_DT_FR_RDR_Det_TrustA23 FR_RDR_Det_TrustA23;
  COM_DT_FR_RDR_Det_TrustA24 FR_RDR_Det_TrustA24;
  COM_DT_FR_RDR_Det_TrustV21 FR_RDR_Det_TrustV21;
  COM_DT_FR_RDR_Det_TrustV22 FR_RDR_Det_TrustV22;
  COM_DT_FR_RDR_Det_TrustV23 FR_RDR_Det_TrustV23;
  COM_DT_FR_RDR_Det_TrustV24 FR_RDR_Det_TrustV24;
  COM_DT_FR_RDR_Det_Valid21 FR_RDR_Det_Valid21;
  COM_DT_FR_RDR_Det_Valid22 FR_RDR_Det_Valid22;
  COM_DT_FR_RDR_Det_Valid23 FR_RDR_Det_Valid23;
  COM_DT_FR_RDR_Det_Valid24 FR_RDR_Det_Valid24;
} COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt07Val FR_RDR_Det_AlvCnt07Val;
  COM_DT_FR_RDR_Det_AmbigSpeed25 FR_RDR_Det_AmbigSpeed25;
  COM_DT_FR_RDR_Det_AmbigSpeed26 FR_RDR_Det_AmbigSpeed26;
  COM_DT_FR_RDR_Det_AmbigSpeed27 FR_RDR_Det_AmbigSpeed27;
  COM_DT_FR_RDR_Det_AmbigSpeed28 FR_RDR_Det_AmbigSpeed28;
  COM_DT_FR_RDR_Det_AssignTag25 FR_RDR_Det_AssignTag25;
  COM_DT_FR_RDR_Det_AssignTag26 FR_RDR_Det_AssignTag26;
  COM_DT_FR_RDR_Det_AssignTag27 FR_RDR_Det_AssignTag27;
  COM_DT_FR_RDR_Det_AssignTag28 FR_RDR_Det_AssignTag28;
  COM_DT_FR_RDR_Det_Attribute25 FR_RDR_Det_Attribute25;
  COM_DT_FR_RDR_Det_Attribute26 FR_RDR_Det_Attribute26;
  COM_DT_FR_RDR_Det_Attribute27 FR_RDR_Det_Attribute27;
  COM_DT_FR_RDR_Det_Attribute28 FR_RDR_Det_Attribute28;
  COM_DT_FR_RDR_Det_ClusterID25 FR_RDR_Det_ClusterID25;
  COM_DT_FR_RDR_Det_ClusterID26 FR_RDR_Det_ClusterID26;
  COM_DT_FR_RDR_Det_ClusterID27 FR_RDR_Det_ClusterID27;
  COM_DT_FR_RDR_Det_ClusterID28 FR_RDR_Det_ClusterID28;
  COM_DT_FR_RDR_Det_CRC07Val FR_RDR_Det_CRC07Val;
  COM_DT_FR_RDR_Det_Height25 FR_RDR_Det_Height25;
  COM_DT_FR_RDR_Det_Height26 FR_RDR_Det_Height26;
  COM_DT_FR_RDR_Det_Height27 FR_RDR_Det_Height27;
  COM_DT_FR_RDR_Det_Height28 FR_RDR_Det_Height28;
  COM_DT_FR_RDR_Det_Lat25 FR_RDR_Det_Lat25;
  COM_DT_FR_RDR_Det_Lat26 FR_RDR_Det_Lat26;
  COM_DT_FR_RDR_Det_Lat27 FR_RDR_Det_Lat27;
  COM_DT_FR_RDR_Det_Lat28 FR_RDR_Det_Lat28;
  COM_DT_FR_RDR_Det_Long25 FR_RDR_Det_Long25;
  COM_DT_FR_RDR_Det_Long26 FR_RDR_Det_Long26;
  COM_DT_FR_RDR_Det_Long27 FR_RDR_Det_Long27;
  COM_DT_FR_RDR_Det_Long28 FR_RDR_Det_Long28;
  COM_DT_FR_RDR_Det_Mov25 FR_RDR_Det_Mov25;
  COM_DT_FR_RDR_Det_Mov26 FR_RDR_Det_Mov26;
  COM_DT_FR_RDR_Det_Mov27 FR_RDR_Det_Mov27;
  COM_DT_FR_RDR_Det_Mov28 FR_RDR_Det_Mov28;
  COM_DT_FR_RDR_Det_SNR25 FR_RDR_Det_SNR25;
  COM_DT_FR_RDR_Det_SNR26 FR_RDR_Det_SNR26;
  COM_DT_FR_RDR_Det_SNR27 FR_RDR_Det_SNR27;
  COM_DT_FR_RDR_Det_SNR28 FR_RDR_Det_SNR28;
  COM_DT_FR_RDR_Det_Speed25 FR_RDR_Det_Speed25;
  COM_DT_FR_RDR_Det_Speed26 FR_RDR_Det_Speed26;
  COM_DT_FR_RDR_Det_Speed27 FR_RDR_Det_Speed27;
  COM_DT_FR_RDR_Det_Speed28 FR_RDR_Det_Speed28;
  COM_DT_FR_RDR_Det_TrustA25 FR_RDR_Det_TrustA25;
  COM_DT_FR_RDR_Det_TrustA26 FR_RDR_Det_TrustA26;
  COM_DT_FR_RDR_Det_TrustA27 FR_RDR_Det_TrustA27;
  COM_DT_FR_RDR_Det_TrustA28 FR_RDR_Det_TrustA28;
  COM_DT_FR_RDR_Det_TrustV25 FR_RDR_Det_TrustV25;
  COM_DT_FR_RDR_Det_TrustV26 FR_RDR_Det_TrustV26;
  COM_DT_FR_RDR_Det_TrustV27 FR_RDR_Det_TrustV27;
  COM_DT_FR_RDR_Det_TrustV28 FR_RDR_Det_TrustV28;
  COM_DT_FR_RDR_Det_Valid25 FR_RDR_Det_Valid25;
  COM_DT_FR_RDR_Det_Valid26 FR_RDR_Det_Valid26;
  COM_DT_FR_RDR_Det_Valid27 FR_RDR_Det_Valid27;
  COM_DT_FR_RDR_Det_Valid28 FR_RDR_Det_Valid28;
} COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt08Val FR_RDR_Det_AlvCnt08Val;
  COM_DT_FR_RDR_Det_AmbigSpeed29 FR_RDR_Det_AmbigSpeed29;
  COM_DT_FR_RDR_Det_AmbigSpeed30 FR_RDR_Det_AmbigSpeed30;
  COM_DT_FR_RDR_Det_AmbigSpeed31 FR_RDR_Det_AmbigSpeed31;
  COM_DT_FR_RDR_Det_AmbigSpeed32 FR_RDR_Det_AmbigSpeed32;
  COM_DT_FR_RDR_Det_AssignTag29 FR_RDR_Det_AssignTag29;
  COM_DT_FR_RDR_Det_AssignTag30 FR_RDR_Det_AssignTag30;
  COM_DT_FR_RDR_Det_AssignTag31 FR_RDR_Det_AssignTag31;
  COM_DT_FR_RDR_Det_AssignTag32 FR_RDR_Det_AssignTag32;
  COM_DT_FR_RDR_Det_Attribute29 FR_RDR_Det_Attribute29;
  COM_DT_FR_RDR_Det_Attribute30 FR_RDR_Det_Attribute30;
  COM_DT_FR_RDR_Det_Attribute31 FR_RDR_Det_Attribute31;
  COM_DT_FR_RDR_Det_Attribute32 FR_RDR_Det_Attribute32;
  COM_DT_FR_RDR_Det_ClusterID29 FR_RDR_Det_ClusterID29;
  COM_DT_FR_RDR_Det_ClusterID30 FR_RDR_Det_ClusterID30;
  COM_DT_FR_RDR_Det_ClusterID31 FR_RDR_Det_ClusterID31;
  COM_DT_FR_RDR_Det_ClusterID32 FR_RDR_Det_ClusterID32;
  COM_DT_FR_RDR_Det_CRC08Val FR_RDR_Det_CRC08Val;
  COM_DT_FR_RDR_Det_Height29 FR_RDR_Det_Height29;
  COM_DT_FR_RDR_Det_Height30 FR_RDR_Det_Height30;
  COM_DT_FR_RDR_Det_Height31 FR_RDR_Det_Height31;
  COM_DT_FR_RDR_Det_Height32 FR_RDR_Det_Height32;
  COM_DT_FR_RDR_Det_Lat29 FR_RDR_Det_Lat29;
  COM_DT_FR_RDR_Det_Lat30 FR_RDR_Det_Lat30;
  COM_DT_FR_RDR_Det_Lat31 FR_RDR_Det_Lat31;
  COM_DT_FR_RDR_Det_Lat32 FR_RDR_Det_Lat32;
  COM_DT_FR_RDR_Det_Long29 FR_RDR_Det_Long29;
  COM_DT_FR_RDR_Det_Long30 FR_RDR_Det_Long30;
  COM_DT_FR_RDR_Det_Long31 FR_RDR_Det_Long31;
  COM_DT_FR_RDR_Det_Long32 FR_RDR_Det_Long32;
  COM_DT_FR_RDR_Det_Mov29 FR_RDR_Det_Mov29;
  COM_DT_FR_RDR_Det_Mov30 FR_RDR_Det_Mov30;
  COM_DT_FR_RDR_Det_Mov31 FR_RDR_Det_Mov31;
  COM_DT_FR_RDR_Det_Mov32 FR_RDR_Det_Mov32;
  COM_DT_FR_RDR_Det_SNR29 FR_RDR_Det_SNR29;
  COM_DT_FR_RDR_Det_SNR30 FR_RDR_Det_SNR30;
  COM_DT_FR_RDR_Det_SNR31 FR_RDR_Det_SNR31;
  COM_DT_FR_RDR_Det_SNR32 FR_RDR_Det_SNR32;
  COM_DT_FR_RDR_Det_Speed29 FR_RDR_Det_Speed29;
  COM_DT_FR_RDR_Det_Speed30 FR_RDR_Det_Speed30;
  COM_DT_FR_RDR_Det_Speed31 FR_RDR_Det_Speed31;
  COM_DT_FR_RDR_Det_Speed32 FR_RDR_Det_Speed32;
  COM_DT_FR_RDR_Det_TrustA29 FR_RDR_Det_TrustA29;
  COM_DT_FR_RDR_Det_TrustA30 FR_RDR_Det_TrustA30;
  COM_DT_FR_RDR_Det_TrustA31 FR_RDR_Det_TrustA31;
  COM_DT_FR_RDR_Det_TrustA32 FR_RDR_Det_TrustA32;
  COM_DT_FR_RDR_Det_TrustV29 FR_RDR_Det_TrustV29;
  COM_DT_FR_RDR_Det_TrustV30 FR_RDR_Det_TrustV30;
  COM_DT_FR_RDR_Det_TrustV31 FR_RDR_Det_TrustV31;
  COM_DT_FR_RDR_Det_TrustV32 FR_RDR_Det_TrustV32;
  COM_DT_FR_RDR_Det_Valid29 FR_RDR_Det_Valid29;
  COM_DT_FR_RDR_Det_Valid30 FR_RDR_Det_Valid30;
  COM_DT_FR_RDR_Det_Valid31 FR_RDR_Det_Valid31;
  COM_DT_FR_RDR_Det_Valid32 FR_RDR_Det_Valid32;
} COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt09Val FR_RDR_Det_AlvCnt09Val;
  COM_DT_FR_RDR_Det_AmbigSpeed33 FR_RDR_Det_AmbigSpeed33;
  COM_DT_FR_RDR_Det_AmbigSpeed34 FR_RDR_Det_AmbigSpeed34;
  COM_DT_FR_RDR_Det_AmbigSpeed35 FR_RDR_Det_AmbigSpeed35;
  COM_DT_FR_RDR_Det_AmbigSpeed36 FR_RDR_Det_AmbigSpeed36;
  COM_DT_FR_RDR_Det_AssignTag33 FR_RDR_Det_AssignTag33;
  COM_DT_FR_RDR_Det_AssignTag34 FR_RDR_Det_AssignTag34;
  COM_DT_FR_RDR_Det_AssignTag35 FR_RDR_Det_AssignTag35;
  COM_DT_FR_RDR_Det_AssignTag36 FR_RDR_Det_AssignTag36;
  COM_DT_FR_RDR_Det_Attribute33 FR_RDR_Det_Attribute33;
  COM_DT_FR_RDR_Det_Attribute34 FR_RDR_Det_Attribute34;
  COM_DT_FR_RDR_Det_Attribute35 FR_RDR_Det_Attribute35;
  COM_DT_FR_RDR_Det_Attribute36 FR_RDR_Det_Attribute36;
  COM_DT_FR_RDR_Det_ClusterID33 FR_RDR_Det_ClusterID33;
  COM_DT_FR_RDR_Det_ClusterID34 FR_RDR_Det_ClusterID34;
  COM_DT_FR_RDR_Det_ClusterID35 FR_RDR_Det_ClusterID35;
  COM_DT_FR_RDR_Det_ClusterID36 FR_RDR_Det_ClusterID36;
  COM_DT_FR_RDR_Det_CRC09Val FR_RDR_Det_CRC09Val;
  COM_DT_FR_RDR_Det_Height33 FR_RDR_Det_Height33;
  COM_DT_FR_RDR_Det_Height34 FR_RDR_Det_Height34;
  COM_DT_FR_RDR_Det_Height35 FR_RDR_Det_Height35;
  COM_DT_FR_RDR_Det_Height36 FR_RDR_Det_Height36;
  COM_DT_FR_RDR_Det_Lat33 FR_RDR_Det_Lat33;
  COM_DT_FR_RDR_Det_Lat34 FR_RDR_Det_Lat34;
  COM_DT_FR_RDR_Det_Lat35 FR_RDR_Det_Lat35;
  COM_DT_FR_RDR_Det_Lat36 FR_RDR_Det_Lat36;
  COM_DT_FR_RDR_Det_Long33 FR_RDR_Det_Long33;
  COM_DT_FR_RDR_Det_Long34 FR_RDR_Det_Long34;
  COM_DT_FR_RDR_Det_Long35 FR_RDR_Det_Long35;
  COM_DT_FR_RDR_Det_Long36 FR_RDR_Det_Long36;
  COM_DT_FR_RDR_Det_Mov33 FR_RDR_Det_Mov33;
  COM_DT_FR_RDR_Det_Mov34 FR_RDR_Det_Mov34;
  COM_DT_FR_RDR_Det_Mov35 FR_RDR_Det_Mov35;
  COM_DT_FR_RDR_Det_Mov36 FR_RDR_Det_Mov36;
  COM_DT_FR_RDR_Det_SNR33 FR_RDR_Det_SNR33;
  COM_DT_FR_RDR_Det_SNR34 FR_RDR_Det_SNR34;
  COM_DT_FR_RDR_Det_SNR35 FR_RDR_Det_SNR35;
  COM_DT_FR_RDR_Det_SNR36 FR_RDR_Det_SNR36;
  COM_DT_FR_RDR_Det_Speed33 FR_RDR_Det_Speed33;
  COM_DT_FR_RDR_Det_Speed34 FR_RDR_Det_Speed34;
  COM_DT_FR_RDR_Det_Speed35 FR_RDR_Det_Speed35;
  COM_DT_FR_RDR_Det_Speed36 FR_RDR_Det_Speed36;
  COM_DT_FR_RDR_Det_TrustA33 FR_RDR_Det_TrustA33;
  COM_DT_FR_RDR_Det_TrustA34 FR_RDR_Det_TrustA34;
  COM_DT_FR_RDR_Det_TrustA35 FR_RDR_Det_TrustA35;
  COM_DT_FR_RDR_Det_TrustA36 FR_RDR_Det_TrustA36;
  COM_DT_FR_RDR_Det_TrustV33 FR_RDR_Det_TrustV33;
  COM_DT_FR_RDR_Det_TrustV34 FR_RDR_Det_TrustV34;
  COM_DT_FR_RDR_Det_TrustV35 FR_RDR_Det_TrustV35;
  COM_DT_FR_RDR_Det_TrustV36 FR_RDR_Det_TrustV36;
  COM_DT_FR_RDR_Det_Valid33 FR_RDR_Det_Valid33;
  COM_DT_FR_RDR_Det_Valid34 FR_RDR_Det_Valid34;
  COM_DT_FR_RDR_Det_Valid35 FR_RDR_Det_Valid35;
  COM_DT_FR_RDR_Det_Valid36 FR_RDR_Det_Valid36;
} COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt10Val FR_RDR_Det_AlvCnt10Val;
  COM_DT_FR_RDR_Det_AmbigSpeed37 FR_RDR_Det_AmbigSpeed37;
  COM_DT_FR_RDR_Det_AmbigSpeed38 FR_RDR_Det_AmbigSpeed38;
  COM_DT_FR_RDR_Det_AmbigSpeed39 FR_RDR_Det_AmbigSpeed39;
  COM_DT_FR_RDR_Det_AmbigSpeed40 FR_RDR_Det_AmbigSpeed40;
  COM_DT_FR_RDR_Det_AssignTag37 FR_RDR_Det_AssignTag37;
  COM_DT_FR_RDR_Det_AssignTag38 FR_RDR_Det_AssignTag38;
  COM_DT_FR_RDR_Det_AssignTag39 FR_RDR_Det_AssignTag39;
  COM_DT_FR_RDR_Det_AssignTag40 FR_RDR_Det_AssignTag40;
  COM_DT_FR_RDR_Det_Attribute37 FR_RDR_Det_Attribute37;
  COM_DT_FR_RDR_Det_Attribute38 FR_RDR_Det_Attribute38;
  COM_DT_FR_RDR_Det_Attribute39 FR_RDR_Det_Attribute39;
  COM_DT_FR_RDR_Det_Attribute40 FR_RDR_Det_Attribute40;
  COM_DT_FR_RDR_Det_ClusterID37 FR_RDR_Det_ClusterID37;
  COM_DT_FR_RDR_Det_ClusterID38 FR_RDR_Det_ClusterID38;
  COM_DT_FR_RDR_Det_ClusterID39 FR_RDR_Det_ClusterID39;
  COM_DT_FR_RDR_Det_ClusterID40 FR_RDR_Det_ClusterID40;
  COM_DT_FR_RDR_Det_CRC10Val FR_RDR_Det_CRC10Val;
  COM_DT_FR_RDR_Det_Height37 FR_RDR_Det_Height37;
  COM_DT_FR_RDR_Det_Height38 FR_RDR_Det_Height38;
  COM_DT_FR_RDR_Det_Height39 FR_RDR_Det_Height39;
  COM_DT_FR_RDR_Det_Height40 FR_RDR_Det_Height40;
  COM_DT_FR_RDR_Det_Lat37 FR_RDR_Det_Lat37;
  COM_DT_FR_RDR_Det_Lat38 FR_RDR_Det_Lat38;
  COM_DT_FR_RDR_Det_Lat39 FR_RDR_Det_Lat39;
  COM_DT_FR_RDR_Det_Lat40 FR_RDR_Det_Lat40;
  COM_DT_FR_RDR_Det_Long37 FR_RDR_Det_Long37;
  COM_DT_FR_RDR_Det_Long38 FR_RDR_Det_Long38;
  COM_DT_FR_RDR_Det_Long39 FR_RDR_Det_Long39;
  COM_DT_FR_RDR_Det_Long40 FR_RDR_Det_Long40;
  COM_DT_FR_RDR_Det_Mov37 FR_RDR_Det_Mov37;
  COM_DT_FR_RDR_Det_Mov38 FR_RDR_Det_Mov38;
  COM_DT_FR_RDR_Det_Mov39 FR_RDR_Det_Mov39;
  COM_DT_FR_RDR_Det_Mov40 FR_RDR_Det_Mov40;
  COM_DT_FR_RDR_Det_SNR37 FR_RDR_Det_SNR37;
  COM_DT_FR_RDR_Det_SNR38 FR_RDR_Det_SNR38;
  COM_DT_FR_RDR_Det_SNR39 FR_RDR_Det_SNR39;
  COM_DT_FR_RDR_Det_SNR40 FR_RDR_Det_SNR40;
  COM_DT_FR_RDR_Det_Speed37 FR_RDR_Det_Speed37;
  COM_DT_FR_RDR_Det_Speed38 FR_RDR_Det_Speed38;
  COM_DT_FR_RDR_Det_Speed39 FR_RDR_Det_Speed39;
  COM_DT_FR_RDR_Det_Speed40 FR_RDR_Det_Speed40;
  COM_DT_FR_RDR_Det_TrustA37 FR_RDR_Det_TrustA37;
  COM_DT_FR_RDR_Det_TrustA38 FR_RDR_Det_TrustA38;
  COM_DT_FR_RDR_Det_TrustA39 FR_RDR_Det_TrustA39;
  COM_DT_FR_RDR_Det_TrustA40 FR_RDR_Det_TrustA40;
  COM_DT_FR_RDR_Det_TrustV37 FR_RDR_Det_TrustV37;
  COM_DT_FR_RDR_Det_TrustV38 FR_RDR_Det_TrustV38;
  COM_DT_FR_RDR_Det_TrustV39 FR_RDR_Det_TrustV39;
  COM_DT_FR_RDR_Det_TrustV40 FR_RDR_Det_TrustV40;
  COM_DT_FR_RDR_Det_Valid37 FR_RDR_Det_Valid37;
  COM_DT_FR_RDR_Det_Valid38 FR_RDR_Det_Valid38;
  COM_DT_FR_RDR_Det_Valid39 FR_RDR_Det_Valid39;
  COM_DT_FR_RDR_Det_Valid40 FR_RDR_Det_Valid40;
} COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt11Val FR_RDR_Det_AlvCnt11Val;
  COM_DT_FR_RDR_Det_AmbigSpeed41 FR_RDR_Det_AmbigSpeed41;
  COM_DT_FR_RDR_Det_AmbigSpeed42 FR_RDR_Det_AmbigSpeed42;
  COM_DT_FR_RDR_Det_AmbigSpeed43 FR_RDR_Det_AmbigSpeed43;
  COM_DT_FR_RDR_Det_AmbigSpeed44 FR_RDR_Det_AmbigSpeed44;
  COM_DT_FR_RDR_Det_AssignTag41 FR_RDR_Det_AssignTag41;
  COM_DT_FR_RDR_Det_AssignTag42 FR_RDR_Det_AssignTag42;
  COM_DT_FR_RDR_Det_AssignTag43 FR_RDR_Det_AssignTag43;
  COM_DT_FR_RDR_Det_AssignTag44 FR_RDR_Det_AssignTag44;
  COM_DT_FR_RDR_Det_Attribute41 FR_RDR_Det_Attribute41;
  COM_DT_FR_RDR_Det_Attribute42 FR_RDR_Det_Attribute42;
  COM_DT_FR_RDR_Det_Attribute43 FR_RDR_Det_Attribute43;
  COM_DT_FR_RDR_Det_Attribute44 FR_RDR_Det_Attribute44;
  COM_DT_FR_RDR_Det_ClusterID41 FR_RDR_Det_ClusterID41;
  COM_DT_FR_RDR_Det_ClusterID42 FR_RDR_Det_ClusterID42;
  COM_DT_FR_RDR_Det_ClusterID43 FR_RDR_Det_ClusterID43;
  COM_DT_FR_RDR_Det_ClusterID44 FR_RDR_Det_ClusterID44;
  COM_DT_FR_RDR_Det_CRC11Val FR_RDR_Det_CRC11Val;
  COM_DT_FR_RDR_Det_Height41 FR_RDR_Det_Height41;
  COM_DT_FR_RDR_Det_Height42 FR_RDR_Det_Height42;
  COM_DT_FR_RDR_Det_Height43 FR_RDR_Det_Height43;
  COM_DT_FR_RDR_Det_Height44 FR_RDR_Det_Height44;
  COM_DT_FR_RDR_Det_Lat41 FR_RDR_Det_Lat41;
  COM_DT_FR_RDR_Det_Lat42 FR_RDR_Det_Lat42;
  COM_DT_FR_RDR_Det_Lat43 FR_RDR_Det_Lat43;
  COM_DT_FR_RDR_Det_Lat44 FR_RDR_Det_Lat44;
  COM_DT_FR_RDR_Det_Long41 FR_RDR_Det_Long41;
  COM_DT_FR_RDR_Det_Long42 FR_RDR_Det_Long42;
  COM_DT_FR_RDR_Det_Long43 FR_RDR_Det_Long43;
  COM_DT_FR_RDR_Det_Long44 FR_RDR_Det_Long44;
  COM_DT_FR_RDR_Det_Mov41 FR_RDR_Det_Mov41;
  COM_DT_FR_RDR_Det_Mov42 FR_RDR_Det_Mov42;
  COM_DT_FR_RDR_Det_Mov43 FR_RDR_Det_Mov43;
  COM_DT_FR_RDR_Det_Mov44 FR_RDR_Det_Mov44;
  COM_DT_FR_RDR_Det_SNR41 FR_RDR_Det_SNR41;
  COM_DT_FR_RDR_Det_SNR42 FR_RDR_Det_SNR42;
  COM_DT_FR_RDR_Det_SNR43 FR_RDR_Det_SNR43;
  COM_DT_FR_RDR_Det_SNR44 FR_RDR_Det_SNR44;
  COM_DT_FR_RDR_Det_Speed41 FR_RDR_Det_Speed41;
  COM_DT_FR_RDR_Det_Speed42 FR_RDR_Det_Speed42;
  COM_DT_FR_RDR_Det_Speed43 FR_RDR_Det_Speed43;
  COM_DT_FR_RDR_Det_Speed44 FR_RDR_Det_Speed44;
  COM_DT_FR_RDR_Det_TrustA41 FR_RDR_Det_TrustA41;
  COM_DT_FR_RDR_Det_TrustA42 FR_RDR_Det_TrustA42;
  COM_DT_FR_RDR_Det_TrustA43 FR_RDR_Det_TrustA43;
  COM_DT_FR_RDR_Det_TrustA44 FR_RDR_Det_TrustA44;
  COM_DT_FR_RDR_Det_TrustV41 FR_RDR_Det_TrustV41;
  COM_DT_FR_RDR_Det_TrustV42 FR_RDR_Det_TrustV42;
  COM_DT_FR_RDR_Det_TrustV43 FR_RDR_Det_TrustV43;
  COM_DT_FR_RDR_Det_TrustV44 FR_RDR_Det_TrustV44;
  COM_DT_FR_RDR_Det_Valid41 FR_RDR_Det_Valid41;
  COM_DT_FR_RDR_Det_Valid42 FR_RDR_Det_Valid42;
  COM_DT_FR_RDR_Det_Valid43 FR_RDR_Det_Valid43;
  COM_DT_FR_RDR_Det_Valid44 FR_RDR_Det_Valid44;
} COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt12Val FR_RDR_Det_AlvCnt12Val;
  COM_DT_FR_RDR_Det_AmbigSpeed45 FR_RDR_Det_AmbigSpeed45;
  COM_DT_FR_RDR_Det_AmbigSpeed46 FR_RDR_Det_AmbigSpeed46;
  COM_DT_FR_RDR_Det_AmbigSpeed47 FR_RDR_Det_AmbigSpeed47;
  COM_DT_FR_RDR_Det_AmbigSpeed48 FR_RDR_Det_AmbigSpeed48;
  COM_DT_FR_RDR_Det_AssignTag45 FR_RDR_Det_AssignTag45;
  COM_DT_FR_RDR_Det_AssignTag46 FR_RDR_Det_AssignTag46;
  COM_DT_FR_RDR_Det_AssignTag47 FR_RDR_Det_AssignTag47;
  COM_DT_FR_RDR_Det_AssignTag48 FR_RDR_Det_AssignTag48;
  COM_DT_FR_RDR_Det_Attribute45 FR_RDR_Det_Attribute45;
  COM_DT_FR_RDR_Det_Attribute46 FR_RDR_Det_Attribute46;
  COM_DT_FR_RDR_Det_Attribute47 FR_RDR_Det_Attribute47;
  COM_DT_FR_RDR_Det_Attribute48 FR_RDR_Det_Attribute48;
  COM_DT_FR_RDR_Det_ClusterID45 FR_RDR_Det_ClusterID45;
  COM_DT_FR_RDR_Det_ClusterID46 FR_RDR_Det_ClusterID46;
  COM_DT_FR_RDR_Det_ClusterID47 FR_RDR_Det_ClusterID47;
  COM_DT_FR_RDR_Det_ClusterID48 FR_RDR_Det_ClusterID48;
  COM_DT_FR_RDR_Det_CRC12Val FR_RDR_Det_CRC12Val;
  COM_DT_FR_RDR_Det_Height45 FR_RDR_Det_Height45;
  COM_DT_FR_RDR_Det_Height46 FR_RDR_Det_Height46;
  COM_DT_FR_RDR_Det_Height47 FR_RDR_Det_Height47;
  COM_DT_FR_RDR_Det_Height48 FR_RDR_Det_Height48;
  COM_DT_FR_RDR_Det_Lat45 FR_RDR_Det_Lat45;
  COM_DT_FR_RDR_Det_Lat46 FR_RDR_Det_Lat46;
  COM_DT_FR_RDR_Det_Lat47 FR_RDR_Det_Lat47;
  COM_DT_FR_RDR_Det_Lat48 FR_RDR_Det_Lat48;
  COM_DT_FR_RDR_Det_Long45 FR_RDR_Det_Long45;
  COM_DT_FR_RDR_Det_Long46 FR_RDR_Det_Long46;
  COM_DT_FR_RDR_Det_Long47 FR_RDR_Det_Long47;
  COM_DT_FR_RDR_Det_Long48 FR_RDR_Det_Long48;
  COM_DT_FR_RDR_Det_Mov45 FR_RDR_Det_Mov45;
  COM_DT_FR_RDR_Det_Mov46 FR_RDR_Det_Mov46;
  COM_DT_FR_RDR_Det_Mov47 FR_RDR_Det_Mov47;
  COM_DT_FR_RDR_Det_Mov48 FR_RDR_Det_Mov48;
  COM_DT_FR_RDR_Det_SNR45 FR_RDR_Det_SNR45;
  COM_DT_FR_RDR_Det_SNR46 FR_RDR_Det_SNR46;
  COM_DT_FR_RDR_Det_SNR47 FR_RDR_Det_SNR47;
  COM_DT_FR_RDR_Det_SNR48 FR_RDR_Det_SNR48;
  COM_DT_FR_RDR_Det_Speed45 FR_RDR_Det_Speed45;
  COM_DT_FR_RDR_Det_Speed46 FR_RDR_Det_Speed46;
  COM_DT_FR_RDR_Det_Speed47 FR_RDR_Det_Speed47;
  COM_DT_FR_RDR_Det_Speed48 FR_RDR_Det_Speed48;
  COM_DT_FR_RDR_Det_TrustA45 FR_RDR_Det_TrustA45;
  COM_DT_FR_RDR_Det_TrustA46 FR_RDR_Det_TrustA46;
  COM_DT_FR_RDR_Det_TrustA47 FR_RDR_Det_TrustA47;
  COM_DT_FR_RDR_Det_TrustA48 FR_RDR_Det_TrustA48;
  COM_DT_FR_RDR_Det_TrustV45 FR_RDR_Det_TrustV45;
  COM_DT_FR_RDR_Det_TrustV46 FR_RDR_Det_TrustV46;
  COM_DT_FR_RDR_Det_TrustV47 FR_RDR_Det_TrustV47;
  COM_DT_FR_RDR_Det_TrustV48 FR_RDR_Det_TrustV48;
  COM_DT_FR_RDR_Det_Valid45 FR_RDR_Det_Valid45;
  COM_DT_FR_RDR_Det_Valid46 FR_RDR_Det_Valid46;
  COM_DT_FR_RDR_Det_Valid47 FR_RDR_Det_Valid47;
  COM_DT_FR_RDR_Det_Valid48 FR_RDR_Det_Valid48;
} COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt13Val FR_RDR_Det_AlvCnt13Val;
  COM_DT_FR_RDR_Det_AmbigSpeed49 FR_RDR_Det_AmbigSpeed49;
  COM_DT_FR_RDR_Det_AmbigSpeed50 FR_RDR_Det_AmbigSpeed50;
  COM_DT_FR_RDR_Det_AmbigSpeed51 FR_RDR_Det_AmbigSpeed51;
  COM_DT_FR_RDR_Det_AmbigSpeed52 FR_RDR_Det_AmbigSpeed52;
  COM_DT_FR_RDR_Det_AssignTag49 FR_RDR_Det_AssignTag49;
  COM_DT_FR_RDR_Det_AssignTag50 FR_RDR_Det_AssignTag50;
  COM_DT_FR_RDR_Det_AssignTag51 FR_RDR_Det_AssignTag51;
  COM_DT_FR_RDR_Det_AssignTag52 FR_RDR_Det_AssignTag52;
  COM_DT_FR_RDR_Det_Attribute49 FR_RDR_Det_Attribute49;
  COM_DT_FR_RDR_Det_Attribute50 FR_RDR_Det_Attribute50;
  COM_DT_FR_RDR_Det_Attribute51 FR_RDR_Det_Attribute51;
  COM_DT_FR_RDR_Det_Attribute52 FR_RDR_Det_Attribute52;
  COM_DT_FR_RDR_Det_ClusterID49 FR_RDR_Det_ClusterID49;
  COM_DT_FR_RDR_Det_ClusterID50 FR_RDR_Det_ClusterID50;
  COM_DT_FR_RDR_Det_ClusterID51 FR_RDR_Det_ClusterID51;
  COM_DT_FR_RDR_Det_ClusterID52 FR_RDR_Det_ClusterID52;
  COM_DT_FR_RDR_Det_CRC13Val FR_RDR_Det_CRC13Val;
  COM_DT_FR_RDR_Det_Height49 FR_RDR_Det_Height49;
  COM_DT_FR_RDR_Det_Height50 FR_RDR_Det_Height50;
  COM_DT_FR_RDR_Det_Height51 FR_RDR_Det_Height51;
  COM_DT_FR_RDR_Det_Height52 FR_RDR_Det_Height52;
  COM_DT_FR_RDR_Det_Lat49 FR_RDR_Det_Lat49;
  COM_DT_FR_RDR_Det_Lat50 FR_RDR_Det_Lat50;
  COM_DT_FR_RDR_Det_Lat51 FR_RDR_Det_Lat51;
  COM_DT_FR_RDR_Det_Lat52 FR_RDR_Det_Lat52;
  COM_DT_FR_RDR_Det_Long49 FR_RDR_Det_Long49;
  COM_DT_FR_RDR_Det_Long50 FR_RDR_Det_Long50;
  COM_DT_FR_RDR_Det_Long51 FR_RDR_Det_Long51;
  COM_DT_FR_RDR_Det_Long52 FR_RDR_Det_Long52;
  COM_DT_FR_RDR_Det_Mov49 FR_RDR_Det_Mov49;
  COM_DT_FR_RDR_Det_Mov50 FR_RDR_Det_Mov50;
  COM_DT_FR_RDR_Det_Mov51 FR_RDR_Det_Mov51;
  COM_DT_FR_RDR_Det_Mov52 FR_RDR_Det_Mov52;
  COM_DT_FR_RDR_Det_SNR49 FR_RDR_Det_SNR49;
  COM_DT_FR_RDR_Det_SNR50 FR_RDR_Det_SNR50;
  COM_DT_FR_RDR_Det_SNR51 FR_RDR_Det_SNR51;
  COM_DT_FR_RDR_Det_SNR52 FR_RDR_Det_SNR52;
  COM_DT_FR_RDR_Det_Speed49 FR_RDR_Det_Speed49;
  COM_DT_FR_RDR_Det_Speed50 FR_RDR_Det_Speed50;
  COM_DT_FR_RDR_Det_Speed51 FR_RDR_Det_Speed51;
  COM_DT_FR_RDR_Det_Speed52 FR_RDR_Det_Speed52;
  COM_DT_FR_RDR_Det_TrustA49 FR_RDR_Det_TrustA49;
  COM_DT_FR_RDR_Det_TrustA50 FR_RDR_Det_TrustA50;
  COM_DT_FR_RDR_Det_TrustA51 FR_RDR_Det_TrustA51;
  COM_DT_FR_RDR_Det_TrustA52 FR_RDR_Det_TrustA52;
  COM_DT_FR_RDR_Det_TrustV49 FR_RDR_Det_TrustV49;
  COM_DT_FR_RDR_Det_TrustV50 FR_RDR_Det_TrustV50;
  COM_DT_FR_RDR_Det_TrustV51 FR_RDR_Det_TrustV51;
  COM_DT_FR_RDR_Det_TrustV52 FR_RDR_Det_TrustV52;
  COM_DT_FR_RDR_Det_Valid49 FR_RDR_Det_Valid49;
  COM_DT_FR_RDR_Det_Valid50 FR_RDR_Det_Valid50;
  COM_DT_FR_RDR_Det_Valid51 FR_RDR_Det_Valid51;
  COM_DT_FR_RDR_Det_Valid52 FR_RDR_Det_Valid52;
} COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt14Val FR_RDR_Det_AlvCnt14Val;
  COM_DT_FR_RDR_Det_AmbigSpeed53 FR_RDR_Det_AmbigSpeed53;
  COM_DT_FR_RDR_Det_AmbigSpeed54 FR_RDR_Det_AmbigSpeed54;
  COM_DT_FR_RDR_Det_AmbigSpeed55 FR_RDR_Det_AmbigSpeed55;
  COM_DT_FR_RDR_Det_AmbigSpeed56 FR_RDR_Det_AmbigSpeed56;
  COM_DT_FR_RDR_Det_AssignTag53 FR_RDR_Det_AssignTag53;
  COM_DT_FR_RDR_Det_AssignTag54 FR_RDR_Det_AssignTag54;
  COM_DT_FR_RDR_Det_AssignTag55 FR_RDR_Det_AssignTag55;
  COM_DT_FR_RDR_Det_AssignTag56 FR_RDR_Det_AssignTag56;
  COM_DT_FR_RDR_Det_Attribute53 FR_RDR_Det_Attribute53;
  COM_DT_FR_RDR_Det_Attribute54 FR_RDR_Det_Attribute54;
  COM_DT_FR_RDR_Det_Attribute55 FR_RDR_Det_Attribute55;
  COM_DT_FR_RDR_Det_Attribute56 FR_RDR_Det_Attribute56;
  COM_DT_FR_RDR_Det_ClusterID53 FR_RDR_Det_ClusterID53;
  COM_DT_FR_RDR_Det_ClusterID54 FR_RDR_Det_ClusterID54;
  COM_DT_FR_RDR_Det_ClusterID55 FR_RDR_Det_ClusterID55;
  COM_DT_FR_RDR_Det_ClusterID56 FR_RDR_Det_ClusterID56;
  COM_DT_FR_RDR_Det_CRC14Val FR_RDR_Det_CRC14Val;
  COM_DT_FR_RDR_Det_Height53 FR_RDR_Det_Height53;
  COM_DT_FR_RDR_Det_Height54 FR_RDR_Det_Height54;
  COM_DT_FR_RDR_Det_Height55 FR_RDR_Det_Height55;
  COM_DT_FR_RDR_Det_Height56 FR_RDR_Det_Height56;
  COM_DT_FR_RDR_Det_Lat53 FR_RDR_Det_Lat53;
  COM_DT_FR_RDR_Det_Lat54 FR_RDR_Det_Lat54;
  COM_DT_FR_RDR_Det_Lat55 FR_RDR_Det_Lat55;
  COM_DT_FR_RDR_Det_Lat56 FR_RDR_Det_Lat56;
  COM_DT_FR_RDR_Det_Long53 FR_RDR_Det_Long53;
  COM_DT_FR_RDR_Det_Long54 FR_RDR_Det_Long54;
  COM_DT_FR_RDR_Det_Long55 FR_RDR_Det_Long55;
  COM_DT_FR_RDR_Det_Long56 FR_RDR_Det_Long56;
  COM_DT_FR_RDR_Det_Mov53 FR_RDR_Det_Mov53;
  COM_DT_FR_RDR_Det_Mov54 FR_RDR_Det_Mov54;
  COM_DT_FR_RDR_Det_Mov55 FR_RDR_Det_Mov55;
  COM_DT_FR_RDR_Det_Mov56 FR_RDR_Det_Mov56;
  COM_DT_FR_RDR_Det_SNR53 FR_RDR_Det_SNR53;
  COM_DT_FR_RDR_Det_SNR54 FR_RDR_Det_SNR54;
  COM_DT_FR_RDR_Det_SNR55 FR_RDR_Det_SNR55;
  COM_DT_FR_RDR_Det_SNR56 FR_RDR_Det_SNR56;
  COM_DT_FR_RDR_Det_Speed53 FR_RDR_Det_Speed53;
  COM_DT_FR_RDR_Det_Speed54 FR_RDR_Det_Speed54;
  COM_DT_FR_RDR_Det_Speed55 FR_RDR_Det_Speed55;
  COM_DT_FR_RDR_Det_Speed56 FR_RDR_Det_Speed56;
  COM_DT_FR_RDR_Det_TrustA53 FR_RDR_Det_TrustA53;
  COM_DT_FR_RDR_Det_TrustA54 FR_RDR_Det_TrustA54;
  COM_DT_FR_RDR_Det_TrustA55 FR_RDR_Det_TrustA55;
  COM_DT_FR_RDR_Det_TrustA56 FR_RDR_Det_TrustA56;
  COM_DT_FR_RDR_Det_TrustV53 FR_RDR_Det_TrustV53;
  COM_DT_FR_RDR_Det_TrustV54 FR_RDR_Det_TrustV54;
  COM_DT_FR_RDR_Det_TrustV55 FR_RDR_Det_TrustV55;
  COM_DT_FR_RDR_Det_TrustV56 FR_RDR_Det_TrustV56;
  COM_DT_FR_RDR_Det_Valid53 FR_RDR_Det_Valid53;
  COM_DT_FR_RDR_Det_Valid54 FR_RDR_Det_Valid54;
  COM_DT_FR_RDR_Det_Valid55 FR_RDR_Det_Valid55;
  COM_DT_FR_RDR_Det_Valid56 FR_RDR_Det_Valid56;
} COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt15Val FR_RDR_Det_AlvCnt15Val;
  COM_DT_FR_RDR_Det_AmbigSpeed57 FR_RDR_Det_AmbigSpeed57;
  COM_DT_FR_RDR_Det_AmbigSpeed58 FR_RDR_Det_AmbigSpeed58;
  COM_DT_FR_RDR_Det_AmbigSpeed59 FR_RDR_Det_AmbigSpeed59;
  COM_DT_FR_RDR_Det_AmbigSpeed60 FR_RDR_Det_AmbigSpeed60;
  COM_DT_FR_RDR_Det_AssignTag57 FR_RDR_Det_AssignTag57;
  COM_DT_FR_RDR_Det_AssignTag58 FR_RDR_Det_AssignTag58;
  COM_DT_FR_RDR_Det_AssignTag59 FR_RDR_Det_AssignTag59;
  COM_DT_FR_RDR_Det_AssignTag60 FR_RDR_Det_AssignTag60;
  COM_DT_FR_RDR_Det_Attribute57 FR_RDR_Det_Attribute57;
  COM_DT_FR_RDR_Det_Attribute58 FR_RDR_Det_Attribute58;
  COM_DT_FR_RDR_Det_Attribute59 FR_RDR_Det_Attribute59;
  COM_DT_FR_RDR_Det_Attribute60 FR_RDR_Det_Attribute60;
  COM_DT_FR_RDR_Det_ClusterID57 FR_RDR_Det_ClusterID57;
  COM_DT_FR_RDR_Det_ClusterID58 FR_RDR_Det_ClusterID58;
  COM_DT_FR_RDR_Det_ClusterID59 FR_RDR_Det_ClusterID59;
  COM_DT_FR_RDR_Det_ClusterID60 FR_RDR_Det_ClusterID60;
  COM_DT_FR_RDR_Det_CRC15Val FR_RDR_Det_CRC15Val;
  COM_DT_FR_RDR_Det_Height57 FR_RDR_Det_Height57;
  COM_DT_FR_RDR_Det_Height58 FR_RDR_Det_Height58;
  COM_DT_FR_RDR_Det_Height59 FR_RDR_Det_Height59;
  COM_DT_FR_RDR_Det_Height60 FR_RDR_Det_Height60;
  COM_DT_FR_RDR_Det_Lat57 FR_RDR_Det_Lat57;
  COM_DT_FR_RDR_Det_Lat58 FR_RDR_Det_Lat58;
  COM_DT_FR_RDR_Det_Lat59 FR_RDR_Det_Lat59;
  COM_DT_FR_RDR_Det_Lat60 FR_RDR_Det_Lat60;
  COM_DT_FR_RDR_Det_Long57 FR_RDR_Det_Long57;
  COM_DT_FR_RDR_Det_Long58 FR_RDR_Det_Long58;
  COM_DT_FR_RDR_Det_Long59 FR_RDR_Det_Long59;
  COM_DT_FR_RDR_Det_Long60 FR_RDR_Det_Long60;
  COM_DT_FR_RDR_Det_Mov57 FR_RDR_Det_Mov57;
  COM_DT_FR_RDR_Det_Mov58 FR_RDR_Det_Mov58;
  COM_DT_FR_RDR_Det_Mov59 FR_RDR_Det_Mov59;
  COM_DT_FR_RDR_Det_Mov60 FR_RDR_Det_Mov60;
  COM_DT_FR_RDR_Det_SNR57 FR_RDR_Det_SNR57;
  COM_DT_FR_RDR_Det_SNR58 FR_RDR_Det_SNR58;
  COM_DT_FR_RDR_Det_SNR59 FR_RDR_Det_SNR59;
  COM_DT_FR_RDR_Det_SNR60 FR_RDR_Det_SNR60;
  COM_DT_FR_RDR_Det_Speed57 FR_RDR_Det_Speed57;
  COM_DT_FR_RDR_Det_Speed58 FR_RDR_Det_Speed58;
  COM_DT_FR_RDR_Det_Speed59 FR_RDR_Det_Speed59;
  COM_DT_FR_RDR_Det_Speed60 FR_RDR_Det_Speed60;
  COM_DT_FR_RDR_Det_TrustA57 FR_RDR_Det_TrustA57;
  COM_DT_FR_RDR_Det_TrustA58 FR_RDR_Det_TrustA58;
  COM_DT_FR_RDR_Det_TrustA59 FR_RDR_Det_TrustA59;
  COM_DT_FR_RDR_Det_TrustA60 FR_RDR_Det_TrustA60;
  COM_DT_FR_RDR_Det_TrustV57 FR_RDR_Det_TrustV57;
  COM_DT_FR_RDR_Det_TrustV58 FR_RDR_Det_TrustV58;
  COM_DT_FR_RDR_Det_TrustV59 FR_RDR_Det_TrustV59;
  COM_DT_FR_RDR_Det_TrustV60 FR_RDR_Det_TrustV60;
  COM_DT_FR_RDR_Det_Valid57 FR_RDR_Det_Valid57;
  COM_DT_FR_RDR_Det_Valid58 FR_RDR_Det_Valid58;
  COM_DT_FR_RDR_Det_Valid59 FR_RDR_Det_Valid59;
  COM_DT_FR_RDR_Det_Valid60 FR_RDR_Det_Valid60;
} COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Det_AlvCnt16Val FR_RDR_Det_AlvCnt16Val;
  COM_DT_FR_RDR_Det_AmbigSpeed61 FR_RDR_Det_AmbigSpeed61;
  COM_DT_FR_RDR_Det_AmbigSpeed62 FR_RDR_Det_AmbigSpeed62;
  COM_DT_FR_RDR_Det_AmbigSpeed63 FR_RDR_Det_AmbigSpeed63;
  COM_DT_FR_RDR_Det_AmbigSpeed64 FR_RDR_Det_AmbigSpeed64;
  COM_DT_FR_RDR_Det_AssignTag61 FR_RDR_Det_AssignTag61;
  COM_DT_FR_RDR_Det_AssignTag62 FR_RDR_Det_AssignTag62;
  COM_DT_FR_RDR_Det_AssignTag63 FR_RDR_Det_AssignTag63;
  COM_DT_FR_RDR_Det_AssignTag64 FR_RDR_Det_AssignTag64;
  COM_DT_FR_RDR_Det_Attribute61 FR_RDR_Det_Attribute61;
  COM_DT_FR_RDR_Det_Attribute62 FR_RDR_Det_Attribute62;
  COM_DT_FR_RDR_Det_Attribute63 FR_RDR_Det_Attribute63;
  COM_DT_FR_RDR_Det_Attribute64 FR_RDR_Det_Attribute64;
  COM_DT_FR_RDR_Det_ClusterID61 FR_RDR_Det_ClusterID61;
  COM_DT_FR_RDR_Det_ClusterID62 FR_RDR_Det_ClusterID62;
  COM_DT_FR_RDR_Det_ClusterID63 FR_RDR_Det_ClusterID63;
  COM_DT_FR_RDR_Det_ClusterID64 FR_RDR_Det_ClusterID64;
  COM_DT_FR_RDR_Det_CRC16Val FR_RDR_Det_CRC16Val;
  COM_DT_FR_RDR_Det_Height61 FR_RDR_Det_Height61;
  COM_DT_FR_RDR_Det_Height62 FR_RDR_Det_Height62;
  COM_DT_FR_RDR_Det_Height63 FR_RDR_Det_Height63;
  COM_DT_FR_RDR_Det_Height64 FR_RDR_Det_Height64;
  COM_DT_FR_RDR_Det_Lat61 FR_RDR_Det_Lat61;
  COM_DT_FR_RDR_Det_Lat62 FR_RDR_Det_Lat62;
  COM_DT_FR_RDR_Det_Lat63 FR_RDR_Det_Lat63;
  COM_DT_FR_RDR_Det_Lat64 FR_RDR_Det_Lat64;
  COM_DT_FR_RDR_Det_Long61 FR_RDR_Det_Long61;
  COM_DT_FR_RDR_Det_Long62 FR_RDR_Det_Long62;
  COM_DT_FR_RDR_Det_Long63 FR_RDR_Det_Long63;
  COM_DT_FR_RDR_Det_Long64 FR_RDR_Det_Long64;
  COM_DT_FR_RDR_Det_Mov61 FR_RDR_Det_Mov61;
  COM_DT_FR_RDR_Det_Mov62 FR_RDR_Det_Mov62;
  COM_DT_FR_RDR_Det_Mov63 FR_RDR_Det_Mov63;
  COM_DT_FR_RDR_Det_Mov64 FR_RDR_Det_Mov64;
  COM_DT_FR_RDR_Det_SNR61 FR_RDR_Det_SNR61;
  COM_DT_FR_RDR_Det_SNR62 FR_RDR_Det_SNR62;
  COM_DT_FR_RDR_Det_SNR63 FR_RDR_Det_SNR63;
  COM_DT_FR_RDR_Det_SNR64 FR_RDR_Det_SNR64;
  COM_DT_FR_RDR_Det_Speed61 FR_RDR_Det_Speed61;
  COM_DT_FR_RDR_Det_Speed62 FR_RDR_Det_Speed62;
  COM_DT_FR_RDR_Det_Speed63 FR_RDR_Det_Speed63;
  COM_DT_FR_RDR_Det_Speed64 FR_RDR_Det_Speed64;
  COM_DT_FR_RDR_Det_TrustA61 FR_RDR_Det_TrustA61;
  COM_DT_FR_RDR_Det_TrustA62 FR_RDR_Det_TrustA62;
  COM_DT_FR_RDR_Det_TrustA63 FR_RDR_Det_TrustA63;
  COM_DT_FR_RDR_Det_TrustA64 FR_RDR_Det_TrustA64;
  COM_DT_FR_RDR_Det_TrustV61 FR_RDR_Det_TrustV61;
  COM_DT_FR_RDR_Det_TrustV62 FR_RDR_Det_TrustV62;
  COM_DT_FR_RDR_Det_TrustV63 FR_RDR_Det_TrustV63;
  COM_DT_FR_RDR_Det_TrustV64 FR_RDR_Det_TrustV64;
  COM_DT_FR_RDR_Det_Valid61 FR_RDR_Det_Valid61;
  COM_DT_FR_RDR_Det_Valid62 FR_RDR_Det_Valid62;
  COM_DT_FR_RDR_Det_Valid63 FR_RDR_Det_Valid63;
  COM_DT_FR_RDR_Det_Valid64 FR_RDR_Det_Valid64;
} COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge01Val FR_RDR_Obj_AlvAge01Val;
  COM_DT_FR_RDR_Obj_AlvAge02Val FR_RDR_Obj_AlvAge02Val;
  COM_DT_FR_RDR_Obj_AlvCnt01Val FR_RDR_Obj_AlvCnt01Val;
  COM_DT_FR_RDR_Obj_CoastAge01Val FR_RDR_Obj_CoastAge01Val;
  COM_DT_FR_RDR_Obj_CoastAge02Val FR_RDR_Obj_CoastAge02Val;
  COM_DT_FR_RDR_Obj_CRC01Val FR_RDR_Obj_CRC01Val;
  COM_DT_FR_RDR_Obj_MedRangeMod01Val FR_RDR_Obj_MedRangeMod01Val;
  COM_DT_FR_RDR_Obj_MedRangeMod02Val FR_RDR_Obj_MedRangeMod02Val;
  COM_DT_FR_RDR_Obj_MvngFlag01Sta FR_RDR_Obj_MvngFlag01Sta;
  COM_DT_FR_RDR_Obj_MvngFlag02Sta FR_RDR_Obj_MvngFlag02Sta;
  COM_DT_FR_RDR_Obj_QualLvl01Sta FR_RDR_Obj_QualLvl01Sta;
  COM_DT_FR_RDR_Obj_QualLvl02Sta FR_RDR_Obj_QualLvl02Sta;
  COM_DT_FR_RDR_Obj_RefObjID01Val FR_RDR_Obj_RefObjID01Val;
  COM_DT_FR_RDR_Obj_RefObjID02Val FR_RDR_Obj_RefObjID02Val;
  COM_DT_FR_RDR_Obj_RelAccelX01Val FR_RDR_Obj_RelAccelX01Val;
  COM_DT_FR_RDR_Obj_RelAccelX02Val FR_RDR_Obj_RelAccelX02Val;
  COM_DT_FR_RDR_Obj_RelPosX01Val FR_RDR_Obj_RelPosX01Val;
  COM_DT_FR_RDR_Obj_RelPosX02Val FR_RDR_Obj_RelPosX02Val;
  COM_DT_FR_RDR_Obj_RelPosY01Val FR_RDR_Obj_RelPosY01Val;
  COM_DT_FR_RDR_Obj_RelPosY02Val FR_RDR_Obj_RelPosY02Val;
  COM_DT_FR_RDR_Obj_RelVelX01Val FR_RDR_Obj_RelVelX01Val;
  COM_DT_FR_RDR_Obj_RelVelX02Val FR_RDR_Obj_RelVelX02Val;
  COM_DT_FR_RDR_Obj_RelVelY01Val FR_RDR_Obj_RelVelY01Val;
  COM_DT_FR_RDR_Obj_RelVelY02Val FR_RDR_Obj_RelVelY02Val;
  COM_DT_FR_RDR_Obj_TrkSta01Sta FR_RDR_Obj_TrkSta01Sta;
  COM_DT_FR_RDR_Obj_TrkSta02Sta FR_RDR_Obj_TrkSta02Sta;
} COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge03Val FR_RDR_Obj_AlvAge03Val;
  COM_DT_FR_RDR_Obj_AlvAge04Val FR_RDR_Obj_AlvAge04Val;
  COM_DT_FR_RDR_Obj_AlvCnt02Val FR_RDR_Obj_AlvCnt02Val;
  COM_DT_FR_RDR_Obj_CoastAge03Val FR_RDR_Obj_CoastAge03Val;
  COM_DT_FR_RDR_Obj_CoastAge04Val FR_RDR_Obj_CoastAge04Val;
  COM_DT_FR_RDR_Obj_CRC02Val FR_RDR_Obj_CRC02Val;
  COM_DT_FR_RDR_Obj_MedRangeMod03Val FR_RDR_Obj_MedRangeMod03Val;
  COM_DT_FR_RDR_Obj_MedRangeMod04Val FR_RDR_Obj_MedRangeMod04Val;
  COM_DT_FR_RDR_Obj_MvngFlag03Sta FR_RDR_Obj_MvngFlag03Sta;
  COM_DT_FR_RDR_Obj_MvngFlag04Sta FR_RDR_Obj_MvngFlag04Sta;
  COM_DT_FR_RDR_Obj_QualLvl03Sta FR_RDR_Obj_QualLvl03Sta;
  COM_DT_FR_RDR_Obj_QualLvl04Sta FR_RDR_Obj_QualLvl04Sta;
  COM_DT_FR_RDR_Obj_RefObjID03Val FR_RDR_Obj_RefObjID03Val;
  COM_DT_FR_RDR_Obj_RefObjID04Val FR_RDR_Obj_RefObjID04Val;
  COM_DT_FR_RDR_Obj_RelAccelX03Val FR_RDR_Obj_RelAccelX03Val;
  COM_DT_FR_RDR_Obj_RelAccelX04Val FR_RDR_Obj_RelAccelX04Val;
  COM_DT_FR_RDR_Obj_RelPosX03Val FR_RDR_Obj_RelPosX03Val;
  COM_DT_FR_RDR_Obj_RelPosX04Val FR_RDR_Obj_RelPosX04Val;
  COM_DT_FR_RDR_Obj_RelPosY03Val FR_RDR_Obj_RelPosY03Val;
  COM_DT_FR_RDR_Obj_RelPosY04Val FR_RDR_Obj_RelPosY04Val;
  COM_DT_FR_RDR_Obj_RelVelX03Val FR_RDR_Obj_RelVelX03Val;
  COM_DT_FR_RDR_Obj_RelVelX04Val FR_RDR_Obj_RelVelX04Val;
  COM_DT_FR_RDR_Obj_RelVelY03Val FR_RDR_Obj_RelVelY03Val;
  COM_DT_FR_RDR_Obj_RelVelY04Val FR_RDR_Obj_RelVelY04Val;
  COM_DT_FR_RDR_Obj_TrkSta03Sta FR_RDR_Obj_TrkSta03Sta;
  COM_DT_FR_RDR_Obj_TrkSta04Sta FR_RDR_Obj_TrkSta04Sta;
} COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge05Val FR_RDR_Obj_AlvAge05Val;
  COM_DT_FR_RDR_Obj_AlvAge06Val FR_RDR_Obj_AlvAge06Val;
  COM_DT_FR_RDR_Obj_AlvCnt03Val FR_RDR_Obj_AlvCnt03Val;
  COM_DT_FR_RDR_Obj_CoastAge05Val FR_RDR_Obj_CoastAge05Val;
  COM_DT_FR_RDR_Obj_CoastAge06Val FR_RDR_Obj_CoastAge06Val;
  COM_DT_FR_RDR_Obj_CRC03Val FR_RDR_Obj_CRC03Val;
  COM_DT_FR_RDR_Obj_MedRangeMod05Val FR_RDR_Obj_MedRangeMod05Val;
  COM_DT_FR_RDR_Obj_MedRangeMod06Val FR_RDR_Obj_MedRangeMod06Val;
  COM_DT_FR_RDR_Obj_MvngFlag05Sta FR_RDR_Obj_MvngFlag05Sta;
  COM_DT_FR_RDR_Obj_MvngFlag06Sta FR_RDR_Obj_MvngFlag06Sta;
  COM_DT_FR_RDR_Obj_QualLvl05Sta FR_RDR_Obj_QualLvl05Sta;
  COM_DT_FR_RDR_Obj_QualLvl06Sta FR_RDR_Obj_QualLvl06Sta;
  COM_DT_FR_RDR_Obj_RefObjID05Val FR_RDR_Obj_RefObjID05Val;
  COM_DT_FR_RDR_Obj_RefObjID06Val FR_RDR_Obj_RefObjID06Val;
  COM_DT_FR_RDR_Obj_RelAccelX05Val FR_RDR_Obj_RelAccelX05Val;
  COM_DT_FR_RDR_Obj_RelAccelX06Val FR_RDR_Obj_RelAccelX06Val;
  COM_DT_FR_RDR_Obj_RelPosX05Val FR_RDR_Obj_RelPosX05Val;
  COM_DT_FR_RDR_Obj_RelPosX06Val FR_RDR_Obj_RelPosX06Val;
  COM_DT_FR_RDR_Obj_RelPosY05Val FR_RDR_Obj_RelPosY05Val;
  COM_DT_FR_RDR_Obj_RelPosY06Val FR_RDR_Obj_RelPosY06Val;
  COM_DT_FR_RDR_Obj_RelVelX05Val FR_RDR_Obj_RelVelX05Val;
  COM_DT_FR_RDR_Obj_RelVelX06Val FR_RDR_Obj_RelVelX06Val;
  COM_DT_FR_RDR_Obj_RelVelY05Val FR_RDR_Obj_RelVelY05Val;
  COM_DT_FR_RDR_Obj_RelVelY06Val FR_RDR_Obj_RelVelY06Val;
  COM_DT_FR_RDR_Obj_TrkSta05Sta FR_RDR_Obj_TrkSta05Sta;
  COM_DT_FR_RDR_Obj_TrkSta06Sta FR_RDR_Obj_TrkSta06Sta;
} COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge07Val FR_RDR_Obj_AlvAge07Val;
  COM_DT_FR_RDR_Obj_AlvAge08Val FR_RDR_Obj_AlvAge08Val;
  COM_DT_FR_RDR_Obj_AlvCnt04Val FR_RDR_Obj_AlvCnt04Val;
  COM_DT_FR_RDR_Obj_CoastAge07Val FR_RDR_Obj_CoastAge07Val;
  COM_DT_FR_RDR_Obj_CoastAge08Val FR_RDR_Obj_CoastAge08Val;
  COM_DT_FR_RDR_Obj_CRC04Val FR_RDR_Obj_CRC04Val;
  COM_DT_FR_RDR_Obj_MedRangeMod07Val FR_RDR_Obj_MedRangeMod07Val;
  COM_DT_FR_RDR_Obj_MedRangeMod08Val FR_RDR_Obj_MedRangeMod08Val;
  COM_DT_FR_RDR_Obj_MvngFlag07Sta FR_RDR_Obj_MvngFlag07Sta;
  COM_DT_FR_RDR_Obj_MvngFlag08Sta FR_RDR_Obj_MvngFlag08Sta;
  COM_DT_FR_RDR_Obj_QualLvl07Sta FR_RDR_Obj_QualLvl07Sta;
  COM_DT_FR_RDR_Obj_QualLvl08Sta FR_RDR_Obj_QualLvl08Sta;
  COM_DT_FR_RDR_Obj_RefObjID07Val FR_RDR_Obj_RefObjID07Val;
  COM_DT_FR_RDR_Obj_RefObjID08Val FR_RDR_Obj_RefObjID08Val;
  COM_DT_FR_RDR_Obj_RelAccelX07Val FR_RDR_Obj_RelAccelX07Val;
  COM_DT_FR_RDR_Obj_RelAccelX08Val FR_RDR_Obj_RelAccelX08Val;
  COM_DT_FR_RDR_Obj_RelPosX07Val FR_RDR_Obj_RelPosX07Val;
  COM_DT_FR_RDR_Obj_RelPosX08Val FR_RDR_Obj_RelPosX08Val;
  COM_DT_FR_RDR_Obj_RelPosY07Val FR_RDR_Obj_RelPosY07Val;
  COM_DT_FR_RDR_Obj_RelPosY08Val FR_RDR_Obj_RelPosY08Val;
  COM_DT_FR_RDR_Obj_RelVelX07Val FR_RDR_Obj_RelVelX07Val;
  COM_DT_FR_RDR_Obj_RelVelX08Val FR_RDR_Obj_RelVelX08Val;
  COM_DT_FR_RDR_Obj_RelVelY07Val FR_RDR_Obj_RelVelY07Val;
  COM_DT_FR_RDR_Obj_RelVelY08Val FR_RDR_Obj_RelVelY08Val;
  COM_DT_FR_RDR_Obj_TrkSta07Sta FR_RDR_Obj_TrkSta07Sta;
  COM_DT_FR_RDR_Obj_TrkSta08Sta FR_RDR_Obj_TrkSta08Sta;
} COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge09Val FR_RDR_Obj_AlvAge09Val;
  COM_DT_FR_RDR_Obj_AlvAge10Val FR_RDR_Obj_AlvAge10Val;
  COM_DT_FR_RDR_Obj_AlvCnt05Val FR_RDR_Obj_AlvCnt05Val;
  COM_DT_FR_RDR_Obj_CoastAge09Val FR_RDR_Obj_CoastAge09Val;
  COM_DT_FR_RDR_Obj_CoastAge10Val FR_RDR_Obj_CoastAge10Val;
  COM_DT_FR_RDR_Obj_CRC05Val FR_RDR_Obj_CRC05Val;
  COM_DT_FR_RDR_Obj_MedRangeMod09Val FR_RDR_Obj_MedRangeMod09Val;
  COM_DT_FR_RDR_Obj_MedRangeMod10Val FR_RDR_Obj_MedRangeMod10Val;
  COM_DT_FR_RDR_Obj_MvngFlag09Sta FR_RDR_Obj_MvngFlag09Sta;
  COM_DT_FR_RDR_Obj_MvngFlag10Sta FR_RDR_Obj_MvngFlag10Sta;
  COM_DT_FR_RDR_Obj_QualLvl09Sta FR_RDR_Obj_QualLvl09Sta;
  COM_DT_FR_RDR_Obj_QualLvl10Sta FR_RDR_Obj_QualLvl10Sta;
  COM_DT_FR_RDR_Obj_RefObjID09Val FR_RDR_Obj_RefObjID09Val;
  COM_DT_FR_RDR_Obj_RefObjID10Val FR_RDR_Obj_RefObjID10Val;
  COM_DT_FR_RDR_Obj_RelAccelX09Val FR_RDR_Obj_RelAccelX09Val;
  COM_DT_FR_RDR_Obj_RelAccelX10Val FR_RDR_Obj_RelAccelX10Val;
  COM_DT_FR_RDR_Obj_RelPosX09Val FR_RDR_Obj_RelPosX09Val;
  COM_DT_FR_RDR_Obj_RelPosX10Val FR_RDR_Obj_RelPosX10Val;
  COM_DT_FR_RDR_Obj_RelPosY09Val FR_RDR_Obj_RelPosY09Val;
  COM_DT_FR_RDR_Obj_RelPosY10Val FR_RDR_Obj_RelPosY10Val;
  COM_DT_FR_RDR_Obj_RelVelX09Val FR_RDR_Obj_RelVelX09Val;
  COM_DT_FR_RDR_Obj_RelVelX10Val FR_RDR_Obj_RelVelX10Val;
  COM_DT_FR_RDR_Obj_RelVelY09Val FR_RDR_Obj_RelVelY09Val;
  COM_DT_FR_RDR_Obj_RelVelY10Val FR_RDR_Obj_RelVelY10Val;
  COM_DT_FR_RDR_Obj_TrkSta09Sta FR_RDR_Obj_TrkSta09Sta;
  COM_DT_FR_RDR_Obj_TrkSta10Sta FR_RDR_Obj_TrkSta10Sta;
} COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge11Val FR_RDR_Obj_AlvAge11Val;
  COM_DT_FR_RDR_Obj_AlvAge12Val FR_RDR_Obj_AlvAge12Val;
  COM_DT_FR_RDR_Obj_AlvCnt06Val FR_RDR_Obj_AlvCnt06Val;
  COM_DT_FR_RDR_Obj_CoastAge11Val FR_RDR_Obj_CoastAge11Val;
  COM_DT_FR_RDR_Obj_CoastAge12Val FR_RDR_Obj_CoastAge12Val;
  COM_DT_FR_RDR_Obj_CRC06Val FR_RDR_Obj_CRC06Val;
  COM_DT_FR_RDR_Obj_MedRangeMod11Val FR_RDR_Obj_MedRangeMod11Val;
  COM_DT_FR_RDR_Obj_MedRangeMod12Val FR_RDR_Obj_MedRangeMod12Val;
  COM_DT_FR_RDR_Obj_MvngFlag11Sta FR_RDR_Obj_MvngFlag11Sta;
  COM_DT_FR_RDR_Obj_MvngFlag12Sta FR_RDR_Obj_MvngFlag12Sta;
  COM_DT_FR_RDR_Obj_QualLvl11Sta FR_RDR_Obj_QualLvl11Sta;
  COM_DT_FR_RDR_Obj_QualLvl12Sta FR_RDR_Obj_QualLvl12Sta;
  COM_DT_FR_RDR_Obj_RefObjID11Val FR_RDR_Obj_RefObjID11Val;
  COM_DT_FR_RDR_Obj_RefObjID12Val FR_RDR_Obj_RefObjID12Val;
  COM_DT_FR_RDR_Obj_RelAccelX11Val FR_RDR_Obj_RelAccelX11Val;
  COM_DT_FR_RDR_Obj_RelAccelX12Val FR_RDR_Obj_RelAccelX12Val;
  COM_DT_FR_RDR_Obj_RelPosX11Val FR_RDR_Obj_RelPosX11Val;
  COM_DT_FR_RDR_Obj_RelPosX12Val FR_RDR_Obj_RelPosX12Val;
  COM_DT_FR_RDR_Obj_RelPosY11Val FR_RDR_Obj_RelPosY11Val;
  COM_DT_FR_RDR_Obj_RelPosY12Val FR_RDR_Obj_RelPosY12Val;
  COM_DT_FR_RDR_Obj_RelVelX11Val FR_RDR_Obj_RelVelX11Val;
  COM_DT_FR_RDR_Obj_RelVelX12Val FR_RDR_Obj_RelVelX12Val;
  COM_DT_FR_RDR_Obj_RelVelY11Val FR_RDR_Obj_RelVelY11Val;
  COM_DT_FR_RDR_Obj_RelVelY12Val FR_RDR_Obj_RelVelY12Val;
  COM_DT_FR_RDR_Obj_TrkSta11Sta FR_RDR_Obj_TrkSta11Sta;
  COM_DT_FR_RDR_Obj_TrkSta12Sta FR_RDR_Obj_TrkSta12Sta;
} COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge13Val FR_RDR_Obj_AlvAge13Val;
  COM_DT_FR_RDR_Obj_AlvAge14Val FR_RDR_Obj_AlvAge14Val;
  COM_DT_FR_RDR_Obj_AlvCnt07Val FR_RDR_Obj_AlvCnt07Val;
  COM_DT_FR_RDR_Obj_CoastAge13Val FR_RDR_Obj_CoastAge13Val;
  COM_DT_FR_RDR_Obj_CoastAge14Val FR_RDR_Obj_CoastAge14Val;
  COM_DT_FR_RDR_Obj_CRC07Val FR_RDR_Obj_CRC07Val;
  COM_DT_FR_RDR_Obj_MedRangeMod13Val FR_RDR_Obj_MedRangeMod13Val;
  COM_DT_FR_RDR_Obj_MedRangeMod14Val FR_RDR_Obj_MedRangeMod14Val;
  COM_DT_FR_RDR_Obj_MvngFlag13Sta FR_RDR_Obj_MvngFlag13Sta;
  COM_DT_FR_RDR_Obj_MvngFlag14Sta FR_RDR_Obj_MvngFlag14Sta;
  COM_DT_FR_RDR_Obj_QualLvl13Sta FR_RDR_Obj_QualLvl13Sta;
  COM_DT_FR_RDR_Obj_QualLvl14Sta FR_RDR_Obj_QualLvl14Sta;
  COM_DT_FR_RDR_Obj_RefObjID13Val FR_RDR_Obj_RefObjID13Val;
  COM_DT_FR_RDR_Obj_RefObjID14Val FR_RDR_Obj_RefObjID14Val;
  COM_DT_FR_RDR_Obj_RelAccelX13Val FR_RDR_Obj_RelAccelX13Val;
  COM_DT_FR_RDR_Obj_RelAccelX14Val FR_RDR_Obj_RelAccelX14Val;
  COM_DT_FR_RDR_Obj_RelPosX13Val FR_RDR_Obj_RelPosX13Val;
  COM_DT_FR_RDR_Obj_RelPosX14Val FR_RDR_Obj_RelPosX14Val;
  COM_DT_FR_RDR_Obj_RelPosY13Val FR_RDR_Obj_RelPosY13Val;
  COM_DT_FR_RDR_Obj_RelPosY14Val FR_RDR_Obj_RelPosY14Val;
  COM_DT_FR_RDR_Obj_RelVelX13Val FR_RDR_Obj_RelVelX13Val;
  COM_DT_FR_RDR_Obj_RelVelX14Val FR_RDR_Obj_RelVelX14Val;
  COM_DT_FR_RDR_Obj_RelVelY13Val FR_RDR_Obj_RelVelY13Val;
  COM_DT_FR_RDR_Obj_RelVelY14Val FR_RDR_Obj_RelVelY14Val;
  COM_DT_FR_RDR_Obj_TrkSta13Sta FR_RDR_Obj_TrkSta13Sta;
  COM_DT_FR_RDR_Obj_TrkSta14Sta FR_RDR_Obj_TrkSta14Sta;
} COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge15Val FR_RDR_Obj_AlvAge15Val;
  COM_DT_FR_RDR_Obj_AlvAge16Val FR_RDR_Obj_AlvAge16Val;
  COM_DT_FR_RDR_Obj_AlvCnt08Val FR_RDR_Obj_AlvCnt08Val;
  COM_DT_FR_RDR_Obj_CoastAge15Val FR_RDR_Obj_CoastAge15Val;
  COM_DT_FR_RDR_Obj_CoastAge16Val FR_RDR_Obj_CoastAge16Val;
  COM_DT_FR_RDR_Obj_CRC08Val FR_RDR_Obj_CRC08Val;
  COM_DT_FR_RDR_Obj_MedRangeMod15Val FR_RDR_Obj_MedRangeMod15Val;
  COM_DT_FR_RDR_Obj_MedRangeMod16Val FR_RDR_Obj_MedRangeMod16Val;
  COM_DT_FR_RDR_Obj_MvngFlag15Sta FR_RDR_Obj_MvngFlag15Sta;
  COM_DT_FR_RDR_Obj_MvngFlag16Sta FR_RDR_Obj_MvngFlag16Sta;
  COM_DT_FR_RDR_Obj_QualLvl15Sta FR_RDR_Obj_QualLvl15Sta;
  COM_DT_FR_RDR_Obj_QualLvl16Sta FR_RDR_Obj_QualLvl16Sta;
  COM_DT_FR_RDR_Obj_RefObjID15Val FR_RDR_Obj_RefObjID15Val;
  COM_DT_FR_RDR_Obj_RefObjID16Val FR_RDR_Obj_RefObjID16Val;
  COM_DT_FR_RDR_Obj_RelAccelX15Val FR_RDR_Obj_RelAccelX15Val;
  COM_DT_FR_RDR_Obj_RelAccelX16Val FR_RDR_Obj_RelAccelX16Val;
  COM_DT_FR_RDR_Obj_RelPosX15Val FR_RDR_Obj_RelPosX15Val;
  COM_DT_FR_RDR_Obj_RelPosX16Val FR_RDR_Obj_RelPosX16Val;
  COM_DT_FR_RDR_Obj_RelPosY15Val FR_RDR_Obj_RelPosY15Val;
  COM_DT_FR_RDR_Obj_RelPosY16Val FR_RDR_Obj_RelPosY16Val;
  COM_DT_FR_RDR_Obj_RelVelX15Val FR_RDR_Obj_RelVelX15Val;
  COM_DT_FR_RDR_Obj_RelVelX16Val FR_RDR_Obj_RelVelX16Val;
  COM_DT_FR_RDR_Obj_RelVelY15Val FR_RDR_Obj_RelVelY15Val;
  COM_DT_FR_RDR_Obj_RelVelY16Val FR_RDR_Obj_RelVelY16Val;
  COM_DT_FR_RDR_Obj_TrkSta15Sta FR_RDR_Obj_TrkSta15Sta;
  COM_DT_FR_RDR_Obj_TrkSta16Sta FR_RDR_Obj_TrkSta16Sta;
} COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge17Val FR_RDR_Obj_AlvAge17Val;
  COM_DT_FR_RDR_Obj_AlvAge18Val FR_RDR_Obj_AlvAge18Val;
  COM_DT_FR_RDR_Obj_AlvCnt09Val FR_RDR_Obj_AlvCnt09Val;
  COM_DT_FR_RDR_Obj_CoastAge17Val FR_RDR_Obj_CoastAge17Val;
  COM_DT_FR_RDR_Obj_CoastAge18Val FR_RDR_Obj_CoastAge18Val;
  COM_DT_FR_RDR_Obj_CRC09Val FR_RDR_Obj_CRC09Val;
  COM_DT_FR_RDR_Obj_MedRangeMod17Val FR_RDR_Obj_MedRangeMod17Val;
  COM_DT_FR_RDR_Obj_MedRangeMod18Val FR_RDR_Obj_MedRangeMod18Val;
  COM_DT_FR_RDR_Obj_MvngFlag17Sta FR_RDR_Obj_MvngFlag17Sta;
  COM_DT_FR_RDR_Obj_MvngFlag18Sta FR_RDR_Obj_MvngFlag18Sta;
  COM_DT_FR_RDR_Obj_QualLvl17Sta FR_RDR_Obj_QualLvl17Sta;
  COM_DT_FR_RDR_Obj_QualLvl18Sta FR_RDR_Obj_QualLvl18Sta;
  COM_DT_FR_RDR_Obj_RefObjID17Val FR_RDR_Obj_RefObjID17Val;
  COM_DT_FR_RDR_Obj_RefObjID18Val FR_RDR_Obj_RefObjID18Val;
  COM_DT_FR_RDR_Obj_RelAccelX17Val FR_RDR_Obj_RelAccelX17Val;
  COM_DT_FR_RDR_Obj_RelAccelX18Val FR_RDR_Obj_RelAccelX18Val;
  COM_DT_FR_RDR_Obj_RelPosX17Val FR_RDR_Obj_RelPosX17Val;
  COM_DT_FR_RDR_Obj_RelPosX18Val FR_RDR_Obj_RelPosX18Val;
  COM_DT_FR_RDR_Obj_RelPosY17Val FR_RDR_Obj_RelPosY17Val;
  COM_DT_FR_RDR_Obj_RelPosY18Val FR_RDR_Obj_RelPosY18Val;
  COM_DT_FR_RDR_Obj_RelVelX17Val FR_RDR_Obj_RelVelX17Val;
  COM_DT_FR_RDR_Obj_RelVelX18Val FR_RDR_Obj_RelVelX18Val;
  COM_DT_FR_RDR_Obj_RelVelY17Val FR_RDR_Obj_RelVelY17Val;
  COM_DT_FR_RDR_Obj_RelVelY18Val FR_RDR_Obj_RelVelY18Val;
  COM_DT_FR_RDR_Obj_TrkSta17Sta FR_RDR_Obj_TrkSta17Sta;
  COM_DT_FR_RDR_Obj_TrkSta18Sta FR_RDR_Obj_TrkSta18Sta;
} COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge19Val FR_RDR_Obj_AlvAge19Val;
  COM_DT_FR_RDR_Obj_AlvAge20Val FR_RDR_Obj_AlvAge20Val;
  COM_DT_FR_RDR_Obj_AlvCnt10Val FR_RDR_Obj_AlvCnt10Val;
  COM_DT_FR_RDR_Obj_CoastAge19Val FR_RDR_Obj_CoastAge19Val;
  COM_DT_FR_RDR_Obj_CoastAge20Val FR_RDR_Obj_CoastAge20Val;
  COM_DT_FR_RDR_Obj_CRC10Val FR_RDR_Obj_CRC10Val;
  COM_DT_FR_RDR_Obj_MedRangeMod19Val FR_RDR_Obj_MedRangeMod19Val;
  COM_DT_FR_RDR_Obj_MedRangeMod20Val FR_RDR_Obj_MedRangeMod20Val;
  COM_DT_FR_RDR_Obj_MvngFlag19Sta FR_RDR_Obj_MvngFlag19Sta;
  COM_DT_FR_RDR_Obj_MvngFlag20Sta FR_RDR_Obj_MvngFlag20Sta;
  COM_DT_FR_RDR_Obj_QualLvl19Sta FR_RDR_Obj_QualLvl19Sta;
  COM_DT_FR_RDR_Obj_QualLvl20Sta FR_RDR_Obj_QualLvl20Sta;
  COM_DT_FR_RDR_Obj_RefObjID19Val FR_RDR_Obj_RefObjID19Val;
  COM_DT_FR_RDR_Obj_RefObjID20Val FR_RDR_Obj_RefObjID20Val;
  COM_DT_FR_RDR_Obj_RelAccelX19Val FR_RDR_Obj_RelAccelX19Val;
  COM_DT_FR_RDR_Obj_RelAccelX20Val FR_RDR_Obj_RelAccelX20Val;
  COM_DT_FR_RDR_Obj_RelPosX19Val FR_RDR_Obj_RelPosX19Val;
  COM_DT_FR_RDR_Obj_RelPosX20Val FR_RDR_Obj_RelPosX20Val;
  COM_DT_FR_RDR_Obj_RelPosY19Val FR_RDR_Obj_RelPosY19Val;
  COM_DT_FR_RDR_Obj_RelPosY20Val FR_RDR_Obj_RelPosY20Val;
  COM_DT_FR_RDR_Obj_RelVelX19Val FR_RDR_Obj_RelVelX19Val;
  COM_DT_FR_RDR_Obj_RelVelX20Val FR_RDR_Obj_RelVelX20Val;
  COM_DT_FR_RDR_Obj_RelVelY19Val FR_RDR_Obj_RelVelY19Val;
  COM_DT_FR_RDR_Obj_RelVelY20Val FR_RDR_Obj_RelVelY20Val;
  COM_DT_FR_RDR_Obj_TrkSta19Sta FR_RDR_Obj_TrkSta19Sta;
  COM_DT_FR_RDR_Obj_TrkSta20Sta FR_RDR_Obj_TrkSta20Sta;
} COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge21Val FR_RDR_Obj_AlvAge21Val;
  COM_DT_FR_RDR_Obj_AlvAge22Val FR_RDR_Obj_AlvAge22Val;
  COM_DT_FR_RDR_Obj_AlvCnt11Val FR_RDR_Obj_AlvCnt11Val;
  COM_DT_FR_RDR_Obj_CoastAge21Val FR_RDR_Obj_CoastAge21Val;
  COM_DT_FR_RDR_Obj_CoastAge22Val FR_RDR_Obj_CoastAge22Val;
  COM_DT_FR_RDR_Obj_CRC11Val FR_RDR_Obj_CRC11Val;
  COM_DT_FR_RDR_Obj_MedRangeMod21Val FR_RDR_Obj_MedRangeMod21Val;
  COM_DT_FR_RDR_Obj_MedRangeMod22Val FR_RDR_Obj_MedRangeMod22Val;
  COM_DT_FR_RDR_Obj_MvngFlag21Sta FR_RDR_Obj_MvngFlag21Sta;
  COM_DT_FR_RDR_Obj_MvngFlag22Sta FR_RDR_Obj_MvngFlag22Sta;
  COM_DT_FR_RDR_Obj_QualLvl21Sta FR_RDR_Obj_QualLvl21Sta;
  COM_DT_FR_RDR_Obj_QualLvl22Sta FR_RDR_Obj_QualLvl22Sta;
  COM_DT_FR_RDR_Obj_RefObjID21Val FR_RDR_Obj_RefObjID21Val;
  COM_DT_FR_RDR_Obj_RefObjID22Val FR_RDR_Obj_RefObjID22Val;
  COM_DT_FR_RDR_Obj_RelAccelX21Val FR_RDR_Obj_RelAccelX21Val;
  COM_DT_FR_RDR_Obj_RelAccelX22Val FR_RDR_Obj_RelAccelX22Val;
  COM_DT_FR_RDR_Obj_RelPosX21Val FR_RDR_Obj_RelPosX21Val;
  COM_DT_FR_RDR_Obj_RelPosX22Val FR_RDR_Obj_RelPosX22Val;
  COM_DT_FR_RDR_Obj_RelPosY21Val FR_RDR_Obj_RelPosY21Val;
  COM_DT_FR_RDR_Obj_RelPosY22Val FR_RDR_Obj_RelPosY22Val;
  COM_DT_FR_RDR_Obj_RelVelX21Val FR_RDR_Obj_RelVelX21Val;
  COM_DT_FR_RDR_Obj_RelVelX22Val FR_RDR_Obj_RelVelX22Val;
  COM_DT_FR_RDR_Obj_RelVelY21Val FR_RDR_Obj_RelVelY21Val;
  COM_DT_FR_RDR_Obj_RelVelY22Val FR_RDR_Obj_RelVelY22Val;
  COM_DT_FR_RDR_Obj_TrkSta21Sta FR_RDR_Obj_TrkSta21Sta;
  COM_DT_FR_RDR_Obj_TrkSta22Sta FR_RDR_Obj_TrkSta22Sta;
} COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge23Val FR_RDR_Obj_AlvAge23Val;
  COM_DT_FR_RDR_Obj_AlvAge24Val FR_RDR_Obj_AlvAge24Val;
  COM_DT_FR_RDR_Obj_AlvCnt12Val FR_RDR_Obj_AlvCnt12Val;
  COM_DT_FR_RDR_Obj_CoastAge23Val FR_RDR_Obj_CoastAge23Val;
  COM_DT_FR_RDR_Obj_CoastAge24Val FR_RDR_Obj_CoastAge24Val;
  COM_DT_FR_RDR_Obj_CRC12Val FR_RDR_Obj_CRC12Val;
  COM_DT_FR_RDR_Obj_MedRangeMod23Val FR_RDR_Obj_MedRangeMod23Val;
  COM_DT_FR_RDR_Obj_MedRangeMod24Val FR_RDR_Obj_MedRangeMod24Val;
  COM_DT_FR_RDR_Obj_MvngFlag23Sta FR_RDR_Obj_MvngFlag23Sta;
  COM_DT_FR_RDR_Obj_MvngFlag24Sta FR_RDR_Obj_MvngFlag24Sta;
  COM_DT_FR_RDR_Obj_QualLvl23Sta FR_RDR_Obj_QualLvl23Sta;
  COM_DT_FR_RDR_Obj_QualLvl24Sta FR_RDR_Obj_QualLvl24Sta;
  COM_DT_FR_RDR_Obj_RefObjID23Val FR_RDR_Obj_RefObjID23Val;
  COM_DT_FR_RDR_Obj_RefObjID24Val FR_RDR_Obj_RefObjID24Val;
  COM_DT_FR_RDR_Obj_RelAccelX23Val FR_RDR_Obj_RelAccelX23Val;
  COM_DT_FR_RDR_Obj_RelAccelX24Val FR_RDR_Obj_RelAccelX24Val;
  COM_DT_FR_RDR_Obj_RelPosX23Val FR_RDR_Obj_RelPosX23Val;
  COM_DT_FR_RDR_Obj_RelPosX24Val FR_RDR_Obj_RelPosX24Val;
  COM_DT_FR_RDR_Obj_RelPosY23Val FR_RDR_Obj_RelPosY23Val;
  COM_DT_FR_RDR_Obj_RelPosY24Val FR_RDR_Obj_RelPosY24Val;
  COM_DT_FR_RDR_Obj_RelVelX23Val FR_RDR_Obj_RelVelX23Val;
  COM_DT_FR_RDR_Obj_RelVelX24Val FR_RDR_Obj_RelVelX24Val;
  COM_DT_FR_RDR_Obj_RelVelY23Val FR_RDR_Obj_RelVelY23Val;
  COM_DT_FR_RDR_Obj_RelVelY24Val FR_RDR_Obj_RelVelY24Val;
  COM_DT_FR_RDR_Obj_TrkSta23Sta FR_RDR_Obj_TrkSta23Sta;
  COM_DT_FR_RDR_Obj_TrkSta24Sta FR_RDR_Obj_TrkSta24Sta;
} COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge25Val FR_RDR_Obj_AlvAge25Val;
  COM_DT_FR_RDR_Obj_AlvAge26Val FR_RDR_Obj_AlvAge26Val;
  COM_DT_FR_RDR_Obj_AlvCnt13Val FR_RDR_Obj_AlvCnt13Val;
  COM_DT_FR_RDR_Obj_CoastAge25Val FR_RDR_Obj_CoastAge25Val;
  COM_DT_FR_RDR_Obj_CoastAge26Val FR_RDR_Obj_CoastAge26Val;
  COM_DT_FR_RDR_Obj_CRC13Val FR_RDR_Obj_CRC13Val;
  COM_DT_FR_RDR_Obj_MedRangeMod25Val FR_RDR_Obj_MedRangeMod25Val;
  COM_DT_FR_RDR_Obj_MedRangeMod26Val FR_RDR_Obj_MedRangeMod26Val;
  COM_DT_FR_RDR_Obj_MvngFlag25Sta FR_RDR_Obj_MvngFlag25Sta;
  COM_DT_FR_RDR_Obj_MvngFlag26Sta FR_RDR_Obj_MvngFlag26Sta;
  COM_DT_FR_RDR_Obj_QualLvl25Sta FR_RDR_Obj_QualLvl25Sta;
  COM_DT_FR_RDR_Obj_QualLvl26Sta FR_RDR_Obj_QualLvl26Sta;
  COM_DT_FR_RDR_Obj_RefObjID25Val FR_RDR_Obj_RefObjID25Val;
  COM_DT_FR_RDR_Obj_RefObjID26Val FR_RDR_Obj_RefObjID26Val;
  COM_DT_FR_RDR_Obj_RelAccelX25Val FR_RDR_Obj_RelAccelX25Val;
  COM_DT_FR_RDR_Obj_RelAccelX26Val FR_RDR_Obj_RelAccelX26Val;
  COM_DT_FR_RDR_Obj_RelPosX25Val FR_RDR_Obj_RelPosX25Val;
  COM_DT_FR_RDR_Obj_RelPosX26Val FR_RDR_Obj_RelPosX26Val;
  COM_DT_FR_RDR_Obj_RelPosY25Val FR_RDR_Obj_RelPosY25Val;
  COM_DT_FR_RDR_Obj_RelPosY26Val FR_RDR_Obj_RelPosY26Val;
  COM_DT_FR_RDR_Obj_RelVelX25Val FR_RDR_Obj_RelVelX25Val;
  COM_DT_FR_RDR_Obj_RelVelX26Val FR_RDR_Obj_RelVelX26Val;
  COM_DT_FR_RDR_Obj_RelVelY25Val FR_RDR_Obj_RelVelY25Val;
  COM_DT_FR_RDR_Obj_RelVelY26Val FR_RDR_Obj_RelVelY26Val;
  COM_DT_FR_RDR_Obj_TrkSta25Sta FR_RDR_Obj_TrkSta25Sta;
  COM_DT_FR_RDR_Obj_TrkSta26Sta FR_RDR_Obj_TrkSta26Sta;
} COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge27Val FR_RDR_Obj_AlvAge27Val;
  COM_DT_FR_RDR_Obj_AlvAge28Val FR_RDR_Obj_AlvAge28Val;
  COM_DT_FR_RDR_Obj_AlvCnt14Val FR_RDR_Obj_AlvCnt14Val;
  COM_DT_FR_RDR_Obj_CoastAge27Val FR_RDR_Obj_CoastAge27Val;
  COM_DT_FR_RDR_Obj_CoastAge28Val FR_RDR_Obj_CoastAge28Val;
  COM_DT_FR_RDR_Obj_CRC14Val FR_RDR_Obj_CRC14Val;
  COM_DT_FR_RDR_Obj_MedRangeMod27Val FR_RDR_Obj_MedRangeMod27Val;
  COM_DT_FR_RDR_Obj_MedRangeMod28Val FR_RDR_Obj_MedRangeMod28Val;
  COM_DT_FR_RDR_Obj_MvngFlag27Sta FR_RDR_Obj_MvngFlag27Sta;
  COM_DT_FR_RDR_Obj_MvngFlag28Sta FR_RDR_Obj_MvngFlag28Sta;
  COM_DT_FR_RDR_Obj_QualLvl27Sta FR_RDR_Obj_QualLvl27Sta;
  COM_DT_FR_RDR_Obj_QualLvl28Sta FR_RDR_Obj_QualLvl28Sta;
  COM_DT_FR_RDR_Obj_RefObjID27Val FR_RDR_Obj_RefObjID27Val;
  COM_DT_FR_RDR_Obj_RefObjID28Val FR_RDR_Obj_RefObjID28Val;
  COM_DT_FR_RDR_Obj_RelAccelX27Val FR_RDR_Obj_RelAccelX27Val;
  COM_DT_FR_RDR_Obj_RelAccelX28Val FR_RDR_Obj_RelAccelX28Val;
  COM_DT_FR_RDR_Obj_RelPosX27Val FR_RDR_Obj_RelPosX27Val;
  COM_DT_FR_RDR_Obj_RelPosX28Val FR_RDR_Obj_RelPosX28Val;
  COM_DT_FR_RDR_Obj_RelPosY27Val FR_RDR_Obj_RelPosY27Val;
  COM_DT_FR_RDR_Obj_RelPosY28Val FR_RDR_Obj_RelPosY28Val;
  COM_DT_FR_RDR_Obj_RelVelX27Val FR_RDR_Obj_RelVelX27Val;
  COM_DT_FR_RDR_Obj_RelVelX28Val FR_RDR_Obj_RelVelX28Val;
  COM_DT_FR_RDR_Obj_RelVelY27Val FR_RDR_Obj_RelVelY27Val;
  COM_DT_FR_RDR_Obj_RelVelY28Val FR_RDR_Obj_RelVelY28Val;
  COM_DT_FR_RDR_Obj_TrkSta27Sta FR_RDR_Obj_TrkSta27Sta;
  COM_DT_FR_RDR_Obj_TrkSta28Sta FR_RDR_Obj_TrkSta28Sta;
} COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge29Val FR_RDR_Obj_AlvAge29Val;
  COM_DT_FR_RDR_Obj_AlvAge30Val FR_RDR_Obj_AlvAge30Val;
  COM_DT_FR_RDR_Obj_AlvCnt15Val FR_RDR_Obj_AlvCnt15Val;
  COM_DT_FR_RDR_Obj_CoastAge29Val FR_RDR_Obj_CoastAge29Val;
  COM_DT_FR_RDR_Obj_CoastAge30Val FR_RDR_Obj_CoastAge30Val;
  COM_DT_FR_RDR_Obj_CRC15Val FR_RDR_Obj_CRC15Val;
  COM_DT_FR_RDR_Obj_MedRangeMod29Val FR_RDR_Obj_MedRangeMod29Val;
  COM_DT_FR_RDR_Obj_MedRangeMod30Val FR_RDR_Obj_MedRangeMod30Val;
  COM_DT_FR_RDR_Obj_MvngFlag29Sta FR_RDR_Obj_MvngFlag29Sta;
  COM_DT_FR_RDR_Obj_MvngFlag30Sta FR_RDR_Obj_MvngFlag30Sta;
  COM_DT_FR_RDR_Obj_QualLvl29Sta FR_RDR_Obj_QualLvl29Sta;
  COM_DT_FR_RDR_Obj_QualLvl30Sta FR_RDR_Obj_QualLvl30Sta;
  COM_DT_FR_RDR_Obj_RefObjID29Val FR_RDR_Obj_RefObjID29Val;
  COM_DT_FR_RDR_Obj_RefObjID30Val FR_RDR_Obj_RefObjID30Val;
  COM_DT_FR_RDR_Obj_RelAccelX29Val FR_RDR_Obj_RelAccelX29Val;
  COM_DT_FR_RDR_Obj_RelAccelX30Val FR_RDR_Obj_RelAccelX30Val;
  COM_DT_FR_RDR_Obj_RelPosX29Val FR_RDR_Obj_RelPosX29Val;
  COM_DT_FR_RDR_Obj_RelPosX30Val FR_RDR_Obj_RelPosX30Val;
  COM_DT_FR_RDR_Obj_RelPosY29Val FR_RDR_Obj_RelPosY29Val;
  COM_DT_FR_RDR_Obj_RelPosY30Val FR_RDR_Obj_RelPosY30Val;
  COM_DT_FR_RDR_Obj_RelVelX29Val FR_RDR_Obj_RelVelX29Val;
  COM_DT_FR_RDR_Obj_RelVelX30Val FR_RDR_Obj_RelVelX30Val;
  COM_DT_FR_RDR_Obj_RelVelY29Val FR_RDR_Obj_RelVelY29Val;
  COM_DT_FR_RDR_Obj_RelVelY30Val FR_RDR_Obj_RelVelY30Val;
  COM_DT_FR_RDR_Obj_TrkSta29Sta FR_RDR_Obj_TrkSta29Sta;
  COM_DT_FR_RDR_Obj_TrkSta30Sta FR_RDR_Obj_TrkSta30Sta;
} COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup
typedef struct
{
  COM_DT_FR_RDR_Obj_AlvAge31Val FR_RDR_Obj_AlvAge31Val;
  COM_DT_FR_RDR_Obj_AlvAge32Val FR_RDR_Obj_AlvAge32Val;
  COM_DT_FR_RDR_Obj_AlvCnt16Val FR_RDR_Obj_AlvCnt16Val;
  COM_DT_FR_RDR_Obj_CoastAge31Val FR_RDR_Obj_CoastAge31Val;
  COM_DT_FR_RDR_Obj_CoastAge32Val FR_RDR_Obj_CoastAge32Val;
  COM_DT_FR_RDR_Obj_CRC16Val FR_RDR_Obj_CRC16Val;
  COM_DT_FR_RDR_Obj_MedRangeMod31Val FR_RDR_Obj_MedRangeMod31Val;
  COM_DT_FR_RDR_Obj_MedRangeMod32Val FR_RDR_Obj_MedRangeMod32Val;
  COM_DT_FR_RDR_Obj_MvngFlag31Sta FR_RDR_Obj_MvngFlag31Sta;
  COM_DT_FR_RDR_Obj_MvngFlag32Sta FR_RDR_Obj_MvngFlag32Sta;
  COM_DT_FR_RDR_Obj_QualLvl31Sta FR_RDR_Obj_QualLvl31Sta;
  COM_DT_FR_RDR_Obj_QualLvl32Sta FR_RDR_Obj_QualLvl32Sta;
  COM_DT_FR_RDR_Obj_RefObjID31Val FR_RDR_Obj_RefObjID31Val;
  COM_DT_FR_RDR_Obj_RefObjID32Val FR_RDR_Obj_RefObjID32Val;
  COM_DT_FR_RDR_Obj_RelAccelX31Val FR_RDR_Obj_RelAccelX31Val;
  COM_DT_FR_RDR_Obj_RelAccelX32Val FR_RDR_Obj_RelAccelX32Val;
  COM_DT_FR_RDR_Obj_RelPosX31Val FR_RDR_Obj_RelPosX31Val;
  COM_DT_FR_RDR_Obj_RelPosX32Val FR_RDR_Obj_RelPosX32Val;
  COM_DT_FR_RDR_Obj_RelPosY31Val FR_RDR_Obj_RelPosY31Val;
  COM_DT_FR_RDR_Obj_RelPosY32Val FR_RDR_Obj_RelPosY32Val;
  COM_DT_FR_RDR_Obj_RelVelX31Val FR_RDR_Obj_RelVelX31Val;
  COM_DT_FR_RDR_Obj_RelVelX32Val FR_RDR_Obj_RelVelX32Val;
  COM_DT_FR_RDR_Obj_RelVelY31Val FR_RDR_Obj_RelVelY31Val;
  COM_DT_FR_RDR_Obj_RelVelY32Val FR_RDR_Obj_RelVelY32Val;
  COM_DT_FR_RDR_Obj_TrkSta31Sta FR_RDR_Obj_TrkSta31Sta;
  COM_DT_FR_RDR_Obj_TrkSta32Sta FR_RDR_Obj_TrkSta32Sta;
} COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_MDPS_01_10ms_SignalGroup
typedef struct
{
  COM_DT_MDPS_AlvCnt1Val MDPS_AlvCnt1Val;
  COM_DT_MDPS_Crc1Val MDPS_Crc1Val;
  COM_DT_MDPS_LkaPlgInSta MDPS_LkaPlgInSta;
  COM_DT_MDPS_LkaToiActvSta MDPS_LkaToiActvSta;
  COM_DT_MDPS_LkaToiUnblSta MDPS_LkaToiUnblSta;
  COM_DT_MDPS_LkaToiFltSta MDPS_LkaToiFltSta;
  COM_DT_MDPS_PaModeSta MDPS_PaModeSta;
  COM_DT_MDPS_StrTqSnsrVal MDPS_StrTqSnsrVal;
  COM_DT_MDPS_ADAS_AciFltSig MDPS_ADAS_AciFltSig;
  COM_DT_MDPS_ADAS_AciFltSig_Lv2 MDPS_ADAS_AciFltSig_Lv2;
  COM_DT_MDPS_ADASAciActvSta MDPS_ADASAciActvSta;
  COM_DT_MDPS_ADASAciActvSta_Lv2 MDPS_ADASAciActvSta_Lv2;
  COM_DT_MDPS_CurrModVal MDPS_CurrModVal;
  COM_DT_MDPS_EngIdleRpmReq MDPS_EngIdleRpmReq;
  COM_DT_MDPS_EstStrAnglVal MDPS_EstStrAnglVal;
  COM_DT_MDPS_HDPSpprtSWVer MDPS_HDPSpprtSWVer;
  COM_DT_MDPS_LkaFailSta MDPS_LkaFailSta;
  COM_DT_MDPS_LoamModSta MDPS_LoamModSta;
  COM_DT_MDPS_OutTqVal MDPS_OutTqVal;
  COM_DT_MDPS_PaCanfltSta MDPS_PaCanfltSta;
  COM_DT_MDPS_PaPlugInSta MDPS_PaPlugInSta;
  COM_DT_MDPS_PaStrAnglVal MDPS_PaStrAnglVal;
  COM_DT_MDPS_Typ MDPS_Typ;
  COM_DT_MDPS_VsmActResp MDPS_VsmActResp;
  COM_DT_MDPS_VsmDfctvSta MDPS_VsmDfctvSta;
  COM_DT_MDPS_VsmPlgInSta MDPS_VsmPlgInSta;
  COM_DT_MDPS_VsmSigErrSta MDPS_VsmSigErrSta;
  COM_DT_MDPS_WrngLmpSta MDPS_WrngLmpSta;
} COM_DT_SG_MDPS_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_MFSW_01_200ms_SignalGroup
typedef struct
{
  COM_DT_Lamp_FrFogLmpSwSta Lamp_FrFogLmpSwSta;
  COM_DT_Lamp_HdLmpHiSwSta Lamp_HdLmpHiSwSta;
  COM_DT_Lamp_LaneChgTrnSigLftSwSta Lamp_LaneChgTrnSigLftSwSta;
  COM_DT_Lamp_LaneChgTrnSigRtSwSta Lamp_LaneChgTrnSigRtSwSta;
  COM_DT_Lamp_LtSwSta Lamp_LtSwSta;
  COM_DT_Lamp_PassingLmpSwSta Lamp_PassingLmpSwSta;
  COM_DT_Lamp_RrFogLmpSwSta Lamp_RrFogLmpSwSta;
  COM_DT_Lamp_TrnSigLftSwSta Lamp_TrnSigLftSwSta;
  COM_DT_Lamp_TrnSigRtSwSta Lamp_TrnSigRtSwSta;
  COM_DT_Lamp_TrnSigSwNtrlSta Lamp_TrnSigSwNtrlSta;
  COM_DT_MFSW_AlvCnt1Val MFSW_AlvCnt1Val;
  COM_DT_MFSW_Crc1Val MFSW_Crc1Val;
} COM_DT_SG_MFSW_01_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RD_DTC_SignalGroup
typedef struct
{
  BatteryVoltageHigh BatteryVoltageHigh;
  BatteryVoltageLow BatteryVoltageLow;
  Blockage_Drv Blockage_Drv;
  Blockage_Init Blockage_Init;
  RadarCANCommError RadarCANCommError;
  RadarErrorCode_No1 RadarErrorCode_No1;
  RadarErrorCode_No2 RadarErrorCode_No2;
  RadarHwError RadarHwError;
  RadarHwTempCondition_High RadarHwTempCondition_High;
  RadarHwTempCondition_Low RadarHwTempCondition_Low;
  RD_DTC_AlvCntVal RD_DTC_AlvCntVal;
  SystemOutOfCalibration_DRV SystemOutOfCalibration_DRV;
  SystemOutOfCalibration_EOL SystemOutOfCalibration_EOL;
  RD_DTC_CRCVal RD_DTC_CRCVal;
  FR_RDR_HW_Reset FR_RDR_HW_Reset;
  FR_RDR_SW_Reset FR_RDR_SW_Reset;
} COM_DT_SG_RD_DTC_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn01_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_41 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_42 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_43 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_44 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_45 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_46 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_47 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_48 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_49 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_50 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_51 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_52 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_53 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_54 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_55 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_56 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn01_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn02_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_25 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_26 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_27 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_28 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_29 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_30 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_31 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_32 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_33 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_34 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_35 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_36 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_37 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_38 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_39 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_40 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn02_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn03_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_57 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_58 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_59 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_60 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_61 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_62 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_63 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_64 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_65 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_66 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_67 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_68 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_69 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_70 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_71 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_72 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn03_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn04_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_73 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_74 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_75 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_76 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_77 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_78 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_79 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_80 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_81 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_82 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_83 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_84 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_85 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_86 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_87 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_88 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn04_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn05_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_01 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_02 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_03 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_04 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_05 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_06 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_07 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_08 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_09 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_10 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_11 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_12 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_13 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_14 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_15 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_16 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn05_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_RxDbgDataIn06_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataIn_2 u32_DbgDataIn_01;
  COM_DT_u32_DbgDataIn_3 u32_DbgDataIn_02;
  COM_DT_u32_DbgDataIn_4 u32_DbgDataIn_03;
  COM_DT_u32_DbgDataIn_5 u32_DbgDataIn_04;
  COM_DT_u32_DbgDataIn_6 u32_DbgDataIn_05;
  COM_DT_u32_DbgDataIn_7 u32_DbgDataIn_06;
  COM_DT_u32_DbgDataIn_8 u32_DbgDataIn_07;
  COM_DT_u32_DbgDataIn_9 u32_DbgDataIn_08;
  COM_DT_u32_DbgDataIn_17 u32_DbgDataIn_09;
  COM_DT_u32_DbgDataIn_18 u32_DbgDataIn_10;
  COM_DT_u32_DbgDataIn_19 u32_DbgDataIn_11;
  COM_DT_u32_DbgDataIn_20 u32_DbgDataIn_12;
  COM_DT_u32_DbgDataIn_21 u32_DbgDataIn_13;
  COM_DT_u32_DbgDataIn_22 u32_DbgDataIn_14;
  COM_DT_u32_DbgDataIn_23 u32_DbgDataIn_15;
  COM_DT_u32_DbgDataIn_24 u32_DbgDataIn_16;
} COM_DT_SG_RxDbgDataIn06_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_SAS_01_10ms_SignalGroup
typedef struct
{
  COM_DT_SAS_AlvCnt1Val SAS_AlvCnt1Val;
  COM_DT_SAS_AnglVal SAS_AnglVal;
  COM_DT_SAS_Crc1Val SAS_Crc1Val;
  COM_DT_SAS_IntSta SAS_IntSta;
  COM_DT_SAS_SpdVal SAS_SpdVal;
} COM_DT_SG_SAS_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_SMK_02_200ms_SignalGroup
typedef struct
{
  COM_DT_SMK_AccInSta SMK_AccInSta;
  COM_DT_SMK_AccRlySta SMK_AccRlySta;
  COM_DT_SMK_AlvCnt2Val SMK_AlvCnt2Val;
  COM_DT_SMK_AuthSta SMK_AuthSta;
  COM_DT_SMK_CLUAccIndOnReq SMK_CLUAccIndOnReq;
  COM_DT_SMK_Crc2Val SMK_Crc2Val;
  COM_DT_SMK_Ign1InSta SMK_Ign1InSta;
  COM_DT_SMK_Ign1RlySta SMK_Ign1RlySta;
  COM_DT_SMK_Ign2InSta SMK_Ign2InSta;
  COM_DT_SMK_Ign2RlySta SMK_Ign2RlySta;
  COM_DT_SMK_RmtKeyCrnkModSta SMK_RmtKeyCrnkModSta;
  COM_DT_SMK_RmtKeyEngRunSta SMK_RmtKeyEngRunSta;
  COM_DT_SMK_SCULckUnlckSta SMK_SCULckUnlckSta;
  COM_DT_SMK_StrtFdbckSta SMK_StrtFdbckSta;
  COM_DT_SMK_StrtrRlyOutSta SMK_StrtrRlyOutSta;
  COM_DT_SMK_TlCrnkModSta SMK_TlCrnkModSta;
  COM_DT_SMK_TlEngRunSta SMK_TlEngRunSta;
  COM_DT_SMK_TrmnlCtrlSta SMK_TrmnlCtrlSta;
  COM_DT_SMK_TrmnlMngrSta SMK_TrmnlMngrSta;
  COM_DT_SMK_VDModeActSta SMK_VDModeActSta;
  COM_DT_SSB_StrtStpBtnSw1Sta SSB_StrtStpBtnSw1Sta;
  COM_DT_SSB_StrtStpBtnSw2Sta SSB_StrtStpBtnSw2Sta;
} COM_DT_SG_SMK_02_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_SWRC_03_20ms_SignalGroup
typedef struct
{
  COM_DT_SWRC_CrsSwSta SWRC_CrsSwSta;
  COM_DT_SWRC_AlvCnt3Val SWRC_AlvCnt3Val;
  COM_DT_SWRC_Crc3Val SWRC_Crc3Val;
  COM_DT_SWRC_CrsMainSwSta SWRC_CrsMainSwSta;
  COM_DT_SWRC_HDPSpprtSWVer SWRC_HDPSpprtSWVer;
  COM_DT_SWRC_HdpSwSta SWRC_HdpSwSta;
  COM_DT_SWRC_Info SWRC_Info;
  COM_DT_SWRC_LFASwSta SWRC_LFASwSta;
  COM_DT_SWRC_PaddleDnSwSta SWRC_PaddleDnSwSta;
  COM_DT_SWRC_PaddleUpSwSta SWRC_PaddleUpSwSta;
  COM_DT_SWRC_SldMainSwSta SWRC_SldMainSwSta;
} COM_DT_SG_SWRC_03_20ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TCU_01_10ms_SignalGroup
typedef struct
{
  COM_DT_TCU_AlvCnt1Val TCU_AlvCnt1Val;
  COM_DT_TCU_Crc1Val TCU_Crc1Val;
  COM_DT_TCU_GearSlctDis TCU_GearSlctDis;
  COM_DT_DCT_CltchState DCT_CltchState;
  COM_DT_DCT_CrpTqReq DCT_CrpTqReq;
  COM_DT_DCT_EngIdleReq DCT_EngIdleReq;
  COM_DT_DCT_FuelCutReq DCT_FuelCutReq;
  COM_DT_DCT_RegenInhbt DCT_RegenInhbt;
  COM_DT_DCT_ShftTqReq DCT_ShftTqReq;
  COM_DT_DCT_TqIncReq DCT_TqIncReq;
  COM_DT_IMT_CltchPdlPos IMT_CltchPdlPos;
  COM_DT_IMT_DisCmd IMT_DisCmd;
  COM_DT_IMT_EOLstate IMT_EOLstate;
  COM_DT_TCH_EngTrgtGearSta TCH_EngTrgtGearSta;
  COM_DT_TCU_BrkOnReq TCU_BrkOnReq;
  COM_DT_TCU_CdaInhbtReq TCU_CdaInhbtReq;
  COM_DT_TCU_CluTrgtGearConfg TCU_CluTrgtGearConfg;
  COM_DT_TCU_CluTrgtGearSta TCU_CluTrgtGearSta;
  COM_DT_TCU_CurrGearSta TCU_CurrGearSta;
  COM_DT_TCU_DcmlVehSpdKphVal TCU_DcmlVehSpdKphVal;
  COM_DT_TCU_DrvngModDis TCU_DrvngModDis;
  COM_DT_TCU_DrvngModReq TCU_DrvngModReq;
  COM_DT_TCU_EngRpmDis TCU_EngRpmDis;
  COM_DT_TCU_EngRpmDisSta TCU_EngRpmDisSta;
  COM_DT_TCU_EngSpdIncReq TCU_EngSpdIncReq;
  COM_DT_TCU_EngTqIncReqVal TCU_EngTqIncReqVal;
  COM_DT_TCU_EngTqLimVal TCU_EngTqLimVal;
  COM_DT_TCU_EPBReq TCU_EPBReq;
  COM_DT_TCU_FrtStcShftSta TCU_FrtStcShftSta;
  COM_DT_TCU_FuelCutInhbtReq TCU_FuelCutInhbtReq;
  COM_DT_TCU_GearLmpBlnkngReq TCU_GearLmpBlnkngReq;
  COM_DT_TCU_GearShftSta TCU_GearShftSta;
  COM_DT_TCU_GearStepTyp TCU_GearStepTyp;
  COM_DT_TCU_IdleUpReq TCU_IdleUpReq;
  COM_DT_TCU_IsgInhbtReq TCU_IsgInhbtReq;
  COM_DT_TCU_LupTrgtEngSpdVal TCU_LupTrgtEngSpdVal;
  COM_DT_TCU_NetrlCtrlSta TCU_NetrlCtrlSta;
  COM_DT_TCU_ObdSta TCU_ObdSta;
  COM_DT_TCU_ShftPtrnSta TCU_ShftPtrnSta;
  COM_DT_TCU_SlpVal TCU_SlpVal;
  COM_DT_TCU_SmrtShftSta TCU_SmrtShftSta;
  COM_DT_TCU_SprkRtrdReq TCU_SprkRtrdReq;
  COM_DT_TCU_SprtyIndxSta TCU_SprtyIndxSta;
  COM_DT_TCU_TqCnvrtrSta TCU_TqCnvrtrSta;
  COM_DT_TCU_TqGrdntLimVal TCU_TqGrdntLimVal;
  COM_DT_TCU_TqRdctnVal TCU_TqRdctnVal;
  COM_DT_TCU_TrgtGearSta TCU_TrgtGearSta;
  COM_DT_TCU_Typ TCU_Typ;
  COM_DT_TCU_VehSpdKphVal TCU_VehSpdKphVal;
  COM_DT_TCU_VgisInhbtReq TCU_VgisInhbtReq;
} COM_DT_SG_TCU_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_01_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_121 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_122 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_123 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_124 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_125 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_126 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_127 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_128 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_129 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_130 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_131 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_132 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_133 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_134 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_135 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_136 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_01_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_02_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_137 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_138 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_139 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_140 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_141 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_142 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_143 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_144 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_145 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_146 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_147 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_148 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_149 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_150 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_151 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_152 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_02_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_03_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_185 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_186 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_187 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_188 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_189 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_190 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_191 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_192 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_193 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_194 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_195 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_196 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_197 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_198 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_199 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_200 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_03_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_04_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_153 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_154 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_155 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_156 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_157 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_158 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_159 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_160 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_161 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_162 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_163 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_164 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_165 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_166 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_167 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_168 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_04_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_05_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_57 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_58 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_59 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_60 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_61 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_62 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_63 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_64 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_65 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_66 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_67 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_68 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_69 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_70 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_71 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_72 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_05_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_06_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_01 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_02 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_03 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_04 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_05 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_06 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_07 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_08 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_09 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_10 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_11 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_12 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_13 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_14 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_15 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_16 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_06_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_07_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_105 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_106 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_107 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_108 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_109 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_110 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_111 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_112 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_113 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_114 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_115 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_116 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_117 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_118 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_119 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_120 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_07_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_08_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_41 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_42 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_43 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_44 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_45 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_46 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_47 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_48 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_49 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_50 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_51 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_52 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_53 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_54 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_55 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_56 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_08_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_09_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_281 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_282 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_283 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_284 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_285 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_286 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_287 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_288 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_289 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_290 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_291 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_292 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_293 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_294 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_295 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_296 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_09_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_10_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_201 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_202 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_203 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_204 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_205 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_206 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_207 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_208 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_209 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_210 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_211 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_212 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_213 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_214 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_215 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_216 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_10_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_11_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_73 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_74 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_75 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_76 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_77 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_78 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_79 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_80 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_81 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_82 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_83 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_84 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_85 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_86 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_87 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_88 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_11_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_12_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_89 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_90 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_91 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_92 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_93 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_94 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_95 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_96 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_97 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_98 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_99 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_100 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_101 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_102 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_103 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_104 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_12_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_13_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_233 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_234 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_235 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_236 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_237 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_238 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_239 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_240 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_241 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_242 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_243 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_244 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_245 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_246 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_247 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_248 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_13_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_14_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_217 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_218 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_219 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_220 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_221 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_222 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_223 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_224 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_225 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_226 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_227 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_228 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_229 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_230 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_231 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_232 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_14_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_15_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_297 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_298 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_299 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_300 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_301 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_302 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_303 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_304 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_305 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_306 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_307 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_308 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_309 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_310 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_311 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_312 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_15_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_16_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_265 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_266 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_267 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_268 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_269 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_270 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_271 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_272 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_273 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_274 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_275 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_276 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_277 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_278 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_279 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_280 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_16_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_17_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_25 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_26 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_27 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_28 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_29 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_30 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_31 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_32 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_33 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_34 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_35 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_36 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_37 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_38 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_39 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_40 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_17_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_18Signal_Group
typedef struct
{
  COM_DT_u32_DbgDataOut_2 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_3 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_4 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_5 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_6 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_7 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_8 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_9 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_17 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_18 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_19 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_20 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_21 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_22 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_23 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_24 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_18Signal_Group;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_19_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_249 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_250 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_251 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_252 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_253 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_254 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_255 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_256 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_257 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_258 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_259 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_260 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_261 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_262 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_263 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_264 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_19_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_20_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_169 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_170 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_171 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_172 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_173 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_174 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_175 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_176 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_177 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_178 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_179 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_180 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_181 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_182 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_183 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_184 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_20_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_TxDbgDataOut_21_SignalGroup
typedef struct
{
  COM_DT_u32_DbgDataOut_313 u32_DbgDataOut_01;
  COM_DT_u32_DbgDataOut_314 u32_DbgDataOut_02;
  COM_DT_u32_DbgDataOut_315 u32_DbgDataOut_03;
  COM_DT_u32_DbgDataOut_316 u32_DbgDataOut_04;
  COM_DT_u32_DbgDataOut_317 u32_DbgDataOut_05;
  COM_DT_u32_DbgDataOut_318 u32_DbgDataOut_06;
  COM_DT_u32_DbgDataOut_319 u32_DbgDataOut_07;
  COM_DT_u32_DbgDataOut_320 u32_DbgDataOut_08;
  COM_DT_u32_DbgDataOut_321 u32_DbgDataOut_09;
  COM_DT_u32_DbgDataOut_322 u32_DbgDataOut_10;
  COM_DT_u32_DbgDataOut_323 u32_DbgDataOut_11;
  COM_DT_u32_DbgDataOut_324 u32_DbgDataOut_12;
  COM_DT_u32_DbgDataOut_325 u32_DbgDataOut_13;
  COM_DT_u32_DbgDataOut_326 u32_DbgDataOut_14;
  COM_DT_u32_DbgDataOut_327 u32_DbgDataOut_15;
  COM_DT_u32_DbgDataOut_328 u32_DbgDataOut_16;
} COM_DT_SG_TxDbgDataOut_21_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_WHL_01_10ms_SignalGroup
typedef struct
{
  COM_DT_WHL_AlvCnt1Val WHL_AlvCnt1Val;
  COM_DT_WHL_Crc1Val WHL_Crc1Val;
  COM_DT_WHL_PlsFLVal WHL_PlsFLVal;
  COM_DT_WHL_PlsFRVal WHL_PlsFRVal;
  COM_DT_WHL_PlsRLVal WHL_PlsRLVal;
  COM_DT_WHL_PlsRRVal WHL_PlsRRVal;
  COM_DT_WHL_SpdFLVal WHL_SpdFLVal;
  COM_DT_WHL_SpdFRVal WHL_SpdFRVal;
  COM_DT_WHL_SpdRLVal WHL_SpdRLVal;
  COM_DT_WHL_SpdRRVal WHL_SpdRRVal;
  COM_DT_WHL_DirFLVal WHL_DirFLVal;
  COM_DT_WHL_DirFRVal WHL_DirFRVal;
  COM_DT_WHL_DirRLVal WHL_DirRLVal;
  COM_DT_WHL_DirRRVal WHL_DirRRVal;
  COM_DT_WHL_SpdCalParmtr WHL_SpdCalParmtr;
} COM_DT_SG_WHL_01_10ms_SignalGroup;

#  define Rte_TypeDef_CoFcaAppVersionInfo_t
typedef struct
{
  uint16 u16_CoFcaAppVersion;
} CoFcaAppVersionInfo_t;

#  define Rte_TypeDef_CoFcaEDR_t
typedef struct
{
  uint16 EgoVeh_Speed;
  uint8 TTC;
  uint16 RelativeVelocity;
  uint16 LongDistance;
  uint16 LatDistance;
} CoFcaEDR_t;

#  define Rte_TypeDef_CoFcaFailSafeInfo_t
typedef struct
{
  uint8 p_EngineRun;
  uint8 p_TrailerMsgTout;
  uint8 p_EcuOverVolt_Fail;
  uint8 p_EcuUndVolt_Fail;
  uint8 p_MalfuncbyCam_Fail;
  uint8 p_EmsMsgTout_Fail;
  uint8 p_TcuMsgTout_Fail;
  uint8 p_EmsSig_Fail;
  uint8 p_HcuVcuFcuMsgTout_Fail;
  uint8 p_EcanBusOff_Fail;
  uint8 p_HcuVcuFcuSig_Fail;
  uint8 p_StrAngTout_Fail;
  uint8 p_EspMsgTout_Fail;
  uint8 p_ABSESPSig_Fail;
  uint8 p_AcuMsgTout_Fail;
  uint8 p_EscVarErr_Fail;
  uint8 p_EscRvsbFCA_Fail;
  uint8 p_TcuSig_Fail;
  uint8 p_IcuMsgTout_Normal_Fail;
  uint8 p_FuncVarErr_Fail;
  uint8 p_StrAngMsg_Fail;
  uint8 p_YrSen_Fail;
  uint8 p_FcaComm_Fail;
  uint8 p_IBUMsgTout_Fail;
  uint8 p_RwsMsgTout_Fail;
  uint8 p_RwsComm_Fail;
  uint8 p_ILCUMsgTout_Fail;
  uint8 p_FrCmrBlockage_Fail;
  uint8 p_FrCmrOvrTemp_Fail;
} CoFcaFailSafeInfo_t;

#  define Rte_TypeDef_CoFcaFrCmrOut_t
typedef struct
{
  uint8 FCA_Equip_FR_CMR;
} CoFcaFrCmrOut_t;

#  define Rte_TypeDef_CoFcaInternalInFromLSS_t
typedef struct
{
  uint8 LSS_TrlrOffDispSta;
} CoFcaInternalInFromLSS_t;

#  define Rte_TypeDef_CoFcaInternalOutputToFca_t
typedef struct
{
  uint8 CoFCA_OnOffEquipSta;
  uint8 CoFCA_SysFlrSta;
  uint8 CoFCA_WrngLvlSta;
  uint8 CoFCA_VehStpReq;
  uint8 CoFCA_StbltActvReq;
  uint8 CoFCA_HydrlcBstAsstReq;
  uint8 CoFCA_DclReqVal;
  uint8 CoFCA_PrefillActvReq;
  uint8 CoFCA_PartialActvReq;
  uint8 CoFCA_FullActvReq;
  uint8 CoFCA_SnstvtyModRetVal;
  uint8 CoFCA_WrngSndSta;
  uint16 CoFCA_RelVel;
  uint8 CoFCA_TimetoCllsn;
  uint8 CoFCA_WrngTrgtDis;
  uint16 EDR_COFCA_RelVel;
  uint8 EDR_COFCA_TimetoCllsn;
  uint16 EDR_COFCA_EgoVehSpeed;
  uint16 EDR_CoFCA_LongDistance;
  uint16 EDR_CoFCA_LatDistance;
} CoFcaInternalOutputToFca_t;

#  define Rte_TypeDef_CoFcaNvmSaveVal_t
typedef struct
{
  uint16 NVM_YawrateOffset;
  uint8 NVM_WarningTime_Guest;
  uint8 NVM_WarningTime_USER1;
  uint8 NVM_WarningTime_USER2;
  uint8 NVM_WarningTime_LastProfileID;
  uint8 Reserved1;
  uint8 Reserved2;
  uint8 Reserved3;
  uint8 Reserved4;
  uint8 Reserved5;
  uint8 Reserved6;
} CoFcaNvmSaveVal_t;

#  define Rte_TypeDef_CoFcaOutput_t
typedef struct
{
  uint8 FCA_FrOnOffEquipSta;
  uint8 FCA_SysFlrSta;
  uint8 FCA_WrngLvlSta;
  uint8 FCA_VehStpReq;
  uint8 FCA_StbltActvReq;
  uint8 FCA_HydrlcBstAsstReq;
  uint8 FCA_DclReqVal;
  uint8 FCA_PrefillActvReq;
  uint8 FCA_PartialActvReq;
  uint8 FCA_FullActvReq;
  uint8 FCA_WarnTimeSta;
  uint8 FCA_WrngSndSta;
  uint16 FCA_RelVel;
  uint8 FCA_TimetoCllsn;
  uint8 FCA_WrngTrgtDis;
  uint8 ADAS_TrlOffStaDisp;
  uint8 FCA_Regulation;
  uint8 ADAS_InhbtOffDispSta;
} CoFcaOutput_t;

#  define Rte_TypeDef_CoFcaUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_FwdSftySymbSta;
  uint8 ux_MV_HostVeh1Sta_FCA;
  uint8 ux_PU_F_Group1_FCA_ADASWarn1_1Sta;
  uint8 ux_PU_F_Group4_FCA_Warn1_1Sta;
  uint8 ux_PU_F_Group7_FCA_FwdSftyFlrSta;
  uint8 ux_FCA_SND_ADASWarn1_1Sta;
  uint8 ux_HPT_StrWhlWarn1Sta_FCA;
  uint8 ux_PU_F_Group4_Trailer_ADASWarn1_1Sta;
} CoFcaUxOutToIvc_t;

#  define Rte_TypeDef_ConstructionArea_t
typedef struct
{
  uint8 CA_ID;
  uint8 CA_Frame_Age;
  uint8 CA_Object_Type;
  uint16 CA_Object_Height;
  uint16 CA_Object_Height_STD;
  uint16 CA_Object_Width;
  uint16 CA_Object_Width_STD;
  uint16 CA_Long_Distance;
  uint16 CA_Long_Distance_STD;
  uint16 CA_Lat_Distance;
  uint16 CA_Lat_Distance_STD;
  uint16 CA_Height;
  uint16 CA_Height_STD;
} ConstructionArea_t;

#  define Rte_TypeDef_Core2AppVersionInfo_t
typedef struct
{
  uint16 HbaAppVersionInfo;
  uint16 IslwAppVersionInfo;
  uint16 LssAppVersionInfo;
  uint16 DawAppVersionInfo;
  uint16 IvcAppVersionInfo;
} Core2AppVersionInfo_t;

#  define Rte_TypeDef_CvdInputData_t
typedef struct
{
  uint16 CvdIn_WheelSpeedFL;
  uint16 CvdIn_WheelSpeedFR;
  uint16 CvdIn_WheelSpeedRL;
  uint16 CvdIn_WheelSpeedRR;
  uint16 CvdIn_VehicleVelocity;
  uint8 CvdIn_VehicleVelocityUnitType;
  uint8 CvdIn_VehicleVelocityValid;
  uint16 CvdIn_SensorYawRate;
  uint8 CvdIn_BrakeLight;
  uint16 CvdIn_BrakePressure;
  uint8 CvdIn_GearboxState;
  uint8 CvdIn_DrivingDirection;
} CvdInputData_t;

#  define Rte_TypeDef_CvdNvmData_t
typedef struct
{
  float32 YrFrontAxleActCal;
  float32 YrRearAxleActCal;
  float32 YrYawRateOffset;
  float32 Reserved_1_f32;
  float32 Reserved_2_f32;
} CvdNvmData_t;

#  define Rte_TypeDef_CvdOutputData_t
typedef struct
{
  uint16 CvdOut_OffsetCompensatedYawRate;
  uint8 CvdOut_OffsetCheckOk;
} CvdOutputData_t;

#  define Rte_TypeDef_Cvd_TrackWidthInput_t
typedef struct
{
  float32 TrackWidth_Front_f32;
  float32 TrackWidth_Rear_f32;
} Cvd_TrackWidthInput_t;

#  define Rte_TypeDef_DawAppVersionInfo_t
typedef struct
{
  uint16 u16_DawAppVersion;
} DawAppVersionInfo_t;

#  define Rte_TypeDef_DawFailInfo_t
typedef struct
{
  uint8 u8_ActiveFault;
  uint8 u8_BlockageFault;
  uint8 u8_TemperatureFault;
} DawFailInfo_t;

#  define Rte_TypeDef_DawFrqNvData_t
typedef struct
{
  sint16 s16_STEERING_ANGLE_BIAS;
  sint16 s16_TORQUE_BIAS;
  uint8 u8_Threshold_Long_Jerk;
  uint8 u8_LVDA_OnOff;
  uint8 u8_Blockage_Full_Status;
  uint8 u8_Blockage_Partial_Status;
  uint8 u8_Blockage_LowVisibility_Status;
  uint8 u8_ProfileVal_Guest;
  uint8 u8_ProfileVal_User1;
  uint8 u8_ProfileVal_User2;
  uint8 u8_ProfileVal_User3;
  uint8 u8_ProfileVal_User4;
  uint8 u8_ProfileVal_User5;
  uint8 u8_ProfileVal_User6;
  uint8 u8_ProfileVal_User7;
  uint8 u8_ProfileVal_User8;
  uint8 u8_ProfileVal_User9;
  uint8 u8_Profile_LastUser;
} DawFrqNvData_t;

#  define Rte_TypeDef_DawInput_t
typedef struct
{
  uint8 u8_LKA_LHLnWrnSta;
  uint8 u8_LKA_RHLnWrnSta;
  uint8 u8_LKA_SysIndReq;
  uint8 u8_ADAS_ActToiSta;
  uint8 u8_HDA_LFA_SymSta;
  uint8 u8_SCC_OpSta;
  uint8 u8_SCC_ObjSta;
  uint8 u8_SCC_InfoDis;
  uint8 u8_SCC_DrvAlrtDis;
} DawInput_t;

#  define Rte_TypeDef_DawOutToLss_t
typedef struct
{
  uint8 u8_Daw_CF_LKA_HandsOff_Snd;
} DawOutToLss_t;

#  define Rte_TypeDef_DawOutput_t
typedef struct
{
  uint8 u8_DAW_Status;
  uint8 u8_DAW_Warn;
  uint8 u8_LVDA_Display;
  uint8 u8_LVDA_USM;
} DawOutput_t;

#  define Rte_TypeDef_DawUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_DAW_SymbSta;
  uint8 ux_PU_F_Group1_DAW_Warn1_2Sta;
  uint8 ux_PU_F_Group4_DAW_WarnSta;
  uint8 ux_PU_F_Group7_DAW_FlrSta;
  uint8 ux_DAW_SND_ADASWarn1_2Sta;
} DawUxOutToIvc_t;

#  define Rte_TypeDef_DeLogicDbgInput_t
typedef struct
{
  uint32 u32_DbgDataIn_01;
  uint32 u32_DbgDataIn_02;
  uint32 u32_DbgDataIn_03;
  uint32 u32_DbgDataIn_04;
  uint32 u32_DbgDataIn_05;
  uint32 u32_DbgDataIn_06;
  uint32 u32_DbgDataIn_07;
  uint32 u32_DbgDataIn_08;
  uint32 u32_DbgDataIn_09;
  uint32 u32_DbgDataIn_10;
  uint32 u32_DbgDataIn_11;
  uint32 u32_DbgDataIn_12;
  uint32 u32_DbgDataIn_13;
  uint32 u32_DbgDataIn_14;
  uint32 u32_DbgDataIn_15;
  uint32 u32_DbgDataIn_16;
} DeLogicDbgInput_t;

#  define Rte_TypeDef_DeLogicDbgOutput_t
typedef struct
{
  uint32 u32_DbgData_01;
  uint32 u32_DbgData_02;
  uint32 u32_DbgData_03;
  uint32 u32_DbgData_04;
  uint32 u32_DbgData_05;
  uint32 u32_DbgData_06;
  uint32 u32_DbgData_07;
  uint32 u32_DbgData_08;
  uint32 u32_DbgData_09;
  uint32 u32_DbgData_10;
  uint32 u32_DbgData_11;
  uint32 u32_DbgData_12;
  uint32 u32_DbgData_13;
  uint32 u32_DbgData_14;
  uint32 u32_DbgData_15;
  uint32 u32_DbgData_16;
} DeLogicDbgOutput_t;

#  define Rte_TypeDef_EDR_IndexData_t
typedef struct
{
  boolean EDR_Enable_bo;
  uint8 EDR_EventIdx_u8;
} EDR_IndexData_t;

#  define Rte_TypeDef_EDR_InputData
typedef struct
{
  uint32 Odometer_u32;
  uint16 VehicleSpeed_u16;
  uint8 TTC_u8;
  uint8 FCA_WrngTrgtDis_u8;
  uint16 Relative_Velocity_u16;
  uint16 Req_Deceleration_u16;
  uint16 MasterCycl_Pressureu16;
  sint16 Steering_Angle_s16;
  uint16 Long_Accel_u16;
  uint8 WarningStatus_u8;
  uint8 FCA_Control_u8;
  uint8 DBS_requested_Info_u8;
  uint8 DBS_Control_u8;
  uint8 FCA_System_Status_u8;
  uint8 FCA_SensorFusion_Status_u8;
  uint8 FCA_Camera_Status_u8;
  uint8 TurnSignal_Left_u8;
  uint8 TurnSignal_Right_u8;
  uint8 Driver_Accel_Braking_Status_u8;
  uint16 Drvr_Accel_PedPressure_u16;
  uint8 SteeringAng_Velocity_u8;
  uint16 Longitudinal_Distance_u16;
  uint16 Lateral_Distance_u16;
} EDR_InputData;

#  define Rte_TypeDef_EOLInfo_t
typedef struct
{
  uint8 u8_EolProjYear;
  uint8 u8_EolSpecGroup;
  uint8 u8_EolDriveType;
  uint8 u8_EolBodyType;
  uint8 u8_EolTransAxle;
  uint8 u8_EolVehicleHeight;
  uint8 u8_EolRWS;
  uint8 u8_EolISG;
  uint8 u8_EolMDPSType;
  uint8 u8_EolLowBeamType;
  uint8 u8_EolSpdOdoUnit;
  uint8 u8_EolExtraRegion;
  uint8 u8_EolFCA;
  uint8 u8_EolLDWLKADAW;
  uint8 u8_EolLFA;
  uint8 u8_EolHBA;
  uint8 u8_EolSpeedLimit;
  uint8 u8_EolHDA;
  uint8 u8_EolSCC;
  uint8 u8_EolNSCC;
  uint8 u8_EolADASDRV;
  uint8 u8_EolBumperType;
  uint8 u8_EolCodingcomplete;
  uint8 U8_Resreved;
} EOLInfo_t;

#  define Rte_TypeDef_EYEQC_SpeedFactorCalParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  float32 SPF_SCA_Mean_X_f32;
  float32 SPF_SCA_Mean_Y_f32;
  float32 SPF_SCA_Cov_XX_f32;
  float32 SPF_SCA_Cov_XY_f32;
  float32 SPF_SCA_Cov_YY_f32;
  float32 SPF_SCA_Weight_f32;
  float32 SPF_SCA_Factor_Mean_f32;
  float32 SPF_SCA_Factor_Variance_f32;
  sint32 SFI_Sca_Revision_s32;
  uint16 Reserved_0_u16;
  uint16 calCRC_u16;
} EYEQC_SpeedFactorCalParams_t;

#  define Rte_TypeDef_EYEQEDR_BBGetHeaderVH_t
typedef struct
{
  uint8 NumberOfHdrs_u8;
  uint8 Reserved1_u8;
  uint8 Reserved2_u8;
  uint8 Reserved3_u8;
  uint32 DataSize_u32;
} EYEQEDR_BBGetHeaderVH_t;

#  define Rte_TypeDef_EYEQEDR_BBGetHeaderVO_t
typedef struct
{
  uint8 EYEQEDR_HdrIdx_au8;
  uint8 EYEQEDR_NumOfFields_au8;
  uint16 EYEQEDR_BlkSize_au16;
  uint32 Reserved1_u32;
  sint32 EYEQEDR_Frameindex_au32;
  sint32 EYEQEDR_TimeStamp_au32;
  sint16 EYEQEDR_Width_au16;
  sint16 EYEQEDR_Height_au16;
  uint8 EYEQEDR_ImageStage_au8;
  uint8 Pad0GetBBHeader_u8;
  uint16 Pad1GetBBHeader_u16;
} EYEQEDR_BBGetHeaderVO_t;

#  define Rte_TypeDef_EYEQMESP_GenInitWheelInfo_t
typedef struct
{
  uint16 WheelRadius_FL_u16;
  uint16 WheelRadius_FR_u16;
  uint16 WheelRadius_RL_u16;
  uint16 WheelRadius_RR_u16;
  uint16 WheelTickSize_FL_u16;
  uint16 WheelTickSize_FR_u16;
  uint16 WheelTickSize_RL_u16;
  uint16 WheelTickSize_RR_u16;
  uint8 WheelRadius_FL_V_u8;
  uint8 WheelRadius_FR_V_u8;
  uint8 WheelRadius_RL_V_u8;
  uint8 WheelRadius_RR_V_u8;
  uint8 WheelTickSize_FL_V_u8;
  uint8 WheelTickSize_FR_V_u8;
  uint8 WheelTickSize_RL_V_u8;
  uint8 WheelTickSize_RR_V_u8;
} EYEQMESP_GenInitWheelInfo_t;

#  define Rte_TypeDef_EYEQMESP_SFRInitParamsNVM_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Reserved_0_u8;
  uint8 MtfvMode_u8;
  uint16 Reserved_1_u16;
  uint16 Reserved_2_u16;
  uint16 CalCRC_u16;
} EYEQMESP_SFRInitParamsNVM_t;

#  define Rte_TypeDef_EYEQMESP_SfrMtfvMode_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Reserved_0_u8;
  uint8 MtfvMode_u8;
  uint16 Reserved_1_u16;
  uint16 Reserved_2_u16;
  uint16 CalCRC_u16;
} EYEQMESP_SfrMtfvMode_t;

#  define Rte_TypeDef_EYEQMESP_TAC2InitParamsNVM_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 TAC_Mode_u8;
  uint8 TAC_BottomLeftSquare_0_u8;
  uint8 TAC_BottomLeftSquare_1_u8;
  uint8 TAC_BottomLeftSquare_2_u8;
  uint16 TAC_TargetInfo_Lat_Distance_0_u16;
  uint16 TAC_TargetInfo_Lat_Distance_1_u16;
  uint16 TAC_TargetInfo_Lat_Distance_2_u16;
  uint16 TAC_TargetInfo_Height_0_u16;
  uint16 TAC_TargetInfo_Height_1_u16;
  uint16 TAC_TargetInfo_Height_2_u16;
  uint16 TAC_Camera_Height_u16;
  uint16 TAC_Camera_Z_u16;
  uint8 TAC_Max_Horizon_u8;
  uint8 TAC_Min_Horizon_u8;
  uint8 TAC_Max_Yaw_u8;
  uint8 TAC_Min_Yaw_u8;
  uint8 TAC_Max_RollAngle_u8;
  uint8 TAC_Bottom_u8;
  uint8 TAC_Targets_Num_u8;
  uint8 TAC_Reserved0_u8;
  uint16 TAC_SquareSideSize_u16;
  uint16 TAC_Reserved1_u16;
  uint8 TAC_Mode_V_u8;
  uint8 TAC_BottomLeftSquare_0_V_u8;
  uint8 TAC_BottomLeftSquare_1_V_u8;
  uint8 TAC_BottomLeftSquare_2_V_u8;
  uint8 TAC_TargetInfo_Lat_Distance_0_V_u8;
  uint8 TAC_TargetInfo_Lat_Distance_1_V_u8;
  uint8 TAC_TargetInfo_Lat_Distance_2_V_u8;
  uint8 TAC_TargetInfo_Height_0_V_u8;
  uint8 TAC_TargetInfo_Height_1_V_u8;
  uint8 TAC_TargetInfo_Height_2_V_u8;
  uint8 TAC_Camera_Height_V_u8;
  uint8 TAC_Camera_Z_V_u8;
  uint8 TAC_Max_Horizon_V_u8;
  uint8 TAC_Min_Horizon_V_u8;
  uint8 TAC_Max_Yaw_V_u8;
  uint8 TAC_Min_Yaw_V_u8;
  uint8 TAC_Max_RollAngle_V_u8;
  uint8 TAC_SquareSideSize_V_u8;
  uint8 TAC_Bottom_V_u8;
  uint8 TAC_Targets_Num_V_u8;
  uint8 TAC_Camera_Z_Close_u8;
  uint8 TAC_SquareSideSize_Close_u8;
  uint8 Tac2_Num_Squares_Row_u8;
  uint8 Tac2_Num_Squares_Col_u8;
  uint8 TAC_Camera_Z_Close_V_u8;
  uint8 TAC_SquareSideSize_Close_V_u8;
  uint8 Tac2_Num_Squares_Row_V_u8;
  uint8 Tac2_Num_Squares_Col_V_u8;
  uint16 TAC_Reserved2_u16;
  uint16 CalCRC_u16;
} EYEQMESP_TAC2InitParamsNVM_t;

#  define Rte_TypeDef_EYEQP_EyeQResetTracker_t
typedef struct
{
  uint16 ErrCnt_u16;
  uint8 ErrStatus_u8;
  uint8 ReportErrStatus_u8;
} EYEQP_EyeQResetTracker_t;

#  define Rte_TypeDef_EYEQTHSD_ThermalParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 EyeQThermalStrategyEnabled_u8;
  uint8 ThermistorHysteresisCheckEnable_u8;
  uint8 ThermalDiagnosticDebounceLimit_u8;
  uint8 MainImagerDieCheckEnable_u8;
  uint8 FishEyeImagerDieCheckEnable_u8;
  uint8 NarrowImagerDieCheckEnable_u8;
  uint8 EyeQDieCheckEnable_u8;
  uint8 DDRDieCheckEnable_u8;
  uint8 MainImagerThermistorCheckEnable_u8;
  uint8 FishEyeImagerThermistorCheckEnable_u8;
  uint8 NarrowImagerThermistorCheckEnable_u8;
  uint8 EyeQThermistorCheckEnable_u8;
  uint8 DDRThermistorCheckEnable_u8;
  uint8 AurixThermistorCheckEnable_u8;
  sint8 MainImagerDieHighUpperThreshold_s8;
  sint8 FishEyeImagerDieHighUpperThreshold_s8;
  sint8 NarrowImagerDieHighUpperThreshold_s8;
  sint8 MainImagerDieLowLowerThreshold_s8;
  sint8 FishEyeImagerDieLowLowerThreshold_s8;
  sint8 NarrowImagerDieLowLowerThreshold_s8;
  sint16 EyeQDieHighUpperThreshold_s16;
  sint16 EyeQDieLowLowerThreshold_s16;
  uint16 AurixDie1HighUpperThreshold_u16;
  uint16 AurixDie1HighLowerThreshold_u16;
  uint16 AurixDie2HighUpperThreshold_u16;
  uint16 AurixDie2HighLowerThreshold_u16;
  uint16 AurixDie1LowLowerThreshold_u16;
  uint16 AurixDie2LowLowerThreshold_u16;
  uint16 MainImagerThermistorHighUpperThreshold_u16;
  uint16 MainImagerThermistorHighLowerThreshold_u16;
  uint16 FishEyeImagerThermistorHighUpperThreshold_u16;
  uint16 FishEyeImagerThermistorHighLowerThreshold_u16;
  uint16 NarrowImagerThermistorHighUpperThreshold_u16;
  uint16 NarrowImagerThermistorHighLowerThreshold_u16;
  uint16 EyeQThermistorHighUpperThreshold_u16;
  uint16 EyeQThermistorHighLowerThreshold_u16;
  uint16 DDRThermistorHighUpperThreshold_u16;
  uint16 DDRThermistorHighLowerThreshold_u16;
  uint16 AurixThermistorHighUpperThreshold_u16;
  uint16 AurixThermistorHighLowerThreshold_u16;
  uint16 SensorDiagMainImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagMainImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagFishEyeImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagFishEyeImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagNarrowImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagNarrowImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagEyeQThermistorUpperThreshold_u16;
  uint16 SensorDiagEyeQThermistorLowerThreshold_u16;
  uint16 SensorDiagDDRThermistorUpperThreshold_u16;
  uint16 SensorDiagDDRThermistorLowerThreshold_u16;
  uint16 SensorDiagAurixThermistorUpperThreshold_u16;
  uint16 SensorDiagAurixThermistorLowerThreshold_u16;
  uint16 Reserved0_u16;
  uint16 calCRC_u16;
} EYEQTHSD_ThermalParams_t;

#  define Rte_TypeDef_EYEQTHSD_ThermalShutdownParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 EyeQThermalStrategyEnabled_u8;
  uint8 ThermistorHysteresisCheckEnable_u8;
  uint8 ThermalDiagnosticDebounceLimit_u8;
  uint8 MainImagerDieCheckEnable_u8;
  uint8 FishEyeImagerDieCheckEnable_u8;
  uint8 NarrowImagerDieCheckEnable_u8;
  uint8 EyeQDieCheckEnable_u8;
  uint8 DDRDieCheckEnable_u8;
  uint8 MainImagerThermistorCheckEnable_u8;
  uint8 FishEyeImagerThermistorCheckEnable_u8;
  uint8 NarrowImagerThermistorCheckEnable_u8;
  uint8 EyeQThermistorCheckEnable_u8;
  uint8 DDRThermistorCheckEnable_u8;
  uint8 AurixThermistorCheckEnable_u8;
  sint8 MainImagerDieHighUpperThreshold_s8;
  sint8 FishEyeImagerDieHighUpperThreshold_s8;
  sint8 NarrowImagerDieHighUpperThreshold_s8;
  sint8 MainImagerDieLowLowerThreshold_s8;
  sint8 FishEyeImagerDieLowLowerThreshold_s8;
  sint8 NarrowImagerDieLowLowerThreshold_s8;
  sint16 EyeQDieHighUpperThreshold_s16;
  sint16 EyeQDieLowLowerThreshold_s16;
  uint16 AurixDie1HighUpperThreshold_u16;
  uint16 AurixDie1HighLowerThreshold_u16;
  uint16 AurixDie2HighUpperThreshold_u16;
  uint16 AurixDie2HighLowerThreshold_u16;
  uint16 AurixDie1LowLowerThreshold_u16;
  uint16 AurixDie2LowLowerThreshold_u16;
  uint16 MainImagerThermistorHighUpperThreshold_u16;
  uint16 MainImagerThermistorHighLowerThreshold_u16;
  uint16 FishEyeImagerThermistorHighUpperThreshold_u16;
  uint16 FishEyeImagerThermistorHighLowerThreshold_u16;
  uint16 NarrowImagerThermistorHighUpperThreshold_u16;
  uint16 NarrowImagerThermistorHighLowerThreshold_u16;
  uint16 EyeQThermistorHighUpperThreshold_u16;
  uint16 EyeQThermistorHighLowerThreshold_u16;
  uint16 DDRThermistorHighUpperThreshold_u16;
  uint16 DDRThermistorHighLowerThreshold_u16;
  uint16 AurixThermistorHighUpperThreshold_u16;
  uint16 AurixThermistorHighLowerThreshold_u16;
  uint16 SensorDiagMainImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagMainImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagFishEyeImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagFishEyeImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagNarrowImagerThermistorUpperThreshold_u16;
  uint16 SensorDiagNarrowImagerThermistorLowerThreshold_u16;
  uint16 SensorDiagEyeQThermistorUpperThreshold_u16;
  uint16 SensorDiagEyeQThermistorLowerThreshold_u16;
  uint16 SensorDiagDDRThermistorUpperThreshold_u16;
  uint16 SensorDiagDDRThermistorLowerThreshold_u16;
  uint16 SensorDiagAurixThermistorUpperThreshold_u16;
  uint16 SensorDiagAurixThermistorLowerThreshold_u16;
  uint16 MainImagerThermistorTemparature_u16;
  uint16 FishEyeImagerThermistorTemparature_u16;
  uint16 NarrowImagerThermistorTemparature_u16;
  uint16 AurixThermistorTemparature_u16;
  uint16 EyeQThermistorTemparature_u16;
  uint16 DDRThermistorTemparature_u16;
  uint16 AurixDie1Temparature_u16;
  uint16 AurixDie2Temparature_u16;
  sint16 EyeQDieTemparature1_s16;
  sint16 EyeQDieTemparature2_s16;
  sint8 MainImagerDieTemparature1_s8;
  sint8 MainImagerDieTemparature2_s8;
  sint8 FishEyeImagerDieTemparature1_s8;
  sint8 FishEyeImagerDieTemparature2_s8;
  sint8 NarrowImagerDieTemparature1_s8;
  sint8 NarrowImagerDieTemparature2_s8;
  uint8 DDRDieTemparature_u8;
  uint8 Reserved1_u8;
  uint32 ThermalShutdownCounter_u32;
  uint32 Reserved2_u32;
  uint16 Reserved0_u16;
  uint16 calCRC_u16;
} EYEQTHSD_ThermalShutdownParams_t;

#  define Rte_TypeDef_EYEQTHSD_ThermalShutdownValues_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint16 MainImagerThermistorTemparature_u16;
  uint16 FishEyeImagerThermistorTemparature_u16;
  uint16 NarrowImagerThermistorTemparature_u16;
  uint16 AurixThermistorTemparature_u16;
  uint16 EyeQThermistorTemparature_u16;
  uint16 DDRThermistorTemparature_u16;
  uint16 AurixDie1Temparature_u16;
  uint16 AurixDie2Temparature_u16;
  sint16 EyeQDieTemparature1_s16;
  sint16 EyeQDieTemparature2_s16;
  sint8 MainImagerDieTemparature1_s8;
  sint8 MainImagerDieTemparature2_s8;
  sint8 FishEyeImagerDieTemparature1_s8;
  sint8 FishEyeImagerDieTemparature2_s8;
  sint8 NarrowImagerDieTemparature1_s8;
  sint8 NarrowImagerDieTemparature2_s8;
  uint8 DDRDieTemparature_u8;
  uint8 Reserved1_u8;
  uint32 ThermalShutdownCounter_u32;
  uint32 Reserved2_u32;
  uint16 Reserved0_u16;
  uint16 calCRC_u16;
} EYEQTHSD_ThermalShutdownValues_t;

#  define Rte_TypeDef_EYEQ_FailSafeStatus_t
typedef struct
{
  uint16 FeatureDisableStatus_u16;
  uint16 ACCFeatureDisableReason_u16;
  uint16 AEBVDFeatureDisableReason_u16;
  uint16 FCWVDFeatureDisableReason_u16;
  uint16 AEBPDFeatureDisableReason_u16;
  uint16 FCWPDFeatureDisableReason_u16;
  uint16 LKALDWLCFeatureDisableReason_u16;
  uint16 FREESPACEFeatureDisableReason_u16;
  uint16 HLBGFHBFeatureDisableReason_u16;
  uint16 TSRFeatureDisableReason_u16;
  uint16 ROADFeatureDisableReason_u16;
  uint16 HEATERFeatureDisableReason_u16;
  uint16 Reserved_1_u16;
  uint16 FsCRC_u16;
} EYEQ_FailSafeStatus_t;

#  define Rte_TypeDef_EyeQC_DriveSide_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 CalStatus_u8;
  uint8 DrivingSide_u8;
  uint16 calCRC_u16;
} EyeQC_DriveSide_t;

#  define Rte_TypeDef_EyeQC_RegionCode_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 CalStatus_u8;
  uint8 RegionCode_u8;
  uint16 calCRC_u16;
} EyeQC_RegionCode_t;

#  define Rte_TypeDef_EyeQEdrEnhd_BbQueryReplyParams_t
typedef struct
{
  uint8 FormatStatus_u8;
  uint8 InProcess_u8;
  uint8 AllImagesExist_u8;
  uint8 MetaDataExist_u8;
  uint32 BBCRC_u32;
  uint32 TotalClipSize_u32;
  uint32 MetaDataSize_u32;
  uint32 OriginalImageSize_u32;
  uint32 NumOfImagesInBB_u32;
  uint32 preImagesNumber_u32;
  uint32 postImagesNumber_u32;
  uint32 appendImagesNumber_u32;
} EyeQEdrEnhd_BbQueryReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_EventQueryReplyParams_t
typedef struct
{
  uint32 RequestedPreFrameNum_u32;
  uint32 RequestedPostFrameNum_u32;
  uint32 ActualPreFrameNum_u32;
  uint32 ActualLoggedImagesNum_u32;
  uint32 ActualDumpImagesNum_u32;
  uint32 AppendImageNum_u32;
  uint32 PreEventSkipped_u32;
  uint32 PostEventSkipped_u32;
  uint32 MappedToBB_u32;
  uint32 MetadataSize_u32;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  uint32 Reserved_3_u32;
  uint32 Reserved_4_u32;
  uint32 Reserved_5_u32;
  uint32 Reserved_6_u32;
  uint32 Reserved_7_u32;
  uint32 Reserved_8_u32;
} EyeQEdrEnhd_EventQueryReplyParams_t;

#  define Rte_TypeDef_EyeQFOTA_Status_t
typedef struct
{
  uint32 StatusSize_u32;
  uint32 OtaState_u32;
  uint32 OtaType_u32;
  uint32 LastMiniblockReceived_u32;
  uint32 MaxMiniblockNum_u32;
  uint32 MiniblockBufOffset_u32;
  uint32 FlashSectorSize_u32;
  uint32 FlashChipSelectForOTA_u32;
  uint32 StartAddress_u32;
  uint32 MaxOTASize_u32;
  uint32 LastError_u32;
} EyeQFOTA_Status_t;

#  define Rte_TypeDef_EyeQImgSrvc_CloneImageResponse_t
typedef struct
{
  uint32 Ret_u32;
  uint32 FrameIndex_u32;
  uint32 LineLength_u32;
  uint32 NumOfLines_u32;
  uint32 ImageSize_u32;
  uint8 Options_u8;
  uint8 ImageType_u8;
  uint32 CRC_u32;
  uint32 Reserved1_u32;
  uint32 Reserved2_u32;
  uint32 Reserved3_u32;
  uint32 Reserved4_u32;
} EyeQImgSrvc_CloneImageResponse_t;

#  define Rte_TypeDef_EyeQ_SetNextBootMode_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 CalStatus_u8;
  uint8 SetNextBootMode_u8;
  uint8 ExtrinsicCalStatus_u8;
  uint8 Reserved1_u8;
  uint16 Reserved2_u16;
  uint16 calCRC_u16;
} EyeQ_SetNextBootMode_t;

#  define Rte_TypeDef_EyeQ_SetNextManualExposureVal_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Reserved0_u8;
  uint8 Reserved1_u8;
  uint16 EyeQ_SetNextManualExposureVal_u16;
  uint16 Reserved2_u16;
  uint16 calCRC_u16;
} EyeQ_SetNextManualExposureVal_t;

#  define Rte_TypeDef_FCF_VD_t
typedef struct
{
  uint16 FCF_VD_Alert;
  uint8 FCF_VD_ID;
  uint16 FCF_VD_AEB_Supp;
  uint16 FCF_VD_FCW_Supp;
  uint8 FCF_VD_Set_Type;
  uint16 FCF_VD_TTC_Thresh;
} FCF_VD_t;

#  define Rte_TypeDef_FCF_VRU_t
typedef struct
{
  uint16 FCF_VRU_Alert_L;
  uint8 FCF_VRU_PED_ID_L;
  uint8 FCF_VRU_Suppress_L;
  uint8 FCF_VRU_Set_Type_L;
  boolean FCF_VRU_Curr_In_Path_L;
  boolean FCF_VRU_Pred_In_Path_L;
  uint16 FCF_VRU_TTC_L;
  uint16 FCF_VRU_TTC_Thresh_L;
} FCF_VRU_t;

#  define Rte_TypeDef_FailSafe_t
typedef struct
{
  uint32 FS_CRC;
  uint8 FS_Camera_ID;
  boolean FS_Free_Sight;
  uint8 FS_Splashes;
  uint8 FS_Sun_Ray;
  uint8 FS_Low_Sun;
  uint8 FS_Blur_Image;
  uint8 FS_Partial_Blockage;
  uint8 FS_Full_Blockage;
  uint8 FS_Frozen_Windshield_Lens;
  uint8 FS_Out_Of_Focus;
  uint8 FS_C2C_Out_Of_Calib;
} FailSafe_t;

#  define Rte_TypeDef_FcaAppVersionInfo_t
typedef struct
{
  uint16 u16_FcaAppVersion;
} FcaAppVersionInfo_t;

#  define Rte_TypeDef_FcaEDR_t
typedef struct
{
  uint16 EgoVeh_Speed;
  uint8 TTC;
  uint16 RelativeVelocity;
  uint16 LongDistance;
  uint16 LatDistance;
} FcaEDR_t;

#  define Rte_TypeDef_FcaEngRdrFailSafeInfo_t
typedef struct
{
  uint8 r_RadarInitialBlockage;
  uint8 r_RadarNormalBlockage;
  uint8 r_RadarHighVolt;
  uint8 r_RadarLowVolt;
  uint8 r_EOL_Alignment;
  uint8 r_Drv_Alignment;
  uint8 r_MalfuncbyRadar;
  uint8 r_RadarHighTemp;
} FcaEngRdrFailSafeInfo_t;

#  define Rte_TypeDef_FcaFailSafeInfoTrailerMsgTout_t
typedef struct
{
  uint8 u8_TrailerMsgTout;
} FcaFailSafeInfoTrailerMsgTout_t;

#  define Rte_TypeDef_FcaFailSafeInfo_t
typedef struct
{
  uint8 p_EngineRun;
  uint8 p_TrailerMsgTout;
  uint8 p_EcuOverVolt_Fail;
  uint8 p_EcuUndVolt_Fail;
  uint8 p_MalfuncbyCam_Fail;
  uint8 p_EmsMsgTout_Fail;
  uint8 p_TcuMsgTout_Fail;
  uint8 p_EmsSig_Fail;
  uint8 p_HcuVcuFcuMsgTout_Fail;
  uint8 p_EcanBusOff_Fail;
  uint8 p_HcuVcuFcuSig_Fail;
  uint8 p_StrAngTout_Fail;
  uint8 p_EspMsgTout_Fail;
  uint8 p_ABSESPSig_Fail;
  uint8 p_AcuMsgTout_Fail;
  uint8 p_EscVarErr_Fail;
  uint8 p_EscRvsbFCA_Fail;
  uint8 p_TcuSig_Fail;
  uint8 p_FrRdr_Fail;
  uint8 p_IcuMsgTout_Normal_Fail;
  uint8 p_IcuMsgTout_JTFcn_Fail;
  uint8 p_FuncVarErr_Fail;
  uint8 p_StrAngMsg_Fail;
  uint8 p_YrSen_Fail;
  uint8 p_FcaComm_Fail;
  uint8 p_IBUMsgTout_Fail;
  uint8 p_RwsMsgTout_Fail;
  uint8 p_RwsComm_Fail;
  uint8 p_MFSWTout_Fail;
  uint8 p_ILCUMsgTout_Fail;
  uint8 p_FrRdrOvrTemp_Fail;
  uint8 p_FrRdrBlockage_Fail;
  uint8 p_FrRdrNotFoundTarget_Fail;
  uint8 p_FrRdrInitBlockage_Fail;
  uint8 p_FrCmrBlockage_Fail;
  uint8 p_FrCmrOvrTemp_Fail;
} FcaFailSafeInfo_t;

#  define Rte_TypeDef_FcaFrCmrOut_t
typedef struct
{
  uint8 FCA_Equip_FR_CMR;
} FcaFrCmrOut_t;

#  define Rte_TypeDef_FcaInput_t
typedef struct
{
  uint8 SCC_InfoDis;
  uint8 SCC_OpSta;
} FcaInput_t;

#  define Rte_TypeDef_FcaInternalInFromCOFCA_t
typedef struct
{
  uint8 CoFCA_FCA_FrOnOffEquipSta;
  uint8 CoFCA_FCA_SysFlrSta;
  uint8 CoFCA_FCA_WrngLvlSta;
  uint8 CoFCA_FCA_VehStpReq;
  uint8 CoFCA_FCA_StbltActvReq;
  uint8 CoFCA_FCA_HydrlcBstAsstReq;
  uint8 CoFCA_FCA_DclReqVal;
  uint8 CoFCA_FCA_PrefillActvReq;
  uint8 CoFCA_FCA_PartialActvReq;
  uint8 CoFCA_FCA_FullActvReq;
  uint8 CoFCA_FCA_WarnTimeSta;
  uint8 CoFCA_FCA_WrngSndSta;
  uint16 CoFCA_FCA_RelVel;
  uint8 CoFCA_FCA_TimetoCllsn;
  uint8 CoFCA_FCA_WrngTrgtDis;
  uint8 CoFCA_ADAS_TrlOffStaDisp;
  uint8 CoFCA_FCA_Regulation;
  uint8 CoFCA_ADAS_InhbtOffDispSta;
  uint16 EDR_COFCA_RelVel;
  uint8 EDR_COFCA_TimetoCllsn;
  uint16 EDR_COFCA_EgoVehSpeed;
  uint16 EDR_COFCA_LongDistance;
  uint16 EDR_COFCA_LatDistance;
} FcaInternalInFromCOFCA_t;

#  define Rte_TypeDef_FcaInternalInFromLSS_t
typedef struct
{
  uint8 LSS_TrlrOffDispSta;
} FcaInternalInFromLSS_t;

#  define Rte_TypeDef_FcaNvmSaveVal_t
typedef struct
{
  uint16 NVM_YawrateOffset;
  uint8 NVM_WarningTime_Guest;
  uint8 NVM_WarningTime_USER1;
  uint8 NVM_WarningTime_USER2;
  uint8 NVM_WarningTime_LastProfileID;
  uint8 Reserved1;
  uint8 Reserved2;
  uint8 Reserved3;
  uint8 Reserved4;
  uint8 Reserved5;
  uint8 Reserved6;
} FcaNvmSaveVal_t;

#  define Rte_TypeDef_FcaOutput_t
typedef struct
{
  uint8 FCA_FrOnOffEquipSta;
  uint8 FCA_SysFlrSta;
  uint8 FCA_WrngLvlSta;
  uint8 FCA_VehStpReq;
  uint8 FCA_StbltActvReq;
  uint8 FCA_HydrlcBstAsstReq;
  uint8 FCA_DclReqVal;
  uint8 FCA_PrefillActvReq;
  uint8 FCA_PartialActvReq;
  uint8 FCA_FullActvReq;
  uint8 FCA_WarnTimeSta;
  uint8 FCA_WrngSndSta;
  uint16 FCA_RelVel;
  uint8 FCA_TimetoCllsn;
  uint8 FCA_WrngTrgtDis;
  uint8 ADAS_TrlOffStaDisp;
  uint8 FCA_Regulation;
  uint8 ADAS_InhbtOffDispSta;
} FcaOutput_t;

#  define Rte_TypeDef_FcaUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_FwdSftySymbSta;
  uint8 ux_MV_HostVeh1Sta_FCA;
  uint8 ux_PU_F_Group1_FCA_ADASWarn1_1Sta;
  uint8 ux_PU_F_Group4_FCA_Warn1_1Sta;
  uint8 ux_PU_F_Group7_FCA_FwdSftyFlrSta;
  uint8 ux_FCA_SND_ADASWarn1_1Sta;
  uint8 ux_HPT_StrWhlWarn1Sta_FCA;
  uint8 ux_PU_F_Group4_Trailer_ADASWarn1_1Sta;
} FcaUxOutToIvc_t;

#  define Rte_TypeDef_FcfVd_t
typedef struct
{
  uint32 FCF_VD_Dyn_CRC;
  uint16 FCF_VD_Dyn_Alert;
  uint8 FCF_VD_Dyn_ID;
  uint16 FCF_VD_Dyn_AEB_Supp;
  uint32 FCF_VD_Dyn_FCW_Supp;
  uint8 FCF_VD_Dyn_Set_Type;
  uint16 FCF_VD_Dyn_TTC_Thresh;
  uint16 FCF_VD_Dyn_TTC;
} FcfVd_t;

#  define Rte_TypeDef_FcfVru_t
typedef struct
{
  uint32 FCF_VRU_Dyn_CRC;
  uint16 FCF_VRU_Dyn_Alert;
  uint8 FCF_VRU_Dyn_PED_ID;
  uint8 FCF_VRU_Dyn_Suppress;
  uint8 FCF_VRU_Dyn_Set_Type;
  boolean FCF_VRU_Dyn_Curr_In_Path;
  boolean FCF_VRU_Dyn_Pred_In_Path;
  uint16 FCF_VRU_Dyn_TTC;
  uint16 FCF_VRU_Dyn_TTC_Thresh;
} FcfVru_t;

#  define Rte_TypeDef_FeatureConfig_t
typedef struct
{
  uint8 u8_CANDbgMsg;
  uint8 u8_CANDbgMode;
  uint8 u8_reserved0;
  uint8 u8_reserved1;
  boolean b_HBA_TestMode;
  boolean b_ISLA_TestMode;
  uint8 u8_reserved3;
  uint8 u8_reserved4;
} FeatureConfig_t;

#  define Rte_TypeDef_FeatureVehicle_t
typedef struct
{
  uint16 u16_NVM_r_VehicleWidth;
  uint8 u8_reserved0;
  uint8 u8_reserved1;
  uint8 u8_CAN_Type;
  uint8 u8_VehicleType;
  uint8 u8_reserved2;
  uint8 u8_reserved3;
} FeatureVehicle_t;

#  define Rte_TypeDef_FrCmrHdrCA_t
typedef struct
{
  uint8 CA_Protocol_Version;
  uint8 CA_Sync_ID;
  uint8 CA_Region_Code;
  uint8 CA_Objects_Count;
} FrCmrHdrCA_t;

#  define Rte_TypeDef_FrCmrHdrFS_t
typedef struct
{
  uint32 FS_Header_CRC;
  uint8 FS_Protocol_Version;
  uint8 FS_Sync_ID;
  uint8 FS_Cameras_Number;
  uint8 FS_TSR_Out_OF_Calib;
  uint8 FS_Out_Of_Calib;
  uint16 FS_Impacted_Technologies;
  uint8 FS_Rain;
  uint8 FS_Fog;
  uint8 FS_C2W_OOR;
} FrCmrHdrFS_t;

#  define Rte_TypeDef_FrCmrHdrFcfVd_t
typedef struct
{
  uint8 FCF_VD_Dyn_Protocol_Version;
  uint8 FCF_VD_Dyn_SyncID;
  uint32 FCF_VD_Dyn_Header_CRC;
  uint16 FCF_VD_Dyn_AEB_Supp_FCV;
  uint16 FCF_VD_Dyn_Alert_FCV;
  uint8 FCF_VD_Dyn_ID_FCV;
  boolean FCF_VD_Dyn_HeadWay_Alert;
  uint16 FCF_VD_Dyn_HeadWay_Distance;
  uint16 FCF_VD_Dyn_HW_Supp_Reason;
} FrCmrHdrFcfVd_t;

#  define Rte_TypeDef_FrCmrHdrFcfVru_t
typedef struct
{
  uint8 FCF_VRU_Dyn_Protocol_Version;
  uint8 FCF_VRU_Dyn_SyncID;
} FrCmrHdrFcfVru_t;

#  define Rte_TypeDef_FrCmrHdrLDW_t
typedef struct
{
  uint8 LDW_Protocol_Version;
  uint8 LDW_Sync_ID;
} FrCmrHdrLDW_t;

#  define Rte_TypeDef_FrCmrHdrLnAdj_t
typedef struct
{
  uint8 LA_Protocol_Version;
  uint8 LA_Sync_ID;
  uint8 LA_Adjacent_Count;
} FrCmrHdrLnAdj_t;

#  define Rte_TypeDef_FrCmrHdrLnAppl_t
typedef struct
{
  uint8 LAP_Protocol_Version;
  uint8 LAP_Sync_ID;
  boolean LAP_Is_Construction_Area;
  boolean LAP_INTP_Available;
  uint8 LAP_INTP_Count;
  boolean LAP_Exit_Merge_Available;
  boolean LAP_Is_Highway_Merge_Left;
  boolean LAP_Is_Highway_Merge_Right;
  boolean LAP_Is_Highway_Exit_Left;
  boolean LAP_Is_Highway_Exit_Right;
  boolean LAP_Vertical_Surface_Available;
  uint16 LAP_Vertical_Surface_C0;
  uint16 LAP_Vertical_Surface_C1;
  uint16 LAP_Vertical_Surface_C2;
  uint32 LAP_Vertical_Surface_C3;
  uint16 LAP_Vertical_Surface_VR_End;
  uint32 LAP_Path_Pred_CRC;
  boolean LAP_Path_Pred_Available;
  boolean LAP_Path_Pred_First_Valid;
  boolean LAP_Path_Pred_Second_Valid;
  uint16 LAP_Path_Pred_Half_Width;
  uint8 LAP_Path_Pred_Conf;
  uint8 LAP_Is_Triggered_SDM_Model;
  uint16 LAP_Path_Pred_First_VR_End;
  uint16 LAP_Path_Pred_second_VR_End;
  uint32 LAP_Path_Pred_First_C0;
  uint32 LAP_Path_Pred_First_C1;
  uint32 LAP_Path_Pred_First_C2;
  uint32 LAP_Path_Pred_First_C3;
  uint32 LAP_Path_Pred_Second_C0;
  uint32 LAP_Path_Pred_Second_C1;
  uint32 LAP_Path_Pred_Second_C2;
  uint32 LAP_Path_Pred_Second_C3;
} FrCmrHdrLnAppl_t;

#  define Rte_TypeDef_FrCmrHdrLnHost_t
typedef struct
{
  uint8 LH_Protocol_Version;
  uint8 LH_Sync_ID;
  uint8 LH_Lanes_Count;
  uint16 LH_Estimated_Width;
} FrCmrHdrLnHost_t;

#  define Rte_TypeDef_FrCmrHdrLnRdEdg_t
typedef struct
{
  uint32 LRE_Header_CRC;
  uint8 LRE_Protocol_Version;
  uint8 LRE_Sync_ID;
  uint8 LRE_Count;
} FrCmrHdrLnRdEdg_t;

#  define Rte_TypeDef_FrCmrHdrObj_t
typedef struct
{
  uint32 OBJ_Header_CRC;
  uint8 OBJ_Protocol_Version;
  uint8 OBJ_Sync_ID;
  uint8 OBJ_VRU_Count;
  uint8 OBJ_VD_Count;
  uint8 OBJ_General_OBJ_Count;
  uint8 OBJ_Animal_Count;
  uint8 OBJ_VD_NIV_Left;
  uint8 OBJ_VD_NIV_Right;
  uint8 OBJ_VD_CIPV_ID;
  uint8 OBJ_VD_CIPV_Lost;
  uint8 OBJ_VD_Allow_Acc;
  boolean OBJ_Is_Blocked_Left;
  boolean OBJ_Is_Blocked_Right;
} FrCmrHdrObj_t;

#  define Rte_TypeDef_HbaAppVersionInfo_t
typedef struct
{
  uint16 u16_HbaAppVersion;
} HbaAppVersionInfo_t;

#  define Rte_TypeDef_HbaFailInfo_t
typedef struct
{
  uint8 u8_ActiveFault;
  uint8 u8_BlockageFault;
  uint8 u8_TemperatureFault;
} HbaFailInfo_t;

#  define Rte_TypeDef_HbaFrqNvData_t
typedef struct
{
  uint8 u8_HBA_OnOff;
  uint8 u8_Blockage_Full_Status;
  uint8 u8_Blockage_Partial_Status;
  uint8 u8_Blockage_LowVisibility_Status;
  uint8 u8_ProfileVal_Guest;
  uint8 u8_ProfileVal_User1;
  uint8 u8_ProfileVal_User2;
  uint8 u8_ProfileVal_User3;
  uint8 u8_ProfileVal_User4;
  uint8 u8_ProfileVal_User5;
  uint8 u8_ProfileVal_User6;
  uint8 u8_ProfileVal_User7;
  uint8 u8_ProfileVal_User8;
  uint8 u8_ProfileVal_User9;
  uint8 u8_Profile_LastUser;
  uint8 Reserved1;
} HbaFrqNvData_t;

#  define Rte_TypeDef_HbaInput_t
typedef struct
{
  uint8 u8_HLB_Inactive_Reason;
  uint32 u32_HLB_Reason;
  uint8 u8_HLB_Decision;
  uint8 u8_HLB_Running_Mode;
} HbaInput_t;

#  define Rte_TypeDef_HbaObjectInfo_t
typedef struct
{
  uint16 u16_LSV_Distance;
  uint8 u8_LSV_Type;
} HbaObjectInfo_t;

#  define Rte_TypeDef_HbaOccNvData_t
typedef struct
{
  uint16 u16_HBA_MIDDLE_EAST_OFF_DIST;
  uint16 u16_HBA_MIDDLE_EAST_ON_DELAY_TIME;
  uint16 u16_Cam_Blockage_Time;
  uint8 u8_HBA_START_VS;
  uint8 u8_HBA_END_VS;
  uint8 u8_HBA_START_VS_US;
  uint8 u8_HBA_END_VS_US;
  uint8 u8_HBA_START_VS_LIMIT;
  uint8 u8_HBA_END_VS_LIMIT;
  uint8 u8_HBA_START_VS_LIMIT_US;
  uint8 u8_HBA_END_VS_LIMIT_US;
  uint8 Reserved1;
  uint8 Reserved2;
} HbaOccNvData_t;

#  define Rte_TypeDef_HbaOutput_t
typedef struct
{
  uint8 u8_HBA_Lamp;
  uint8 u8_HBA_SysState;
  uint8 u8_HBA_Opt;
  uint8 u8_HBA_OptUSM;
} HbaOutput_t;

#  define Rte_TypeDef_HbaUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_HBA_SymbSta;
  uint8 ux_PU_F_Group7_HBA_FlrSta;
} HbaUxOutToIvc_t;

#  define Rte_TypeDef_IoHwAb_HeaterInfo_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint32 HeaterCounter_u32;
  uint8 HeaterStatus_u8;
  uint8 Reserved_1_u8;
  uint16 Reserved_2_u16;
  uint16 Reserved_3_u16;
  uint16 calCRC_u16;
} IoHwAb_HeaterInfo_t;

#  define Rte_TypeDef_IsMsgVaildObjtAEBStatus_t
typedef struct
{
  uint8 VDStatus_u8;
  uint8 VRUStatus_u8;
  uint8 ObjtStatus_u8;
} IsMsgVaildObjtAEBStatus_t;

#  define Rte_TypeDef_IslaUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_ISLA_SpdLimTrffcSgnSta;
  uint8 ux_TT_ISLA_SpdLimTrffcSgnVal;
  uint8 ux_TT_ISLA_TrffcSgnCntryInfoSta;
  uint8 ux_TT_ISLA_AddtnlTrffcSgnSta;
  uint8 ux_TT_ISLA_SuppTrffcSgnSta;
  uint8 ux_ISLA_TrffcSgnBlnkngSta;
  uint8 ux_SMV_SetSpdSta_ISLA;
  uint8 ux_SMV_ISLA_SetSpdSymbSta;
  uint8 ux_ISLA_SetSpdSymbBlnkngSta;
  uint8 ux_PU_F_Group7_ISLA_FlrSta;
  uint8 ux_PU_M_Group2_ISLA_ADASWarn1_1Sta;
  uint8 ux_SND_ADAS_Warn1_3Sta;
} IslaUxOutToIvc_t;

#  define Rte_TypeDef_IslwAppVersionInfo_t
typedef struct
{
  uint16 u16_IslwAppVersion;
} IslwAppVersionInfo_t;

#  define Rte_TypeDef_IslwEyeQInput_t
typedef struct
{
  uint8 u8_TSR_Sign_Count;
  uint8 u8_TSR_Sync_ID;
  uint8 u8_DrivingSideME;
} IslwEyeQInput_t;

#  define Rte_TypeDef_IslwFailInfo_t
typedef struct
{
  uint8 u8_Timeout_HU_Navi_ISLW_PE_00;
  uint8 u8_Timeout_HU_MON_PE_01;
  uint8 u8_ActiveFault;
  uint8 u8_BlockageFault;
} IslwFailInfo_t;

#  define Rte_TypeDef_IslwInput_t
typedef struct
{
  uint8 u8_SCC_OpSta;
  uint8 u8_SCC_TrgtSpdSetVal;
  uint16 u16_aReqValue;
} IslwInput_t;

#  define Rte_TypeDef_IslwOccNvData_t
typedef struct
{
  uint32 u32_SLIF_MIN_TSR_DIST_MOTORWAY_SIGN_AFT_NO_SIGN;
  uint32 u32_SLIF_MIN_TSR_DIST_PASS_JC_AFT_NO_SIGN;
  uint32 u32_SLIF_MIN_TSR_DIST_ENTER_FREEWAY_AFT_NO_SIGN;
  uint32 u32_SLIF_MIN_TSR_DIST_EXIT_IC_AFT_NO_SIGN;
  uint32 u32_SLIF_MIN_TSR_DIST_EXIT_FREEWAY_AFT_NO_SIGN;
  uint32 u32_SLIF_MIN_TSR_DIST_EXPIRE_TIMER_AFT_NO_SIGN;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_NON_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_NON_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_NON_HW;
  uint32 u32_SLIF_Rain_Decision_Period;
  uint32 u32_SLIF_Rain_Off_Decision_Period;
  uint32 u32_SLIF_MAX_TSR_DIST_EXTRA_DELAY_NOSPDLMT_BY_NAVI;
  uint32 u32_SLIF_MAX_TSR_DIST_LATRANGE_ARROW_SIGN_HWEXIT;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_NON_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_ARROW_SIGN_HW;
  uint32 u32_SLIF_MAX_TSR_DIST_RECOGND_RAIN_SIGN_HW;
  uint32 u32_SLIF_MIN_TSR_SAS_TURNDEC;
  uint32 u32_SLIF_BLOCKAGE_RUNTIME;
  uint8 u8_SLIF_SET_TSR_TIMER_MODE;
  uint8 u8_Nvm_Occ_ISLA_OffstUsmSta;
  uint8 u8_Nvm_Occ_ISLA_AutoUsmSta;
  uint8 u8_Nvm_Occ_ISLA_OptUsmSta;
  uint16 u16_IslwAppVersion;
  uint16 Reserved1;
  uint16 Reserved2;
  uint16 Reserved3;
  uint16 Reserved4;
  uint16 Reserved5;
  uint16 Reserved6;
  uint16 Reserved7;
} IslwOccNvData_t;

#  define Rte_TypeDef_IslwOutput_t
typedef struct
{
  uint8 u8_ISLW_Status;
  uint8 u8_ISLW_Spd_Dis_CLU_Main;
  uint8 u8_ISLW_Spd_Dis_NAVI_Main;
  uint8 u8_ISLA_SpdwOffst;
  uint8 u8_ISLA_SwIgnoreReq;
  uint8 u8_ISLA_SpdChgReq;
  uint8 u8_ISLA_SpdWrn;
  uint8 u8_ISLA_SymFlashMod;
  uint8 u8_ISLA_Popup;
  uint8 u8_ISLA_OptUsmSta;
  uint8 u8_ISLA_OffstUsmSta;
  uint8 u8_ISLA_Cntry;
  uint8 u8_ISLA_AddtnlSign;
  uint8 u8_ISLA_AutoSetSpdSta;
  uint8 u8_ISLA_CondInfoDisp;
  uint8 u8_ISLA_SndReqSta;
  uint8 u8_ISLA_NAOffstUSMSta;
  uint8 u8_ISLA_EUCntry1USMSta;
  uint8 u8_ISLA_EUCntry2USMSta;
  uint8 u8_ISLA_EUCntryVertyp;
  uint8 u8_ISLA_NACntry1USMSta;
  uint8 u8_ISLA_NACntry2USMSta;
  uint8 u8_ISLA_NACntryVertyp;
  uint8 u8_ISLA_SpdLimVal;
  uint8 u8_ISLA_TSRSpdLimEnfrcmtSta;
} IslwOutput_t;

#  define Rte_TypeDef_IslwTSRInfo_t
typedef struct
{
  uint16 u16_TSR_Sign_Name;
  uint8 u8_TSR_Relevancy;
  uint8 u8_TSR_Sup1_SignName;
  uint8 u8_TSR_Sup2_SignName;
  uint16 u16_TSR_Sign_Long_Distance;
  uint16 u16_TSR_Sign_Lateral_Distance;
  uint16 u16_TSR_Sign_Height;
  uint8 u8_TSR_ID;
  uint8 u8_TSR_Sup1_Confidence;
  uint8 u8_TSR_Sup2_Confidence;
  uint8 u8_TSR_Sign_Shape;
  boolean u8_TSR_Sign_Is_Electronic;
  uint8 u8_TSR_Confidence;
  uint16 u16_TSR_Sign_Long_Distance_STD;
  uint16 u16_TSR_Sign_Lat_Distance_STD;
  uint16 u16_TSR_Sign_Height_STD;
  uint16 u16_TSR_Sign_Panel_Width;
  uint16 u16_TSR_Sign_Panel_Height;
  uint16 u16_TSR_Sign_Panel_Width_STD;
  uint16 u16_TSR_Sign_Panel_Height_STD;
  uint16 u16_Tracking_Out_of_Image;
  uint16 u16_TSR_Tracking_Age;
} IslwTSRInfo_t;

#  define Rte_TypeDef_IvcAppVersionInfo_t
typedef struct
{
  uint16 u16_IvcAppVersion;
} IvcAppVersionInfo_t;

#  define Rte_TypeDef_IvcHptOutput_t
typedef struct
{
  uint8 u8_HPT_StrWhlWarn1Sta;
} IvcHptOutput_t;

#  define Rte_TypeDef_IvcMv1Output_t
typedef struct
{
  uint8 u8_MV_DrvLnCtLnSta;
  uint8 u8_MV_LtLnSta;
  uint8 u8_MV_RtLnSta;
  uint8 u8_MV_DrvLnRdsVal;
  uint8 u8_MV_LtLnOffstVal;
  uint8 u8_MV_RtLnOffstVal;
  uint8 u8_MV_VehDstSta;
  uint16 u16_MV_VehDstVal;
} IvcMv1Output_t;

#  define Rte_TypeDef_IvcMv2Output_t
typedef struct
{
  uint8 u8_MV_HostVeh1Sta;
  uint8 u8_MV_FrObjSta;
  uint16 u16_MV_FrObjLongPosVal;
  sint8 s8_MV_FrObjLatPosVal;
} IvcMv2Output_t;

#  define Rte_TypeDef_IvcPuFOutput_t
typedef struct
{
  uint8 u8_PU_F_Group1_ADASWarn1_1Sta;
  uint8 u8_PU_F_Group1_ADASWarn1_2Sta;
  uint8 u8_PU_F_Group4_ADASWarn1_1Sta;
  uint8 u8_PU_F_Group7_FwdSftyFlrSta;
  uint8 u8_PU_F_Group7_LnSftyFlrSta;
  uint8 u8_PU_F_Group7_ISLA_FlrSta;
  uint8 u8_PU_F_Group7_DAW_FlrSta;
  uint8 u8_PU_F_Group7_HBA_FlrSta;
  uint8 u8_PU_F_Group7_SCC_FlrSta;
  uint8 u8_PU_F_Group7_LFA_FlrSta;
  uint8 u8_PU_F_Group7_HDA_FlrSta;
  uint8 u8_PU_F_Group7_MRM_FlrSta;
  uint8 u8_PU_F_Group7_DrvrAsstFlr1Sta;
} IvcPuFOutput_t;

#  define Rte_TypeDef_IvcPuMOutput_t
typedef struct
{
  uint8 u8_PU_M_Group2_ADASWarn1_1Sta;
} IvcPuMOutput_t;

#  define Rte_TypeDef_IvcSmvOutput_t
typedef struct
{
  uint8 u8_SMV_FrObjSta;
  uint8 u8_SMV_VehDstLvlVal;
  uint8 u8_SMV_VehDstLvlSta;
  uint8 u8_SMV_HostVehSta;
  uint8 u8_SMV_SetSpdSta;
  uint8 u8_SMV_SetSpdVal;
  uint8 u8_SMV_HDA_SymbSta;
  uint8 u8_SMV_ISLA_SetSpdSymbSta;
  uint8 u8_SMV_NSCC_SymbSta;
  uint8 u8_SMV_LFA_SymbSta;
  uint8 u8_SMV_DrvAsstHUDSymbSta;
} IvcSmvOutput_t;

#  define Rte_TypeDef_IvcSndOutput_t
typedef struct
{
  uint8 u8_SND_ADASWarn1_1Sta;
  uint8 u8_SND_ADASWarn1_2Sta;
  uint8 u8_SND_ADASWarn1_3Sta;
  uint8 u8_SND_ADASWarn1_4Sta;
  uint8 u8_SND_ADASWarn1_5Sta;
} IvcSndOutput_t;

#  define Rte_TypeDef_IvcSymbStaOutput_t
typedef struct
{
  uint8 u8_TT_FwdSftySymbSta;
  uint8 u8_TT_LnSftySymbSta;
  uint8 u8_TT_DAW_SymbSta;
  uint8 u8_TT_HBA_SymbSta;
} IvcSymbStaOutput_t;

#  define Rte_TypeDef_IvcTrffcSgnOutput_t
typedef struct
{
  uint8 u8_TT_ISLA_SpdLimTrffcSgnSta;
  uint8 u8_TT_ISLA_SpdLimTrffcSgnVal;
  uint8 u8_TT_ISLA_TrffcSgnCntryInfoSta;
  uint8 u8_TT_ISLA_AddtnlTrffcSgnSta;
  uint8 u8_TT_ISLA_SuppTrffcSgnSta;
} IvcTrffcSgnOutput_t;

#  define Rte_TypeDef_IvcVarOutput_t
typedef struct
{
  uint32 u32_VAR_Opt1Sta;
} IvcVarOutput_t;

#  define Rte_TypeDef_LDW_t
typedef struct
{
  uint32 LDW_Suppression_Reason_Left;
  uint32 LDW_Suppression_Reason_Right;
  float32 LDW_Time_To_Warning_Left;
  float32 LDW_Time_To_Warning_Right;
  uint8 LDW_Warning_Status_Left;
  uint8 LDW_Warning_Status_Right;
} LDW_t;

#  define Rte_TypeDef_LandMarks_t
typedef struct
{
  uint16 LM_Angle_0;
  uint16 LM_AnglSTD_0;
  uint16 LM_Height_0;
  uint16 LM_Height_STD_0;
  uint16 LM_Long_Distanc_0;
  uint16 LM_Long_DistancSTD_0;
  uint16 LM_Lat_Distance_0;
  uint16 LM_Lat_DistancSTD_0;
  uint16 LM_Angle_1;
  uint16 LM_AnglSTD_1;
  uint16 LM_Height_1;
  uint16 LM_Height_STD_1;
  uint16 LM_Long_Distanc_1;
  uint16 LM_Long_DistancSTD_1;
  uint16 LM_Lat_Distance_1;
  uint16 LM_Lat_DistancSTD_1;
  uint16 LM_Angle_2;
  uint16 LM_AnglSTD_2;
  uint16 LM_Height_2;
  uint16 LM_Height_STD_2;
  uint16 LM_Long_Distanc_2;
  uint16 LM_Long_DistancSTD_2;
  uint16 LM_Lat_Distance_2;
  uint16 LM_Lat_DistancSTD_2;
  uint16 LM_Angle_3;
  uint16 LM_AnglSTD_3;
  uint16 LM_Height_3;
  uint16 LM_Height_STD_3;
  uint16 LM_Long_Distanc_3;
  uint16 LM_Long_DistancSTD_3;
  uint16 LM_Lat_Distance_3;
  uint16 LM_Lat_DistancSTD_3;
  uint16 LM_Angle_4;
  uint16 LM_AnglSTD_4;
  uint16 LM_Height_4;
  uint16 LM_Height_STD_4;
  uint16 LM_Long_Distanc_4;
  uint16 LM_Long_DistancSTD_4;
  uint16 LM_Lat_Distance_4;
  uint16 LM_Lat_DistancSTD_4;
  uint8 LM_Objects_Count;
  uint8 LM_Is_In_Tunnel;
  uint8 LM_ID_0;
  uint8 LM_FramAge_0;
  uint8 LM_Type_0;
  uint8 LM_Object_Is_Centered_0;
  uint8 LM_MeasurState_0;
  uint8 LM_ID_1;
  uint8 LM_FramAge_1;
  uint8 LM_Type_1;
  uint8 LM_Object_Is_Centered_1;
  uint8 LM_MeasurState_1;
  uint8 LM_ID_2;
  uint8 LM_FramAge_2;
  uint8 LM_Type_2;
  uint8 LM_Object_Is_Centered_2;
  uint8 LM_MeasurState_2;
  uint8 LM_ID_3;
  uint8 LM_FramAge_3;
  uint8 LM_Type_3;
  uint8 LM_Object_Is_Centered_3;
  uint8 LM_MeasurState_3;
  uint8 LM_ID_4;
  uint8 LM_FramAge_4;
  uint8 LM_Type_4;
  uint8 LM_Object_Is_Centered_4;
  uint8 LM_MeasurState_4;
} LandMarks_t;

#  define Rte_TypeDef_LaneInfo_t
typedef struct
{
  uint16 CMR_Lane_View_Range_End;
  uint16 CMR_Position;
  uint16 CMR_Curvature;
  uint16 CMR_Curvature_Derivative;
  uint16 CMR_Heading_Angle;
  uint8 CMR_Quality;
  uint8 CMR_LaneType;
  uint8 CMR_Width_Marking;
  uint8 CMR_LDW_Warning;
} LaneInfo_t;

#  define Rte_TypeDef_LanesAdjacent_t
typedef struct
{
  uint8 LA_Lane_Track_ID;
  uint8 LA_Age;
  uint8 LA_Exist_Probability;
  uint8 LA_Color;
  uint8 LA_Color_Conf;
  boolean LA_Prediction_Type;
  boolean LA_Prediction_Source;
  uint16 LA_View_Range_Start;
  uint16 LA_View_Range_End;
  uint16 LA_Measured_VR_End;
  uint8 LA_Lanemark_Type;
  uint8 LA_DLM_Type;
  uint8 LA_Lanemark_Type_Conf;
  uint8 LA_Line_Role;
  uint8 LA_Marker_Width;
  uint8 LA_Marker_Width_STD;
  float32 LA_Line_C3;
  float32 LA_Line_C2;
  float32 LA_Line_C1;
  float32 LA_Line_C0;
} LanesAdjacent_t;

#  define Rte_TypeDef_LanesApplications_t
typedef struct
{
  uint8 LAP_INTP_ID;
  uint16 LAP_INTP_Age;
  uint8 LAP_INTP_Exist_Probability;
  boolean LAP_INTP_Is_Valid;
  uint8 LAP_INTP_Line_Role;
  boolean LAP_INTP_Type;
  boolean LAP_INTP_Is_Start;
  uint16 LAP_INTP_Lat_Distance;
  uint16 LAP_INTP_Long_Distance;
} LanesApplications_t;

#  define Rte_TypeDef_LanesHost_t
typedef struct
{
  uint32 LH_CRC;
  uint8 LH_Is_Triggered_SDM_Type;
  uint8 LH_Is_Triggered_SDM_Model;
  uint8 LH_Track_ID;
  uint8 LH_Age;
  uint8 LH_Confidence;
  uint8 LH_Prediction_Reason;
  uint8 LH_Availability_State;
  uint8 LH_Color;
  uint8 LH_Color_Confidence;
  uint8 LH_Lanemark_Type;
  uint8 LH_DLM_Type;
  uint8 LH_DECEL_Type;
  uint8 LH_Lanemark_Type_Conf;
  uint8 LH_Side;
  boolean LH_Crossing;
  uint8 LH_Marker_Width;
  uint8 LH_Marker_Width_STD;
  boolean LH_Dash_Average_Available;
  uint8 LH_Dash_Average_Length;
  uint8 LH_Dash_Average_Gap;
  boolean LH_Is_Multi_Clothoid;
  float32 LH_Line_First_C0;
  float32 LH_Line_First_C1;
  float32 LH_Line_First_C2;
  float32 LH_Line_First_C3;
  uint16 LH_First_VR_Start;
  uint16 LH_First_VR_End;
  uint16 LH_First_Measured_VR_End;
  uint16 LH_Second_Measured_VR_End;
  float32 LH_Line_Second_C0;
  float32 LH_Line_Second_C1;
  float32 LH_Line_Second_C2;
  float32 LH_Line_Second_C3;
  uint16 LH_Second_VR_Start;
  uint16 LH_Second_VR_End;
  boolean LH_Is_Construction_Area;
} LanesHost_t;

#  define Rte_TypeDef_LanesRoadEdge_t
typedef struct
{
  uint32 LRE_Element_CRC;
  uint8 LRE_ID;
  uint8 LRE_Age;
  uint8 LRE_Confidence;
  uint8 LRE_Type;
  uint8 LRE_Prediction_Reason;
  uint8 LRE_Availability_State;
  uint8 LRE_Height;
  uint8 LRE_Height_STD;
  uint16 LRE_View_Range_Start;
  uint16 LRE_View_Range_End;
  uint16 LRE_Measured_VR_End;
  uint8 LRE_Side;
  uint8 LRE_Is_Triggered_SDM_Model;
  float32 LRE_Line_C3;
  float32 LRE_Line_C2;
  float32 LRE_Line_C1;
  float32 LRE_Line_C0;
  uint8 LRE_Position;
} LanesRoadEdge_t;

#  define Rte_TypeDef_Lanes_Support_ADV_t
typedef struct
{
  uint8 LS_ADV_Protocol_Version;
  uint8 LS_ADV_Sync_ID;
  uint8 LS_INTP_Number;
  boolean LS_CA_Is_Construction_Area;
  boolean LS_Path_Pred_Available;
  boolean LS_Exit_Merge_Available;
  boolean LS_INTP_Available;
  uint32 LS_Path_Pred_CRC;
  uint32 LS_Path_Pred_C0;
  uint32 LS_Path_Pred_C1;
  uint32 LS_Path_Pred_C2;
  uint32 LS_Path_Pred_C3;
  uint8 LS_Path_Pred_Conf;
  uint8 LS_Path_Pred_Half_Width;
  boolean LS_Is_Merge_Left_Valid;
  boolean LS_Is_Merge_Right_Valid;
  boolean LS_Is_Exit_Left_Valid;
  boolean LS_Is_Exit_Right_Valid;
  boolean LS_Is_Highway_Merge_Left;
  boolean LS_Is_Highway_Merge_Right;
  boolean LS_Is_Highway_Exit_Left;
  boolean LS_Is_Highway_Exit_Right;
  uint8 LS_INTP_ID_0;
  uint16 LS_INTP_Age_0;
  uint8 LS_INTP_Existense_Probability_0;
  boolean LS_INTP_Is_Valid_0;
  uint8 LS_INTP_Line_Role_0;
  boolean LS_INTP_Type_0;
  boolean LS_INTP_Is_Start_0;
  uint16 LS_INTP_Lat_Distance_0;
  uint16 LS_INTP_Long_Distance_0;
  uint8 LS_INTP_ID_1;
  uint16 LS_INTP_Age_1;
  uint8 LS_INTP_Existense_Probability_1;
  boolean LS_INTP_Is_Valid_1;
  uint8 LS_INTP_Line_Role_1;
  boolean LS_INTP_Type_1;
  boolean LS_INTP_Is_Start_1;
  uint16 LS_INTP_Lat_Distance_1;
  uint16 LS_INTP_Long_Distance_1;
  uint8 LS_INTP_ID_2;
  uint16 LS_INTP_Age_2;
  uint8 LS_INTP_Existense_Probability_2;
  boolean LS_INTP_Is_Valid_2;
  uint8 LS_INTP_Line_Role_2;
  boolean LS_INTP_Type_2;
  boolean LS_INTP_Is_Start_2;
  uint16 LS_INTP_Lat_Distance_2;
  uint16 LS_INTP_Long_Distance_2;
  uint8 LS_INTP_ID_3;
  uint16 LS_INTP_Age_3;
  uint8 LS_INTP_Existense_Probability_3;
  boolean LS_INTP_Is_Valid_3;
  uint8 LS_INTP_Line_Role_3;
  boolean LS_INTP_Type_3;
  boolean LS_INTP_Is_Start_3;
  uint16 LS_INTP_Lat_Distance_3;
  uint16 LS_INTP_Long_Distance_3;
  uint8 LS_INTP_ID_4;
  uint16 LS_INTP_Age_4;
  uint8 LS_INTP_Existense_Probability_4;
  boolean LS_INTP_Is_Valid_4;
  uint8 LS_INTP_Line_Role_4;
  boolean LS_INTP_Type_4;
  boolean LS_INTP_Is_Start_4;
  uint16 LS_INTP_Lat_Distance_4;
  uint16 LS_INTP_Long_Distance_4;
  uint8 LS_INTP_ID_5;
  uint16 LS_INTP_Age_5;
  uint8 LS_INTP_Existense_Probability_5;
  boolean LS_INTP_Is_Valid_5;
  uint8 LS_INTP_Line_Role_5;
  boolean LS_INTP_Type_5;
  boolean LS_INTP_Is_Start_5;
  uint16 LS_INTP_Lat_Distance_5;
  uint16 LS_INTP_Long_Distance_5;
  uint8 LS_INTP_ID_6;
  uint16 LS_INTP_Age_6;
  uint8 LS_INTP_Existense_Probability_6;
  boolean LS_INTP_Is_Valid_6;
  uint8 LS_INTP_Line_Role_6;
  boolean LS_INTP_Type_6;
  boolean LS_INTP_Is_Start_6;
  uint16 LS_INTP_Lat_Distance_6;
  uint16 LS_INTP_Long_Distance_6;
  uint8 LS_INTP_ID_7;
  uint16 LS_INTP_Age_7;
  uint8 LS_INTP_Existense_Probability_7;
  boolean LS_INTP_Is_Valid_7;
  uint8 LS_INTP_Line_Role_7;
  boolean LS_INTP_Type_7;
  boolean LS_INTP_Is_Start_7;
  uint16 LS_INTP_Lat_Distance_7;
  uint16 LS_INTP_Long_Distance_7;
} Lanes_Support_ADV_t;

#  define Rte_TypeDef_Lanes_Support_Road_Edge_t
typedef struct
{
  uint8 LS_Road_Edge_Protocol_Version;
  uint8 LS_Road_Edge_Sync_ID;
  uint8 LS_Road_Edge_Number;
  uint8 LS_Road_Edge_ID_0;
  uint8 LS_Road_Edge_Age_0;
  uint8 LS_Road_Edge_Exist_Prob_0;
  uint8 LS_Road_Edge_Type_0;
  uint8 LS_Road_Edge_Prediction_Type_0;
  uint8 LS_Road_Edge_Height_0;
  uint8 LS_Road_Edge_Height_STD_0;
  uint16 LS_Road_Edge_View_Range_Start_0;
  uint16 LS_Road_Edge_View_Range_End_0;
  uint8 LS_Road_Edge_Host_Side_0;
  uint8 LS_Road_Edge_From_Host_Index_0;
  uint32 LS_Road_Edge_Line_C3_0;
  uint16 LS_Road_Edge_Line_C3_STD_0;
  uint16 LS_Road_Edge_Line_C2_STD_0;
  uint32 LS_Road_Edge_Line_C2_0;
  uint32 LS_Road_Edge_Line_C1_0;
  uint16 LS_Road_Edge_Line_C1_STD_0;
  uint16 LS_Road_Edge_Line_C0_STD_0;
  uint32 LS_Road_Edge_Line_C0_0;
  uint8 LS_Road_Edge_ID_1;
  uint8 LS_Road_Edge_Age_1;
  uint8 LS_Road_Edge_Exist_Prob_1;
  uint8 LS_Road_Edge_Type_1;
  uint8 LS_Road_Edge_Prediction_Type_1;
  uint8 LS_Road_Edge_Height_1;
  uint8 LS_Road_Edge_Height_STD_1;
  uint16 LS_Road_Edge_View_Range_Start_1;
  uint16 LS_Road_Edge_View_Range_End_1;
  uint8 LS_Road_Edge_Host_Side_1;
  uint8 LS_Road_Edge_From_Host_Index_1;
  uint32 LS_Road_Edge_Line_C3_1;
  uint16 LS_Road_Edge_Line_C3_STD_1;
  uint16 LS_Road_Edge_Line_C2_STD_1;
  uint32 LS_Road_Edge_Line_C2_1;
  uint32 LS_Road_Edge_Line_C1_1;
  uint16 LS_Road_Edge_Line_C1_STD_1;
  uint16 LS_Road_Edge_Line_C0_STD_1;
  uint32 LS_Road_Edge_Line_C0_1;
  uint8 LS_Road_Edge_ID_2;
  uint8 LS_Road_Edge_Age_2;
  uint8 LS_Road_Edge_Exist_Prob_2;
  uint8 LS_Road_Edge_Type_2;
  uint8 LS_Road_Edge_Prediction_Type_2;
  uint8 LS_Road_Edge_Height_2;
  uint8 LS_Road_Edge_Height_STD_2;
  uint16 LS_Road_Edge_View_Range_Start_2;
  uint16 LS_Road_Edge_View_Range_End_2;
  uint8 LS_Road_Edge_Host_Side_2;
  uint8 LS_Road_Edge_From_Host_Index_2;
  uint32 LS_Road_Edge_Line_C3_2;
  uint16 LS_Road_Edge_Line_C3_STD_2;
  uint16 LS_Road_Edge_Line_C2_STD_2;
  uint32 LS_Road_Edge_Line_C2_2;
  uint32 LS_Road_Edge_Line_C1_2;
  uint16 LS_Road_Edge_Line_C1_STD_2;
  uint16 LS_Road_Edge_Line_C0_STD_2;
  uint32 LS_Road_Edge_Line_C0_2;
  uint8 LS_Road_Edge_ID_3;
  uint8 LS_Road_Edge_Age_3;
  uint8 LS_Road_Edge_Exist_Prob_3;
  uint8 LS_Road_Edge_Type_3;
  uint8 LS_Road_Edge_Prediction_Type_3;
  uint8 LS_Road_Edge_Height_3;
  uint8 LS_Road_Edge_Height_STD_3;
  uint16 LS_Road_Edge_View_Range_Start_3;
  uint16 LS_Road_Edge_View_Range_End_3;
  uint8 LS_Road_Edge_Host_Side_3;
  uint8 LS_Road_Edge_From_Host_Index_3;
  uint32 LS_Road_Edge_Line_C3_3;
  uint16 LS_Road_Edge_Line_C3_STD_3;
  uint16 LS_Road_Edge_Line_C2_STD_3;
  uint32 LS_Road_Edge_Line_C2_3;
  uint32 LS_Road_Edge_Line_C1_3;
  uint16 LS_Road_Edge_Line_C1_STD_3;
  uint16 LS_Road_Edge_Line_C0_STD_3;
  uint32 LS_Road_Edge_Line_C0_3;
} Lanes_Support_Road_Edge_t;

#  define Rte_TypeDef_Lanes_Support_t
typedef struct
{
  uint8 LS_Protocol_Version;
  uint8 LS_Sync_ID;
  uint8 LS_Adjacent_Number;
  boolean LS_CA_Is_Construction_Area;
  uint16 LS_Host_Estimated_Width;
  uint32 LS_Host_CRC;
  boolean LS_Host_L_Valid;
  uint8 LS_Host_L_Is_Triggered_SDM;
  uint8 LS_Host_L_Track_ID;
  uint8 LS_Host_L_Age;
  uint8 LS_Host_L_Existence_Probability;
  uint8 LS_Host_L_Prediction_Source;
  uint8 LS_Host_L_Prediction_Type;
  uint8 LS_Host_L_Color;
  uint8 LS_Host_L_Color_Confidence;
  uint8 LS_Host_L_Type_Classification;
  uint8 LS_Host_L_Type_Confidence;
  uint8 LS_Host_L_DLM_Type;
  uint8 LS_Host_L_DECEL_Type;
  uint16 LS_Host_L_View_Range_Start;
  uint16 LS_Host_L_View_Range_End;
  uint16 LS_Host_L_Measured_VR_End;
  boolean LS_Host_L_Crossing;
  uint8 LS_Host_L_Marker_Width;
  uint8 LS_Host_L_Marker_Width_STD;
  uint8 LS_Host_L_Dash_Average_Length;
  uint8 LS_Host_L_Dash_Average_Gap;
  uint32 LS_Host_L_Line_C0;
  uint16 LS_Host_L_Line_C0_STD;
  uint16 LS_Host_L_Line_C1_STD;
  uint32 LS_Host_L_Line_C1;
  uint32 LS_Host_L_Line_C2;
  uint16 LS_Host_L_Line_C2_STD;
  uint16 LS_Host_L_Line_C3_STD;
  uint32 LS_Host_L_Line_C3;
  boolean LS_Host_R_Valid;
  uint8 LS_Host_R_Is_Triggered_SDM;
  uint8 LS_Host_R_Track_ID;
  uint8 LS_Host_R_Age;
  uint8 LS_Host_R_Existence_Probability;
  uint8 LS_Host_R_Prediction_Source;
  uint8 LS_Host_R_Prediction_Type;
  uint8 LS_Host_R_Color;
  uint8 LS_Host_R_Color_Confidence;
  uint8 LS_Host_R_Type_Classification;
  uint8 LS_Host_R_Type_Confidence;
  uint8 LS_Host_R_DLM_Type;
  uint8 LS_Host_R_DECEL_Type;
  uint16 LS_Host_R_View_Range_Start;
  uint16 LS_Host_R_View_Range_End;
  uint16 LS_Host_R_Measured_VR_End;
  boolean LS_Host_R_Crossing;
  uint8 LS_Host_R_Marker_Width;
  uint8 LS_Host_R_Marker_Width_STD;
  uint8 LS_Host_R_Dash_Average_Length;
  uint8 LS_Host_R_Dash_Average_Gap;
  uint32 LS_Host_R_Line_C0;
  uint16 LS_Host_R_Line_C0_STD;
  uint16 LS_Host_R_Line_C1_STD;
  uint32 LS_Host_R_Line_C1;
  uint32 LS_Host_R_Line_C2;
  uint16 LS_Host_R_Line_C2_STD;
  uint16 LS_Host_R_Line_C3_STD;
  uint32 LS_Host_R_Line_C3;
  uint8 LS_Adjacent_Lane_Track_ID_0;
  uint8 LS_Adjacent_Age_0;
  uint8 LS_Adjacent_Exist_Probability_0;
  uint8 LS_Adjacent_Color_0;
  uint8 LS_Adjacent_Color_Conf_0;
  boolean LS_Adjacent_Prediction_Type_0;
  boolean LS_Adjacent_Prediction_Source_0;
  uint16 LS_Adjacent_View_Range_Start_0;
  uint16 LS_Adjacent_View_Range_End_0;
  uint8 LS_Adjacent_Type_Class_0;
  uint8 LS_Adjacent_Type_Conf_0;
  uint8 LS_Adjacent_DLM_Type_0;
  uint8 LS_Adjacent_Line_Role_0;
  uint8 LS_Adjacent_Marker_Width_0;
  uint8 LS_Adjacent_Marker_Width_STD_0;
  uint16 LS_Adjacent_Line_C3_STD_0;
  uint32 LS_Adjacent_Line_C3_0;
  uint32 LS_Adjacent_Line_C2_0;
  uint16 LS_Adjacent_Line_C2_STD_0;
  uint16 LS_Adjacent_Line_C1_STD_0;
  uint32 LS_Adjacent_Line_C1_0;
  uint32 LS_Adjacent_Line_C0_0;
  uint16 LS_Adjacent_Line_C0_STD_0;
  uint8 LS_Adjacent_Lane_Track_ID_1;
  uint8 LS_Adjacent_Age_1;
  uint8 LS_Adjacent_Exist_Probability_1;
  uint8 LS_Adjacent_Color_1;
  uint8 LS_Adjacent_Color_Conf_1;
  boolean LS_Adjacent_Prediction_Type_1;
  boolean LS_Adjacent_Prediction_Source_1;
  uint16 LS_Adjacent_View_Range_Start_1;
  uint16 LS_Adjacent_View_Range_End_1;
  uint8 LS_Adjacent_Type_Class_1;
  uint8 LS_Adjacent_Type_Conf_1;
  uint8 LS_Adjacent_DLM_Type_1;
  uint8 LS_Adjacent_Line_Role_1;
  uint8 LS_Adjacent_Marker_Width_1;
  uint8 LS_Adjacent_Marker_Width_STD_1;
  uint16 LS_Adjacent_Line_C3_STD_1;
  uint32 LS_Adjacent_Line_C3_1;
  uint32 LS_Adjacent_Line_C2_1;
  uint16 LS_Adjacent_Line_C2_STD_1;
  uint16 LS_Adjacent_Line_C1_STD_1;
  uint32 LS_Adjacent_Line_C1_1;
  uint32 LS_Adjacent_Line_C0_1;
  uint16 LS_Adjacent_Line_C0_STD_1;
  uint8 LS_Adjacent_Lane_Track_ID_2;
  uint8 LS_Adjacent_Age_2;
  uint8 LS_Adjacent_Exist_Probability_2;
  uint8 LS_Adjacent_Color_2;
  uint8 LS_Adjacent_Color_Conf_2;
  boolean LS_Adjacent_Prediction_Type_2;
  boolean LS_Adjacent_Prediction_Source_2;
  uint16 LS_Adjacent_View_Range_Start_2;
  uint16 LS_Adjacent_View_Range_End_2;
  uint8 LS_Adjacent_Type_Class_2;
  uint8 LS_Adjacent_Type_Conf_2;
  uint8 LS_Adjacent_DLM_Type_2;
  uint8 LS_Adjacent_Line_Role_2;
  uint8 LS_Adjacent_Marker_Width_2;
  uint8 LS_Adjacent_Marker_Width_STD_2;
  uint16 LS_Adjacent_Line_C3_STD_2;
  uint32 LS_Adjacent_Line_C3_2;
  uint32 LS_Adjacent_Line_C2_2;
  uint16 LS_Adjacent_Line_C2_STD_2;
  uint16 LS_Adjacent_Line_C1_STD_2;
  uint32 LS_Adjacent_Line_C1_2;
  uint32 LS_Adjacent_Line_C0_2;
  uint16 LS_Adjacent_Line_C0_STD_2;
  uint8 LS_Adjacent_Lane_Track_ID_3;
  uint8 LS_Adjacent_Age_3;
  uint8 LS_Adjacent_Exist_Probability_3;
  uint8 LS_Adjacent_Color_3;
  uint8 LS_Adjacent_Color_Conf_3;
  boolean LS_Adjacent_Prediction_Type_3;
  boolean LS_Adjacent_Prediction_Source_3;
  uint16 LS_Adjacent_View_Range_Start_3;
  uint16 LS_Adjacent_View_Range_End_3;
  uint8 LS_Adjacent_Type_Class_3;
  uint8 LS_Adjacent_Type_Conf_3;
  uint8 LS_Adjacent_DLM_Type_3;
  uint8 LS_Adjacent_Line_Role_3;
  uint8 LS_Adjacent_Marker_Width_3;
  uint8 LS_Adjacent_Marker_Width_STD_3;
  uint16 LS_Adjacent_Line_C3_STD_3;
  uint32 LS_Adjacent_Line_C3_3;
  uint32 LS_Adjacent_Line_C2_3;
  uint16 LS_Adjacent_Line_C2_STD_3;
  uint16 LS_Adjacent_Line_C1_STD_3;
  uint32 LS_Adjacent_Line_C1_3;
  uint32 LS_Adjacent_Line_C0_3;
  uint16 LS_Adjacent_Line_C0_STD_3;
  boolean LDW_Line_Valid_Left;
  boolean LDW_Line_Valid_Right;
  uint8 LDW_Warning_Status_Left_0;
  uint8 LDW_Warning_Status_Right_0;
  uint8 LDW_Warning_Status_Left_1;
  uint8 LDW_Warning_Status_Right_1;
  uint8 LDW_Warning_Status_Left_2;
  uint8 LDW_Warning_Status_Right_2;
  uint8 LDW_Warning_Status_Left_3;
  uint8 LDW_Warning_Status_Right_3;
} Lanes_Support_t;

#  define Rte_TypeDef_LkaSwData_t
typedef struct
{
  uint8 LkaSwStatus;
} LkaSwData_t;

#  define Rte_TypeDef_LkaSwFaultStatus_t
typedef struct
{
  uint8 SwSTG_u8;
  uint8 SwSTB_u8;
  uint8 SwContPressed_u8;
} LkaSwFaultStatus_t;

#  define Rte_TypeDef_LssAppVersionInfo_t
typedef struct
{
  uint16 u16_LssAppVersion;
} LssAppVersionInfo_t;

#  define Rte_TypeDef_LssCanSigFailSafeInfo_t
typedef struct
{
  uint8 b_OverrideDTCforCal;
  uint8 b_OverrideDTC;
  uint8 b_LfaFail;
  uint8 b_Navi_Fault;
  uint8 b_HDA_Fault;
  uint8 b_LdwFail;
  uint8 b_LkaFail;
  uint8 b_LkaHwSwFail;
  uint8 b_CMRTempSta;
  uint8 b_BlockageSta;
} LssCanSigFailSafeInfo_t;

#  define Rte_TypeDef_LssFrqNvData_t
typedef struct
{
  sint16 s16_NVM_r_SteerWhlAgOffs;
  sint16 s16_NVM_r_YawRateOffs;
  sint16 s16_NVM_r_StrColTqOffs;
  sint16 s16_Nvm_Rom_HdngAngOffset;
  uint8 u8_NVM_r_LkasUsmOpt;
  uint8 u8_NVM_r_LkasUsmOptDelay;
  uint8 u8_NVM_r_LFA_Opt_USM;
  uint8 u8_Rom_SysOff;
  uint8 u8_NVM_LKA_Status;
  uint8 u8_NVM_LFA_Status;
  uint8 u8_NVM_HdaStatus_User1;
  uint8 u8_NVM_HdaStatus_User2;
  uint8 u8_NVM_HdaStatus_Guest;
  uint8 u8_NVM_ProfileIDRVal;
  uint8 u8_NVM_WarnSndUSMSta;
  uint8 Reserved;
} LssFrqNvData_t;

#  define Rte_TypeDef_LssInput_t
typedef struct
{
  uint8 b_Uds_LdwFuncValidCmd;
  uint8 u8_FCA_Status;
  uint8 u8_FCA_FailInfo;
  uint8 u8_ACCMode;
  uint8 u8_SCC_InfoDisplay;
  uint8 u8_SCC_VSetDis;
  uint8 u8_SCC_MainMode_ACC;
  uint8 u8_SCC_ACCFailInfo;
} LssInput_t;

#  define Rte_TypeDef_LssMeInfo_t
typedef struct
{
  uint8 b_MEFailSafeLKA;
  uint8 u8_DrivingSideME;
} LssMeInfo_t;

#  define Rte_TypeDef_LssMrmUxOutToIvc_t
typedef struct
{
  uint8 u8_ux_PU_F_Group1_ADASWarn1_2Sta_MRM;
} LssMrmUxOutToIvc_t;

#  define Rte_TypeDef_LssOutput_t
typedef struct
{
  uint8 u8_LKA_CF_Lkas_ActToi;
  uint8 u8_LKA_CF_Lkas_SysWarning;
  uint8 u8_LKA_CF_Lkas_ToiFlt;
  uint16 u16_LKA_CR_Lkas_StrToqReq;
  uint8 u8_LKA_OnOffEquip2Sta;
  uint8 u8_CF_LKA_HandsOff_Snd;
  uint8 u8_CF_LKA_SymbolState;
  uint8 u8_LKA_WarnSndUSMSta;
  uint8 u8_CF_HDA_Opt_USM;
  uint8 u8_CF_HDA_Mode;
  uint8 u8_CF_HDA_InfoDisplay;
  uint8 u8_CF_HDA_LFA_SteeringState;
  uint8 u8_CF_LKA_LaneRecogState;
  uint8 u8_CF_HDA_InfoDisplay2;
  uint8 u8_CF_HDA_LFA_Wrn_Snd;
  uint8 u8_CF_LKA_LHWarning;
  uint8 u8_CF_LKA_RHWarning;
  uint8 u8_ADAS_Damping_Gain;
  uint8 u8_LKA_EmergencyRampDown;
  uint8 u8_CF_HDA_TDMRMDecelReq;
} LssOutput_t;

#  define Rte_TypeDef_LssUxOutToIvc_t
typedef struct
{
  uint8 ux_TT_LnSftySymbSta;
  uint8 ux_SMV_HDA_SymbSta;
  uint8 ux_SMV_LFA_SymbSta;
  uint8 ux_MV_DrvLnCtLnSta;
  uint8 ux_MV_LtLnSta_LKA;
  uint8 ux_MV_LtLnSta_LFA;
  uint8 ux_MV_RtLnSta_LKA;
  uint8 ux_MV_RtLnSta_LFA;
  uint8 ux_MV_HostVeh1Sta_LKA;
  uint8 ux_MV_HostVeh1Sta_LFA;
  uint8 ux_PU_F_Group1_ADASWarn1_2Sta_LKA;
  uint8 ux_PU_F_Group1_ADASWarn1_2Sta_LFA;
  uint8 ux_PU_F_Group1_ADASWarn1_2Sta_HDA;
  uint8 ux_PU_F_Group7_LnSftyFlrSta;
  uint8 ux_PU_F_Group7_LFA_FlrSta;
  uint8 ux_PU_F_Group7_HDA_FlrSta;
  uint8 ux_LKA_SND_ADASWarn1_2Sta;
  uint8 ux_LFA_SND_ADASWarn1_2Sta;
  uint8 ux_HDA_SND_ADASWarn1_2Sta;
  uint8 ux_LFA_SND_ADASWarn1_4Sta;
  uint8 ux_SND_ADASWarn1_5Sta;
  uint8 ux_HPT_StrWhlWarn1Sta_LKA;
} LssUxOutToIvc_t;

#  define Rte_TypeDef_MeFailInfo_t
typedef struct
{
  uint8 u8_FS_Autofix_OOC_Yaw;
  uint8 u8_FS_Autofix_OOC_Horizon;
  uint8 u8_FS_TSR_OutOfCalib_yaw;
  uint8 u8_FS_TSR_OutOfCalib_pitch;
  uint8 u8_FS_TSR_OutOfCalib_Roll;
  uint8 u8_FS_rain;
  uint8 u8_FS_snow;
  uint8 u8_FS_fog;
  uint8 u8_FS_selfGlare_M;
  uint8 u8_FS_sunRay_M;
  uint8 u8_FS_splashes_M;
  uint8 u8_FS_blurImage_M;
  uint8 u8_FS_lowSun_M;
  uint8 u8_FS_PTB_M;
  uint8 u8_FS_fullBlockage_M;
  uint8 u8_FS_outOfFocus_M;
  uint8 u8_FS_Frozen_Windshield_M;
  uint8 u8_FS_Rel_Calib_Misalignment;
  uint8 CMR_Full_Blockage;
  uint8 CMR_Partial_Blockage;
} MeFailInfo_t;

#  define Rte_TypeDef_MeInfo_t
typedef struct
{
  uint8 OBJ_VRU_Count;
  uint8 OBJ_Sync_ID;
  uint8 OBJ_VD_Count;
  uint8 OBJ_General_OBJ_Count;
  uint8 OBJ_Animal_Count;
  uint8 OBJ_VD_NIV_Left;
  uint8 OBJ_VD_NIV_Right;
  uint8 OBJ_VD_CIPV_ID;
  uint8 OBJ_VD_CIPV_Lost;
  uint8 OBJ_VD_Allow_Acce;
  uint16 FCF_VD_AEB_Supp_FCV;
  uint16 FCF_VD_Alert_FCV;
  uint8 FCF_VD_ID_FCV;
  boolean FCF_VD_HeadWay_Alert;
  uint16 FCF_VD_HeadWay_Distance;
} MeInfo_t;

#  define Rte_TypeDef_MeInputCommData_t
typedef struct
{
  uint16 VehicleSpeed_u16;
  uint8 VehicleSpeedValid_u8;
  uint16 YawRate_u16;
  uint8 YawRateValid_u8;
  uint16 LatAccel_u16;
  uint8 LatAccelValid_u8;
  uint8 WiperStatus_u8;
  uint8 WiperStatusValid_u8;
  uint8 ReverseIndicator_u8;
  uint8 ReverseIndicatorValid_u8;
  sint16 SteeringWheelAngle_s16;
  uint8 SteeringWheelAngleValid_u8;
  uint8 AccelPedalValue_u8;
  uint8 AccelPedalValid_u8;
  uint16 AccelRate_u16;
  uint8 AccelRateValid_u8;
  uint8 BrakePedalPressed_u8;
  uint8 BrakePedalPressedValid_u8;
  uint16 VehicleDisplaySpeed_u16;
  uint8 VehicleDisplaySpeedValid_u8;
  uint8 TurnSwitchStatus_u8;
  uint8 HighBeamActive_u8;
  uint8 FogLightActive_u8;
  uint8 VehicleCode_u8;
  uint8 fcaGapSensitivity_u8;
  uint8 fcaGapSensitivityValid_u8;
  uint8 pcwGapSensitivity_u8;
  uint8 pcwGapSensitivityValid_u8;
} MeInputCommData_t;

#  define Rte_TypeDef_MrmUxOutToIvc_t
typedef struct
{
  uint8 ux_PU_F_Group1_ADASWarn1_2Sta_MRM;
  uint8 ux_MRM_SND_ADASWarn1_1Sta;
  uint8 ux_PU_F_Group7_MRM_FlrSta;
} MrmUxOutToIvc_t;

#  define Rte_TypeDef_Nvm8ByteDataRead_t
typedef struct
{
  uint32 data1_u32;
  uint32 data2_u32;
} Nvm8ByteDataRead_t;

#  define Rte_TypeDef_ObjInfo_t
typedef struct
{
  uint32 OBJ_CRC;
  uint16 OBJ_Object_Age;
  uint16 OBJ_Width;
  uint16 OBJ_Length;
  uint16 OBJ_Height;
  uint16 OBJ_Abs_Long_Velocity;
  uint16 OBJ_Abs_Long_Velocity_STD;
  uint16 OBJ_Abs_Lat_Velocity;
  uint16 OBJ_Abs_Lat_Velocity_STD;
  uint16 OBJ_Abs_Long_Acc;
  uint16 OBJ_Abs_Lat_Acc;
  uint16 OBJ_Abs_Acceleration;
  uint16 OBJ_Inv_TTC;
  uint16 OBJ_Inv_TTC_STD;
  uint16 OBJ_Relative_Long_Acc;
  uint16 OBJ_Relative_Long_Velocity;
  uint16 OBJ_Relative_Long_Velo_STD;
  uint16 OBJ_Relative_Lat_Velocity;
  uint16 OBJ_Relative_Lat_Velocity_STD;
  uint16 OBJ_Long_Distance;
  uint16 OBJ_Long_Distance_STD;
  uint16 OBJ_Lat_Distance;
  uint16 OBJ_Lat_Distance_STD;
  uint16 OBJ_Absolute_Speed;
  uint16 OBJ_Absolute_Speed_STD;
  uint16 OBJ_Heading;
  uint16 OBJ_Heading_STD;
  uint16 OBJ_Angle_Rate_STD;
  uint16 OBJ_Angle_Rate;
  uint16 OBJ_Angle_Right;
  uint16 OBJ_Angle_Right_STD;
  uint16 OBJ_Angle_Left;
  uint16 OBJ_Angle_Left_STD;
  uint16 OBJ_Angle_Side;
  uint16 OBJ_Angle_Side_STD;
  uint16 OBJ_Angle_Mid;
  uint16 OBJ_Angle_Mid_STD;
  uint16 OBJ_Angle_Bottom_V;
  uint16 OBJ_Angle_Bottom;
  uint16 OBJ_Angle_Bottom_STD;
  uint8 OBJ_VD_CIPVFlag;
  uint8 OBJ_ID;
  uint8 OBJ_Existence_Probability;
  uint8 OBJ_Triggered_SDM;
  uint8 OBJ_Motion_Category;
  uint8 OBJ_Measuring_Status;
  uint8 OBJ_Object_Class;
  uint8 OBJ_Class_Probability;
  uint8 OBJ_Camera;
  uint8 OBJ_Motion_Status;
  uint8 OBJ_Motion_Orientation;
  uint8 OBJ_Lane_Assignment;
  uint8 OBJ_Age_Seconds;
  uint8 OBJ_Width_STD;
  uint8 OBJ_Length_STD;
  uint8 OBJ_Height_STD;
  uint8 OBJ_Abs_Long_Acc_STD;
  uint8 OBJ_Abs_Lat_Acc_STD;
  uint8 OBJ_Abs_Acce_STD;
  uint8 OBJ_Relative_Long_Acc_STD;
  boolean OBJ_Has_Cut_Lane;
  boolean OBJ_Has_Cut_Path;
  boolean OBJ_Brake_Light;
  boolean OBJ_Turn_Indicator_Right;
  boolean OBJ_Turn_Indicator_Left;
  boolean OBJ_Light_Indicator_Validity;
  boolean OBJ_Right_Out_Of_Image;
  boolean OBJ_Left_Out_Of_Image;
  boolean OBJ_Right_Out_Of_Image_V;
  boolean OBJ_Left_Out_Of_Image_V;
  boolean OBJ_Top_Out_Of_Image;
  boolean OBJ_Bottom_Out_Of_Image;
  boolean OBJ_Top_Out_Of_Image_V;
  boolean OBJ_Bottom_Out_Of_Image_V;
  boolean OBJ_Lane_Assignment_V;
  boolean OBJ_Age_Seconds_V;
  boolean OBJ_Width_V;
  boolean OBJ_Width_STD_V;
  boolean OBJ_Length_V;
  boolean OBJ_Length_STD_V;
  boolean OBJ_Height_V;
  boolean OBJ_Height_STD_V;
  boolean OBJ_Abs_Long_Velocity_V;
  boolean OBJ_Abs_Long_Velo_STD_V;
  boolean OBJ_Abs_Lat_Velocity_V;
  boolean OBJ_Abs_Lat_Velo_STD_V;
  boolean OBJ_Abs_Long_Acc_V;
  boolean OBJ_Abs_Long_Acc_STD_V;
  boolean OBJ_Abs_Lat_Acc_V;
  boolean OBJ_Abs_Lat_Acc_STD_V;
  boolean OBJ_Abs_Acceleration_V;
  boolean OBJ_Abs_Acc_STD_V;
  boolean OBJ_Inv_TTC_V;
  boolean OBJ_Inv_TTC_STD_V;
  boolean OBJ_Relative_Long_Acc_V;
  boolean OBJ_Rel_Long_Acc_STD_V;
  boolean OBJ_Relative_Long_Velocity_V;
  boolean OBJ_Rel_Long_Velo_STD_V;
  boolean OBJ_Relative_Lat_Velocity_V;
  boolean OBJ_Rel_Lat_Velo_STD_V;
  boolean OBJ_Long_Distance_V;
  boolean OBJ_Long_Distance_STD_V;
  boolean OBJ_Lat_Distance_V;
  boolean OBJ_Lat_Distance_STD_V;
  boolean OBJ_Absolute_Speed_V;
  boolean OBJ_Absolute_Speed_STD_V;
  boolean OBJ_Heading_V;
  boolean OBJ_Heading_STD_V;
  boolean OBJ_Angle_Rate_STD_V;
  boolean OBJ_Angle_Rate_V;
  boolean OBJ_Angle_Right_V;
  boolean OBJ_Angle_Right_STD_V;
  boolean OBJ_Angle_Left_V;
  boolean OBJ_Angle_Left_STD_V;
  boolean OBJ_Angle_Side_V;
  boolean OBJ_Angle_Side_STD_V;
  boolean OBJ_Angle_Mid_V;
  boolean OBJ_Angle_Mid_STD_V;
  boolean OBJ_Angle_Bottom_STD_V;
  boolean OBJ_Is_In_Drivable_Area;
  boolean OBJ_Is_In_Drivable_Area_V;
  boolean OBJ_Is_VeryClose;
  boolean OBJ_Is_VeryClose_V;
} ObjInfo_t;

#  define Rte_TypeDef_Objects_t
typedef struct
{
  uint32 OBJ_CRC;
  uint8 OBJ_ID;
  uint8 OBJ_VD_CIPVFlag;
  uint8 OBJ_Existence_Probability;
  uint16 OBJ_Fusion_Source;
  uint8 OBJ_Triggered_SDM;
  uint8 OBJ_Motion_Category;
  uint16 OBJ_Object_Age;
  uint8 OBJ_Measuring_Status;
  uint8 OBJ_Object_Class;
  uint8 OBJ_Class_Probability;
  uint8 OBJ_Camera_Source;
  uint8 OBJ_Motion_Status;
  uint8 OBJ_Motion_Orientation;
  boolean OBJ_Has_Cut_Lane;
  boolean OBJ_Has_Cut_Path;
  boolean OBJ_Brake_Light_Validity;
  boolean OBJ_Brake_Light;
  boolean OBJ_Turn_Indicator_Right;
  boolean OBJ_Turn_Indicator_Left;
  boolean OBJ_Turn_Indicator_Validity;
  boolean OBJ_Right_Out_Of_Image;
  boolean OBJ_Left_Out_Of_Image;
  boolean OBJ_Right_Out_Of_Image_V;
  boolean OBJ_Left_Out_Of_Image_V;
  boolean OBJ_Top_Out_Of_Image;
  boolean OBJ_Bottom_Out_Of_Image;
  boolean OBJ_Top_Out_Of_Image_V;
  boolean OBJ_Bottom_Out_Of_Image_V;
  uint8 OBJ_Lane_Assignment;
  boolean OBJ_Lane_Assignment_V;
  uint8 OBJ_Age_Seconds;
  boolean OBJ_Age_Seconds_V;
  uint16 OBJ_Width;
  boolean OBJ_Width_V;
  uint16 OBJ_Width_STD;
  boolean OBJ_Width_STD_V;
  uint16 OBJ_Length;
  boolean OBJ_Length_V;
  uint16 OBJ_Length_STD;
  boolean OBJ_Length_STD_V;
  uint16 OBJ_Height;
  boolean OBJ_Height_V;
  uint16 OBJ_Height_STD;
  boolean OBJ_Height_STD_V;
  uint16 OBJ_Abs_Long_Velocity;
  boolean OBJ_Abs_Long_Velocity_V;
  uint16 OBJ_Abs_Long_Velocity_STD;
  boolean OBJ_Abs_Long_Vel_STD_V;
  uint16 OBJ_Abs_Lat_Velocity;
  boolean OBJ_Abs_Lat_Velocity_V;
  uint16 OBJ_Abs_Lat_Velocity_STD;
  boolean OBJ_Abs_Lat_Vel_STD_V;
  uint16 OBJ_Abs_Long_Acc;
  boolean OBJ_Abs_Long_Acc_V;
  uint16 OBJ_Abs_Long_Acc_STD;
  boolean OBJ_Abs_Long_Acc_STD_V;
  uint16 OBJ_Abs_Lat_Acc;
  boolean OBJ_Abs_Lat_Acc_V;
  uint16 OBJ_Abs_Lat_Acc_STD;
  boolean OBJ_Abs_Lat_Acc_STD_V;
  uint16 OBJ_Abs_Acceleration;
  boolean OBJ_Abs_Acceleration_V;
  uint16 OBJ_Abs_Acc_STD;
  boolean OBJ_Abs_Acc_STD_V;
  uint16 OBJ_Inv_TTC;
  boolean OBJ_Inv_TTC_V;
  uint16 OBJ_Inv_TTC_STD;
  boolean OBJ_Inv_TTC_STD_V;
  uint16 OBJ_Relative_Long_Acc;
  boolean OBJ_Relative_Long_Acc_V;
  uint16 OBJ_Relative_Long_Acc_STD;
  boolean OBJ_Rel_Long_Acc_STD_V;
  uint16 OBJ_Relative_Long_Velocity;
  boolean OBJ_Relative_Long_Velocity_V;
  uint16 OBJ_Relative_Long_Vel_STD;
  boolean OBJ_Rel_Long_Vel_STD_V;
  uint16 OBJ_Relative_Lat_Velocity;
  boolean OBJ_Relative_Lat_Velocity_V;
  uint16 OBJ_Relative_Lat_Velocity_STD;
  boolean OBJ_Rel_Lat_Vel_STD_V;
  uint16 OBJ_Long_Distance;
  boolean OBJ_Long_Distance_V;
  uint16 OBJ_Long_Distance_STD;
  boolean OBJ_Long_Distance_STD_V;
  uint16 OBJ_Lat_Distance;
  boolean OBJ_Lat_Distance_V;
  uint16 OBJ_Lat_Distance_STD;
  boolean OBJ_Lat_Distance_STD_V;
  uint16 OBJ_Absolute_Speed;
  boolean OBJ_Absolute_Speed_V;
  uint16 OBJ_Absolute_Speed_STD;
  boolean OBJ_Absolute_Speed_STD_V;
  uint16 OBJ_Heading;
  boolean OBJ_Heading_V;
  uint16 OBJ_Heading_STD;
  boolean OBJ_Heading_STD_V;
  uint16 OBJ_Angle_Rate_STD;
  boolean OBJ_Angle_Rate_STD_V;
  uint16 OBJ_Angle_Rate;
  boolean OBJ_Angle_Rate_V;
  uint16 OBJ_Angle_Right;
  boolean OBJ_Angle_Right_V;
  uint16 OBJ_Angle_Right_STD;
  boolean OBJ_Angle_Right_STD_V;
  uint16 OBJ_Angle_Left;
  boolean OBJ_Angle_Left_V;
  uint16 OBJ_Angle_Left_STD;
  boolean OBJ_Angle_Left_STD_V;
  uint16 OBJ_Angle_Side;
  boolean OBJ_Angle_Side_V;
  uint16 OBJ_Angle_Side_STD;
  boolean OBJ_Angle_Side_STD_V;
  boolean OBJ_Angle_Mid_V;
  uint16 OBJ_Angle_Mid;
  uint16 OBJ_Angle_Mid_STD;
  boolean OBJ_Angle_Mid_STD_V;
  boolean OBJ_Angle_Bottom_V;
  uint16 OBJ_Angle_Bottom;
  uint16 OBJ_Angle_Bottom_STD;
  boolean OBJ_Angle_Bottom_STD_V;
  boolean OBJ_Visibility_Side_V;
  uint8 OBJ_Visibility_Side;
  boolean OBJ_Is_In_Drivable_Area;
  boolean OBJ_Is_In_Drivable_Area_V;
  boolean OBJ_Is_VeryClose_V;
  boolean OBJ_Is_VeryClose;
  boolean OBJ_Is_EMERGENCY_VCL;
  uint8 OBJ_EMERGENCY_LIGHT_COLOR;
  boolean OBJ_EMERGENCY_V;
  boolean OBJ_Open_Door_Left;
  boolean OBJ_Open_Door_Right;
  uint8 OBJ_Visible_Left_or_Right;
  boolean OBJ_Visible_Left_or_Right_V;
  uint8 OBJ_2W_Is_Motorbike_Probability;
  uint8 OBJ_2W_Is_Bicycle_Probability;
  boolean Obj_partially_in_lane;
} Objects_t;

#  define Rte_TypeDef_Plant_TAC2InitParamsNVM_t
typedef struct
{
  uint8 TAC_Mode_u8;
  uint8 TAC_BottomLeftSquare_0_u8;
  uint8 TAC_BottomLeftSquare_1_u8;
  uint8 TAC_Targets_Num_u8;
  uint16 TAC_TargetInfo_Lat_Distance_0_u16;
  uint16 TAC_TargetInfo_Lat_Distance_1_u16;
  uint16 TAC_TargetInfo_Height_0_u16;
  uint16 TAC_TargetInfo_Height_1_u16;
  uint16 TAC_Camera_Height_u16;
  uint16 TAC_Camera_Z_u16;
  uint8 TAC_Max_Horizon_u8;
  uint8 TAC_Min_Horizon_u8;
  uint8 TAC_Max_Yaw_u8;
  uint8 TAC_Min_Yaw_u8;
  uint8 TAC_Max_RollAngle_u8;
  uint8 TAC_Bottom_u8;
  uint16 TAC_SquareSideSize_u16;
} Plant_TAC2InitParamsNVM_t;

#  define Rte_TypeDef_RadarDtcInfo_t
typedef struct
{
  COM_DT_BatteryVoltageHigh BatteryVoltageHigh;
  COM_DT_BatteryVoltageLow BatteryVoltageLow;
  COM_DT_Blockage_Drv Blockage_Drv;
  COM_DT_Blockage_Init Blockage_Init;
  COM_DT_RadarCANCommError RadarCANCommError;
  COM_DT_RadarErrorCode_No1 RadarErrorCode_No1;
  COM_DT_RadarErrorCode_No2 RadarErrorCode_No2;
  COM_DT_RadarHwError RadarHwError;
  COM_DT_RadarHwTempCondition_High RadarHwTempCondition_High;
  COM_DT_RadarHwTempCondition_Low RadarHwTempCondition_Low;
  COM_DT_RD_DTC_AlvCntVal RD_DTC_AlvCntVal;
  COM_DT_SystemOutOfCalibration_DRV SystemOutOfCalibration_DRV;
  COM_DT_SystemOutOfCalibration_EOL SystemOutOfCalibration_EOL;
  COM_DT_FR_RDR_CrcVal RD_DTC_CRCVal;
} RadarDtcInfo_t;

#  define Rte_TypeDef_RdrInfo_t
typedef struct
{
  uint16 FR_RDR_Det_CRC01Val;
  uint16 FR_RDR_Det_CRC02Val;
  uint16 FR_RDR_Det_CRC03Val;
  uint16 FR_RDR_Det_CRC04Val;
  uint16 FR_RDR_Det_CRC05Val;
  uint16 FR_RDR_Det_CRC06Val;
  uint16 FR_RDR_Det_CRC07Val;
  uint16 FR_RDR_Det_CRC08Val;
  uint16 FR_RDR_Det_CRC09Val;
  uint16 FR_RDR_Det_CRC10Val;
  uint16 FR_RDR_Det_CRC11Val;
  uint16 FR_RDR_Det_CRC12Val;
  uint16 FR_RDR_Det_CRC13Val;
  uint16 FR_RDR_Det_CRC14Val;
  uint16 FR_RDR_Det_CRC15Val;
  uint16 FR_RDR_Det_CRC16Val;
  uint16 FR_RDR_Det_Long01;
  uint16 FR_RDR_Det_Long02;
  uint16 FR_RDR_Det_Long03;
  uint16 FR_RDR_Det_Long04;
  uint16 FR_RDR_Det_Long05;
  uint16 FR_RDR_Det_Long06;
  uint16 FR_RDR_Det_Long07;
  uint16 FR_RDR_Det_Long08;
  uint16 FR_RDR_Det_Long09;
  uint16 FR_RDR_Det_Long10;
  uint16 FR_RDR_Det_Long11;
  uint16 FR_RDR_Det_Long12;
  uint16 FR_RDR_Det_Long13;
  uint16 FR_RDR_Det_Long14;
  uint16 FR_RDR_Det_Long15;
  uint16 FR_RDR_Det_Long16;
  uint16 FR_RDR_Det_Long17;
  uint16 FR_RDR_Det_Long18;
  uint16 FR_RDR_Det_Long19;
  uint16 FR_RDR_Det_Long20;
  uint16 FR_RDR_Det_Long21;
  uint16 FR_RDR_Det_Long22;
  uint16 FR_RDR_Det_Long23;
  uint16 FR_RDR_Det_Long24;
  uint16 FR_RDR_Det_Long25;
  uint16 FR_RDR_Det_Long26;
  uint16 FR_RDR_Det_Long27;
  uint16 FR_RDR_Det_Long28;
  uint16 FR_RDR_Det_Long29;
  uint16 FR_RDR_Det_Long30;
  uint16 FR_RDR_Det_Long31;
  uint16 FR_RDR_Det_Long32;
  uint16 FR_RDR_Det_Long33;
  uint16 FR_RDR_Det_Long34;
  uint16 FR_RDR_Det_Long35;
  uint16 FR_RDR_Det_Long36;
  uint16 FR_RDR_Det_Long37;
  uint16 FR_RDR_Det_Long38;
  uint16 FR_RDR_Det_Long39;
  uint16 FR_RDR_Det_Long40;
  uint16 FR_RDR_Det_Long41;
  uint16 FR_RDR_Det_Long42;
  uint16 FR_RDR_Det_Long43;
  uint16 FR_RDR_Det_Long44;
  uint16 FR_RDR_Det_Long45;
  uint16 FR_RDR_Det_Long46;
  uint16 FR_RDR_Det_Long47;
  uint16 FR_RDR_Det_Long48;
  uint16 FR_RDR_Det_Long49;
  uint16 FR_RDR_Det_Long50;
  uint16 FR_RDR_Det_Long51;
  uint16 FR_RDR_Det_Long52;
  uint16 FR_RDR_Det_Long53;
  uint16 FR_RDR_Det_Long54;
  uint16 FR_RDR_Det_Long55;
  uint16 FR_RDR_Det_Long56;
  uint16 FR_RDR_Det_Long57;
  uint16 FR_RDR_Det_Long58;
  uint16 FR_RDR_Det_Long59;
  uint16 FR_RDR_Det_Long60;
  uint16 FR_RDR_Det_Long61;
  uint16 FR_RDR_Det_Long62;
  uint16 FR_RDR_Det_Long63;
  uint16 FR_RDR_Det_Long64;
  sint16 FR_RDR_Det_Lat01;
  sint16 FR_RDR_Det_Lat02;
  sint16 FR_RDR_Det_Lat03;
  sint16 FR_RDR_Det_Lat04;
  sint16 FR_RDR_Det_Lat05;
  sint16 FR_RDR_Det_Lat06;
  sint16 FR_RDR_Det_Lat07;
  sint16 FR_RDR_Det_Lat08;
  sint16 FR_RDR_Det_Lat09;
  sint16 FR_RDR_Det_Lat10;
  sint16 FR_RDR_Det_Lat11;
  sint16 FR_RDR_Det_Lat12;
  sint16 FR_RDR_Det_Lat13;
  sint16 FR_RDR_Det_Lat14;
  sint16 FR_RDR_Det_Lat15;
  sint16 FR_RDR_Det_Lat16;
  sint16 FR_RDR_Det_Lat17;
  sint16 FR_RDR_Det_Lat18;
  sint16 FR_RDR_Det_Lat19;
  sint16 FR_RDR_Det_Lat20;
  sint16 FR_RDR_Det_Lat21;
  sint16 FR_RDR_Det_Lat22;
  sint16 FR_RDR_Det_Lat23;
  sint16 FR_RDR_Det_Lat24;
  sint16 FR_RDR_Det_Lat25;
  sint16 FR_RDR_Det_Lat26;
  sint16 FR_RDR_Det_Lat27;
  sint16 FR_RDR_Det_Lat28;
  sint16 FR_RDR_Det_Lat29;
  sint16 FR_RDR_Det_Lat30;
  sint16 FR_RDR_Det_Lat31;
  sint16 FR_RDR_Det_Lat32;
  sint16 FR_RDR_Det_Lat33;
  sint16 FR_RDR_Det_Lat34;
  sint16 FR_RDR_Det_Lat35;
  sint16 FR_RDR_Det_Lat36;
  sint16 FR_RDR_Det_Lat37;
  sint16 FR_RDR_Det_Lat38;
  sint16 FR_RDR_Det_Lat39;
  sint16 FR_RDR_Det_Lat40;
  sint16 FR_RDR_Det_Lat41;
  sint16 FR_RDR_Det_Lat42;
  sint16 FR_RDR_Det_Lat43;
  sint16 FR_RDR_Det_Lat44;
  sint16 FR_RDR_Det_Lat45;
  sint16 FR_RDR_Det_Lat46;
  sint16 FR_RDR_Det_Lat47;
  sint16 FR_RDR_Det_Lat48;
  sint16 FR_RDR_Det_Lat49;
  sint16 FR_RDR_Det_Lat50;
  sint16 FR_RDR_Det_Lat51;
  sint16 FR_RDR_Det_Lat52;
  sint16 FR_RDR_Det_Lat53;
  sint16 FR_RDR_Det_Lat54;
  sint16 FR_RDR_Det_Lat55;
  sint16 FR_RDR_Det_Lat56;
  sint16 FR_RDR_Det_Lat57;
  sint16 FR_RDR_Det_Lat58;
  sint16 FR_RDR_Det_Lat59;
  sint16 FR_RDR_Det_Lat60;
  sint16 FR_RDR_Det_Lat61;
  sint16 FR_RDR_Det_Lat62;
  sint16 FR_RDR_Det_Lat63;
  sint16 FR_RDR_Det_Lat64;
  sint16 FR_RDR_Det_Speed01;
  sint16 FR_RDR_Det_Speed02;
  sint16 FR_RDR_Det_Speed03;
  sint16 FR_RDR_Det_Speed04;
  sint16 FR_RDR_Det_Speed05;
  sint16 FR_RDR_Det_Speed06;
  sint16 FR_RDR_Det_Speed07;
  sint16 FR_RDR_Det_Speed08;
  sint16 FR_RDR_Det_Speed09;
  sint16 FR_RDR_Det_Speed10;
  sint16 FR_RDR_Det_Speed11;
  sint16 FR_RDR_Det_Speed12;
  sint16 FR_RDR_Det_Speed13;
  sint16 FR_RDR_Det_Speed14;
  sint16 FR_RDR_Det_Speed15;
  sint16 FR_RDR_Det_Speed16;
  sint16 FR_RDR_Det_Speed17;
  sint16 FR_RDR_Det_Speed18;
  sint16 FR_RDR_Det_Speed19;
  sint16 FR_RDR_Det_Speed20;
  sint16 FR_RDR_Det_Speed21;
  sint16 FR_RDR_Det_Speed22;
  sint16 FR_RDR_Det_Speed23;
  sint16 FR_RDR_Det_Speed24;
  sint16 FR_RDR_Det_Speed25;
  sint16 FR_RDR_Det_Speed26;
  sint16 FR_RDR_Det_Speed27;
  sint16 FR_RDR_Det_Speed28;
  sint16 FR_RDR_Det_Speed29;
  sint16 FR_RDR_Det_Speed30;
  sint16 FR_RDR_Det_Speed31;
  sint16 FR_RDR_Det_Speed32;
  sint16 FR_RDR_Det_Speed33;
  sint16 FR_RDR_Det_Speed34;
  sint16 FR_RDR_Det_Speed35;
  sint16 FR_RDR_Det_Speed36;
  sint16 FR_RDR_Det_Speed37;
  sint16 FR_RDR_Det_Speed38;
  sint16 FR_RDR_Det_Speed39;
  sint16 FR_RDR_Det_Speed40;
  sint16 FR_RDR_Det_Speed41;
  sint16 FR_RDR_Det_Speed42;
  sint16 FR_RDR_Det_Speed43;
  sint16 FR_RDR_Det_Speed44;
  sint16 FR_RDR_Det_Speed45;
  sint16 FR_RDR_Det_Speed46;
  sint16 FR_RDR_Det_Speed47;
  sint16 FR_RDR_Det_Speed48;
  sint16 FR_RDR_Det_Speed49;
  sint16 FR_RDR_Det_Speed50;
  sint16 FR_RDR_Det_Speed51;
  sint16 FR_RDR_Det_Speed52;
  sint16 FR_RDR_Det_Speed53;
  sint16 FR_RDR_Det_Speed54;
  sint16 FR_RDR_Det_Speed55;
  sint16 FR_RDR_Det_Speed56;
  sint16 FR_RDR_Det_Speed57;
  sint16 FR_RDR_Det_Speed58;
  sint16 FR_RDR_Det_Speed59;
  sint16 FR_RDR_Det_Speed60;
  sint16 FR_RDR_Det_Speed61;
  sint16 FR_RDR_Det_Speed62;
  sint16 FR_RDR_Det_Speed63;
  sint16 FR_RDR_Det_Speed64;
  uint16 FR_RDR_Det_SNR01;
  uint16 FR_RDR_Det_SNR02;
  uint16 FR_RDR_Det_SNR03;
  uint16 FR_RDR_Det_SNR04;
  uint16 FR_RDR_Det_SNR05;
  uint16 FR_RDR_Det_SNR06;
  uint16 FR_RDR_Det_SNR07;
  uint16 FR_RDR_Det_SNR08;
  uint16 FR_RDR_Det_SNR09;
  uint16 FR_RDR_Det_SNR10;
  uint16 FR_RDR_Det_SNR11;
  uint16 FR_RDR_Det_SNR12;
  uint16 FR_RDR_Det_SNR13;
  uint16 FR_RDR_Det_SNR14;
  uint16 FR_RDR_Det_SNR15;
  uint16 FR_RDR_Det_SNR16;
  uint16 FR_RDR_Det_SNR17;
  uint16 FR_RDR_Det_SNR18;
  uint16 FR_RDR_Det_SNR19;
  uint16 FR_RDR_Det_SNR20;
  uint16 FR_RDR_Det_SNR21;
  uint16 FR_RDR_Det_SNR22;
  uint16 FR_RDR_Det_SNR23;
  uint16 FR_RDR_Det_SNR24;
  uint16 FR_RDR_Det_SNR25;
  uint16 FR_RDR_Det_SNR26;
  uint16 FR_RDR_Det_SNR27;
  uint16 FR_RDR_Det_SNR28;
  uint16 FR_RDR_Det_SNR29;
  uint16 FR_RDR_Det_SNR30;
  uint16 FR_RDR_Det_SNR31;
  uint16 FR_RDR_Det_SNR32;
  uint16 FR_RDR_Det_SNR33;
  uint16 FR_RDR_Det_SNR34;
  uint16 FR_RDR_Det_SNR35;
  uint16 FR_RDR_Det_SNR36;
  uint16 FR_RDR_Det_SNR37;
  uint16 FR_RDR_Det_SNR38;
  uint16 FR_RDR_Det_SNR39;
  uint16 FR_RDR_Det_SNR40;
  uint16 FR_RDR_Det_SNR41;
  uint16 FR_RDR_Det_SNR42;
  uint16 FR_RDR_Det_SNR43;
  uint16 FR_RDR_Det_SNR44;
  uint16 FR_RDR_Det_SNR45;
  uint16 FR_RDR_Det_SNR46;
  uint16 FR_RDR_Det_SNR47;
  uint16 FR_RDR_Det_SNR48;
  uint16 FR_RDR_Det_SNR49;
  uint16 FR_RDR_Det_SNR50;
  uint16 FR_RDR_Det_SNR51;
  uint16 FR_RDR_Det_SNR52;
  uint16 FR_RDR_Det_SNR53;
  uint16 FR_RDR_Det_SNR54;
  uint16 FR_RDR_Det_SNR55;
  uint16 FR_RDR_Det_SNR56;
  uint16 FR_RDR_Det_SNR57;
  uint16 FR_RDR_Det_SNR58;
  uint16 FR_RDR_Det_SNR59;
  uint16 FR_RDR_Det_SNR60;
  uint16 FR_RDR_Det_SNR61;
  uint16 FR_RDR_Det_SNR62;
  uint16 FR_RDR_Det_SNR63;
  uint16 FR_RDR_Det_SNR64;
  sint16 FR_RDR_Det_AmbigSpeed01;
  sint16 FR_RDR_Det_AmbigSpeed02;
  sint16 FR_RDR_Det_AmbigSpeed03;
  sint16 FR_RDR_Det_AmbigSpeed04;
  sint16 FR_RDR_Det_AmbigSpeed05;
  sint16 FR_RDR_Det_AmbigSpeed06;
  sint16 FR_RDR_Det_AmbigSpeed07;
  sint16 FR_RDR_Det_AmbigSpeed08;
  sint16 FR_RDR_Det_AmbigSpeed09;
  sint16 FR_RDR_Det_AmbigSpeed10;
  sint16 FR_RDR_Det_AmbigSpeed11;
  sint16 FR_RDR_Det_AmbigSpeed12;
  sint16 FR_RDR_Det_AmbigSpeed13;
  sint16 FR_RDR_Det_AmbigSpeed14;
  sint16 FR_RDR_Det_AmbigSpeed15;
  sint16 FR_RDR_Det_AmbigSpeed16;
  sint16 FR_RDR_Det_AmbigSpeed17;
  sint16 FR_RDR_Det_AmbigSpeed18;
  sint16 FR_RDR_Det_AmbigSpeed19;
  sint16 FR_RDR_Det_AmbigSpeed20;
  sint16 FR_RDR_Det_AmbigSpeed21;
  sint16 FR_RDR_Det_AmbigSpeed22;
  sint16 FR_RDR_Det_AmbigSpeed23;
  sint16 FR_RDR_Det_AmbigSpeed24;
  sint16 FR_RDR_Det_AmbigSpeed25;
  sint16 FR_RDR_Det_AmbigSpeed26;
  sint16 FR_RDR_Det_AmbigSpeed27;
  sint16 FR_RDR_Det_AmbigSpeed28;
  sint16 FR_RDR_Det_AmbigSpeed29;
  sint16 FR_RDR_Det_AmbigSpeed30;
  sint16 FR_RDR_Det_AmbigSpeed31;
  sint16 FR_RDR_Det_AmbigSpeed32;
  sint16 FR_RDR_Det_AmbigSpeed33;
  sint16 FR_RDR_Det_AmbigSpeed34;
  sint16 FR_RDR_Det_AmbigSpeed35;
  sint16 FR_RDR_Det_AmbigSpeed36;
  sint16 FR_RDR_Det_AmbigSpeed37;
  sint16 FR_RDR_Det_AmbigSpeed38;
  sint16 FR_RDR_Det_AmbigSpeed39;
  sint16 FR_RDR_Det_AmbigSpeed40;
  sint16 FR_RDR_Det_AmbigSpeed41;
  sint16 FR_RDR_Det_AmbigSpeed42;
  sint16 FR_RDR_Det_AmbigSpeed43;
  sint16 FR_RDR_Det_AmbigSpeed44;
  sint16 FR_RDR_Det_AmbigSpeed45;
  sint16 FR_RDR_Det_AmbigSpeed46;
  sint16 FR_RDR_Det_AmbigSpeed47;
  sint16 FR_RDR_Det_AmbigSpeed48;
  sint16 FR_RDR_Det_AmbigSpeed49;
  sint16 FR_RDR_Det_AmbigSpeed50;
  sint16 FR_RDR_Det_AmbigSpeed51;
  sint16 FR_RDR_Det_AmbigSpeed52;
  sint16 FR_RDR_Det_AmbigSpeed53;
  sint16 FR_RDR_Det_AmbigSpeed54;
  sint16 FR_RDR_Det_AmbigSpeed55;
  sint16 FR_RDR_Det_AmbigSpeed56;
  sint16 FR_RDR_Det_AmbigSpeed57;
  sint16 FR_RDR_Det_AmbigSpeed58;
  sint16 FR_RDR_Det_AmbigSpeed59;
  sint16 FR_RDR_Det_AmbigSpeed60;
  sint16 FR_RDR_Det_AmbigSpeed61;
  sint16 FR_RDR_Det_AmbigSpeed62;
  sint16 FR_RDR_Det_AmbigSpeed63;
  sint16 FR_RDR_Det_AmbigSpeed64;
  uint16 FR_RDR_Obj_CRC01Val;
  uint16 FR_RDR_Obj_CRC02Val;
  uint16 FR_RDR_Obj_CRC03Val;
  uint16 FR_RDR_Obj_CRC04Val;
  uint16 FR_RDR_Obj_CRC05Val;
  uint16 FR_RDR_Obj_CRC06Val;
  uint16 FR_RDR_Obj_CRC07Val;
  uint16 FR_RDR_Obj_CRC08Val;
  uint16 FR_RDR_Obj_CRC09Val;
  uint16 FR_RDR_Obj_CRC10Val;
  uint16 FR_RDR_Obj_CRC11Val;
  uint16 FR_RDR_Obj_CRC12Val;
  uint16 FR_RDR_Obj_CRC13Val;
  uint16 FR_RDR_Obj_CRC14Val;
  uint16 FR_RDR_Obj_CRC15Val;
  uint16 FR_RDR_Obj_CRC16Val;
  uint16 FR_RDR_Obj_RelPosX01Val;
  uint16 FR_RDR_Obj_RelPosX02Val;
  uint16 FR_RDR_Obj_RelPosX03Val;
  uint16 FR_RDR_Obj_RelPosX04Val;
  uint16 FR_RDR_Obj_RelPosX05Val;
  uint16 FR_RDR_Obj_RelPosX06Val;
  uint16 FR_RDR_Obj_RelPosX07Val;
  uint16 FR_RDR_Obj_RelPosX08Val;
  uint16 FR_RDR_Obj_RelPosX09Val;
  uint16 FR_RDR_Obj_RelPosX10Val;
  uint16 FR_RDR_Obj_RelPosX11Val;
  uint16 FR_RDR_Obj_RelPosX12Val;
  uint16 FR_RDR_Obj_RelPosX13Val;
  uint16 FR_RDR_Obj_RelPosX14Val;
  uint16 FR_RDR_Obj_RelPosX15Val;
  uint16 FR_RDR_Obj_RelPosX16Val;
  uint16 FR_RDR_Obj_RelPosX17Val;
  uint16 FR_RDR_Obj_RelPosX18Val;
  uint16 FR_RDR_Obj_RelPosX19Val;
  uint16 FR_RDR_Obj_RelPosX20Val;
  uint16 FR_RDR_Obj_RelPosX21Val;
  uint16 FR_RDR_Obj_RelPosX22Val;
  uint16 FR_RDR_Obj_RelPosX23Val;
  uint16 FR_RDR_Obj_RelPosX24Val;
  uint16 FR_RDR_Obj_RelPosX25Val;
  uint16 FR_RDR_Obj_RelPosX26Val;
  uint16 FR_RDR_Obj_RelPosX27Val;
  uint16 FR_RDR_Obj_RelPosX28Val;
  uint16 FR_RDR_Obj_RelPosX29Val;
  uint16 FR_RDR_Obj_RelPosX30Val;
  uint16 FR_RDR_Obj_RelPosX31Val;
  uint16 FR_RDR_Obj_RelPosX32Val;
  sint16 FR_RDR_Obj_RelPosY01Val;
  sint16 FR_RDR_Obj_RelPosY02Val;
  sint16 FR_RDR_Obj_RelPosY03Val;
  sint16 FR_RDR_Obj_RelPosY04Val;
  sint16 FR_RDR_Obj_RelPosY05Val;
  sint16 FR_RDR_Obj_RelPosY06Val;
  sint16 FR_RDR_Obj_RelPosY07Val;
  sint16 FR_RDR_Obj_RelPosY08Val;
  sint16 FR_RDR_Obj_RelPosY09Val;
  sint16 FR_RDR_Obj_RelPosY10Val;
  sint16 FR_RDR_Obj_RelPosY11Val;
  sint16 FR_RDR_Obj_RelPosY12Val;
  sint16 FR_RDR_Obj_RelPosY13Val;
  sint16 FR_RDR_Obj_RelPosY14Val;
  sint16 FR_RDR_Obj_RelPosY15Val;
  sint16 FR_RDR_Obj_RelPosY16Val;
  sint16 FR_RDR_Obj_RelPosY17Val;
  sint16 FR_RDR_Obj_RelPosY18Val;
  sint16 FR_RDR_Obj_RelPosY19Val;
  sint16 FR_RDR_Obj_RelPosY20Val;
  sint16 FR_RDR_Obj_RelPosY21Val;
  sint16 FR_RDR_Obj_RelPosY22Val;
  sint16 FR_RDR_Obj_RelPosY23Val;
  sint16 FR_RDR_Obj_RelPosY24Val;
  sint16 FR_RDR_Obj_RelPosY25Val;
  sint16 FR_RDR_Obj_RelPosY26Val;
  sint16 FR_RDR_Obj_RelPosY27Val;
  sint16 FR_RDR_Obj_RelPosY28Val;
  sint16 FR_RDR_Obj_RelPosY29Val;
  sint16 FR_RDR_Obj_RelPosY30Val;
  sint16 FR_RDR_Obj_RelPosY31Val;
  sint16 FR_RDR_Obj_RelPosY32Val;
  sint16 FR_RDR_Obj_RelVelX01Val;
  sint16 FR_RDR_Obj_RelVelX02Val;
  sint16 FR_RDR_Obj_RelVelX03Val;
  sint16 FR_RDR_Obj_RelVelX04Val;
  sint16 FR_RDR_Obj_RelVelX05Val;
  sint16 FR_RDR_Obj_RelVelX06Val;
  sint16 FR_RDR_Obj_RelVelX07Val;
  sint16 FR_RDR_Obj_RelVelX08Val;
  sint16 FR_RDR_Obj_RelVelX09Val;
  sint16 FR_RDR_Obj_RelVelX10Val;
  sint16 FR_RDR_Obj_RelVelX11Val;
  sint16 FR_RDR_Obj_RelVelX12Val;
  sint16 FR_RDR_Obj_RelVelX13Val;
  sint16 FR_RDR_Obj_RelVelX14Val;
  sint16 FR_RDR_Obj_RelVelX15Val;
  sint16 FR_RDR_Obj_RelVelX16Val;
  sint16 FR_RDR_Obj_RelVelX17Val;
  sint16 FR_RDR_Obj_RelVelX18Val;
  sint16 FR_RDR_Obj_RelVelX19Val;
  sint16 FR_RDR_Obj_RelVelX20Val;
  sint16 FR_RDR_Obj_RelVelX21Val;
  sint16 FR_RDR_Obj_RelVelX22Val;
  sint16 FR_RDR_Obj_RelVelX23Val;
  sint16 FR_RDR_Obj_RelVelX24Val;
  sint16 FR_RDR_Obj_RelVelX25Val;
  sint16 FR_RDR_Obj_RelVelX26Val;
  sint16 FR_RDR_Obj_RelVelX27Val;
  sint16 FR_RDR_Obj_RelVelX28Val;
  sint16 FR_RDR_Obj_RelVelX29Val;
  sint16 FR_RDR_Obj_RelVelX30Val;
  sint16 FR_RDR_Obj_RelVelX31Val;
  sint16 FR_RDR_Obj_RelVelX32Val;
  sint16 FR_RDR_Obj_RelVelY01Val;
  sint16 FR_RDR_Obj_RelVelY02Val;
  sint16 FR_RDR_Obj_RelVelY03Val;
  sint16 FR_RDR_Obj_RelVelY04Val;
  sint16 FR_RDR_Obj_RelVelY05Val;
  sint16 FR_RDR_Obj_RelVelY06Val;
  sint16 FR_RDR_Obj_RelVelY07Val;
  sint16 FR_RDR_Obj_RelVelY08Val;
  sint16 FR_RDR_Obj_RelVelY09Val;
  sint16 FR_RDR_Obj_RelVelY10Val;
  sint16 FR_RDR_Obj_RelVelY11Val;
  sint16 FR_RDR_Obj_RelVelY12Val;
  sint16 FR_RDR_Obj_RelVelY13Val;
  sint16 FR_RDR_Obj_RelVelY14Val;
  sint16 FR_RDR_Obj_RelVelY15Val;
  sint16 FR_RDR_Obj_RelVelY16Val;
  sint16 FR_RDR_Obj_RelVelY17Val;
  sint16 FR_RDR_Obj_RelVelY18Val;
  sint16 FR_RDR_Obj_RelVelY19Val;
  sint16 FR_RDR_Obj_RelVelY20Val;
  sint16 FR_RDR_Obj_RelVelY21Val;
  sint16 FR_RDR_Obj_RelVelY22Val;
  sint16 FR_RDR_Obj_RelVelY23Val;
  sint16 FR_RDR_Obj_RelVelY24Val;
  sint16 FR_RDR_Obj_RelVelY25Val;
  sint16 FR_RDR_Obj_RelVelY26Val;
  sint16 FR_RDR_Obj_RelVelY27Val;
  sint16 FR_RDR_Obj_RelVelY28Val;
  sint16 FR_RDR_Obj_RelVelY29Val;
  sint16 FR_RDR_Obj_RelVelY30Val;
  sint16 FR_RDR_Obj_RelVelY31Val;
  sint16 FR_RDR_Obj_RelVelY32Val;
  sint16 FR_RDR_Obj_RelAccelX01Val;
  sint16 FR_RDR_Obj_RelAccelX02Val;
  sint16 FR_RDR_Obj_RelAccelX03Val;
  sint16 FR_RDR_Obj_RelAccelX04Val;
  sint16 FR_RDR_Obj_RelAccelX05Val;
  sint16 FR_RDR_Obj_RelAccelX06Val;
  sint16 FR_RDR_Obj_RelAccelX07Val;
  sint16 FR_RDR_Obj_RelAccelX08Val;
  sint16 FR_RDR_Obj_RelAccelX09Val;
  sint16 FR_RDR_Obj_RelAccelX10Val;
  sint16 FR_RDR_Obj_RelAccelX11Val;
  sint16 FR_RDR_Obj_RelAccelX12Val;
  sint16 FR_RDR_Obj_RelAccelX13Val;
  sint16 FR_RDR_Obj_RelAccelX14Val;
  sint16 FR_RDR_Obj_RelAccelX15Val;
  sint16 FR_RDR_Obj_RelAccelX16Val;
  sint16 FR_RDR_Obj_RelAccelX17Val;
  sint16 FR_RDR_Obj_RelAccelX18Val;
  sint16 FR_RDR_Obj_RelAccelX19Val;
  sint16 FR_RDR_Obj_RelAccelX20Val;
  sint16 FR_RDR_Obj_RelAccelX21Val;
  sint16 FR_RDR_Obj_RelAccelX22Val;
  sint16 FR_RDR_Obj_RelAccelX23Val;
  sint16 FR_RDR_Obj_RelAccelX24Val;
  sint16 FR_RDR_Obj_RelAccelX25Val;
  sint16 FR_RDR_Obj_RelAccelX26Val;
  sint16 FR_RDR_Obj_RelAccelX27Val;
  sint16 FR_RDR_Obj_RelAccelX28Val;
  sint16 FR_RDR_Obj_RelAccelX29Val;
  sint16 FR_RDR_Obj_RelAccelX30Val;
  sint16 FR_RDR_Obj_RelAccelX31Val;
  sint16 FR_RDR_Obj_RelAccelX32Val;
  uint16 FR_RDR_DTC_RadarCRCVal;
  uint16 FR_RDR_DTC_RadarErrorCode_1;
  uint16 FR_RDR_DTC_RadarErrorCode_2;
  uint8 FR_RDR_Det_AlvCnt01Val;
  uint8 FR_RDR_Det_AlvCnt02Val;
  uint8 FR_RDR_Det_AlvCnt03Val;
  uint8 FR_RDR_Det_AlvCnt04Val;
  uint8 FR_RDR_Det_AlvCnt05Val;
  uint8 FR_RDR_Det_AlvCnt06Val;
  uint8 FR_RDR_Det_AlvCnt07Val;
  uint8 FR_RDR_Det_AlvCnt08Val;
  uint8 FR_RDR_Det_AlvCnt09Val;
  uint8 FR_RDR_Det_AlvCnt10Val;
  uint8 FR_RDR_Det_AlvCnt11Val;
  uint8 FR_RDR_Det_AlvCnt12Val;
  uint8 FR_RDR_Det_AlvCnt13Val;
  uint8 FR_RDR_Det_AlvCnt14Val;
  uint8 FR_RDR_Det_AlvCnt15Val;
  uint8 FR_RDR_Det_AlvCnt16Val;
  uint8 FR_RDR_Det_AssignTag01;
  uint8 FR_RDR_Det_AssignTag02;
  uint8 FR_RDR_Det_AssignTag03;
  uint8 FR_RDR_Det_AssignTag04;
  uint8 FR_RDR_Det_AssignTag05;
  uint8 FR_RDR_Det_AssignTag06;
  uint8 FR_RDR_Det_AssignTag07;
  uint8 FR_RDR_Det_AssignTag08;
  uint8 FR_RDR_Det_AssignTag09;
  uint8 FR_RDR_Det_AssignTag10;
  uint8 FR_RDR_Det_AssignTag11;
  uint8 FR_RDR_Det_AssignTag12;
  uint8 FR_RDR_Det_AssignTag13;
  uint8 FR_RDR_Det_AssignTag14;
  uint8 FR_RDR_Det_AssignTag15;
  uint8 FR_RDR_Det_AssignTag16;
  uint8 FR_RDR_Det_AssignTag17;
  uint8 FR_RDR_Det_AssignTag18;
  uint8 FR_RDR_Det_AssignTag19;
  uint8 FR_RDR_Det_AssignTag20;
  uint8 FR_RDR_Det_AssignTag21;
  uint8 FR_RDR_Det_AssignTag22;
  uint8 FR_RDR_Det_AssignTag23;
  uint8 FR_RDR_Det_AssignTag24;
  uint8 FR_RDR_Det_AssignTag25;
  uint8 FR_RDR_Det_AssignTag26;
  uint8 FR_RDR_Det_AssignTag27;
  uint8 FR_RDR_Det_AssignTag28;
  uint8 FR_RDR_Det_AssignTag29;
  uint8 FR_RDR_Det_AssignTag30;
  uint8 FR_RDR_Det_AssignTag31;
  uint8 FR_RDR_Det_AssignTag32;
  uint8 FR_RDR_Det_AssignTag33;
  uint8 FR_RDR_Det_AssignTag34;
  uint8 FR_RDR_Det_AssignTag35;
  uint8 FR_RDR_Det_AssignTag36;
  uint8 FR_RDR_Det_AssignTag37;
  uint8 FR_RDR_Det_AssignTag38;
  uint8 FR_RDR_Det_AssignTag39;
  uint8 FR_RDR_Det_AssignTag40;
  uint8 FR_RDR_Det_AssignTag41;
  uint8 FR_RDR_Det_AssignTag42;
  uint8 FR_RDR_Det_AssignTag43;
  uint8 FR_RDR_Det_AssignTag44;
  uint8 FR_RDR_Det_AssignTag45;
  uint8 FR_RDR_Det_AssignTag46;
  uint8 FR_RDR_Det_AssignTag47;
  uint8 FR_RDR_Det_AssignTag48;
  uint8 FR_RDR_Det_AssignTag49;
  uint8 FR_RDR_Det_AssignTag50;
  uint8 FR_RDR_Det_AssignTag51;
  uint8 FR_RDR_Det_AssignTag52;
  uint8 FR_RDR_Det_AssignTag53;
  uint8 FR_RDR_Det_AssignTag54;
  uint8 FR_RDR_Det_AssignTag55;
  uint8 FR_RDR_Det_AssignTag56;
  uint8 FR_RDR_Det_AssignTag57;
  uint8 FR_RDR_Det_AssignTag58;
  uint8 FR_RDR_Det_AssignTag59;
  uint8 FR_RDR_Det_AssignTag60;
  uint8 FR_RDR_Det_AssignTag61;
  uint8 FR_RDR_Det_AssignTag62;
  uint8 FR_RDR_Det_AssignTag63;
  uint8 FR_RDR_Det_AssignTag64;
  uint8 FR_RDR_Det_ClusterID01;
  uint8 FR_RDR_Det_ClusterID02;
  uint8 FR_RDR_Det_ClusterID03;
  uint8 FR_RDR_Det_ClusterID04;
  uint8 FR_RDR_Det_ClusterID05;
  uint8 FR_RDR_Det_ClusterID06;
  uint8 FR_RDR_Det_ClusterID07;
  uint8 FR_RDR_Det_ClusterID08;
  uint8 FR_RDR_Det_ClusterID09;
  uint8 FR_RDR_Det_ClusterID10;
  uint8 FR_RDR_Det_ClusterID11;
  uint8 FR_RDR_Det_ClusterID12;
  uint8 FR_RDR_Det_ClusterID13;
  uint8 FR_RDR_Det_ClusterID14;
  uint8 FR_RDR_Det_ClusterID15;
  uint8 FR_RDR_Det_ClusterID16;
  uint8 FR_RDR_Det_ClusterID17;
  uint8 FR_RDR_Det_ClusterID18;
  uint8 FR_RDR_Det_ClusterID19;
  uint8 FR_RDR_Det_ClusterID20;
  uint8 FR_RDR_Det_ClusterID21;
  uint8 FR_RDR_Det_ClusterID22;
  uint8 FR_RDR_Det_ClusterID23;
  uint8 FR_RDR_Det_ClusterID24;
  uint8 FR_RDR_Det_ClusterID25;
  uint8 FR_RDR_Det_ClusterID26;
  uint8 FR_RDR_Det_ClusterID27;
  uint8 FR_RDR_Det_ClusterID28;
  uint8 FR_RDR_Det_ClusterID29;
  uint8 FR_RDR_Det_ClusterID30;
  uint8 FR_RDR_Det_ClusterID31;
  uint8 FR_RDR_Det_ClusterID32;
  uint8 FR_RDR_Det_ClusterID33;
  uint8 FR_RDR_Det_ClusterID34;
  uint8 FR_RDR_Det_ClusterID35;
  uint8 FR_RDR_Det_ClusterID36;
  uint8 FR_RDR_Det_ClusterID37;
  uint8 FR_RDR_Det_ClusterID38;
  uint8 FR_RDR_Det_ClusterID39;
  uint8 FR_RDR_Det_ClusterID40;
  uint8 FR_RDR_Det_ClusterID41;
  uint8 FR_RDR_Det_ClusterID42;
  uint8 FR_RDR_Det_ClusterID43;
  uint8 FR_RDR_Det_ClusterID44;
  uint8 FR_RDR_Det_ClusterID45;
  uint8 FR_RDR_Det_ClusterID46;
  uint8 FR_RDR_Det_ClusterID47;
  uint8 FR_RDR_Det_ClusterID48;
  uint8 FR_RDR_Det_ClusterID49;
  uint8 FR_RDR_Det_ClusterID50;
  uint8 FR_RDR_Det_ClusterID51;
  uint8 FR_RDR_Det_ClusterID52;
  uint8 FR_RDR_Det_ClusterID53;
  uint8 FR_RDR_Det_ClusterID54;
  uint8 FR_RDR_Det_ClusterID55;
  uint8 FR_RDR_Det_ClusterID56;
  uint8 FR_RDR_Det_ClusterID57;
  uint8 FR_RDR_Det_ClusterID58;
  uint8 FR_RDR_Det_ClusterID59;
  uint8 FR_RDR_Det_ClusterID60;
  uint8 FR_RDR_Det_ClusterID61;
  uint8 FR_RDR_Det_ClusterID62;
  uint8 FR_RDR_Det_ClusterID63;
  uint8 FR_RDR_Det_ClusterID64;
  uint8 FR_RDR_Det_TrustV01;
  uint8 FR_RDR_Det_TrustV02;
  uint8 FR_RDR_Det_TrustV03;
  uint8 FR_RDR_Det_TrustV04;
  uint8 FR_RDR_Det_TrustV05;
  uint8 FR_RDR_Det_TrustV06;
  uint8 FR_RDR_Det_TrustV07;
  uint8 FR_RDR_Det_TrustV08;
  uint8 FR_RDR_Det_TrustV09;
  uint8 FR_RDR_Det_TrustV10;
  uint8 FR_RDR_Det_TrustV11;
  uint8 FR_RDR_Det_TrustV12;
  uint8 FR_RDR_Det_TrustV13;
  uint8 FR_RDR_Det_TrustV14;
  uint8 FR_RDR_Det_TrustV15;
  uint8 FR_RDR_Det_TrustV16;
  uint8 FR_RDR_Det_TrustV17;
  uint8 FR_RDR_Det_TrustV18;
  uint8 FR_RDR_Det_TrustV19;
  uint8 FR_RDR_Det_TrustV20;
  uint8 FR_RDR_Det_TrustV21;
  uint8 FR_RDR_Det_TrustV22;
  uint8 FR_RDR_Det_TrustV23;
  uint8 FR_RDR_Det_TrustV24;
  uint8 FR_RDR_Det_TrustV25;
  uint8 FR_RDR_Det_TrustV26;
  uint8 FR_RDR_Det_TrustV27;
  uint8 FR_RDR_Det_TrustV28;
  uint8 FR_RDR_Det_TrustV29;
  uint8 FR_RDR_Det_TrustV30;
  uint8 FR_RDR_Det_TrustV31;
  uint8 FR_RDR_Det_TrustV32;
  uint8 FR_RDR_Det_TrustV33;
  uint8 FR_RDR_Det_TrustV34;
  uint8 FR_RDR_Det_TrustV35;
  uint8 FR_RDR_Det_TrustV36;
  uint8 FR_RDR_Det_TrustV37;
  uint8 FR_RDR_Det_TrustV38;
  uint8 FR_RDR_Det_TrustV39;
  uint8 FR_RDR_Det_TrustV40;
  uint8 FR_RDR_Det_TrustV41;
  uint8 FR_RDR_Det_TrustV42;
  uint8 FR_RDR_Det_TrustV43;
  uint8 FR_RDR_Det_TrustV44;
  uint8 FR_RDR_Det_TrustV45;
  uint8 FR_RDR_Det_TrustV46;
  uint8 FR_RDR_Det_TrustV47;
  uint8 FR_RDR_Det_TrustV48;
  uint8 FR_RDR_Det_TrustV49;
  uint8 FR_RDR_Det_TrustV50;
  uint8 FR_RDR_Det_TrustV51;
  uint8 FR_RDR_Det_TrustV52;
  uint8 FR_RDR_Det_TrustV53;
  uint8 FR_RDR_Det_TrustV54;
  uint8 FR_RDR_Det_TrustV55;
  uint8 FR_RDR_Det_TrustV56;
  uint8 FR_RDR_Det_TrustV57;
  uint8 FR_RDR_Det_TrustV58;
  uint8 FR_RDR_Det_TrustV59;
  uint8 FR_RDR_Det_TrustV60;
  uint8 FR_RDR_Det_TrustV61;
  uint8 FR_RDR_Det_TrustV62;
  uint8 FR_RDR_Det_TrustV63;
  uint8 FR_RDR_Det_TrustV64;
  sint8 FR_RDR_Det_Height01;
  sint8 FR_RDR_Det_Height02;
  sint8 FR_RDR_Det_Height03;
  sint8 FR_RDR_Det_Height04;
  sint8 FR_RDR_Det_Height05;
  sint8 FR_RDR_Det_Height06;
  sint8 FR_RDR_Det_Height07;
  sint8 FR_RDR_Det_Height08;
  sint8 FR_RDR_Det_Height09;
  sint8 FR_RDR_Det_Height10;
  sint8 FR_RDR_Det_Height11;
  sint8 FR_RDR_Det_Height12;
  sint8 FR_RDR_Det_Height13;
  sint8 FR_RDR_Det_Height14;
  sint8 FR_RDR_Det_Height15;
  sint8 FR_RDR_Det_Height16;
  sint8 FR_RDR_Det_Height17;
  sint8 FR_RDR_Det_Height18;
  sint8 FR_RDR_Det_Height19;
  sint8 FR_RDR_Det_Height20;
  sint8 FR_RDR_Det_Height21;
  sint8 FR_RDR_Det_Height22;
  sint8 FR_RDR_Det_Height23;
  sint8 FR_RDR_Det_Height24;
  sint8 FR_RDR_Det_Height25;
  sint8 FR_RDR_Det_Height26;
  sint8 FR_RDR_Det_Height27;
  sint8 FR_RDR_Det_Height28;
  sint8 FR_RDR_Det_Height29;
  sint8 FR_RDR_Det_Height30;
  sint8 FR_RDR_Det_Height31;
  sint8 FR_RDR_Det_Height32;
  sint8 FR_RDR_Det_Height33;
  sint8 FR_RDR_Det_Height34;
  sint8 FR_RDR_Det_Height35;
  sint8 FR_RDR_Det_Height36;
  sint8 FR_RDR_Det_Height37;
  sint8 FR_RDR_Det_Height38;
  sint8 FR_RDR_Det_Height39;
  sint8 FR_RDR_Det_Height40;
  sint8 FR_RDR_Det_Height41;
  sint8 FR_RDR_Det_Height42;
  sint8 FR_RDR_Det_Height43;
  sint8 FR_RDR_Det_Height44;
  sint8 FR_RDR_Det_Height45;
  sint8 FR_RDR_Det_Height46;
  sint8 FR_RDR_Det_Height47;
  sint8 FR_RDR_Det_Height48;
  sint8 FR_RDR_Det_Height49;
  sint8 FR_RDR_Det_Height50;
  sint8 FR_RDR_Det_Height51;
  sint8 FR_RDR_Det_Height52;
  sint8 FR_RDR_Det_Height53;
  sint8 FR_RDR_Det_Height54;
  sint8 FR_RDR_Det_Height55;
  sint8 FR_RDR_Det_Height56;
  sint8 FR_RDR_Det_Height57;
  sint8 FR_RDR_Det_Height58;
  sint8 FR_RDR_Det_Height59;
  sint8 FR_RDR_Det_Height60;
  sint8 FR_RDR_Det_Height61;
  sint8 FR_RDR_Det_Height62;
  sint8 FR_RDR_Det_Height63;
  sint8 FR_RDR_Det_Height64;
  uint8 FR_RDR_Det_Attribute01;
  uint8 FR_RDR_Det_Attribute02;
  uint8 FR_RDR_Det_Attribute03;
  uint8 FR_RDR_Det_Attribute04;
  uint8 FR_RDR_Det_Attribute05;
  uint8 FR_RDR_Det_Attribute06;
  uint8 FR_RDR_Det_Attribute07;
  uint8 FR_RDR_Det_Attribute08;
  uint8 FR_RDR_Det_Attribute09;
  uint8 FR_RDR_Det_Attribute10;
  uint8 FR_RDR_Det_Attribute11;
  uint8 FR_RDR_Det_Attribute12;
  uint8 FR_RDR_Det_Attribute13;
  uint8 FR_RDR_Det_Attribute14;
  uint8 FR_RDR_Det_Attribute15;
  uint8 FR_RDR_Det_Attribute16;
  uint8 FR_RDR_Det_Attribute17;
  uint8 FR_RDR_Det_Attribute18;
  uint8 FR_RDR_Det_Attribute19;
  uint8 FR_RDR_Det_Attribute20;
  uint8 FR_RDR_Det_Attribute21;
  uint8 FR_RDR_Det_Attribute22;
  uint8 FR_RDR_Det_Attribute23;
  uint8 FR_RDR_Det_Attribute24;
  uint8 FR_RDR_Det_Attribute25;
  uint8 FR_RDR_Det_Attribute26;
  uint8 FR_RDR_Det_Attribute27;
  uint8 FR_RDR_Det_Attribute28;
  uint8 FR_RDR_Det_Attribute29;
  uint8 FR_RDR_Det_Attribute30;
  uint8 FR_RDR_Det_Attribute31;
  uint8 FR_RDR_Det_Attribute32;
  uint8 FR_RDR_Det_Attribute33;
  uint8 FR_RDR_Det_Attribute34;
  uint8 FR_RDR_Det_Attribute35;
  uint8 FR_RDR_Det_Attribute36;
  uint8 FR_RDR_Det_Attribute37;
  uint8 FR_RDR_Det_Attribute38;
  uint8 FR_RDR_Det_Attribute39;
  uint8 FR_RDR_Det_Attribute40;
  uint8 FR_RDR_Det_Attribute41;
  uint8 FR_RDR_Det_Attribute42;
  uint8 FR_RDR_Det_Attribute43;
  uint8 FR_RDR_Det_Attribute44;
  uint8 FR_RDR_Det_Attribute45;
  uint8 FR_RDR_Det_Attribute46;
  uint8 FR_RDR_Det_Attribute47;
  uint8 FR_RDR_Det_Attribute48;
  uint8 FR_RDR_Det_Attribute49;
  uint8 FR_RDR_Det_Attribute50;
  uint8 FR_RDR_Det_Attribute51;
  uint8 FR_RDR_Det_Attribute52;
  uint8 FR_RDR_Det_Attribute53;
  uint8 FR_RDR_Det_Attribute54;
  uint8 FR_RDR_Det_Attribute55;
  uint8 FR_RDR_Det_Attribute56;
  uint8 FR_RDR_Det_Attribute57;
  uint8 FR_RDR_Det_Attribute58;
  uint8 FR_RDR_Det_Attribute59;
  uint8 FR_RDR_Det_Attribute60;
  uint8 FR_RDR_Det_Attribute61;
  uint8 FR_RDR_Det_Attribute62;
  uint8 FR_RDR_Det_Attribute63;
  uint8 FR_RDR_Det_Attribute64;
  uint8 FR_RDR_Det_TrustA01;
  uint8 FR_RDR_Det_TrustA02;
  uint8 FR_RDR_Det_TrustA03;
  uint8 FR_RDR_Det_TrustA04;
  uint8 FR_RDR_Det_TrustA05;
  uint8 FR_RDR_Det_TrustA06;
  uint8 FR_RDR_Det_TrustA07;
  uint8 FR_RDR_Det_TrustA08;
  uint8 FR_RDR_Det_TrustA09;
  uint8 FR_RDR_Det_TrustA10;
  uint8 FR_RDR_Det_TrustA11;
  uint8 FR_RDR_Det_TrustA12;
  uint8 FR_RDR_Det_TrustA13;
  uint8 FR_RDR_Det_TrustA14;
  uint8 FR_RDR_Det_TrustA15;
  uint8 FR_RDR_Det_TrustA16;
  uint8 FR_RDR_Det_TrustA17;
  uint8 FR_RDR_Det_TrustA18;
  uint8 FR_RDR_Det_TrustA19;
  uint8 FR_RDR_Det_TrustA20;
  uint8 FR_RDR_Det_TrustA21;
  uint8 FR_RDR_Det_TrustA22;
  uint8 FR_RDR_Det_TrustA23;
  uint8 FR_RDR_Det_TrustA24;
  uint8 FR_RDR_Det_TrustA25;
  uint8 FR_RDR_Det_TrustA26;
  uint8 FR_RDR_Det_TrustA27;
  uint8 FR_RDR_Det_TrustA28;
  uint8 FR_RDR_Det_TrustA29;
  uint8 FR_RDR_Det_TrustA30;
  uint8 FR_RDR_Det_TrustA31;
  uint8 FR_RDR_Det_TrustA32;
  uint8 FR_RDR_Det_TrustA33;
  uint8 FR_RDR_Det_TrustA34;
  uint8 FR_RDR_Det_TrustA35;
  uint8 FR_RDR_Det_TrustA36;
  uint8 FR_RDR_Det_TrustA37;
  uint8 FR_RDR_Det_TrustA38;
  uint8 FR_RDR_Det_TrustA39;
  uint8 FR_RDR_Det_TrustA40;
  uint8 FR_RDR_Det_TrustA41;
  uint8 FR_RDR_Det_TrustA42;
  uint8 FR_RDR_Det_TrustA43;
  uint8 FR_RDR_Det_TrustA44;
  uint8 FR_RDR_Det_TrustA45;
  uint8 FR_RDR_Det_TrustA46;
  uint8 FR_RDR_Det_TrustA47;
  uint8 FR_RDR_Det_TrustA48;
  uint8 FR_RDR_Det_TrustA49;
  uint8 FR_RDR_Det_TrustA50;
  uint8 FR_RDR_Det_TrustA51;
  uint8 FR_RDR_Det_TrustA52;
  uint8 FR_RDR_Det_TrustA53;
  uint8 FR_RDR_Det_TrustA54;
  uint8 FR_RDR_Det_TrustA55;
  uint8 FR_RDR_Det_TrustA56;
  uint8 FR_RDR_Det_TrustA57;
  uint8 FR_RDR_Det_TrustA58;
  uint8 FR_RDR_Det_TrustA59;
  uint8 FR_RDR_Det_TrustA60;
  uint8 FR_RDR_Det_TrustA61;
  uint8 FR_RDR_Det_TrustA62;
  uint8 FR_RDR_Det_TrustA63;
  uint8 FR_RDR_Det_TrustA64;
  uint8 FR_RDR_Obj_AlvCnt01Val;
  uint8 FR_RDR_Obj_AlvCnt02Val;
  uint8 FR_RDR_Obj_AlvCnt03Val;
  uint8 FR_RDR_Obj_AlvCnt04Val;
  uint8 FR_RDR_Obj_AlvCnt05Val;
  uint8 FR_RDR_Obj_AlvCnt06Val;
  uint8 FR_RDR_Obj_AlvCnt07Val;
  uint8 FR_RDR_Obj_AlvCnt08Val;
  uint8 FR_RDR_Obj_AlvCnt09Val;
  uint8 FR_RDR_Obj_AlvCnt10Val;
  uint8 FR_RDR_Obj_AlvCnt11Val;
  uint8 FR_RDR_Obj_AlvCnt12Val;
  uint8 FR_RDR_Obj_AlvCnt13Val;
  uint8 FR_RDR_Obj_AlvCnt14Val;
  uint8 FR_RDR_Obj_AlvCnt15Val;
  uint8 FR_RDR_Obj_AlvCnt16Val;
  uint8 FR_RDR_Obj_TrkSta01Sta;
  uint8 FR_RDR_Obj_TrkSta02Sta;
  uint8 FR_RDR_Obj_TrkSta03Sta;
  uint8 FR_RDR_Obj_TrkSta04Sta;
  uint8 FR_RDR_Obj_TrkSta05Sta;
  uint8 FR_RDR_Obj_TrkSta06Sta;
  uint8 FR_RDR_Obj_TrkSta07Sta;
  uint8 FR_RDR_Obj_TrkSta08Sta;
  uint8 FR_RDR_Obj_TrkSta09Sta;
  uint8 FR_RDR_Obj_TrkSta10Sta;
  uint8 FR_RDR_Obj_TrkSta11Sta;
  uint8 FR_RDR_Obj_TrkSta12Sta;
  uint8 FR_RDR_Obj_TrkSta13Sta;
  uint8 FR_RDR_Obj_TrkSta14Sta;
  uint8 FR_RDR_Obj_TrkSta15Sta;
  uint8 FR_RDR_Obj_TrkSta16Sta;
  uint8 FR_RDR_Obj_TrkSta17Sta;
  uint8 FR_RDR_Obj_TrkSta18Sta;
  uint8 FR_RDR_Obj_TrkSta19Sta;
  uint8 FR_RDR_Obj_TrkSta20Sta;
  uint8 FR_RDR_Obj_TrkSta21Sta;
  uint8 FR_RDR_Obj_TrkSta22Sta;
  uint8 FR_RDR_Obj_TrkSta23Sta;
  uint8 FR_RDR_Obj_TrkSta24Sta;
  uint8 FR_RDR_Obj_TrkSta25Sta;
  uint8 FR_RDR_Obj_TrkSta26Sta;
  uint8 FR_RDR_Obj_TrkSta27Sta;
  uint8 FR_RDR_Obj_TrkSta28Sta;
  uint8 FR_RDR_Obj_TrkSta29Sta;
  uint8 FR_RDR_Obj_TrkSta30Sta;
  uint8 FR_RDR_Obj_TrkSta31Sta;
  uint8 FR_RDR_Obj_TrkSta32Sta;
  uint8 FR_RDR_Obj_MvngFlag01Sta;
  uint8 FR_RDR_Obj_MvngFlag02Sta;
  uint8 FR_RDR_Obj_MvngFlag03Sta;
  uint8 FR_RDR_Obj_MvngFlag04Sta;
  uint8 FR_RDR_Obj_MvngFlag05Sta;
  uint8 FR_RDR_Obj_MvngFlag06Sta;
  uint8 FR_RDR_Obj_MvngFlag07Sta;
  uint8 FR_RDR_Obj_MvngFlag08Sta;
  uint8 FR_RDR_Obj_MvngFlag09Sta;
  uint8 FR_RDR_Obj_MvngFlag10Sta;
  uint8 FR_RDR_Obj_MvngFlag11Sta;
  uint8 FR_RDR_Obj_MvngFlag12Sta;
  uint8 FR_RDR_Obj_MvngFlag13Sta;
  uint8 FR_RDR_Obj_MvngFlag14Sta;
  uint8 FR_RDR_Obj_MvngFlag15Sta;
  uint8 FR_RDR_Obj_MvngFlag16Sta;
  uint8 FR_RDR_Obj_MvngFlag17Sta;
  uint8 FR_RDR_Obj_MvngFlag18Sta;
  uint8 FR_RDR_Obj_MvngFlag19Sta;
  uint8 FR_RDR_Obj_MvngFlag20Sta;
  uint8 FR_RDR_Obj_MvngFlag21Sta;
  uint8 FR_RDR_Obj_MvngFlag22Sta;
  uint8 FR_RDR_Obj_MvngFlag23Sta;
  uint8 FR_RDR_Obj_MvngFlag24Sta;
  uint8 FR_RDR_Obj_MvngFlag25Sta;
  uint8 FR_RDR_Obj_MvngFlag26Sta;
  uint8 FR_RDR_Obj_MvngFlag27Sta;
  uint8 FR_RDR_Obj_MvngFlag28Sta;
  uint8 FR_RDR_Obj_MvngFlag29Sta;
  uint8 FR_RDR_Obj_MvngFlag30Sta;
  uint8 FR_RDR_Obj_MvngFlag31Sta;
  uint8 FR_RDR_Obj_MvngFlag32Sta;
  uint8 FR_RDR_Obj_QualLvl01Sta;
  uint8 FR_RDR_Obj_QualLvl02Sta;
  uint8 FR_RDR_Obj_QualLvl03Sta;
  uint8 FR_RDR_Obj_QualLvl04Sta;
  uint8 FR_RDR_Obj_QualLvl05Sta;
  uint8 FR_RDR_Obj_QualLvl06Sta;
  uint8 FR_RDR_Obj_QualLvl07Sta;
  uint8 FR_RDR_Obj_QualLvl08Sta;
  uint8 FR_RDR_Obj_QualLvl09Sta;
  uint8 FR_RDR_Obj_QualLvl10Sta;
  uint8 FR_RDR_Obj_QualLvl11Sta;
  uint8 FR_RDR_Obj_QualLvl12Sta;
  uint8 FR_RDR_Obj_QualLvl13Sta;
  uint8 FR_RDR_Obj_QualLvl14Sta;
  uint8 FR_RDR_Obj_QualLvl15Sta;
  uint8 FR_RDR_Obj_QualLvl16Sta;
  uint8 FR_RDR_Obj_QualLvl17Sta;
  uint8 FR_RDR_Obj_QualLvl18Sta;
  uint8 FR_RDR_Obj_QualLvl19Sta;
  uint8 FR_RDR_Obj_QualLvl20Sta;
  uint8 FR_RDR_Obj_QualLvl21Sta;
  uint8 FR_RDR_Obj_QualLvl22Sta;
  uint8 FR_RDR_Obj_QualLvl23Sta;
  uint8 FR_RDR_Obj_QualLvl24Sta;
  uint8 FR_RDR_Obj_QualLvl25Sta;
  uint8 FR_RDR_Obj_QualLvl26Sta;
  uint8 FR_RDR_Obj_QualLvl27Sta;
  uint8 FR_RDR_Obj_QualLvl28Sta;
  uint8 FR_RDR_Obj_QualLvl29Sta;
  uint8 FR_RDR_Obj_QualLvl30Sta;
  uint8 FR_RDR_Obj_QualLvl31Sta;
  uint8 FR_RDR_Obj_QualLvl32Sta;
  uint8 FR_RDR_Obj_AlvAge01Val;
  uint8 FR_RDR_Obj_AlvAge02Val;
  uint8 FR_RDR_Obj_AlvAge03Val;
  uint8 FR_RDR_Obj_AlvAge04Val;
  uint8 FR_RDR_Obj_AlvAge05Val;
  uint8 FR_RDR_Obj_AlvAge06Val;
  uint8 FR_RDR_Obj_AlvAge07Val;
  uint8 FR_RDR_Obj_AlvAge08Val;
  uint8 FR_RDR_Obj_AlvAge09Val;
  uint8 FR_RDR_Obj_AlvAge10Val;
  uint8 FR_RDR_Obj_AlvAge11Val;
  uint8 FR_RDR_Obj_AlvAge12Val;
  uint8 FR_RDR_Obj_AlvAge13Val;
  uint8 FR_RDR_Obj_AlvAge14Val;
  uint8 FR_RDR_Obj_AlvAge15Val;
  uint8 FR_RDR_Obj_AlvAge16Val;
  uint8 FR_RDR_Obj_AlvAge17Val;
  uint8 FR_RDR_Obj_AlvAge18Val;
  uint8 FR_RDR_Obj_AlvAge19Val;
  uint8 FR_RDR_Obj_AlvAge20Val;
  uint8 FR_RDR_Obj_AlvAge21Val;
  uint8 FR_RDR_Obj_AlvAge22Val;
  uint8 FR_RDR_Obj_AlvAge23Val;
  uint8 FR_RDR_Obj_AlvAge24Val;
  uint8 FR_RDR_Obj_AlvAge25Val;
  uint8 FR_RDR_Obj_AlvAge26Val;
  uint8 FR_RDR_Obj_AlvAge27Val;
  uint8 FR_RDR_Obj_AlvAge28Val;
  uint8 FR_RDR_Obj_AlvAge29Val;
  uint8 FR_RDR_Obj_AlvAge30Val;
  uint8 FR_RDR_Obj_AlvAge31Val;
  uint8 FR_RDR_Obj_AlvAge32Val;
  uint8 FR_RDR_Obj_CoastAge01Val;
  uint8 FR_RDR_Obj_CoastAge02Val;
  uint8 FR_RDR_Obj_CoastAge03Val;
  uint8 FR_RDR_Obj_CoastAge04Val;
  uint8 FR_RDR_Obj_CoastAge05Val;
  uint8 FR_RDR_Obj_CoastAge06Val;
  uint8 FR_RDR_Obj_CoastAge07Val;
  uint8 FR_RDR_Obj_CoastAge08Val;
  uint8 FR_RDR_Obj_CoastAge09Val;
  uint8 FR_RDR_Obj_CoastAge10Val;
  uint8 FR_RDR_Obj_CoastAge11Val;
  uint8 FR_RDR_Obj_CoastAge12Val;
  uint8 FR_RDR_Obj_CoastAge13Val;
  uint8 FR_RDR_Obj_CoastAge14Val;
  uint8 FR_RDR_Obj_CoastAge15Val;
  uint8 FR_RDR_Obj_CoastAge16Val;
  uint8 FR_RDR_Obj_CoastAge17Val;
  uint8 FR_RDR_Obj_CoastAge18Val;
  uint8 FR_RDR_Obj_CoastAge19Val;
  uint8 FR_RDR_Obj_CoastAge20Val;
  uint8 FR_RDR_Obj_CoastAge21Val;
  uint8 FR_RDR_Obj_CoastAge22Val;
  uint8 FR_RDR_Obj_CoastAge23Val;
  uint8 FR_RDR_Obj_CoastAge24Val;
  uint8 FR_RDR_Obj_CoastAge25Val;
  uint8 FR_RDR_Obj_CoastAge26Val;
  uint8 FR_RDR_Obj_CoastAge27Val;
  uint8 FR_RDR_Obj_CoastAge28Val;
  uint8 FR_RDR_Obj_CoastAge29Val;
  uint8 FR_RDR_Obj_CoastAge30Val;
  uint8 FR_RDR_Obj_CoastAge31Val;
  uint8 FR_RDR_Obj_CoastAge32Val;
  uint8 FR_RDR_Obj_MedRangeMod01Val;
  uint8 FR_RDR_Obj_MedRangeMod02Val;
  uint8 FR_RDR_Obj_MedRangeMod03Val;
  uint8 FR_RDR_Obj_MedRangeMod04Val;
  uint8 FR_RDR_Obj_MedRangeMod05Val;
  uint8 FR_RDR_Obj_MedRangeMod06Val;
  uint8 FR_RDR_Obj_MedRangeMod07Val;
  uint8 FR_RDR_Obj_MedRangeMod08Val;
  uint8 FR_RDR_Obj_MedRangeMod09Val;
  uint8 FR_RDR_Obj_MedRangeMod10Val;
  uint8 FR_RDR_Obj_MedRangeMod11Val;
  uint8 FR_RDR_Obj_MedRangeMod12Val;
  uint8 FR_RDR_Obj_MedRangeMod13Val;
  uint8 FR_RDR_Obj_MedRangeMod14Val;
  uint8 FR_RDR_Obj_MedRangeMod15Val;
  uint8 FR_RDR_Obj_MedRangeMod16Val;
  uint8 FR_RDR_Obj_MedRangeMod17Val;
  uint8 FR_RDR_Obj_MedRangeMod18Val;
  uint8 FR_RDR_Obj_MedRangeMod19Val;
  uint8 FR_RDR_Obj_MedRangeMod20Val;
  uint8 FR_RDR_Obj_MedRangeMod21Val;
  uint8 FR_RDR_Obj_MedRangeMod22Val;
  uint8 FR_RDR_Obj_MedRangeMod23Val;
  uint8 FR_RDR_Obj_MedRangeMod24Val;
  uint8 FR_RDR_Obj_MedRangeMod25Val;
  uint8 FR_RDR_Obj_MedRangeMod26Val;
  uint8 FR_RDR_Obj_MedRangeMod27Val;
  uint8 FR_RDR_Obj_MedRangeMod28Val;
  uint8 FR_RDR_Obj_MedRangeMod29Val;
  uint8 FR_RDR_Obj_MedRangeMod30Val;
  uint8 FR_RDR_Obj_MedRangeMod31Val;
  uint8 FR_RDR_Obj_MedRangeMod32Val;
  uint8 FR_RDR_Obj_RefObjID01Val;
  uint8 FR_RDR_Obj_RefObjID02Val;
  uint8 FR_RDR_Obj_RefObjID03Val;
  uint8 FR_RDR_Obj_RefObjID04Val;
  uint8 FR_RDR_Obj_RefObjID05Val;
  uint8 FR_RDR_Obj_RefObjID06Val;
  uint8 FR_RDR_Obj_RefObjID07Val;
  uint8 FR_RDR_Obj_RefObjID08Val;
  uint8 FR_RDR_Obj_RefObjID09Val;
  uint8 FR_RDR_Obj_RefObjID10Val;
  uint8 FR_RDR_Obj_RefObjID11Val;
  uint8 FR_RDR_Obj_RefObjID12Val;
  uint8 FR_RDR_Obj_RefObjID13Val;
  uint8 FR_RDR_Obj_RefObjID14Val;
  uint8 FR_RDR_Obj_RefObjID15Val;
  uint8 FR_RDR_Obj_RefObjID16Val;
  uint8 FR_RDR_Obj_RefObjID17Val;
  uint8 FR_RDR_Obj_RefObjID18Val;
  uint8 FR_RDR_Obj_RefObjID19Val;
  uint8 FR_RDR_Obj_RefObjID20Val;
  uint8 FR_RDR_Obj_RefObjID21Val;
  uint8 FR_RDR_Obj_RefObjID22Val;
  uint8 FR_RDR_Obj_RefObjID23Val;
  uint8 FR_RDR_Obj_RefObjID24Val;
  uint8 FR_RDR_Obj_RefObjID25Val;
  uint8 FR_RDR_Obj_RefObjID26Val;
  uint8 FR_RDR_Obj_RefObjID27Val;
  uint8 FR_RDR_Obj_RefObjID28Val;
  uint8 FR_RDR_Obj_RefObjID29Val;
  uint8 FR_RDR_Obj_RefObjID30Val;
  uint8 FR_RDR_Obj_RefObjID31Val;
  uint8 FR_RDR_Obj_RefObjID32Val;
  uint8 FR_RDR_DTC_RadarAliveCounter;
  uint8 FR_RDR_DTC_BatteryVoltageHigh;
  uint8 FR_RDR_DTC_BatteryVoltageLow;
  uint8 FR_RDR_DTC_RadarHwError;
  uint8 FR_RDR_DTC_SystemOutOfCalibration_EOL;
  uint8 FR_RDR_DTC_SystemOutOfCalibration_DRV;
  uint8 FR_RDR_DTC_Blockage_Init;
  uint8 FR_RDR_DTC_Blockage_Drv;
  uint8 FR_RDR_DTC_RadarHwTempCondition_High;
  uint8 FR_RDR_DTC_RadarHwTempCondition_Low;
  uint8 FR_RDR_DTC_RadarCANCommError;
  boolean FR_RDR_Det_Mov01;
  boolean FR_RDR_Det_Mov02;
  boolean FR_RDR_Det_Mov03;
  boolean FR_RDR_Det_Mov04;
  boolean FR_RDR_Det_Mov05;
  boolean FR_RDR_Det_Mov06;
  boolean FR_RDR_Det_Mov07;
  boolean FR_RDR_Det_Mov08;
  boolean FR_RDR_Det_Mov09;
  boolean FR_RDR_Det_Mov10;
  boolean FR_RDR_Det_Mov11;
  boolean FR_RDR_Det_Mov12;
  boolean FR_RDR_Det_Mov13;
  boolean FR_RDR_Det_Mov14;
  boolean FR_RDR_Det_Mov15;
  boolean FR_RDR_Det_Mov16;
  boolean FR_RDR_Det_Mov17;
  boolean FR_RDR_Det_Mov18;
  boolean FR_RDR_Det_Mov19;
  boolean FR_RDR_Det_Mov20;
  boolean FR_RDR_Det_Mov21;
  boolean FR_RDR_Det_Mov22;
  boolean FR_RDR_Det_Mov23;
  boolean FR_RDR_Det_Mov24;
  boolean FR_RDR_Det_Mov25;
  boolean FR_RDR_Det_Mov26;
  boolean FR_RDR_Det_Mov27;
  boolean FR_RDR_Det_Mov28;
  boolean FR_RDR_Det_Mov29;
  boolean FR_RDR_Det_Mov30;
  boolean FR_RDR_Det_Mov31;
  boolean FR_RDR_Det_Mov32;
  boolean FR_RDR_Det_Mov33;
  boolean FR_RDR_Det_Mov34;
  boolean FR_RDR_Det_Mov35;
  boolean FR_RDR_Det_Mov36;
  boolean FR_RDR_Det_Mov37;
  boolean FR_RDR_Det_Mov38;
  boolean FR_RDR_Det_Mov39;
  boolean FR_RDR_Det_Mov40;
  boolean FR_RDR_Det_Mov41;
  boolean FR_RDR_Det_Mov42;
  boolean FR_RDR_Det_Mov43;
  boolean FR_RDR_Det_Mov44;
  boolean FR_RDR_Det_Mov45;
  boolean FR_RDR_Det_Mov46;
  boolean FR_RDR_Det_Mov47;
  boolean FR_RDR_Det_Mov48;
  boolean FR_RDR_Det_Mov49;
  boolean FR_RDR_Det_Mov50;
  boolean FR_RDR_Det_Mov51;
  boolean FR_RDR_Det_Mov52;
  boolean FR_RDR_Det_Mov53;
  boolean FR_RDR_Det_Mov54;
  boolean FR_RDR_Det_Mov55;
  boolean FR_RDR_Det_Mov56;
  boolean FR_RDR_Det_Mov57;
  boolean FR_RDR_Det_Mov58;
  boolean FR_RDR_Det_Mov59;
  boolean FR_RDR_Det_Mov60;
  boolean FR_RDR_Det_Mov61;
  boolean FR_RDR_Det_Mov62;
  boolean FR_RDR_Det_Mov63;
  boolean FR_RDR_Det_Mov64;
  boolean FR_RDR_Det_Valid01;
  boolean FR_RDR_Det_Valid02;
  boolean FR_RDR_Det_Valid03;
  boolean FR_RDR_Det_Valid04;
  boolean FR_RDR_Det_Valid05;
  boolean FR_RDR_Det_Valid06;
  boolean FR_RDR_Det_Valid07;
  boolean FR_RDR_Det_Valid08;
  boolean FR_RDR_Det_Valid09;
  boolean FR_RDR_Det_Valid10;
  boolean FR_RDR_Det_Valid11;
  boolean FR_RDR_Det_Valid12;
  boolean FR_RDR_Det_Valid13;
  boolean FR_RDR_Det_Valid14;
  boolean FR_RDR_Det_Valid15;
  boolean FR_RDR_Det_Valid16;
  boolean FR_RDR_Det_Valid17;
  boolean FR_RDR_Det_Valid18;
  boolean FR_RDR_Det_Valid19;
  boolean FR_RDR_Det_Valid20;
  boolean FR_RDR_Det_Valid21;
  boolean FR_RDR_Det_Valid22;
  boolean FR_RDR_Det_Valid23;
  boolean FR_RDR_Det_Valid24;
  boolean FR_RDR_Det_Valid25;
  boolean FR_RDR_Det_Valid26;
  boolean FR_RDR_Det_Valid27;
  boolean FR_RDR_Det_Valid28;
  boolean FR_RDR_Det_Valid29;
  boolean FR_RDR_Det_Valid30;
  boolean FR_RDR_Det_Valid31;
  boolean FR_RDR_Det_Valid32;
  boolean FR_RDR_Det_Valid33;
  boolean FR_RDR_Det_Valid34;
  boolean FR_RDR_Det_Valid35;
  boolean FR_RDR_Det_Valid36;
  boolean FR_RDR_Det_Valid37;
  boolean FR_RDR_Det_Valid38;
  boolean FR_RDR_Det_Valid39;
  boolean FR_RDR_Det_Valid40;
  boolean FR_RDR_Det_Valid41;
  boolean FR_RDR_Det_Valid42;
  boolean FR_RDR_Det_Valid43;
  boolean FR_RDR_Det_Valid44;
  boolean FR_RDR_Det_Valid45;
  boolean FR_RDR_Det_Valid46;
  boolean FR_RDR_Det_Valid47;
  boolean FR_RDR_Det_Valid48;
  boolean FR_RDR_Det_Valid49;
  boolean FR_RDR_Det_Valid50;
  boolean FR_RDR_Det_Valid51;
  boolean FR_RDR_Det_Valid52;
  boolean FR_RDR_Det_Valid53;
  boolean FR_RDR_Det_Valid54;
  boolean FR_RDR_Det_Valid55;
  boolean FR_RDR_Det_Valid56;
  boolean FR_RDR_Det_Valid57;
  boolean FR_RDR_Det_Valid58;
  boolean FR_RDR_Det_Valid59;
  boolean FR_RDR_Det_Valid60;
  boolean FR_RDR_Det_Valid61;
  boolean FR_RDR_Det_Valid62;
  boolean FR_RDR_Det_Valid63;
  boolean FR_RDR_Det_Valid64;
} RdrInfo_t;

#  define Rte_TypeDef_ReversibleFailreDataType_t
typedef struct
{
  uint8 FR_CMR_Blockage;
  uint8 FR_CMR_Over_Temp;
  uint8 FR_CMR_SW_Reset;
  uint8 FR_CMR_HW_Reset;
  uint8 FR_RDR_Bloackage;
  uint8 FR_RDR_Over_Temp;
  uint8 FR_RDR_SW_Reset;
  uint8 FR_RDR_HW_Reset;
  uint32 OdometerValue;
} ReversibleFailreDataType_t;

#  define Rte_TypeDef_SccAppVersionInfo_t
typedef struct
{
  uint16 u16_SccAppVersionInfo;
} SccAppVersionInfo_t;

#  define Rte_TypeDef_SccCanSigFailSafeInfo_t
typedef struct
{
  boolean b_C110117_Battery_Voltage_High;
  boolean b_C110216_Battery_Voltage_Low;
  boolean b_C160449_ECU_Hardware_Error;
  boolean b_C160649_ECU_Software_Error;
  boolean b_C160A87_Local_CAN_Bus_Off;
  boolean b_C160C87_Local_CAN_Time_Out;
  boolean b_C161187_CAN_Time_Out_EMS;
  boolean b_C161487_CAN_Time_Out_HCU;
  boolean b_C161287_CAN_Time_Out_TCU;
  boolean b_C161386_CAN_Signal_Error_EMS;
  boolean b_C161C86_CAN_Signal_Error_HCU;
  boolean b_C161E87_E_CAN_Bus_Off;
  boolean b_C162387_CAN_Time_Out_SAS;
  boolean b_C162587_CAN_Time_Out_ABS_ESP;
  boolean b_C162887_CAN_Time_Out_CLU;
  boolean b_C164286_CAN_Msg_Failure_brake;
  boolean b_C164686_CAN_Signal_Error_TCU;
  boolean b_C165686_CAN_Signal_Error_CLU;
  boolean b_C28B881_ESP_Reversible_Error;
  boolean b_C170246_Variant_Coding_Error;
  boolean b_C174281_Variant_Error_ESC;
  boolean b_B26A687_CAN_Time_Out_ICU;
  boolean b_C183186_CAN_Signal_Error_NAVI;
  boolean b_C184286_YRS_Not_valid;
  boolean b_C186387_CAN_Time_Out_NAVI_forHDA;
  boolean b_C272146_System_Calibration_Required;
  boolean b_C272246_System_Out_Calibration;
  boolean b_No222_CAN_Msg_Failure_brake_DiagMode;
  boolean b_C166987_CAN_Time_Out_ACU;
  boolean b_C183C86_CAN_Msg_Failure_ICU;
  boolean b_C181486_CAN_Msg_Failure_SAS;
  boolean b_C16B902_FCASCC_Communication_Error;
  boolean b_C135F81_HCU_Trq_Ctrl_Unavailable;
  boolean b_C167A87_CAN_Time_Out_NAVI;
  boolean b_C2A2397_Front_Camera_Blockage;
  boolean b_C2A274B_Front_Camera_OverTemp;
  boolean b_B26A987_CANTime_Out_HOD;
  boolean b_C225387_CANTime_Out_IBU;
  boolean b_C186A87_CANTime_Out_ILCU_LH;
  boolean b_C186B87_CANTime_Out_ILCU_RH;
  boolean b_C185087_CANTime_Out_MFSW;
  boolean b_C168787_CANTime_Out_VSM2;
  boolean b_C168886_VSM2_Signal_Error;
  boolean b_C223986_MDPS_Steering_Control_Failure_LKA;
  boolean b_C290386_Invalid_Signal_HOD;
  boolean b_C28C586_Lateral_Control_Failure;
  boolean b_C170255_Variant_Coding_Error;
  boolean b_C183129_CAN_Signal_Error_NAVI;
  boolean b_C28AC87_CANTime_Out_SWRC;
  boolean b_C183D86_CANMsg_Failure_SWRC;
} SccCanSigFailSafeInfo_t;

#  define Rte_TypeDef_SccInputFromFca_t
typedef struct
{
  uint8 u8_Radar_Match_Ch_1;
  uint8 u8_Radar_Match_Ch_2;
  uint8 u8_Radar_Match_Ch_3;
  uint8 u8_Radar_Match_Ch_4;
  uint8 u8_Radar_Match_Ch_5;
  uint8 u8_Radar_Match_Ch_6;
  uint8 u8_Radar_Match_Ch_7;
  uint8 u8_Radar_Match_Ch_8;
  uint8 u8_Radar_Match_ID_1;
  uint8 u8_Radar_Match_ID_2;
  uint8 u8_Radar_Match_ID_3;
  uint8 u8_Radar_Match_ID_4;
  uint8 u8_Radar_Match_ID_5;
  uint8 u8_Radar_Match_ID_6;
  uint8 u8_Radar_Match_ID_7;
  uint8 u8_Radar_Match_ID_8;
  uint8 u8_Radar_Match_Flag_1;
  uint8 u8_Radar_Match_Flag_2;
  uint8 u8_Radar_Match_Flag_3;
  uint8 u8_Radar_Match_Flag_4;
  uint8 u8_Radar_Match_Flag_5;
  uint8 u8_Radar_Match_Flag_6;
  uint8 u8_Radar_Match_Flag_7;
  uint8 u8_Radar_Match_Flag_8;
  uint8 u8_Radar_Match_Value_1;
  uint8 u8_Radar_Match_Value_2;
  uint8 u8_Radar_Match_Value_3;
  uint8 u8_Radar_Match_Value_4;
  uint8 u8_Radar_Match_Value_5;
  uint8 u8_Radar_Match_Value_6;
  uint8 u8_Radar_Match_Value_7;
  uint8 u8_Radar_Match_Value_8;
  uint16 u16_Radar_Match_Value1_1;
  uint16 u16_Radar_Match_Value1_2;
  uint16 u16_Radar_Match_Value1_3;
  uint16 u16_Radar_Match_Value1_4;
  uint16 u16_Radar_Match_Value1_5;
  uint16 u16_Radar_Match_Value1_6;
  uint16 u16_Radar_Match_Value1_7;
  uint16 u16_Radar_Match_Value1_8;
} SccInputFromFca_t;

#  define Rte_TypeDef_SccInputFromVCan_t
typedef struct
{
  uint8 u8_HDA_CntrlModSta;
  uint8 u8_HDA_TDMRMDclReq;
  uint8 u8_ISLA_OptUsmSta;
  uint8 u8_ISLA_SpdwOffst;
  uint8 u8_ISLA_SwIgnoreReq;
  uint8 u8_ISLA_SpdChgReq;
  uint8 u8_ISLW_SpdCluMainDis;
  uint8 u8_ISLW_SysSta;
} SccInputFromVCan_t;

#  define Rte_TypeDef_SccInput_t
typedef struct
{
  uint8 u8_HDA_CntrlModSta;
  uint8 u8_HDA_TDMRMDclReq;
  uint8 u8_ISLA_SpdwOffst;
  uint8 u8_ISLA_SwIgnoreReq;
  uint8 u8_ISLA_SpdChgReq;
  uint8 u8_FCA_PartialActvReq;
  uint8 u8_FCA_FullActvReq;
  uint8 u8_FCA_DclReqVal;
  uint8 u8_FCA_WrngLvlSta;
  uint8 u8_HDA_LFA_SymSta;
  uint8 u8_HDA_InfoPUDis;
} SccInput_t;

#  define Rte_TypeDef_SccInternalInFromLSS_t
typedef struct
{
  uint8 u8_Hands_On_Status;
  uint8 u8_LFA_Failure_Status;
} SccInternalInFromLSS_t;

#  define Rte_TypeDef_SccInternalOutToFca_t
typedef struct
{
  uint8 u8_SCC_InfoDis;
  uint8 u8_SCC_OpSta;
  uint8 u8_NSCC_Inibit;
} SccInternalOutToFca_t;

#  define Rte_TypeDef_SccOutput_t
typedef struct
{
  uint8 u8_SCC_MainOnOffSta;
  uint8 u8_SCC_InfoDis;
  uint8 u8_SCC_DrvAlrtDis;
  uint8 u8_SCC_TakeoverReq;
  uint8 u8_SCC_TrgtSpdSetVal;
  uint8 u8_SCC_SysFlrSta;
  uint16 u16_SCC_AccelReqVal;
  uint16 u16_SCC_AccelReqRawVal;
  uint8 u8_SCC_VehStpReq;
  uint8 u8_SCC_HeadwayDstSetVal;
  uint8 u8_SCC_AccelLimBandLwrVal;
  uint8 u8_SCC_AccelLimBandUppVal;
  uint8 u8_SCC_JrkLwrLimVal;
  uint8 u8_SCC_JrkUppLimVal;
  uint8 u8_SCC_ObjSta;
  uint16 u16_SCC_ObjDstVal;
  uint16 u16_SCC_ObjLatPosVal;
  uint16 u16_SCC_ObjRelSpdVal;
  uint16 u16_SCC_TrgtDstVal;
  uint8 u8_SCC_OpSta;
  uint8 u8_SCC_NSCCOpSta;
  uint8 u8_SCC_NSCCOnOffSta;
  uint8 u8_SCC_SnstvtyModRetVal;
  uint8 u8_ADAS_CMD_AlvCnt20Val;
  uint16 u8_ADAS_CMD_Crc20Val;
  uint8 u8_SCC_NSCCInfoPUDis;
  uint8 u8_SCC_EngStateReq;
  uint8 u8_ADAS_DrUnlckReqSta;
  uint8 u8_ADAS_HzrdLmpReqVal;
  uint8 u8_NSCC_Op2Sta;
  uint8 u8_SCC_Char1Sta;
  uint8 u8_SCC_Char2Sta;
  uint8 u8_SCC_Char3Sta;
} SccOutput_t;

#  define Rte_TypeDef_SccRdrBlockage_t
typedef struct
{
  uint8 u8_Blockage_Drv;
  uint8 u8_Blockage_Init;
} SccRdrBlockage_t;

#  define Rte_TypeDef_SccRdrSigFailSafeInfoOverPCan_t
typedef struct
{
  uint8 p_FrRdrInitBlockage_Fail;
  uint8 p_FrRdrBlockage_Fail;
  uint8 p_FrRdrHighVolt_Fail;
  uint8 p_FrRdrLowVolt_Fail;
  uint8 p_FrRdrAlignmentEOL_Fail;
  uint8 p_FrRdrAlignmentDrvng_Fail;
  uint8 p_FrRdrCanComm_Fail;
  uint8 p_FrRdrOvrTemp_Fail;
  uint8 p_FrRdrUdrTemp_Fail;
} SccRdrSigFailSafeInfoOverPCan_t;

#  define Rte_TypeDef_SccRdrSigFailSafeInfoSystemFailure_t
typedef struct
{
  uint8 p_FrRdrHw_Fail;
  uint8 p_FrRdrAlignment_Fail;
  uint8 p_FrRdrVolt_Fail;
  uint8 p_FrRdrComm_Fail;
  uint8 p_FrRdrAliveCounter_Fail;
  uint8 p_FrRdrInitBlockage_Fail;
  uint8 p_FrRdrBlockage_Fail;
  uint8 p_FrRdrOvrTemp_Fail;
} SccRdrSigFailSafeInfoSystemFailure_t;

#  define Rte_TypeDef_SccRdrSigFailSafeInfo_t
typedef struct
{
  boolean b_No140_FrRdrHw_Fail;
  boolean b_No141_FrRdrAlignment_Fail;
  boolean b_No142_FrRdrVolt_Fail;
  boolean b_No143_FrRdrComm_Fail;
  boolean b_No144_FrRdrOvrTemp_Fail;
  boolean b_C28B181_CAN_Signal_Error_FR_RDR;
  uint8 u8_FrRdrBlockage_Fail;
  uint8 u8_FrRdrInitBlockage_Fail;
} SccRdrSigFailSafeInfo_t;

#  define Rte_TypeDef_SccUxOutToIvc_t
typedef struct
{
  uint8 ux_SMV_FrObjSta;
  uint8 ux_SMV_VehDstLvlVal;
  uint8 ux_SMV_VehDstLvlSta;
  uint8 ux_SMV_HostVehSta;
  uint8 ux_SMV_SetSpdSta_SCC;
  uint8 ux_SMV_SetSpdVal;
  uint8 ux_SMV_NSCC_SymbSta;
  uint8 ux_SMV_DrvAsstHUDSymbSta;
  uint8 ux_MV_VehDstSta;
  uint16 ux_MV_VehDstVal;
  uint8 ux_MV_HostVeh1Sta_SCC;
  uint8 ux_MV_FrObjSta;
  uint16 ux_MV_FrObjLongPosVal;
  sint8 ux_MV_FrObjLatPosVal;
  uint8 ux_PU_F_Group1_SCC_ADASWarn1_1Sta;
  uint8 ux_PU_F_Group4_SCC_ADASWarn1_1Sta;
  uint8 ux_PU_F_Group7_SCC_FlrSta;
  uint8 ux_PU_M_Group2_SCC_ADASWarn1_1Sta;
  uint8 ux_PU_M_Group2_NSCC_ADASWarn1_1Sta;
  uint8 ux_SCC_SND_ADASWarn1_1Sta;
  uint8 ux_HPT_StrWhlWarn1Sta_SCC;
} SccUxOutToIvc_t;

#  define Rte_TypeDef_VCanFcaInput_t
typedef struct
{
  uint8 SCC_InfoDis;
  uint8 SCC_OpSta;
} VCanFcaInput_t;

#  define Rte_TypeDef_VCanIslwInput_t
typedef struct
{
  uint8 u8_SCC_OpSta;
  uint8 u8_SCC_TrgtSpdSetVal;
  uint8 u8_SCC_NSCCAutoSetSpdSta;
  uint8 u8_SCC_FailInfo;
  uint8 u8_NSCC_Inibit;
} VCanIslwInput_t;

#  define Rte_TypeDef_VCanLssInput_t
typedef struct
{
  uint8 u8_FCA_Status;
  uint8 u8_FCA_FailInfo;
  uint8 u8_ACCMode;
  uint8 u8_SCC_InfoDisplay;
  uint8 u8_SCC_VSetDis;
  uint8 u8_SCC_MainMode_ACC;
  uint8 u8_SCC_ACCFailInfo;
} VCanLssInput_t;

#  define Rte_TypeDef_VCan_ENG_EngSta_t
typedef struct
{
  uint8 ENG_EngSta;
} VCan_ENG_EngSta_t;

#  define Rte_TypeDef_VCan_ENG_IsgSta_t
typedef struct
{
  uint8 ENG_IsgSta;
} VCan_ENG_IsgSta_t;

#  define Rte_TypeDef_ZfAppCameraState_t
typedef struct
{
  uint8 CameraState_u8;
  uint8 Camera_SubState_u8;
  uint8 Reserved1_u8;
  uint8 Reserved2_u8;
} ZfAppCameraState_t;

#  define Rte_TypeDef_COM_DT_AcuRstSta
typedef uint8 COM_DT_AcuRstSta;

#  define Rte_TypeDef_COM_DT_DATC_OutTempDispC
typedef uint8 COM_DT_DATC_OutTempDispC;

#  define Rte_TypeDef_COM_DT_DATC_OutTempDispF
typedef uint8 COM_DT_DATC_OutTempDispF;

#  define Rte_TypeDef_COM_DT_ESC_IMURstStaAck
typedef uint8 COM_DT_ESC_IMURstStaAck;

#  define Rte_TypeDef_COM_DT_META_V2_CyclicCounter
typedef uint8 COM_DT_META_V2_CyclicCounter;

#  define Rte_TypeDef_COM_DT_YRS_AcuRstSta
typedef uint8 COM_DT_YRS_AcuRstSta;

#  define Rte_TypeDef_ComM_InhibitionStatusType
typedef uint8 ComM_InhibitionStatusType;

#  define Rte_TypeDef_ComM_UserHandleType
typedef uint8 ComM_UserHandleType;

#  define Rte_TypeDef_Dem_DTCGroupType
typedef uint32 Dem_DTCGroupType;

#  define Rte_TypeDef_Dem_DTCStatusMaskType
typedef uint8 Dem_DTCStatusMaskType;

#  define Rte_TypeDef_Dem_EventIdType
typedef uint16 Dem_EventIdType;

#  define Rte_TypeDef_Dem_OperationCycleIdType
typedef uint8 Dem_OperationCycleIdType;

#  define Rte_TypeDef_Dem_RatioIdType
typedef uint16 Dem_RatioIdType;

#  define Rte_TypeDef_EcuM_TimeType
typedef uint32 EcuM_TimeType;

#  define Rte_TypeDef_EcuM_UserType
typedef uint8 EcuM_UserType;

#  define Rte_TypeDef_NvM_BlockIdType
typedef uint16 NvM_BlockIdType;

#  define Rte_TypeDef_Rte_Adc_ValueGroupType
typedef uint16 Rte_Adc_ValueGroupType;

#  define Rte_TypeDef_Rte_Dio_LevelType
typedef uint8 Rte_Dio_LevelType;

#  define Rte_TypeDef_TimeInMicrosecondsType
typedef uint32 TimeInMicrosecondsType;

#  define Rte_TypeDef_WdgM_CheckpointIdType
typedef uint16 WdgM_CheckpointIdType;

#  define Rte_TypeDef_WdgM_ModeType
typedef uint8 WdgM_ModeType;

#  define Rte_TypeDef_WdgM_SupervisedEntityIdType
typedef uint16 WdgM_SupervisedEntityIdType;

#  define Rte_TypeDef_uint8_ptr_ptr_t
typedef uint8_ptr_t * uint8_ptr_ptr_t;

#  define Rte_TypeDef_BswM_BswMPCAN_RteModeDclGroup
typedef uint8 BswM_BswMPCAN_RteModeDclGroup;

#  define Rte_TypeDef_BswM_BswMVCAN_RteModeDclGroup
typedef uint8 BswM_BswMVCAN_RteModeDclGroup;

#  define Rte_TypeDef_BswM_DNMT_PCAN_Rx
typedef uint8 BswM_DNMT_PCAN_Rx;

#  define Rte_TypeDef_BswM_DNMT_PCAN_Tx
typedef uint8 BswM_DNMT_PCAN_Tx;

#  define Rte_TypeDef_BswM_DNMT_VCAN_Rx
typedef uint8 BswM_DNMT_VCAN_Rx;

#  define Rte_TypeDef_BswM_DNMT_VCAN_Tx
typedef uint8 BswM_DNMT_VCAN_Tx;

#  define Rte_TypeDef_BswM_ESH_Mode
typedef uint8 BswM_ESH_Mode;

#  define Rte_TypeDef_BswM_ESH_RunRequest
typedef uint8 BswM_ESH_RunRequest;

#  define Rte_TypeDef_COM_DT_USM_ISLAOffSetReq
typedef uint8 COM_DT_USM_ISLAOffSetReq;

#  define Rte_TypeDef_ComM_ModeType
typedef uint8 ComM_ModeType;

#  define Rte_TypeDef_Dcm_CommunicationModeType
typedef uint8 Dcm_CommunicationModeType;

#  define Rte_TypeDef_Dcm_ConfirmationStatusType
typedef uint8 Dcm_ConfirmationStatusType;

#  define Rte_TypeDef_Dcm_ControlDtcSettingType
typedef uint8 Dcm_ControlDtcSettingType;

#  define Rte_TypeDef_Dcm_DiagnosticSessionControlType
typedef uint8 Dcm_DiagnosticSessionControlType;

#  define Rte_TypeDef_Dcm_EcuResetType
typedef uint8 Dcm_EcuResetType;

#  define Rte_TypeDef_Dcm_NegativeResponseCodeType
typedef uint8 Dcm_NegativeResponseCodeType;

#  define Rte_TypeDef_Dcm_OpStatusType
typedef uint8 Dcm_OpStatusType;

#  define Rte_TypeDef_Dcm_ProtocolType
typedef uint8 Dcm_ProtocolType;

#  define Rte_TypeDef_Dcm_RequestKindType
typedef uint8 Dcm_RequestKindType;

#  define Rte_TypeDef_Dcm_SecLevelType
typedef uint8 Dcm_SecLevelType;

#  define Rte_TypeDef_Dcm_SesCtrlType
typedef uint8 Dcm_SesCtrlType;

#  define Rte_TypeDef_Dem_DTCFormatType
typedef uint8 Dem_DTCFormatType;

#  define Rte_TypeDef_Dem_DTCKindType
typedef uint8 Dem_DTCKindType;

#  define Rte_TypeDef_Dem_DTCOriginType
typedef uint16 Dem_DTCOriginType;

#  define Rte_TypeDef_Dem_DTCSeverityType
typedef uint8 Dem_DTCSeverityType;

#  define Rte_TypeDef_Dem_DTRControlType
typedef uint8 Dem_DTRControlType;

#  define Rte_TypeDef_Dem_DebounceResetStatusType
typedef uint8 Dem_DebounceResetStatusType;

#  define Rte_TypeDef_Dem_DebouncingStateType
typedef uint8 Dem_DebouncingStateType;

#  define Rte_TypeDef_Dem_EventStatusType
typedef uint8 Dem_EventStatusType;

#  define Rte_TypeDef_Dem_IndicatorStatusType
typedef uint8 Dem_IndicatorStatusType;

#  define Rte_TypeDef_Dem_InitMonitorReasonType
typedef uint8 Dem_InitMonitorReasonType;

#  define Rte_TypeDef_Dem_IumprDenomCondIdType
typedef uint8 Dem_IumprDenomCondIdType;

#  define Rte_TypeDef_Dem_IumprDenomCondStatusType
typedef uint8 Dem_IumprDenomCondStatusType;

#  define Rte_TypeDef_Dem_IumprReadinessGroupType
typedef uint8 Dem_IumprReadinessGroupType;

#  define Rte_TypeDef_Dem_MonitorStatusType
typedef uint8 Dem_MonitorStatusType;

#  define Rte_TypeDef_Dem_OperationCycleStateType
typedef uint8 Dem_OperationCycleStateType;

#  define Rte_TypeDef_Dem_UdsStatusByteType
typedef uint8 Dem_UdsStatusByteType;

#  define Rte_TypeDef_EYEQDG_MsgValidType
typedef uint16 EYEQDG_MsgValidType;

#  define Rte_TypeDef_EYEQMESP_CalStatusType
typedef uint8 EYEQMESP_CalStatusType;

#  define Rte_TypeDef_EcuM_BootTargetType
typedef uint8 EcuM_BootTargetType;

#  define Rte_TypeDef_EcuM_ModeType
typedef uint8 EcuM_ModeType;

#  define Rte_TypeDef_EcuM_ShutdownCauseType
typedef uint8 EcuM_ShutdownCauseType;

#  define Rte_TypeDef_EcuM_StateType
typedef uint8 EcuM_StateType;

#  define Rte_TypeDef_EyeQSecurity_ActionType
typedef uint8 EyeQSecurity_ActionType;

#  define Rte_TypeDef_EyeQSecurity_DeviceType
typedef uint8 EyeQSecurity_DeviceType;

#  define Rte_TypeDef_EyeQSecurity_ResultsType
typedef uint8 EyeQSecurity_ResultsType;

#  define Rte_TypeDef_FeatureConfig_DbgMode_t
typedef uint8 FeatureConfig_DbgMode_t;

#  define Rte_TypeDef_IoHwAb_Heater_FailSafeStatusType
typedef uint8 IoHwAb_Heater_FailSafeStatusType;

#  define Rte_TypeDef_IoHwAb_Heater_StateType
typedef uint8 IoHwAb_Heater_StateType;

#  define Rte_TypeDef_IoHwAb_Thermal_Shutdown_SourceType
typedef uint8 IoHwAb_Thermal_Shutdown_SourceType;

#  define Rte_TypeDef_NvM_RequestResultType
typedef uint8 NvM_RequestResultType;

#  define Rte_TypeDef_NvM_ServiceIdType
typedef uint8 NvM_ServiceIdType;

#  define Rte_TypeDef_Rte_DT_VdVruSuppFlagInfo_t_0
typedef uint8 Rte_DT_VdVruSuppFlagInfo_t_0;

#  define Rte_TypeDef_Rte_DT_VdVruSuppFlagInfo_t_1
typedef uint8 Rte_DT_VdVruSuppFlagInfo_t_1;

#  define Rte_TypeDef_Rte_DT_VdVruSuppFlagInfo_t_2
typedef uint8 Rte_DT_VdVruSuppFlagInfo_t_2;

#  define Rte_TypeDef_Rte_DT_VdVruSuppFlagInfo_t_3
typedef uint8 Rte_DT_VdVruSuppFlagInfo_t_3;

#  define Rte_TypeDef_WdgMMode
typedef uint8 WdgMMode;

#  define Rte_TypeDef_WdgM_GlobalStatusType
typedef uint8 WdgM_GlobalStatusType;

#  define Rte_TypeDef_WdgM_LocalStatusType
typedef uint8 WdgM_LocalStatusType;

#  define Rte_TypeDef_EYEQP_EyeQResetTrackerType
typedef EYEQP_EyeQResetTracker_t EYEQP_EyeQResetTrackerType[220];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrCA_0
typedef ConstructionArea_t Rte_DT_ArrFrCmrCA_0[10];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrFS_0
typedef FailSafe_t Rte_DT_ArrFrCmrFS_0[3];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrFcfVd_0
typedef FcfVd_t Rte_DT_ArrFrCmrFcfVd_0[8];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrFcfVru_0
typedef FcfVru_t Rte_DT_ArrFrCmrFcfVru_0[8];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrLDW_0
typedef LDW_t Rte_DT_ArrFrCmrLDW_0[4];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrLnAdj_0
typedef LanesAdjacent_t Rte_DT_ArrFrCmrLnAdj_0[4];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrLnAppl_0
typedef LanesApplications_t Rte_DT_ArrFrCmrLnAppl_0[12];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrLnHost_0
typedef LanesHost_t Rte_DT_ArrFrCmrLnHost_0[2];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrLnRdEdg_0
typedef LanesRoadEdge_t Rte_DT_ArrFrCmrLnRdEdg_0[4];

#  define Rte_TypeDef_Rte_DT_ArrFrCmrObj_0
typedef Objects_t Rte_DT_ArrFrCmrObj_0[20];

#  define Rte_TypeDef_Rte_DT_Arr_FcfVd_0
typedef FCF_VD_t Rte_DT_Arr_FcfVd_0[8];

#  define Rte_TypeDef_Rte_DT_Arr_FcfVru_0
typedef FCF_VRU_t Rte_DT_Arr_FcfVru_0[6];

#  define Rte_TypeDef_Rte_DT_Arr_HbaInfo_0
typedef HbaObjectInfo_t Rte_DT_Arr_HbaInfo_0[10];

#  define Rte_TypeDef_Rte_DT_Arr_ObjInfo_0
typedef ObjInfo_t Rte_DT_Arr_ObjInfo_0[20];

#  define Rte_TypeDef_Rte_DT_Arr_TsrInfo_0
typedef IslwTSRInfo_t Rte_DT_Arr_TsrInfo_0[10];

#  define Rte_TypeDef_Rte_DT_CVD_VehicleTrackWidths_0
typedef Cvd_TrackWidthInput_t Rte_DT_CVD_VehicleTrackWidths_0[5];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_0
typedef CoFca_u32_15 Rte_DT_CoFcaNvmTunPara_t_0[20];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_1
typedef CoFca_u32_15 Rte_DT_CoFcaNvmTunPara_t_1[20];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_2
typedef CoFca_u16_16 Rte_DT_CoFcaNvmTunPara_t_2[20];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_3
typedef CoFca_u16_16 Rte_DT_CoFcaNvmTunPara_t_3[20];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_4
typedef CoFca_u8_15 Rte_DT_CoFcaNvmTunPara_t_4[20];

#  define Rte_TypeDef_Rte_DT_CoFcaNvmTunPara_t_5
typedef CoFca_u8_15 Rte_DT_CoFcaNvmTunPara_t_5[20];

#  define Rte_TypeDef_Rte_DT_EYEQEDR_BBHeaderResParams_t_1
typedef EYEQEDR_BBGetHeaderVO_t Rte_DT_EYEQEDR_BBHeaderResParams_t_1[41];

#  define Rte_TypeDef_Rte_DT_IslwFrqNvData_t_24
typedef Rte_DT_IslwFrqNvData_t_24_0 Rte_DT_IslwFrqNvData_t_24[3];

#  define Rte_TypeDef_s16_2D_array_4_4
typedef s16_array_4 s16_2D_array_4_4[4];

#  define Rte_TypeDef_s32_array_1_48
typedef s32_array_48 s32_array_1_48[1];

#  define Rte_TypeDef_s32_array_6_8
typedef s32_array_8 s32_array_6_8[6];

#  define Rte_TypeDef_u16_2D_array_1_16
typedef u16_array_16 u16_2D_array_1_16[1];

#  define Rte_TypeDef_u16_2D_array_1_25
typedef u16_array_25 u16_2D_array_1_25[1];

#  define Rte_TypeDef_u16_2D_array_4_4
typedef u16_array_4 u16_2D_array_4_4[4];

#  define Rte_TypeDef_u16_array_2_2
typedef u16_array_2 u16_array_2_2[2];

#  define Rte_TypeDef_u16_array_3_8
typedef u16_array_8 u16_array_3_8[3];

#  define Rte_TypeDef_u16_array_4_2
typedef u16_array_2 u16_array_4_2[4];

#  define Rte_TypeDef_u16_array_4_3
typedef u16_array_3 u16_array_4_3[4];

#  define Rte_TypeDef_u16_array_4_4
typedef u16_array_4 u16_array_4_4[4];

#  define Rte_TypeDef_u16_array_5_4
typedef u16_array_4 u16_array_5_4[5];

#  define Rte_TypeDef_u16_array_5_6
typedef u16_array_6 u16_array_5_6[5];

#  define Rte_TypeDef_u16_array_5_7
typedef u16_array_7 u16_array_5_7[5];

#  define Rte_TypeDef_u16_array_6_4
typedef u16_array_4 u16_array_6_4[6];

#  define Rte_TypeDef_u16_array_6_7
typedef u16_array_7 u16_array_6_7[6];

#  define Rte_TypeDef_u16_array_6_8
typedef u16_array_8 u16_array_6_8[6];

#  define Rte_TypeDef_u16_array_7_3
typedef u16_array_3 u16_array_7_3[7];

#  define Rte_TypeDef_u16_array_7_7
typedef u16_array_7 u16_array_7_7[7];

#  define Rte_TypeDef_u16_array_8_2
typedef u16_array_2 u16_array_8_2[8];

#  define Rte_TypeDef_u16_array_8_7
typedef u16_array_7 u16_array_8_7[8];

#  define Rte_TypeDef_u32_2D_array_1_42
typedef u32_array_42 u32_2D_array_1_42[1];

#  define Rte_TypeDef_u32_array_13_6
typedef u32_array_6 u32_array_13_6[13];

#  define Rte_TypeDef_u32_array_1_78
typedef u32_array_78 u32_array_1_78[1];

#  define Rte_TypeDef_u32_array_7_6
typedef u32_array_6 u32_array_7_6[7];

#  define Rte_TypeDef_u8_array_2_2
typedef u8_array_2 u8_array_2_2[2];

#  define Rte_TypeDef_u8_array_4_4
typedef u8_array_4 u8_array_4_4[4];

#  define Rte_TypeDef_u8_array_4_7
typedef u8_array_7 u8_array_4_7[4];

#  define Rte_TypeDef_AppWdgMonInfo
typedef struct
{
  WdgM_SupervisedEntityIdType LocalFirstExpiredSEID;
  uint8 AliveCnt_u8;
} AppWdgMonInfo;

#  define Rte_TypeDef_ArrFrCmrCA
typedef struct
{
  Rte_DT_ArrFrCmrCA_0 FrCmrCA;
} ArrFrCmrCA;

#  define Rte_TypeDef_ArrFrCmrFS
typedef struct
{
  Rte_DT_ArrFrCmrFS_0 FrCmrFS;
} ArrFrCmrFS;

#  define Rte_TypeDef_ArrFrCmrFcfVd
typedef struct
{
  Rte_DT_ArrFrCmrFcfVd_0 FrCmrFcfVd;
} ArrFrCmrFcfVd;

#  define Rte_TypeDef_ArrFrCmrFcfVru
typedef struct
{
  Rte_DT_ArrFrCmrFcfVru_0 FrCmrFcfVru;
} ArrFrCmrFcfVru;

#  define Rte_TypeDef_ArrFrCmrLDW
typedef struct
{
  Rte_DT_ArrFrCmrLDW_0 FrCmrLDW;
} ArrFrCmrLDW;

#  define Rte_TypeDef_ArrFrCmrLnAdj
typedef struct
{
  Rte_DT_ArrFrCmrLnAdj_0 FrCmrLnAdj;
} ArrFrCmrLnAdj;

#  define Rte_TypeDef_ArrFrCmrLnAppl
typedef struct
{
  Rte_DT_ArrFrCmrLnAppl_0 FrCmrLnAppl;
} ArrFrCmrLnAppl;

#  define Rte_TypeDef_ArrFrCmrLnHost
typedef struct
{
  Rte_DT_ArrFrCmrLnHost_0 FrCmrLnHost;
} ArrFrCmrLnHost;

#  define Rte_TypeDef_ArrFrCmrLnRdEdg
typedef struct
{
  Rte_DT_ArrFrCmrLnRdEdg_0 FrCmrLnRdEdg;
} ArrFrCmrLnRdEdg;

#  define Rte_TypeDef_ArrFrCmrObj
typedef struct
{
  Rte_DT_ArrFrCmrObj_0 FrCmrObj;
} ArrFrCmrObj;

#  define Rte_TypeDef_Arr_FcfVd
typedef struct
{
  Rte_DT_Arr_FcfVd_0 CMR_FCF_VD_DataInfo;
} Arr_FcfVd;

#  define Rte_TypeDef_Arr_FcfVru
typedef struct
{
  Rte_DT_Arr_FcfVru_0 CMR_FCF_VRU_DataInfo;
} Arr_FcfVru;

#  define Rte_TypeDef_Arr_HbaInfo
typedef struct
{
  Rte_DT_Arr_HbaInfo_0 HbaObjectInfo;
} Arr_HbaInfo;

#  define Rte_TypeDef_Arr_ObjInfo
typedef struct
{
  Rte_DT_Arr_ObjInfo_0 CMR_ObstacleDataInfo;
} Arr_ObjInfo;

#  define Rte_TypeDef_Arr_TsrInfo
typedef struct
{
  Rte_DT_Arr_TsrInfo_0 IslwTSRInfo;
} Arr_TsrInfo;

#  define Rte_TypeDef_COM_DT_SG_DATC_17_200ms_SignalGroup
typedef struct
{
  COM_DT_DATC_OutTempDispC DATC_OutTempDispC;
  COM_DT_DATC_OutTempDispF DATC_OutTempDispF;
} COM_DT_SG_DATC_17_200ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_IMU_01_10ms_SignalGroup
typedef struct
{
  COM_DT_IMU_AcuRstSta IMU_AcuRstSta;
  COM_DT_IMU_AlvCnt1Val IMU_AlvCnt1Val;
  COM_DT_IMU_Crc1Val IMU_Crc1Val;
  COM_DT_IMU_LatAccelSigSta IMU_LatAccelSigSta;
  COM_DT_IMU_LatAccelVal IMU_LatAccelVal;
  COM_DT_IMU_LongAccelSigSta IMU_LongAccelSigSta;
  COM_DT_IMU_LongAccelVal IMU_LongAccelVal;
  COM_DT_IMU_McuVoltSta IMU_McuVoltSta;
  COM_DT_IMU_RollRtVal IMU_RollRtVal;
  COM_DT_IMU_RollSigSta IMU_RollSigSta;
  COM_DT_IMU_SeralNumVal IMU_SeralNumVal;
  COM_DT_IMU_SnsrTempVal IMU_SnsrTempVal;
  COM_DT_IMU_SnsrTyp IMU_SnsrTyp;
  COM_DT_IMU_VerAccelSigSta IMU_VerAccelSigSta;
  COM_DT_IMU_VerAccelVal IMU_VerAccelVal;
  COM_DT_IMU_YawRtVal IMU_YawRtVal;
  COM_DT_IMU_YawSigSta IMU_YawSigSta;
} COM_DT_SG_IMU_01_10ms_SignalGroup;

#  define Rte_TypeDef_COM_DT_SG_YRS_01_10ms_SignalGroup
typedef struct
{
  COM_DT_YRS_AlvCnt1Val YRS_AlvCnt1Val;
  COM_DT_YRS_Crc1Val YRS_Crc1Val;
  COM_DT_YRS_LatAccelSigSta YRS_LatAccelSigSta;
  COM_DT_YRS_LatAccelVal YRS_LatAccelVal;
  COM_DT_YRS_LongAccelSigSta YRS_LongAccelSigSta;
  COM_DT_YRS_LongAccelVal YRS_LongAccelVal;
  COM_DT_YRS_YawRtVal YRS_YawRtVal;
  COM_DT_YRS_YawSigSta YRS_YawSigSta;
  COM_DT_YRS_AcuRstSta YRS_AcuRstSta;
} COM_DT_SG_YRS_01_10ms_SignalGroup;

#  define Rte_TypeDef_CVD_VehicleTrackWidths
typedef struct
{
  Rte_DT_CVD_VehicleTrackWidths_0 RecordElement;
} CVD_VehicleTrackWidths;

#  define Rte_TypeDef_CoFcaNvmTunPara_t
typedef struct
{
  Rte_DT_CoFcaNvmTunPara_t_0 a_CoFca_Class32_TableX;
  Rte_DT_CoFcaNvmTunPara_t_1 a_CoFca_Class32_TableY;
  Rte_DT_CoFcaNvmTunPara_t_2 a_CoFca_Class16_TableX;
  Rte_DT_CoFcaNvmTunPara_t_3 a_CoFca_Class16_TableY;
  Rte_DT_CoFcaNvmTunPara_t_4 a_CoFca_Class8_TableX;
  Rte_DT_CoFcaNvmTunPara_t_5 a_CoFca_Class8_TableY;
  uint32 p_CoFca_Class32_Parameter;
  uint16 p_CoFca_Class16_Parameter;
  uint16 p_CoFca_NVM_Brake_Act_Enable_flag;
  uint8 p_CoFca_NVM_HBA_Act_Enable_flag;
  uint8 p_CoFca_NVM_Brake_Supplier_Code;
  uint8 p_CoFca_Class8_Parameter;
} CoFcaNvmTunPara_t;

#  define Rte_TypeDef_DawOccNvData_t
typedef struct
{
  uint16 u16_LVDA_CHK_INTEGRITY_DIST_M;
  uint16 u16_LVDA_CHK_INTEGRITY_SPD_MPS;
  uint8 u8_PAR_MIN_DISTANCE;
  uint8 u8_PAR_MIN_SPEED;
  uint8 u8_PAR_DISTANCE_FV;
  uint8 u8_PAR_TIME_STOP;
  uint8 u8_PAR_SPEED_FV;
  uint8 u8_PAR_MOVING_DISTANCE_FV;
  uint8 u8_PAR_TIME_LVDA_POPUP;
  uint8 u8_LVDA_TIME_TRG_ALRM_SMPL;
  uint8 u8_LVDA_CHK_INTEGRITY_TIME_SMPL;
  Rte_DT_DawOccNvData_t_11 u8a_Reserved;
} DawOccNvData_t;

#  define Rte_TypeDef_DtcFaultSts_t
typedef struct
{
  Rte_DT_DtcFaultSts_t_0 u8_DtcFaultSts;
} DtcFaultSts_t;

#  define Rte_TypeDef_DvTest_Mode_t
typedef struct
{
  uint8 DvTest_Mode;
  u8_array_3 Reserved_u8;
} DvTest_Mode_t;

#  define Rte_TypeDef_EDR_NvData_t
typedef struct
{
  Rte_DT_EDR_NvData_t_0 Data;
} EDR_NvData_t;

#  define Rte_TypeDef_EYEQCAM_CamHwCalParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  Rte_DT_EYEQCAM_CamHwCalParams_t_2 OTP_Data_au8;
  Rte_DT_EYEQCAM_CamHwCalParams_t_3 Chip_Revision_Number_u8;
  Rte_DT_EYEQCAM_CamHwCalParams_t_4 Reserved_u8;
  uint16 calCRC_u16;
} EYEQCAM_CamHwCalParams_t;

#  define Rte_TypeDef_EYEQDG_InputSignals_t
typedef struct
{
  uint64 MCUSyncTimestamp_u64;
  uint32 WheelTicksTimestampFL_u32;
  uint32 WheelTicksTimestampFR_u32;
  uint32 WheelTicksTimestampRL_u32;
  uint32 WheelTicksTimestampRR_u32;
  uint16 VehicleSpeed_u16;
  uint16 VehicleYaw_u16;
  uint16 LatAccel_u16;
  sint16 SteeringWheelAngle_s16;
  uint16 AccelRate_u16;
  uint16 AmbientLightLevel_u16;
  uint16 VehicleDisplaySpeed_u16;
  sint16 EffectiveSteerAxleAngle_s16;
  sint16 SuspHeightDelta_s16;
  uint16 VSpeedHiPrecision_u16;
  uint16 GSensorAccPitch_u16;
  uint16 GSensorGyroPitchRate_u16;
  uint16 GSensorGyroRollRate_u16;
  uint16 GSensorWheelSpeedFL_u16;
  uint16 GSensorWheelSpeedFR_u16;
  uint16 GSensorWheelSpeedRL_u16;
  uint16 GSensorWheelSpeedRR_u16;
  uint16 ExternalTemp_u16;
  sint16 FrontWheelsAngle_s16;
  uint16 Reserved0_u16;
  uint16 SuspFL_u16;
  uint16 SuspFR_u16;
  uint16 SuspRL_u16;
  uint16 SuspRR_u16;
  uint16 WheelTicksFL_u16;
  uint16 WheelTicksFR_u16;
  uint16 WheelTicksRL_u16;
  uint16 WheelTicksRR_u16;
  uint16 BrakePedalPressureRate_u16;
  uint16 AEBPressure_u16;
  uint16 SteeringWheelAngleSpeed_u16;
  uint16 Reserved_u16;
  uint8 VehicleSpeedValid_u8;
  uint8 VehicleYawValid_u8;
  uint8 LatAccelValid_u8;
  uint8 WiperStatusValid_u8;
  uint8 WiperStatus_u8;
  uint8 ReverseIndicator_u8;
  uint8 ReverseIndicatorValid_u8;
  uint8 SteeringWheelAngleValid_u8;
  uint8 TurnSwitchStatus_u8;
  uint8 HighBeamActive_u8;
  uint8 FogLightActive_u8;
  uint8 AccelPedalValue_u8;
  uint8 AccelPedalValid_u8;
  uint8 AccelRateValid_u8;
  uint8 AmbientLightLevelValid_u8;
  uint8 BrakePedalPosition_u8;
  uint8 BrakePedalPressed_u8;
  uint8 BrakePedalPressedValid_u8;
  uint8 VehicleDisplaySpeedValid_u8;
  uint8 MCUSyncTimestampValid_u8;
  uint8 SuspHeightDeltaValid_u8;
  uint8 SuspHeightDeprecated_u8;
  uint8 VSpeedHiPrecisionValid_u8;
  uint8 GpsCountryCodeCapital_u8;
  uint8 GpsCountryCodeFirstChar_u8;
  uint8 GpsCountryCodeSecondChar_u8;
  uint8 AEBBrakeActivated_u8;
  uint8 AEBBrakeValid_u8;
  uint8 TirePreassurePsiFLValid_u8;
  uint8 TirePreassurePsiFRValid_u8;
  uint8 TirePreassurePsiRLValid_u8;
  uint8 TirePreassurePsiRRValid_u8;
  uint8 TirePreassurePsiFL_u8;
  uint8 TirePreassurePsiFR_u8;
  uint8 TirePreassurePsiRL_u8;
  uint8 TirePreassurePsiRR_u8;
  uint8 AccPitchValid_u8;
  uint8 GyroPitchRateValid_u8;
  uint8 GyroRollRateValid_u8;
  uint8 WheelSpeedFLValid_u8;
  uint8 WheelSpeedFRValid_u8;
  uint8 WheelSpeedRLValid_u8;
  uint8 WheelSpeedRRValid_u8;
  uint8 WheelDirectionFLValid_u8;
  uint8 WheelDirectionFRValid_u8;
  uint8 WheelDirectionRLValid_u8;
  uint8 WheelDirectionRRValid_u8;
  uint8 WheelDirectionFL_u8;
  uint8 WheelDirectionFR_u8;
  uint8 WheelDirectionRL_u8;
  uint8 WheelDirectionRR_u8;
  uint8 FcaGapSensitivityValid_u8;
  uint8 FcaGapSensitivity_u8;
  uint8 PcwGapSensitivityValid_u8;
  uint8 PcwGapSensitivity_u8;
  uint8 DriverAwarenessValid_u8;
  uint8 DriverAwareness_u8;
  uint8 ExternalTempValid_u8;
  uint8 ReduceSenseForceActivation_u8;
  uint8 Reduce_enseForceActivationValid_u8;
  uint8 StandStillValid_u8;
  uint8 StandStill_u8;
  uint8 FrontWheelsAngleValid_u8;
  uint8 SuspPitchDeltaValid_u8;
  sint8 SuspPitchDelta_s8;
  uint8 SuspRollDeltaValid_u8;
  sint8 SuspRollDelta_s8;
  uint8 SuspFLValid_u8;
  uint8 SuspFRValid_u8;
  uint8 SuspRLValid_u8;
  uint8 SuspRRValid_u8;
  uint8 WheelTicksFLValid_u8;
  uint8 WheelTicksFRValid_u8;
  uint8 WheelTicksRLValid_u8;
  uint8 WheelTicksRRValid_u8;
  uint8 WheelTicksTimestampFLValid_u8;
  uint8 WheelTicksTimestampFRValid_u8;
  uint8 WheelTicksTimestampRLValid_u8;
  uint8 WheelTicksTimestampRRValid_u8;
  uint8 AccIsOn_u8;
  uint8 AccIsOnValid_u8;
  uint8 AccStatusAvailable_u8;
  uint8 AccStatusAvailableValid_u8;
  uint8 AccBraking_u8;
  uint8 AccBrakingValid_u8;
  uint8 VehicleCode_u8;
  uint8 SPCTrigger_u8;
  uint8 SPCTriggerValid_u8;
  uint8 MovablePartsUnlocked_u8;
  uint8 MovablePartsUnlockedValid_u8;
  uint8 BrakePedalPressureRateValid_u8;
  uint8 AEBPressureValid_u8;
  uint8 BrakePedalPressure_u8;
  uint8 BrakePedalPressureValid_u8;
  uint8 SteeringWheelAngleSpeedValid_u8;
  uint8 ActiveStationaryTesting_u8;
  uint8 ActiveStationaryTestingValid_u8;
  uint8 CIN_Angles_Static_Test_V_u8;
  uint8 CIN_Angles_Static_Test_u8;
  Rte_DT_EYEQDG_InputSignals_t_136 Reserved_u8;
  uint8 InternalAliveCounter_u8;
  uint16 InternalCRC_u16;
} EYEQDG_InputSignals_t;

#  define Rte_TypeDef_EYEQDG_LastFSDataRcd_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint32 FSSevrMisAlgmntTmr_u32;
  uint8 FS_outOfFocus_Cntr_u8;
  uint8 Last_FS_Partial_Blockage_u8;
  uint8 Last_FS_Full_Blockage_u8;
  uint8 Last_FS_Out_Of_Focus_u8;
  uint8 Last_FS_Out_Of_Calib_u8;
  uint8 LastTriggerSPC_u8;
  uint16 FS_Reserved_1_u16;
  Rte_DT_EYEQDG_LastFSDataRcd_t_10 Reserved3_u16;
  uint16 CalCRC_u16;
} EYEQDG_LastFSDataRcd_t;

#  define Rte_TypeDef_EYEQDG_SafetyFuncConfig_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 IsGeneralSafetyCritical_u8;
  uint8 IsAEBSafetyCritical_u8;
  uint8 IsPEDSafetyCritical_u8;
  uint8 IsVDSafetyCritical_u8;
  uint8 IsRoadSafetyCritical_u8;
  uint8 IsRoadEdgeSafetyCritical_u8;
  uint8 IsDecelerationSafetyCritical_u8;
  uint8 IsMeasurementsSafetyCritical_u8;
  uint8 IsFreeSpaceSafetyCritical_u8;
  uint8 Reserved_0_u8;
  Rte_DT_EYEQDG_SafetyFuncConfig_t_12 Reserved_1_u16;
  uint16 calCRC_u16;
} EYEQDG_SafetyFuncConfig_t;

#  define Rte_TypeDef_EYEQEDR_BBHeaderResParams_t
typedef struct
{
  EYEQEDR_BBGetHeaderVH_t EYEQEDR_BBGetHeaderVH_s;
  Rte_DT_EYEQEDR_BBHeaderResParams_t_1 EYEQEDR_BBGetHeaderVO_s;
} EYEQEDR_BBHeaderResParams_t;

#  define Rte_TypeDef_EYEQEDR_BBQueryResParams_t
typedef struct
{
  uint16 Pad0BBQuery_u16;
  uint16 BBState_u16;
  uint32 CRC_u32;
  uint32 DataSize_u32;
  uint32 ImageSize_u32;
  uint32 NumOfImages_u32;
  uint32 RESERVED1_u32;
  Rte_DT_EYEQEDR_BBQueryResParams_t_7 BBName_au8;
} EYEQEDR_BBQueryResParams_t;

#  define Rte_TypeDef_EYEQMESP_AutoFixCalData_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint16 Autofix_Yaw_u16;
  uint16 Autofix_Horizon_u16;
  float32 Autofix_Roll_f32;
  uint16 Autofix_Cam_Height_u16;
  uint8 CalStatus_u8;
  uint8 Reserved_1_u8;
  Rte_DT_EYEQMESP_AutoFixCalData_t_8 Reserved_2_u8;
  uint16 CalCRC_u16;
} EYEQMESP_AutoFixCalData_t;

#  define Rte_TypeDef_EYEQMESP_CamDistorParams_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Reserved4_u8;
  uint8 Reserved0_u8;
  uint8 DistortionModelType_0_u8;
  uint8 Reserved1_u8;
  float64 CODX_f64;
  float64 CODY_f64;
  float64 DistorParams0_f64;
  float64 DistorParams1_f64;
  float64 DistorParams2_f64;
  float64 DistorParams3_f64;
  float64 DistorParams4_f64;
  float64 DistorParams5_f64;
  float64 DistorParams6_f64;
  float64 DistorParams7_f64;
  float64 DistorParams8_f64;
  float64 DistorParams9_f64;
  float64 DistorParams10_f64;
  float64 DistorParams11_f64;
  float64 DistorParams12_f64;
  float64 DistorParams13_f64;
  float64 DistorParams14_f64;
  float64 DistorParams15_f64;
  float64 FocalLengthX_f64;
  float64 FocalLengthY_f64;
  float64 Skew_f64;
  float64 PrincipalPointX_f64;
  float64 PrincipalPointY_f64;
  Rte_DT_EYEQMESP_CamDistorParams_t_29 Reserved2_u16;
  uint8 Reserved3_u8;
  uint8 CalStatus_u8;
  uint16 CalCRC_u16;
} EYEQMESP_CamDistorParams_t;

#  define Rte_TypeDef_EYEQMESP_CameraFocused_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Focused_Main_u8;
  uint8 Focused_Narrow_u8;
  uint8 Focused_Fisheye_u8;
  uint8 Reserved_0_u8;
  Rte_DT_EYEQMESP_CameraFocused_t_6 Reserved_1_u8;
  uint16 calCRC_u16;
} EYEQMESP_CameraFocused_t;

#  define Rte_TypeDef_EYEQMESP_SPCalibration_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 Max_distorParams_0_u8;
  uint8 DistortionModelType_0_u8;
  uint16 Reserved0_u16;
  float32 CODX_0_f32;
  float32 CODY_0_f32;
  float32 DistorParams0_0_f32;
  float32 DistorParams1_0_f32;
  float32 DistorParams2_0_f32;
  float32 DistorParams3_0_f32;
  float32 DistorParams4_0_f32;
  float32 DistorParams5_0_f32;
  float32 DistorParams6_0_f32;
  float32 DistorParams7_0_f32;
  float32 DistorParams8_0_f32;
  float32 DistorParams9_0_f32;
  float32 DistorParams10_0_f32;
  float32 DistorParams11_0_f32;
  float32 DistorParams12_0_f32;
  float32 DistorParams13_0_f32;
  float32 DistorParams14_0_f32;
  float32 DistorParams15_0_f32;
  float32 FocalLengthX_0_f32;
  float32 FocalLengthY_0_f32;
  float32 Skew_0_f32;
  float32 PrincipalPointX_0_f32;
  float32 PrincipalPointY_0_f32;
  Rte_DT_EYEQMESP_SPCalibration_t_28 Reserved1_u16;
  uint8 Reserved2_u8;
  uint8 CalStatus_u8;
  uint16 CalCRC_u16;
} EYEQMESP_SPCalibration_t;

#  define Rte_TypeDef_EYEQMESP_TargetCalParamsLimits_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint16 Yaw_Min_u16;
  uint16 Yaw_Max_u16;
  uint16 Horizon_Min_u16;
  uint16 Horizon_Max_u16;
  float32 rollAngle_Min_f32;
  float32 rollAngle_Max_f32;
  uint16 CameraHeight_Min_u16;
  uint16 CameraHeight_Max_u16;
  Rte_DT_EYEQMESP_TargetCalParamsLimits_t_10 Reserved_0_u16;
  uint16 Reserved_1_u16;
  uint16 calCRC_u16;
} EYEQMESP_TargetCalParamsLimits_t;

#  define Rte_TypeDef_EYEQMESP_TargetCalibData_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint16 Yaw_u16;
  uint16 Pitch_u16;
  float32 Roll_Angle_f32;
  uint16 Cam_Height_u16;
  uint8 IsAutoTriggered_u8;
  uint8 CalStatus_u8;
  Rte_DT_EYEQMESP_TargetCalibData_t_8 Reserved0_u8;
  uint16 CalCRC_u16;
} EYEQMESP_TargetCalibData_t;

#  define Rte_TypeDef_EYEQ_SysCfgFlgsRcd_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  Rte_DT_EYEQ_SysCfgFlgsRcd_t_2 Flags_au8;
  uint16 calCRC_u16;
} EYEQ_SysCfgFlgsRcd_t;

#  define Rte_TypeDef_EyeQDG_SafetyCriticalFuncConfig_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint8 IsAEBSafetyCritical_u8;
  uint8 IsPEDSafetyCritical_u8;
  uint8 IsVMSafetyCritical_u8;
  uint8 IsLDSafetyCritical_u8;
  uint8 IsEyeQProvideAEBDecel_u8;
  uint8 Reserved_0_u8;
  Rte_DT_EyeQDG_SafetyCriticalFuncConfig_t_8 Reserved_1_u16;
  uint16 calCRC_u16;
} EyeQDG_SafetyCriticalFuncConfig_t;

#  define Rte_TypeDef_EyeQEdrEnhd_AppendImageRequestParams_t
typedef struct
{
  uint32 Event_tag_u32;
  uint32 TriggerDataSize_u32;
  Rte_DT_EyeQEdrEnhd_AppendImageRequestParams_t_2 TriggerData_au8;
} EyeQEdrEnhd_AppendImageRequestParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_AppendRequests_t
typedef struct
{
  uint32 RequestTotalSize_u32;
  uint32 Event_tag_u32;
  uint32 TriggerDataSize_u32;
  Rte_DT_EyeQEdrEnhd_AppendRequests_t_3 TriggerData_au8;
} EyeQEdrEnhd_AppendRequests_t;

#  define Rte_TypeDef_EyeQEdrEnhd_BbGetDescReplyParams_t
typedef struct
{
  Rte_DT_EyeQEdrEnhd_BbGetDescReplyParams_t_0 desc_str_au8;
} EyeQEdrEnhd_BbGetDescReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t
typedef struct
{
  uint32 HeaderVersion_u32;
  uint32 ImageWidth_u32;
  uint32 ImageHeight_u32;
  uint32 ImageActualSize_u32;
  uint32 Padding_u32;
  uint32 PaddingRemoved_u32;
  uint32 ImageStage_u32;
  uint32 GrabIndex_u32;
  uint64 TimeStamp_u64;
  uint32 TimeStampSource_u32;
  uint32 CompressedQuality_u32;
  uint32 EncryptionType_u32;
  uint32 EncryptionTagSize_u32;
  Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_13 EncryptionTag_au8;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  uint32 Reserved_3_u32;
  uint32 Reserved_4_u32;
  uint32 Reserved_5_u32;
  uint32 Reserved_6_u32;
  uint32 Reserved_7_u32;
  uint32 Reserved_8_u32;
  uint32 Reserved_9_u32;
  uint32 Reserved_10_u32;
  uint32 SensorDataSize_u32;
  Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_25 SensorData_au8;
  uint32 TriggerDataSize_u32;
  Rte_DT_EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t_27 TriggerData_au8;
} EyeQEdrEnhd_BbGetImageHeaderInfoReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_MultipleAppendImageReplyParams_t
typedef struct
{
  uint32 NumberOfappendImageReplies_u32;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  Rte_DT_EyeQEdrEnhd_MultipleAppendImageReplyParams_t_3 AppendImageReplies_au32;
} EyeQEdrEnhd_MultipleAppendImageReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_MultipleTriggerEventReplyParams_t
typedef struct
{
  uint32 NumberOfTriggerReplies_u32;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  Rte_DT_EyeQEdrEnhd_MultipleTriggerEventReplyParams_t_3 TriggerReplies_au32;
} EyeQEdrEnhd_MultipleTriggerEventReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_StatusReplyParams_t
typedef struct
{
  uint32 Events_data_Size_u32;
  Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_1 Events_data_u8;
  uint32 BBs_data_Size_u32;
  Rte_DT_EyeQEdrEnhd_StatusReplyParams_t_3 BBs_data_u8;
} EyeQEdrEnhd_StatusReplyParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t
typedef struct
{
  uint32 preImagesNumber_u32;
  uint32 postImagesNumber_u32;
  uint32 preImagesSkip_u32;
  uint32 postImagesSkip_u32;
  uint32 eventNum_u32;
  uint32 BB_Num_u32;
  uint32 Reserved_u32;
  uint32 TriggerDataSize_u32;
  Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_8 TriggerData_au8;
  Rte_DT_EyeQEdrEnhd_TriggerEventExtendedRequestParams_t_9 Event_metadata_au8;
} EyeQEdrEnhd_TriggerEventExtendedRequestParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_TriggerRequestsParams_t
typedef struct
{
  uint32 RequestTotalSize_u32;
  uint32 PreImagesNumber_u32;
  uint32 PostImagesNumber_u32;
  uint32 PreImagesSkip_u32;
  uint32 PostImagesSkip_u32;
  uint32 EventNum_u32;
  uint32 Bb_Num_u32;
  uint32 Reserved_u32;
  uint32 TriggerDataSize_u32;
  Rte_DT_EyeQEdrEnhd_TriggerRequestsParams_t_9 TriggerData_au8;
} EyeQEdrEnhd_TriggerRequestsParams_t;

#  define Rte_TypeDef_EyeQFOTA_BlackBoxData_t
typedef struct
{
  uint32 BlackBoxDataSize_u32;
  Rte_DT_EyeQFOTA_BlackBoxData_t_1 BlackBoxData_au8;
} EyeQFOTA_BlackBoxData_t;

#  define Rte_TypeDef_EyeQFOTA_Hash_t
typedef struct
{
  uint32 HashSize_u32;
  Rte_DT_EyeQFOTA_Hash_t_1 Hash_au8;
} EyeQFOTA_Hash_t;

#  define Rte_TypeDef_EyeQFOTA_MiniBlock_t
typedef struct
{
  uint32 MiniBlockDataSize_u32;
  Rte_DT_EyeQFOTA_MiniBlock_t_1 MiniBlockData_au8;
} EyeQFOTA_MiniBlock_t;

#  define Rte_TypeDef_EyeQFfsSrvc_FfsHash_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  Rte_DT_EyeQFfsSrvc_FfsHash_t_2 OTP_Data_au8;
  uint16 IsFfsHashCalculated_u16;
  uint16 calCRC_u16;
} EyeQFfsSrvc_FfsHash_t;

#  define Rte_TypeDef_EyeQFfsSrvc_SerialIDReplyData_t
typedef struct
{
  uint32 DataSize_u32;
  Rte_DT_EyeQFfsSrvc_SerialIDReplyData_t_1 Data_au8;
} EyeQFfsSrvc_SerialIDReplyData_t;

#  define Rte_TypeDef_EyeQIDMGRC_SerialNumberPCB_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  Rte_DT_EyeQIDMGRC_SerialNumberPCB_t_2 SerialNumber_au8;
  uint16 Reserved_u16;
  uint16 CalCRC_u16;
} EyeQIDMGRC_SerialNumberPCB_t;

#  define Rte_TypeDef_FcaNvmTunPara_t
typedef struct
{
  uint32 p_Inv_Max_CurveRadius;
  sint32 p_NMax_CurveRadius;
  s32_array_11 a_FCA_Max_Decel_X;
  s32_array_8 a_Abs_SteerRate_X_axis;
  s32_array_6 a_Add_in_TargetAccel_X;
  s32_array_2 a_Cal_SteerRate_Den;
  s32_array_2 a_Cal_SteerRate_Num;
  u32_array_5 a_Cal_init_X;
  u32_array_8 a_Cnt_by_SteerRate_X;
  u32_array_4 a_Cnt_by_SteerRate_X_for_FCWTarget_ON;
  u32_array_4 a_Cnt_by_SteerRate_X_for_FCWTarget_OFF;
  u32_array_4 a_Dist_Lat_VUT_Table1;
  u32_array_4 a_Dist_Lat_VUT_Table2;
  u32_array_4 a_Dist_Lat_VUT_Table3;
  u32_array_4 a_Dist_Lat_VUT_Table4;
  s32_array_4 a_Dist_Lat_VUT_X1;
  s32_array_4 a_Dist_Lat_VUT_X2;
  u32_array_9 a_InPath_FCW_Width_Table_X;
  s32_array_9 a_InvTTC_X;
  u32_array_1_78 a_LatVelPD_Out;
  u32_array_1_78 a_LatVelPD_Out_Cyclist;
  s32_array_13 a_LatVelPD_X;
  s32_array_6 a_LatVelPD_Y;
  s32_array_9 a_Min_InvTTC_Th_Table;
  u32_array_7 a_Obj_cosHeading_based_LatVrel_Weight_Table_In;
  u32_array_8 a_OvlpThreshold_15to1_Table;
  u32_array_8 a_OvlpThreshold_15to25_Table;
  s32_array_6 a_PredTime_Vrel_JS_X;
  u32_array_9 a_Primary_TOS_Width_Table_X;
  s32_array_7 a_RelAccel_Table_X;
  s32_array_8 a_FCA_JT_CMDC_TTI_Th_for_Warn_Column;
  s32_array_1_48 a_FCA_JT_CMDC_TTI_Th_for_Warn_Table;
  u32_array_6 a_TargetAccel_Table_Out;
  s32_array_6 a_TargetAccel_Table_X;
  u32_array_9 a_Th_As_Req_Out;
  u32_array_9 a_Th_Inpath_X;
  u32_array_9 a_Threshold_As_Req_FCA_Mov_Table;
  u32_array_5 a_Valid_TimeGap_Table_Out;
  u32_array_5 a_Valid_TimeGap_Table_X;
  s32_array_9 a_Vs_Threshold_InvTTC_X;
  s32_array_4 a_WF_At_by_Vt_Out;
  s32_array_4 a_WF_At_by_Vt_X;
  u32_array_5 a_WF_YR_by_Vs_Out;
  u32_array_3 a_WeightFactor_OpCnt_Table;
  u32_array_6 a_Weight_F_steer_Out;
  u32_array_6 a_Weight_F_steer_X;
  s32_array_6 a_FCA_JT_CMDC_AreqMin_Th_for_Brake_value;
  s32_array_8 a_FCA_JT_CMDC_TTI_Th_for_Brake_Column;
  s32_array_1_48 a_FCA_JT_CMDC_TTI_Th_for_Brake_Table;
  s32_array_6 a_FCA_JT_CMDC_TimeToCollision_Th_for_Brake_value;
  sint16 p_ALPHA;
  uint16 p_MaxRadarBlkCnt;
  uint16 p_Max_Curvature;
  uint16 p_Max_CurveRadius;
  uint16 p_Monitoring_Time;
  uint16 p_Recovering_Time;
  sint16 p_Steer_Ratio;
  uint16 p_FCA_Act_Vmax_MT_Th;
  uint16 p_FCA_Act_Vmax_PD_Th;
  uint16 p_FCA_Act_Vmax_RMT_Th;
  uint16 p_FCA_Act_Vmin_MT_Th;
  uint16 p_FCA_Act_Vmin_PD_Th;
  uint16 p_FCA_Act_Vmin_ST_Th;
  uint16 p_FCA_DeAct_Vmax_PD_Th;
  uint16 p_FCA_DeAct_Vmin_PD_Th;
  uint16 p_FCA_DeAct_Vmin_ST_Th;
  uint16 p_CurvRadiusThreshold;
  uint16 p_FCA_JT_CMDC_TarVeh_Heading_Act_Disable_Th;
  uint16 p_FCA_JT_CMDC_TarVeh_Heading_Act_Enable_Th;
  uint16 p_FCA_JT_CTG_TarVeh_Heading_Disable_Th;
  uint16 p_FCA_JT_CTG_TarVeh_Heading_Enable_Th;
  uint16 p_FCA_JT_CTG_TarVeh_FOV_Enable_Th;
  uint16 p_FCA_JT_CMDC_TarVeh_FOV_Enable_Th;
  uint16 p_FCA_JT_CMDC_TarVeh_FOV_Disable_Th;
  sint16 p_FCA_JT_CMDC_TV_Decel_by_Axrel_th_Enable;
  sint16 p_FCA_JT_CMDC_TV_Decel_by_Ax_th_Enable;
  sint16 p_FCA_JT_CMDC_TV_Decel_by_Axrel_th_Disable;
  sint16 p_FCA_JT_CMDC_TV_Decel_by_Ax_th_Disable;
  uint16 p_FCA_JT_DSI_CounterSteer_Index_Th;
  uint16 p_FCW_VEH_DeAct_Vmin_Th;
  uint16 p_FCW_VEH_DeAct_Vmax_Th;
  uint16 p_FCW_VEH_Act_Vmin_Th;
  uint16 p_FCW_VEH_Act_Vmax_Th;
  uint16 p_Tar1_Sig_Filt_K22;
  uint16 p_Tar1_Sig_Filt_K32;
  uint16 p_Th1_SteerAngleRate;
  uint16 p_Th2_SteerAngleRate;
  uint16 p_Th3_SteerAngleRate;
  s16_array_11 a_FCA_Max_Decel_Out;
  s16_array_11 a_Accel4Pedestrian1_Out;
  u16_array_11 a_Accel4Pedestrian1_X;
  s16_array_11 a_Accel4Pedestrian_Out;
  u16_array_11 a_Accel4Pedestrian_X;
  u16_array_6 a_Add_in_TargetAccel_Table;
  s16_array_3 a_Basic_Count_Table;
  u16_array_3 a_Basic_Count_X;
  s16_array_3 a_BrakeJerk_Count_Table;
  u16_array_5 a_Cal_init_Out;
  s16_array_8 a_Cnt_by_SteerRate_Table;
  s16_array_4 a_Cnt_by_SteerRate_Table_for_FCATarget_OFF;
  s16_array_4 a_Cnt_by_SteerRate_Table_for_FCWTarget_ON;
  u16_array_9 a_InPath_FCW_Width_Table_Out;
  s16_array_9 a_InvTTC_Table;
  s16_array_8 a_Max_AccelCmd_Table_Out;
  s16_array_8 a_Max_FallingRate_Table_Out;
  s16_array_4 a_Max_PreBrake_Count_Table;
  u16_array_5 a_Max_PreBrake_Vrel_Table;
  s16_array_5 a_Max_PreBrake_b_Vrel_Table;
  s16_array_5 a_Max_PreBrake_b_Vrel_X;
  s16_array_6 a_Max_Rate_by_Vrel_Table;
  s16_array_6 a_Max_Rate_by_Vrel_X;
  s16_array_8 a_Max_RisingRate_Table_Out;
  u16_array_9 a_Min_InvTTC_Th_X;
  u16_array_7 a_Obj_cosHeading_based_LatVrel_Weight_Table_Out;
  u16_array_5 a_Overlap_pct_Table;
  u16_array_5 a_Overlap_pct_Table_FCW;
  u16_array_8 a_OvlpThreshold_15to1_X;
  u16_array_8 a_OvlpThreshold_15to25_X;
  u16_array_8 a_PreBrake_Vrel_X;
  s16_array_6 a_PredTime_Vrel_JS_Table;
  u16_array_3 a_Pred_Time_Table_Demo_Out;
  u16_array_3 a_Pred_Time_Table_Demo_X;
  u16_array_9 a_Primary_TOS_Adjacent_Width_Table_Out;
  u16_array_9 a_Primary_TOS_InPath_Width_Table_Out;
  s16_array_8 a_STR_Max_PreBrake_by_Vrel_Out;
  s16_array_6 a_FCA_JT_CMDC_TTI_Th_for_Warn_Row;
  u16_array_9 a_Th_As_Req_Out_SCC;
  u16_array_9 a_Th_As_Req_X;
  u16_array_9 a_Th_As_Req_X_SCC;
  u16_array_9 a_Th_Inpath_Out;
  u16_array_9 a_Threshold_As_Req_FCA_Moving_X;
  s16_array_11 a_Threshold_InvTTC_Late_Table;
  s16_array_11 a_Threshold_InvTTC_TOS_Table;
  s16_array_11 a_Threshold_InvTTC_Table;
  u16_array_11 a_Threshold_InvTTC_X;
  u16_array_9 a_Velocity1_Table_Out;
  u16_array_9 a_Velocity_SCC_Table_Out;
  u16_array_9 a_Velocity_SCC_X;
  s16_array_9 a_Vrel_B_Threshold_Table;
  u16_array_9 a_Vrel_B_Threshold_X;
  s16_array_9 a_Vrel_Based_Threshold_Table;
  u16_array_9 a_Vrel_Based_Threshold_X;
  u16_array_10 a_Vrel_Threshold_Table_Out;
  u16_array_10 a_Vrel_Threshold_Table_X;
  s16_array_9 a_Vs_B_Threshold_Table;
  u16_array_9 a_Vs_B_Threshold_X;
  u16_array_8 a_Vs_Lookup_X;
  u16_array_8 a_Vs_Lookup_table;
  u16_array_8 a_Vs_Lookup_table_Additional_TTC_for_FCW;
  u16_array_9 a_Vs_Threshold_InvTTC_Table;
  u16_array_5 a_WF_YR_by_Vs_X;
  u16_array_6 a_FCA_JT_CMDC_AreqMin_Th_for_Brake_axis;
  u16_array_6 a_FCA_JT_CMDC_TTI_Th_for_Brake_Row;
  u16_array_6 a_FCA_JT_CMDC_TimeToCollision_Th_for_Brake_axis;
  uint8 p_BrakeJerk_Activation;
  sint8 p_FCA_Falling_Rate_Max1;
  sint8 p_FCA_Falling_Rate_Max2;
  uint8 p_FCA_Margin_Dist;
  uint8 p_FCA_Max_Sen_Delay;
  uint8 p_FCA_Partial_Decel;
  uint8 p_FCA_Rising_Rate_Max;
  uint8 p_Act_Hold_Cnt;
  uint8 p_Comp_Start_Dist;
  uint8 p_Preview_Time_FCW;
  uint8 p_Radar_Delay_FCW;
  sint8 p_Thr_Spd_Opp_Dir_Veh;
  uint8 p_Steering_Intention_StableCNT_Th;
  uint8 p_TargetVehicle_Length;
  uint8 p_YOC_EEPROM_Default_Value;
  uint8 p_YOC_Request_Threshold;
  uint8 p_FCA_Act_Vmax_ST_Th;
  uint8 p_FCA_Act_Vmin_RMT_Th;
  uint8 p_FCA_DeAct_Vmax_MT_Th;
  uint8 p_FCA_DeAct_Vmax_RMT_Th;
  uint8 p_FCA_DeAct_Vmax_ST_Th;
  uint8 p_FCA_DeAct_Vmin_MT_Th;
  uint8 p_FCA_DeAct_Vmin_RMT_Th;
  sint8 p_FCA_JT_CMDC_AreqMax_Th_for_Brake;
  sint8 p_FCA_JT_CMDC_AreqMin_Th_for_Warn;
  uint8 p_FCA_JT_CMDC_Brake_Enable;
  uint8 p_FCA_JT_CMDC_CollisionType_LowerTh_for_Brake;
  uint8 p_FCA_JT_CMDC_CollisionType_LowerTh_for_Warn;
  uint8 p_FCA_JT_CMDC_CollisionType_UpperTh_for_Brake;
  uint8 p_FCA_JT_CMDC_CollisionType_UpperTh_for_Warn;
  uint8 p_FCA_JT_CMDC_FusionHistoryCNT_Th;
  uint8 p_FCA_JT_CMDC_LowerCollisionType_StableCNT_Th_for_Brake;
  sint8 p_FCA_JT_CMDC_Max_DecelCmd;
  uint8 p_FCA_JT_CMDC_Max_TimeCNT_for_Brake;
  uint8 p_FCA_JT_CMDC_Max_TimeCNT_for_Warn;
  sint8 p_FCA_JT_CMDC_SAS_Rate_Th_for_Brake;
  uint8 p_FCA_JT_CMDC_TTC_Th_for_Brake;
  uint8 p_FCA_JT_CMDC_TTC_Th_for_Warn;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv1_Disable;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv1_Enable;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv2_Disable;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv2_Enable;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv3_Disable;
  uint8 p_FCA_JT_CMDC_TarVeh_DiffLatVrel_Lv3_Enable;
  uint8 p_FCA_JT_CMDC_TarVeh_Heading_Brake_Disable_CNT_Th;
  uint8 p_FCA_JT_CMDC_TarVeh_Heading_Brake_Enable_CNT_Th;
  uint8 p_FCA_JT_CMDC_Warn_Enable;
  uint8 p_FCA_JT_CTG_FusionHistoryCNT_Th;
  sint8 p_FCA_JT_CTG_LHD_Candi_PosY_Lower_Disable;
  sint8 p_FCA_JT_CTG_LHD_Candi_PosY_Lower_Enable;
  uint8 p_FCA_JT_CTG_LHD_Candi_PosY_Upper_Disable;
  uint8 p_FCA_JT_CTG_LHD_Candi_PosY_Upper_Enable;
  sint8 p_FCA_JT_CTG_RHD_Candi_PosY_Lower_Disable;
  sint8 p_FCA_JT_CTG_RHD_Candi_PosY_Lower_Enable;
  uint8 p_FCA_JT_CTG_RHD_Candi_PosY_Upper_Disable;
  uint8 p_FCA_JT_CTG_RHD_Candi_PosY_Upper_Enable;
  uint8 p_FCA_JT_CTG_RadarMatchValue1_Th;
  uint8 p_FCA_JT_DSI_StrColTq_Enable;
  uint8 p_FCA_JT_CMDC_RadarMatchValue1_Th;
  uint8 p_FCA_JT_DSI_Steer_Index_Th;
  uint8 p_FCA_JT_DSI_Diff_WHL_SPD_Th;
  uint8 p_Full_Brake_DeAct_Vmax_MT_Th;
  uint8 p_Full_Brake_DeAct_Vmax_ST_Th;
  uint8 p_Tar1_Sig_Filt_K11;
  uint8 p_Tar1_Sig_Filt_K12;
  uint8 p_Tar1_Sig_Filt_K21;
  sint8 p_Tar1_Sig_Filt_K31;
  sint8 p_Th1_Areq_Prefill;
  uint8 p_Th1_BrkPressure;
  uint8 p_Th1_CurveRadius_PED;
  sint8 p_Th1_Decel;
  uint8 p_Th1_Stop;
  uint8 p_Th2_BrkPressure;
  uint8 p_Th2_CurveRadius_PED;
  sint8 p_Th2_Decel;
  uint8 p_Th2_Stop;
  uint8 p_USM_Reset_Activation;
  uint8 p_YOC_SIM_Mode;
  uint8 p_EmerBrk_Max_Time;
  uint8 p_EmerBrk_Min_Time;
  uint8 p_FCA_OUTPUT_MaxSpeedReduction;
  uint8 p_FCA_OUTPUT_SpeedReductionCheck_Enable;
  u8_array_3 a_BrakeJerk_Count_X;
  u8_array_4 a_Max_PreBrake_Count_X;
  u8_array_5 a_Max_PreBrake_Vrel_X;
  u8_array_5 a_Overlap_pct_X;
  s8_array_7 a_RelAccel_Table_Out;
  u8_array_3 a_WeightFactor_OpCnt_X;
} FcaNvmTunPara_t;

#  define Rte_TypeDef_HKMC_ReleaseInfo_record
typedef struct
{
  HKMC_PartNumber_t HKMC_PartNumber;
  SW_Version_t SW_Version;
  HW_Version_t HW_Version;
  Supplier_SW_Info_t Supplier_SW_Info;
  Reserved_2 Reserved;
} HKMC_ReleaseInfo_record;

#  define Rte_TypeDef_HKMC_TraceabilityInformation_t
typedef struct
{
  uint8 TraceabilityIDLetter;
  Rte_DT_HKMC_TraceabilityInformation_t_1 ManufacturingDate;
  uint8 RotationWorking;
  uint8 ManufacturingFactory;
  uint8 ManufacturingLine;
  uint8 Data_4M;
  uint8 SerialNumberIDLetter;
  Rte_DT_HKMC_TraceabilityInformation_t_7 SerialNumber;
  uint8 Reserved1_u8;
  uint16 calCRC_u16;
} HKMC_TraceabilityInformation_t;

#  define Rte_TypeDef_IslwFrqNvData_t
typedef struct
{
  uint16 u16_Nvm_Navi_CountryCode;
  uint8 u8_SLIF_Speed_Display_Cluster;
  uint8 u8_SLIF_Speed_Display_Navi;
  uint8 u8_SLIF_VS_Unit;
  uint8 u8_Navi_SLIF_LinkClass_NVM;
  uint8 u8_SLIF_Former_Speed_Limit_From;
  uint8 u8_Nvm_ISLA_OffstUsmSta;
  uint8 u8_Nvm_ISLA_OptUsmSta;
  uint8 u8_Nvm_ISLA_Cntry;
  boolean b_Nvm_Navi_On;
  uint8 u8_Nvm_ISLA_Cntry1USMSta;
  uint8 u8_Nvm_ISLA_Cntry2USMSta;
  uint8 u8_Nvm_ISLA_CntryVerTyp;
  uint8 u8_Nvm_USER_ID;
  uint8 u8_Nvm_OffsetUSM_User1;
  uint8 u8_Nvm_OffsetUSM_User2;
  uint8 u8_Nvm_OffsetUSM_Geust;
  uint8 u8_Nvm_NRS_USM_User1;
  uint8 u8_Nvm_NRS_USM_User2;
  uint8 u8_Nvm_NRS_USM_Guest;
  uint8 u8_Blockage_Full_Status;
  uint8 u8_Blockage_Partial_Status;
  uint8 u8_Blockage_SunRay_Status;
  uint8 u8_RawValueCamolny_CLUMain;
  Rte_DT_IslwFrqNvData_t_24 Reserved;
} IslwFrqNvData_t;

#  define Rte_TypeDef_NvMVersionDataRead
typedef struct
{
  Rte_DT_NvMVersionDataRead_0 data_u8;
} NvMVersionDataRead;

#  define Rte_TypeDef_PtmEepDumpRecord_t
typedef struct
{
  Rte_DT_PtmEepDumpRecord_t_0 Data_au8;
} PtmEepDumpRecord_t;

#  define Rte_TypeDef_SECURITY_RNGInitCount_t
typedef struct
{
  uint16 TagID_u16;
  uint16 Version_u16;
  uint32 RNGInitCnt_au32;
  Rte_DT_SECURITY_RNGInitCount_t_3 Reserved2_au8;
  uint16 calCRC_u16;
} SECURITY_RNGInitCount_t;

#  define Rte_TypeDef_SccNvmData_t
typedef struct
{
  uint16 u16_Nvm_YawRateOffsetCal;
  uint8 u8_Nvm_TauGapSet;
  uint8 u8_Nvm_NsccStatus;
  uint8 u8_Nvm_NsccStatus_guest;
  uint8 u8_Nvm_NsccStatus_user1;
  uint8 u8_Nvm_NsccStatus_user2;
  uint8 u8_NVM_SCC_Char1Sta;
  uint8 u8_NVM_SCC_Char1Sta_guest;
  uint8 u8_NVM_SCC_Char1Sta_user1;
  uint8 u8_NVM_SCC_Char1Sta_user2;
  uint8 u8_NVM_SCC_Char2Sta;
  uint8 u8_NVM_SCC_Char2Sta_guest;
  uint8 u8_NVM_SCC_Char2Sta_user1;
  uint8 u8_NVM_SCC_Char2Sta_user2;
  uint8 u8_NVM_SCC_Char3Sta;
  uint8 u8_NVM_SCC_Char3Sta_guest;
  uint8 u8_NVM_SCC_Char3Sta_user1;
  uint8 u8_NVM_SCC_Char3Sta_user2;
  uint8 u8_Nvm_ProfileDrv;
  Rte_DT_SccNvmData_t_19 Reserved;
  uint8 Reserved4;
} SccNvmData_t;

#  define Rte_TypeDef_VdVruSuppFlagInfo_t
typedef struct
{
  Rte_DT_VdVruSuppFlagInfo_t_0 VRU_FCW_PD_Supp_Status_u8;
  Rte_DT_VdVruSuppFlagInfo_t_1 VRU_AEB_PD_Supp_Status_u8;
  Rte_DT_VdVruSuppFlagInfo_t_2 VD_AEB_VD_Supp_Status_u8;
  Rte_DT_VdVruSuppFlagInfo_t_3 VD_FCW_VD_Supp_Status_u8;
} VdVruSuppFlagInfo_t;

#  define Rte_TypeDef_ZFECUHwNrDataId_t
typedef struct
{
  Rte_DT_ZFECUHwNrDataId_t_0 ZFECUHwNrDataId;
  uint16 Reserved_u16;
  uint16 calCRC_u16;
} ZFECUHwNrDataId_t;

#  define Rte_TypeDef_ZFECUHwVerNrDataId_t
typedef struct
{
  Rte_DT_ZFECUHwVerNrDataId_t_0 ZFECUHwVerNrDataId;
  uint16 Reserved_u16;
  uint16 calCRC_u16;
} ZFECUHwVerNrDataId_t;

#  define Rte_TypeDef_ZFManfrECUSerialNr_t
typedef struct
{
  Rte_DT_ZFManfrECUSerialNr_t_0 IDMGRC_SerialNumberECU;
  uint16 Reserved_u16;
  uint16 calCRC_u16;
} ZFManfrECUSerialNr_t;

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_MultipleAppendImageRequestParams_t_4
typedef EyeQEdrEnhd_AppendRequests_t Rte_DT_EyeQEdrEnhd_MultipleAppendImageRequestParams_t_4[10];

#  define Rte_TypeDef_Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_4
typedef EyeQEdrEnhd_TriggerRequestsParams_t Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_4[10];

#  define Rte_TypeDef_EyeQEdrEnhd_MultipleAppendImageRequestParams_t
typedef struct
{
  uint32 NumberOfAppendImageRequests_u32;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  uint32 AppendRequestsSize_u32;
  Rte_DT_EyeQEdrEnhd_MultipleAppendImageRequestParams_t_4 EdrEnhd_AppendRequests_s;
} EyeQEdrEnhd_MultipleAppendImageRequestParams_t;

#  define Rte_TypeDef_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t
typedef struct
{
  uint32 NumberOfTriggerRequests_u32;
  uint32 Reserved_1_u32;
  uint32 Reserved_2_u32;
  uint32 TriggerRequestsSize_u32;
  Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_4 EdrEnhd_TriggerRequestsParams_s;
  Rte_DT_EyeQEdrEnhd_MultipleTriggerEventRequestParams_t_5 Events_metadata_au8;
} EyeQEdrEnhd_MultipleTriggerEventRequestParams_t;

# endif

#endif /* _RTE_TYPE_H */
