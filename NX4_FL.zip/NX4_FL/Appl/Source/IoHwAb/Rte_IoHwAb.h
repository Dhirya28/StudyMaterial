/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_IoHwAb.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  IoHwAb
 *  Generation Time:  2023-04-20 13:53:13
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <IoHwAb> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_IOHWAB_H
# define _RTE_IOHWAB_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_IoHwAb_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_IoHwAb
{
  /* Data Handles section */
  P2VAR(Rte_DE_uint16, TYPEDEF, RTE_IOHWAB_APPL_VAR) IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* PIM Handles section */
  P2VAR(EYEQTHSD_ThermalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalParams; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQTHSD_ThermalShutdownValues_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalShutdownPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQTHSD_ThermalShutdownValues_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalShutdownSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IoHwAb_HeaterInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQIoHwAb_HeaterInfoPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IoHwAb_HeaterInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQIoHwAb_HeaterInfoSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_IoHwAb, RTE_CONST, RTE_CONST) Rte_Inst_IoHwAb; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_IoHwAb, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_IoHwAb_AdcRaw_VBATT_MON (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera1_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera1_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera2_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera2_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera3_temperature_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Camera3_temperature_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(P2VAR(sint16, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_EyeQTemperature1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(P2VAR(sint16, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_EyeQTemperature2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Temperature_DDR(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) APP_Temperature_DDR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_CPU_Temperature(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) BOOT_CPU_Temperature); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_VMP_Temperature(P2VAR(sint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) BOOT_VMP_Temperature); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EyeQMCD_NotifyEyeQCoreDump_EyeQMCD_NotifyEyeQCoreDump(uint8 CoreDumpStatus_u8, P2VAR(boolean, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EyeQMgr_GetCurrentState_EyeQMgr_GetCurrentState(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) EyeQMgrState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EyeQMgr_IsThermalShutdownSet_EyeQMgr_IsThermalShutdownSet(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pu8, P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) reason_pu8, P2VAR(IoHwAb_Thermal_Shutdown_SourceType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) source_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EyeQMgr_SendErrorAndAction_EyeQMgr_SendErrorAndAction(uint8 DesiredCoreState_u8, uint32 ErrorCode_u32); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_EyeQMgr_SetErrOutPinStatusNotify_EyeQMgr_SetErrOutPinStatusNotify(uint8 Status_u8, uint8 Result_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_IOHWAB_PWRMGR_SetFOTAChipSelectPin_IOHWAB_PWRMGR_SetFOTAChipSelectPin(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) chipSelect_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_IoHwAb_PowerMgr_GetCatalogID_IoHwAb_PowerMgr_GetCatalogID(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) EyeQCatalogId_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_IoHwAb_ThermalMgr_ShutdownNotify_IoHwAb_ThermalMgr_ShutdownNotify(uint8 status_u8, uint8 reason_u8, IoHwAb_Thermal_Shutdown_SourceType source_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_IoHwAb_RP_WdgM_General_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_IRead_<r>_<p>_<d>
 * Rte_IStatus_<r>_<p>_<d>
 * Rte_IWrite_<r>_<p>_<d>
 * Rte_IWriteRef_<r>_<p>_<d>
 * Rte_IInvalidate_<r>_<p>_<d>
 *********************************************************************************************************************/

/* PRQA S 3453 L1 */ /* MD_MSR_19.7 */
# define Rte_IWrite_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(data) \
  ( \
    Rte_Inst_IoHwAb->IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON->value = (data) \
  )
/* PRQA L:L1 */

/* PRQA S 3453 L1 */ /* MD_MSR_19.7 */
# define Rte_IWriteRef_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON() \
  (&Rte_Inst_IoHwAb->IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON->value)
/* PRQA L:L1 */


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus Rte_Call_IoHwAb_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2 Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Temperature_DDR Rte_Call_IoHwAb_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Temperature_DDR
# define Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_CPU_Temperature Rte_Call_IoHwAb_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_CPU_Temperature
# define Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_VMP_Temperature Rte_Call_IoHwAb_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_VMP_Temperature
# define Rte_Call_RP_EyeQMCD_NotifyEyeQCoreDump_EyeQMCD_NotifyEyeQCoreDump Rte_Call_IoHwAb_RP_EyeQMCD_NotifyEyeQCoreDump_EyeQMCD_NotifyEyeQCoreDump
# define Rte_Call_RP_EyeQMgr_GetCurrentState_EyeQMgr_GetCurrentState Rte_Call_IoHwAb_RP_EyeQMgr_GetCurrentState_EyeQMgr_GetCurrentState
# define Rte_Call_RP_EyeQMgr_IsThermalShutdownSet_EyeQMgr_IsThermalShutdownSet Rte_Call_IoHwAb_RP_EyeQMgr_IsThermalShutdownSet_EyeQMgr_IsThermalShutdownSet
# define Rte_Call_RP_EyeQMgr_SendErrorAndAction_EyeQMgr_SendErrorAndAction Rte_Call_IoHwAb_RP_EyeQMgr_SendErrorAndAction_EyeQMgr_SendErrorAndAction
# define Rte_Call_RP_EyeQMgr_SetErrOutPinStatusNotify_EyeQMgr_SetErrOutPinStatusNotify Rte_Call_IoHwAb_RP_EyeQMgr_SetErrOutPinStatusNotify_EyeQMgr_SetErrOutPinStatusNotify
# define Rte_Call_RP_IOHWAB_PWRMGR_SetFOTAChipSelectPin_IOHWAB_PWRMGR_SetFOTAChipSelectPin Rte_Call_IoHwAb_RP_IOHWAB_PWRMGR_SetFOTAChipSelectPin_IOHWAB_PWRMGR_SetFOTAChipSelectPin
# define Rte_Call_RP_IoHwAb_PowerMgr_GetCatalogID_IoHwAb_PowerMgr_GetCatalogID Rte_Call_IoHwAb_RP_IoHwAb_PowerMgr_GetCatalogID_IoHwAb_PowerMgr_GetCatalogID
# define Rte_Call_RP_IoHwAb_ThermalMgr_ShutdownNotify_IoHwAb_ThermalMgr_ShutdownNotify Rte_Call_IoHwAb_RP_IoHwAb_ThermalMgr_ShutdownNotify_IoHwAb_ThermalMgr_ShutdownNotify
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_ReadBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalParams_ReadBlock
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_WriteBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalParams_WriteBlock
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock
# define Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock Rte_Call_IoHwAb_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock
# define Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock
# define Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock
# define Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock
# define Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock Rte_Call_IoHwAb_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock
# define Rte_Call_RP_WdgM_General_ActivateSupervisionEntity Rte_Call_IoHwAb_RP_WdgM_General_ActivateSupervisionEntity


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_EYEQTHSD_ThermalParams() (Rte_Inst_IoHwAb->Pim_EYEQTHSD_ThermalParams) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQTHSD_ThermalShutdownPrimary() (Rte_Inst_IoHwAb->Pim_EYEQTHSD_ThermalShutdownPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQTHSD_ThermalShutdownSecondary() (Rte_Inst_IoHwAb->Pim_EYEQTHSD_ThermalShutdownSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary() (Rte_Inst_IoHwAb->Pim_EyeQIoHwAb_HeaterInfoPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary() (Rte_Inst_IoHwAb->Pim_EyeQIoHwAb_HeaterInfoSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   EYEQTHSD_ThermalParams_t *Rte_Pim_EYEQTHSD_ThermalParams(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownPrimary(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownSecondary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary(void)
 *
 *********************************************************************************************************************/


# define IoHwAb_START_SEC_CODE
# include "IoHwAb_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAbNvM_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_CPU_Temperature(sint8 *BOOT_CPU_Temperature)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_BOOTADV_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_VMP_Temperature(sint8 *BOOT_VMP_Temperature)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_BOOTADV_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_IsThermalShutdownSet_EyeQMgr_IsThermalShutdownSet(uint8 *status_pu8, uint8 *reason_pu8, IoHwAb_Thermal_Shutdown_SourceType *source_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_IsThermalShutdownSet_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_ThermalMgr_ShutdownNotify_IoHwAb_ThermalMgr_ShutdownNotify(uint8 status_u8, uint8 reason_u8, IoHwAb_Thermal_Shutdown_SourceType source_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_ThermalMgr_ShutdownNotify_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAbNvM_Run IoHwAbNvM_Run
FUNC(void, IoHwAb_CODE) IoHwAbNvM_Run(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_ADCDIAG_GetADCSeedArray
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_ADCDIAG_GetADCSeedArray> of PortPrototype <PP_IoHwAb_ADCDIAG_GetADCSeedArray>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_ADCDIAG_GetADCSeedArray(uint8 *adcSeedArray_pau8, uint16 expectedSize_u16, uint8 *result_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_ADCDIAG_GetADCSeedArray_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_ADCDIAG_GetADCSeedArray IoHwAb_ADCDIAG_GetADCSeedArray
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_ADCDIAG_GetADCSeedArray(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) adcSeedArray_pau8, uint16 expectedSize_u16, P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) result_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_ADH_Service
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_EyeQMCD_NotifyEyeQCoreDump_EyeQMCD_NotifyEyeQCoreDump(uint8 CoreDumpStatus_u8, boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMCD_NotifyEyeQCoreDump_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_SetErrOutPinStatusNotify_EyeQMgr_SetErrOutPinStatusNotify(uint8 Status_u8, uint8 Result_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_SetErrOutPinStatusNotify_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_ADH_Service IoHwAb_ADH_Service
FUNC(void, IoHwAb_CODE) IoHwAb_ADH_Service(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_DIODIAG_SetErrOutPinDiagState
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_DIODIAG_SetErrOutPinDiagState> of PortPrototype <PP_IoHwAb_DIODIAG_SetErrOutPinDiagState>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_DIODIAG_SetErrOutPinDiagState(uint8 SetCmd_u8, uint8 *Result_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_DIODIAG_SetErrOutPinDiagState_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_DIODIAG_SetErrOutPinDiagState IoHwAb_DIODIAG_SetErrOutPinDiagState
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_DIODIAG_SetErrOutPinDiagState(uint8 SetCmd_u8, P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Result_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V0_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V0_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V0_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_1V0_MON IoHwAb_Get_ADC_1V0_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V1_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V1_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V1_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V1_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_1V1_MON IoHwAb_Get_ADC_1V1_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V1_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V8_DDR_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V8_DDR_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V8_DDR_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V8_DDR_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_1V8_DDR_MON IoHwAb_Get_ADC_1V8_DDR_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V8_DDR_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V8_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V8_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V8_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_1V8_MON IoHwAb_Get_ADC_1V8_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_2V8_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_2V8_MON> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_2V8_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_2V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_3V3_2V8_MON IoHwAb_Get_ADC_3V3_2V8_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_2V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_FEYE_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_FEYE_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC IoHwAb_Get_ADC_3V3_FEYE_MON_ADC
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_MAIN_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_MAIN_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC IoHwAb_Get_ADC_3V3_MAIN_MON_ADC
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_MON> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_3V3_MON IoHwAb_Get_ADC_3V3_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_NARROW_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_NARROW_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC IoHwAb_Get_ADC_3V3_NARROW_MON_ADC
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_5V0_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_5V0_MON> of PortPrototype <PP_IoHwAb_Get_ADC_5V0_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_5V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_5V0_MON IoHwAb_Get_ADC_5V0_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_5V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_ADC_REF_CAL
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_ADC_REF_CAL> of PortPrototype <PP_IoHwAb_Get_ADC_ADC_REF_CAL>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_ADC_REF_CAL(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_ADC_REF_CAL IoHwAb_Get_ADC_ADC_REF_CAL
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_ADC_REF_CAL(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_EQ4_MON_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_EQ4_MON_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_EQ4_MON_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_EQ4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_EQ4_MON_TEMP IoHwAb_Get_ADC_EQ4_MON_TEMP
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_EQ4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_FEYE_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_FEYE_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_FEYE_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_FEYE_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_FEYE_TEMP_MON IoHwAb_Get_ADC_FEYE_TEMP_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_FEYE_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_LKA_SW_INPUT
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_LKA_SW_INPUT> of PortPrototype <PP_IoHwAb_Get_ADC_LKA_SW_INPUT>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_LKA_SW_INPUT(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_LKA_SW_INPUT IoHwAb_Get_ADC_LKA_SW_INPUT
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_LKA_SW_INPUT(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_LPDDR4_MON_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_LPDDR4_MON_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_LPDDR4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_LPDDR4_MON_TEMP IoHwAb_Get_ADC_LPDDR4_MON_TEMP
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_LPDDR4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_MAIN_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_MAIN_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_MAIN_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_MAIN_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_MAIN_TEMP_MON IoHwAb_Get_ADC_MAIN_TEMP_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_MAIN_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_MICRO_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_MICRO_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_MICRO_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_MICRO_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_MICRO_TEMP_MON IoHwAb_Get_ADC_MICRO_TEMP_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_MICRO_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_NARROW_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_NARROW_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_NARROW_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_NARROW_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_NARROW_TEMP_MON IoHwAb_Get_ADC_NARROW_TEMP_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_NARROW_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_PSU_1V3_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_PSU_1V3_MON> of PortPrototype <PP_IoHwAb_Get_ADC_PSU_1V3_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_PSU_1V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_PSU_1V3_MON IoHwAb_Get_ADC_PSU_1V3_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_PSU_1V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_PSU_IMAGER_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_PSU_IMAGER_MON> of PortPrototype <PP_IoHwAb_Get_ADC_PSU_IMAGER_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_PSU_IMAGER_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_PSU_IMAGER_MON IoHwAb_Get_ADC_PSU_IMAGER_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_PSU_IMAGER_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_SENSE_HEATER
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_SENSE_HEATER> of PortPrototype <PP_IoHwAb_Get_ADC_SENSE_HEATER>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_SENSE_HEATER(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_SENSE_HEATER IoHwAb_Get_ADC_SENSE_HEATER
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_SENSE_HEATER(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_VBATT_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_VBATT_MON> of PortPrototype <PP_IoHwAb_Get_ADC_VBATT_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_VBATT_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_ADC_VBATT_MON IoHwAb_Get_ADC_VBATT_MON
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_VBATT_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_BoardRev
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_BoardRev> of PortPrototype <PP_IoHwAb_Get_BoardRev>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_BoardRev(uint8 *BoardRev_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_BoardRev_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_BoardRev IoHwAb_Get_BoardRev
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_BoardRev(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) BoardRev_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_1V5_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_1V5_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN IoHwAb_Get_Dio_1V5_PSU_MICRO_EN
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_1V8_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_1V8_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN IoHwAb_Get_Dio_1V8_PSU_MICRO_EN
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_CatalogID
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_CatalogID> of PortPrototype <PP_IoHwAb_Get_Dio_CatalogID>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_CatalogID(uint8 *CatalogId)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_CatalogID_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_CatalogID IoHwAb_Get_Dio_CatalogID
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_CatalogID(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) CatalogId); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_0> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_0(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Debug_0 IoHwAb_Get_Dio_Debug_0
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_1> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Debug_1 IoHwAb_Get_Dio_Debug_1
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_2
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_2> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_2(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Debug_2 IoHwAb_Get_Dio_Debug_2
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_2(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_3
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_3> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_3>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_3(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Debug_3 IoHwAb_Get_Dio_Debug_3
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_3(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Diag_Out_Sw_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Diag_Out_Sw_En> of PortPrototype <PP_IoHwAb_Get_Dio_Diag_Out_Sw_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Diag_Out_Sw_En IoHwAb_Get_Dio_Diag_Out_Sw_En
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Diag_Out_Sw_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Errout
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Errout> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Errout>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Errout(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Errout IoHwAb_Get_Dio_Eq4_Errout
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Errout(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev0_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev0_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev0_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Rev0_Pm IoHwAb_Get_Dio_Eq4_Rev0_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev0_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev1_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev1_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev1_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Rev1_Pm IoHwAb_Get_Dio_Eq4_Rev1_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev1_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev2_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev2_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev2_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Rev2_Pm IoHwAb_Get_Dio_Eq4_Rev2_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev2_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev3_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev3_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev3_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Rev3_Pm IoHwAb_Get_Dio_Eq4_Rev3_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev3_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev4_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev4_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev4_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Rev4_Pm IoHwAb_Get_Dio_Eq4_Rev4_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev4_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Xint
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Xint> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Xint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Xint(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eq4_Xint IoHwAb_Get_Dio_Eq4_Xint
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Xint(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_EyeQ_Init_Ready
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_EyeQ_Init_Ready> of PortPrototype <PP_IoHwAb_Get_Dio_EyeQ_Init_Ready>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_EyeQ_Init_Ready(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_EyeQ_Init_Ready IoHwAb_Get_Dio_EyeQ_Init_Ready
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_EyeQ_Init_Ready(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio16
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio16> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio16>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio16(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio16 IoHwAb_Get_Dio_Eyeq4_Gpio16
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio16(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio17
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio17> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio17>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio17(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio17 IoHwAb_Get_Dio_Eyeq4_Gpio17
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio17(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1 IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync> of PortPrototype <PP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Heater_Ch0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Heater_Ch0> of PortPrototype <PP_IoHwAb_Get_Dio_Heater_Ch0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Heater_Ch0(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Heater_Ch0 IoHwAb_Get_Dio_Heater_Ch0
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Heater_Ch0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Heater_Diag_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Heater_Diag_En> of PortPrototype <PP_IoHwAb_Get_Dio_Heater_Diag_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Heater_Diag_En(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Heater_Diag_En IoHwAb_Get_Dio_Heater_Diag_En
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Heater_Diag_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Micro_Sfi_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Micro_Sfi_Enable> of PortPrototype <PP_IoHwAb_Get_Dio_Micro_Sfi_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Micro_Sfi_Enable IoHwAb_Get_Dio_Micro_Sfi_Enable
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Micro_Sfi_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Off_Battery_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Off_Battery_Enable> of PortPrototype <PP_IoHwAb_Get_Dio_Off_Battery_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Off_Battery_Enable(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Off_Battery_Enable IoHwAb_Get_Dio_Off_Battery_Enable
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Off_Battery_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_1V1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_1V1> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_1V1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_1V1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Psu_En_1V1 IoHwAb_Get_Dio_Psu_En_1V1
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_1V1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_1V8_Ddr
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_1V8_Ddr> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Psu_En_1V8_Ddr IoHwAb_Get_Dio_Psu_En_1V8_Ddr
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_1V8_Ddr(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_Vision_Supplies
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_Vision_Supplies> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Get_Dio_Psu_En_Vision_Supplies IoHwAb_Get_Dio_Psu_En_Vision_Supplies
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_Vision_Supplies(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_GetFailSafeStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_GetFailSafeStatus> of PortPrototype <PP_IoHwAb_HEATER_GetFailSafeStatus>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_GetFailSafeStatus(IoHwAb_Heater_FailSafeStatusType *FailSafeStatus_pu8, IoHwAb_Heater_StateType *state_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_GetFailSafeStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_HEATER_GetFailSafeStatus IoHwAb_HEATER_GetFailSafeStatus
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_GetFailSafeStatus(P2VAR(IoHwAb_Heater_FailSafeStatusType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) FailSafeStatus_pu8, P2VAR(IoHwAb_Heater_StateType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) state_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_GetStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_GetStatus> of PortPrototype <PP_IoHwAb_HEATER_GetStatus>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_GetStatus(uint8 *status_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_GetStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_HEATER_GetStatus IoHwAb_HEATER_GetStatus
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_GetStatus(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_TurnOn
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_TurnOn> of PortPrototype <PP_IoHwAb_HEATER_TurnOn>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_TurnOn(boolean HeaterOn_b, boolean *Status_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_TurnOn_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_HEATER_TurnOn IoHwAb_HEATER_TurnOn
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_TurnOn(boolean HeaterOn_b, P2VAR(boolean, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore0Ready> of PortPrototype <RP_ProxyCore0Ready>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_WdgM_General_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Init IoHwAb_Init
FUNC(void, IoHwAb_CODE) IoHwAb_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Implicit S/R API:
 *   -----------------
 *   void Rte_IWrite_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(uint16 data)
 *   uint16 *Rte_IWriteRef_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(void)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_GetCurrentState_EyeQMgr_GetCurrentState(uint8 *EyeQMgrState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_GetCurrentState_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_SendErrorAndAction_EyeQMgr_SendErrorAndAction(uint8 DesiredCoreState_u8, uint32 ErrorCode_u32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_SendErrorAndAction_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_10ms IoHwAb_PowerMgr_10ms
FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_10ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_2ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 2ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_IOHWAB_PWRMGR_SetFOTAChipSelectPin_IOHWAB_PWRMGR_SetFOTAChipSelectPin(Rte_Dio_LevelType *chipSelect_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IOHWAB_PWRMGR_SetFOTAChipSelectPin_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_PowerMgr_GetCatalogID_IoHwAb_PowerMgr_GetCatalogID(uint8 *EyeQCatalogId_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_2ms IoHwAb_PowerMgr_2ms
FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_2ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_GetCurrentState
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_GetCurrentState> of PortPrototype <PP_IoHwAb_PowerMgr_GetCurrentState>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_PowerMgr_GetCurrentState(uint8 *PowerMgrState_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_PowerMgr_GetCurrentState_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_GetCurrentState IoHwAb_PowerMgr_GetCurrentState
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_PowerMgr_GetCurrentState(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) PowerMgrState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_RestartVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_RestartVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_RestartVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_RestartVisionSys(uint8 AppMode_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_RestartVisionSys IoHwAb_PowerMgr_RestartVisionSys
FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_RestartVisionSys(uint8 AppMode_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_TurnOffVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_TurnOffVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_TurnOffVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_TurnOffVisionSys(void)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_TurnOffVisionSys IoHwAb_PowerMgr_TurnOffVisionSys
FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_TurnOffVisionSys(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_TurnOnVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_TurnOnVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_TurnOnVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_TurnOnVisionSys(uint8 AppMode_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_TurnOnVisionSys IoHwAb_PowerMgr_TurnOnVisionSys
FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_TurnOnVisionSys(uint8 AppMode_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_1V5_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_1V5_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN IoHwAb_Set_Dio_1V5_PSU_MICRO_EN
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_1V8_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_1V8_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN IoHwAb_Set_Dio_1V8_PSU_MICRO_EN
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_0> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Debug_0 IoHwAb_Set_Dio_Debug_0
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_1> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Debug_1 IoHwAb_Set_Dio_Debug_1
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_2
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_2> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Debug_2 IoHwAb_Set_Dio_Debug_2
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_3
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_3> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_3>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Debug_3 IoHwAb_Set_Dio_Debug_3
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Diag_Out_Sw_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Diag_Out_Sw_En> of PortPrototype <PP_IoHwAb_Set_Dio_Diag_Out_Sw_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Diag_Out_Sw_En IoHwAb_Set_Dio_Diag_Out_Sw_En
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev0_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev0_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev0_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Rev0_Pm IoHwAb_Set_Dio_Eq4_Rev0_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev1_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev1_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev1_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Rev1_Pm IoHwAb_Set_Dio_Eq4_Rev1_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev2_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev2_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev2_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Rev2_Pm IoHwAb_Set_Dio_Eq4_Rev2_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev3_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev3_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev3_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Rev3_Pm IoHwAb_Set_Dio_Eq4_Rev3_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev4_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev4_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev4_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Rev4_Pm IoHwAb_Set_Dio_Eq4_Rev4_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Xint
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Xint> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Xint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eq4_Xint IoHwAb_Set_Dio_Eq4_Xint
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Heater_Ch0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Heater_Ch0> of PortPrototype <PP_IoHwAb_Set_Dio_Heater_Ch0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Heater_Ch0 IoHwAb_Set_Dio_Heater_Ch0
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Heater_Diag_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Heater_Diag_En> of PortPrototype <PP_IoHwAb_Set_Dio_Heater_Diag_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Heater_Diag_En IoHwAb_Set_Dio_Heater_Diag_En
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Micro_Sfi_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Micro_Sfi_Enable> of PortPrototype <PP_IoHwAb_Set_Dio_Micro_Sfi_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Micro_Sfi_Enable IoHwAb_Set_Dio_Micro_Sfi_Enable
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Off_Battery_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Off_Battery_Enable> of PortPrototype <PP_IoHwAb_Set_Dio_Off_Battery_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Off_Battery_Enable IoHwAb_Set_Dio_Off_Battery_Enable
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_1V1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_1V1> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_1V1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Psu_En_1V1 IoHwAb_Set_Dio_Psu_En_1V1
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_1V8_Ddr
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_1V8_Ddr> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Psu_En_1V8_Ddr IoHwAb_Set_Dio_Psu_En_1V8_Ddr
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_Vision_Supplies
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_Vision_Supplies> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Set_Dio_Psu_En_Vision_Supplies IoHwAb_Set_Dio_Psu_En_Vision_Supplies
FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Thermal_GetShutdownTemperatures
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Thermal_GetShutdownTemperatures> of PortPrototype <PP_IoHwAb_Thermal_GetShutdownTemperatures>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Thermal_GetShutdownTemperatures(boolean *status_pb, EYEQTHSD_ThermalShutdownValues_t *thermalShutdownValues_p)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Thermal_GetShutdownTemperatures_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_Thermal_GetShutdownTemperatures IoHwAb_Thermal_GetShutdownTemperatures
FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Thermal_GetShutdownTemperatures(P2VAR(boolean, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pb, P2VAR(EYEQTHSD_ThermalShutdownValues_t, AUTOMATIC, RTE_IOHWAB_APPL_VAR) thermalShutdownValues_p); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define IoHwAb_STOP_SEC_CODE
# include "IoHwAb_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EYEQDG_APP_ReturnType (1U)

# define RTE_E_IF_EYEQDG_BOOTADV_ReturnType (1U)

# define RTE_E_IF_EyeQMCD_NotifyEyeQCoreDump_ReturnType (1U)

# define RTE_E_IF_EyeQMgr_GetCurrentState_ReturnType (1U)

# define RTE_E_IF_EyeQMgr_IsThermalShutdownSet_ReturnType (1U)

# define RTE_E_IF_EyeQMgr_SendErrorAndAction_ReturnType (1U)

# define RTE_E_IF_EyeQMgr_SetErrOutPinStatusNotify_ReturnType (1U)

# define RTE_E_IF_IOHWAB_PWRMGR_SetFOTAChipSelectPin_ReturnType (1U)

# define RTE_E_IF_IoHwAb_ADCDIAG_GetADCSeedArray_ReturnType (1U)

# define RTE_E_IF_IoHwAb_DIODIAG_SetErrOutPinDiagState_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_BoardRev_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_CatalogID_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType (1U)

# define RTE_E_IF_IoHwAb_HEATER_GetFailSafeStatus_ReturnType (1U)

# define RTE_E_IF_IoHwAb_HEATER_GetStatus_ReturnType (1U)

# define RTE_E_IF_IoHwAb_HEATER_TurnOn_ReturnType (1U)

# define RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType (1U)

# define RTE_E_IF_IoHwAb_PowerMgr_GetCurrentState_ReturnType (1U)

# define RTE_E_IF_IoHwAb_ThermalMgr_ShutdownNotify_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Thermal_GetShutdownTemperatures_ReturnType (1U)

# define RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK (1U)

# define RTE_E_IF_Proxy_DiagnosticMonitor_E_OK (0U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# define RTE_E_WdgM_General_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_IOHWAB_H */
