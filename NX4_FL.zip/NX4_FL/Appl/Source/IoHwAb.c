/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  IoHwAb.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  IoHwAb
 *  Generation Time:  2023-04-20 13:53:33
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <IoHwAb>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Dem_EventStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IoHwAb_Heater_FailSafeStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IoHwAb_Heater_StateType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IoHwAb_Thermal_Shutdown_SourceType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_Adc_ValueGroupType
 *   uint16 represents integers with a minimum value of 0 and a maximum value of 65535.
 *      The order-relation on uint16 is: x < y if y - x is positive.
 *      uint16 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 1267, +10000.
 *
 * Rte_Dio_LevelType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * WdgM_SupervisedEntityIdType
 *   uint16 represents integers with a minimum value of 0 and a maximum value of 65535.
 *      The order-relation on uint16 is: x < y if y - x is positive.
 *      uint16 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 1267, +10000.
 *
 *
 * Operation Prototypes:
 * =====================
 * ActivateSupervisionEntity of Port Interface WdgM_General
 *   Activates the supervision of the given supervised entity.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_IoHwAb.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * Rte_Adc_ValueGroupType: Integer in interval [0...65535]
 * Rte_Dio_LevelType: Integer in interval [0...255]
 * WdgM_SupervisedEntityIdType: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Dem_EventStatusType: Enumeration of integer in interval [0...255] with enumerators
 *   DEM_EVENT_STATUS_PASSED (0U)
 *   DEM_EVENT_STATUS_FAILED (1U)
 *   DEM_EVENT_STATUS_PREPASSED (2U)
 *   DEM_EVENT_STATUS_PREFAILED (3U)
 *   DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED (4U)
 *   DEM_EVENT_STATUS_PASSED_CONDITIONS_NOT_FULFILLED (5U)
 *   DEM_EVENT_STATUS_FAILED_CONDITIONS_NOT_FULFILLED (6U)
 *   DEM_EVENT_STATUS_PREPASSED_CONDITIONS_NOT_FULFILLED (7U)
 *   DEM_EVENT_STATUS_PREFAILED_CONDITIONS_NOT_FULFILLED (8U)
 * IoHwAb_Heater_FailSafeStatusType: Enumeration of integer in interval [0...255] with enumerators
 *   HEATER_FAILSAFE_DISABLED (5U)
 *   HEATER_FAILSAFE_OPEN_LOAD (1U)
 *   HEATER_FAILSAFE_OVER_CURRENT (4U)
 *   HEATER_FAILSAFE_READY (0U)
 *   HEATER_FAILSAFE_SHORT_LOAD_GND (3U)
 *   HEATER_FAILSAFE_SHORT_LOAD_PWR (2U)
 *   HEATER_FAILSAFE_UNAVAILABLE_STATE (6U)
 * IoHwAb_Heater_StateType: Enumeration of integer in interval [0...255] with enumerators
 *   HEATER_STATE_CHECK_CONNECTION (4U)
 *   HEATER_STATE_FAILSAFE (7U)
 *   HEATER_STATE_INIT (0U)
 *   HEATER_STATE_OFF (1U)
 *   HEATER_STATE_ON (3U)
 *   HEATER_STATE_PREPARE_CHECK_CONNECTION (5U)
 *   HEATER_STATE_UNUSED (2U)
 *   HEATER_STATE_WAIT_AFTER_SHORT_LOAD (6U)
 * IoHwAb_Thermal_Shutdown_SourceType: Enumeration of integer in interval [0...255] with enumerators
 *   IOHWAB_THERMAL_SHUTDOWN_BOOTCPU (17U)
 *   IOHWAB_THERMAL_SHUTDOWN_BOOTVMP (16U)
 *   IOHWAB_THERMAL_SHUTDOWN_DDRDIE (3U)
 *   IOHWAB_THERMAL_SHUTDOWN_DDRTHERM (9U)
 *   IOHWAB_THERMAL_SHUTDOWN_ERROUT (13U)
 *   IOHWAB_THERMAL_SHUTDOWN_EYEQDIE (2U)
 *   IOHWAB_THERMAL_SHUTDOWN_EYEQOVERTEMP (15U)
 *   IOHWAB_THERMAL_SHUTDOWN_EYEQTHERM (8U)
 *   IOHWAB_THERMAL_SHUTDOWN_GPIO15 (14U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER1DIE (4U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER1THERM (10U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER2DIE (5U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER2THERM (11U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER3DIE (6U)
 *   IOHWAB_THERMAL_SHUTDOWN_IMAGER3THERM (12U)
 *   IOHWAB_THERMAL_SHUTDOWN_MCUDIE (1U)
 *   IOHWAB_THERMAL_SHUTDOWN_MCUTHERM (7U)
 *   IOHWAB_THERMAL_SHUTDOWN_NO_SOURCE (0U)
 *   IOHWAB_THERMAL_SHUTDOWN_UNKNOWN (18U)
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Record Types:
 * =============
 * EYEQTHSD_ThermalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   EyeQThermalStrategyEnabled_u8 of type uint8
 *   ThermistorHysteresisCheckEnable_u8 of type uint8
 *   ThermalDiagnosticDebounceLimit_u8 of type uint8
 *   MainImagerDieCheckEnable_u8 of type uint8
 *   FishEyeImagerDieCheckEnable_u8 of type uint8
 *   NarrowImagerDieCheckEnable_u8 of type uint8
 *   EyeQDieCheckEnable_u8 of type uint8
 *   DDRDieCheckEnable_u8 of type uint8
 *   MainImagerThermistorCheckEnable_u8 of type uint8
 *   FishEyeImagerThermistorCheckEnable_u8 of type uint8
 *   NarrowImagerThermistorCheckEnable_u8 of type uint8
 *   EyeQThermistorCheckEnable_u8 of type uint8
 *   DDRThermistorCheckEnable_u8 of type uint8
 *   AurixThermistorCheckEnable_u8 of type uint8
 *   MainImagerDieHighUpperThreshold_s8 of type sint8
 *   FishEyeImagerDieHighUpperThreshold_s8 of type sint8
 *   NarrowImagerDieHighUpperThreshold_s8 of type sint8
 *   MainImagerDieLowLowerThreshold_s8 of type sint8
 *   FishEyeImagerDieLowLowerThreshold_s8 of type sint8
 *   NarrowImagerDieLowLowerThreshold_s8 of type sint8
 *   EyeQDieHighUpperThreshold_s16 of type sint16
 *   EyeQDieLowLowerThreshold_s16 of type sint16
 *   AurixDie1HighUpperThreshold_u16 of type uint16
 *   AurixDie1HighLowerThreshold_u16 of type uint16
 *   AurixDie2HighUpperThreshold_u16 of type uint16
 *   AurixDie2HighLowerThreshold_u16 of type uint16
 *   AurixDie1LowLowerThreshold_u16 of type uint16
 *   AurixDie2LowLowerThreshold_u16 of type uint16
 *   MainImagerThermistorHighUpperThreshold_u16 of type uint16
 *   MainImagerThermistorHighLowerThreshold_u16 of type uint16
 *   FishEyeImagerThermistorHighUpperThreshold_u16 of type uint16
 *   FishEyeImagerThermistorHighLowerThreshold_u16 of type uint16
 *   NarrowImagerThermistorHighUpperThreshold_u16 of type uint16
 *   NarrowImagerThermistorHighLowerThreshold_u16 of type uint16
 *   EyeQThermistorHighUpperThreshold_u16 of type uint16
 *   EyeQThermistorHighLowerThreshold_u16 of type uint16
 *   DDRThermistorHighUpperThreshold_u16 of type uint16
 *   DDRThermistorHighLowerThreshold_u16 of type uint16
 *   AurixThermistorHighUpperThreshold_u16 of type uint16
 *   AurixThermistorHighLowerThreshold_u16 of type uint16
 *   SensorDiagMainImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagMainImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagFishEyeImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagFishEyeImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagNarrowImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagNarrowImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagEyeQThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagEyeQThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagDDRThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagDDRThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagAurixThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagAurixThermistorLowerThreshold_u16 of type uint16
 *   Reserved0_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EYEQTHSD_ThermalShutdownValues_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   MainImagerThermistorTemparature_u16 of type uint16
 *   FishEyeImagerThermistorTemparature_u16 of type uint16
 *   NarrowImagerThermistorTemparature_u16 of type uint16
 *   AurixThermistorTemparature_u16 of type uint16
 *   EyeQThermistorTemparature_u16 of type uint16
 *   DDRThermistorTemparature_u16 of type uint16
 *   AurixDie1Temparature_u16 of type uint16
 *   AurixDie2Temparature_u16 of type uint16
 *   EyeQDieTemparature1_s16 of type sint16
 *   EyeQDieTemparature2_s16 of type sint16
 *   MainImagerDieTemparature1_s8 of type sint8
 *   MainImagerDieTemparature2_s8 of type sint8
 *   FishEyeImagerDieTemparature1_s8 of type sint8
 *   FishEyeImagerDieTemparature2_s8 of type sint8
 *   NarrowImagerDieTemparature1_s8 of type sint8
 *   NarrowImagerDieTemparature2_s8 of type sint8
 *   DDRDieTemparature_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   ThermalShutdownCounter_u32 of type uint32
 *   Reserved2_u32 of type uint32
 *   Reserved0_u16 of type uint16
 *   calCRC_u16 of type uint16
 * IoHwAb_HeaterInfo_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   HeaterCounter_u32 of type uint32
 *   HeaterStatus_u8 of type uint8
 *   Reserved_1_u8 of type uint8
 *   Reserved_2_u16 of type uint16
 *   Reserved_3_u16 of type uint16
 *   calCRC_u16 of type uint16
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   EYEQTHSD_ThermalParams_t *Rte_Pim_EYEQTHSD_ThermalParams(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownPrimary(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownSecondary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary(void)
 *
 *********************************************************************************************************************/


#define IoHwAb_START_SEC_CODE
#include "IoHwAb_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAbNvM_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_CPU_Temperature(sint8 *BOOT_CPU_Temperature)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_BOOTADV_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_BOOTADV_EYEQDG_Get_BOOTADV_BOOT_VMP_Temperature(sint8 *BOOT_VMP_Temperature)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_BOOTADV_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_IsThermalShutdownSet_EyeQMgr_IsThermalShutdownSet(uint8 *status_pu8, uint8 *reason_pu8, IoHwAb_Thermal_Shutdown_SourceType *source_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_IsThermalShutdownSet_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_ThermalMgr_ShutdownNotify_IoHwAb_ThermalMgr_ShutdownNotify(uint8 status_u8, uint8 reason_u8, IoHwAb_Thermal_Shutdown_SourceType source_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_ThermalMgr_ShutdownNotify_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAbNvM_Run_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAbNvM_Run(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAbNvM_Run
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_ADCDIAG_GetADCSeedArray
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_ADCDIAG_GetADCSeedArray> of PortPrototype <PP_IoHwAb_ADCDIAG_GetADCSeedArray>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_ADCDIAG_GetADCSeedArray(uint8 *adcSeedArray_pau8, uint16 expectedSize_u16, uint8 *result_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_ADCDIAG_GetADCSeedArray_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_ADCDIAG_GetADCSeedArray_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_ADCDIAG_GetADCSeedArray(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) adcSeedArray_pau8, uint16 expectedSize_u16, P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) result_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_ADCDIAG_GetADCSeedArray (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_ADH_Service
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_EyeQMCD_NotifyEyeQCoreDump_EyeQMCD_NotifyEyeQCoreDump(uint8 CoreDumpStatus_u8, boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMCD_NotifyEyeQCoreDump_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_SetErrOutPinStatusNotify_EyeQMgr_SetErrOutPinStatusNotify(uint8 Status_u8, uint8 Result_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_SetErrOutPinStatusNotify_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_ADH_Service_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_ADH_Service(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_ADH_Service
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_DIODIAG_SetErrOutPinDiagState
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_DIODIAG_SetErrOutPinDiagState> of PortPrototype <PP_IoHwAb_DIODIAG_SetErrOutPinDiagState>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_DIODIAG_SetErrOutPinDiagState(uint8 SetCmd_u8, uint8 *Result_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_DIODIAG_SetErrOutPinDiagState_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_DIODIAG_SetErrOutPinDiagState_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_DIODIAG_SetErrOutPinDiagState(uint8 SetCmd_u8, P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Result_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_DIODIAG_SetErrOutPinDiagState (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V0_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V0_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V0_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V0_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V0_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V1_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V1_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V1_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V1_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V1_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V1_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V1_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V8_DDR_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V8_DDR_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V8_DDR_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V8_DDR_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V8_DDR_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V8_DDR_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V8_DDR_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_1V8_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_1V8_MON> of PortPrototype <PP_IoHwAb_Get_ADC_1V8_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_1V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V8_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_1V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_1V8_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_2V8_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_2V8_MON> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_2V8_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_2V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_2V8_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_2V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_2V8_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_FEYE_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_FEYE_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_FEYE_MON_ADC (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_MAIN_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_MAIN_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_MAIN_MON_ADC (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_MON> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_3V3_NARROW_MON_ADC
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_3V3_NARROW_MON_ADC> of PortPrototype <PP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_3V3_NARROW_MON_ADC (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_5V0_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_5V0_MON> of PortPrototype <PP_IoHwAb_Get_ADC_5V0_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_5V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_5V0_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_5V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_5V0_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_ADC_REF_CAL
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_ADC_REF_CAL> of PortPrototype <PP_IoHwAb_Get_ADC_ADC_REF_CAL>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_ADC_REF_CAL(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_ADC_REF_CAL_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_ADC_REF_CAL(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_ADC_REF_CAL (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_EQ4_MON_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_EQ4_MON_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_EQ4_MON_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_EQ4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_EQ4_MON_TEMP_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_EQ4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_EQ4_MON_TEMP (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_FEYE_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_FEYE_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_FEYE_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_FEYE_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_FEYE_TEMP_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_FEYE_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_FEYE_TEMP_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_LKA_SW_INPUT
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_LKA_SW_INPUT> of PortPrototype <PP_IoHwAb_Get_ADC_LKA_SW_INPUT>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_LKA_SW_INPUT(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_LKA_SW_INPUT_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_LKA_SW_INPUT(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_LKA_SW_INPUT (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_LPDDR4_MON_TEMP
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_LPDDR4_MON_TEMP> of PortPrototype <PP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_LPDDR4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_LPDDR4_MON_TEMP_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_LPDDR4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_LPDDR4_MON_TEMP (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_MAIN_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_MAIN_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_MAIN_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_MAIN_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_MAIN_TEMP_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_MAIN_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_MAIN_TEMP_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_MICRO_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_MICRO_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_MICRO_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_MICRO_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_MICRO_TEMP_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_MICRO_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_MICRO_TEMP_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_NARROW_TEMP_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_NARROW_TEMP_MON> of PortPrototype <PP_IoHwAb_Get_ADC_NARROW_TEMP_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_NARROW_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_NARROW_TEMP_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_NARROW_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_NARROW_TEMP_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_PSU_1V3_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_PSU_1V3_MON> of PortPrototype <PP_IoHwAb_Get_ADC_PSU_1V3_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_PSU_1V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_PSU_1V3_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_PSU_1V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_PSU_1V3_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_PSU_IMAGER_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_PSU_IMAGER_MON> of PortPrototype <PP_IoHwAb_Get_ADC_PSU_IMAGER_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_PSU_IMAGER_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_PSU_IMAGER_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_PSU_IMAGER_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_PSU_IMAGER_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_SENSE_HEATER
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_SENSE_HEATER> of PortPrototype <PP_IoHwAb_Get_ADC_SENSE_HEATER>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_SENSE_HEATER(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_SENSE_HEATER_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_SENSE_HEATER(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_SENSE_HEATER (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_ADC_VBATT_MON
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_ADC_VBATT_MON> of PortPrototype <PP_IoHwAb_Get_ADC_VBATT_MON>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_ADC_VBATT_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_VBATT_MON_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_ADC_VBATT_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) DataBufferPointer_u16) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_ADC_VBATT_MON (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_BoardRev
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_BoardRev> of PortPrototype <PP_IoHwAb_Get_BoardRev>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_BoardRev(uint8 *BoardRev_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_BoardRev_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_BoardRev_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_BoardRev(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) BoardRev_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_BoardRev (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_1V5_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_1V5_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_1V5_PSU_MICRO_EN (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_1V8_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_1V8_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_1V8_PSU_MICRO_EN (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_CatalogID
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_CatalogID> of PortPrototype <PP_IoHwAb_Get_Dio_CatalogID>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_CatalogID(uint8 *CatalogId)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_CatalogID_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_CatalogID_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_CatalogID(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) CatalogId) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_CatalogID (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_0> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_0(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_0_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_0 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_1> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_1 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_2
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_2> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_2(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_2_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_2(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_2 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Debug_3
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Debug_3> of PortPrototype <PP_IoHwAb_Get_Dio_Debug_3>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Debug_3(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_3_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Debug_3(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Debug_3 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Diag_Out_Sw_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Diag_Out_Sw_En> of PortPrototype <PP_IoHwAb_Get_Dio_Diag_Out_Sw_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Diag_Out_Sw_En_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Diag_Out_Sw_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Diag_Out_Sw_En (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Errout
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Errout> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Errout>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Errout(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Errout_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Errout(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Errout (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev0_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev0_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev0_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev0_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev0_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev0_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev1_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev1_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev1_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev1_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev1_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev1_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev2_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev2_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev2_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev2_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev2_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev2_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev3_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev3_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev3_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev3_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev3_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev3_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Rev4_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Rev4_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Rev4_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev4_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Rev4_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Rev4_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eq4_Xint
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eq4_Xint> of PortPrototype <PP_IoHwAb_Get_Dio_Eq4_Xint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eq4_Xint(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Xint_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eq4_Xint(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eq4_Xint (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_EyeQ_Init_Ready
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_EyeQ_Init_Ready> of PortPrototype <PP_IoHwAb_Get_Dio_EyeQ_Init_Ready>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_EyeQ_Init_Ready(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_EyeQ_Init_Ready_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_EyeQ_Init_Ready(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_EyeQ_Init_Ready (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio16
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio16> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio16>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio16(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio16_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio16(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio16 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio17
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio17> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio17>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio17(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio17_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio17(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio17 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1> of PortPrototype <PP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync> of PortPrototype <PP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Heater_Ch0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Heater_Ch0> of PortPrototype <PP_IoHwAb_Get_Dio_Heater_Ch0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Heater_Ch0(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Heater_Ch0_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Heater_Ch0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Heater_Ch0 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Heater_Diag_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Heater_Diag_En> of PortPrototype <PP_IoHwAb_Get_Dio_Heater_Diag_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Heater_Diag_En(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Heater_Diag_En_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Heater_Diag_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Heater_Diag_En (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm> of PortPrototype <PP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Micro_Sfi_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Micro_Sfi_Enable> of PortPrototype <PP_IoHwAb_Get_Dio_Micro_Sfi_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Micro_Sfi_Enable_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Micro_Sfi_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Micro_Sfi_Enable (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Off_Battery_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Off_Battery_Enable> of PortPrototype <PP_IoHwAb_Get_Dio_Off_Battery_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Off_Battery_Enable(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Off_Battery_Enable_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Off_Battery_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Off_Battery_Enable (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_1V1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_1V1> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_1V1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_1V1(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_1V1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_1V1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_1V1 (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_1V8_Ddr
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_1V8_Ddr> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_1V8_Ddr_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_1V8_Ddr(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_1V8_Ddr (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Get_Dio_Psu_En_Vision_Supplies
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Get_Dio_Psu_En_Vision_Supplies> of PortPrototype <PP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Get_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType *Level_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_Vision_Supplies_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Get_Dio_Psu_En_Vision_Supplies(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Level_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Get_Dio_Psu_En_Vision_Supplies (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_GetFailSafeStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_GetFailSafeStatus> of PortPrototype <PP_IoHwAb_HEATER_GetFailSafeStatus>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_GetFailSafeStatus(IoHwAb_Heater_FailSafeStatusType *FailSafeStatus_pu8, IoHwAb_Heater_StateType *state_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_GetFailSafeStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_GetFailSafeStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_GetFailSafeStatus(P2VAR(IoHwAb_Heater_FailSafeStatusType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) FailSafeStatus_pu8, P2VAR(IoHwAb_Heater_StateType, AUTOMATIC, RTE_IOHWAB_APPL_VAR) state_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_GetFailSafeStatus (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_GetStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_GetStatus> of PortPrototype <PP_IoHwAb_HEATER_GetStatus>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_GetStatus(uint8 *status_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_GetStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_GetStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_GetStatus(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_GetStatus (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_HEATER_TurnOn
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_HEATER_TurnOn> of PortPrototype <PP_IoHwAb_HEATER_TurnOn>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_HEATER_TurnOn(boolean HeaterOn_b, boolean *Status_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_HEATER_TurnOn_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_TurnOn_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_HEATER_TurnOn(boolean HeaterOn_b, P2VAR(boolean, AUTOMATIC, RTE_IOHWAB_APPL_VAR) Status_pb) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_HEATER_TurnOn (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore0Ready> of PortPrototype <RP_ProxyCore0Ready>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_WdgM_General_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Implicit S/R API:
 *   -----------------
 *   void Rte_IWrite_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(uint16 data)
 *   uint16 *Rte_IWriteRef_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(void)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_GetCurrentState_EyeQMgr_GetCurrentState(uint8 *EyeQMgrState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_GetCurrentState_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQMgr_SendErrorAndAction_EyeQMgr_SendErrorAndAction(uint8 DesiredCoreState_u8, uint32 ErrorCode_u32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQMgr_SendErrorAndAction_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_10ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_10ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_10ms
 *********************************************************************************************************************/

#ifdef RTE_INIT_IMPLICIT_BUFFERS
  Rte_IWrite_IoHwAb_PowerMgr_10ms_PP_IoHwAb_AdcRaw_VBATT_MON(Rte_InitValue_PP_IoHwAb_AdcRaw_VBATT_MON);
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_2ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 2ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK, RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *   Std_ReturnType Rte_Call_RP_IOHWAB_PWRMGR_SetFOTAChipSelectPin_IOHWAB_PWRMGR_SetFOTAChipSelectPin(Rte_Dio_LevelType *chipSelect_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IOHWAB_PWRMGR_SetFOTAChipSelectPin_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_PowerMgr_GetCatalogID_IoHwAb_PowerMgr_GetCatalogID(uint8 *EyeQCatalogId_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_2ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_2ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_2ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_GetCurrentState
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_GetCurrentState> of PortPrototype <PP_IoHwAb_PowerMgr_GetCurrentState>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_PowerMgr_GetCurrentState(uint8 *PowerMgrState_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_PowerMgr_GetCurrentState_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_GetCurrentState_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_PowerMgr_GetCurrentState(P2VAR(uint8, AUTOMATIC, RTE_IOHWAB_APPL_VAR) PowerMgrState_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_GetCurrentState (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_RestartVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_RestartVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_RestartVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_RestartVisionSys(uint8 AppMode_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_RestartVisionSys_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_RestartVisionSys(uint8 AppMode_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_RestartVisionSys
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_TurnOffVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_TurnOffVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_TurnOffVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_TurnOffVisionSys(void)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_TurnOffVisionSys_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_TurnOffVisionSys(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_TurnOffVisionSys
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_TurnOnVisionSys
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_TurnOnVisionSys> of PortPrototype <PP_IoHwAb_PowerMgr_TurnOnVisionSys>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_PowerMgr_TurnOnVisionSys(uint8 AppMode_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_TurnOnVisionSys_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_PowerMgr_TurnOnVisionSys(uint8 AppMode_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_TurnOnVisionSys
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_1V5_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_1V5_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_1V5_PSU_MICRO_EN
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_1V8_PSU_MICRO_EN
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_1V8_PSU_MICRO_EN> of PortPrototype <PP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_1V8_PSU_MICRO_EN
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_0> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_0_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_0
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_1> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_1
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_2
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_2> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_2_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_2
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Debug_3
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Debug_3> of PortPrototype <PP_IoHwAb_Set_Dio_Debug_3>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_3_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Debug_3
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Diag_Out_Sw_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Diag_Out_Sw_En> of PortPrototype <PP_IoHwAb_Set_Dio_Diag_Out_Sw_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Diag_Out_Sw_En_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Diag_Out_Sw_En
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev0_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev0_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev0_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev0_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev0_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev1_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev1_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev1_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev1_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev1_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev2_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev2_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev2_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev2_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev2_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev3_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev3_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev3_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev3_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev3_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Rev4_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Rev4_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Rev4_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev4_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Rev4_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eq4_Xint
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eq4_Xint> of PortPrototype <PP_IoHwAb_Set_Dio_Eq4_Xint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Xint_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eq4_Xint
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp> of PortPrototype <PP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Heater_Ch0
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Heater_Ch0> of PortPrototype <PP_IoHwAb_Set_Dio_Heater_Ch0>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Heater_Ch0_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Heater_Ch0
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Heater_Diag_En
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Heater_Diag_En> of PortPrototype <PP_IoHwAb_Set_Dio_Heater_Diag_En>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Heater_Diag_En_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Heater_Diag_En
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm> of PortPrototype <PP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Micro_Sfi_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Micro_Sfi_Enable> of PortPrototype <PP_IoHwAb_Set_Dio_Micro_Sfi_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Micro_Sfi_Enable_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Micro_Sfi_Enable
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Off_Battery_Enable
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Off_Battery_Enable> of PortPrototype <PP_IoHwAb_Set_Dio_Off_Battery_Enable>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Off_Battery_Enable_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Off_Battery_Enable
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_1V1
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_1V1> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_1V1>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_1V1_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_1V1
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_1V8_Ddr
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_1V8_Ddr> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_1V8_Ddr_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_1V8_Ddr
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Set_Dio_Psu_En_Vision_Supplies
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Set_Dio_Psu_En_Vision_Supplies> of PortPrototype <PP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_Vision_Supplies_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, IoHwAb_CODE) IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Set_Dio_Psu_En_Vision_Supplies
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_Thermal_GetShutdownTemperatures
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_Thermal_GetShutdownTemperatures> of PortPrototype <PP_IoHwAb_Thermal_GetShutdownTemperatures>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_Thermal_GetShutdownTemperatures(boolean *status_pb, EYEQTHSD_ThermalShutdownValues_t *thermalShutdownValues_p)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_Thermal_GetShutdownTemperatures_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Thermal_GetShutdownTemperatures_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, IoHwAb_CODE) IoHwAb_Thermal_GetShutdownTemperatures(P2VAR(boolean, AUTOMATIC, RTE_IOHWAB_APPL_VAR) status_pb, P2VAR(EYEQTHSD_ThermalShutdownValues_t, AUTOMATIC, RTE_IOHWAB_APPL_VAR) thermalShutdownValues_p) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_Thermal_GetShutdownTemperatures (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define IoHwAb_STOP_SEC_CODE
#include "IoHwAb_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
