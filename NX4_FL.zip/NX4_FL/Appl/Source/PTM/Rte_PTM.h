/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_PTM.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  PTM
 *  Generation Time:  2023-04-20 13:53:18
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <PTM> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_PTM_H
# define _RTE_PTM_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_PTM_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_PTM
{
  /* PIM Handles section */
  P2VAR(DvTest_Mode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DvTest_Mode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HKMC_TraceabilityInformation_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HKMC_TraceabilityInformation; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFECUHwNrDataId_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFECUHwNrDataId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFECUHwVerNrDataId_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFECUHwVerNrDataId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFManfrECUSerialNr_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFManfrECUSerialNr; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_PTM, RTE_CONST, RTE_CONST) Rte_Inst_PTM; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_PTM, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_GetPtmEepDump_GetEepDump(uint32 nvmAddr_u32, P2VAR(PtmEepDumpRecord_t, AUTOMATIC, RTE_PTM_APPL_VAR) ramAddr_u8, uint16 numBytes_u16, uint16 operation); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V0_MON_IoHwAb_Get_ADC_1V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V1_MON_IoHwAb_Get_ADC_1V1_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V8_DDR_MON_IoHwAb_Get_ADC_1V8_DDR_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V8_MON_IoHwAb_Get_ADC_1V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_2V8_MON_IoHwAb_Get_ADC_3V3_2V8_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_MON_IoHwAb_Get_ADC_3V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_5V0_MON_IoHwAb_Get_ADC_5V0_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_ADC_REF_CAL_IoHwAb_Get_ADC_ADC_REF_CAL(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_FEYE_TEMP_MON_IoHwAb_Get_ADC_FEYE_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_LKA_SW_INPUT_IoHwAb_Get_ADC_LKA_SW_INPUT(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_NARROW_TEMP_MON_IoHwAb_Get_ADC_NARROW_TEMP_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_PSU_1V3_MON_IoHwAb_Get_ADC_PSU_1V3_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_PSU_IMAGER_MON_IoHwAb_Get_ADC_PSU_IMAGER_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_SENSE_HEATER_IoHwAb_Get_ADC_SENSE_HEATER(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON(P2VAR(Rte_Adc_ValueGroupType, AUTOMATIC, RTE_PTM_APPL_VAR) DataBufferPointer_u16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_0_IoHwAb_Get_Dio_Debug_0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_1_IoHwAb_Get_Dio_Debug_1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_2_IoHwAb_Get_Dio_Debug_2(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_3_IoHwAb_Get_Dio_Debug_3(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Diag_Out_Sw_En_IoHwAb_Get_Dio_Diag_Out_Sw_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Errout_IoHwAb_Get_Dio_Eq4_Errout(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev0_Pm_IoHwAb_Get_Dio_Eq4_Rev0_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev1_Pm_IoHwAb_Get_Dio_Eq4_Rev1_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev2_Pm_IoHwAb_Get_Dio_Eq4_Rev2_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev3_Pm_IoHwAb_Get_Dio_Eq4_Rev3_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev4_Pm_IoHwAb_Get_Dio_Eq4_Rev4_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Xint_IoHwAb_Get_Dio_Eq4_Xint(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_EyeQ_Init_Ready_IoHwAb_Get_Dio_EyeQ_Init_Ready(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio16_IoHwAb_Get_Dio_Eyeq4_Gpio16(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio17_IoHwAb_Get_Dio_Eyeq4_Gpio17(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Heater_Ch0_IoHwAb_Get_Dio_Heater_Ch0(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Heater_Diag_En_IoHwAb_Get_Dio_Heater_Diag_En(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Micro_Sfi_Enable_IoHwAb_Get_Dio_Micro_Sfi_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Off_Battery_Enable_IoHwAb_Get_Dio_Off_Battery_Enable(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_1V1_IoHwAb_Get_Dio_Psu_En_1V1(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_IoHwAb_Get_Dio_Psu_En_1V8_Ddr(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_IoHwAb_Get_Dio_Psu_En_Vision_Supplies(P2VAR(Rte_Dio_LevelType, AUTOMATIC, RTE_PTM_APPL_VAR) Level_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_0_IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_1_IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_2_IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_3_IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Diag_Out_Sw_En_IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev0_Pm_IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev1_Pm_IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev2_Pm_IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev3_Pm_IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev4_Pm_IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Xint_IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Heater_Ch0_IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Heater_Diag_En_IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Micro_Sfi_Enable_IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Off_Battery_Enable_IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_1V1_IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr_IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies_IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_DvTest_Mode_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_NvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetCurrentSFRTestStatus(P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData(P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) sfrBuffer_pau8, P2VAR(uint16, AUTOMATIC, RTE_PTM_APPL_VAR) paramsCount_pu16, P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) reqStatus_pb, P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) SampleStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData(P2VAR(EYEQMESP_SFRBufferType, AUTOMATIC, RTE_PTM_APPL_VAR) sfrBuffer_pau8, P2VAR(uint16, AUTOMATIC, RTE_PTM_APPL_VAR) paramsCount_pu16, P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) reqStatus_pb, P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) SampleStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRTestResults(sint8 cameraType_s8, P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) isCameraFocused_pb, P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) failFlags_pu8, P2VAR(uint8, AUTOMATIC, RTE_PTM_APPL_VAR) nvmStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_SendSFRAnalysisResults(sint8 cameraType_s8, boolean isCameraFocused_bo, P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StartSFRProcessReq(P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) status_pb, sint8 cameraType_s8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StopSFRProcess(P2VAR(boolean, AUTOMATIC, RTE_PTM_APPL_VAR) status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_GetPtmEepDump_GetEepDump Rte_Call_PTM_RP_GetPtmEepDump_GetEepDump
# define Rte_Call_RP_IoHwAb_Get_ADC_1V0_MON_IoHwAb_Get_ADC_1V0_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V0_MON_IoHwAb_Get_ADC_1V0_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_1V1_MON_IoHwAb_Get_ADC_1V1_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V1_MON_IoHwAb_Get_ADC_1V1_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_1V8_DDR_MON_IoHwAb_Get_ADC_1V8_DDR_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V8_DDR_MON_IoHwAb_Get_ADC_1V8_DDR_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_1V8_MON_IoHwAb_Get_ADC_1V8_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_1V8_MON_IoHwAb_Get_ADC_1V8_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_3V3_2V8_MON_IoHwAb_Get_ADC_3V3_2V8_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_2V8_MON_IoHwAb_Get_ADC_3V3_2V8_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC
# define Rte_Call_RP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC
# define Rte_Call_RP_IoHwAb_Get_ADC_3V3_MON_IoHwAb_Get_ADC_3V3_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_MON_IoHwAb_Get_ADC_3V3_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC Rte_Call_PTM_RP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC
# define Rte_Call_RP_IoHwAb_Get_ADC_5V0_MON_IoHwAb_Get_ADC_5V0_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_5V0_MON_IoHwAb_Get_ADC_5V0_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_ADC_REF_CAL_IoHwAb_Get_ADC_ADC_REF_CAL Rte_Call_PTM_RP_IoHwAb_Get_ADC_ADC_REF_CAL_IoHwAb_Get_ADC_ADC_REF_CAL
# define Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP Rte_Call_PTM_RP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP Rte_Call_PTM_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP Rte_Call_PTM_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_FEYE_TEMP_MON_IoHwAb_Get_ADC_FEYE_TEMP_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_FEYE_TEMP_MON_IoHwAb_Get_ADC_FEYE_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_LKA_SW_INPUT_IoHwAb_Get_ADC_LKA_SW_INPUT Rte_Call_PTM_RP_IoHwAb_Get_ADC_LKA_SW_INPUT_IoHwAb_Get_ADC_LKA_SW_INPUT
# define Rte_Call_RP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP Rte_Call_PTM_RP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP
# define Rte_Call_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_NARROW_TEMP_MON_IoHwAb_Get_ADC_NARROW_TEMP_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_NARROW_TEMP_MON_IoHwAb_Get_ADC_NARROW_TEMP_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_PSU_1V3_MON_IoHwAb_Get_ADC_PSU_1V3_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_PSU_1V3_MON_IoHwAb_Get_ADC_PSU_1V3_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_PSU_IMAGER_MON_IoHwAb_Get_ADC_PSU_IMAGER_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_PSU_IMAGER_MON_IoHwAb_Get_ADC_PSU_IMAGER_MON
# define Rte_Call_RP_IoHwAb_Get_ADC_SENSE_HEATER_IoHwAb_Get_ADC_SENSE_HEATER Rte_Call_PTM_RP_IoHwAb_Get_ADC_SENSE_HEATER_IoHwAb_Get_ADC_SENSE_HEATER
# define Rte_Call_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON Rte_Call_PTM_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON
# define Rte_Call_RP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN Rte_Call_PTM_RP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN
# define Rte_Call_RP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN Rte_Call_PTM_RP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN
# define Rte_Call_RP_IoHwAb_Get_Dio_Debug_0_IoHwAb_Get_Dio_Debug_0 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_0_IoHwAb_Get_Dio_Debug_0
# define Rte_Call_RP_IoHwAb_Get_Dio_Debug_1_IoHwAb_Get_Dio_Debug_1 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_1_IoHwAb_Get_Dio_Debug_1
# define Rte_Call_RP_IoHwAb_Get_Dio_Debug_2_IoHwAb_Get_Dio_Debug_2 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_2_IoHwAb_Get_Dio_Debug_2
# define Rte_Call_RP_IoHwAb_Get_Dio_Debug_3_IoHwAb_Get_Dio_Debug_3 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Debug_3_IoHwAb_Get_Dio_Debug_3
# define Rte_Call_RP_IoHwAb_Get_Dio_Diag_Out_Sw_En_IoHwAb_Get_Dio_Diag_Out_Sw_En Rte_Call_PTM_RP_IoHwAb_Get_Dio_Diag_Out_Sw_En_IoHwAb_Get_Dio_Diag_Out_Sw_En
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Errout_IoHwAb_Get_Dio_Eq4_Errout Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Errout_IoHwAb_Get_Dio_Eq4_Errout
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev0_Pm_IoHwAb_Get_Dio_Eq4_Rev0_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev0_Pm_IoHwAb_Get_Dio_Eq4_Rev0_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev1_Pm_IoHwAb_Get_Dio_Eq4_Rev1_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev1_Pm_IoHwAb_Get_Dio_Eq4_Rev1_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev2_Pm_IoHwAb_Get_Dio_Eq4_Rev2_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev2_Pm_IoHwAb_Get_Dio_Eq4_Rev2_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev3_Pm_IoHwAb_Get_Dio_Eq4_Rev3_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev3_Pm_IoHwAb_Get_Dio_Eq4_Rev3_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev4_Pm_IoHwAb_Get_Dio_Eq4_Rev4_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Rev4_Pm_IoHwAb_Get_Dio_Eq4_Rev4_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Xint_IoHwAb_Get_Dio_Eq4_Xint Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eq4_Xint_IoHwAb_Get_Dio_Eq4_Xint
# define Rte_Call_RP_IoHwAb_Get_Dio_EyeQ_Init_Ready_IoHwAb_Get_Dio_EyeQ_Init_Ready Rte_Call_PTM_RP_IoHwAb_Get_Dio_EyeQ_Init_Ready_IoHwAb_Get_Dio_EyeQ_Init_Ready
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio16_IoHwAb_Get_Dio_Eyeq4_Gpio16 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio16_IoHwAb_Get_Dio_Eyeq4_Gpio16
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio17_IoHwAb_Get_Dio_Eyeq4_Gpio17 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio17_IoHwAb_Get_Dio_Eyeq4_Gpio17
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp
# define Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1
# define Rte_Call_RP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync Rte_Call_PTM_RP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync
# define Rte_Call_RP_IoHwAb_Get_Dio_Heater_Ch0_IoHwAb_Get_Dio_Heater_Ch0 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Heater_Ch0_IoHwAb_Get_Dio_Heater_Ch0
# define Rte_Call_RP_IoHwAb_Get_Dio_Heater_Diag_En_IoHwAb_Get_Dio_Heater_Diag_En Rte_Call_PTM_RP_IoHwAb_Get_Dio_Heater_Diag_En_IoHwAb_Get_Dio_Heater_Diag_En
# define Rte_Call_RP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm Rte_Call_PTM_RP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm
# define Rte_Call_RP_IoHwAb_Get_Dio_Micro_Sfi_Enable_IoHwAb_Get_Dio_Micro_Sfi_Enable Rte_Call_PTM_RP_IoHwAb_Get_Dio_Micro_Sfi_Enable_IoHwAb_Get_Dio_Micro_Sfi_Enable
# define Rte_Call_RP_IoHwAb_Get_Dio_Off_Battery_Enable_IoHwAb_Get_Dio_Off_Battery_Enable Rte_Call_PTM_RP_IoHwAb_Get_Dio_Off_Battery_Enable_IoHwAb_Get_Dio_Off_Battery_Enable
# define Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V1_IoHwAb_Get_Dio_Psu_En_1V1 Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_1V1_IoHwAb_Get_Dio_Psu_En_1V1
# define Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_IoHwAb_Get_Dio_Psu_En_1V8_Ddr Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_IoHwAb_Get_Dio_Psu_En_1V8_Ddr
# define Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_IoHwAb_Get_Dio_Psu_En_Vision_Supplies Rte_Call_PTM_RP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_IoHwAb_Get_Dio_Psu_En_Vision_Supplies
# define Rte_Call_RP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN Rte_Call_PTM_RP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN
# define Rte_Call_RP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN Rte_Call_PTM_RP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN
# define Rte_Call_RP_IoHwAb_Set_Dio_Debug_0_IoHwAb_Set_Dio_Debug_0 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_0_IoHwAb_Set_Dio_Debug_0
# define Rte_Call_RP_IoHwAb_Set_Dio_Debug_1_IoHwAb_Set_Dio_Debug_1 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_1_IoHwAb_Set_Dio_Debug_1
# define Rte_Call_RP_IoHwAb_Set_Dio_Debug_2_IoHwAb_Set_Dio_Debug_2 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_2_IoHwAb_Set_Dio_Debug_2
# define Rte_Call_RP_IoHwAb_Set_Dio_Debug_3_IoHwAb_Set_Dio_Debug_3 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Debug_3_IoHwAb_Set_Dio_Debug_3
# define Rte_Call_RP_IoHwAb_Set_Dio_Diag_Out_Sw_En_IoHwAb_Set_Dio_Diag_Out_Sw_En Rte_Call_PTM_RP_IoHwAb_Set_Dio_Diag_Out_Sw_En_IoHwAb_Set_Dio_Diag_Out_Sw_En
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev0_Pm_IoHwAb_Set_Dio_Eq4_Rev0_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev0_Pm_IoHwAb_Set_Dio_Eq4_Rev0_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev1_Pm_IoHwAb_Set_Dio_Eq4_Rev1_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev1_Pm_IoHwAb_Set_Dio_Eq4_Rev1_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev2_Pm_IoHwAb_Set_Dio_Eq4_Rev2_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev2_Pm_IoHwAb_Set_Dio_Eq4_Rev2_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev3_Pm_IoHwAb_Set_Dio_Eq4_Rev3_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev3_Pm_IoHwAb_Set_Dio_Eq4_Rev3_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev4_Pm_IoHwAb_Set_Dio_Eq4_Rev4_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Rev4_Pm_IoHwAb_Set_Dio_Eq4_Rev4_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Xint_IoHwAb_Set_Dio_Eq4_Xint Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eq4_Xint_IoHwAb_Set_Dio_Eq4_Xint
# define Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode
# define Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode
# define Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode
# define Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp Rte_Call_PTM_RP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp
# define Rte_Call_RP_IoHwAb_Set_Dio_Heater_Ch0_IoHwAb_Set_Dio_Heater_Ch0 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Heater_Ch0_IoHwAb_Set_Dio_Heater_Ch0
# define Rte_Call_RP_IoHwAb_Set_Dio_Heater_Diag_En_IoHwAb_Set_Dio_Heater_Diag_En Rte_Call_PTM_RP_IoHwAb_Set_Dio_Heater_Diag_En_IoHwAb_Set_Dio_Heater_Diag_En
# define Rte_Call_RP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm Rte_Call_PTM_RP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm
# define Rte_Call_RP_IoHwAb_Set_Dio_Micro_Sfi_Enable_IoHwAb_Set_Dio_Micro_Sfi_Enable Rte_Call_PTM_RP_IoHwAb_Set_Dio_Micro_Sfi_Enable_IoHwAb_Set_Dio_Micro_Sfi_Enable
# define Rte_Call_RP_IoHwAb_Set_Dio_Off_Battery_Enable_IoHwAb_Set_Dio_Off_Battery_Enable Rte_Call_PTM_RP_IoHwAb_Set_Dio_Off_Battery_Enable_IoHwAb_Set_Dio_Off_Battery_Enable
# define Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V1_IoHwAb_Set_Dio_Psu_En_1V1 Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_1V1_IoHwAb_Set_Dio_Psu_En_1V1
# define Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr_IoHwAb_Set_Dio_Psu_En_1V8_Ddr Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr_IoHwAb_Set_Dio_Psu_En_1V8_Ddr
# define Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies_IoHwAb_Set_Dio_Psu_En_Vision_Supplies Rte_Call_PTM_RP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies_IoHwAb_Set_Dio_Psu_En_Vision_Supplies
# define Rte_Call_RP_NvMService_DvTest_Mode_ReadBlock Rte_Call_PTM_RP_NvMService_DvTest_Mode_ReadBlock
# define Rte_Call_RP_NvMService_DvTest_Mode_WriteBlock Rte_Call_PTM_RP_NvMService_DvTest_Mode_WriteBlock
# define Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock Rte_Call_PTM_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock
# define Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_WriteBlock Rte_Call_PTM_RP_NvMService_HKMC_TraceabilityInformation_WriteBlock
# define Rte_Call_RP_NvMService_ZFManfrECUSerialNr_ReadBlock Rte_Call_PTM_RP_NvMService_ZFManfrECUSerialNr_ReadBlock
# define Rte_Call_RP_NvMService_ZFManfrECUSerialNr_WriteBlock Rte_Call_PTM_RP_NvMService_ZFManfrECUSerialNr_WriteBlock
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetCurrentSFRTestStatus Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetCurrentSFRTestStatus
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRTestResults Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRTestResults
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_SendSFRAnalysisResults Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_SendSFRAnalysisResults
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StartSFRProcessReq Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StartSFRProcessReq
# define Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StopSFRProcess Rte_Call_PTM_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StopSFRProcess


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_DvTest_Mode() (Rte_Inst_PTM->Pim_DvTest_Mode) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_HKMC_TraceabilityInformation() (Rte_Inst_PTM->Pim_HKMC_TraceabilityInformation) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFECUHwNrDataId() (Rte_Inst_PTM->Pim_ZFECUHwNrDataId) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFECUHwVerNrDataId() (Rte_Inst_PTM->Pim_ZFECUHwVerNrDataId) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFManfrECUSerialNr() (Rte_Inst_PTM->Pim_ZFManfrECUSerialNr) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   DvTest_Mode_t *Rte_Pim_DvTest_Mode(void)
 *   HKMC_TraceabilityInformation_t *Rte_Pim_HKMC_TraceabilityInformation(void)
 *   ZFECUHwNrDataId_t *Rte_Pim_ZFECUHwNrDataId(void)
 *   ZFECUHwVerNrDataId_t *Rte_Pim_ZFECUHwVerNrDataId(void)
 *   ZFManfrECUSerialNr_t *Rte_Pim_ZFManfrECUSerialNr(void)
 *
 *********************************************************************************************************************/


# define PTM_START_SEC_CODE
# include "PTM_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished
FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_GetPtmEepDump_GetEepDump(uint32 nvmAddr_u32, PtmEepDumpRecord_t *ramAddr_u8, uint16 numBytes_u16, uint16 operation)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V0_MON_IoHwAb_Get_ADC_1V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V1_MON_IoHwAb_Get_ADC_1V1_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V8_DDR_MON_IoHwAb_Get_ADC_1V8_DDR_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V8_MON_IoHwAb_Get_ADC_1V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_2V8_MON_IoHwAb_Get_ADC_3V3_2V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_MON_IoHwAb_Get_ADC_3V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_5V0_MON_IoHwAb_Get_ADC_5V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_ADC_REF_CAL_IoHwAb_Get_ADC_ADC_REF_CAL(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_FEYE_TEMP_MON_IoHwAb_Get_ADC_FEYE_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_LKA_SW_INPUT_IoHwAb_Get_ADC_LKA_SW_INPUT(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_NARROW_TEMP_MON_IoHwAb_Get_ADC_NARROW_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_PSU_1V3_MON_IoHwAb_Get_ADC_PSU_1V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_PSU_IMAGER_MON_IoHwAb_Get_ADC_PSU_IMAGER_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_SENSE_HEATER_IoHwAb_Get_ADC_SENSE_HEATER(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_0_IoHwAb_Get_Dio_Debug_0(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_1_IoHwAb_Get_Dio_Debug_1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_2_IoHwAb_Get_Dio_Debug_2(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_3_IoHwAb_Get_Dio_Debug_3(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Diag_Out_Sw_En_IoHwAb_Get_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Errout_IoHwAb_Get_Dio_Eq4_Errout(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev0_Pm_IoHwAb_Get_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev1_Pm_IoHwAb_Get_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev2_Pm_IoHwAb_Get_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev3_Pm_IoHwAb_Get_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev4_Pm_IoHwAb_Get_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Xint_IoHwAb_Get_Dio_Eq4_Xint(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_EyeQ_Init_Ready_IoHwAb_Get_Dio_EyeQ_Init_Ready(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio16_IoHwAb_Get_Dio_Eyeq4_Gpio16(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio17_IoHwAb_Get_Dio_Eyeq4_Gpio17(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Heater_Ch0_IoHwAb_Get_Dio_Heater_Ch0(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Heater_Diag_En_IoHwAb_Get_Dio_Heater_Diag_En(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Micro_Sfi_Enable_IoHwAb_Get_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Off_Battery_Enable_IoHwAb_Get_Dio_Off_Battery_Enable(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V1_IoHwAb_Get_Dio_Psu_En_1V1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_IoHwAb_Get_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_IoHwAb_Get_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_0_IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_1_IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_2_IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_3_IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Diag_Out_Sw_En_IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev0_Pm_IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev1_Pm_IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev2_Pm_IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev3_Pm_IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev4_Pm_IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Xint_IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Heater_Ch0_IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Heater_Diag_En_IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Micro_Sfi_Enable_IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Off_Battery_Enable_IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V1_IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr_IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies_IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_DvTest_Mode_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetCurrentSFRTestStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData(uint8 *sfrBuffer_pau8, uint16 *paramsCount_pu16, boolean *reqStatus_pb, uint8 *SampleStatus_pu8)
 *     Argument sfrBuffer_pau8: uint8* is of type EYEQMESP_SFRBufferType
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRTestResults(sint8 cameraType_s8, boolean *isCameraFocused_pb, uint8 *failFlags_pu8, uint8 *nvmStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_SendSFRAnalysisResults(sint8 cameraType_s8, boolean isCameraFocused_bo, boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StartSFRProcessReq(boolean *status_pb, sint8 cameraType_s8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StopSFRProcess(boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PTM_Run PTM_Run
FUNC(void, PTM_CODE) PTM_Run(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define PTM_STOP_SEC_CODE
# include "PTM_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType (1U)

# define RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# define RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_PTM_H */
