/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Core2_MobisProxy.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  Core2_MobisProxy
 *  Generation Time:  2023-04-20 13:53:20
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <Core2_MobisProxy>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_Core2_MobisProxy.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 *
 *********************************************************************************************************************/


#define Core2_MobisProxy_START_SEC_CODE
#include "Core2_MobisProxy_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CANmsg_Core2_getCanmsg
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getCanmsg> of PortPrototype <PP_CANmsg_Core2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CANmsg_Core2_getCanmsg(CANmsg_t *CANmsg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_CANmsg_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CANmsg_Core2_getCanmsg_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, Core2_MobisProxy_CODE) Re_CANmsg_Core2_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CORE2_MOBISPROXY_APPL_VAR) CANmsg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CANmsg_Core2_getCanmsg (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_Core2MobisProxyInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2VCan_CANmsg(CANmsg_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_EOLInfo_EOLInfo(EOLInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_FeatureConfig_FeatureConfig(FeatureConfig_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_FeatureVehicle_FeatureVehicle(FeatureVehicle_t *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_Core2MobisProxyInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, Core2_MobisProxy_CODE) Re_Core2MobisProxyInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_Core2MobisProxyInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_Core2MobisProxy_5ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2VCan_CANmsg(CANmsg_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_EOLInfo_EOLInfo(EOLInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_FeatureConfig_FeatureConfig(FeatureConfig_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ToCore2_FeatureVehicle_FeatureVehicle(FeatureVehicle_t *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_Core2MobisProxy_5ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, Core2_MobisProxy_CODE) Re_Core2MobisProxy_5ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_Core2MobisProxy_5ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EOLInfo_Core2_getEOLInfo
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getEOLInfo> of PortPrototype <PP_EOLInfo_Core2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_EOLInfo_Core2_getEOLInfo(EOLInfo_t *EOLInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EOLInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EOLInfo_Core2_getEOLInfo_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, Core2_MobisProxy_CODE) Re_EOLInfo_Core2_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CORE2_MOBISPROXY_APPL_VAR) EOLInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EOLInfo_Core2_getEOLInfo (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FeatureConfig_Core2_getFeatureConfig
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureConfig> of PortPrototype <PP_FeatureConfig_Core2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_FeatureConfig_Core2_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FeatureConfig_Core2_getFeatureConfig_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, Core2_MobisProxy_CODE) Re_FeatureConfig_Core2_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CORE2_MOBISPROXY_APPL_VAR) FeatureConfig) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FeatureConfig_Core2_getFeatureConfig (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FeatureVehicle_Core2_getFeatureVehicle
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureVehicle> of PortPrototype <PP_FeatureVehicle_Core2>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_FeatureVehicle_Core2_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FeatureVehicle_Core2_getFeatureVehicle_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, Core2_MobisProxy_CODE) Re_FeatureVehicle_Core2_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CORE2_MOBISPROXY_APPL_VAR) FeatureVehicle) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_FeatureVehicle_Core2_getFeatureVehicle (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define Core2_MobisProxy_STOP_SEC_CODE
#include "Core2_MobisProxy_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
