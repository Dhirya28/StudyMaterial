/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_ProxyCore2.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  ProxyCore2
 *  Generation Time:  2023-04-20 13:53:17
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <ProxyCore2> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_PROXYCORE2_H
# define _RTE_PROXYCORE2_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_ProxyCore2_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_ProxyCore2
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_ProxyCore2, RTE_CONST, RTE_CONST) Rte_Inst_ProxyCore2; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_ProxyCore2, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Switch_ProxyCore2_PP_ProxyCore2Ready_ProxyCore2Ready(uint8 nextMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Switch_ProxyCore2_PP_ProxyCore2Ready_QM_ProxyCore2Ready_QM(uint8 nextMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Switch_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Switch_PP_ProxyCore2Ready_ProxyCore2Ready Rte_Switch_ProxyCore2_PP_ProxyCore2Ready_ProxyCore2Ready
# define Rte_Switch_PP_ProxyCore2Ready_QM_ProxyCore2Ready_QM Rte_Switch_ProxyCore2_PP_ProxyCore2Ready_QM_ProxyCore2Ready_QM


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_NvMNotifyJobFinished_DawFrqNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_DawFrqNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_DawOccNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_DawOccNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_HbaFrqNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_HbaFrqNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_HbaOccNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_HbaOccNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_IslwFrqNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_IslwFrqNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_IslwOccNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_IslwOccNvData_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_LssFrqNvData_JobFinished Rte_Call_ProxyCore2_RP_NvMNotifyJobFinished_LssFrqNvData_JobFinished




# define ProxyCore2_START_SEC_CODE
# include "ProxyCore2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_DawFrqNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_DawFrqNvData_ReadBlock ProxyCore2_NvMService_DawFrqNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_DawFrqNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_DawFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_DawFrqNvData_WriteBlock Os_Call_ProxyCore2_NvMService_DawFrqNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_DawFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_DawOccNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_DawOccNvData_ReadBlock ProxyCore2_NvMService_DawOccNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_DawOccNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_DawOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_DawOccNvData_WriteBlock Os_Call_ProxyCore2_NvMService_DawOccNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_DawOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_HbaFrqNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_HbaFrqNvData_ReadBlock ProxyCore2_NvMService_HbaFrqNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_HbaFrqNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_HbaFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_HbaFrqNvData_WriteBlock Os_Call_ProxyCore2_NvMService_HbaFrqNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_HbaFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_HbaOccNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_HbaOccNvData_ReadBlock ProxyCore2_NvMService_HbaOccNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_HbaOccNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_HbaOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_HbaOccNvData_WriteBlock Os_Call_ProxyCore2_NvMService_HbaOccNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_HbaOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_IslwFrqNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_IslwFrqNvData_ReadBlock ProxyCore2_NvMService_IslwFrqNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_IslwFrqNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_IslwFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_IslwFrqNvData_WriteBlock Os_Call_ProxyCore2_NvMService_IslwFrqNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_IslwFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_IslwOccNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_IslwOccNvData_ReadBlock ProxyCore2_NvMService_IslwOccNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_IslwOccNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_IslwOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_IslwOccNvData_WriteBlock Os_Call_ProxyCore2_NvMService_IslwOccNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_IslwOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_LssFrqNvData_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore2_NvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_LssFrqNvData_ReadBlock ProxyCore2_NvMService_LssFrqNvData_ReadBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) ProxyCore2_NvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_NvMService_LssFrqNvData_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_ProxyCore2_NvMService_LssFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_NvMService_LssFrqNvData_WriteBlock Os_Call_ProxyCore2_NvMService_LssFrqNvData_WriteBlock
FUNC(Std_ReturnType, ProxyCore2_CODE) Os_Call_ProxyCore2_NvMService_LssFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore2_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_ProxyCore2Ready_ProxyCore2Ready(uint8 mode)
 *   Modes of Rte_ModeType_ProxyCore2Ready:
 *   - RTE_MODE_ProxyCore2Ready_False
 *   - RTE_MODE_ProxyCore2Ready_True
 *   - RTE_TRANSITION_ProxyCore2Ready
 *   Std_ReturnType Rte_Switch_PP_ProxyCore2Ready_QM_ProxyCore2Ready_QM(uint8 mode)
 *   Modes of Rte_ModeType_ProxyCore2Ready_QM:
 *   - RTE_MODE_ProxyCore2Ready_QM_FALSE
 *   - RTE_MODE_ProxyCore2Ready_QM_TRUE
 *   - RTE_TRANSITION_ProxyCore2Ready_QM
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore2_Run ProxyCore2_Run
FUNC(void, ProxyCore2_CODE) ProxyCore2_Run(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define ProxyCore2_STOP_SEC_CODE
# include "ProxyCore2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_PROXYCORE2_H */
