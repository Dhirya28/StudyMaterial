/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApEyeQSim.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApEyeQSim
 *  Generation Time:  2023-04-20 13:53:21
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApEyeQSim>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CpApEyeQSim.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * COM_DT_u32_DbgDataIn_01: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_02: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_03: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_04: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_05: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_06: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_07: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_08: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_09: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_10: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_11: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_12: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_13: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_14: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_15: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_16: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_17: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_18: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_19: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_2: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_20: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_21: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_22: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_23: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_24: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_25: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_26: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_27: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_28: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_29: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_3: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_30: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_31: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_32: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_33: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_34: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_35: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_36: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_37: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_38: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_39: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_4: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_40: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_41: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_42: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_43: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_44: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_45: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_46: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_47: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_48: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_49: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_5: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_50: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_51: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_52: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_53: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_54: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_55: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_56: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_57: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_58: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_59: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_6: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_60: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_61: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_62: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_63: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_64: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_65: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_66: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_67: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_68: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_69: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_7: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_70: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_71: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_72: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_73: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_74: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_75: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_76: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_77: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_78: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_79: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_8: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_80: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_81: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_82: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_83: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_84: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_85: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_86: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_87: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_88: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataIn_9: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_01: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_02: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_03: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_04: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_05: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_06: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_07: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_08: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_09: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_10: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_100: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_101: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_102: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_103: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_104: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_105: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_106: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_107: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_108: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_109: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_11: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_110: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_111: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_112: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_113: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_114: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_115: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_116: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_117: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_118: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_119: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_12: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_120: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_121: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_122: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_123: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_124: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_125: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_126: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_127: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_128: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_129: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_13: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_130: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_131: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_132: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_133: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_134: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_135: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_136: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_137: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_138: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_139: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_14: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_140: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_141: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_142: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_143: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_144: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_145: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_146: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_147: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_148: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_149: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_15: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_150: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_151: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_152: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_153: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_154: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_155: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_156: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_157: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_158: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_159: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_16: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_160: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_161: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_162: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_163: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_164: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_165: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_166: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_167: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_168: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_169: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_17: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_170: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_171: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_172: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_173: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_174: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_175: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_176: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_177: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_178: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_179: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_18: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_180: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_181: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_182: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_183: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_184: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_185: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_186: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_187: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_188: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_189: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_19: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_190: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_191: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_192: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_193: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_194: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_195: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_196: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_197: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_198: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_199: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_2: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_20: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_200: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_201: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_202: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_203: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_204: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_205: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_206: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_207: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_208: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_209: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_21: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_210: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_211: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_212: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_213: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_214: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_215: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_216: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_217: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_218: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_219: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_22: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_220: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_221: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_222: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_223: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_224: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_225: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_226: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_227: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_228: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_229: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_23: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_230: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_231: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_232: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_233: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_234: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_235: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_236: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_237: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_238: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_239: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_24: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_240: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_241: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_242: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_243: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_244: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_245: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_246: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_247: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_248: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_249: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_25: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_250: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_251: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_252: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_253: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_254: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_255: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_256: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_257: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_258: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_259: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_26: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_260: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_261: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_262: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_263: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_264: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_265: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_266: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_267: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_268: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_269: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_27: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_270: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_271: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_272: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_273: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_274: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_275: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_276: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_277: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_278: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_279: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_28: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_280: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_281: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_282: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_283: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_284: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_285: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_286: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_287: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_288: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_289: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_29: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_290: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_291: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_292: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_293: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_294: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_295: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_296: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_297: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_298: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_299: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_3: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_30: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_300: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_301: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_302: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_303: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_304: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_305: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_306: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_307: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_308: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_309: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_31: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_310: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_311: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_312: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_313: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_314: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_315: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_316: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_317: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_318: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_319: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_32: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_320: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_321: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_322: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_323: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_324: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_325: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_326: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_327: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_328: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_33: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_34: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_35: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_36: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_37: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_38: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_39: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_4: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_40: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_41: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_42: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_43: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_44: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_45: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_46: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_47: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_48: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_49: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_5: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_50: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_51: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_52: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_53: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_54: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_55: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_56: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_57: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_58: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_59: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_6: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_60: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_61: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_62: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_63: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_64: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_65: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_66: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_67: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_68: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_69: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_7: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_70: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_71: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_72: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_73: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_74: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_75: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_76: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_77: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_78: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_79: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_8: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_80: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_81: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_82: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_83: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_84: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_85: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_86: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_87: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_88: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_89: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_9: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_90: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_91: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_92: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_93: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_94: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_95: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_96: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_97: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_98: Integer in interval [0...4294967295]
 * COM_DT_u32_DbgDataOut_99: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * COM_DT_SG_RxDbgDataIn01_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_41
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_42
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_43
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_44
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_45
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_46
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_47
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_48
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_49
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_50
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_51
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_52
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_53
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_54
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_55
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_56
 * COM_DT_SG_RxDbgDataIn02_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_25
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_26
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_27
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_28
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_29
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_30
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_31
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_32
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_33
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_34
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_35
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_36
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_37
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_38
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_39
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_40
 * COM_DT_SG_RxDbgDataIn03_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_57
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_58
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_59
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_60
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_61
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_62
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_63
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_64
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_65
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_66
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_67
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_68
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_69
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_70
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_71
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_72
 * COM_DT_SG_RxDbgDataIn04_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_73
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_74
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_75
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_76
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_77
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_78
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_79
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_80
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_81
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_82
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_83
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_84
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_85
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_86
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_87
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_88
 * COM_DT_SG_RxDbgDataIn05_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_01
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_02
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_03
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_04
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_05
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_06
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_07
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_08
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_09
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_10
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_11
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_12
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_13
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_14
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_15
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_16
 * COM_DT_SG_RxDbgDataIn06_SignalGroup: Record with elements
 *   u32_DbgDataIn_01 of type COM_DT_u32_DbgDataIn_2
 *   u32_DbgDataIn_02 of type COM_DT_u32_DbgDataIn_3
 *   u32_DbgDataIn_03 of type COM_DT_u32_DbgDataIn_4
 *   u32_DbgDataIn_04 of type COM_DT_u32_DbgDataIn_5
 *   u32_DbgDataIn_05 of type COM_DT_u32_DbgDataIn_6
 *   u32_DbgDataIn_06 of type COM_DT_u32_DbgDataIn_7
 *   u32_DbgDataIn_07 of type COM_DT_u32_DbgDataIn_8
 *   u32_DbgDataIn_08 of type COM_DT_u32_DbgDataIn_9
 *   u32_DbgDataIn_09 of type COM_DT_u32_DbgDataIn_17
 *   u32_DbgDataIn_10 of type COM_DT_u32_DbgDataIn_18
 *   u32_DbgDataIn_11 of type COM_DT_u32_DbgDataIn_19
 *   u32_DbgDataIn_12 of type COM_DT_u32_DbgDataIn_20
 *   u32_DbgDataIn_13 of type COM_DT_u32_DbgDataIn_21
 *   u32_DbgDataIn_14 of type COM_DT_u32_DbgDataIn_22
 *   u32_DbgDataIn_15 of type COM_DT_u32_DbgDataIn_23
 *   u32_DbgDataIn_16 of type COM_DT_u32_DbgDataIn_24
 * COM_DT_SG_TxDbgDataOut_01_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_121
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_122
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_123
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_124
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_125
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_126
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_127
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_128
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_129
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_130
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_131
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_132
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_133
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_134
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_135
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_136
 * COM_DT_SG_TxDbgDataOut_02_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_137
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_138
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_139
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_140
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_141
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_142
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_143
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_144
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_145
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_146
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_147
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_148
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_149
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_150
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_151
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_152
 * COM_DT_SG_TxDbgDataOut_03_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_185
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_186
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_187
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_188
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_189
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_190
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_191
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_192
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_193
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_194
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_195
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_196
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_197
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_198
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_199
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_200
 * COM_DT_SG_TxDbgDataOut_04_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_153
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_154
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_155
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_156
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_157
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_158
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_159
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_160
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_161
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_162
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_163
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_164
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_165
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_166
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_167
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_168
 * COM_DT_SG_TxDbgDataOut_05_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_57
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_58
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_59
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_60
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_61
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_62
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_63
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_64
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_65
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_66
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_67
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_68
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_69
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_70
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_71
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_72
 * COM_DT_SG_TxDbgDataOut_06_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_01
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_02
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_03
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_04
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_05
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_06
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_07
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_08
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_09
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_10
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_11
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_12
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_13
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_14
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_15
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_16
 * COM_DT_SG_TxDbgDataOut_07_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_105
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_106
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_107
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_108
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_109
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_110
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_111
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_112
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_113
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_114
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_115
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_116
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_117
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_118
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_119
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_120
 * COM_DT_SG_TxDbgDataOut_08_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_41
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_42
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_43
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_44
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_45
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_46
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_47
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_48
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_49
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_50
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_51
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_52
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_53
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_54
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_55
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_56
 * COM_DT_SG_TxDbgDataOut_09_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_281
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_282
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_283
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_284
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_285
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_286
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_287
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_288
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_289
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_290
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_291
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_292
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_293
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_294
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_295
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_296
 * COM_DT_SG_TxDbgDataOut_10_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_201
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_202
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_203
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_204
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_205
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_206
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_207
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_208
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_209
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_210
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_211
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_212
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_213
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_214
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_215
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_216
 * COM_DT_SG_TxDbgDataOut_11_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_73
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_74
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_75
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_76
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_77
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_78
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_79
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_80
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_81
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_82
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_83
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_84
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_85
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_86
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_87
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_88
 * COM_DT_SG_TxDbgDataOut_12_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_89
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_90
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_91
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_92
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_93
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_94
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_95
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_96
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_97
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_98
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_99
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_100
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_101
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_102
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_103
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_104
 * COM_DT_SG_TxDbgDataOut_13_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_233
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_234
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_235
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_236
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_237
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_238
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_239
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_240
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_241
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_242
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_243
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_244
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_245
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_246
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_247
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_248
 * COM_DT_SG_TxDbgDataOut_14_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_217
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_218
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_219
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_220
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_221
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_222
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_223
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_224
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_225
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_226
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_227
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_228
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_229
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_230
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_231
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_232
 * COM_DT_SG_TxDbgDataOut_15_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_297
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_298
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_299
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_300
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_301
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_302
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_303
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_304
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_305
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_306
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_307
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_308
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_309
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_310
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_311
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_312
 * COM_DT_SG_TxDbgDataOut_16_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_265
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_266
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_267
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_268
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_269
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_270
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_271
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_272
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_273
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_274
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_275
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_276
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_277
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_278
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_279
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_280
 * COM_DT_SG_TxDbgDataOut_17_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_25
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_26
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_27
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_28
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_29
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_30
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_31
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_32
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_33
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_34
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_35
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_36
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_37
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_38
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_39
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_40
 * COM_DT_SG_TxDbgDataOut_18Signal_Group: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_2
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_3
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_4
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_5
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_6
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_7
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_8
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_9
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_17
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_18
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_19
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_20
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_21
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_22
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_23
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_24
 * COM_DT_SG_TxDbgDataOut_19_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_249
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_250
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_251
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_252
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_253
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_254
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_255
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_256
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_257
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_258
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_259
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_260
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_261
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_262
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_263
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_264
 * COM_DT_SG_TxDbgDataOut_20_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_169
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_170
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_171
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_172
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_173
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_174
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_175
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_176
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_177
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_178
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_179
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_180
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_181
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_182
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_183
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_184
 * COM_DT_SG_TxDbgDataOut_21_SignalGroup: Record with elements
 *   u32_DbgDataOut_01 of type COM_DT_u32_DbgDataOut_313
 *   u32_DbgDataOut_02 of type COM_DT_u32_DbgDataOut_314
 *   u32_DbgDataOut_03 of type COM_DT_u32_DbgDataOut_315
 *   u32_DbgDataOut_04 of type COM_DT_u32_DbgDataOut_316
 *   u32_DbgDataOut_05 of type COM_DT_u32_DbgDataOut_317
 *   u32_DbgDataOut_06 of type COM_DT_u32_DbgDataOut_318
 *   u32_DbgDataOut_07 of type COM_DT_u32_DbgDataOut_319
 *   u32_DbgDataOut_08 of type COM_DT_u32_DbgDataOut_320
 *   u32_DbgDataOut_09 of type COM_DT_u32_DbgDataOut_321
 *   u32_DbgDataOut_10 of type COM_DT_u32_DbgDataOut_322
 *   u32_DbgDataOut_11 of type COM_DT_u32_DbgDataOut_323
 *   u32_DbgDataOut_12 of type COM_DT_u32_DbgDataOut_324
 *   u32_DbgDataOut_13 of type COM_DT_u32_DbgDataOut_325
 *   u32_DbgDataOut_14 of type COM_DT_u32_DbgDataOut_326
 *   u32_DbgDataOut_15 of type COM_DT_u32_DbgDataOut_327
 *   u32_DbgDataOut_16 of type COM_DT_u32_DbgDataOut_328
 * DeLogicDbgInput_t: Record with elements
 *   u32_DbgDataIn_01 of type uint32
 *   u32_DbgDataIn_02 of type uint32
 *   u32_DbgDataIn_03 of type uint32
 *   u32_DbgDataIn_04 of type uint32
 *   u32_DbgDataIn_05 of type uint32
 *   u32_DbgDataIn_06 of type uint32
 *   u32_DbgDataIn_07 of type uint32
 *   u32_DbgDataIn_08 of type uint32
 *   u32_DbgDataIn_09 of type uint32
 *   u32_DbgDataIn_10 of type uint32
 *   u32_DbgDataIn_11 of type uint32
 *   u32_DbgDataIn_12 of type uint32
 *   u32_DbgDataIn_13 of type uint32
 *   u32_DbgDataIn_14 of type uint32
 *   u32_DbgDataIn_15 of type uint32
 *   u32_DbgDataIn_16 of type uint32
 * DeLogicDbgOutput_t: Record with elements
 *   u32_DbgData_01 of type uint32
 *   u32_DbgData_02 of type uint32
 *   u32_DbgData_03 of type uint32
 *   u32_DbgData_04 of type uint32
 *   u32_DbgData_05 of type uint32
 *   u32_DbgData_06 of type uint32
 *   u32_DbgData_07 of type uint32
 *   u32_DbgData_08 of type uint32
 *   u32_DbgData_09 of type uint32
 *   u32_DbgData_10 of type uint32
 *   u32_DbgData_11 of type uint32
 *   u32_DbgData_12 of type uint32
 *   u32_DbgData_13 of type uint32
 *   u32_DbgData_14 of type uint32
 *   u32_DbgData_15 of type uint32
 *   u32_DbgData_16 of type uint32
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 *
 *********************************************************************************************************************/


#define CpApEyeQSim_START_SEC_CODE
#include "CpApEyeQSim_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApEyeQSimInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApEyeQSimInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApEyeQSim_CODE) Re_CpApEyeQSimInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApEyeQSimInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApEyeQSimMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn01_SignalGroup_COM_SG_RxDbgDataIn01_SignalGroup(COM_DT_SG_RxDbgDataIn01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn02_SignalGroup_COM_SG_RxDbgDataIn02_SignalGroup(COM_DT_SG_RxDbgDataIn02_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn03_SignalGroup_COM_SG_RxDbgDataIn03_SignalGroup(COM_DT_SG_RxDbgDataIn03_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn04_SignalGroup_COM_SG_RxDbgDataIn04_SignalGroup(COM_DT_SG_RxDbgDataIn04_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn05_SignalGroup_COM_SG_RxDbgDataIn05_SignalGroup(COM_DT_SG_RxDbgDataIn05_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn06_SignalGroup_COM_SG_RxDbgDataIn06_SignalGroup(COM_DT_SG_RxDbgDataIn06_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput01_De_DawLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput02_De_DawLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput03_De_DawLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput04_De_DawLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput05_De_DawLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput06_De_DawLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput07_De_DawLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput08_De_DawLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput09_De_DawLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput10_De_DawLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput11_De_DawLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput12_De_DawLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput13_De_DawLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput14_De_DawLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput15_De_DawLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput16_De_DawLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput17_De_DawLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput18_De_DawLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput19_De_DawLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput20_De_DawLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput01_De_SccLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput02_De_SccLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput03_De_SccLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput04_De_SccLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput05_De_SccLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput06_De_SccLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput07_De_SccLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput08_De_SccLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput09_De_SccLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput10_De_SccLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput11_De_SccLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput12_De_SccLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput13_De_SccLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput14_De_SccLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput15_De_SccLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput16_De_SccLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput17_De_SccLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput18_De_SccLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput19_De_SccLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput20_De_SccLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_01_SignalGroup_COM_SG_TxDbgDataOut_01_SignalGroup(const COM_DT_SG_TxDbgDataOut_01_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_02_SignalGroup_COM_SG_TxDbgDataOut_02_SignalGroup(const COM_DT_SG_TxDbgDataOut_02_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_03_SignalGroup_COM_SG_TxDbgDataOut_03_SignalGroup(const COM_DT_SG_TxDbgDataOut_03_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_04_SignalGroup_COM_SG_TxDbgDataOut_04_SignalGroup(const COM_DT_SG_TxDbgDataOut_04_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_05_SignalGroup_COM_SG_TxDbgDataOut_05_SignalGroup(const COM_DT_SG_TxDbgDataOut_05_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_06_SignalGroup_COM_SG_TxDbgDataOut_06_SignalGroup(const COM_DT_SG_TxDbgDataOut_06_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_07_SignalGroup_COM_SG_TxDbgDataOut_07_SignalGroup(const COM_DT_SG_TxDbgDataOut_07_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_08_SignalGroup_COM_SG_TxDbgDataOut_08_SignalGroup(const COM_DT_SG_TxDbgDataOut_08_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_09_SignalGroup_COM_SG_TxDbgDataOut_09_SignalGroup(const COM_DT_SG_TxDbgDataOut_09_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_10_SignalGroup_COM_SG_TxDbgDataOut_10_SignalGroup(const COM_DT_SG_TxDbgDataOut_10_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_11_SignalGroup_COM_SG_TxDbgDataOut_11_SignalGroup(const COM_DT_SG_TxDbgDataOut_11_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_12_SignalGroup_COM_SG_TxDbgDataOut_12_SignalGroup(const COM_DT_SG_TxDbgDataOut_12_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_13_SignalGroup_COM_SG_TxDbgDataOut_13_SignalGroup(const COM_DT_SG_TxDbgDataOut_13_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_14_SignalGroup_COM_SG_TxDbgDataOut_14_SignalGroup(const COM_DT_SG_TxDbgDataOut_14_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_15_SignalGroup_COM_SG_TxDbgDataOut_15_SignalGroup(const COM_DT_SG_TxDbgDataOut_15_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_16_SignalGroup_COM_SG_TxDbgDataOut_16_SignalGroup(const COM_DT_SG_TxDbgDataOut_16_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_17_SignalGroup_COM_SG_TxDbgDataOut_17_SignalGroup(const COM_DT_SG_TxDbgDataOut_17_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_18Signal_Group_COM_SG_TxDbgDataOut_18Signal_Group(const COM_DT_SG_TxDbgDataOut_18Signal_Group *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_19_SignalGroup_COM_SG_TxDbgDataOut_19_SignalGroup(const COM_DT_SG_TxDbgDataOut_19_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_20_SignalGroup_COM_SG_TxDbgDataOut_20_SignalGroup(const COM_DT_SG_TxDbgDataOut_20_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_21_SignalGroup_COM_SG_TxDbgDataOut_21_SignalGroup(const COM_DT_SG_TxDbgDataOut_21_SignalGroup *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn01_De_CoFcaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn02_De_CoFcaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn03_De_CoFcaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn04_De_CoFcaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn05_De_CoFcaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn06_De_CoFcaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn01_De_DawDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn02_De_DawDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn03_De_DawDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn04_De_DawDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn05_De_DawDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn06_De_DawDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn01_De_FcaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn02_De_FcaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn03_De_FcaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn04_De_FcaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn05_De_FcaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn06_De_FcaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn01_De_HbaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn02_De_HbaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn03_De_HbaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn04_De_HbaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn05_De_HbaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn06_De_HbaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn01_De_IslwDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn02_De_IslwDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn03_De_IslwDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn04_De_IslwDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn05_De_IslwDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn06_De_IslwDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn01_De_IvcDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn02_De_IvcDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn03_De_IvcDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn04_De_IvcDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn05_De_IvcDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn06_De_IvcDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn01_De_LssDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn02_De_LssDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn03_De_LssDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn04_De_LssDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn05_De_LssDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn06_De_LssDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn01_De_SccDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn02_De_SccDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn03_De_SccDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn04_De_SccDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn05_De_SccDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn06_De_SccDbgIn06(const DeLogicDbgInput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApEyeQSimMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApEyeQSim_CODE) Re_CpApEyeQSimMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApEyeQSimMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApEyeQSim_STOP_SEC_CODE
#include "CpApEyeQSim_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
