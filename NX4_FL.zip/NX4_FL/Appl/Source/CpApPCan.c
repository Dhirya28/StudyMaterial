/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApPCan.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPCan
 *  Generation Time:  2023-04-20 13:53:24
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApPCan>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CpApPCan.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * ADAS101_AlvCntVal_t_1: Integer in interval [0...255]
 * ADAS101_CrcVal_t_1: Integer in interval [0...65535]
 * BatteryVoltageHigh: Integer in interval [0...255]
 * BatteryVoltageLow: Integer in interval [0...255]
 * Blockage_Drv: Integer in interval [0...255]
 * Blockage_Init: Integer in interval [0...255]
 * CALR_t_1: Integer in interval [0...65535]
 * COM_DT_ADAS101_AlvCntVal_1: Integer in interval [0...255]
 * COM_DT_ADAS101_CrcVal_1: Integer in interval [0...65535]
 * COM_DT_BatteryVoltageHigh: Integer in interval [0...255]
 * COM_DT_BatteryVoltageLow: Integer in interval [0...255]
 * COM_DT_Blockage_Drv: Integer in interval [0...255]
 * COM_DT_Blockage_Init: Integer in interval [0...255]
 * COM_DT_CALR_1: Integer in interval [0...65535]
 * COM_DT_FR_RDR_CrcVal: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_AlvCnt01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AlvCnt16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AmbigSpeed01: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed02: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed03: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed04: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed05: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed06: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed07: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed08: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed09: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed10: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed11: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed12: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed13: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed14: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed15: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed16: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed17: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed18: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed19: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed20: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed21: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed22: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed23: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed24: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed25: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed26: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed27: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed28: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed29: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed30: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed31: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed32: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed33: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed34: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed35: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed36: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed37: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed38: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed39: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed40: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed41: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed42: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed43: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed44: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed45: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed46: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed47: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed48: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed49: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed50: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed51: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed52: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed53: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed54: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed55: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed56: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed57: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed58: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed59: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed60: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed61: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed62: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed63: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AmbigSpeed64: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_AssignTag01: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag02: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag03: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag04: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag05: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag06: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag07: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag08: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag09: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag10: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag11: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag12: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag13: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag14: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag15: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag16: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag17: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag18: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag19: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag20: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag21: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag22: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag23: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag24: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag25: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag26: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag27: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag28: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag29: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag30: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag31: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag32: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag33: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag34: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag35: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag36: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag37: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag38: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag39: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag40: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag41: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag42: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag43: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag44: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag45: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag46: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag47: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag48: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag49: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag50: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag51: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag52: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag53: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag54: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag55: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag56: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag57: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag58: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag59: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag60: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag61: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag62: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag63: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_AssignTag64: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute01: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute02: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute03: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute04: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute05: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute06: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute07: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute08: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute09: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute10: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute11: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute12: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute13: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute14: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute15: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute16: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute17: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute18: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute19: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute20: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute21: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute22: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute23: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute24: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute25: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute26: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute27: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute28: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute29: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute30: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute31: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute32: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute33: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute34: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute35: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute36: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute37: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute38: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute39: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute40: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute41: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute42: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute43: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute44: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute45: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute46: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute47: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute48: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute49: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute50: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute51: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute52: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute53: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute54: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute55: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute56: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute57: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute58: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute59: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute60: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute61: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute62: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute63: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Attribute64: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_CRC01Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC02Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC03Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC04Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC05Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC06Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC07Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC08Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC09Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC10Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC11Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC12Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC13Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC14Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC15Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_CRC16Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_ClusterID01: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID02: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID03: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID04: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID05: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID06: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID07: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID08: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID09: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID10: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID11: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID12: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID13: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID14: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID15: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID16: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID17: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID18: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID19: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID20: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID21: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID22: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID23: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID24: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID25: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID26: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID27: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID28: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID29: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID30: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID31: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID32: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID33: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID34: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID35: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID36: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID37: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID38: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID39: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID40: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID41: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID42: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID43: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID44: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID45: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID46: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID47: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID48: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID49: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID50: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID51: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID52: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID53: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID54: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID55: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID56: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID57: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID58: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID59: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID60: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID61: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID62: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID63: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_ClusterID64: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Height01: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height02: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height03: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height04: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height05: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height06: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height07: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height08: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height09: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height10: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height11: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height12: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height13: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height14: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height15: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height16: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height17: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height18: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height19: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height20: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height21: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height22: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height23: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height24: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height25: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height26: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height27: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height28: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height29: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height30: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height31: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height32: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height33: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height34: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height35: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height36: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height37: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height38: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height39: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height40: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height41: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height42: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height43: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height44: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height45: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height46: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height47: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height48: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height49: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height50: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height51: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height52: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height53: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height54: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height55: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height56: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height57: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height58: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height59: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height60: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height61: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height62: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height63: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Height64: Integer in interval [-128...127]
 * COM_DT_FR_RDR_Det_Lat01: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat02: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat03: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat04: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat05: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat06: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat07: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat08: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat09: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat10: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat11: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat12: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat13: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat14: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat15: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat16: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat17: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat18: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat19: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat20: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat21: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat22: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat23: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat24: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat25: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat26: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat27: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat28: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat29: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat30: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat31: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat32: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat33: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat34: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat35: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat36: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat37: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat38: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat39: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat40: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat41: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat42: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat43: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat44: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat45: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat46: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat47: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat48: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat49: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat50: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat51: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat52: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat53: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat54: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat55: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat56: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat57: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat58: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat59: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat60: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat61: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat62: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat63: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Lat64: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Long01: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long02: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long03: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long04: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long05: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long06: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long07: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long08: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long09: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long10: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long11: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long12: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long13: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long14: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long15: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long16: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long17: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long18: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long19: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long20: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long21: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long22: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long23: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long24: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long25: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long26: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long27: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long28: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long29: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long30: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long31: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long32: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long33: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long34: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long35: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long36: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long37: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long38: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long39: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long40: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long41: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long42: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long43: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long44: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long45: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long46: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long47: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long48: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long49: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long50: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long51: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long52: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long53: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long54: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long55: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long56: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long57: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long58: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long59: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long60: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long61: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long62: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long63: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Long64: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Mov01: Boolean
 * COM_DT_FR_RDR_Det_Mov02: Boolean
 * COM_DT_FR_RDR_Det_Mov03: Boolean
 * COM_DT_FR_RDR_Det_Mov04: Boolean
 * COM_DT_FR_RDR_Det_Mov05: Boolean
 * COM_DT_FR_RDR_Det_Mov06: Boolean
 * COM_DT_FR_RDR_Det_Mov07: Boolean
 * COM_DT_FR_RDR_Det_Mov08: Boolean
 * COM_DT_FR_RDR_Det_Mov09: Boolean
 * COM_DT_FR_RDR_Det_Mov10: Boolean
 * COM_DT_FR_RDR_Det_Mov11: Boolean
 * COM_DT_FR_RDR_Det_Mov12: Boolean
 * COM_DT_FR_RDR_Det_Mov13: Boolean
 * COM_DT_FR_RDR_Det_Mov14: Boolean
 * COM_DT_FR_RDR_Det_Mov15: Boolean
 * COM_DT_FR_RDR_Det_Mov16: Boolean
 * COM_DT_FR_RDR_Det_Mov17: Boolean
 * COM_DT_FR_RDR_Det_Mov18: Boolean
 * COM_DT_FR_RDR_Det_Mov19: Boolean
 * COM_DT_FR_RDR_Det_Mov20: Boolean
 * COM_DT_FR_RDR_Det_Mov21: Boolean
 * COM_DT_FR_RDR_Det_Mov22: Boolean
 * COM_DT_FR_RDR_Det_Mov23: Boolean
 * COM_DT_FR_RDR_Det_Mov24: Boolean
 * COM_DT_FR_RDR_Det_Mov25: Boolean
 * COM_DT_FR_RDR_Det_Mov26: Boolean
 * COM_DT_FR_RDR_Det_Mov27: Boolean
 * COM_DT_FR_RDR_Det_Mov28: Boolean
 * COM_DT_FR_RDR_Det_Mov29: Boolean
 * COM_DT_FR_RDR_Det_Mov30: Boolean
 * COM_DT_FR_RDR_Det_Mov31: Boolean
 * COM_DT_FR_RDR_Det_Mov32: Boolean
 * COM_DT_FR_RDR_Det_Mov33: Boolean
 * COM_DT_FR_RDR_Det_Mov34: Boolean
 * COM_DT_FR_RDR_Det_Mov35: Boolean
 * COM_DT_FR_RDR_Det_Mov36: Boolean
 * COM_DT_FR_RDR_Det_Mov37: Boolean
 * COM_DT_FR_RDR_Det_Mov38: Boolean
 * COM_DT_FR_RDR_Det_Mov39: Boolean
 * COM_DT_FR_RDR_Det_Mov40: Boolean
 * COM_DT_FR_RDR_Det_Mov41: Boolean
 * COM_DT_FR_RDR_Det_Mov42: Boolean
 * COM_DT_FR_RDR_Det_Mov43: Boolean
 * COM_DT_FR_RDR_Det_Mov44: Boolean
 * COM_DT_FR_RDR_Det_Mov45: Boolean
 * COM_DT_FR_RDR_Det_Mov46: Boolean
 * COM_DT_FR_RDR_Det_Mov47: Boolean
 * COM_DT_FR_RDR_Det_Mov48: Boolean
 * COM_DT_FR_RDR_Det_Mov49: Boolean
 * COM_DT_FR_RDR_Det_Mov50: Boolean
 * COM_DT_FR_RDR_Det_Mov51: Boolean
 * COM_DT_FR_RDR_Det_Mov52: Boolean
 * COM_DT_FR_RDR_Det_Mov53: Boolean
 * COM_DT_FR_RDR_Det_Mov54: Boolean
 * COM_DT_FR_RDR_Det_Mov55: Boolean
 * COM_DT_FR_RDR_Det_Mov56: Boolean
 * COM_DT_FR_RDR_Det_Mov57: Boolean
 * COM_DT_FR_RDR_Det_Mov58: Boolean
 * COM_DT_FR_RDR_Det_Mov59: Boolean
 * COM_DT_FR_RDR_Det_Mov60: Boolean
 * COM_DT_FR_RDR_Det_Mov61: Boolean
 * COM_DT_FR_RDR_Det_Mov62: Boolean
 * COM_DT_FR_RDR_Det_Mov63: Boolean
 * COM_DT_FR_RDR_Det_Mov64: Boolean
 * COM_DT_FR_RDR_Det_SNR01: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR02: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR03: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR04: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR05: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR06: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR07: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR08: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR09: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR10: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR11: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR12: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR13: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR14: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR15: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR16: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR17: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR18: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR19: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR20: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR21: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR22: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR23: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR24: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR25: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR26: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR27: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR28: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR29: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR30: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR31: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR32: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR33: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR34: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR35: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR36: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR37: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR38: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR39: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR40: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR41: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR42: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR43: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR44: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR45: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR46: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR47: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR48: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR49: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR50: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR51: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR52: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR53: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR54: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR55: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR56: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR57: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR58: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR59: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR60: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR61: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR62: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR63: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_SNR64: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Det_Speed01: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed02: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed03: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed04: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed05: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed06: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed07: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed08: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed09: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed10: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed11: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed12: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed13: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed14: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed15: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed16: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed17: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed18: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed19: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed20: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed21: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed22: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed23: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed24: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed25: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed26: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed27: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed28: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed29: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed30: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed31: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed32: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed33: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed34: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed35: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed36: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed37: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed38: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed39: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed40: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed41: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed42: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed43: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed44: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed45: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed46: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed47: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed48: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed49: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed50: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed51: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed52: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed53: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed54: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed55: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed56: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed57: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed58: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed59: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed60: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed61: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed62: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed63: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_Speed64: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Det_TrustA01: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA02: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA03: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA04: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA05: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA06: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA07: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA08: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA09: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA10: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA11: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA12: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA13: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA14: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA15: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA16: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA17: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA18: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA19: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA20: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA21: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA22: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA23: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA24: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA25: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA26: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA27: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA28: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA29: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA30: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA31: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA32: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA33: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA34: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA35: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA36: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA37: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA38: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA39: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA40: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA41: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA42: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA43: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA44: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA45: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA46: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA47: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA48: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA49: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA50: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA51: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA52: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA53: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA54: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA55: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA56: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA57: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA58: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA59: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA60: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA61: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA62: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA63: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustA64: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV01: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV02: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV03: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV04: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV05: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV06: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV07: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV08: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV09: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV10: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV11: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV12: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV13: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV14: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV15: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV16: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV17: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV18: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV19: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV20: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV21: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV22: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV23: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV24: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV25: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV26: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV27: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV28: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV29: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV30: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV31: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV32: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV33: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV34: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV35: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV36: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV37: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV38: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV39: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV40: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV41: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV42: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV43: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV44: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV45: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV46: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV47: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV48: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV49: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV50: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV51: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV52: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV53: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV54: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV55: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV56: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV57: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV58: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV59: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV60: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV61: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV62: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV63: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_TrustV64: Integer in interval [0...255]
 * COM_DT_FR_RDR_Det_Valid01: Boolean
 * COM_DT_FR_RDR_Det_Valid02: Boolean
 * COM_DT_FR_RDR_Det_Valid03: Boolean
 * COM_DT_FR_RDR_Det_Valid04: Boolean
 * COM_DT_FR_RDR_Det_Valid05: Boolean
 * COM_DT_FR_RDR_Det_Valid06: Boolean
 * COM_DT_FR_RDR_Det_Valid07: Boolean
 * COM_DT_FR_RDR_Det_Valid08: Boolean
 * COM_DT_FR_RDR_Det_Valid09: Boolean
 * COM_DT_FR_RDR_Det_Valid10: Boolean
 * COM_DT_FR_RDR_Det_Valid11: Boolean
 * COM_DT_FR_RDR_Det_Valid12: Boolean
 * COM_DT_FR_RDR_Det_Valid13: Boolean
 * COM_DT_FR_RDR_Det_Valid14: Boolean
 * COM_DT_FR_RDR_Det_Valid15: Boolean
 * COM_DT_FR_RDR_Det_Valid16: Boolean
 * COM_DT_FR_RDR_Det_Valid17: Boolean
 * COM_DT_FR_RDR_Det_Valid18: Boolean
 * COM_DT_FR_RDR_Det_Valid19: Boolean
 * COM_DT_FR_RDR_Det_Valid20: Boolean
 * COM_DT_FR_RDR_Det_Valid21: Boolean
 * COM_DT_FR_RDR_Det_Valid22: Boolean
 * COM_DT_FR_RDR_Det_Valid23: Boolean
 * COM_DT_FR_RDR_Det_Valid24: Boolean
 * COM_DT_FR_RDR_Det_Valid25: Boolean
 * COM_DT_FR_RDR_Det_Valid26: Boolean
 * COM_DT_FR_RDR_Det_Valid27: Boolean
 * COM_DT_FR_RDR_Det_Valid28: Boolean
 * COM_DT_FR_RDR_Det_Valid29: Boolean
 * COM_DT_FR_RDR_Det_Valid30: Boolean
 * COM_DT_FR_RDR_Det_Valid31: Boolean
 * COM_DT_FR_RDR_Det_Valid32: Boolean
 * COM_DT_FR_RDR_Det_Valid33: Boolean
 * COM_DT_FR_RDR_Det_Valid34: Boolean
 * COM_DT_FR_RDR_Det_Valid35: Boolean
 * COM_DT_FR_RDR_Det_Valid36: Boolean
 * COM_DT_FR_RDR_Det_Valid37: Boolean
 * COM_DT_FR_RDR_Det_Valid38: Boolean
 * COM_DT_FR_RDR_Det_Valid39: Boolean
 * COM_DT_FR_RDR_Det_Valid40: Boolean
 * COM_DT_FR_RDR_Det_Valid41: Boolean
 * COM_DT_FR_RDR_Det_Valid42: Boolean
 * COM_DT_FR_RDR_Det_Valid43: Boolean
 * COM_DT_FR_RDR_Det_Valid44: Boolean
 * COM_DT_FR_RDR_Det_Valid45: Boolean
 * COM_DT_FR_RDR_Det_Valid46: Boolean
 * COM_DT_FR_RDR_Det_Valid47: Boolean
 * COM_DT_FR_RDR_Det_Valid48: Boolean
 * COM_DT_FR_RDR_Det_Valid49: Boolean
 * COM_DT_FR_RDR_Det_Valid50: Boolean
 * COM_DT_FR_RDR_Det_Valid51: Boolean
 * COM_DT_FR_RDR_Det_Valid52: Boolean
 * COM_DT_FR_RDR_Det_Valid53: Boolean
 * COM_DT_FR_RDR_Det_Valid54: Boolean
 * COM_DT_FR_RDR_Det_Valid55: Boolean
 * COM_DT_FR_RDR_Det_Valid56: Boolean
 * COM_DT_FR_RDR_Det_Valid57: Boolean
 * COM_DT_FR_RDR_Det_Valid58: Boolean
 * COM_DT_FR_RDR_Det_Valid59: Boolean
 * COM_DT_FR_RDR_Det_Valid60: Boolean
 * COM_DT_FR_RDR_Det_Valid61: Boolean
 * COM_DT_FR_RDR_Det_Valid62: Boolean
 * COM_DT_FR_RDR_Det_Valid63: Boolean
 * COM_DT_FR_RDR_Det_Valid64: Boolean
 * COM_DT_FR_RDR_Obj_AlvAge01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge17Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge18Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge19Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge20Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge21Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge22Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge23Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge24Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge25Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge26Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge27Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge28Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge29Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge30Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge31Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvAge32Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_AlvCnt16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CRC01Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC02Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC03Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC04Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC05Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC06Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC07Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC08Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC09Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC10Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC11Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC12Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC13Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC14Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC15Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CRC16Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_CoastAge01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge17Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge18Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge19Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge20Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge21Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge22Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge23Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge24Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge25Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge26Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge27Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge28Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge29Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge30Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge31Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_CoastAge32Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod17Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod18Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod19Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod20Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod21Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod22Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod23Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod24Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod25Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod26Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod27Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod28Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod29Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod30Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod31Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_MedRangeMod32Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl01Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl02Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl03Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl04Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl05Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl06Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl07Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl08Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl09Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl10Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl11Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl12Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl13Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl14Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl15Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl16Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl17Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl18Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl19Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl20Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl21Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl22Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl23Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl24Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl25Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl26Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl27Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl28Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl29Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl30Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl31Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_QualLvl32Sta: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID01Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID02Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID03Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID04Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID05Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID06Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID07Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID08Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID09Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID10Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID11Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID12Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID13Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID14Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID15Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID16Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID17Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID18Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID19Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID20Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID21Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID22Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID23Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID24Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID25Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID26Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID27Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID28Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID29Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID30Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID31Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RefObjID32Val: Integer in interval [0...255]
 * COM_DT_FR_RDR_Obj_RelAccelX01Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX02Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX03Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX04Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX05Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX06Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX07Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX08Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX09Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX10Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX11Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX12Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX13Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX14Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX15Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX16Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX17Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX18Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX19Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX20Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX21Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX22Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX23Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX24Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX25Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX26Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX27Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX28Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX29Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX30Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX31Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelAccelX32Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosX01Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX02Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX03Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX04Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX05Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX06Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX07Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX08Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX09Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX10Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX11Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX12Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX13Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX14Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX15Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX16Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX17Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX18Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX19Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX20Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX21Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX22Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX23Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX24Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX25Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX26Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX27Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX28Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX29Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX30Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX31Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosX32Val: Integer in interval [0...65535]
 * COM_DT_FR_RDR_Obj_RelPosY01Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY02Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY03Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY04Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY05Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY06Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY07Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY08Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY09Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY10Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY11Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY12Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY13Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY14Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY15Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY16Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY17Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY18Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY19Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY20Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY21Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY22Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY23Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY24Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY25Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY26Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY27Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY28Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY29Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY30Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY31Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelPosY32Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX01Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX02Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX03Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX04Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX05Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX06Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX07Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX08Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX09Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX10Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX11Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX12Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX13Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX14Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX15Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX16Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX17Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX18Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX19Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX20Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX21Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX22Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX23Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX24Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX25Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX26Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX27Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX28Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX29Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX30Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX31Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelX32Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY01Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY02Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY03Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY04Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY05Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY06Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY07Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY08Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY09Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY10Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY11Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY12Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY13Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY14Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY15Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY16Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY17Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY18Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY19Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY20Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY21Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY22Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY23Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY24Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY25Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY26Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY27Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY28Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY29Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY30Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY31Val: Integer in interval [-32768...32767]
 * COM_DT_FR_RDR_Obj_RelVelY32Val: Integer in interval [-32768...32767]
 * COM_DT_RD_DTC_AlvCntVal: Integer in interval [0...255]
 * COM_DT_RadarCANCommError: Integer in interval [0...255]
 * COM_DT_RadarErrorCode_No1: Integer in interval [0...65535]
 * COM_DT_RadarErrorCode_No2: Integer in interval [0...65535]
 * COM_DT_RadarHwError: Integer in interval [0...255]
 * COM_DT_RadarHwTempCondition_High: Integer in interval [0...255]
 * COM_DT_RadarHwTempCondition_Low: Integer in interval [0...255]
 * COM_DT_SystemOutOfCalibration_DRV: Integer in interval [0...255]
 * COM_DT_SystemOutOfCalibration_EOL: Integer in interval [0...255]
 * COM_DT_VN_1: Integer in interval [0...65535]
 * COM_DT_p_ABS_DiagSta: Integer in interval [0...255]
 * COM_DT_p_CLU_OutTempCSta_1: Integer in interval [0...255]
 * COM_DT_p_HCU_HevRdySta: Integer in interval [0...255]
 * COM_DT_p_SAS_AnglVal_1: Integer in interval [-32768...32767]
 * COM_DT_p_WHL_SpdFLVal_1: Integer in interval [0...65535]
 * COM_DT_p_WHL_SpdFRVal_1: Integer in interval [0...65535]
 * COM_DT_p_WHL_SpdRLVal_1: Integer in interval [0...65535]
 * COM_DT_p_WHL_SpdRRVal_1: Integer in interval [0...65535]
 * COM_DT_p_YRS_YawRtVal_1: Integer in interval [0...65535]
 * CpApDiag_Status: Integer in interval [0...65535]
 * FR_RDR_HW_Reset: Integer in interval [0...255]
 * FR_RDR_SW_Reset: Integer in interval [0...255]
 * RD_DTC_AlvCntVal: Integer in interval [0...255]
 * RD_DTC_CRCVal: Integer in interval [0...65535]
 * RadarCANCommError: Integer in interval [0...255]
 * RadarErrorCode_No1: Integer in interval [0...65535]
 * RadarErrorCode_No2: Integer in interval [0...65535]
 * RadarHwError: Integer in interval [0...255]
 * RadarHwTempCondition_High: Integer in interval [0...255]
 * RadarHwTempCondition_Low: Integer in interval [0...255]
 * SystemOutOfCalibration_DRV: Integer in interval [0...255]
 * SystemOutOfCalibration_EOL: Integer in interval [0...255]
 * VN_t_2: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * p_CF_Gway_InhibitRMT_t_1: Integer in interval [0...255]
 * p_CR_Fatc_OutTemp_t_1: Integer in interval [0...255]
 * p_SAS_Angle_t: Integer in interval [-32768...32767]
 * p_WHL_SpdFL_t_1: Integer in interval [0...65535]
 * p_WHL_SpdFR_t_1: Integer in interval [0...65535]
 * p_WHL_SpdRL_t_1: Integer in interval [0...65535]
 * p_WHL_SpdRR_t_1: Integer in interval [0...65535]
 * p_Yaw_rate_t_1: Integer in interval [0...65535]
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * COM_DT_FR_RDR_Obj_MvngFlag01Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag02Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag03Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag04Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag05Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag06Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag07Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag08Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag09Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag10Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag11Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag12Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag13Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag14Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag15Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag16Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag17Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag18Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag19Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag20Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag21Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag22Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag23Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag24Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag25Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag26Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag27Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag28Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag29Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag30Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag31Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_MvngFlag32Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Not_defined (0U)
 *   Cx1_Stationary (1U)
 *   Cx2_Moving (2U)
 *   Cx3_Stopped (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta01Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta02Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta03Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta04Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta05Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta06Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta07Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta08Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta09Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta10Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta11Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta12Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta13Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta14Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta15Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta16Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta17Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta18Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta19Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta20Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta21Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta22Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta23Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta24Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta25Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta26Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta27Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta28Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta29Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta30Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta31Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_FR_RDR_Obj_TrkSta32Sta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Undecided (0U)
 *   Cx1_New_Target (1U)
 *   Cx2_Updated_Target (2U)
 *   Cx3_Memory_Tartget (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Not_used (6U)
 *   Cx7_Error_Indicator (7U)
 * COM_DT_p_CF_ECU_SSC_STAT: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 * COM_DT_p_ENG_EngSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Fault (7U)
 * COM_DT_p_ENG_IsgSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Fault (7U)
 * COM_DT_p_ICU_MtGearPosRSta: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Off (0U)
 *   Cx1_On (1U)
 * COM_DT_p_TCU_GearSlctDis: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_P (0U)
 *   Cx1_L (1U)
 *   Cx2_2 (2U)
 *   Cx3_3 (3U)
 *   Cx4_DS_Mode (4U)
 *   Cx5_D (5U)
 *   Cx6_N (6U)
 *   Cx7_R (7U)
 *   Cx8_sportsmode_manual_paddleshift (8U)
 *   Cx9_Not_Display_at_Cluster (9U)
 *   CxA_Sub_Rom_Communication (10U)
 *   CxB_Sub_Rom_Communication_Error (11U)
 *   CxC_Paddle_shift_D_position_ (12U)
 *   CxD_Reserved (13U)
 *   CxE_Intermediate_Position (14U)
 *   CxF_fault (15U)
 * COM_DT_u8_VehicleType: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_No_Coding (0U)
 *   Cx1_Internal_combustion_engine (1U)
 *   Cx2_HEV (2U)
 *   Cx3_PHEV (3U)
 *   Cx4_EV (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Reserved (7U)
 * p_CF_ECU_SSC_STAT_t: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 * p_CF_Ems_IsgStat_t: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Fault (7U)
 * p_ENG_Stat_t: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_Engine_Stop (0U)
 *   Cx1_Cranking (1U)
 *   Cx2_Stalled (2U)
 *   Cx3_Running (3U)
 *   Cx4_Reserved (4U)
 *   Cx5_Reserved (5U)
 *   Cx6_Reserved (6U)
 *   Cx7_Fault (7U)
 * p_G_Sel_Disp_t: Enumeration of integer in interval [0...255] with enumerators
 *   Cx0_P (0U)
 *   Cx1_L (1U)
 *   Cx2_2 (2U)
 *   Cx3_3 (3U)
 *   Cx4_DS_Mode (4U)
 *   Cx5_D (5U)
 *   Cx6_N (6U)
 *   Cx7_R (7U)
 *   Cx8_sports_mode_manual_shift_paddle_shift (8U)
 *   Cx9_Not_Display_at_Cluster (9U)
 *   CxA_Sub_Rom_Communication (10U)
 *   CxB_Sub_Rom_Communication_Error (11U)
 *   CxC_Paddle_shift_D_position_ (12U)
 *   CxD_Reserved (13U)
 *   CxE_Intermediate_Position (14U)
 *   CxF_fault (15U)
 *
 * Record Types:
 * =============
 * ADAS101_t: Record with elements
 *   CALR of type uint16
 *   VN of type uint16
 *   p_YRS_YawRtVal of type uint16
 *   p_OutTempCSta of type uint8
 *   p_WHL_SpdFLVal of type uint16
 *   p_WHL_SpdFRVal of type uint16
 *   p_WHL_SpdRLVal of type uint16
 *   p_WHL_SpdRRVal of type uint16
 *   p_SAS_AnglVal of type sint16
 *   p_TCU_GearSlctDis of type uint8
 *   p_ICU_MtGearPosRSta of type uint8
 *   p_ENG_EngSta of type uint8
 *   p_ENG_IsgSta of type uint8
 *   p_CF_ECU_SSC_STAT of type uint8
 *   p_HCU_HevRdySta of type uint8
 *   p_ABS_DiagSta of type uint8
 * COM_DT_SG_ADAS101_2Gen_SignalGroup: Record with elements
 *   ADAS101_AlvCntVal of type ADAS101_AlvCntVal_t_1
 *   ADAS101_CrcVal of type ADAS101_CrcVal_t_1
 *   CALR of type CALR_t_1
 *   p_CF_ECU_SSC_STAT of type p_CF_ECU_SSC_STAT_t
 *   p_CF_Ems_IsgStat of type p_CF_Ems_IsgStat_t
 *   p_CF_Gway_InhibitRMT of type p_CF_Gway_InhibitRMT_t_1
 *   p_CR_Fatc_OutTemp of type p_CR_Fatc_OutTemp_t_1
 *   p_Eng_Stat of type p_ENG_Stat_t
 *   p_G_Sel_Disp of type p_G_Sel_Disp_t
 *   p_SAS_Angle of type p_SAS_Angle_t
 *   p_WHL_SpdFL of type p_WHL_SpdFL_t_1
 *   p_WHL_SpdFR of type p_WHL_SpdFR_t_1
 *   p_WHL_SpdRL of type p_WHL_SpdRL_t_1
 *   p_WHL_SpdRR of type p_WHL_SpdRR_t_1
 *   p_Yaw_rate of type p_Yaw_rate_t_1
 *   VN of type VN_t_2
 * COM_DT_SG_ADAS101_3Gen_SignalGroup: Record with elements
 *   ADAS101_AlvCntVal of type COM_DT_ADAS101_AlvCntVal_1
 *   ADAS101_CrcVal of type COM_DT_ADAS101_CrcVal_1
 *   CALR of type COM_DT_CALR_1
 *   p_ABS_DiagSta of type COM_DT_p_ABS_DiagSta
 *   p_CF_ECU_SSC_STAT of type COM_DT_p_CF_ECU_SSC_STAT
 *   p_CLU_OutTempCSta of type COM_DT_p_CLU_OutTempCSta_1
 *   p_ENG_EngSta of type COM_DT_p_ENG_EngSta
 *   p_ENG_IsgSta of type COM_DT_p_ENG_IsgSta
 *   p_HCU_HevRdySta of type COM_DT_p_HCU_HevRdySta
 *   p_ICU_MtGearPosRSta of type COM_DT_p_ICU_MtGearPosRSta
 *   p_SAS_AnglVal of type COM_DT_p_SAS_AnglVal_1
 *   p_TCU_GearSlctDis of type COM_DT_p_TCU_GearSlctDis
 *   p_WHL_SpdFLVal of type COM_DT_p_WHL_SpdFLVal_1
 *   p_WHL_SpdFRVal of type COM_DT_p_WHL_SpdFRVal_1
 *   p_WHL_SpdRLVal of type COM_DT_p_WHL_SpdRLVal_1
 *   p_WHL_SpdRRVal of type COM_DT_p_WHL_SpdRRVal_1
 *   p_YRS_YawRtVal of type COM_DT_p_YRS_YawRtVal_1
 *   VN of type COM_DT_VN_1
 * COM_DT_SG_CodingForRadar: Record with elements
 *   u8_VehicleType of type COM_DT_u8_VehicleType
 * COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt01Val of type COM_DT_FR_RDR_Det_AlvCnt01Val
 *   FR_RDR_Det_AmbigSpeed01 of type COM_DT_FR_RDR_Det_AmbigSpeed01
 *   FR_RDR_Det_AmbigSpeed02 of type COM_DT_FR_RDR_Det_AmbigSpeed02
 *   FR_RDR_Det_AmbigSpeed03 of type COM_DT_FR_RDR_Det_AmbigSpeed03
 *   FR_RDR_Det_AmbigSpeed04 of type COM_DT_FR_RDR_Det_AmbigSpeed04
 *   FR_RDR_Det_AssignTag01 of type COM_DT_FR_RDR_Det_AssignTag01
 *   FR_RDR_Det_AssignTag02 of type COM_DT_FR_RDR_Det_AssignTag02
 *   FR_RDR_Det_AssignTag03 of type COM_DT_FR_RDR_Det_AssignTag03
 *   FR_RDR_Det_AssignTag04 of type COM_DT_FR_RDR_Det_AssignTag04
 *   FR_RDR_Det_Attribute01 of type COM_DT_FR_RDR_Det_Attribute01
 *   FR_RDR_Det_Attribute02 of type COM_DT_FR_RDR_Det_Attribute02
 *   FR_RDR_Det_Attribute03 of type COM_DT_FR_RDR_Det_Attribute03
 *   FR_RDR_Det_Attribute04 of type COM_DT_FR_RDR_Det_Attribute04
 *   FR_RDR_Det_ClusterID01 of type COM_DT_FR_RDR_Det_ClusterID01
 *   FR_RDR_Det_ClusterID02 of type COM_DT_FR_RDR_Det_ClusterID02
 *   FR_RDR_Det_ClusterID03 of type COM_DT_FR_RDR_Det_ClusterID03
 *   FR_RDR_Det_ClusterID04 of type COM_DT_FR_RDR_Det_ClusterID04
 *   FR_RDR_Det_CRC01Val of type COM_DT_FR_RDR_Det_CRC01Val
 *   FR_RDR_Det_Height01 of type COM_DT_FR_RDR_Det_Height01
 *   FR_RDR_Det_Height02 of type COM_DT_FR_RDR_Det_Height02
 *   FR_RDR_Det_Height03 of type COM_DT_FR_RDR_Det_Height03
 *   FR_RDR_Det_Height04 of type COM_DT_FR_RDR_Det_Height04
 *   FR_RDR_Det_Lat01 of type COM_DT_FR_RDR_Det_Lat01
 *   FR_RDR_Det_Lat02 of type COM_DT_FR_RDR_Det_Lat02
 *   FR_RDR_Det_Lat03 of type COM_DT_FR_RDR_Det_Lat03
 *   FR_RDR_Det_Lat04 of type COM_DT_FR_RDR_Det_Lat04
 *   FR_RDR_Det_Long01 of type COM_DT_FR_RDR_Det_Long01
 *   FR_RDR_Det_Long02 of type COM_DT_FR_RDR_Det_Long02
 *   FR_RDR_Det_Long03 of type COM_DT_FR_RDR_Det_Long03
 *   FR_RDR_Det_Long04 of type COM_DT_FR_RDR_Det_Long04
 *   FR_RDR_Det_Mov01 of type COM_DT_FR_RDR_Det_Mov01
 *   FR_RDR_Det_Mov02 of type COM_DT_FR_RDR_Det_Mov02
 *   FR_RDR_Det_Mov03 of type COM_DT_FR_RDR_Det_Mov03
 *   FR_RDR_Det_Mov04 of type COM_DT_FR_RDR_Det_Mov04
 *   FR_RDR_Det_SNR01 of type COM_DT_FR_RDR_Det_SNR01
 *   FR_RDR_Det_SNR02 of type COM_DT_FR_RDR_Det_SNR02
 *   FR_RDR_Det_SNR03 of type COM_DT_FR_RDR_Det_SNR03
 *   FR_RDR_Det_SNR04 of type COM_DT_FR_RDR_Det_SNR04
 *   FR_RDR_Det_Speed01 of type COM_DT_FR_RDR_Det_Speed01
 *   FR_RDR_Det_Speed02 of type COM_DT_FR_RDR_Det_Speed02
 *   FR_RDR_Det_Speed03 of type COM_DT_FR_RDR_Det_Speed03
 *   FR_RDR_Det_Speed04 of type COM_DT_FR_RDR_Det_Speed04
 *   FR_RDR_Det_TrustA01 of type COM_DT_FR_RDR_Det_TrustA01
 *   FR_RDR_Det_TrustA02 of type COM_DT_FR_RDR_Det_TrustA02
 *   FR_RDR_Det_TrustA03 of type COM_DT_FR_RDR_Det_TrustA03
 *   FR_RDR_Det_TrustA04 of type COM_DT_FR_RDR_Det_TrustA04
 *   FR_RDR_Det_TrustV01 of type COM_DT_FR_RDR_Det_TrustV01
 *   FR_RDR_Det_TrustV02 of type COM_DT_FR_RDR_Det_TrustV02
 *   FR_RDR_Det_TrustV03 of type COM_DT_FR_RDR_Det_TrustV03
 *   FR_RDR_Det_TrustV04 of type COM_DT_FR_RDR_Det_TrustV04
 *   FR_RDR_Det_Valid01 of type COM_DT_FR_RDR_Det_Valid01
 *   FR_RDR_Det_Valid02 of type COM_DT_FR_RDR_Det_Valid02
 *   FR_RDR_Det_Valid03 of type COM_DT_FR_RDR_Det_Valid03
 *   FR_RDR_Det_Valid04 of type COM_DT_FR_RDR_Det_Valid04
 * COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt02Val of type COM_DT_FR_RDR_Det_AlvCnt02Val
 *   FR_RDR_Det_AmbigSpeed05 of type COM_DT_FR_RDR_Det_AmbigSpeed05
 *   FR_RDR_Det_AmbigSpeed06 of type COM_DT_FR_RDR_Det_AmbigSpeed06
 *   FR_RDR_Det_AmbigSpeed07 of type COM_DT_FR_RDR_Det_AmbigSpeed07
 *   FR_RDR_Det_AmbigSpeed08 of type COM_DT_FR_RDR_Det_AmbigSpeed08
 *   FR_RDR_Det_AssignTag05 of type COM_DT_FR_RDR_Det_AssignTag05
 *   FR_RDR_Det_AssignTag06 of type COM_DT_FR_RDR_Det_AssignTag06
 *   FR_RDR_Det_AssignTag07 of type COM_DT_FR_RDR_Det_AssignTag07
 *   FR_RDR_Det_AssignTag08 of type COM_DT_FR_RDR_Det_AssignTag08
 *   FR_RDR_Det_Attribute05 of type COM_DT_FR_RDR_Det_Attribute05
 *   FR_RDR_Det_Attribute06 of type COM_DT_FR_RDR_Det_Attribute06
 *   FR_RDR_Det_Attribute07 of type COM_DT_FR_RDR_Det_Attribute07
 *   FR_RDR_Det_Attribute08 of type COM_DT_FR_RDR_Det_Attribute08
 *   FR_RDR_Det_ClusterID05 of type COM_DT_FR_RDR_Det_ClusterID05
 *   FR_RDR_Det_ClusterID06 of type COM_DT_FR_RDR_Det_ClusterID06
 *   FR_RDR_Det_ClusterID07 of type COM_DT_FR_RDR_Det_ClusterID07
 *   FR_RDR_Det_ClusterID08 of type COM_DT_FR_RDR_Det_ClusterID08
 *   FR_RDR_Det_CRC02Val of type COM_DT_FR_RDR_Det_CRC02Val
 *   FR_RDR_Det_Height05 of type COM_DT_FR_RDR_Det_Height05
 *   FR_RDR_Det_Height06 of type COM_DT_FR_RDR_Det_Height06
 *   FR_RDR_Det_Height07 of type COM_DT_FR_RDR_Det_Height07
 *   FR_RDR_Det_Height08 of type COM_DT_FR_RDR_Det_Height08
 *   FR_RDR_Det_Lat05 of type COM_DT_FR_RDR_Det_Lat05
 *   FR_RDR_Det_Lat06 of type COM_DT_FR_RDR_Det_Lat06
 *   FR_RDR_Det_Lat07 of type COM_DT_FR_RDR_Det_Lat07
 *   FR_RDR_Det_Lat08 of type COM_DT_FR_RDR_Det_Lat08
 *   FR_RDR_Det_Long05 of type COM_DT_FR_RDR_Det_Long05
 *   FR_RDR_Det_Long06 of type COM_DT_FR_RDR_Det_Long06
 *   FR_RDR_Det_Long07 of type COM_DT_FR_RDR_Det_Long07
 *   FR_RDR_Det_Long08 of type COM_DT_FR_RDR_Det_Long08
 *   FR_RDR_Det_Mov05 of type COM_DT_FR_RDR_Det_Mov05
 *   FR_RDR_Det_Mov06 of type COM_DT_FR_RDR_Det_Mov06
 *   FR_RDR_Det_Mov07 of type COM_DT_FR_RDR_Det_Mov07
 *   FR_RDR_Det_Mov08 of type COM_DT_FR_RDR_Det_Mov08
 *   FR_RDR_Det_SNR05 of type COM_DT_FR_RDR_Det_SNR05
 *   FR_RDR_Det_SNR06 of type COM_DT_FR_RDR_Det_SNR06
 *   FR_RDR_Det_SNR07 of type COM_DT_FR_RDR_Det_SNR07
 *   FR_RDR_Det_SNR08 of type COM_DT_FR_RDR_Det_SNR08
 *   FR_RDR_Det_Speed05 of type COM_DT_FR_RDR_Det_Speed05
 *   FR_RDR_Det_Speed06 of type COM_DT_FR_RDR_Det_Speed06
 *   FR_RDR_Det_Speed07 of type COM_DT_FR_RDR_Det_Speed07
 *   FR_RDR_Det_Speed08 of type COM_DT_FR_RDR_Det_Speed08
 *   FR_RDR_Det_TrustA05 of type COM_DT_FR_RDR_Det_TrustA05
 *   FR_RDR_Det_TrustA06 of type COM_DT_FR_RDR_Det_TrustA06
 *   FR_RDR_Det_TrustA07 of type COM_DT_FR_RDR_Det_TrustA07
 *   FR_RDR_Det_TrustA08 of type COM_DT_FR_RDR_Det_TrustA08
 *   FR_RDR_Det_TrustV05 of type COM_DT_FR_RDR_Det_TrustV05
 *   FR_RDR_Det_TrustV06 of type COM_DT_FR_RDR_Det_TrustV06
 *   FR_RDR_Det_TrustV07 of type COM_DT_FR_RDR_Det_TrustV07
 *   FR_RDR_Det_TrustV08 of type COM_DT_FR_RDR_Det_TrustV08
 *   FR_RDR_Det_Valid05 of type COM_DT_FR_RDR_Det_Valid05
 *   FR_RDR_Det_Valid06 of type COM_DT_FR_RDR_Det_Valid06
 *   FR_RDR_Det_Valid07 of type COM_DT_FR_RDR_Det_Valid07
 *   FR_RDR_Det_Valid08 of type COM_DT_FR_RDR_Det_Valid08
 * COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt03Val of type COM_DT_FR_RDR_Det_AlvCnt03Val
 *   FR_RDR_Det_AmbigSpeed09 of type COM_DT_FR_RDR_Det_AmbigSpeed09
 *   FR_RDR_Det_AmbigSpeed10 of type COM_DT_FR_RDR_Det_AmbigSpeed10
 *   FR_RDR_Det_AmbigSpeed11 of type COM_DT_FR_RDR_Det_AmbigSpeed11
 *   FR_RDR_Det_AmbigSpeed12 of type COM_DT_FR_RDR_Det_AmbigSpeed12
 *   FR_RDR_Det_AssignTag09 of type COM_DT_FR_RDR_Det_AssignTag09
 *   FR_RDR_Det_AssignTag10 of type COM_DT_FR_RDR_Det_AssignTag10
 *   FR_RDR_Det_AssignTag11 of type COM_DT_FR_RDR_Det_AssignTag11
 *   FR_RDR_Det_AssignTag12 of type COM_DT_FR_RDR_Det_AssignTag12
 *   FR_RDR_Det_Attribute09 of type COM_DT_FR_RDR_Det_Attribute09
 *   FR_RDR_Det_Attribute10 of type COM_DT_FR_RDR_Det_Attribute10
 *   FR_RDR_Det_Attribute11 of type COM_DT_FR_RDR_Det_Attribute11
 *   FR_RDR_Det_Attribute12 of type COM_DT_FR_RDR_Det_Attribute12
 *   FR_RDR_Det_ClusterID09 of type COM_DT_FR_RDR_Det_ClusterID09
 *   FR_RDR_Det_ClusterID10 of type COM_DT_FR_RDR_Det_ClusterID10
 *   FR_RDR_Det_ClusterID11 of type COM_DT_FR_RDR_Det_ClusterID11
 *   FR_RDR_Det_ClusterID12 of type COM_DT_FR_RDR_Det_ClusterID12
 *   FR_RDR_Det_CRC03Val of type COM_DT_FR_RDR_Det_CRC03Val
 *   FR_RDR_Det_Height09 of type COM_DT_FR_RDR_Det_Height09
 *   FR_RDR_Det_Height10 of type COM_DT_FR_RDR_Det_Height10
 *   FR_RDR_Det_Height11 of type COM_DT_FR_RDR_Det_Height11
 *   FR_RDR_Det_Height12 of type COM_DT_FR_RDR_Det_Height12
 *   FR_RDR_Det_Lat09 of type COM_DT_FR_RDR_Det_Lat09
 *   FR_RDR_Det_Lat10 of type COM_DT_FR_RDR_Det_Lat10
 *   FR_RDR_Det_Lat11 of type COM_DT_FR_RDR_Det_Lat11
 *   FR_RDR_Det_Lat12 of type COM_DT_FR_RDR_Det_Lat12
 *   FR_RDR_Det_Long09 of type COM_DT_FR_RDR_Det_Long09
 *   FR_RDR_Det_Long10 of type COM_DT_FR_RDR_Det_Long10
 *   FR_RDR_Det_Long11 of type COM_DT_FR_RDR_Det_Long11
 *   FR_RDR_Det_Long12 of type COM_DT_FR_RDR_Det_Long12
 *   FR_RDR_Det_Mov09 of type COM_DT_FR_RDR_Det_Mov09
 *   FR_RDR_Det_Mov10 of type COM_DT_FR_RDR_Det_Mov10
 *   FR_RDR_Det_Mov11 of type COM_DT_FR_RDR_Det_Mov11
 *   FR_RDR_Det_Mov12 of type COM_DT_FR_RDR_Det_Mov12
 *   FR_RDR_Det_SNR09 of type COM_DT_FR_RDR_Det_SNR09
 *   FR_RDR_Det_SNR10 of type COM_DT_FR_RDR_Det_SNR10
 *   FR_RDR_Det_SNR11 of type COM_DT_FR_RDR_Det_SNR11
 *   FR_RDR_Det_SNR12 of type COM_DT_FR_RDR_Det_SNR12
 *   FR_RDR_Det_Speed09 of type COM_DT_FR_RDR_Det_Speed09
 *   FR_RDR_Det_Speed10 of type COM_DT_FR_RDR_Det_Speed10
 *   FR_RDR_Det_Speed11 of type COM_DT_FR_RDR_Det_Speed11
 *   FR_RDR_Det_Speed12 of type COM_DT_FR_RDR_Det_Speed12
 *   FR_RDR_Det_TrustA09 of type COM_DT_FR_RDR_Det_TrustA09
 *   FR_RDR_Det_TrustA10 of type COM_DT_FR_RDR_Det_TrustA10
 *   FR_RDR_Det_TrustA11 of type COM_DT_FR_RDR_Det_TrustA11
 *   FR_RDR_Det_TrustA12 of type COM_DT_FR_RDR_Det_TrustA12
 *   FR_RDR_Det_TrustV09 of type COM_DT_FR_RDR_Det_TrustV09
 *   FR_RDR_Det_TrustV10 of type COM_DT_FR_RDR_Det_TrustV10
 *   FR_RDR_Det_TrustV11 of type COM_DT_FR_RDR_Det_TrustV11
 *   FR_RDR_Det_TrustV12 of type COM_DT_FR_RDR_Det_TrustV12
 *   FR_RDR_Det_Valid09 of type COM_DT_FR_RDR_Det_Valid09
 *   FR_RDR_Det_Valid10 of type COM_DT_FR_RDR_Det_Valid10
 *   FR_RDR_Det_Valid11 of type COM_DT_FR_RDR_Det_Valid11
 *   FR_RDR_Det_Valid12 of type COM_DT_FR_RDR_Det_Valid12
 * COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt04Val of type COM_DT_FR_RDR_Det_AlvCnt04Val
 *   FR_RDR_Det_AmbigSpeed13 of type COM_DT_FR_RDR_Det_AmbigSpeed13
 *   FR_RDR_Det_AmbigSpeed14 of type COM_DT_FR_RDR_Det_AmbigSpeed14
 *   FR_RDR_Det_AmbigSpeed15 of type COM_DT_FR_RDR_Det_AmbigSpeed15
 *   FR_RDR_Det_AmbigSpeed16 of type COM_DT_FR_RDR_Det_AmbigSpeed16
 *   FR_RDR_Det_AssignTag13 of type COM_DT_FR_RDR_Det_AssignTag13
 *   FR_RDR_Det_AssignTag14 of type COM_DT_FR_RDR_Det_AssignTag14
 *   FR_RDR_Det_AssignTag15 of type COM_DT_FR_RDR_Det_AssignTag15
 *   FR_RDR_Det_AssignTag16 of type COM_DT_FR_RDR_Det_AssignTag16
 *   FR_RDR_Det_Attribute13 of type COM_DT_FR_RDR_Det_Attribute13
 *   FR_RDR_Det_Attribute14 of type COM_DT_FR_RDR_Det_Attribute14
 *   FR_RDR_Det_Attribute15 of type COM_DT_FR_RDR_Det_Attribute15
 *   FR_RDR_Det_Attribute16 of type COM_DT_FR_RDR_Det_Attribute16
 *   FR_RDR_Det_ClusterID13 of type COM_DT_FR_RDR_Det_ClusterID13
 *   FR_RDR_Det_ClusterID14 of type COM_DT_FR_RDR_Det_ClusterID14
 *   FR_RDR_Det_ClusterID15 of type COM_DT_FR_RDR_Det_ClusterID15
 *   FR_RDR_Det_ClusterID16 of type COM_DT_FR_RDR_Det_ClusterID16
 *   FR_RDR_Det_CRC04Val of type COM_DT_FR_RDR_Det_CRC04Val
 *   FR_RDR_Det_Height13 of type COM_DT_FR_RDR_Det_Height13
 *   FR_RDR_Det_Height14 of type COM_DT_FR_RDR_Det_Height14
 *   FR_RDR_Det_Height15 of type COM_DT_FR_RDR_Det_Height15
 *   FR_RDR_Det_Height16 of type COM_DT_FR_RDR_Det_Height16
 *   FR_RDR_Det_Lat13 of type COM_DT_FR_RDR_Det_Lat13
 *   FR_RDR_Det_Lat14 of type COM_DT_FR_RDR_Det_Lat14
 *   FR_RDR_Det_Lat15 of type COM_DT_FR_RDR_Det_Lat15
 *   FR_RDR_Det_Lat16 of type COM_DT_FR_RDR_Det_Lat16
 *   FR_RDR_Det_Long13 of type COM_DT_FR_RDR_Det_Long13
 *   FR_RDR_Det_Long14 of type COM_DT_FR_RDR_Det_Long14
 *   FR_RDR_Det_Long15 of type COM_DT_FR_RDR_Det_Long15
 *   FR_RDR_Det_Long16 of type COM_DT_FR_RDR_Det_Long16
 *   FR_RDR_Det_Mov13 of type COM_DT_FR_RDR_Det_Mov13
 *   FR_RDR_Det_Mov14 of type COM_DT_FR_RDR_Det_Mov14
 *   FR_RDR_Det_Mov15 of type COM_DT_FR_RDR_Det_Mov15
 *   FR_RDR_Det_Mov16 of type COM_DT_FR_RDR_Det_Mov16
 *   FR_RDR_Det_SNR13 of type COM_DT_FR_RDR_Det_SNR13
 *   FR_RDR_Det_SNR14 of type COM_DT_FR_RDR_Det_SNR14
 *   FR_RDR_Det_SNR15 of type COM_DT_FR_RDR_Det_SNR15
 *   FR_RDR_Det_SNR16 of type COM_DT_FR_RDR_Det_SNR16
 *   FR_RDR_Det_Speed13 of type COM_DT_FR_RDR_Det_Speed13
 *   FR_RDR_Det_Speed14 of type COM_DT_FR_RDR_Det_Speed14
 *   FR_RDR_Det_Speed15 of type COM_DT_FR_RDR_Det_Speed15
 *   FR_RDR_Det_Speed16 of type COM_DT_FR_RDR_Det_Speed16
 *   FR_RDR_Det_TrustA13 of type COM_DT_FR_RDR_Det_TrustA13
 *   FR_RDR_Det_TrustA14 of type COM_DT_FR_RDR_Det_TrustA14
 *   FR_RDR_Det_TrustA15 of type COM_DT_FR_RDR_Det_TrustA15
 *   FR_RDR_Det_TrustA16 of type COM_DT_FR_RDR_Det_TrustA16
 *   FR_RDR_Det_TrustV13 of type COM_DT_FR_RDR_Det_TrustV13
 *   FR_RDR_Det_TrustV14 of type COM_DT_FR_RDR_Det_TrustV14
 *   FR_RDR_Det_TrustV15 of type COM_DT_FR_RDR_Det_TrustV15
 *   FR_RDR_Det_TrustV16 of type COM_DT_FR_RDR_Det_TrustV16
 *   FR_RDR_Det_Valid13 of type COM_DT_FR_RDR_Det_Valid13
 *   FR_RDR_Det_Valid14 of type COM_DT_FR_RDR_Det_Valid14
 *   FR_RDR_Det_Valid15 of type COM_DT_FR_RDR_Det_Valid15
 *   FR_RDR_Det_Valid16 of type COM_DT_FR_RDR_Det_Valid16
 * COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt05Val of type COM_DT_FR_RDR_Det_AlvCnt05Val
 *   FR_RDR_Det_AmbigSpeed17 of type COM_DT_FR_RDR_Det_AmbigSpeed17
 *   FR_RDR_Det_AmbigSpeed18 of type COM_DT_FR_RDR_Det_AmbigSpeed18
 *   FR_RDR_Det_AmbigSpeed19 of type COM_DT_FR_RDR_Det_AmbigSpeed19
 *   FR_RDR_Det_AmbigSpeed20 of type COM_DT_FR_RDR_Det_AmbigSpeed20
 *   FR_RDR_Det_AssignTag17 of type COM_DT_FR_RDR_Det_AssignTag17
 *   FR_RDR_Det_AssignTag18 of type COM_DT_FR_RDR_Det_AssignTag18
 *   FR_RDR_Det_AssignTag19 of type COM_DT_FR_RDR_Det_AssignTag19
 *   FR_RDR_Det_AssignTag20 of type COM_DT_FR_RDR_Det_AssignTag20
 *   FR_RDR_Det_Attribute17 of type COM_DT_FR_RDR_Det_Attribute17
 *   FR_RDR_Det_Attribute18 of type COM_DT_FR_RDR_Det_Attribute18
 *   FR_RDR_Det_Attribute19 of type COM_DT_FR_RDR_Det_Attribute19
 *   FR_RDR_Det_Attribute20 of type COM_DT_FR_RDR_Det_Attribute20
 *   FR_RDR_Det_ClusterID17 of type COM_DT_FR_RDR_Det_ClusterID17
 *   FR_RDR_Det_ClusterID18 of type COM_DT_FR_RDR_Det_ClusterID18
 *   FR_RDR_Det_ClusterID19 of type COM_DT_FR_RDR_Det_ClusterID19
 *   FR_RDR_Det_ClusterID20 of type COM_DT_FR_RDR_Det_ClusterID20
 *   FR_RDR_Det_CRC05Val of type COM_DT_FR_RDR_Det_CRC05Val
 *   FR_RDR_Det_Height17 of type COM_DT_FR_RDR_Det_Height17
 *   FR_RDR_Det_Height18 of type COM_DT_FR_RDR_Det_Height18
 *   FR_RDR_Det_Height19 of type COM_DT_FR_RDR_Det_Height19
 *   FR_RDR_Det_Height20 of type COM_DT_FR_RDR_Det_Height20
 *   FR_RDR_Det_Lat17 of type COM_DT_FR_RDR_Det_Lat17
 *   FR_RDR_Det_Lat18 of type COM_DT_FR_RDR_Det_Lat18
 *   FR_RDR_Det_Lat19 of type COM_DT_FR_RDR_Det_Lat19
 *   FR_RDR_Det_Lat20 of type COM_DT_FR_RDR_Det_Lat20
 *   FR_RDR_Det_Long17 of type COM_DT_FR_RDR_Det_Long17
 *   FR_RDR_Det_Long18 of type COM_DT_FR_RDR_Det_Long18
 *   FR_RDR_Det_Long19 of type COM_DT_FR_RDR_Det_Long19
 *   FR_RDR_Det_Long20 of type COM_DT_FR_RDR_Det_Long20
 *   FR_RDR_Det_Mov17 of type COM_DT_FR_RDR_Det_Mov17
 *   FR_RDR_Det_Mov18 of type COM_DT_FR_RDR_Det_Mov18
 *   FR_RDR_Det_Mov19 of type COM_DT_FR_RDR_Det_Mov19
 *   FR_RDR_Det_Mov20 of type COM_DT_FR_RDR_Det_Mov20
 *   FR_RDR_Det_SNR17 of type COM_DT_FR_RDR_Det_SNR17
 *   FR_RDR_Det_SNR18 of type COM_DT_FR_RDR_Det_SNR18
 *   FR_RDR_Det_SNR19 of type COM_DT_FR_RDR_Det_SNR19
 *   FR_RDR_Det_SNR20 of type COM_DT_FR_RDR_Det_SNR20
 *   FR_RDR_Det_Speed17 of type COM_DT_FR_RDR_Det_Speed17
 *   FR_RDR_Det_Speed18 of type COM_DT_FR_RDR_Det_Speed18
 *   FR_RDR_Det_Speed19 of type COM_DT_FR_RDR_Det_Speed19
 *   FR_RDR_Det_Speed20 of type COM_DT_FR_RDR_Det_Speed20
 *   FR_RDR_Det_TrustA17 of type COM_DT_FR_RDR_Det_TrustA17
 *   FR_RDR_Det_TrustA18 of type COM_DT_FR_RDR_Det_TrustA18
 *   FR_RDR_Det_TrustA19 of type COM_DT_FR_RDR_Det_TrustA19
 *   FR_RDR_Det_TrustA20 of type COM_DT_FR_RDR_Det_TrustA20
 *   FR_RDR_Det_TrustV17 of type COM_DT_FR_RDR_Det_TrustV17
 *   FR_RDR_Det_TrustV18 of type COM_DT_FR_RDR_Det_TrustV18
 *   FR_RDR_Det_TrustV19 of type COM_DT_FR_RDR_Det_TrustV19
 *   FR_RDR_Det_TrustV20 of type COM_DT_FR_RDR_Det_TrustV20
 *   FR_RDR_Det_Valid17 of type COM_DT_FR_RDR_Det_Valid17
 *   FR_RDR_Det_Valid18 of type COM_DT_FR_RDR_Det_Valid18
 *   FR_RDR_Det_Valid19 of type COM_DT_FR_RDR_Det_Valid19
 *   FR_RDR_Det_Valid20 of type COM_DT_FR_RDR_Det_Valid20
 * COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt06Val of type COM_DT_FR_RDR_Det_AlvCnt06Val
 *   FR_RDR_Det_AmbigSpeed21 of type COM_DT_FR_RDR_Det_AmbigSpeed21
 *   FR_RDR_Det_AmbigSpeed22 of type COM_DT_FR_RDR_Det_AmbigSpeed22
 *   FR_RDR_Det_AmbigSpeed23 of type COM_DT_FR_RDR_Det_AmbigSpeed23
 *   FR_RDR_Det_AmbigSpeed24 of type COM_DT_FR_RDR_Det_AmbigSpeed24
 *   FR_RDR_Det_AssignTag21 of type COM_DT_FR_RDR_Det_AssignTag21
 *   FR_RDR_Det_AssignTag22 of type COM_DT_FR_RDR_Det_AssignTag22
 *   FR_RDR_Det_AssignTag23 of type COM_DT_FR_RDR_Det_AssignTag23
 *   FR_RDR_Det_AssignTag24 of type COM_DT_FR_RDR_Det_AssignTag24
 *   FR_RDR_Det_Attribute21 of type COM_DT_FR_RDR_Det_Attribute21
 *   FR_RDR_Det_Attribute22 of type COM_DT_FR_RDR_Det_Attribute22
 *   FR_RDR_Det_Attribute23 of type COM_DT_FR_RDR_Det_Attribute23
 *   FR_RDR_Det_Attribute24 of type COM_DT_FR_RDR_Det_Attribute24
 *   FR_RDR_Det_ClusterID21 of type COM_DT_FR_RDR_Det_ClusterID21
 *   FR_RDR_Det_ClusterID22 of type COM_DT_FR_RDR_Det_ClusterID22
 *   FR_RDR_Det_ClusterID23 of type COM_DT_FR_RDR_Det_ClusterID23
 *   FR_RDR_Det_ClusterID24 of type COM_DT_FR_RDR_Det_ClusterID24
 *   FR_RDR_Det_CRC06Val of type COM_DT_FR_RDR_Det_CRC06Val
 *   FR_RDR_Det_Height21 of type COM_DT_FR_RDR_Det_Height21
 *   FR_RDR_Det_Height22 of type COM_DT_FR_RDR_Det_Height22
 *   FR_RDR_Det_Height23 of type COM_DT_FR_RDR_Det_Height23
 *   FR_RDR_Det_Height24 of type COM_DT_FR_RDR_Det_Height24
 *   FR_RDR_Det_Lat21 of type COM_DT_FR_RDR_Det_Lat21
 *   FR_RDR_Det_Lat22 of type COM_DT_FR_RDR_Det_Lat22
 *   FR_RDR_Det_Lat23 of type COM_DT_FR_RDR_Det_Lat23
 *   FR_RDR_Det_Lat24 of type COM_DT_FR_RDR_Det_Lat24
 *   FR_RDR_Det_Long21 of type COM_DT_FR_RDR_Det_Long21
 *   FR_RDR_Det_Long22 of type COM_DT_FR_RDR_Det_Long22
 *   FR_RDR_Det_Long23 of type COM_DT_FR_RDR_Det_Long23
 *   FR_RDR_Det_Long24 of type COM_DT_FR_RDR_Det_Long24
 *   FR_RDR_Det_Mov21 of type COM_DT_FR_RDR_Det_Mov21
 *   FR_RDR_Det_Mov22 of type COM_DT_FR_RDR_Det_Mov22
 *   FR_RDR_Det_Mov23 of type COM_DT_FR_RDR_Det_Mov23
 *   FR_RDR_Det_Mov24 of type COM_DT_FR_RDR_Det_Mov24
 *   FR_RDR_Det_SNR21 of type COM_DT_FR_RDR_Det_SNR21
 *   FR_RDR_Det_SNR22 of type COM_DT_FR_RDR_Det_SNR22
 *   FR_RDR_Det_SNR23 of type COM_DT_FR_RDR_Det_SNR23
 *   FR_RDR_Det_SNR24 of type COM_DT_FR_RDR_Det_SNR24
 *   FR_RDR_Det_Speed21 of type COM_DT_FR_RDR_Det_Speed21
 *   FR_RDR_Det_Speed22 of type COM_DT_FR_RDR_Det_Speed22
 *   FR_RDR_Det_Speed23 of type COM_DT_FR_RDR_Det_Speed23
 *   FR_RDR_Det_Speed24 of type COM_DT_FR_RDR_Det_Speed24
 *   FR_RDR_Det_TrustA21 of type COM_DT_FR_RDR_Det_TrustA21
 *   FR_RDR_Det_TrustA22 of type COM_DT_FR_RDR_Det_TrustA22
 *   FR_RDR_Det_TrustA23 of type COM_DT_FR_RDR_Det_TrustA23
 *   FR_RDR_Det_TrustA24 of type COM_DT_FR_RDR_Det_TrustA24
 *   FR_RDR_Det_TrustV21 of type COM_DT_FR_RDR_Det_TrustV21
 *   FR_RDR_Det_TrustV22 of type COM_DT_FR_RDR_Det_TrustV22
 *   FR_RDR_Det_TrustV23 of type COM_DT_FR_RDR_Det_TrustV23
 *   FR_RDR_Det_TrustV24 of type COM_DT_FR_RDR_Det_TrustV24
 *   FR_RDR_Det_Valid21 of type COM_DT_FR_RDR_Det_Valid21
 *   FR_RDR_Det_Valid22 of type COM_DT_FR_RDR_Det_Valid22
 *   FR_RDR_Det_Valid23 of type COM_DT_FR_RDR_Det_Valid23
 *   FR_RDR_Det_Valid24 of type COM_DT_FR_RDR_Det_Valid24
 * COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt07Val of type COM_DT_FR_RDR_Det_AlvCnt07Val
 *   FR_RDR_Det_AmbigSpeed25 of type COM_DT_FR_RDR_Det_AmbigSpeed25
 *   FR_RDR_Det_AmbigSpeed26 of type COM_DT_FR_RDR_Det_AmbigSpeed26
 *   FR_RDR_Det_AmbigSpeed27 of type COM_DT_FR_RDR_Det_AmbigSpeed27
 *   FR_RDR_Det_AmbigSpeed28 of type COM_DT_FR_RDR_Det_AmbigSpeed28
 *   FR_RDR_Det_AssignTag25 of type COM_DT_FR_RDR_Det_AssignTag25
 *   FR_RDR_Det_AssignTag26 of type COM_DT_FR_RDR_Det_AssignTag26
 *   FR_RDR_Det_AssignTag27 of type COM_DT_FR_RDR_Det_AssignTag27
 *   FR_RDR_Det_AssignTag28 of type COM_DT_FR_RDR_Det_AssignTag28
 *   FR_RDR_Det_Attribute25 of type COM_DT_FR_RDR_Det_Attribute25
 *   FR_RDR_Det_Attribute26 of type COM_DT_FR_RDR_Det_Attribute26
 *   FR_RDR_Det_Attribute27 of type COM_DT_FR_RDR_Det_Attribute27
 *   FR_RDR_Det_Attribute28 of type COM_DT_FR_RDR_Det_Attribute28
 *   FR_RDR_Det_ClusterID25 of type COM_DT_FR_RDR_Det_ClusterID25
 *   FR_RDR_Det_ClusterID26 of type COM_DT_FR_RDR_Det_ClusterID26
 *   FR_RDR_Det_ClusterID27 of type COM_DT_FR_RDR_Det_ClusterID27
 *   FR_RDR_Det_ClusterID28 of type COM_DT_FR_RDR_Det_ClusterID28
 *   FR_RDR_Det_CRC07Val of type COM_DT_FR_RDR_Det_CRC07Val
 *   FR_RDR_Det_Height25 of type COM_DT_FR_RDR_Det_Height25
 *   FR_RDR_Det_Height26 of type COM_DT_FR_RDR_Det_Height26
 *   FR_RDR_Det_Height27 of type COM_DT_FR_RDR_Det_Height27
 *   FR_RDR_Det_Height28 of type COM_DT_FR_RDR_Det_Height28
 *   FR_RDR_Det_Lat25 of type COM_DT_FR_RDR_Det_Lat25
 *   FR_RDR_Det_Lat26 of type COM_DT_FR_RDR_Det_Lat26
 *   FR_RDR_Det_Lat27 of type COM_DT_FR_RDR_Det_Lat27
 *   FR_RDR_Det_Lat28 of type COM_DT_FR_RDR_Det_Lat28
 *   FR_RDR_Det_Long25 of type COM_DT_FR_RDR_Det_Long25
 *   FR_RDR_Det_Long26 of type COM_DT_FR_RDR_Det_Long26
 *   FR_RDR_Det_Long27 of type COM_DT_FR_RDR_Det_Long27
 *   FR_RDR_Det_Long28 of type COM_DT_FR_RDR_Det_Long28
 *   FR_RDR_Det_Mov25 of type COM_DT_FR_RDR_Det_Mov25
 *   FR_RDR_Det_Mov26 of type COM_DT_FR_RDR_Det_Mov26
 *   FR_RDR_Det_Mov27 of type COM_DT_FR_RDR_Det_Mov27
 *   FR_RDR_Det_Mov28 of type COM_DT_FR_RDR_Det_Mov28
 *   FR_RDR_Det_SNR25 of type COM_DT_FR_RDR_Det_SNR25
 *   FR_RDR_Det_SNR26 of type COM_DT_FR_RDR_Det_SNR26
 *   FR_RDR_Det_SNR27 of type COM_DT_FR_RDR_Det_SNR27
 *   FR_RDR_Det_SNR28 of type COM_DT_FR_RDR_Det_SNR28
 *   FR_RDR_Det_Speed25 of type COM_DT_FR_RDR_Det_Speed25
 *   FR_RDR_Det_Speed26 of type COM_DT_FR_RDR_Det_Speed26
 *   FR_RDR_Det_Speed27 of type COM_DT_FR_RDR_Det_Speed27
 *   FR_RDR_Det_Speed28 of type COM_DT_FR_RDR_Det_Speed28
 *   FR_RDR_Det_TrustA25 of type COM_DT_FR_RDR_Det_TrustA25
 *   FR_RDR_Det_TrustA26 of type COM_DT_FR_RDR_Det_TrustA26
 *   FR_RDR_Det_TrustA27 of type COM_DT_FR_RDR_Det_TrustA27
 *   FR_RDR_Det_TrustA28 of type COM_DT_FR_RDR_Det_TrustA28
 *   FR_RDR_Det_TrustV25 of type COM_DT_FR_RDR_Det_TrustV25
 *   FR_RDR_Det_TrustV26 of type COM_DT_FR_RDR_Det_TrustV26
 *   FR_RDR_Det_TrustV27 of type COM_DT_FR_RDR_Det_TrustV27
 *   FR_RDR_Det_TrustV28 of type COM_DT_FR_RDR_Det_TrustV28
 *   FR_RDR_Det_Valid25 of type COM_DT_FR_RDR_Det_Valid25
 *   FR_RDR_Det_Valid26 of type COM_DT_FR_RDR_Det_Valid26
 *   FR_RDR_Det_Valid27 of type COM_DT_FR_RDR_Det_Valid27
 *   FR_RDR_Det_Valid28 of type COM_DT_FR_RDR_Det_Valid28
 * COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt08Val of type COM_DT_FR_RDR_Det_AlvCnt08Val
 *   FR_RDR_Det_AmbigSpeed29 of type COM_DT_FR_RDR_Det_AmbigSpeed29
 *   FR_RDR_Det_AmbigSpeed30 of type COM_DT_FR_RDR_Det_AmbigSpeed30
 *   FR_RDR_Det_AmbigSpeed31 of type COM_DT_FR_RDR_Det_AmbigSpeed31
 *   FR_RDR_Det_AmbigSpeed32 of type COM_DT_FR_RDR_Det_AmbigSpeed32
 *   FR_RDR_Det_AssignTag29 of type COM_DT_FR_RDR_Det_AssignTag29
 *   FR_RDR_Det_AssignTag30 of type COM_DT_FR_RDR_Det_AssignTag30
 *   FR_RDR_Det_AssignTag31 of type COM_DT_FR_RDR_Det_AssignTag31
 *   FR_RDR_Det_AssignTag32 of type COM_DT_FR_RDR_Det_AssignTag32
 *   FR_RDR_Det_Attribute29 of type COM_DT_FR_RDR_Det_Attribute29
 *   FR_RDR_Det_Attribute30 of type COM_DT_FR_RDR_Det_Attribute30
 *   FR_RDR_Det_Attribute31 of type COM_DT_FR_RDR_Det_Attribute31
 *   FR_RDR_Det_Attribute32 of type COM_DT_FR_RDR_Det_Attribute32
 *   FR_RDR_Det_ClusterID29 of type COM_DT_FR_RDR_Det_ClusterID29
 *   FR_RDR_Det_ClusterID30 of type COM_DT_FR_RDR_Det_ClusterID30
 *   FR_RDR_Det_ClusterID31 of type COM_DT_FR_RDR_Det_ClusterID31
 *   FR_RDR_Det_ClusterID32 of type COM_DT_FR_RDR_Det_ClusterID32
 *   FR_RDR_Det_CRC08Val of type COM_DT_FR_RDR_Det_CRC08Val
 *   FR_RDR_Det_Height29 of type COM_DT_FR_RDR_Det_Height29
 *   FR_RDR_Det_Height30 of type COM_DT_FR_RDR_Det_Height30
 *   FR_RDR_Det_Height31 of type COM_DT_FR_RDR_Det_Height31
 *   FR_RDR_Det_Height32 of type COM_DT_FR_RDR_Det_Height32
 *   FR_RDR_Det_Lat29 of type COM_DT_FR_RDR_Det_Lat29
 *   FR_RDR_Det_Lat30 of type COM_DT_FR_RDR_Det_Lat30
 *   FR_RDR_Det_Lat31 of type COM_DT_FR_RDR_Det_Lat31
 *   FR_RDR_Det_Lat32 of type COM_DT_FR_RDR_Det_Lat32
 *   FR_RDR_Det_Long29 of type COM_DT_FR_RDR_Det_Long29
 *   FR_RDR_Det_Long30 of type COM_DT_FR_RDR_Det_Long30
 *   FR_RDR_Det_Long31 of type COM_DT_FR_RDR_Det_Long31
 *   FR_RDR_Det_Long32 of type COM_DT_FR_RDR_Det_Long32
 *   FR_RDR_Det_Mov29 of type COM_DT_FR_RDR_Det_Mov29
 *   FR_RDR_Det_Mov30 of type COM_DT_FR_RDR_Det_Mov30
 *   FR_RDR_Det_Mov31 of type COM_DT_FR_RDR_Det_Mov31
 *   FR_RDR_Det_Mov32 of type COM_DT_FR_RDR_Det_Mov32
 *   FR_RDR_Det_SNR29 of type COM_DT_FR_RDR_Det_SNR29
 *   FR_RDR_Det_SNR30 of type COM_DT_FR_RDR_Det_SNR30
 *   FR_RDR_Det_SNR31 of type COM_DT_FR_RDR_Det_SNR31
 *   FR_RDR_Det_SNR32 of type COM_DT_FR_RDR_Det_SNR32
 *   FR_RDR_Det_Speed29 of type COM_DT_FR_RDR_Det_Speed29
 *   FR_RDR_Det_Speed30 of type COM_DT_FR_RDR_Det_Speed30
 *   FR_RDR_Det_Speed31 of type COM_DT_FR_RDR_Det_Speed31
 *   FR_RDR_Det_Speed32 of type COM_DT_FR_RDR_Det_Speed32
 *   FR_RDR_Det_TrustA29 of type COM_DT_FR_RDR_Det_TrustA29
 *   FR_RDR_Det_TrustA30 of type COM_DT_FR_RDR_Det_TrustA30
 *   FR_RDR_Det_TrustA31 of type COM_DT_FR_RDR_Det_TrustA31
 *   FR_RDR_Det_TrustA32 of type COM_DT_FR_RDR_Det_TrustA32
 *   FR_RDR_Det_TrustV29 of type COM_DT_FR_RDR_Det_TrustV29
 *   FR_RDR_Det_TrustV30 of type COM_DT_FR_RDR_Det_TrustV30
 *   FR_RDR_Det_TrustV31 of type COM_DT_FR_RDR_Det_TrustV31
 *   FR_RDR_Det_TrustV32 of type COM_DT_FR_RDR_Det_TrustV32
 *   FR_RDR_Det_Valid29 of type COM_DT_FR_RDR_Det_Valid29
 *   FR_RDR_Det_Valid30 of type COM_DT_FR_RDR_Det_Valid30
 *   FR_RDR_Det_Valid31 of type COM_DT_FR_RDR_Det_Valid31
 *   FR_RDR_Det_Valid32 of type COM_DT_FR_RDR_Det_Valid32
 * COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt09Val of type COM_DT_FR_RDR_Det_AlvCnt09Val
 *   FR_RDR_Det_AmbigSpeed33 of type COM_DT_FR_RDR_Det_AmbigSpeed33
 *   FR_RDR_Det_AmbigSpeed34 of type COM_DT_FR_RDR_Det_AmbigSpeed34
 *   FR_RDR_Det_AmbigSpeed35 of type COM_DT_FR_RDR_Det_AmbigSpeed35
 *   FR_RDR_Det_AmbigSpeed36 of type COM_DT_FR_RDR_Det_AmbigSpeed36
 *   FR_RDR_Det_AssignTag33 of type COM_DT_FR_RDR_Det_AssignTag33
 *   FR_RDR_Det_AssignTag34 of type COM_DT_FR_RDR_Det_AssignTag34
 *   FR_RDR_Det_AssignTag35 of type COM_DT_FR_RDR_Det_AssignTag35
 *   FR_RDR_Det_AssignTag36 of type COM_DT_FR_RDR_Det_AssignTag36
 *   FR_RDR_Det_Attribute33 of type COM_DT_FR_RDR_Det_Attribute33
 *   FR_RDR_Det_Attribute34 of type COM_DT_FR_RDR_Det_Attribute34
 *   FR_RDR_Det_Attribute35 of type COM_DT_FR_RDR_Det_Attribute35
 *   FR_RDR_Det_Attribute36 of type COM_DT_FR_RDR_Det_Attribute36
 *   FR_RDR_Det_ClusterID33 of type COM_DT_FR_RDR_Det_ClusterID33
 *   FR_RDR_Det_ClusterID34 of type COM_DT_FR_RDR_Det_ClusterID34
 *   FR_RDR_Det_ClusterID35 of type COM_DT_FR_RDR_Det_ClusterID35
 *   FR_RDR_Det_ClusterID36 of type COM_DT_FR_RDR_Det_ClusterID36
 *   FR_RDR_Det_CRC09Val of type COM_DT_FR_RDR_Det_CRC09Val
 *   FR_RDR_Det_Height33 of type COM_DT_FR_RDR_Det_Height33
 *   FR_RDR_Det_Height34 of type COM_DT_FR_RDR_Det_Height34
 *   FR_RDR_Det_Height35 of type COM_DT_FR_RDR_Det_Height35
 *   FR_RDR_Det_Height36 of type COM_DT_FR_RDR_Det_Height36
 *   FR_RDR_Det_Lat33 of type COM_DT_FR_RDR_Det_Lat33
 *   FR_RDR_Det_Lat34 of type COM_DT_FR_RDR_Det_Lat34
 *   FR_RDR_Det_Lat35 of type COM_DT_FR_RDR_Det_Lat35
 *   FR_RDR_Det_Lat36 of type COM_DT_FR_RDR_Det_Lat36
 *   FR_RDR_Det_Long33 of type COM_DT_FR_RDR_Det_Long33
 *   FR_RDR_Det_Long34 of type COM_DT_FR_RDR_Det_Long34
 *   FR_RDR_Det_Long35 of type COM_DT_FR_RDR_Det_Long35
 *   FR_RDR_Det_Long36 of type COM_DT_FR_RDR_Det_Long36
 *   FR_RDR_Det_Mov33 of type COM_DT_FR_RDR_Det_Mov33
 *   FR_RDR_Det_Mov34 of type COM_DT_FR_RDR_Det_Mov34
 *   FR_RDR_Det_Mov35 of type COM_DT_FR_RDR_Det_Mov35
 *   FR_RDR_Det_Mov36 of type COM_DT_FR_RDR_Det_Mov36
 *   FR_RDR_Det_SNR33 of type COM_DT_FR_RDR_Det_SNR33
 *   FR_RDR_Det_SNR34 of type COM_DT_FR_RDR_Det_SNR34
 *   FR_RDR_Det_SNR35 of type COM_DT_FR_RDR_Det_SNR35
 *   FR_RDR_Det_SNR36 of type COM_DT_FR_RDR_Det_SNR36
 *   FR_RDR_Det_Speed33 of type COM_DT_FR_RDR_Det_Speed33
 *   FR_RDR_Det_Speed34 of type COM_DT_FR_RDR_Det_Speed34
 *   FR_RDR_Det_Speed35 of type COM_DT_FR_RDR_Det_Speed35
 *   FR_RDR_Det_Speed36 of type COM_DT_FR_RDR_Det_Speed36
 *   FR_RDR_Det_TrustA33 of type COM_DT_FR_RDR_Det_TrustA33
 *   FR_RDR_Det_TrustA34 of type COM_DT_FR_RDR_Det_TrustA34
 *   FR_RDR_Det_TrustA35 of type COM_DT_FR_RDR_Det_TrustA35
 *   FR_RDR_Det_TrustA36 of type COM_DT_FR_RDR_Det_TrustA36
 *   FR_RDR_Det_TrustV33 of type COM_DT_FR_RDR_Det_TrustV33
 *   FR_RDR_Det_TrustV34 of type COM_DT_FR_RDR_Det_TrustV34
 *   FR_RDR_Det_TrustV35 of type COM_DT_FR_RDR_Det_TrustV35
 *   FR_RDR_Det_TrustV36 of type COM_DT_FR_RDR_Det_TrustV36
 *   FR_RDR_Det_Valid33 of type COM_DT_FR_RDR_Det_Valid33
 *   FR_RDR_Det_Valid34 of type COM_DT_FR_RDR_Det_Valid34
 *   FR_RDR_Det_Valid35 of type COM_DT_FR_RDR_Det_Valid35
 *   FR_RDR_Det_Valid36 of type COM_DT_FR_RDR_Det_Valid36
 * COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt10Val of type COM_DT_FR_RDR_Det_AlvCnt10Val
 *   FR_RDR_Det_AmbigSpeed37 of type COM_DT_FR_RDR_Det_AmbigSpeed37
 *   FR_RDR_Det_AmbigSpeed38 of type COM_DT_FR_RDR_Det_AmbigSpeed38
 *   FR_RDR_Det_AmbigSpeed39 of type COM_DT_FR_RDR_Det_AmbigSpeed39
 *   FR_RDR_Det_AmbigSpeed40 of type COM_DT_FR_RDR_Det_AmbigSpeed40
 *   FR_RDR_Det_AssignTag37 of type COM_DT_FR_RDR_Det_AssignTag37
 *   FR_RDR_Det_AssignTag38 of type COM_DT_FR_RDR_Det_AssignTag38
 *   FR_RDR_Det_AssignTag39 of type COM_DT_FR_RDR_Det_AssignTag39
 *   FR_RDR_Det_AssignTag40 of type COM_DT_FR_RDR_Det_AssignTag40
 *   FR_RDR_Det_Attribute37 of type COM_DT_FR_RDR_Det_Attribute37
 *   FR_RDR_Det_Attribute38 of type COM_DT_FR_RDR_Det_Attribute38
 *   FR_RDR_Det_Attribute39 of type COM_DT_FR_RDR_Det_Attribute39
 *   FR_RDR_Det_Attribute40 of type COM_DT_FR_RDR_Det_Attribute40
 *   FR_RDR_Det_ClusterID37 of type COM_DT_FR_RDR_Det_ClusterID37
 *   FR_RDR_Det_ClusterID38 of type COM_DT_FR_RDR_Det_ClusterID38
 *   FR_RDR_Det_ClusterID39 of type COM_DT_FR_RDR_Det_ClusterID39
 *   FR_RDR_Det_ClusterID40 of type COM_DT_FR_RDR_Det_ClusterID40
 *   FR_RDR_Det_CRC10Val of type COM_DT_FR_RDR_Det_CRC10Val
 *   FR_RDR_Det_Height37 of type COM_DT_FR_RDR_Det_Height37
 *   FR_RDR_Det_Height38 of type COM_DT_FR_RDR_Det_Height38
 *   FR_RDR_Det_Height39 of type COM_DT_FR_RDR_Det_Height39
 *   FR_RDR_Det_Height40 of type COM_DT_FR_RDR_Det_Height40
 *   FR_RDR_Det_Lat37 of type COM_DT_FR_RDR_Det_Lat37
 *   FR_RDR_Det_Lat38 of type COM_DT_FR_RDR_Det_Lat38
 *   FR_RDR_Det_Lat39 of type COM_DT_FR_RDR_Det_Lat39
 *   FR_RDR_Det_Lat40 of type COM_DT_FR_RDR_Det_Lat40
 *   FR_RDR_Det_Long37 of type COM_DT_FR_RDR_Det_Long37
 *   FR_RDR_Det_Long38 of type COM_DT_FR_RDR_Det_Long38
 *   FR_RDR_Det_Long39 of type COM_DT_FR_RDR_Det_Long39
 *   FR_RDR_Det_Long40 of type COM_DT_FR_RDR_Det_Long40
 *   FR_RDR_Det_Mov37 of type COM_DT_FR_RDR_Det_Mov37
 *   FR_RDR_Det_Mov38 of type COM_DT_FR_RDR_Det_Mov38
 *   FR_RDR_Det_Mov39 of type COM_DT_FR_RDR_Det_Mov39
 *   FR_RDR_Det_Mov40 of type COM_DT_FR_RDR_Det_Mov40
 *   FR_RDR_Det_SNR37 of type COM_DT_FR_RDR_Det_SNR37
 *   FR_RDR_Det_SNR38 of type COM_DT_FR_RDR_Det_SNR38
 *   FR_RDR_Det_SNR39 of type COM_DT_FR_RDR_Det_SNR39
 *   FR_RDR_Det_SNR40 of type COM_DT_FR_RDR_Det_SNR40
 *   FR_RDR_Det_Speed37 of type COM_DT_FR_RDR_Det_Speed37
 *   FR_RDR_Det_Speed38 of type COM_DT_FR_RDR_Det_Speed38
 *   FR_RDR_Det_Speed39 of type COM_DT_FR_RDR_Det_Speed39
 *   FR_RDR_Det_Speed40 of type COM_DT_FR_RDR_Det_Speed40
 *   FR_RDR_Det_TrustA37 of type COM_DT_FR_RDR_Det_TrustA37
 *   FR_RDR_Det_TrustA38 of type COM_DT_FR_RDR_Det_TrustA38
 *   FR_RDR_Det_TrustA39 of type COM_DT_FR_RDR_Det_TrustA39
 *   FR_RDR_Det_TrustA40 of type COM_DT_FR_RDR_Det_TrustA40
 *   FR_RDR_Det_TrustV37 of type COM_DT_FR_RDR_Det_TrustV37
 *   FR_RDR_Det_TrustV38 of type COM_DT_FR_RDR_Det_TrustV38
 *   FR_RDR_Det_TrustV39 of type COM_DT_FR_RDR_Det_TrustV39
 *   FR_RDR_Det_TrustV40 of type COM_DT_FR_RDR_Det_TrustV40
 *   FR_RDR_Det_Valid37 of type COM_DT_FR_RDR_Det_Valid37
 *   FR_RDR_Det_Valid38 of type COM_DT_FR_RDR_Det_Valid38
 *   FR_RDR_Det_Valid39 of type COM_DT_FR_RDR_Det_Valid39
 *   FR_RDR_Det_Valid40 of type COM_DT_FR_RDR_Det_Valid40
 * COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt11Val of type COM_DT_FR_RDR_Det_AlvCnt11Val
 *   FR_RDR_Det_AmbigSpeed41 of type COM_DT_FR_RDR_Det_AmbigSpeed41
 *   FR_RDR_Det_AmbigSpeed42 of type COM_DT_FR_RDR_Det_AmbigSpeed42
 *   FR_RDR_Det_AmbigSpeed43 of type COM_DT_FR_RDR_Det_AmbigSpeed43
 *   FR_RDR_Det_AmbigSpeed44 of type COM_DT_FR_RDR_Det_AmbigSpeed44
 *   FR_RDR_Det_AssignTag41 of type COM_DT_FR_RDR_Det_AssignTag41
 *   FR_RDR_Det_AssignTag42 of type COM_DT_FR_RDR_Det_AssignTag42
 *   FR_RDR_Det_AssignTag43 of type COM_DT_FR_RDR_Det_AssignTag43
 *   FR_RDR_Det_AssignTag44 of type COM_DT_FR_RDR_Det_AssignTag44
 *   FR_RDR_Det_Attribute41 of type COM_DT_FR_RDR_Det_Attribute41
 *   FR_RDR_Det_Attribute42 of type COM_DT_FR_RDR_Det_Attribute42
 *   FR_RDR_Det_Attribute43 of type COM_DT_FR_RDR_Det_Attribute43
 *   FR_RDR_Det_Attribute44 of type COM_DT_FR_RDR_Det_Attribute44
 *   FR_RDR_Det_ClusterID41 of type COM_DT_FR_RDR_Det_ClusterID41
 *   FR_RDR_Det_ClusterID42 of type COM_DT_FR_RDR_Det_ClusterID42
 *   FR_RDR_Det_ClusterID43 of type COM_DT_FR_RDR_Det_ClusterID43
 *   FR_RDR_Det_ClusterID44 of type COM_DT_FR_RDR_Det_ClusterID44
 *   FR_RDR_Det_CRC11Val of type COM_DT_FR_RDR_Det_CRC11Val
 *   FR_RDR_Det_Height41 of type COM_DT_FR_RDR_Det_Height41
 *   FR_RDR_Det_Height42 of type COM_DT_FR_RDR_Det_Height42
 *   FR_RDR_Det_Height43 of type COM_DT_FR_RDR_Det_Height43
 *   FR_RDR_Det_Height44 of type COM_DT_FR_RDR_Det_Height44
 *   FR_RDR_Det_Lat41 of type COM_DT_FR_RDR_Det_Lat41
 *   FR_RDR_Det_Lat42 of type COM_DT_FR_RDR_Det_Lat42
 *   FR_RDR_Det_Lat43 of type COM_DT_FR_RDR_Det_Lat43
 *   FR_RDR_Det_Lat44 of type COM_DT_FR_RDR_Det_Lat44
 *   FR_RDR_Det_Long41 of type COM_DT_FR_RDR_Det_Long41
 *   FR_RDR_Det_Long42 of type COM_DT_FR_RDR_Det_Long42
 *   FR_RDR_Det_Long43 of type COM_DT_FR_RDR_Det_Long43
 *   FR_RDR_Det_Long44 of type COM_DT_FR_RDR_Det_Long44
 *   FR_RDR_Det_Mov41 of type COM_DT_FR_RDR_Det_Mov41
 *   FR_RDR_Det_Mov42 of type COM_DT_FR_RDR_Det_Mov42
 *   FR_RDR_Det_Mov43 of type COM_DT_FR_RDR_Det_Mov43
 *   FR_RDR_Det_Mov44 of type COM_DT_FR_RDR_Det_Mov44
 *   FR_RDR_Det_SNR41 of type COM_DT_FR_RDR_Det_SNR41
 *   FR_RDR_Det_SNR42 of type COM_DT_FR_RDR_Det_SNR42
 *   FR_RDR_Det_SNR43 of type COM_DT_FR_RDR_Det_SNR43
 *   FR_RDR_Det_SNR44 of type COM_DT_FR_RDR_Det_SNR44
 *   FR_RDR_Det_Speed41 of type COM_DT_FR_RDR_Det_Speed41
 *   FR_RDR_Det_Speed42 of type COM_DT_FR_RDR_Det_Speed42
 *   FR_RDR_Det_Speed43 of type COM_DT_FR_RDR_Det_Speed43
 *   FR_RDR_Det_Speed44 of type COM_DT_FR_RDR_Det_Speed44
 *   FR_RDR_Det_TrustA41 of type COM_DT_FR_RDR_Det_TrustA41
 *   FR_RDR_Det_TrustA42 of type COM_DT_FR_RDR_Det_TrustA42
 *   FR_RDR_Det_TrustA43 of type COM_DT_FR_RDR_Det_TrustA43
 *   FR_RDR_Det_TrustA44 of type COM_DT_FR_RDR_Det_TrustA44
 *   FR_RDR_Det_TrustV41 of type COM_DT_FR_RDR_Det_TrustV41
 *   FR_RDR_Det_TrustV42 of type COM_DT_FR_RDR_Det_TrustV42
 *   FR_RDR_Det_TrustV43 of type COM_DT_FR_RDR_Det_TrustV43
 *   FR_RDR_Det_TrustV44 of type COM_DT_FR_RDR_Det_TrustV44
 *   FR_RDR_Det_Valid41 of type COM_DT_FR_RDR_Det_Valid41
 *   FR_RDR_Det_Valid42 of type COM_DT_FR_RDR_Det_Valid42
 *   FR_RDR_Det_Valid43 of type COM_DT_FR_RDR_Det_Valid43
 *   FR_RDR_Det_Valid44 of type COM_DT_FR_RDR_Det_Valid44
 * COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt12Val of type COM_DT_FR_RDR_Det_AlvCnt12Val
 *   FR_RDR_Det_AmbigSpeed45 of type COM_DT_FR_RDR_Det_AmbigSpeed45
 *   FR_RDR_Det_AmbigSpeed46 of type COM_DT_FR_RDR_Det_AmbigSpeed46
 *   FR_RDR_Det_AmbigSpeed47 of type COM_DT_FR_RDR_Det_AmbigSpeed47
 *   FR_RDR_Det_AmbigSpeed48 of type COM_DT_FR_RDR_Det_AmbigSpeed48
 *   FR_RDR_Det_AssignTag45 of type COM_DT_FR_RDR_Det_AssignTag45
 *   FR_RDR_Det_AssignTag46 of type COM_DT_FR_RDR_Det_AssignTag46
 *   FR_RDR_Det_AssignTag47 of type COM_DT_FR_RDR_Det_AssignTag47
 *   FR_RDR_Det_AssignTag48 of type COM_DT_FR_RDR_Det_AssignTag48
 *   FR_RDR_Det_Attribute45 of type COM_DT_FR_RDR_Det_Attribute45
 *   FR_RDR_Det_Attribute46 of type COM_DT_FR_RDR_Det_Attribute46
 *   FR_RDR_Det_Attribute47 of type COM_DT_FR_RDR_Det_Attribute47
 *   FR_RDR_Det_Attribute48 of type COM_DT_FR_RDR_Det_Attribute48
 *   FR_RDR_Det_ClusterID45 of type COM_DT_FR_RDR_Det_ClusterID45
 *   FR_RDR_Det_ClusterID46 of type COM_DT_FR_RDR_Det_ClusterID46
 *   FR_RDR_Det_ClusterID47 of type COM_DT_FR_RDR_Det_ClusterID47
 *   FR_RDR_Det_ClusterID48 of type COM_DT_FR_RDR_Det_ClusterID48
 *   FR_RDR_Det_CRC12Val of type COM_DT_FR_RDR_Det_CRC12Val
 *   FR_RDR_Det_Height45 of type COM_DT_FR_RDR_Det_Height45
 *   FR_RDR_Det_Height46 of type COM_DT_FR_RDR_Det_Height46
 *   FR_RDR_Det_Height47 of type COM_DT_FR_RDR_Det_Height47
 *   FR_RDR_Det_Height48 of type COM_DT_FR_RDR_Det_Height48
 *   FR_RDR_Det_Lat45 of type COM_DT_FR_RDR_Det_Lat45
 *   FR_RDR_Det_Lat46 of type COM_DT_FR_RDR_Det_Lat46
 *   FR_RDR_Det_Lat47 of type COM_DT_FR_RDR_Det_Lat47
 *   FR_RDR_Det_Lat48 of type COM_DT_FR_RDR_Det_Lat48
 *   FR_RDR_Det_Long45 of type COM_DT_FR_RDR_Det_Long45
 *   FR_RDR_Det_Long46 of type COM_DT_FR_RDR_Det_Long46
 *   FR_RDR_Det_Long47 of type COM_DT_FR_RDR_Det_Long47
 *   FR_RDR_Det_Long48 of type COM_DT_FR_RDR_Det_Long48
 *   FR_RDR_Det_Mov45 of type COM_DT_FR_RDR_Det_Mov45
 *   FR_RDR_Det_Mov46 of type COM_DT_FR_RDR_Det_Mov46
 *   FR_RDR_Det_Mov47 of type COM_DT_FR_RDR_Det_Mov47
 *   FR_RDR_Det_Mov48 of type COM_DT_FR_RDR_Det_Mov48
 *   FR_RDR_Det_SNR45 of type COM_DT_FR_RDR_Det_SNR45
 *   FR_RDR_Det_SNR46 of type COM_DT_FR_RDR_Det_SNR46
 *   FR_RDR_Det_SNR47 of type COM_DT_FR_RDR_Det_SNR47
 *   FR_RDR_Det_SNR48 of type COM_DT_FR_RDR_Det_SNR48
 *   FR_RDR_Det_Speed45 of type COM_DT_FR_RDR_Det_Speed45
 *   FR_RDR_Det_Speed46 of type COM_DT_FR_RDR_Det_Speed46
 *   FR_RDR_Det_Speed47 of type COM_DT_FR_RDR_Det_Speed47
 *   FR_RDR_Det_Speed48 of type COM_DT_FR_RDR_Det_Speed48
 *   FR_RDR_Det_TrustA45 of type COM_DT_FR_RDR_Det_TrustA45
 *   FR_RDR_Det_TrustA46 of type COM_DT_FR_RDR_Det_TrustA46
 *   FR_RDR_Det_TrustA47 of type COM_DT_FR_RDR_Det_TrustA47
 *   FR_RDR_Det_TrustA48 of type COM_DT_FR_RDR_Det_TrustA48
 *   FR_RDR_Det_TrustV45 of type COM_DT_FR_RDR_Det_TrustV45
 *   FR_RDR_Det_TrustV46 of type COM_DT_FR_RDR_Det_TrustV46
 *   FR_RDR_Det_TrustV47 of type COM_DT_FR_RDR_Det_TrustV47
 *   FR_RDR_Det_TrustV48 of type COM_DT_FR_RDR_Det_TrustV48
 *   FR_RDR_Det_Valid45 of type COM_DT_FR_RDR_Det_Valid45
 *   FR_RDR_Det_Valid46 of type COM_DT_FR_RDR_Det_Valid46
 *   FR_RDR_Det_Valid47 of type COM_DT_FR_RDR_Det_Valid47
 *   FR_RDR_Det_Valid48 of type COM_DT_FR_RDR_Det_Valid48
 * COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt13Val of type COM_DT_FR_RDR_Det_AlvCnt13Val
 *   FR_RDR_Det_AmbigSpeed49 of type COM_DT_FR_RDR_Det_AmbigSpeed49
 *   FR_RDR_Det_AmbigSpeed50 of type COM_DT_FR_RDR_Det_AmbigSpeed50
 *   FR_RDR_Det_AmbigSpeed51 of type COM_DT_FR_RDR_Det_AmbigSpeed51
 *   FR_RDR_Det_AmbigSpeed52 of type COM_DT_FR_RDR_Det_AmbigSpeed52
 *   FR_RDR_Det_AssignTag49 of type COM_DT_FR_RDR_Det_AssignTag49
 *   FR_RDR_Det_AssignTag50 of type COM_DT_FR_RDR_Det_AssignTag50
 *   FR_RDR_Det_AssignTag51 of type COM_DT_FR_RDR_Det_AssignTag51
 *   FR_RDR_Det_AssignTag52 of type COM_DT_FR_RDR_Det_AssignTag52
 *   FR_RDR_Det_Attribute49 of type COM_DT_FR_RDR_Det_Attribute49
 *   FR_RDR_Det_Attribute50 of type COM_DT_FR_RDR_Det_Attribute50
 *   FR_RDR_Det_Attribute51 of type COM_DT_FR_RDR_Det_Attribute51
 *   FR_RDR_Det_Attribute52 of type COM_DT_FR_RDR_Det_Attribute52
 *   FR_RDR_Det_ClusterID49 of type COM_DT_FR_RDR_Det_ClusterID49
 *   FR_RDR_Det_ClusterID50 of type COM_DT_FR_RDR_Det_ClusterID50
 *   FR_RDR_Det_ClusterID51 of type COM_DT_FR_RDR_Det_ClusterID51
 *   FR_RDR_Det_ClusterID52 of type COM_DT_FR_RDR_Det_ClusterID52
 *   FR_RDR_Det_CRC13Val of type COM_DT_FR_RDR_Det_CRC13Val
 *   FR_RDR_Det_Height49 of type COM_DT_FR_RDR_Det_Height49
 *   FR_RDR_Det_Height50 of type COM_DT_FR_RDR_Det_Height50
 *   FR_RDR_Det_Height51 of type COM_DT_FR_RDR_Det_Height51
 *   FR_RDR_Det_Height52 of type COM_DT_FR_RDR_Det_Height52
 *   FR_RDR_Det_Lat49 of type COM_DT_FR_RDR_Det_Lat49
 *   FR_RDR_Det_Lat50 of type COM_DT_FR_RDR_Det_Lat50
 *   FR_RDR_Det_Lat51 of type COM_DT_FR_RDR_Det_Lat51
 *   FR_RDR_Det_Lat52 of type COM_DT_FR_RDR_Det_Lat52
 *   FR_RDR_Det_Long49 of type COM_DT_FR_RDR_Det_Long49
 *   FR_RDR_Det_Long50 of type COM_DT_FR_RDR_Det_Long50
 *   FR_RDR_Det_Long51 of type COM_DT_FR_RDR_Det_Long51
 *   FR_RDR_Det_Long52 of type COM_DT_FR_RDR_Det_Long52
 *   FR_RDR_Det_Mov49 of type COM_DT_FR_RDR_Det_Mov49
 *   FR_RDR_Det_Mov50 of type COM_DT_FR_RDR_Det_Mov50
 *   FR_RDR_Det_Mov51 of type COM_DT_FR_RDR_Det_Mov51
 *   FR_RDR_Det_Mov52 of type COM_DT_FR_RDR_Det_Mov52
 *   FR_RDR_Det_SNR49 of type COM_DT_FR_RDR_Det_SNR49
 *   FR_RDR_Det_SNR50 of type COM_DT_FR_RDR_Det_SNR50
 *   FR_RDR_Det_SNR51 of type COM_DT_FR_RDR_Det_SNR51
 *   FR_RDR_Det_SNR52 of type COM_DT_FR_RDR_Det_SNR52
 *   FR_RDR_Det_Speed49 of type COM_DT_FR_RDR_Det_Speed49
 *   FR_RDR_Det_Speed50 of type COM_DT_FR_RDR_Det_Speed50
 *   FR_RDR_Det_Speed51 of type COM_DT_FR_RDR_Det_Speed51
 *   FR_RDR_Det_Speed52 of type COM_DT_FR_RDR_Det_Speed52
 *   FR_RDR_Det_TrustA49 of type COM_DT_FR_RDR_Det_TrustA49
 *   FR_RDR_Det_TrustA50 of type COM_DT_FR_RDR_Det_TrustA50
 *   FR_RDR_Det_TrustA51 of type COM_DT_FR_RDR_Det_TrustA51
 *   FR_RDR_Det_TrustA52 of type COM_DT_FR_RDR_Det_TrustA52
 *   FR_RDR_Det_TrustV49 of type COM_DT_FR_RDR_Det_TrustV49
 *   FR_RDR_Det_TrustV50 of type COM_DT_FR_RDR_Det_TrustV50
 *   FR_RDR_Det_TrustV51 of type COM_DT_FR_RDR_Det_TrustV51
 *   FR_RDR_Det_TrustV52 of type COM_DT_FR_RDR_Det_TrustV52
 *   FR_RDR_Det_Valid49 of type COM_DT_FR_RDR_Det_Valid49
 *   FR_RDR_Det_Valid50 of type COM_DT_FR_RDR_Det_Valid50
 *   FR_RDR_Det_Valid51 of type COM_DT_FR_RDR_Det_Valid51
 *   FR_RDR_Det_Valid52 of type COM_DT_FR_RDR_Det_Valid52
 * COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt14Val of type COM_DT_FR_RDR_Det_AlvCnt14Val
 *   FR_RDR_Det_AmbigSpeed53 of type COM_DT_FR_RDR_Det_AmbigSpeed53
 *   FR_RDR_Det_AmbigSpeed54 of type COM_DT_FR_RDR_Det_AmbigSpeed54
 *   FR_RDR_Det_AmbigSpeed55 of type COM_DT_FR_RDR_Det_AmbigSpeed55
 *   FR_RDR_Det_AmbigSpeed56 of type COM_DT_FR_RDR_Det_AmbigSpeed56
 *   FR_RDR_Det_AssignTag53 of type COM_DT_FR_RDR_Det_AssignTag53
 *   FR_RDR_Det_AssignTag54 of type COM_DT_FR_RDR_Det_AssignTag54
 *   FR_RDR_Det_AssignTag55 of type COM_DT_FR_RDR_Det_AssignTag55
 *   FR_RDR_Det_AssignTag56 of type COM_DT_FR_RDR_Det_AssignTag56
 *   FR_RDR_Det_Attribute53 of type COM_DT_FR_RDR_Det_Attribute53
 *   FR_RDR_Det_Attribute54 of type COM_DT_FR_RDR_Det_Attribute54
 *   FR_RDR_Det_Attribute55 of type COM_DT_FR_RDR_Det_Attribute55
 *   FR_RDR_Det_Attribute56 of type COM_DT_FR_RDR_Det_Attribute56
 *   FR_RDR_Det_ClusterID53 of type COM_DT_FR_RDR_Det_ClusterID53
 *   FR_RDR_Det_ClusterID54 of type COM_DT_FR_RDR_Det_ClusterID54
 *   FR_RDR_Det_ClusterID55 of type COM_DT_FR_RDR_Det_ClusterID55
 *   FR_RDR_Det_ClusterID56 of type COM_DT_FR_RDR_Det_ClusterID56
 *   FR_RDR_Det_CRC14Val of type COM_DT_FR_RDR_Det_CRC14Val
 *   FR_RDR_Det_Height53 of type COM_DT_FR_RDR_Det_Height53
 *   FR_RDR_Det_Height54 of type COM_DT_FR_RDR_Det_Height54
 *   FR_RDR_Det_Height55 of type COM_DT_FR_RDR_Det_Height55
 *   FR_RDR_Det_Height56 of type COM_DT_FR_RDR_Det_Height56
 *   FR_RDR_Det_Lat53 of type COM_DT_FR_RDR_Det_Lat53
 *   FR_RDR_Det_Lat54 of type COM_DT_FR_RDR_Det_Lat54
 *   FR_RDR_Det_Lat55 of type COM_DT_FR_RDR_Det_Lat55
 *   FR_RDR_Det_Lat56 of type COM_DT_FR_RDR_Det_Lat56
 *   FR_RDR_Det_Long53 of type COM_DT_FR_RDR_Det_Long53
 *   FR_RDR_Det_Long54 of type COM_DT_FR_RDR_Det_Long54
 *   FR_RDR_Det_Long55 of type COM_DT_FR_RDR_Det_Long55
 *   FR_RDR_Det_Long56 of type COM_DT_FR_RDR_Det_Long56
 *   FR_RDR_Det_Mov53 of type COM_DT_FR_RDR_Det_Mov53
 *   FR_RDR_Det_Mov54 of type COM_DT_FR_RDR_Det_Mov54
 *   FR_RDR_Det_Mov55 of type COM_DT_FR_RDR_Det_Mov55
 *   FR_RDR_Det_Mov56 of type COM_DT_FR_RDR_Det_Mov56
 *   FR_RDR_Det_SNR53 of type COM_DT_FR_RDR_Det_SNR53
 *   FR_RDR_Det_SNR54 of type COM_DT_FR_RDR_Det_SNR54
 *   FR_RDR_Det_SNR55 of type COM_DT_FR_RDR_Det_SNR55
 *   FR_RDR_Det_SNR56 of type COM_DT_FR_RDR_Det_SNR56
 *   FR_RDR_Det_Speed53 of type COM_DT_FR_RDR_Det_Speed53
 *   FR_RDR_Det_Speed54 of type COM_DT_FR_RDR_Det_Speed54
 *   FR_RDR_Det_Speed55 of type COM_DT_FR_RDR_Det_Speed55
 *   FR_RDR_Det_Speed56 of type COM_DT_FR_RDR_Det_Speed56
 *   FR_RDR_Det_TrustA53 of type COM_DT_FR_RDR_Det_TrustA53
 *   FR_RDR_Det_TrustA54 of type COM_DT_FR_RDR_Det_TrustA54
 *   FR_RDR_Det_TrustA55 of type COM_DT_FR_RDR_Det_TrustA55
 *   FR_RDR_Det_TrustA56 of type COM_DT_FR_RDR_Det_TrustA56
 *   FR_RDR_Det_TrustV53 of type COM_DT_FR_RDR_Det_TrustV53
 *   FR_RDR_Det_TrustV54 of type COM_DT_FR_RDR_Det_TrustV54
 *   FR_RDR_Det_TrustV55 of type COM_DT_FR_RDR_Det_TrustV55
 *   FR_RDR_Det_TrustV56 of type COM_DT_FR_RDR_Det_TrustV56
 *   FR_RDR_Det_Valid53 of type COM_DT_FR_RDR_Det_Valid53
 *   FR_RDR_Det_Valid54 of type COM_DT_FR_RDR_Det_Valid54
 *   FR_RDR_Det_Valid55 of type COM_DT_FR_RDR_Det_Valid55
 *   FR_RDR_Det_Valid56 of type COM_DT_FR_RDR_Det_Valid56
 * COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt15Val of type COM_DT_FR_RDR_Det_AlvCnt15Val
 *   FR_RDR_Det_AmbigSpeed57 of type COM_DT_FR_RDR_Det_AmbigSpeed57
 *   FR_RDR_Det_AmbigSpeed58 of type COM_DT_FR_RDR_Det_AmbigSpeed58
 *   FR_RDR_Det_AmbigSpeed59 of type COM_DT_FR_RDR_Det_AmbigSpeed59
 *   FR_RDR_Det_AmbigSpeed60 of type COM_DT_FR_RDR_Det_AmbigSpeed60
 *   FR_RDR_Det_AssignTag57 of type COM_DT_FR_RDR_Det_AssignTag57
 *   FR_RDR_Det_AssignTag58 of type COM_DT_FR_RDR_Det_AssignTag58
 *   FR_RDR_Det_AssignTag59 of type COM_DT_FR_RDR_Det_AssignTag59
 *   FR_RDR_Det_AssignTag60 of type COM_DT_FR_RDR_Det_AssignTag60
 *   FR_RDR_Det_Attribute57 of type COM_DT_FR_RDR_Det_Attribute57
 *   FR_RDR_Det_Attribute58 of type COM_DT_FR_RDR_Det_Attribute58
 *   FR_RDR_Det_Attribute59 of type COM_DT_FR_RDR_Det_Attribute59
 *   FR_RDR_Det_Attribute60 of type COM_DT_FR_RDR_Det_Attribute60
 *   FR_RDR_Det_ClusterID57 of type COM_DT_FR_RDR_Det_ClusterID57
 *   FR_RDR_Det_ClusterID58 of type COM_DT_FR_RDR_Det_ClusterID58
 *   FR_RDR_Det_ClusterID59 of type COM_DT_FR_RDR_Det_ClusterID59
 *   FR_RDR_Det_ClusterID60 of type COM_DT_FR_RDR_Det_ClusterID60
 *   FR_RDR_Det_CRC15Val of type COM_DT_FR_RDR_Det_CRC15Val
 *   FR_RDR_Det_Height57 of type COM_DT_FR_RDR_Det_Height57
 *   FR_RDR_Det_Height58 of type COM_DT_FR_RDR_Det_Height58
 *   FR_RDR_Det_Height59 of type COM_DT_FR_RDR_Det_Height59
 *   FR_RDR_Det_Height60 of type COM_DT_FR_RDR_Det_Height60
 *   FR_RDR_Det_Lat57 of type COM_DT_FR_RDR_Det_Lat57
 *   FR_RDR_Det_Lat58 of type COM_DT_FR_RDR_Det_Lat58
 *   FR_RDR_Det_Lat59 of type COM_DT_FR_RDR_Det_Lat59
 *   FR_RDR_Det_Lat60 of type COM_DT_FR_RDR_Det_Lat60
 *   FR_RDR_Det_Long57 of type COM_DT_FR_RDR_Det_Long57
 *   FR_RDR_Det_Long58 of type COM_DT_FR_RDR_Det_Long58
 *   FR_RDR_Det_Long59 of type COM_DT_FR_RDR_Det_Long59
 *   FR_RDR_Det_Long60 of type COM_DT_FR_RDR_Det_Long60
 *   FR_RDR_Det_Mov57 of type COM_DT_FR_RDR_Det_Mov57
 *   FR_RDR_Det_Mov58 of type COM_DT_FR_RDR_Det_Mov58
 *   FR_RDR_Det_Mov59 of type COM_DT_FR_RDR_Det_Mov59
 *   FR_RDR_Det_Mov60 of type COM_DT_FR_RDR_Det_Mov60
 *   FR_RDR_Det_SNR57 of type COM_DT_FR_RDR_Det_SNR57
 *   FR_RDR_Det_SNR58 of type COM_DT_FR_RDR_Det_SNR58
 *   FR_RDR_Det_SNR59 of type COM_DT_FR_RDR_Det_SNR59
 *   FR_RDR_Det_SNR60 of type COM_DT_FR_RDR_Det_SNR60
 *   FR_RDR_Det_Speed57 of type COM_DT_FR_RDR_Det_Speed57
 *   FR_RDR_Det_Speed58 of type COM_DT_FR_RDR_Det_Speed58
 *   FR_RDR_Det_Speed59 of type COM_DT_FR_RDR_Det_Speed59
 *   FR_RDR_Det_Speed60 of type COM_DT_FR_RDR_Det_Speed60
 *   FR_RDR_Det_TrustA57 of type COM_DT_FR_RDR_Det_TrustA57
 *   FR_RDR_Det_TrustA58 of type COM_DT_FR_RDR_Det_TrustA58
 *   FR_RDR_Det_TrustA59 of type COM_DT_FR_RDR_Det_TrustA59
 *   FR_RDR_Det_TrustA60 of type COM_DT_FR_RDR_Det_TrustA60
 *   FR_RDR_Det_TrustV57 of type COM_DT_FR_RDR_Det_TrustV57
 *   FR_RDR_Det_TrustV58 of type COM_DT_FR_RDR_Det_TrustV58
 *   FR_RDR_Det_TrustV59 of type COM_DT_FR_RDR_Det_TrustV59
 *   FR_RDR_Det_TrustV60 of type COM_DT_FR_RDR_Det_TrustV60
 *   FR_RDR_Det_Valid57 of type COM_DT_FR_RDR_Det_Valid57
 *   FR_RDR_Det_Valid58 of type COM_DT_FR_RDR_Det_Valid58
 *   FR_RDR_Det_Valid59 of type COM_DT_FR_RDR_Det_Valid59
 *   FR_RDR_Det_Valid60 of type COM_DT_FR_RDR_Det_Valid60
 * COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup: Record with elements
 *   FR_RDR_Det_AlvCnt16Val of type COM_DT_FR_RDR_Det_AlvCnt16Val
 *   FR_RDR_Det_AmbigSpeed61 of type COM_DT_FR_RDR_Det_AmbigSpeed61
 *   FR_RDR_Det_AmbigSpeed62 of type COM_DT_FR_RDR_Det_AmbigSpeed62
 *   FR_RDR_Det_AmbigSpeed63 of type COM_DT_FR_RDR_Det_AmbigSpeed63
 *   FR_RDR_Det_AmbigSpeed64 of type COM_DT_FR_RDR_Det_AmbigSpeed64
 *   FR_RDR_Det_AssignTag61 of type COM_DT_FR_RDR_Det_AssignTag61
 *   FR_RDR_Det_AssignTag62 of type COM_DT_FR_RDR_Det_AssignTag62
 *   FR_RDR_Det_AssignTag63 of type COM_DT_FR_RDR_Det_AssignTag63
 *   FR_RDR_Det_AssignTag64 of type COM_DT_FR_RDR_Det_AssignTag64
 *   FR_RDR_Det_Attribute61 of type COM_DT_FR_RDR_Det_Attribute61
 *   FR_RDR_Det_Attribute62 of type COM_DT_FR_RDR_Det_Attribute62
 *   FR_RDR_Det_Attribute63 of type COM_DT_FR_RDR_Det_Attribute63
 *   FR_RDR_Det_Attribute64 of type COM_DT_FR_RDR_Det_Attribute64
 *   FR_RDR_Det_ClusterID61 of type COM_DT_FR_RDR_Det_ClusterID61
 *   FR_RDR_Det_ClusterID62 of type COM_DT_FR_RDR_Det_ClusterID62
 *   FR_RDR_Det_ClusterID63 of type COM_DT_FR_RDR_Det_ClusterID63
 *   FR_RDR_Det_ClusterID64 of type COM_DT_FR_RDR_Det_ClusterID64
 *   FR_RDR_Det_CRC16Val of type COM_DT_FR_RDR_Det_CRC16Val
 *   FR_RDR_Det_Height61 of type COM_DT_FR_RDR_Det_Height61
 *   FR_RDR_Det_Height62 of type COM_DT_FR_RDR_Det_Height62
 *   FR_RDR_Det_Height63 of type COM_DT_FR_RDR_Det_Height63
 *   FR_RDR_Det_Height64 of type COM_DT_FR_RDR_Det_Height64
 *   FR_RDR_Det_Lat61 of type COM_DT_FR_RDR_Det_Lat61
 *   FR_RDR_Det_Lat62 of type COM_DT_FR_RDR_Det_Lat62
 *   FR_RDR_Det_Lat63 of type COM_DT_FR_RDR_Det_Lat63
 *   FR_RDR_Det_Lat64 of type COM_DT_FR_RDR_Det_Lat64
 *   FR_RDR_Det_Long61 of type COM_DT_FR_RDR_Det_Long61
 *   FR_RDR_Det_Long62 of type COM_DT_FR_RDR_Det_Long62
 *   FR_RDR_Det_Long63 of type COM_DT_FR_RDR_Det_Long63
 *   FR_RDR_Det_Long64 of type COM_DT_FR_RDR_Det_Long64
 *   FR_RDR_Det_Mov61 of type COM_DT_FR_RDR_Det_Mov61
 *   FR_RDR_Det_Mov62 of type COM_DT_FR_RDR_Det_Mov62
 *   FR_RDR_Det_Mov63 of type COM_DT_FR_RDR_Det_Mov63
 *   FR_RDR_Det_Mov64 of type COM_DT_FR_RDR_Det_Mov64
 *   FR_RDR_Det_SNR61 of type COM_DT_FR_RDR_Det_SNR61
 *   FR_RDR_Det_SNR62 of type COM_DT_FR_RDR_Det_SNR62
 *   FR_RDR_Det_SNR63 of type COM_DT_FR_RDR_Det_SNR63
 *   FR_RDR_Det_SNR64 of type COM_DT_FR_RDR_Det_SNR64
 *   FR_RDR_Det_Speed61 of type COM_DT_FR_RDR_Det_Speed61
 *   FR_RDR_Det_Speed62 of type COM_DT_FR_RDR_Det_Speed62
 *   FR_RDR_Det_Speed63 of type COM_DT_FR_RDR_Det_Speed63
 *   FR_RDR_Det_Speed64 of type COM_DT_FR_RDR_Det_Speed64
 *   FR_RDR_Det_TrustA61 of type COM_DT_FR_RDR_Det_TrustA61
 *   FR_RDR_Det_TrustA62 of type COM_DT_FR_RDR_Det_TrustA62
 *   FR_RDR_Det_TrustA63 of type COM_DT_FR_RDR_Det_TrustA63
 *   FR_RDR_Det_TrustA64 of type COM_DT_FR_RDR_Det_TrustA64
 *   FR_RDR_Det_TrustV61 of type COM_DT_FR_RDR_Det_TrustV61
 *   FR_RDR_Det_TrustV62 of type COM_DT_FR_RDR_Det_TrustV62
 *   FR_RDR_Det_TrustV63 of type COM_DT_FR_RDR_Det_TrustV63
 *   FR_RDR_Det_TrustV64 of type COM_DT_FR_RDR_Det_TrustV64
 *   FR_RDR_Det_Valid61 of type COM_DT_FR_RDR_Det_Valid61
 *   FR_RDR_Det_Valid62 of type COM_DT_FR_RDR_Det_Valid62
 *   FR_RDR_Det_Valid63 of type COM_DT_FR_RDR_Det_Valid63
 *   FR_RDR_Det_Valid64 of type COM_DT_FR_RDR_Det_Valid64
 * COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge01Val of type COM_DT_FR_RDR_Obj_AlvAge01Val
 *   FR_RDR_Obj_AlvAge02Val of type COM_DT_FR_RDR_Obj_AlvAge02Val
 *   FR_RDR_Obj_AlvCnt01Val of type COM_DT_FR_RDR_Obj_AlvCnt01Val
 *   FR_RDR_Obj_CoastAge01Val of type COM_DT_FR_RDR_Obj_CoastAge01Val
 *   FR_RDR_Obj_CoastAge02Val of type COM_DT_FR_RDR_Obj_CoastAge02Val
 *   FR_RDR_Obj_CRC01Val of type COM_DT_FR_RDR_Obj_CRC01Val
 *   FR_RDR_Obj_MedRangeMod01Val of type COM_DT_FR_RDR_Obj_MedRangeMod01Val
 *   FR_RDR_Obj_MedRangeMod02Val of type COM_DT_FR_RDR_Obj_MedRangeMod02Val
 *   FR_RDR_Obj_MvngFlag01Sta of type COM_DT_FR_RDR_Obj_MvngFlag01Sta
 *   FR_RDR_Obj_MvngFlag02Sta of type COM_DT_FR_RDR_Obj_MvngFlag02Sta
 *   FR_RDR_Obj_QualLvl01Sta of type COM_DT_FR_RDR_Obj_QualLvl01Sta
 *   FR_RDR_Obj_QualLvl02Sta of type COM_DT_FR_RDR_Obj_QualLvl02Sta
 *   FR_RDR_Obj_RefObjID01Val of type COM_DT_FR_RDR_Obj_RefObjID01Val
 *   FR_RDR_Obj_RefObjID02Val of type COM_DT_FR_RDR_Obj_RefObjID02Val
 *   FR_RDR_Obj_RelAccelX01Val of type COM_DT_FR_RDR_Obj_RelAccelX01Val
 *   FR_RDR_Obj_RelAccelX02Val of type COM_DT_FR_RDR_Obj_RelAccelX02Val
 *   FR_RDR_Obj_RelPosX01Val of type COM_DT_FR_RDR_Obj_RelPosX01Val
 *   FR_RDR_Obj_RelPosX02Val of type COM_DT_FR_RDR_Obj_RelPosX02Val
 *   FR_RDR_Obj_RelPosY01Val of type COM_DT_FR_RDR_Obj_RelPosY01Val
 *   FR_RDR_Obj_RelPosY02Val of type COM_DT_FR_RDR_Obj_RelPosY02Val
 *   FR_RDR_Obj_RelVelX01Val of type COM_DT_FR_RDR_Obj_RelVelX01Val
 *   FR_RDR_Obj_RelVelX02Val of type COM_DT_FR_RDR_Obj_RelVelX02Val
 *   FR_RDR_Obj_RelVelY01Val of type COM_DT_FR_RDR_Obj_RelVelY01Val
 *   FR_RDR_Obj_RelVelY02Val of type COM_DT_FR_RDR_Obj_RelVelY02Val
 *   FR_RDR_Obj_TrkSta01Sta of type COM_DT_FR_RDR_Obj_TrkSta01Sta
 *   FR_RDR_Obj_TrkSta02Sta of type COM_DT_FR_RDR_Obj_TrkSta02Sta
 * COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge03Val of type COM_DT_FR_RDR_Obj_AlvAge03Val
 *   FR_RDR_Obj_AlvAge04Val of type COM_DT_FR_RDR_Obj_AlvAge04Val
 *   FR_RDR_Obj_AlvCnt02Val of type COM_DT_FR_RDR_Obj_AlvCnt02Val
 *   FR_RDR_Obj_CoastAge03Val of type COM_DT_FR_RDR_Obj_CoastAge03Val
 *   FR_RDR_Obj_CoastAge04Val of type COM_DT_FR_RDR_Obj_CoastAge04Val
 *   FR_RDR_Obj_CRC02Val of type COM_DT_FR_RDR_Obj_CRC02Val
 *   FR_RDR_Obj_MedRangeMod03Val of type COM_DT_FR_RDR_Obj_MedRangeMod03Val
 *   FR_RDR_Obj_MedRangeMod04Val of type COM_DT_FR_RDR_Obj_MedRangeMod04Val
 *   FR_RDR_Obj_MvngFlag03Sta of type COM_DT_FR_RDR_Obj_MvngFlag03Sta
 *   FR_RDR_Obj_MvngFlag04Sta of type COM_DT_FR_RDR_Obj_MvngFlag04Sta
 *   FR_RDR_Obj_QualLvl03Sta of type COM_DT_FR_RDR_Obj_QualLvl03Sta
 *   FR_RDR_Obj_QualLvl04Sta of type COM_DT_FR_RDR_Obj_QualLvl04Sta
 *   FR_RDR_Obj_RefObjID03Val of type COM_DT_FR_RDR_Obj_RefObjID03Val
 *   FR_RDR_Obj_RefObjID04Val of type COM_DT_FR_RDR_Obj_RefObjID04Val
 *   FR_RDR_Obj_RelAccelX03Val of type COM_DT_FR_RDR_Obj_RelAccelX03Val
 *   FR_RDR_Obj_RelAccelX04Val of type COM_DT_FR_RDR_Obj_RelAccelX04Val
 *   FR_RDR_Obj_RelPosX03Val of type COM_DT_FR_RDR_Obj_RelPosX03Val
 *   FR_RDR_Obj_RelPosX04Val of type COM_DT_FR_RDR_Obj_RelPosX04Val
 *   FR_RDR_Obj_RelPosY03Val of type COM_DT_FR_RDR_Obj_RelPosY03Val
 *   FR_RDR_Obj_RelPosY04Val of type COM_DT_FR_RDR_Obj_RelPosY04Val
 *   FR_RDR_Obj_RelVelX03Val of type COM_DT_FR_RDR_Obj_RelVelX03Val
 *   FR_RDR_Obj_RelVelX04Val of type COM_DT_FR_RDR_Obj_RelVelX04Val
 *   FR_RDR_Obj_RelVelY03Val of type COM_DT_FR_RDR_Obj_RelVelY03Val
 *   FR_RDR_Obj_RelVelY04Val of type COM_DT_FR_RDR_Obj_RelVelY04Val
 *   FR_RDR_Obj_TrkSta03Sta of type COM_DT_FR_RDR_Obj_TrkSta03Sta
 *   FR_RDR_Obj_TrkSta04Sta of type COM_DT_FR_RDR_Obj_TrkSta04Sta
 * COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge05Val of type COM_DT_FR_RDR_Obj_AlvAge05Val
 *   FR_RDR_Obj_AlvAge06Val of type COM_DT_FR_RDR_Obj_AlvAge06Val
 *   FR_RDR_Obj_AlvCnt03Val of type COM_DT_FR_RDR_Obj_AlvCnt03Val
 *   FR_RDR_Obj_CoastAge05Val of type COM_DT_FR_RDR_Obj_CoastAge05Val
 *   FR_RDR_Obj_CoastAge06Val of type COM_DT_FR_RDR_Obj_CoastAge06Val
 *   FR_RDR_Obj_CRC03Val of type COM_DT_FR_RDR_Obj_CRC03Val
 *   FR_RDR_Obj_MedRangeMod05Val of type COM_DT_FR_RDR_Obj_MedRangeMod05Val
 *   FR_RDR_Obj_MedRangeMod06Val of type COM_DT_FR_RDR_Obj_MedRangeMod06Val
 *   FR_RDR_Obj_MvngFlag05Sta of type COM_DT_FR_RDR_Obj_MvngFlag05Sta
 *   FR_RDR_Obj_MvngFlag06Sta of type COM_DT_FR_RDR_Obj_MvngFlag06Sta
 *   FR_RDR_Obj_QualLvl05Sta of type COM_DT_FR_RDR_Obj_QualLvl05Sta
 *   FR_RDR_Obj_QualLvl06Sta of type COM_DT_FR_RDR_Obj_QualLvl06Sta
 *   FR_RDR_Obj_RefObjID05Val of type COM_DT_FR_RDR_Obj_RefObjID05Val
 *   FR_RDR_Obj_RefObjID06Val of type COM_DT_FR_RDR_Obj_RefObjID06Val
 *   FR_RDR_Obj_RelAccelX05Val of type COM_DT_FR_RDR_Obj_RelAccelX05Val
 *   FR_RDR_Obj_RelAccelX06Val of type COM_DT_FR_RDR_Obj_RelAccelX06Val
 *   FR_RDR_Obj_RelPosX05Val of type COM_DT_FR_RDR_Obj_RelPosX05Val
 *   FR_RDR_Obj_RelPosX06Val of type COM_DT_FR_RDR_Obj_RelPosX06Val
 *   FR_RDR_Obj_RelPosY05Val of type COM_DT_FR_RDR_Obj_RelPosY05Val
 *   FR_RDR_Obj_RelPosY06Val of type COM_DT_FR_RDR_Obj_RelPosY06Val
 *   FR_RDR_Obj_RelVelX05Val of type COM_DT_FR_RDR_Obj_RelVelX05Val
 *   FR_RDR_Obj_RelVelX06Val of type COM_DT_FR_RDR_Obj_RelVelX06Val
 *   FR_RDR_Obj_RelVelY05Val of type COM_DT_FR_RDR_Obj_RelVelY05Val
 *   FR_RDR_Obj_RelVelY06Val of type COM_DT_FR_RDR_Obj_RelVelY06Val
 *   FR_RDR_Obj_TrkSta05Sta of type COM_DT_FR_RDR_Obj_TrkSta05Sta
 *   FR_RDR_Obj_TrkSta06Sta of type COM_DT_FR_RDR_Obj_TrkSta06Sta
 * COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge07Val of type COM_DT_FR_RDR_Obj_AlvAge07Val
 *   FR_RDR_Obj_AlvAge08Val of type COM_DT_FR_RDR_Obj_AlvAge08Val
 *   FR_RDR_Obj_AlvCnt04Val of type COM_DT_FR_RDR_Obj_AlvCnt04Val
 *   FR_RDR_Obj_CoastAge07Val of type COM_DT_FR_RDR_Obj_CoastAge07Val
 *   FR_RDR_Obj_CoastAge08Val of type COM_DT_FR_RDR_Obj_CoastAge08Val
 *   FR_RDR_Obj_CRC04Val of type COM_DT_FR_RDR_Obj_CRC04Val
 *   FR_RDR_Obj_MedRangeMod07Val of type COM_DT_FR_RDR_Obj_MedRangeMod07Val
 *   FR_RDR_Obj_MedRangeMod08Val of type COM_DT_FR_RDR_Obj_MedRangeMod08Val
 *   FR_RDR_Obj_MvngFlag07Sta of type COM_DT_FR_RDR_Obj_MvngFlag07Sta
 *   FR_RDR_Obj_MvngFlag08Sta of type COM_DT_FR_RDR_Obj_MvngFlag08Sta
 *   FR_RDR_Obj_QualLvl07Sta of type COM_DT_FR_RDR_Obj_QualLvl07Sta
 *   FR_RDR_Obj_QualLvl08Sta of type COM_DT_FR_RDR_Obj_QualLvl08Sta
 *   FR_RDR_Obj_RefObjID07Val of type COM_DT_FR_RDR_Obj_RefObjID07Val
 *   FR_RDR_Obj_RefObjID08Val of type COM_DT_FR_RDR_Obj_RefObjID08Val
 *   FR_RDR_Obj_RelAccelX07Val of type COM_DT_FR_RDR_Obj_RelAccelX07Val
 *   FR_RDR_Obj_RelAccelX08Val of type COM_DT_FR_RDR_Obj_RelAccelX08Val
 *   FR_RDR_Obj_RelPosX07Val of type COM_DT_FR_RDR_Obj_RelPosX07Val
 *   FR_RDR_Obj_RelPosX08Val of type COM_DT_FR_RDR_Obj_RelPosX08Val
 *   FR_RDR_Obj_RelPosY07Val of type COM_DT_FR_RDR_Obj_RelPosY07Val
 *   FR_RDR_Obj_RelPosY08Val of type COM_DT_FR_RDR_Obj_RelPosY08Val
 *   FR_RDR_Obj_RelVelX07Val of type COM_DT_FR_RDR_Obj_RelVelX07Val
 *   FR_RDR_Obj_RelVelX08Val of type COM_DT_FR_RDR_Obj_RelVelX08Val
 *   FR_RDR_Obj_RelVelY07Val of type COM_DT_FR_RDR_Obj_RelVelY07Val
 *   FR_RDR_Obj_RelVelY08Val of type COM_DT_FR_RDR_Obj_RelVelY08Val
 *   FR_RDR_Obj_TrkSta07Sta of type COM_DT_FR_RDR_Obj_TrkSta07Sta
 *   FR_RDR_Obj_TrkSta08Sta of type COM_DT_FR_RDR_Obj_TrkSta08Sta
 * COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge09Val of type COM_DT_FR_RDR_Obj_AlvAge09Val
 *   FR_RDR_Obj_AlvAge10Val of type COM_DT_FR_RDR_Obj_AlvAge10Val
 *   FR_RDR_Obj_AlvCnt05Val of type COM_DT_FR_RDR_Obj_AlvCnt05Val
 *   FR_RDR_Obj_CoastAge09Val of type COM_DT_FR_RDR_Obj_CoastAge09Val
 *   FR_RDR_Obj_CoastAge10Val of type COM_DT_FR_RDR_Obj_CoastAge10Val
 *   FR_RDR_Obj_CRC05Val of type COM_DT_FR_RDR_Obj_CRC05Val
 *   FR_RDR_Obj_MedRangeMod09Val of type COM_DT_FR_RDR_Obj_MedRangeMod09Val
 *   FR_RDR_Obj_MedRangeMod10Val of type COM_DT_FR_RDR_Obj_MedRangeMod10Val
 *   FR_RDR_Obj_MvngFlag09Sta of type COM_DT_FR_RDR_Obj_MvngFlag09Sta
 *   FR_RDR_Obj_MvngFlag10Sta of type COM_DT_FR_RDR_Obj_MvngFlag10Sta
 *   FR_RDR_Obj_QualLvl09Sta of type COM_DT_FR_RDR_Obj_QualLvl09Sta
 *   FR_RDR_Obj_QualLvl10Sta of type COM_DT_FR_RDR_Obj_QualLvl10Sta
 *   FR_RDR_Obj_RefObjID09Val of type COM_DT_FR_RDR_Obj_RefObjID09Val
 *   FR_RDR_Obj_RefObjID10Val of type COM_DT_FR_RDR_Obj_RefObjID10Val
 *   FR_RDR_Obj_RelAccelX09Val of type COM_DT_FR_RDR_Obj_RelAccelX09Val
 *   FR_RDR_Obj_RelAccelX10Val of type COM_DT_FR_RDR_Obj_RelAccelX10Val
 *   FR_RDR_Obj_RelPosX09Val of type COM_DT_FR_RDR_Obj_RelPosX09Val
 *   FR_RDR_Obj_RelPosX10Val of type COM_DT_FR_RDR_Obj_RelPosX10Val
 *   FR_RDR_Obj_RelPosY09Val of type COM_DT_FR_RDR_Obj_RelPosY09Val
 *   FR_RDR_Obj_RelPosY10Val of type COM_DT_FR_RDR_Obj_RelPosY10Val
 *   FR_RDR_Obj_RelVelX09Val of type COM_DT_FR_RDR_Obj_RelVelX09Val
 *   FR_RDR_Obj_RelVelX10Val of type COM_DT_FR_RDR_Obj_RelVelX10Val
 *   FR_RDR_Obj_RelVelY09Val of type COM_DT_FR_RDR_Obj_RelVelY09Val
 *   FR_RDR_Obj_RelVelY10Val of type COM_DT_FR_RDR_Obj_RelVelY10Val
 *   FR_RDR_Obj_TrkSta09Sta of type COM_DT_FR_RDR_Obj_TrkSta09Sta
 *   FR_RDR_Obj_TrkSta10Sta of type COM_DT_FR_RDR_Obj_TrkSta10Sta
 * COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge11Val of type COM_DT_FR_RDR_Obj_AlvAge11Val
 *   FR_RDR_Obj_AlvAge12Val of type COM_DT_FR_RDR_Obj_AlvAge12Val
 *   FR_RDR_Obj_AlvCnt06Val of type COM_DT_FR_RDR_Obj_AlvCnt06Val
 *   FR_RDR_Obj_CoastAge11Val of type COM_DT_FR_RDR_Obj_CoastAge11Val
 *   FR_RDR_Obj_CoastAge12Val of type COM_DT_FR_RDR_Obj_CoastAge12Val
 *   FR_RDR_Obj_CRC06Val of type COM_DT_FR_RDR_Obj_CRC06Val
 *   FR_RDR_Obj_MedRangeMod11Val of type COM_DT_FR_RDR_Obj_MedRangeMod11Val
 *   FR_RDR_Obj_MedRangeMod12Val of type COM_DT_FR_RDR_Obj_MedRangeMod12Val
 *   FR_RDR_Obj_MvngFlag11Sta of type COM_DT_FR_RDR_Obj_MvngFlag11Sta
 *   FR_RDR_Obj_MvngFlag12Sta of type COM_DT_FR_RDR_Obj_MvngFlag12Sta
 *   FR_RDR_Obj_QualLvl11Sta of type COM_DT_FR_RDR_Obj_QualLvl11Sta
 *   FR_RDR_Obj_QualLvl12Sta of type COM_DT_FR_RDR_Obj_QualLvl12Sta
 *   FR_RDR_Obj_RefObjID11Val of type COM_DT_FR_RDR_Obj_RefObjID11Val
 *   FR_RDR_Obj_RefObjID12Val of type COM_DT_FR_RDR_Obj_RefObjID12Val
 *   FR_RDR_Obj_RelAccelX11Val of type COM_DT_FR_RDR_Obj_RelAccelX11Val
 *   FR_RDR_Obj_RelAccelX12Val of type COM_DT_FR_RDR_Obj_RelAccelX12Val
 *   FR_RDR_Obj_RelPosX11Val of type COM_DT_FR_RDR_Obj_RelPosX11Val
 *   FR_RDR_Obj_RelPosX12Val of type COM_DT_FR_RDR_Obj_RelPosX12Val
 *   FR_RDR_Obj_RelPosY11Val of type COM_DT_FR_RDR_Obj_RelPosY11Val
 *   FR_RDR_Obj_RelPosY12Val of type COM_DT_FR_RDR_Obj_RelPosY12Val
 *   FR_RDR_Obj_RelVelX11Val of type COM_DT_FR_RDR_Obj_RelVelX11Val
 *   FR_RDR_Obj_RelVelX12Val of type COM_DT_FR_RDR_Obj_RelVelX12Val
 *   FR_RDR_Obj_RelVelY11Val of type COM_DT_FR_RDR_Obj_RelVelY11Val
 *   FR_RDR_Obj_RelVelY12Val of type COM_DT_FR_RDR_Obj_RelVelY12Val
 *   FR_RDR_Obj_TrkSta11Sta of type COM_DT_FR_RDR_Obj_TrkSta11Sta
 *   FR_RDR_Obj_TrkSta12Sta of type COM_DT_FR_RDR_Obj_TrkSta12Sta
 * COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge13Val of type COM_DT_FR_RDR_Obj_AlvAge13Val
 *   FR_RDR_Obj_AlvAge14Val of type COM_DT_FR_RDR_Obj_AlvAge14Val
 *   FR_RDR_Obj_AlvCnt07Val of type COM_DT_FR_RDR_Obj_AlvCnt07Val
 *   FR_RDR_Obj_CoastAge13Val of type COM_DT_FR_RDR_Obj_CoastAge13Val
 *   FR_RDR_Obj_CoastAge14Val of type COM_DT_FR_RDR_Obj_CoastAge14Val
 *   FR_RDR_Obj_CRC07Val of type COM_DT_FR_RDR_Obj_CRC07Val
 *   FR_RDR_Obj_MedRangeMod13Val of type COM_DT_FR_RDR_Obj_MedRangeMod13Val
 *   FR_RDR_Obj_MedRangeMod14Val of type COM_DT_FR_RDR_Obj_MedRangeMod14Val
 *   FR_RDR_Obj_MvngFlag13Sta of type COM_DT_FR_RDR_Obj_MvngFlag13Sta
 *   FR_RDR_Obj_MvngFlag14Sta of type COM_DT_FR_RDR_Obj_MvngFlag14Sta
 *   FR_RDR_Obj_QualLvl13Sta of type COM_DT_FR_RDR_Obj_QualLvl13Sta
 *   FR_RDR_Obj_QualLvl14Sta of type COM_DT_FR_RDR_Obj_QualLvl14Sta
 *   FR_RDR_Obj_RefObjID13Val of type COM_DT_FR_RDR_Obj_RefObjID13Val
 *   FR_RDR_Obj_RefObjID14Val of type COM_DT_FR_RDR_Obj_RefObjID14Val
 *   FR_RDR_Obj_RelAccelX13Val of type COM_DT_FR_RDR_Obj_RelAccelX13Val
 *   FR_RDR_Obj_RelAccelX14Val of type COM_DT_FR_RDR_Obj_RelAccelX14Val
 *   FR_RDR_Obj_RelPosX13Val of type COM_DT_FR_RDR_Obj_RelPosX13Val
 *   FR_RDR_Obj_RelPosX14Val of type COM_DT_FR_RDR_Obj_RelPosX14Val
 *   FR_RDR_Obj_RelPosY13Val of type COM_DT_FR_RDR_Obj_RelPosY13Val
 *   FR_RDR_Obj_RelPosY14Val of type COM_DT_FR_RDR_Obj_RelPosY14Val
 *   FR_RDR_Obj_RelVelX13Val of type COM_DT_FR_RDR_Obj_RelVelX13Val
 *   FR_RDR_Obj_RelVelX14Val of type COM_DT_FR_RDR_Obj_RelVelX14Val
 *   FR_RDR_Obj_RelVelY13Val of type COM_DT_FR_RDR_Obj_RelVelY13Val
 *   FR_RDR_Obj_RelVelY14Val of type COM_DT_FR_RDR_Obj_RelVelY14Val
 *   FR_RDR_Obj_TrkSta13Sta of type COM_DT_FR_RDR_Obj_TrkSta13Sta
 *   FR_RDR_Obj_TrkSta14Sta of type COM_DT_FR_RDR_Obj_TrkSta14Sta
 * COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge15Val of type COM_DT_FR_RDR_Obj_AlvAge15Val
 *   FR_RDR_Obj_AlvAge16Val of type COM_DT_FR_RDR_Obj_AlvAge16Val
 *   FR_RDR_Obj_AlvCnt08Val of type COM_DT_FR_RDR_Obj_AlvCnt08Val
 *   FR_RDR_Obj_CoastAge15Val of type COM_DT_FR_RDR_Obj_CoastAge15Val
 *   FR_RDR_Obj_CoastAge16Val of type COM_DT_FR_RDR_Obj_CoastAge16Val
 *   FR_RDR_Obj_CRC08Val of type COM_DT_FR_RDR_Obj_CRC08Val
 *   FR_RDR_Obj_MedRangeMod15Val of type COM_DT_FR_RDR_Obj_MedRangeMod15Val
 *   FR_RDR_Obj_MedRangeMod16Val of type COM_DT_FR_RDR_Obj_MedRangeMod16Val
 *   FR_RDR_Obj_MvngFlag15Sta of type COM_DT_FR_RDR_Obj_MvngFlag15Sta
 *   FR_RDR_Obj_MvngFlag16Sta of type COM_DT_FR_RDR_Obj_MvngFlag16Sta
 *   FR_RDR_Obj_QualLvl15Sta of type COM_DT_FR_RDR_Obj_QualLvl15Sta
 *   FR_RDR_Obj_QualLvl16Sta of type COM_DT_FR_RDR_Obj_QualLvl16Sta
 *   FR_RDR_Obj_RefObjID15Val of type COM_DT_FR_RDR_Obj_RefObjID15Val
 *   FR_RDR_Obj_RefObjID16Val of type COM_DT_FR_RDR_Obj_RefObjID16Val
 *   FR_RDR_Obj_RelAccelX15Val of type COM_DT_FR_RDR_Obj_RelAccelX15Val
 *   FR_RDR_Obj_RelAccelX16Val of type COM_DT_FR_RDR_Obj_RelAccelX16Val
 *   FR_RDR_Obj_RelPosX15Val of type COM_DT_FR_RDR_Obj_RelPosX15Val
 *   FR_RDR_Obj_RelPosX16Val of type COM_DT_FR_RDR_Obj_RelPosX16Val
 *   FR_RDR_Obj_RelPosY15Val of type COM_DT_FR_RDR_Obj_RelPosY15Val
 *   FR_RDR_Obj_RelPosY16Val of type COM_DT_FR_RDR_Obj_RelPosY16Val
 *   FR_RDR_Obj_RelVelX15Val of type COM_DT_FR_RDR_Obj_RelVelX15Val
 *   FR_RDR_Obj_RelVelX16Val of type COM_DT_FR_RDR_Obj_RelVelX16Val
 *   FR_RDR_Obj_RelVelY15Val of type COM_DT_FR_RDR_Obj_RelVelY15Val
 *   FR_RDR_Obj_RelVelY16Val of type COM_DT_FR_RDR_Obj_RelVelY16Val
 *   FR_RDR_Obj_TrkSta15Sta of type COM_DT_FR_RDR_Obj_TrkSta15Sta
 *   FR_RDR_Obj_TrkSta16Sta of type COM_DT_FR_RDR_Obj_TrkSta16Sta
 * COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge17Val of type COM_DT_FR_RDR_Obj_AlvAge17Val
 *   FR_RDR_Obj_AlvAge18Val of type COM_DT_FR_RDR_Obj_AlvAge18Val
 *   FR_RDR_Obj_AlvCnt09Val of type COM_DT_FR_RDR_Obj_AlvCnt09Val
 *   FR_RDR_Obj_CoastAge17Val of type COM_DT_FR_RDR_Obj_CoastAge17Val
 *   FR_RDR_Obj_CoastAge18Val of type COM_DT_FR_RDR_Obj_CoastAge18Val
 *   FR_RDR_Obj_CRC09Val of type COM_DT_FR_RDR_Obj_CRC09Val
 *   FR_RDR_Obj_MedRangeMod17Val of type COM_DT_FR_RDR_Obj_MedRangeMod17Val
 *   FR_RDR_Obj_MedRangeMod18Val of type COM_DT_FR_RDR_Obj_MedRangeMod18Val
 *   FR_RDR_Obj_MvngFlag17Sta of type COM_DT_FR_RDR_Obj_MvngFlag17Sta
 *   FR_RDR_Obj_MvngFlag18Sta of type COM_DT_FR_RDR_Obj_MvngFlag18Sta
 *   FR_RDR_Obj_QualLvl17Sta of type COM_DT_FR_RDR_Obj_QualLvl17Sta
 *   FR_RDR_Obj_QualLvl18Sta of type COM_DT_FR_RDR_Obj_QualLvl18Sta
 *   FR_RDR_Obj_RefObjID17Val of type COM_DT_FR_RDR_Obj_RefObjID17Val
 *   FR_RDR_Obj_RefObjID18Val of type COM_DT_FR_RDR_Obj_RefObjID18Val
 *   FR_RDR_Obj_RelAccelX17Val of type COM_DT_FR_RDR_Obj_RelAccelX17Val
 *   FR_RDR_Obj_RelAccelX18Val of type COM_DT_FR_RDR_Obj_RelAccelX18Val
 *   FR_RDR_Obj_RelPosX17Val of type COM_DT_FR_RDR_Obj_RelPosX17Val
 *   FR_RDR_Obj_RelPosX18Val of type COM_DT_FR_RDR_Obj_RelPosX18Val
 *   FR_RDR_Obj_RelPosY17Val of type COM_DT_FR_RDR_Obj_RelPosY17Val
 *   FR_RDR_Obj_RelPosY18Val of type COM_DT_FR_RDR_Obj_RelPosY18Val
 *   FR_RDR_Obj_RelVelX17Val of type COM_DT_FR_RDR_Obj_RelVelX17Val
 *   FR_RDR_Obj_RelVelX18Val of type COM_DT_FR_RDR_Obj_RelVelX18Val
 *   FR_RDR_Obj_RelVelY17Val of type COM_DT_FR_RDR_Obj_RelVelY17Val
 *   FR_RDR_Obj_RelVelY18Val of type COM_DT_FR_RDR_Obj_RelVelY18Val
 *   FR_RDR_Obj_TrkSta17Sta of type COM_DT_FR_RDR_Obj_TrkSta17Sta
 *   FR_RDR_Obj_TrkSta18Sta of type COM_DT_FR_RDR_Obj_TrkSta18Sta
 * COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge19Val of type COM_DT_FR_RDR_Obj_AlvAge19Val
 *   FR_RDR_Obj_AlvAge20Val of type COM_DT_FR_RDR_Obj_AlvAge20Val
 *   FR_RDR_Obj_AlvCnt10Val of type COM_DT_FR_RDR_Obj_AlvCnt10Val
 *   FR_RDR_Obj_CoastAge19Val of type COM_DT_FR_RDR_Obj_CoastAge19Val
 *   FR_RDR_Obj_CoastAge20Val of type COM_DT_FR_RDR_Obj_CoastAge20Val
 *   FR_RDR_Obj_CRC10Val of type COM_DT_FR_RDR_Obj_CRC10Val
 *   FR_RDR_Obj_MedRangeMod19Val of type COM_DT_FR_RDR_Obj_MedRangeMod19Val
 *   FR_RDR_Obj_MedRangeMod20Val of type COM_DT_FR_RDR_Obj_MedRangeMod20Val
 *   FR_RDR_Obj_MvngFlag19Sta of type COM_DT_FR_RDR_Obj_MvngFlag19Sta
 *   FR_RDR_Obj_MvngFlag20Sta of type COM_DT_FR_RDR_Obj_MvngFlag20Sta
 *   FR_RDR_Obj_QualLvl19Sta of type COM_DT_FR_RDR_Obj_QualLvl19Sta
 *   FR_RDR_Obj_QualLvl20Sta of type COM_DT_FR_RDR_Obj_QualLvl20Sta
 *   FR_RDR_Obj_RefObjID19Val of type COM_DT_FR_RDR_Obj_RefObjID19Val
 *   FR_RDR_Obj_RefObjID20Val of type COM_DT_FR_RDR_Obj_RefObjID20Val
 *   FR_RDR_Obj_RelAccelX19Val of type COM_DT_FR_RDR_Obj_RelAccelX19Val
 *   FR_RDR_Obj_RelAccelX20Val of type COM_DT_FR_RDR_Obj_RelAccelX20Val
 *   FR_RDR_Obj_RelPosX19Val of type COM_DT_FR_RDR_Obj_RelPosX19Val
 *   FR_RDR_Obj_RelPosX20Val of type COM_DT_FR_RDR_Obj_RelPosX20Val
 *   FR_RDR_Obj_RelPosY19Val of type COM_DT_FR_RDR_Obj_RelPosY19Val
 *   FR_RDR_Obj_RelPosY20Val of type COM_DT_FR_RDR_Obj_RelPosY20Val
 *   FR_RDR_Obj_RelVelX19Val of type COM_DT_FR_RDR_Obj_RelVelX19Val
 *   FR_RDR_Obj_RelVelX20Val of type COM_DT_FR_RDR_Obj_RelVelX20Val
 *   FR_RDR_Obj_RelVelY19Val of type COM_DT_FR_RDR_Obj_RelVelY19Val
 *   FR_RDR_Obj_RelVelY20Val of type COM_DT_FR_RDR_Obj_RelVelY20Val
 *   FR_RDR_Obj_TrkSta19Sta of type COM_DT_FR_RDR_Obj_TrkSta19Sta
 *   FR_RDR_Obj_TrkSta20Sta of type COM_DT_FR_RDR_Obj_TrkSta20Sta
 * COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge21Val of type COM_DT_FR_RDR_Obj_AlvAge21Val
 *   FR_RDR_Obj_AlvAge22Val of type COM_DT_FR_RDR_Obj_AlvAge22Val
 *   FR_RDR_Obj_AlvCnt11Val of type COM_DT_FR_RDR_Obj_AlvCnt11Val
 *   FR_RDR_Obj_CoastAge21Val of type COM_DT_FR_RDR_Obj_CoastAge21Val
 *   FR_RDR_Obj_CoastAge22Val of type COM_DT_FR_RDR_Obj_CoastAge22Val
 *   FR_RDR_Obj_CRC11Val of type COM_DT_FR_RDR_Obj_CRC11Val
 *   FR_RDR_Obj_MedRangeMod21Val of type COM_DT_FR_RDR_Obj_MedRangeMod21Val
 *   FR_RDR_Obj_MedRangeMod22Val of type COM_DT_FR_RDR_Obj_MedRangeMod22Val
 *   FR_RDR_Obj_MvngFlag21Sta of type COM_DT_FR_RDR_Obj_MvngFlag21Sta
 *   FR_RDR_Obj_MvngFlag22Sta of type COM_DT_FR_RDR_Obj_MvngFlag22Sta
 *   FR_RDR_Obj_QualLvl21Sta of type COM_DT_FR_RDR_Obj_QualLvl21Sta
 *   FR_RDR_Obj_QualLvl22Sta of type COM_DT_FR_RDR_Obj_QualLvl22Sta
 *   FR_RDR_Obj_RefObjID21Val of type COM_DT_FR_RDR_Obj_RefObjID21Val
 *   FR_RDR_Obj_RefObjID22Val of type COM_DT_FR_RDR_Obj_RefObjID22Val
 *   FR_RDR_Obj_RelAccelX21Val of type COM_DT_FR_RDR_Obj_RelAccelX21Val
 *   FR_RDR_Obj_RelAccelX22Val of type COM_DT_FR_RDR_Obj_RelAccelX22Val
 *   FR_RDR_Obj_RelPosX21Val of type COM_DT_FR_RDR_Obj_RelPosX21Val
 *   FR_RDR_Obj_RelPosX22Val of type COM_DT_FR_RDR_Obj_RelPosX22Val
 *   FR_RDR_Obj_RelPosY21Val of type COM_DT_FR_RDR_Obj_RelPosY21Val
 *   FR_RDR_Obj_RelPosY22Val of type COM_DT_FR_RDR_Obj_RelPosY22Val
 *   FR_RDR_Obj_RelVelX21Val of type COM_DT_FR_RDR_Obj_RelVelX21Val
 *   FR_RDR_Obj_RelVelX22Val of type COM_DT_FR_RDR_Obj_RelVelX22Val
 *   FR_RDR_Obj_RelVelY21Val of type COM_DT_FR_RDR_Obj_RelVelY21Val
 *   FR_RDR_Obj_RelVelY22Val of type COM_DT_FR_RDR_Obj_RelVelY22Val
 *   FR_RDR_Obj_TrkSta21Sta of type COM_DT_FR_RDR_Obj_TrkSta21Sta
 *   FR_RDR_Obj_TrkSta22Sta of type COM_DT_FR_RDR_Obj_TrkSta22Sta
 * COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge23Val of type COM_DT_FR_RDR_Obj_AlvAge23Val
 *   FR_RDR_Obj_AlvAge24Val of type COM_DT_FR_RDR_Obj_AlvAge24Val
 *   FR_RDR_Obj_AlvCnt12Val of type COM_DT_FR_RDR_Obj_AlvCnt12Val
 *   FR_RDR_Obj_CoastAge23Val of type COM_DT_FR_RDR_Obj_CoastAge23Val
 *   FR_RDR_Obj_CoastAge24Val of type COM_DT_FR_RDR_Obj_CoastAge24Val
 *   FR_RDR_Obj_CRC12Val of type COM_DT_FR_RDR_Obj_CRC12Val
 *   FR_RDR_Obj_MedRangeMod23Val of type COM_DT_FR_RDR_Obj_MedRangeMod23Val
 *   FR_RDR_Obj_MedRangeMod24Val of type COM_DT_FR_RDR_Obj_MedRangeMod24Val
 *   FR_RDR_Obj_MvngFlag23Sta of type COM_DT_FR_RDR_Obj_MvngFlag23Sta
 *   FR_RDR_Obj_MvngFlag24Sta of type COM_DT_FR_RDR_Obj_MvngFlag24Sta
 *   FR_RDR_Obj_QualLvl23Sta of type COM_DT_FR_RDR_Obj_QualLvl23Sta
 *   FR_RDR_Obj_QualLvl24Sta of type COM_DT_FR_RDR_Obj_QualLvl24Sta
 *   FR_RDR_Obj_RefObjID23Val of type COM_DT_FR_RDR_Obj_RefObjID23Val
 *   FR_RDR_Obj_RefObjID24Val of type COM_DT_FR_RDR_Obj_RefObjID24Val
 *   FR_RDR_Obj_RelAccelX23Val of type COM_DT_FR_RDR_Obj_RelAccelX23Val
 *   FR_RDR_Obj_RelAccelX24Val of type COM_DT_FR_RDR_Obj_RelAccelX24Val
 *   FR_RDR_Obj_RelPosX23Val of type COM_DT_FR_RDR_Obj_RelPosX23Val
 *   FR_RDR_Obj_RelPosX24Val of type COM_DT_FR_RDR_Obj_RelPosX24Val
 *   FR_RDR_Obj_RelPosY23Val of type COM_DT_FR_RDR_Obj_RelPosY23Val
 *   FR_RDR_Obj_RelPosY24Val of type COM_DT_FR_RDR_Obj_RelPosY24Val
 *   FR_RDR_Obj_RelVelX23Val of type COM_DT_FR_RDR_Obj_RelVelX23Val
 *   FR_RDR_Obj_RelVelX24Val of type COM_DT_FR_RDR_Obj_RelVelX24Val
 *   FR_RDR_Obj_RelVelY23Val of type COM_DT_FR_RDR_Obj_RelVelY23Val
 *   FR_RDR_Obj_RelVelY24Val of type COM_DT_FR_RDR_Obj_RelVelY24Val
 *   FR_RDR_Obj_TrkSta23Sta of type COM_DT_FR_RDR_Obj_TrkSta23Sta
 *   FR_RDR_Obj_TrkSta24Sta of type COM_DT_FR_RDR_Obj_TrkSta24Sta
 * COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge25Val of type COM_DT_FR_RDR_Obj_AlvAge25Val
 *   FR_RDR_Obj_AlvAge26Val of type COM_DT_FR_RDR_Obj_AlvAge26Val
 *   FR_RDR_Obj_AlvCnt13Val of type COM_DT_FR_RDR_Obj_AlvCnt13Val
 *   FR_RDR_Obj_CoastAge25Val of type COM_DT_FR_RDR_Obj_CoastAge25Val
 *   FR_RDR_Obj_CoastAge26Val of type COM_DT_FR_RDR_Obj_CoastAge26Val
 *   FR_RDR_Obj_CRC13Val of type COM_DT_FR_RDR_Obj_CRC13Val
 *   FR_RDR_Obj_MedRangeMod25Val of type COM_DT_FR_RDR_Obj_MedRangeMod25Val
 *   FR_RDR_Obj_MedRangeMod26Val of type COM_DT_FR_RDR_Obj_MedRangeMod26Val
 *   FR_RDR_Obj_MvngFlag25Sta of type COM_DT_FR_RDR_Obj_MvngFlag25Sta
 *   FR_RDR_Obj_MvngFlag26Sta of type COM_DT_FR_RDR_Obj_MvngFlag26Sta
 *   FR_RDR_Obj_QualLvl25Sta of type COM_DT_FR_RDR_Obj_QualLvl25Sta
 *   FR_RDR_Obj_QualLvl26Sta of type COM_DT_FR_RDR_Obj_QualLvl26Sta
 *   FR_RDR_Obj_RefObjID25Val of type COM_DT_FR_RDR_Obj_RefObjID25Val
 *   FR_RDR_Obj_RefObjID26Val of type COM_DT_FR_RDR_Obj_RefObjID26Val
 *   FR_RDR_Obj_RelAccelX25Val of type COM_DT_FR_RDR_Obj_RelAccelX25Val
 *   FR_RDR_Obj_RelAccelX26Val of type COM_DT_FR_RDR_Obj_RelAccelX26Val
 *   FR_RDR_Obj_RelPosX25Val of type COM_DT_FR_RDR_Obj_RelPosX25Val
 *   FR_RDR_Obj_RelPosX26Val of type COM_DT_FR_RDR_Obj_RelPosX26Val
 *   FR_RDR_Obj_RelPosY25Val of type COM_DT_FR_RDR_Obj_RelPosY25Val
 *   FR_RDR_Obj_RelPosY26Val of type COM_DT_FR_RDR_Obj_RelPosY26Val
 *   FR_RDR_Obj_RelVelX25Val of type COM_DT_FR_RDR_Obj_RelVelX25Val
 *   FR_RDR_Obj_RelVelX26Val of type COM_DT_FR_RDR_Obj_RelVelX26Val
 *   FR_RDR_Obj_RelVelY25Val of type COM_DT_FR_RDR_Obj_RelVelY25Val
 *   FR_RDR_Obj_RelVelY26Val of type COM_DT_FR_RDR_Obj_RelVelY26Val
 *   FR_RDR_Obj_TrkSta25Sta of type COM_DT_FR_RDR_Obj_TrkSta25Sta
 *   FR_RDR_Obj_TrkSta26Sta of type COM_DT_FR_RDR_Obj_TrkSta26Sta
 * COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge27Val of type COM_DT_FR_RDR_Obj_AlvAge27Val
 *   FR_RDR_Obj_AlvAge28Val of type COM_DT_FR_RDR_Obj_AlvAge28Val
 *   FR_RDR_Obj_AlvCnt14Val of type COM_DT_FR_RDR_Obj_AlvCnt14Val
 *   FR_RDR_Obj_CoastAge27Val of type COM_DT_FR_RDR_Obj_CoastAge27Val
 *   FR_RDR_Obj_CoastAge28Val of type COM_DT_FR_RDR_Obj_CoastAge28Val
 *   FR_RDR_Obj_CRC14Val of type COM_DT_FR_RDR_Obj_CRC14Val
 *   FR_RDR_Obj_MedRangeMod27Val of type COM_DT_FR_RDR_Obj_MedRangeMod27Val
 *   FR_RDR_Obj_MedRangeMod28Val of type COM_DT_FR_RDR_Obj_MedRangeMod28Val
 *   FR_RDR_Obj_MvngFlag27Sta of type COM_DT_FR_RDR_Obj_MvngFlag27Sta
 *   FR_RDR_Obj_MvngFlag28Sta of type COM_DT_FR_RDR_Obj_MvngFlag28Sta
 *   FR_RDR_Obj_QualLvl27Sta of type COM_DT_FR_RDR_Obj_QualLvl27Sta
 *   FR_RDR_Obj_QualLvl28Sta of type COM_DT_FR_RDR_Obj_QualLvl28Sta
 *   FR_RDR_Obj_RefObjID27Val of type COM_DT_FR_RDR_Obj_RefObjID27Val
 *   FR_RDR_Obj_RefObjID28Val of type COM_DT_FR_RDR_Obj_RefObjID28Val
 *   FR_RDR_Obj_RelAccelX27Val of type COM_DT_FR_RDR_Obj_RelAccelX27Val
 *   FR_RDR_Obj_RelAccelX28Val of type COM_DT_FR_RDR_Obj_RelAccelX28Val
 *   FR_RDR_Obj_RelPosX27Val of type COM_DT_FR_RDR_Obj_RelPosX27Val
 *   FR_RDR_Obj_RelPosX28Val of type COM_DT_FR_RDR_Obj_RelPosX28Val
 *   FR_RDR_Obj_RelPosY27Val of type COM_DT_FR_RDR_Obj_RelPosY27Val
 *   FR_RDR_Obj_RelPosY28Val of type COM_DT_FR_RDR_Obj_RelPosY28Val
 *   FR_RDR_Obj_RelVelX27Val of type COM_DT_FR_RDR_Obj_RelVelX27Val
 *   FR_RDR_Obj_RelVelX28Val of type COM_DT_FR_RDR_Obj_RelVelX28Val
 *   FR_RDR_Obj_RelVelY27Val of type COM_DT_FR_RDR_Obj_RelVelY27Val
 *   FR_RDR_Obj_RelVelY28Val of type COM_DT_FR_RDR_Obj_RelVelY28Val
 *   FR_RDR_Obj_TrkSta27Sta of type COM_DT_FR_RDR_Obj_TrkSta27Sta
 *   FR_RDR_Obj_TrkSta28Sta of type COM_DT_FR_RDR_Obj_TrkSta28Sta
 * COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge29Val of type COM_DT_FR_RDR_Obj_AlvAge29Val
 *   FR_RDR_Obj_AlvAge30Val of type COM_DT_FR_RDR_Obj_AlvAge30Val
 *   FR_RDR_Obj_AlvCnt15Val of type COM_DT_FR_RDR_Obj_AlvCnt15Val
 *   FR_RDR_Obj_CoastAge29Val of type COM_DT_FR_RDR_Obj_CoastAge29Val
 *   FR_RDR_Obj_CoastAge30Val of type COM_DT_FR_RDR_Obj_CoastAge30Val
 *   FR_RDR_Obj_CRC15Val of type COM_DT_FR_RDR_Obj_CRC15Val
 *   FR_RDR_Obj_MedRangeMod29Val of type COM_DT_FR_RDR_Obj_MedRangeMod29Val
 *   FR_RDR_Obj_MedRangeMod30Val of type COM_DT_FR_RDR_Obj_MedRangeMod30Val
 *   FR_RDR_Obj_MvngFlag29Sta of type COM_DT_FR_RDR_Obj_MvngFlag29Sta
 *   FR_RDR_Obj_MvngFlag30Sta of type COM_DT_FR_RDR_Obj_MvngFlag30Sta
 *   FR_RDR_Obj_QualLvl29Sta of type COM_DT_FR_RDR_Obj_QualLvl29Sta
 *   FR_RDR_Obj_QualLvl30Sta of type COM_DT_FR_RDR_Obj_QualLvl30Sta
 *   FR_RDR_Obj_RefObjID29Val of type COM_DT_FR_RDR_Obj_RefObjID29Val
 *   FR_RDR_Obj_RefObjID30Val of type COM_DT_FR_RDR_Obj_RefObjID30Val
 *   FR_RDR_Obj_RelAccelX29Val of type COM_DT_FR_RDR_Obj_RelAccelX29Val
 *   FR_RDR_Obj_RelAccelX30Val of type COM_DT_FR_RDR_Obj_RelAccelX30Val
 *   FR_RDR_Obj_RelPosX29Val of type COM_DT_FR_RDR_Obj_RelPosX29Val
 *   FR_RDR_Obj_RelPosX30Val of type COM_DT_FR_RDR_Obj_RelPosX30Val
 *   FR_RDR_Obj_RelPosY29Val of type COM_DT_FR_RDR_Obj_RelPosY29Val
 *   FR_RDR_Obj_RelPosY30Val of type COM_DT_FR_RDR_Obj_RelPosY30Val
 *   FR_RDR_Obj_RelVelX29Val of type COM_DT_FR_RDR_Obj_RelVelX29Val
 *   FR_RDR_Obj_RelVelX30Val of type COM_DT_FR_RDR_Obj_RelVelX30Val
 *   FR_RDR_Obj_RelVelY29Val of type COM_DT_FR_RDR_Obj_RelVelY29Val
 *   FR_RDR_Obj_RelVelY30Val of type COM_DT_FR_RDR_Obj_RelVelY30Val
 *   FR_RDR_Obj_TrkSta29Sta of type COM_DT_FR_RDR_Obj_TrkSta29Sta
 *   FR_RDR_Obj_TrkSta30Sta of type COM_DT_FR_RDR_Obj_TrkSta30Sta
 * COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup: Record with elements
 *   FR_RDR_Obj_AlvAge31Val of type COM_DT_FR_RDR_Obj_AlvAge31Val
 *   FR_RDR_Obj_AlvAge32Val of type COM_DT_FR_RDR_Obj_AlvAge32Val
 *   FR_RDR_Obj_AlvCnt16Val of type COM_DT_FR_RDR_Obj_AlvCnt16Val
 *   FR_RDR_Obj_CoastAge31Val of type COM_DT_FR_RDR_Obj_CoastAge31Val
 *   FR_RDR_Obj_CoastAge32Val of type COM_DT_FR_RDR_Obj_CoastAge32Val
 *   FR_RDR_Obj_CRC16Val of type COM_DT_FR_RDR_Obj_CRC16Val
 *   FR_RDR_Obj_MedRangeMod31Val of type COM_DT_FR_RDR_Obj_MedRangeMod31Val
 *   FR_RDR_Obj_MedRangeMod32Val of type COM_DT_FR_RDR_Obj_MedRangeMod32Val
 *   FR_RDR_Obj_MvngFlag31Sta of type COM_DT_FR_RDR_Obj_MvngFlag31Sta
 *   FR_RDR_Obj_MvngFlag32Sta of type COM_DT_FR_RDR_Obj_MvngFlag32Sta
 *   FR_RDR_Obj_QualLvl31Sta of type COM_DT_FR_RDR_Obj_QualLvl31Sta
 *   FR_RDR_Obj_QualLvl32Sta of type COM_DT_FR_RDR_Obj_QualLvl32Sta
 *   FR_RDR_Obj_RefObjID31Val of type COM_DT_FR_RDR_Obj_RefObjID31Val
 *   FR_RDR_Obj_RefObjID32Val of type COM_DT_FR_RDR_Obj_RefObjID32Val
 *   FR_RDR_Obj_RelAccelX31Val of type COM_DT_FR_RDR_Obj_RelAccelX31Val
 *   FR_RDR_Obj_RelAccelX32Val of type COM_DT_FR_RDR_Obj_RelAccelX32Val
 *   FR_RDR_Obj_RelPosX31Val of type COM_DT_FR_RDR_Obj_RelPosX31Val
 *   FR_RDR_Obj_RelPosX32Val of type COM_DT_FR_RDR_Obj_RelPosX32Val
 *   FR_RDR_Obj_RelPosY31Val of type COM_DT_FR_RDR_Obj_RelPosY31Val
 *   FR_RDR_Obj_RelPosY32Val of type COM_DT_FR_RDR_Obj_RelPosY32Val
 *   FR_RDR_Obj_RelVelX31Val of type COM_DT_FR_RDR_Obj_RelVelX31Val
 *   FR_RDR_Obj_RelVelX32Val of type COM_DT_FR_RDR_Obj_RelVelX32Val
 *   FR_RDR_Obj_RelVelY31Val of type COM_DT_FR_RDR_Obj_RelVelY31Val
 *   FR_RDR_Obj_RelVelY32Val of type COM_DT_FR_RDR_Obj_RelVelY32Val
 *   FR_RDR_Obj_TrkSta31Sta of type COM_DT_FR_RDR_Obj_TrkSta31Sta
 *   FR_RDR_Obj_TrkSta32Sta of type COM_DT_FR_RDR_Obj_TrkSta32Sta
 * COM_DT_SG_RD_DTC_SignalGroup: Record with elements
 *   BatteryVoltageHigh of type BatteryVoltageHigh
 *   BatteryVoltageLow of type BatteryVoltageLow
 *   Blockage_Drv of type Blockage_Drv
 *   Blockage_Init of type Blockage_Init
 *   RadarCANCommError of type RadarCANCommError
 *   RadarErrorCode_No1 of type RadarErrorCode_No1
 *   RadarErrorCode_No2 of type RadarErrorCode_No2
 *   RadarHwError of type RadarHwError
 *   RadarHwTempCondition_High of type RadarHwTempCondition_High
 *   RadarHwTempCondition_Low of type RadarHwTempCondition_Low
 *   RD_DTC_AlvCntVal of type RD_DTC_AlvCntVal
 *   SystemOutOfCalibration_DRV of type SystemOutOfCalibration_DRV
 *   SystemOutOfCalibration_EOL of type SystemOutOfCalibration_EOL
 *   RD_DTC_CRCVal of type RD_DTC_CRCVal
 *   FR_RDR_HW_Reset of type FR_RDR_HW_Reset
 *   FR_RDR_SW_Reset of type FR_RDR_SW_Reset
 * RadarDtcInfo_t: Record with elements
 *   BatteryVoltageHigh of type COM_DT_BatteryVoltageHigh
 *   BatteryVoltageLow of type COM_DT_BatteryVoltageLow
 *   Blockage_Drv of type COM_DT_Blockage_Drv
 *   Blockage_Init of type COM_DT_Blockage_Init
 *   RadarCANCommError of type COM_DT_RadarCANCommError
 *   RadarErrorCode_No1 of type COM_DT_RadarErrorCode_No1
 *   RadarErrorCode_No2 of type COM_DT_RadarErrorCode_No2
 *   RadarHwError of type COM_DT_RadarHwError
 *   RadarHwTempCondition_High of type COM_DT_RadarHwTempCondition_High
 *   RadarHwTempCondition_Low of type COM_DT_RadarHwTempCondition_Low
 *   RD_DTC_AlvCntVal of type COM_DT_RD_DTC_AlvCntVal
 *   SystemOutOfCalibration_DRV of type COM_DT_SystemOutOfCalibration_DRV
 *   SystemOutOfCalibration_EOL of type COM_DT_SystemOutOfCalibration_EOL
 *   RD_DTC_CRCVal of type COM_DT_FR_RDR_CrcVal
 * RdrInfo_t: Record with elements
 *   FR_RDR_Det_CRC01Val of type uint16
 *   FR_RDR_Det_CRC02Val of type uint16
 *   FR_RDR_Det_CRC03Val of type uint16
 *   FR_RDR_Det_CRC04Val of type uint16
 *   FR_RDR_Det_CRC05Val of type uint16
 *   FR_RDR_Det_CRC06Val of type uint16
 *   FR_RDR_Det_CRC07Val of type uint16
 *   FR_RDR_Det_CRC08Val of type uint16
 *   FR_RDR_Det_CRC09Val of type uint16
 *   FR_RDR_Det_CRC10Val of type uint16
 *   FR_RDR_Det_CRC11Val of type uint16
 *   FR_RDR_Det_CRC12Val of type uint16
 *   FR_RDR_Det_CRC13Val of type uint16
 *   FR_RDR_Det_CRC14Val of type uint16
 *   FR_RDR_Det_CRC15Val of type uint16
 *   FR_RDR_Det_CRC16Val of type uint16
 *   FR_RDR_Det_Long01 of type uint16
 *   FR_RDR_Det_Long02 of type uint16
 *   FR_RDR_Det_Long03 of type uint16
 *   FR_RDR_Det_Long04 of type uint16
 *   FR_RDR_Det_Long05 of type uint16
 *   FR_RDR_Det_Long06 of type uint16
 *   FR_RDR_Det_Long07 of type uint16
 *   FR_RDR_Det_Long08 of type uint16
 *   FR_RDR_Det_Long09 of type uint16
 *   FR_RDR_Det_Long10 of type uint16
 *   FR_RDR_Det_Long11 of type uint16
 *   FR_RDR_Det_Long12 of type uint16
 *   FR_RDR_Det_Long13 of type uint16
 *   FR_RDR_Det_Long14 of type uint16
 *   FR_RDR_Det_Long15 of type uint16
 *   FR_RDR_Det_Long16 of type uint16
 *   FR_RDR_Det_Long17 of type uint16
 *   FR_RDR_Det_Long18 of type uint16
 *   FR_RDR_Det_Long19 of type uint16
 *   FR_RDR_Det_Long20 of type uint16
 *   FR_RDR_Det_Long21 of type uint16
 *   FR_RDR_Det_Long22 of type uint16
 *   FR_RDR_Det_Long23 of type uint16
 *   FR_RDR_Det_Long24 of type uint16
 *   FR_RDR_Det_Long25 of type uint16
 *   FR_RDR_Det_Long26 of type uint16
 *   FR_RDR_Det_Long27 of type uint16
 *   FR_RDR_Det_Long28 of type uint16
 *   FR_RDR_Det_Long29 of type uint16
 *   FR_RDR_Det_Long30 of type uint16
 *   FR_RDR_Det_Long31 of type uint16
 *   FR_RDR_Det_Long32 of type uint16
 *   FR_RDR_Det_Long33 of type uint16
 *   FR_RDR_Det_Long34 of type uint16
 *   FR_RDR_Det_Long35 of type uint16
 *   FR_RDR_Det_Long36 of type uint16
 *   FR_RDR_Det_Long37 of type uint16
 *   FR_RDR_Det_Long38 of type uint16
 *   FR_RDR_Det_Long39 of type uint16
 *   FR_RDR_Det_Long40 of type uint16
 *   FR_RDR_Det_Long41 of type uint16
 *   FR_RDR_Det_Long42 of type uint16
 *   FR_RDR_Det_Long43 of type uint16
 *   FR_RDR_Det_Long44 of type uint16
 *   FR_RDR_Det_Long45 of type uint16
 *   FR_RDR_Det_Long46 of type uint16
 *   FR_RDR_Det_Long47 of type uint16
 *   FR_RDR_Det_Long48 of type uint16
 *   FR_RDR_Det_Long49 of type uint16
 *   FR_RDR_Det_Long50 of type uint16
 *   FR_RDR_Det_Long51 of type uint16
 *   FR_RDR_Det_Long52 of type uint16
 *   FR_RDR_Det_Long53 of type uint16
 *   FR_RDR_Det_Long54 of type uint16
 *   FR_RDR_Det_Long55 of type uint16
 *   FR_RDR_Det_Long56 of type uint16
 *   FR_RDR_Det_Long57 of type uint16
 *   FR_RDR_Det_Long58 of type uint16
 *   FR_RDR_Det_Long59 of type uint16
 *   FR_RDR_Det_Long60 of type uint16
 *   FR_RDR_Det_Long61 of type uint16
 *   FR_RDR_Det_Long62 of type uint16
 *   FR_RDR_Det_Long63 of type uint16
 *   FR_RDR_Det_Long64 of type uint16
 *   FR_RDR_Det_Lat01 of type sint16
 *   FR_RDR_Det_Lat02 of type sint16
 *   FR_RDR_Det_Lat03 of type sint16
 *   FR_RDR_Det_Lat04 of type sint16
 *   FR_RDR_Det_Lat05 of type sint16
 *   FR_RDR_Det_Lat06 of type sint16
 *   FR_RDR_Det_Lat07 of type sint16
 *   FR_RDR_Det_Lat08 of type sint16
 *   FR_RDR_Det_Lat09 of type sint16
 *   FR_RDR_Det_Lat10 of type sint16
 *   FR_RDR_Det_Lat11 of type sint16
 *   FR_RDR_Det_Lat12 of type sint16
 *   FR_RDR_Det_Lat13 of type sint16
 *   FR_RDR_Det_Lat14 of type sint16
 *   FR_RDR_Det_Lat15 of type sint16
 *   FR_RDR_Det_Lat16 of type sint16
 *   FR_RDR_Det_Lat17 of type sint16
 *   FR_RDR_Det_Lat18 of type sint16
 *   FR_RDR_Det_Lat19 of type sint16
 *   FR_RDR_Det_Lat20 of type sint16
 *   FR_RDR_Det_Lat21 of type sint16
 *   FR_RDR_Det_Lat22 of type sint16
 *   FR_RDR_Det_Lat23 of type sint16
 *   FR_RDR_Det_Lat24 of type sint16
 *   FR_RDR_Det_Lat25 of type sint16
 *   FR_RDR_Det_Lat26 of type sint16
 *   FR_RDR_Det_Lat27 of type sint16
 *   FR_RDR_Det_Lat28 of type sint16
 *   FR_RDR_Det_Lat29 of type sint16
 *   FR_RDR_Det_Lat30 of type sint16
 *   FR_RDR_Det_Lat31 of type sint16
 *   FR_RDR_Det_Lat32 of type sint16
 *   FR_RDR_Det_Lat33 of type sint16
 *   FR_RDR_Det_Lat34 of type sint16
 *   FR_RDR_Det_Lat35 of type sint16
 *   FR_RDR_Det_Lat36 of type sint16
 *   FR_RDR_Det_Lat37 of type sint16
 *   FR_RDR_Det_Lat38 of type sint16
 *   FR_RDR_Det_Lat39 of type sint16
 *   FR_RDR_Det_Lat40 of type sint16
 *   FR_RDR_Det_Lat41 of type sint16
 *   FR_RDR_Det_Lat42 of type sint16
 *   FR_RDR_Det_Lat43 of type sint16
 *   FR_RDR_Det_Lat44 of type sint16
 *   FR_RDR_Det_Lat45 of type sint16
 *   FR_RDR_Det_Lat46 of type sint16
 *   FR_RDR_Det_Lat47 of type sint16
 *   FR_RDR_Det_Lat48 of type sint16
 *   FR_RDR_Det_Lat49 of type sint16
 *   FR_RDR_Det_Lat50 of type sint16
 *   FR_RDR_Det_Lat51 of type sint16
 *   FR_RDR_Det_Lat52 of type sint16
 *   FR_RDR_Det_Lat53 of type sint16
 *   FR_RDR_Det_Lat54 of type sint16
 *   FR_RDR_Det_Lat55 of type sint16
 *   FR_RDR_Det_Lat56 of type sint16
 *   FR_RDR_Det_Lat57 of type sint16
 *   FR_RDR_Det_Lat58 of type sint16
 *   FR_RDR_Det_Lat59 of type sint16
 *   FR_RDR_Det_Lat60 of type sint16
 *   FR_RDR_Det_Lat61 of type sint16
 *   FR_RDR_Det_Lat62 of type sint16
 *   FR_RDR_Det_Lat63 of type sint16
 *   FR_RDR_Det_Lat64 of type sint16
 *   FR_RDR_Det_Speed01 of type sint16
 *   FR_RDR_Det_Speed02 of type sint16
 *   FR_RDR_Det_Speed03 of type sint16
 *   FR_RDR_Det_Speed04 of type sint16
 *   FR_RDR_Det_Speed05 of type sint16
 *   FR_RDR_Det_Speed06 of type sint16
 *   FR_RDR_Det_Speed07 of type sint16
 *   FR_RDR_Det_Speed08 of type sint16
 *   FR_RDR_Det_Speed09 of type sint16
 *   FR_RDR_Det_Speed10 of type sint16
 *   FR_RDR_Det_Speed11 of type sint16
 *   FR_RDR_Det_Speed12 of type sint16
 *   FR_RDR_Det_Speed13 of type sint16
 *   FR_RDR_Det_Speed14 of type sint16
 *   FR_RDR_Det_Speed15 of type sint16
 *   FR_RDR_Det_Speed16 of type sint16
 *   FR_RDR_Det_Speed17 of type sint16
 *   FR_RDR_Det_Speed18 of type sint16
 *   FR_RDR_Det_Speed19 of type sint16
 *   FR_RDR_Det_Speed20 of type sint16
 *   FR_RDR_Det_Speed21 of type sint16
 *   FR_RDR_Det_Speed22 of type sint16
 *   FR_RDR_Det_Speed23 of type sint16
 *   FR_RDR_Det_Speed24 of type sint16
 *   FR_RDR_Det_Speed25 of type sint16
 *   FR_RDR_Det_Speed26 of type sint16
 *   FR_RDR_Det_Speed27 of type sint16
 *   FR_RDR_Det_Speed28 of type sint16
 *   FR_RDR_Det_Speed29 of type sint16
 *   FR_RDR_Det_Speed30 of type sint16
 *   FR_RDR_Det_Speed31 of type sint16
 *   FR_RDR_Det_Speed32 of type sint16
 *   FR_RDR_Det_Speed33 of type sint16
 *   FR_RDR_Det_Speed34 of type sint16
 *   FR_RDR_Det_Speed35 of type sint16
 *   FR_RDR_Det_Speed36 of type sint16
 *   FR_RDR_Det_Speed37 of type sint16
 *   FR_RDR_Det_Speed38 of type sint16
 *   FR_RDR_Det_Speed39 of type sint16
 *   FR_RDR_Det_Speed40 of type sint16
 *   FR_RDR_Det_Speed41 of type sint16
 *   FR_RDR_Det_Speed42 of type sint16
 *   FR_RDR_Det_Speed43 of type sint16
 *   FR_RDR_Det_Speed44 of type sint16
 *   FR_RDR_Det_Speed45 of type sint16
 *   FR_RDR_Det_Speed46 of type sint16
 *   FR_RDR_Det_Speed47 of type sint16
 *   FR_RDR_Det_Speed48 of type sint16
 *   FR_RDR_Det_Speed49 of type sint16
 *   FR_RDR_Det_Speed50 of type sint16
 *   FR_RDR_Det_Speed51 of type sint16
 *   FR_RDR_Det_Speed52 of type sint16
 *   FR_RDR_Det_Speed53 of type sint16
 *   FR_RDR_Det_Speed54 of type sint16
 *   FR_RDR_Det_Speed55 of type sint16
 *   FR_RDR_Det_Speed56 of type sint16
 *   FR_RDR_Det_Speed57 of type sint16
 *   FR_RDR_Det_Speed58 of type sint16
 *   FR_RDR_Det_Speed59 of type sint16
 *   FR_RDR_Det_Speed60 of type sint16
 *   FR_RDR_Det_Speed61 of type sint16
 *   FR_RDR_Det_Speed62 of type sint16
 *   FR_RDR_Det_Speed63 of type sint16
 *   FR_RDR_Det_Speed64 of type sint16
 *   FR_RDR_Det_SNR01 of type uint16
 *   FR_RDR_Det_SNR02 of type uint16
 *   FR_RDR_Det_SNR03 of type uint16
 *   FR_RDR_Det_SNR04 of type uint16
 *   FR_RDR_Det_SNR05 of type uint16
 *   FR_RDR_Det_SNR06 of type uint16
 *   FR_RDR_Det_SNR07 of type uint16
 *   FR_RDR_Det_SNR08 of type uint16
 *   FR_RDR_Det_SNR09 of type uint16
 *   FR_RDR_Det_SNR10 of type uint16
 *   FR_RDR_Det_SNR11 of type uint16
 *   FR_RDR_Det_SNR12 of type uint16
 *   FR_RDR_Det_SNR13 of type uint16
 *   FR_RDR_Det_SNR14 of type uint16
 *   FR_RDR_Det_SNR15 of type uint16
 *   FR_RDR_Det_SNR16 of type uint16
 *   FR_RDR_Det_SNR17 of type uint16
 *   FR_RDR_Det_SNR18 of type uint16
 *   FR_RDR_Det_SNR19 of type uint16
 *   FR_RDR_Det_SNR20 of type uint16
 *   FR_RDR_Det_SNR21 of type uint16
 *   FR_RDR_Det_SNR22 of type uint16
 *   FR_RDR_Det_SNR23 of type uint16
 *   FR_RDR_Det_SNR24 of type uint16
 *   FR_RDR_Det_SNR25 of type uint16
 *   FR_RDR_Det_SNR26 of type uint16
 *   FR_RDR_Det_SNR27 of type uint16
 *   FR_RDR_Det_SNR28 of type uint16
 *   FR_RDR_Det_SNR29 of type uint16
 *   FR_RDR_Det_SNR30 of type uint16
 *   FR_RDR_Det_SNR31 of type uint16
 *   FR_RDR_Det_SNR32 of type uint16
 *   FR_RDR_Det_SNR33 of type uint16
 *   FR_RDR_Det_SNR34 of type uint16
 *   FR_RDR_Det_SNR35 of type uint16
 *   FR_RDR_Det_SNR36 of type uint16
 *   FR_RDR_Det_SNR37 of type uint16
 *   FR_RDR_Det_SNR38 of type uint16
 *   FR_RDR_Det_SNR39 of type uint16
 *   FR_RDR_Det_SNR40 of type uint16
 *   FR_RDR_Det_SNR41 of type uint16
 *   FR_RDR_Det_SNR42 of type uint16
 *   FR_RDR_Det_SNR43 of type uint16
 *   FR_RDR_Det_SNR44 of type uint16
 *   FR_RDR_Det_SNR45 of type uint16
 *   FR_RDR_Det_SNR46 of type uint16
 *   FR_RDR_Det_SNR47 of type uint16
 *   FR_RDR_Det_SNR48 of type uint16
 *   FR_RDR_Det_SNR49 of type uint16
 *   FR_RDR_Det_SNR50 of type uint16
 *   FR_RDR_Det_SNR51 of type uint16
 *   FR_RDR_Det_SNR52 of type uint16
 *   FR_RDR_Det_SNR53 of type uint16
 *   FR_RDR_Det_SNR54 of type uint16
 *   FR_RDR_Det_SNR55 of type uint16
 *   FR_RDR_Det_SNR56 of type uint16
 *   FR_RDR_Det_SNR57 of type uint16
 *   FR_RDR_Det_SNR58 of type uint16
 *   FR_RDR_Det_SNR59 of type uint16
 *   FR_RDR_Det_SNR60 of type uint16
 *   FR_RDR_Det_SNR61 of type uint16
 *   FR_RDR_Det_SNR62 of type uint16
 *   FR_RDR_Det_SNR63 of type uint16
 *   FR_RDR_Det_SNR64 of type uint16
 *   FR_RDR_Det_AmbigSpeed01 of type sint16
 *   FR_RDR_Det_AmbigSpeed02 of type sint16
 *   FR_RDR_Det_AmbigSpeed03 of type sint16
 *   FR_RDR_Det_AmbigSpeed04 of type sint16
 *   FR_RDR_Det_AmbigSpeed05 of type sint16
 *   FR_RDR_Det_AmbigSpeed06 of type sint16
 *   FR_RDR_Det_AmbigSpeed07 of type sint16
 *   FR_RDR_Det_AmbigSpeed08 of type sint16
 *   FR_RDR_Det_AmbigSpeed09 of type sint16
 *   FR_RDR_Det_AmbigSpeed10 of type sint16
 *   FR_RDR_Det_AmbigSpeed11 of type sint16
 *   FR_RDR_Det_AmbigSpeed12 of type sint16
 *   FR_RDR_Det_AmbigSpeed13 of type sint16
 *   FR_RDR_Det_AmbigSpeed14 of type sint16
 *   FR_RDR_Det_AmbigSpeed15 of type sint16
 *   FR_RDR_Det_AmbigSpeed16 of type sint16
 *   FR_RDR_Det_AmbigSpeed17 of type sint16
 *   FR_RDR_Det_AmbigSpeed18 of type sint16
 *   FR_RDR_Det_AmbigSpeed19 of type sint16
 *   FR_RDR_Det_AmbigSpeed20 of type sint16
 *   FR_RDR_Det_AmbigSpeed21 of type sint16
 *   FR_RDR_Det_AmbigSpeed22 of type sint16
 *   FR_RDR_Det_AmbigSpeed23 of type sint16
 *   FR_RDR_Det_AmbigSpeed24 of type sint16
 *   FR_RDR_Det_AmbigSpeed25 of type sint16
 *   FR_RDR_Det_AmbigSpeed26 of type sint16
 *   FR_RDR_Det_AmbigSpeed27 of type sint16
 *   FR_RDR_Det_AmbigSpeed28 of type sint16
 *   FR_RDR_Det_AmbigSpeed29 of type sint16
 *   FR_RDR_Det_AmbigSpeed30 of type sint16
 *   FR_RDR_Det_AmbigSpeed31 of type sint16
 *   FR_RDR_Det_AmbigSpeed32 of type sint16
 *   FR_RDR_Det_AmbigSpeed33 of type sint16
 *   FR_RDR_Det_AmbigSpeed34 of type sint16
 *   FR_RDR_Det_AmbigSpeed35 of type sint16
 *   FR_RDR_Det_AmbigSpeed36 of type sint16
 *   FR_RDR_Det_AmbigSpeed37 of type sint16
 *   FR_RDR_Det_AmbigSpeed38 of type sint16
 *   FR_RDR_Det_AmbigSpeed39 of type sint16
 *   FR_RDR_Det_AmbigSpeed40 of type sint16
 *   FR_RDR_Det_AmbigSpeed41 of type sint16
 *   FR_RDR_Det_AmbigSpeed42 of type sint16
 *   FR_RDR_Det_AmbigSpeed43 of type sint16
 *   FR_RDR_Det_AmbigSpeed44 of type sint16
 *   FR_RDR_Det_AmbigSpeed45 of type sint16
 *   FR_RDR_Det_AmbigSpeed46 of type sint16
 *   FR_RDR_Det_AmbigSpeed47 of type sint16
 *   FR_RDR_Det_AmbigSpeed48 of type sint16
 *   FR_RDR_Det_AmbigSpeed49 of type sint16
 *   FR_RDR_Det_AmbigSpeed50 of type sint16
 *   FR_RDR_Det_AmbigSpeed51 of type sint16
 *   FR_RDR_Det_AmbigSpeed52 of type sint16
 *   FR_RDR_Det_AmbigSpeed53 of type sint16
 *   FR_RDR_Det_AmbigSpeed54 of type sint16
 *   FR_RDR_Det_AmbigSpeed55 of type sint16
 *   FR_RDR_Det_AmbigSpeed56 of type sint16
 *   FR_RDR_Det_AmbigSpeed57 of type sint16
 *   FR_RDR_Det_AmbigSpeed58 of type sint16
 *   FR_RDR_Det_AmbigSpeed59 of type sint16
 *   FR_RDR_Det_AmbigSpeed60 of type sint16
 *   FR_RDR_Det_AmbigSpeed61 of type sint16
 *   FR_RDR_Det_AmbigSpeed62 of type sint16
 *   FR_RDR_Det_AmbigSpeed63 of type sint16
 *   FR_RDR_Det_AmbigSpeed64 of type sint16
 *   FR_RDR_Obj_CRC01Val of type uint16
 *   FR_RDR_Obj_CRC02Val of type uint16
 *   FR_RDR_Obj_CRC03Val of type uint16
 *   FR_RDR_Obj_CRC04Val of type uint16
 *   FR_RDR_Obj_CRC05Val of type uint16
 *   FR_RDR_Obj_CRC06Val of type uint16
 *   FR_RDR_Obj_CRC07Val of type uint16
 *   FR_RDR_Obj_CRC08Val of type uint16
 *   FR_RDR_Obj_CRC09Val of type uint16
 *   FR_RDR_Obj_CRC10Val of type uint16
 *   FR_RDR_Obj_CRC11Val of type uint16
 *   FR_RDR_Obj_CRC12Val of type uint16
 *   FR_RDR_Obj_CRC13Val of type uint16
 *   FR_RDR_Obj_CRC14Val of type uint16
 *   FR_RDR_Obj_CRC15Val of type uint16
 *   FR_RDR_Obj_CRC16Val of type uint16
 *   FR_RDR_Obj_RelPosX01Val of type uint16
 *   FR_RDR_Obj_RelPosX02Val of type uint16
 *   FR_RDR_Obj_RelPosX03Val of type uint16
 *   FR_RDR_Obj_RelPosX04Val of type uint16
 *   FR_RDR_Obj_RelPosX05Val of type uint16
 *   FR_RDR_Obj_RelPosX06Val of type uint16
 *   FR_RDR_Obj_RelPosX07Val of type uint16
 *   FR_RDR_Obj_RelPosX08Val of type uint16
 *   FR_RDR_Obj_RelPosX09Val of type uint16
 *   FR_RDR_Obj_RelPosX10Val of type uint16
 *   FR_RDR_Obj_RelPosX11Val of type uint16
 *   FR_RDR_Obj_RelPosX12Val of type uint16
 *   FR_RDR_Obj_RelPosX13Val of type uint16
 *   FR_RDR_Obj_RelPosX14Val of type uint16
 *   FR_RDR_Obj_RelPosX15Val of type uint16
 *   FR_RDR_Obj_RelPosX16Val of type uint16
 *   FR_RDR_Obj_RelPosX17Val of type uint16
 *   FR_RDR_Obj_RelPosX18Val of type uint16
 *   FR_RDR_Obj_RelPosX19Val of type uint16
 *   FR_RDR_Obj_RelPosX20Val of type uint16
 *   FR_RDR_Obj_RelPosX21Val of type uint16
 *   FR_RDR_Obj_RelPosX22Val of type uint16
 *   FR_RDR_Obj_RelPosX23Val of type uint16
 *   FR_RDR_Obj_RelPosX24Val of type uint16
 *   FR_RDR_Obj_RelPosX25Val of type uint16
 *   FR_RDR_Obj_RelPosX26Val of type uint16
 *   FR_RDR_Obj_RelPosX27Val of type uint16
 *   FR_RDR_Obj_RelPosX28Val of type uint16
 *   FR_RDR_Obj_RelPosX29Val of type uint16
 *   FR_RDR_Obj_RelPosX30Val of type uint16
 *   FR_RDR_Obj_RelPosX31Val of type uint16
 *   FR_RDR_Obj_RelPosX32Val of type uint16
 *   FR_RDR_Obj_RelPosY01Val of type sint16
 *   FR_RDR_Obj_RelPosY02Val of type sint16
 *   FR_RDR_Obj_RelPosY03Val of type sint16
 *   FR_RDR_Obj_RelPosY04Val of type sint16
 *   FR_RDR_Obj_RelPosY05Val of type sint16
 *   FR_RDR_Obj_RelPosY06Val of type sint16
 *   FR_RDR_Obj_RelPosY07Val of type sint16
 *   FR_RDR_Obj_RelPosY08Val of type sint16
 *   FR_RDR_Obj_RelPosY09Val of type sint16
 *   FR_RDR_Obj_RelPosY10Val of type sint16
 *   FR_RDR_Obj_RelPosY11Val of type sint16
 *   FR_RDR_Obj_RelPosY12Val of type sint16
 *   FR_RDR_Obj_RelPosY13Val of type sint16
 *   FR_RDR_Obj_RelPosY14Val of type sint16
 *   FR_RDR_Obj_RelPosY15Val of type sint16
 *   FR_RDR_Obj_RelPosY16Val of type sint16
 *   FR_RDR_Obj_RelPosY17Val of type sint16
 *   FR_RDR_Obj_RelPosY18Val of type sint16
 *   FR_RDR_Obj_RelPosY19Val of type sint16
 *   FR_RDR_Obj_RelPosY20Val of type sint16
 *   FR_RDR_Obj_RelPosY21Val of type sint16
 *   FR_RDR_Obj_RelPosY22Val of type sint16
 *   FR_RDR_Obj_RelPosY23Val of type sint16
 *   FR_RDR_Obj_RelPosY24Val of type sint16
 *   FR_RDR_Obj_RelPosY25Val of type sint16
 *   FR_RDR_Obj_RelPosY26Val of type sint16
 *   FR_RDR_Obj_RelPosY27Val of type sint16
 *   FR_RDR_Obj_RelPosY28Val of type sint16
 *   FR_RDR_Obj_RelPosY29Val of type sint16
 *   FR_RDR_Obj_RelPosY30Val of type sint16
 *   FR_RDR_Obj_RelPosY31Val of type sint16
 *   FR_RDR_Obj_RelPosY32Val of type sint16
 *   FR_RDR_Obj_RelVelX01Val of type sint16
 *   FR_RDR_Obj_RelVelX02Val of type sint16
 *   FR_RDR_Obj_RelVelX03Val of type sint16
 *   FR_RDR_Obj_RelVelX04Val of type sint16
 *   FR_RDR_Obj_RelVelX05Val of type sint16
 *   FR_RDR_Obj_RelVelX06Val of type sint16
 *   FR_RDR_Obj_RelVelX07Val of type sint16
 *   FR_RDR_Obj_RelVelX08Val of type sint16
 *   FR_RDR_Obj_RelVelX09Val of type sint16
 *   FR_RDR_Obj_RelVelX10Val of type sint16
 *   FR_RDR_Obj_RelVelX11Val of type sint16
 *   FR_RDR_Obj_RelVelX12Val of type sint16
 *   FR_RDR_Obj_RelVelX13Val of type sint16
 *   FR_RDR_Obj_RelVelX14Val of type sint16
 *   FR_RDR_Obj_RelVelX15Val of type sint16
 *   FR_RDR_Obj_RelVelX16Val of type sint16
 *   FR_RDR_Obj_RelVelX17Val of type sint16
 *   FR_RDR_Obj_RelVelX18Val of type sint16
 *   FR_RDR_Obj_RelVelX19Val of type sint16
 *   FR_RDR_Obj_RelVelX20Val of type sint16
 *   FR_RDR_Obj_RelVelX21Val of type sint16
 *   FR_RDR_Obj_RelVelX22Val of type sint16
 *   FR_RDR_Obj_RelVelX23Val of type sint16
 *   FR_RDR_Obj_RelVelX24Val of type sint16
 *   FR_RDR_Obj_RelVelX25Val of type sint16
 *   FR_RDR_Obj_RelVelX26Val of type sint16
 *   FR_RDR_Obj_RelVelX27Val of type sint16
 *   FR_RDR_Obj_RelVelX28Val of type sint16
 *   FR_RDR_Obj_RelVelX29Val of type sint16
 *   FR_RDR_Obj_RelVelX30Val of type sint16
 *   FR_RDR_Obj_RelVelX31Val of type sint16
 *   FR_RDR_Obj_RelVelX32Val of type sint16
 *   FR_RDR_Obj_RelVelY01Val of type sint16
 *   FR_RDR_Obj_RelVelY02Val of type sint16
 *   FR_RDR_Obj_RelVelY03Val of type sint16
 *   FR_RDR_Obj_RelVelY04Val of type sint16
 *   FR_RDR_Obj_RelVelY05Val of type sint16
 *   FR_RDR_Obj_RelVelY06Val of type sint16
 *   FR_RDR_Obj_RelVelY07Val of type sint16
 *   FR_RDR_Obj_RelVelY08Val of type sint16
 *   FR_RDR_Obj_RelVelY09Val of type sint16
 *   FR_RDR_Obj_RelVelY10Val of type sint16
 *   FR_RDR_Obj_RelVelY11Val of type sint16
 *   FR_RDR_Obj_RelVelY12Val of type sint16
 *   FR_RDR_Obj_RelVelY13Val of type sint16
 *   FR_RDR_Obj_RelVelY14Val of type sint16
 *   FR_RDR_Obj_RelVelY15Val of type sint16
 *   FR_RDR_Obj_RelVelY16Val of type sint16
 *   FR_RDR_Obj_RelVelY17Val of type sint16
 *   FR_RDR_Obj_RelVelY18Val of type sint16
 *   FR_RDR_Obj_RelVelY19Val of type sint16
 *   FR_RDR_Obj_RelVelY20Val of type sint16
 *   FR_RDR_Obj_RelVelY21Val of type sint16
 *   FR_RDR_Obj_RelVelY22Val of type sint16
 *   FR_RDR_Obj_RelVelY23Val of type sint16
 *   FR_RDR_Obj_RelVelY24Val of type sint16
 *   FR_RDR_Obj_RelVelY25Val of type sint16
 *   FR_RDR_Obj_RelVelY26Val of type sint16
 *   FR_RDR_Obj_RelVelY27Val of type sint16
 *   FR_RDR_Obj_RelVelY28Val of type sint16
 *   FR_RDR_Obj_RelVelY29Val of type sint16
 *   FR_RDR_Obj_RelVelY30Val of type sint16
 *   FR_RDR_Obj_RelVelY31Val of type sint16
 *   FR_RDR_Obj_RelVelY32Val of type sint16
 *   FR_RDR_Obj_RelAccelX01Val of type sint16
 *   FR_RDR_Obj_RelAccelX02Val of type sint16
 *   FR_RDR_Obj_RelAccelX03Val of type sint16
 *   FR_RDR_Obj_RelAccelX04Val of type sint16
 *   FR_RDR_Obj_RelAccelX05Val of type sint16
 *   FR_RDR_Obj_RelAccelX06Val of type sint16
 *   FR_RDR_Obj_RelAccelX07Val of type sint16
 *   FR_RDR_Obj_RelAccelX08Val of type sint16
 *   FR_RDR_Obj_RelAccelX09Val of type sint16
 *   FR_RDR_Obj_RelAccelX10Val of type sint16
 *   FR_RDR_Obj_RelAccelX11Val of type sint16
 *   FR_RDR_Obj_RelAccelX12Val of type sint16
 *   FR_RDR_Obj_RelAccelX13Val of type sint16
 *   FR_RDR_Obj_RelAccelX14Val of type sint16
 *   FR_RDR_Obj_RelAccelX15Val of type sint16
 *   FR_RDR_Obj_RelAccelX16Val of type sint16
 *   FR_RDR_Obj_RelAccelX17Val of type sint16
 *   FR_RDR_Obj_RelAccelX18Val of type sint16
 *   FR_RDR_Obj_RelAccelX19Val of type sint16
 *   FR_RDR_Obj_RelAccelX20Val of type sint16
 *   FR_RDR_Obj_RelAccelX21Val of type sint16
 *   FR_RDR_Obj_RelAccelX22Val of type sint16
 *   FR_RDR_Obj_RelAccelX23Val of type sint16
 *   FR_RDR_Obj_RelAccelX24Val of type sint16
 *   FR_RDR_Obj_RelAccelX25Val of type sint16
 *   FR_RDR_Obj_RelAccelX26Val of type sint16
 *   FR_RDR_Obj_RelAccelX27Val of type sint16
 *   FR_RDR_Obj_RelAccelX28Val of type sint16
 *   FR_RDR_Obj_RelAccelX29Val of type sint16
 *   FR_RDR_Obj_RelAccelX30Val of type sint16
 *   FR_RDR_Obj_RelAccelX31Val of type sint16
 *   FR_RDR_Obj_RelAccelX32Val of type sint16
 *   FR_RDR_DTC_RadarCRCVal of type uint16
 *   FR_RDR_DTC_RadarErrorCode_1 of type uint16
 *   FR_RDR_DTC_RadarErrorCode_2 of type uint16
 *   FR_RDR_Det_AlvCnt01Val of type uint8
 *   FR_RDR_Det_AlvCnt02Val of type uint8
 *   FR_RDR_Det_AlvCnt03Val of type uint8
 *   FR_RDR_Det_AlvCnt04Val of type uint8
 *   FR_RDR_Det_AlvCnt05Val of type uint8
 *   FR_RDR_Det_AlvCnt06Val of type uint8
 *   FR_RDR_Det_AlvCnt07Val of type uint8
 *   FR_RDR_Det_AlvCnt08Val of type uint8
 *   FR_RDR_Det_AlvCnt09Val of type uint8
 *   FR_RDR_Det_AlvCnt10Val of type uint8
 *   FR_RDR_Det_AlvCnt11Val of type uint8
 *   FR_RDR_Det_AlvCnt12Val of type uint8
 *   FR_RDR_Det_AlvCnt13Val of type uint8
 *   FR_RDR_Det_AlvCnt14Val of type uint8
 *   FR_RDR_Det_AlvCnt15Val of type uint8
 *   FR_RDR_Det_AlvCnt16Val of type uint8
 *   FR_RDR_Det_AssignTag01 of type uint8
 *   FR_RDR_Det_AssignTag02 of type uint8
 *   FR_RDR_Det_AssignTag03 of type uint8
 *   FR_RDR_Det_AssignTag04 of type uint8
 *   FR_RDR_Det_AssignTag05 of type uint8
 *   FR_RDR_Det_AssignTag06 of type uint8
 *   FR_RDR_Det_AssignTag07 of type uint8
 *   FR_RDR_Det_AssignTag08 of type uint8
 *   FR_RDR_Det_AssignTag09 of type uint8
 *   FR_RDR_Det_AssignTag10 of type uint8
 *   FR_RDR_Det_AssignTag11 of type uint8
 *   FR_RDR_Det_AssignTag12 of type uint8
 *   FR_RDR_Det_AssignTag13 of type uint8
 *   FR_RDR_Det_AssignTag14 of type uint8
 *   FR_RDR_Det_AssignTag15 of type uint8
 *   FR_RDR_Det_AssignTag16 of type uint8
 *   FR_RDR_Det_AssignTag17 of type uint8
 *   FR_RDR_Det_AssignTag18 of type uint8
 *   FR_RDR_Det_AssignTag19 of type uint8
 *   FR_RDR_Det_AssignTag20 of type uint8
 *   FR_RDR_Det_AssignTag21 of type uint8
 *   FR_RDR_Det_AssignTag22 of type uint8
 *   FR_RDR_Det_AssignTag23 of type uint8
 *   FR_RDR_Det_AssignTag24 of type uint8
 *   FR_RDR_Det_AssignTag25 of type uint8
 *   FR_RDR_Det_AssignTag26 of type uint8
 *   FR_RDR_Det_AssignTag27 of type uint8
 *   FR_RDR_Det_AssignTag28 of type uint8
 *   FR_RDR_Det_AssignTag29 of type uint8
 *   FR_RDR_Det_AssignTag30 of type uint8
 *   FR_RDR_Det_AssignTag31 of type uint8
 *   FR_RDR_Det_AssignTag32 of type uint8
 *   FR_RDR_Det_AssignTag33 of type uint8
 *   FR_RDR_Det_AssignTag34 of type uint8
 *   FR_RDR_Det_AssignTag35 of type uint8
 *   FR_RDR_Det_AssignTag36 of type uint8
 *   FR_RDR_Det_AssignTag37 of type uint8
 *   FR_RDR_Det_AssignTag38 of type uint8
 *   FR_RDR_Det_AssignTag39 of type uint8
 *   FR_RDR_Det_AssignTag40 of type uint8
 *   FR_RDR_Det_AssignTag41 of type uint8
 *   FR_RDR_Det_AssignTag42 of type uint8
 *   FR_RDR_Det_AssignTag43 of type uint8
 *   FR_RDR_Det_AssignTag44 of type uint8
 *   FR_RDR_Det_AssignTag45 of type uint8
 *   FR_RDR_Det_AssignTag46 of type uint8
 *   FR_RDR_Det_AssignTag47 of type uint8
 *   FR_RDR_Det_AssignTag48 of type uint8
 *   FR_RDR_Det_AssignTag49 of type uint8
 *   FR_RDR_Det_AssignTag50 of type uint8
 *   FR_RDR_Det_AssignTag51 of type uint8
 *   FR_RDR_Det_AssignTag52 of type uint8
 *   FR_RDR_Det_AssignTag53 of type uint8
 *   FR_RDR_Det_AssignTag54 of type uint8
 *   FR_RDR_Det_AssignTag55 of type uint8
 *   FR_RDR_Det_AssignTag56 of type uint8
 *   FR_RDR_Det_AssignTag57 of type uint8
 *   FR_RDR_Det_AssignTag58 of type uint8
 *   FR_RDR_Det_AssignTag59 of type uint8
 *   FR_RDR_Det_AssignTag60 of type uint8
 *   FR_RDR_Det_AssignTag61 of type uint8
 *   FR_RDR_Det_AssignTag62 of type uint8
 *   FR_RDR_Det_AssignTag63 of type uint8
 *   FR_RDR_Det_AssignTag64 of type uint8
 *   FR_RDR_Det_ClusterID01 of type uint8
 *   FR_RDR_Det_ClusterID02 of type uint8
 *   FR_RDR_Det_ClusterID03 of type uint8
 *   FR_RDR_Det_ClusterID04 of type uint8
 *   FR_RDR_Det_ClusterID05 of type uint8
 *   FR_RDR_Det_ClusterID06 of type uint8
 *   FR_RDR_Det_ClusterID07 of type uint8
 *   FR_RDR_Det_ClusterID08 of type uint8
 *   FR_RDR_Det_ClusterID09 of type uint8
 *   FR_RDR_Det_ClusterID10 of type uint8
 *   FR_RDR_Det_ClusterID11 of type uint8
 *   FR_RDR_Det_ClusterID12 of type uint8
 *   FR_RDR_Det_ClusterID13 of type uint8
 *   FR_RDR_Det_ClusterID14 of type uint8
 *   FR_RDR_Det_ClusterID15 of type uint8
 *   FR_RDR_Det_ClusterID16 of type uint8
 *   FR_RDR_Det_ClusterID17 of type uint8
 *   FR_RDR_Det_ClusterID18 of type uint8
 *   FR_RDR_Det_ClusterID19 of type uint8
 *   FR_RDR_Det_ClusterID20 of type uint8
 *   FR_RDR_Det_ClusterID21 of type uint8
 *   FR_RDR_Det_ClusterID22 of type uint8
 *   FR_RDR_Det_ClusterID23 of type uint8
 *   FR_RDR_Det_ClusterID24 of type uint8
 *   FR_RDR_Det_ClusterID25 of type uint8
 *   FR_RDR_Det_ClusterID26 of type uint8
 *   FR_RDR_Det_ClusterID27 of type uint8
 *   FR_RDR_Det_ClusterID28 of type uint8
 *   FR_RDR_Det_ClusterID29 of type uint8
 *   FR_RDR_Det_ClusterID30 of type uint8
 *   FR_RDR_Det_ClusterID31 of type uint8
 *   FR_RDR_Det_ClusterID32 of type uint8
 *   FR_RDR_Det_ClusterID33 of type uint8
 *   FR_RDR_Det_ClusterID34 of type uint8
 *   FR_RDR_Det_ClusterID35 of type uint8
 *   FR_RDR_Det_ClusterID36 of type uint8
 *   FR_RDR_Det_ClusterID37 of type uint8
 *   FR_RDR_Det_ClusterID38 of type uint8
 *   FR_RDR_Det_ClusterID39 of type uint8
 *   FR_RDR_Det_ClusterID40 of type uint8
 *   FR_RDR_Det_ClusterID41 of type uint8
 *   FR_RDR_Det_ClusterID42 of type uint8
 *   FR_RDR_Det_ClusterID43 of type uint8
 *   FR_RDR_Det_ClusterID44 of type uint8
 *   FR_RDR_Det_ClusterID45 of type uint8
 *   FR_RDR_Det_ClusterID46 of type uint8
 *   FR_RDR_Det_ClusterID47 of type uint8
 *   FR_RDR_Det_ClusterID48 of type uint8
 *   FR_RDR_Det_ClusterID49 of type uint8
 *   FR_RDR_Det_ClusterID50 of type uint8
 *   FR_RDR_Det_ClusterID51 of type uint8
 *   FR_RDR_Det_ClusterID52 of type uint8
 *   FR_RDR_Det_ClusterID53 of type uint8
 *   FR_RDR_Det_ClusterID54 of type uint8
 *   FR_RDR_Det_ClusterID55 of type uint8
 *   FR_RDR_Det_ClusterID56 of type uint8
 *   FR_RDR_Det_ClusterID57 of type uint8
 *   FR_RDR_Det_ClusterID58 of type uint8
 *   FR_RDR_Det_ClusterID59 of type uint8
 *   FR_RDR_Det_ClusterID60 of type uint8
 *   FR_RDR_Det_ClusterID61 of type uint8
 *   FR_RDR_Det_ClusterID62 of type uint8
 *   FR_RDR_Det_ClusterID63 of type uint8
 *   FR_RDR_Det_ClusterID64 of type uint8
 *   FR_RDR_Det_TrustV01 of type uint8
 *   FR_RDR_Det_TrustV02 of type uint8
 *   FR_RDR_Det_TrustV03 of type uint8
 *   FR_RDR_Det_TrustV04 of type uint8
 *   FR_RDR_Det_TrustV05 of type uint8
 *   FR_RDR_Det_TrustV06 of type uint8
 *   FR_RDR_Det_TrustV07 of type uint8
 *   FR_RDR_Det_TrustV08 of type uint8
 *   FR_RDR_Det_TrustV09 of type uint8
 *   FR_RDR_Det_TrustV10 of type uint8
 *   FR_RDR_Det_TrustV11 of type uint8
 *   FR_RDR_Det_TrustV12 of type uint8
 *   FR_RDR_Det_TrustV13 of type uint8
 *   FR_RDR_Det_TrustV14 of type uint8
 *   FR_RDR_Det_TrustV15 of type uint8
 *   FR_RDR_Det_TrustV16 of type uint8
 *   FR_RDR_Det_TrustV17 of type uint8
 *   FR_RDR_Det_TrustV18 of type uint8
 *   FR_RDR_Det_TrustV19 of type uint8
 *   FR_RDR_Det_TrustV20 of type uint8
 *   FR_RDR_Det_TrustV21 of type uint8
 *   FR_RDR_Det_TrustV22 of type uint8
 *   FR_RDR_Det_TrustV23 of type uint8
 *   FR_RDR_Det_TrustV24 of type uint8
 *   FR_RDR_Det_TrustV25 of type uint8
 *   FR_RDR_Det_TrustV26 of type uint8
 *   FR_RDR_Det_TrustV27 of type uint8
 *   FR_RDR_Det_TrustV28 of type uint8
 *   FR_RDR_Det_TrustV29 of type uint8
 *   FR_RDR_Det_TrustV30 of type uint8
 *   FR_RDR_Det_TrustV31 of type uint8
 *   FR_RDR_Det_TrustV32 of type uint8
 *   FR_RDR_Det_TrustV33 of type uint8
 *   FR_RDR_Det_TrustV34 of type uint8
 *   FR_RDR_Det_TrustV35 of type uint8
 *   FR_RDR_Det_TrustV36 of type uint8
 *   FR_RDR_Det_TrustV37 of type uint8
 *   FR_RDR_Det_TrustV38 of type uint8
 *   FR_RDR_Det_TrustV39 of type uint8
 *   FR_RDR_Det_TrustV40 of type uint8
 *   FR_RDR_Det_TrustV41 of type uint8
 *   FR_RDR_Det_TrustV42 of type uint8
 *   FR_RDR_Det_TrustV43 of type uint8
 *   FR_RDR_Det_TrustV44 of type uint8
 *   FR_RDR_Det_TrustV45 of type uint8
 *   FR_RDR_Det_TrustV46 of type uint8
 *   FR_RDR_Det_TrustV47 of type uint8
 *   FR_RDR_Det_TrustV48 of type uint8
 *   FR_RDR_Det_TrustV49 of type uint8
 *   FR_RDR_Det_TrustV50 of type uint8
 *   FR_RDR_Det_TrustV51 of type uint8
 *   FR_RDR_Det_TrustV52 of type uint8
 *   FR_RDR_Det_TrustV53 of type uint8
 *   FR_RDR_Det_TrustV54 of type uint8
 *   FR_RDR_Det_TrustV55 of type uint8
 *   FR_RDR_Det_TrustV56 of type uint8
 *   FR_RDR_Det_TrustV57 of type uint8
 *   FR_RDR_Det_TrustV58 of type uint8
 *   FR_RDR_Det_TrustV59 of type uint8
 *   FR_RDR_Det_TrustV60 of type uint8
 *   FR_RDR_Det_TrustV61 of type uint8
 *   FR_RDR_Det_TrustV62 of type uint8
 *   FR_RDR_Det_TrustV63 of type uint8
 *   FR_RDR_Det_TrustV64 of type uint8
 *   FR_RDR_Det_Height01 of type sint8
 *   FR_RDR_Det_Height02 of type sint8
 *   FR_RDR_Det_Height03 of type sint8
 *   FR_RDR_Det_Height04 of type sint8
 *   FR_RDR_Det_Height05 of type sint8
 *   FR_RDR_Det_Height06 of type sint8
 *   FR_RDR_Det_Height07 of type sint8
 *   FR_RDR_Det_Height08 of type sint8
 *   FR_RDR_Det_Height09 of type sint8
 *   FR_RDR_Det_Height10 of type sint8
 *   FR_RDR_Det_Height11 of type sint8
 *   FR_RDR_Det_Height12 of type sint8
 *   FR_RDR_Det_Height13 of type sint8
 *   FR_RDR_Det_Height14 of type sint8
 *   FR_RDR_Det_Height15 of type sint8
 *   FR_RDR_Det_Height16 of type sint8
 *   FR_RDR_Det_Height17 of type sint8
 *   FR_RDR_Det_Height18 of type sint8
 *   FR_RDR_Det_Height19 of type sint8
 *   FR_RDR_Det_Height20 of type sint8
 *   FR_RDR_Det_Height21 of type sint8
 *   FR_RDR_Det_Height22 of type sint8
 *   FR_RDR_Det_Height23 of type sint8
 *   FR_RDR_Det_Height24 of type sint8
 *   FR_RDR_Det_Height25 of type sint8
 *   FR_RDR_Det_Height26 of type sint8
 *   FR_RDR_Det_Height27 of type sint8
 *   FR_RDR_Det_Height28 of type sint8
 *   FR_RDR_Det_Height29 of type sint8
 *   FR_RDR_Det_Height30 of type sint8
 *   FR_RDR_Det_Height31 of type sint8
 *   FR_RDR_Det_Height32 of type sint8
 *   FR_RDR_Det_Height33 of type sint8
 *   FR_RDR_Det_Height34 of type sint8
 *   FR_RDR_Det_Height35 of type sint8
 *   FR_RDR_Det_Height36 of type sint8
 *   FR_RDR_Det_Height37 of type sint8
 *   FR_RDR_Det_Height38 of type sint8
 *   FR_RDR_Det_Height39 of type sint8
 *   FR_RDR_Det_Height40 of type sint8
 *   FR_RDR_Det_Height41 of type sint8
 *   FR_RDR_Det_Height42 of type sint8
 *   FR_RDR_Det_Height43 of type sint8
 *   FR_RDR_Det_Height44 of type sint8
 *   FR_RDR_Det_Height45 of type sint8
 *   FR_RDR_Det_Height46 of type sint8
 *   FR_RDR_Det_Height47 of type sint8
 *   FR_RDR_Det_Height48 of type sint8
 *   FR_RDR_Det_Height49 of type sint8
 *   FR_RDR_Det_Height50 of type sint8
 *   FR_RDR_Det_Height51 of type sint8
 *   FR_RDR_Det_Height52 of type sint8
 *   FR_RDR_Det_Height53 of type sint8
 *   FR_RDR_Det_Height54 of type sint8
 *   FR_RDR_Det_Height55 of type sint8
 *   FR_RDR_Det_Height56 of type sint8
 *   FR_RDR_Det_Height57 of type sint8
 *   FR_RDR_Det_Height58 of type sint8
 *   FR_RDR_Det_Height59 of type sint8
 *   FR_RDR_Det_Height60 of type sint8
 *   FR_RDR_Det_Height61 of type sint8
 *   FR_RDR_Det_Height62 of type sint8
 *   FR_RDR_Det_Height63 of type sint8
 *   FR_RDR_Det_Height64 of type sint8
 *   FR_RDR_Det_Attribute01 of type uint8
 *   FR_RDR_Det_Attribute02 of type uint8
 *   FR_RDR_Det_Attribute03 of type uint8
 *   FR_RDR_Det_Attribute04 of type uint8
 *   FR_RDR_Det_Attribute05 of type uint8
 *   FR_RDR_Det_Attribute06 of type uint8
 *   FR_RDR_Det_Attribute07 of type uint8
 *   FR_RDR_Det_Attribute08 of type uint8
 *   FR_RDR_Det_Attribute09 of type uint8
 *   FR_RDR_Det_Attribute10 of type uint8
 *   FR_RDR_Det_Attribute11 of type uint8
 *   FR_RDR_Det_Attribute12 of type uint8
 *   FR_RDR_Det_Attribute13 of type uint8
 *   FR_RDR_Det_Attribute14 of type uint8
 *   FR_RDR_Det_Attribute15 of type uint8
 *   FR_RDR_Det_Attribute16 of type uint8
 *   FR_RDR_Det_Attribute17 of type uint8
 *   FR_RDR_Det_Attribute18 of type uint8
 *   FR_RDR_Det_Attribute19 of type uint8
 *   FR_RDR_Det_Attribute20 of type uint8
 *   FR_RDR_Det_Attribute21 of type uint8
 *   FR_RDR_Det_Attribute22 of type uint8
 *   FR_RDR_Det_Attribute23 of type uint8
 *   FR_RDR_Det_Attribute24 of type uint8
 *   FR_RDR_Det_Attribute25 of type uint8
 *   FR_RDR_Det_Attribute26 of type uint8
 *   FR_RDR_Det_Attribute27 of type uint8
 *   FR_RDR_Det_Attribute28 of type uint8
 *   FR_RDR_Det_Attribute29 of type uint8
 *   FR_RDR_Det_Attribute30 of type uint8
 *   FR_RDR_Det_Attribute31 of type uint8
 *   FR_RDR_Det_Attribute32 of type uint8
 *   FR_RDR_Det_Attribute33 of type uint8
 *   FR_RDR_Det_Attribute34 of type uint8
 *   FR_RDR_Det_Attribute35 of type uint8
 *   FR_RDR_Det_Attribute36 of type uint8
 *   FR_RDR_Det_Attribute37 of type uint8
 *   FR_RDR_Det_Attribute38 of type uint8
 *   FR_RDR_Det_Attribute39 of type uint8
 *   FR_RDR_Det_Attribute40 of type uint8
 *   FR_RDR_Det_Attribute41 of type uint8
 *   FR_RDR_Det_Attribute42 of type uint8
 *   FR_RDR_Det_Attribute43 of type uint8
 *   FR_RDR_Det_Attribute44 of type uint8
 *   FR_RDR_Det_Attribute45 of type uint8
 *   FR_RDR_Det_Attribute46 of type uint8
 *   FR_RDR_Det_Attribute47 of type uint8
 *   FR_RDR_Det_Attribute48 of type uint8
 *   FR_RDR_Det_Attribute49 of type uint8
 *   FR_RDR_Det_Attribute50 of type uint8
 *   FR_RDR_Det_Attribute51 of type uint8
 *   FR_RDR_Det_Attribute52 of type uint8
 *   FR_RDR_Det_Attribute53 of type uint8
 *   FR_RDR_Det_Attribute54 of type uint8
 *   FR_RDR_Det_Attribute55 of type uint8
 *   FR_RDR_Det_Attribute56 of type uint8
 *   FR_RDR_Det_Attribute57 of type uint8
 *   FR_RDR_Det_Attribute58 of type uint8
 *   FR_RDR_Det_Attribute59 of type uint8
 *   FR_RDR_Det_Attribute60 of type uint8
 *   FR_RDR_Det_Attribute61 of type uint8
 *   FR_RDR_Det_Attribute62 of type uint8
 *   FR_RDR_Det_Attribute63 of type uint8
 *   FR_RDR_Det_Attribute64 of type uint8
 *   FR_RDR_Det_TrustA01 of type uint8
 *   FR_RDR_Det_TrustA02 of type uint8
 *   FR_RDR_Det_TrustA03 of type uint8
 *   FR_RDR_Det_TrustA04 of type uint8
 *   FR_RDR_Det_TrustA05 of type uint8
 *   FR_RDR_Det_TrustA06 of type uint8
 *   FR_RDR_Det_TrustA07 of type uint8
 *   FR_RDR_Det_TrustA08 of type uint8
 *   FR_RDR_Det_TrustA09 of type uint8
 *   FR_RDR_Det_TrustA10 of type uint8
 *   FR_RDR_Det_TrustA11 of type uint8
 *   FR_RDR_Det_TrustA12 of type uint8
 *   FR_RDR_Det_TrustA13 of type uint8
 *   FR_RDR_Det_TrustA14 of type uint8
 *   FR_RDR_Det_TrustA15 of type uint8
 *   FR_RDR_Det_TrustA16 of type uint8
 *   FR_RDR_Det_TrustA17 of type uint8
 *   FR_RDR_Det_TrustA18 of type uint8
 *   FR_RDR_Det_TrustA19 of type uint8
 *   FR_RDR_Det_TrustA20 of type uint8
 *   FR_RDR_Det_TrustA21 of type uint8
 *   FR_RDR_Det_TrustA22 of type uint8
 *   FR_RDR_Det_TrustA23 of type uint8
 *   FR_RDR_Det_TrustA24 of type uint8
 *   FR_RDR_Det_TrustA25 of type uint8
 *   FR_RDR_Det_TrustA26 of type uint8
 *   FR_RDR_Det_TrustA27 of type uint8
 *   FR_RDR_Det_TrustA28 of type uint8
 *   FR_RDR_Det_TrustA29 of type uint8
 *   FR_RDR_Det_TrustA30 of type uint8
 *   FR_RDR_Det_TrustA31 of type uint8
 *   FR_RDR_Det_TrustA32 of type uint8
 *   FR_RDR_Det_TrustA33 of type uint8
 *   FR_RDR_Det_TrustA34 of type uint8
 *   FR_RDR_Det_TrustA35 of type uint8
 *   FR_RDR_Det_TrustA36 of type uint8
 *   FR_RDR_Det_TrustA37 of type uint8
 *   FR_RDR_Det_TrustA38 of type uint8
 *   FR_RDR_Det_TrustA39 of type uint8
 *   FR_RDR_Det_TrustA40 of type uint8
 *   FR_RDR_Det_TrustA41 of type uint8
 *   FR_RDR_Det_TrustA42 of type uint8
 *   FR_RDR_Det_TrustA43 of type uint8
 *   FR_RDR_Det_TrustA44 of type uint8
 *   FR_RDR_Det_TrustA45 of type uint8
 *   FR_RDR_Det_TrustA46 of type uint8
 *   FR_RDR_Det_TrustA47 of type uint8
 *   FR_RDR_Det_TrustA48 of type uint8
 *   FR_RDR_Det_TrustA49 of type uint8
 *   FR_RDR_Det_TrustA50 of type uint8
 *   FR_RDR_Det_TrustA51 of type uint8
 *   FR_RDR_Det_TrustA52 of type uint8
 *   FR_RDR_Det_TrustA53 of type uint8
 *   FR_RDR_Det_TrustA54 of type uint8
 *   FR_RDR_Det_TrustA55 of type uint8
 *   FR_RDR_Det_TrustA56 of type uint8
 *   FR_RDR_Det_TrustA57 of type uint8
 *   FR_RDR_Det_TrustA58 of type uint8
 *   FR_RDR_Det_TrustA59 of type uint8
 *   FR_RDR_Det_TrustA60 of type uint8
 *   FR_RDR_Det_TrustA61 of type uint8
 *   FR_RDR_Det_TrustA62 of type uint8
 *   FR_RDR_Det_TrustA63 of type uint8
 *   FR_RDR_Det_TrustA64 of type uint8
 *   FR_RDR_Obj_AlvCnt01Val of type uint8
 *   FR_RDR_Obj_AlvCnt02Val of type uint8
 *   FR_RDR_Obj_AlvCnt03Val of type uint8
 *   FR_RDR_Obj_AlvCnt04Val of type uint8
 *   FR_RDR_Obj_AlvCnt05Val of type uint8
 *   FR_RDR_Obj_AlvCnt06Val of type uint8
 *   FR_RDR_Obj_AlvCnt07Val of type uint8
 *   FR_RDR_Obj_AlvCnt08Val of type uint8
 *   FR_RDR_Obj_AlvCnt09Val of type uint8
 *   FR_RDR_Obj_AlvCnt10Val of type uint8
 *   FR_RDR_Obj_AlvCnt11Val of type uint8
 *   FR_RDR_Obj_AlvCnt12Val of type uint8
 *   FR_RDR_Obj_AlvCnt13Val of type uint8
 *   FR_RDR_Obj_AlvCnt14Val of type uint8
 *   FR_RDR_Obj_AlvCnt15Val of type uint8
 *   FR_RDR_Obj_AlvCnt16Val of type uint8
 *   FR_RDR_Obj_TrkSta01Sta of type uint8
 *   FR_RDR_Obj_TrkSta02Sta of type uint8
 *   FR_RDR_Obj_TrkSta03Sta of type uint8
 *   FR_RDR_Obj_TrkSta04Sta of type uint8
 *   FR_RDR_Obj_TrkSta05Sta of type uint8
 *   FR_RDR_Obj_TrkSta06Sta of type uint8
 *   FR_RDR_Obj_TrkSta07Sta of type uint8
 *   FR_RDR_Obj_TrkSta08Sta of type uint8
 *   FR_RDR_Obj_TrkSta09Sta of type uint8
 *   FR_RDR_Obj_TrkSta10Sta of type uint8
 *   FR_RDR_Obj_TrkSta11Sta of type uint8
 *   FR_RDR_Obj_TrkSta12Sta of type uint8
 *   FR_RDR_Obj_TrkSta13Sta of type uint8
 *   FR_RDR_Obj_TrkSta14Sta of type uint8
 *   FR_RDR_Obj_TrkSta15Sta of type uint8
 *   FR_RDR_Obj_TrkSta16Sta of type uint8
 *   FR_RDR_Obj_TrkSta17Sta of type uint8
 *   FR_RDR_Obj_TrkSta18Sta of type uint8
 *   FR_RDR_Obj_TrkSta19Sta of type uint8
 *   FR_RDR_Obj_TrkSta20Sta of type uint8
 *   FR_RDR_Obj_TrkSta21Sta of type uint8
 *   FR_RDR_Obj_TrkSta22Sta of type uint8
 *   FR_RDR_Obj_TrkSta23Sta of type uint8
 *   FR_RDR_Obj_TrkSta24Sta of type uint8
 *   FR_RDR_Obj_TrkSta25Sta of type uint8
 *   FR_RDR_Obj_TrkSta26Sta of type uint8
 *   FR_RDR_Obj_TrkSta27Sta of type uint8
 *   FR_RDR_Obj_TrkSta28Sta of type uint8
 *   FR_RDR_Obj_TrkSta29Sta of type uint8
 *   FR_RDR_Obj_TrkSta30Sta of type uint8
 *   FR_RDR_Obj_TrkSta31Sta of type uint8
 *   FR_RDR_Obj_TrkSta32Sta of type uint8
 *   FR_RDR_Obj_MvngFlag01Sta of type uint8
 *   FR_RDR_Obj_MvngFlag02Sta of type uint8
 *   FR_RDR_Obj_MvngFlag03Sta of type uint8
 *   FR_RDR_Obj_MvngFlag04Sta of type uint8
 *   FR_RDR_Obj_MvngFlag05Sta of type uint8
 *   FR_RDR_Obj_MvngFlag06Sta of type uint8
 *   FR_RDR_Obj_MvngFlag07Sta of type uint8
 *   FR_RDR_Obj_MvngFlag08Sta of type uint8
 *   FR_RDR_Obj_MvngFlag09Sta of type uint8
 *   FR_RDR_Obj_MvngFlag10Sta of type uint8
 *   FR_RDR_Obj_MvngFlag11Sta of type uint8
 *   FR_RDR_Obj_MvngFlag12Sta of type uint8
 *   FR_RDR_Obj_MvngFlag13Sta of type uint8
 *   FR_RDR_Obj_MvngFlag14Sta of type uint8
 *   FR_RDR_Obj_MvngFlag15Sta of type uint8
 *   FR_RDR_Obj_MvngFlag16Sta of type uint8
 *   FR_RDR_Obj_MvngFlag17Sta of type uint8
 *   FR_RDR_Obj_MvngFlag18Sta of type uint8
 *   FR_RDR_Obj_MvngFlag19Sta of type uint8
 *   FR_RDR_Obj_MvngFlag20Sta of type uint8
 *   FR_RDR_Obj_MvngFlag21Sta of type uint8
 *   FR_RDR_Obj_MvngFlag22Sta of type uint8
 *   FR_RDR_Obj_MvngFlag23Sta of type uint8
 *   FR_RDR_Obj_MvngFlag24Sta of type uint8
 *   FR_RDR_Obj_MvngFlag25Sta of type uint8
 *   FR_RDR_Obj_MvngFlag26Sta of type uint8
 *   FR_RDR_Obj_MvngFlag27Sta of type uint8
 *   FR_RDR_Obj_MvngFlag28Sta of type uint8
 *   FR_RDR_Obj_MvngFlag29Sta of type uint8
 *   FR_RDR_Obj_MvngFlag30Sta of type uint8
 *   FR_RDR_Obj_MvngFlag31Sta of type uint8
 *   FR_RDR_Obj_MvngFlag32Sta of type uint8
 *   FR_RDR_Obj_QualLvl01Sta of type uint8
 *   FR_RDR_Obj_QualLvl02Sta of type uint8
 *   FR_RDR_Obj_QualLvl03Sta of type uint8
 *   FR_RDR_Obj_QualLvl04Sta of type uint8
 *   FR_RDR_Obj_QualLvl05Sta of type uint8
 *   FR_RDR_Obj_QualLvl06Sta of type uint8
 *   FR_RDR_Obj_QualLvl07Sta of type uint8
 *   FR_RDR_Obj_QualLvl08Sta of type uint8
 *   FR_RDR_Obj_QualLvl09Sta of type uint8
 *   FR_RDR_Obj_QualLvl10Sta of type uint8
 *   FR_RDR_Obj_QualLvl11Sta of type uint8
 *   FR_RDR_Obj_QualLvl12Sta of type uint8
 *   FR_RDR_Obj_QualLvl13Sta of type uint8
 *   FR_RDR_Obj_QualLvl14Sta of type uint8
 *   FR_RDR_Obj_QualLvl15Sta of type uint8
 *   FR_RDR_Obj_QualLvl16Sta of type uint8
 *   FR_RDR_Obj_QualLvl17Sta of type uint8
 *   FR_RDR_Obj_QualLvl18Sta of type uint8
 *   FR_RDR_Obj_QualLvl19Sta of type uint8
 *   FR_RDR_Obj_QualLvl20Sta of type uint8
 *   FR_RDR_Obj_QualLvl21Sta of type uint8
 *   FR_RDR_Obj_QualLvl22Sta of type uint8
 *   FR_RDR_Obj_QualLvl23Sta of type uint8
 *   FR_RDR_Obj_QualLvl24Sta of type uint8
 *   FR_RDR_Obj_QualLvl25Sta of type uint8
 *   FR_RDR_Obj_QualLvl26Sta of type uint8
 *   FR_RDR_Obj_QualLvl27Sta of type uint8
 *   FR_RDR_Obj_QualLvl28Sta of type uint8
 *   FR_RDR_Obj_QualLvl29Sta of type uint8
 *   FR_RDR_Obj_QualLvl30Sta of type uint8
 *   FR_RDR_Obj_QualLvl31Sta of type uint8
 *   FR_RDR_Obj_QualLvl32Sta of type uint8
 *   FR_RDR_Obj_AlvAge01Val of type uint8
 *   FR_RDR_Obj_AlvAge02Val of type uint8
 *   FR_RDR_Obj_AlvAge03Val of type uint8
 *   FR_RDR_Obj_AlvAge04Val of type uint8
 *   FR_RDR_Obj_AlvAge05Val of type uint8
 *   FR_RDR_Obj_AlvAge06Val of type uint8
 *   FR_RDR_Obj_AlvAge07Val of type uint8
 *   FR_RDR_Obj_AlvAge08Val of type uint8
 *   FR_RDR_Obj_AlvAge09Val of type uint8
 *   FR_RDR_Obj_AlvAge10Val of type uint8
 *   FR_RDR_Obj_AlvAge11Val of type uint8
 *   FR_RDR_Obj_AlvAge12Val of type uint8
 *   FR_RDR_Obj_AlvAge13Val of type uint8
 *   FR_RDR_Obj_AlvAge14Val of type uint8
 *   FR_RDR_Obj_AlvAge15Val of type uint8
 *   FR_RDR_Obj_AlvAge16Val of type uint8
 *   FR_RDR_Obj_AlvAge17Val of type uint8
 *   FR_RDR_Obj_AlvAge18Val of type uint8
 *   FR_RDR_Obj_AlvAge19Val of type uint8
 *   FR_RDR_Obj_AlvAge20Val of type uint8
 *   FR_RDR_Obj_AlvAge21Val of type uint8
 *   FR_RDR_Obj_AlvAge22Val of type uint8
 *   FR_RDR_Obj_AlvAge23Val of type uint8
 *   FR_RDR_Obj_AlvAge24Val of type uint8
 *   FR_RDR_Obj_AlvAge25Val of type uint8
 *   FR_RDR_Obj_AlvAge26Val of type uint8
 *   FR_RDR_Obj_AlvAge27Val of type uint8
 *   FR_RDR_Obj_AlvAge28Val of type uint8
 *   FR_RDR_Obj_AlvAge29Val of type uint8
 *   FR_RDR_Obj_AlvAge30Val of type uint8
 *   FR_RDR_Obj_AlvAge31Val of type uint8
 *   FR_RDR_Obj_AlvAge32Val of type uint8
 *   FR_RDR_Obj_CoastAge01Val of type uint8
 *   FR_RDR_Obj_CoastAge02Val of type uint8
 *   FR_RDR_Obj_CoastAge03Val of type uint8
 *   FR_RDR_Obj_CoastAge04Val of type uint8
 *   FR_RDR_Obj_CoastAge05Val of type uint8
 *   FR_RDR_Obj_CoastAge06Val of type uint8
 *   FR_RDR_Obj_CoastAge07Val of type uint8
 *   FR_RDR_Obj_CoastAge08Val of type uint8
 *   FR_RDR_Obj_CoastAge09Val of type uint8
 *   FR_RDR_Obj_CoastAge10Val of type uint8
 *   FR_RDR_Obj_CoastAge11Val of type uint8
 *   FR_RDR_Obj_CoastAge12Val of type uint8
 *   FR_RDR_Obj_CoastAge13Val of type uint8
 *   FR_RDR_Obj_CoastAge14Val of type uint8
 *   FR_RDR_Obj_CoastAge15Val of type uint8
 *   FR_RDR_Obj_CoastAge16Val of type uint8
 *   FR_RDR_Obj_CoastAge17Val of type uint8
 *   FR_RDR_Obj_CoastAge18Val of type uint8
 *   FR_RDR_Obj_CoastAge19Val of type uint8
 *   FR_RDR_Obj_CoastAge20Val of type uint8
 *   FR_RDR_Obj_CoastAge21Val of type uint8
 *   FR_RDR_Obj_CoastAge22Val of type uint8
 *   FR_RDR_Obj_CoastAge23Val of type uint8
 *   FR_RDR_Obj_CoastAge24Val of type uint8
 *   FR_RDR_Obj_CoastAge25Val of type uint8
 *   FR_RDR_Obj_CoastAge26Val of type uint8
 *   FR_RDR_Obj_CoastAge27Val of type uint8
 *   FR_RDR_Obj_CoastAge28Val of type uint8
 *   FR_RDR_Obj_CoastAge29Val of type uint8
 *   FR_RDR_Obj_CoastAge30Val of type uint8
 *   FR_RDR_Obj_CoastAge31Val of type uint8
 *   FR_RDR_Obj_CoastAge32Val of type uint8
 *   FR_RDR_Obj_MedRangeMod01Val of type uint8
 *   FR_RDR_Obj_MedRangeMod02Val of type uint8
 *   FR_RDR_Obj_MedRangeMod03Val of type uint8
 *   FR_RDR_Obj_MedRangeMod04Val of type uint8
 *   FR_RDR_Obj_MedRangeMod05Val of type uint8
 *   FR_RDR_Obj_MedRangeMod06Val of type uint8
 *   FR_RDR_Obj_MedRangeMod07Val of type uint8
 *   FR_RDR_Obj_MedRangeMod08Val of type uint8
 *   FR_RDR_Obj_MedRangeMod09Val of type uint8
 *   FR_RDR_Obj_MedRangeMod10Val of type uint8
 *   FR_RDR_Obj_MedRangeMod11Val of type uint8
 *   FR_RDR_Obj_MedRangeMod12Val of type uint8
 *   FR_RDR_Obj_MedRangeMod13Val of type uint8
 *   FR_RDR_Obj_MedRangeMod14Val of type uint8
 *   FR_RDR_Obj_MedRangeMod15Val of type uint8
 *   FR_RDR_Obj_MedRangeMod16Val of type uint8
 *   FR_RDR_Obj_MedRangeMod17Val of type uint8
 *   FR_RDR_Obj_MedRangeMod18Val of type uint8
 *   FR_RDR_Obj_MedRangeMod19Val of type uint8
 *   FR_RDR_Obj_MedRangeMod20Val of type uint8
 *   FR_RDR_Obj_MedRangeMod21Val of type uint8
 *   FR_RDR_Obj_MedRangeMod22Val of type uint8
 *   FR_RDR_Obj_MedRangeMod23Val of type uint8
 *   FR_RDR_Obj_MedRangeMod24Val of type uint8
 *   FR_RDR_Obj_MedRangeMod25Val of type uint8
 *   FR_RDR_Obj_MedRangeMod26Val of type uint8
 *   FR_RDR_Obj_MedRangeMod27Val of type uint8
 *   FR_RDR_Obj_MedRangeMod28Val of type uint8
 *   FR_RDR_Obj_MedRangeMod29Val of type uint8
 *   FR_RDR_Obj_MedRangeMod30Val of type uint8
 *   FR_RDR_Obj_MedRangeMod31Val of type uint8
 *   FR_RDR_Obj_MedRangeMod32Val of type uint8
 *   FR_RDR_Obj_RefObjID01Val of type uint8
 *   FR_RDR_Obj_RefObjID02Val of type uint8
 *   FR_RDR_Obj_RefObjID03Val of type uint8
 *   FR_RDR_Obj_RefObjID04Val of type uint8
 *   FR_RDR_Obj_RefObjID05Val of type uint8
 *   FR_RDR_Obj_RefObjID06Val of type uint8
 *   FR_RDR_Obj_RefObjID07Val of type uint8
 *   FR_RDR_Obj_RefObjID08Val of type uint8
 *   FR_RDR_Obj_RefObjID09Val of type uint8
 *   FR_RDR_Obj_RefObjID10Val of type uint8
 *   FR_RDR_Obj_RefObjID11Val of type uint8
 *   FR_RDR_Obj_RefObjID12Val of type uint8
 *   FR_RDR_Obj_RefObjID13Val of type uint8
 *   FR_RDR_Obj_RefObjID14Val of type uint8
 *   FR_RDR_Obj_RefObjID15Val of type uint8
 *   FR_RDR_Obj_RefObjID16Val of type uint8
 *   FR_RDR_Obj_RefObjID17Val of type uint8
 *   FR_RDR_Obj_RefObjID18Val of type uint8
 *   FR_RDR_Obj_RefObjID19Val of type uint8
 *   FR_RDR_Obj_RefObjID20Val of type uint8
 *   FR_RDR_Obj_RefObjID21Val of type uint8
 *   FR_RDR_Obj_RefObjID22Val of type uint8
 *   FR_RDR_Obj_RefObjID23Val of type uint8
 *   FR_RDR_Obj_RefObjID24Val of type uint8
 *   FR_RDR_Obj_RefObjID25Val of type uint8
 *   FR_RDR_Obj_RefObjID26Val of type uint8
 *   FR_RDR_Obj_RefObjID27Val of type uint8
 *   FR_RDR_Obj_RefObjID28Val of type uint8
 *   FR_RDR_Obj_RefObjID29Val of type uint8
 *   FR_RDR_Obj_RefObjID30Val of type uint8
 *   FR_RDR_Obj_RefObjID31Val of type uint8
 *   FR_RDR_Obj_RefObjID32Val of type uint8
 *   FR_RDR_DTC_RadarAliveCounter of type uint8
 *   FR_RDR_DTC_BatteryVoltageHigh of type uint8
 *   FR_RDR_DTC_BatteryVoltageLow of type uint8
 *   FR_RDR_DTC_RadarHwError of type uint8
 *   FR_RDR_DTC_SystemOutOfCalibration_EOL of type uint8
 *   FR_RDR_DTC_SystemOutOfCalibration_DRV of type uint8
 *   FR_RDR_DTC_Blockage_Init of type uint8
 *   FR_RDR_DTC_Blockage_Drv of type uint8
 *   FR_RDR_DTC_RadarHwTempCondition_High of type uint8
 *   FR_RDR_DTC_RadarHwTempCondition_Low of type uint8
 *   FR_RDR_DTC_RadarCANCommError of type uint8
 *   FR_RDR_Det_Mov01 of type boolean
 *   FR_RDR_Det_Mov02 of type boolean
 *   FR_RDR_Det_Mov03 of type boolean
 *   FR_RDR_Det_Mov04 of type boolean
 *   FR_RDR_Det_Mov05 of type boolean
 *   FR_RDR_Det_Mov06 of type boolean
 *   FR_RDR_Det_Mov07 of type boolean
 *   FR_RDR_Det_Mov08 of type boolean
 *   FR_RDR_Det_Mov09 of type boolean
 *   FR_RDR_Det_Mov10 of type boolean
 *   FR_RDR_Det_Mov11 of type boolean
 *   FR_RDR_Det_Mov12 of type boolean
 *   FR_RDR_Det_Mov13 of type boolean
 *   FR_RDR_Det_Mov14 of type boolean
 *   FR_RDR_Det_Mov15 of type boolean
 *   FR_RDR_Det_Mov16 of type boolean
 *   FR_RDR_Det_Mov17 of type boolean
 *   FR_RDR_Det_Mov18 of type boolean
 *   FR_RDR_Det_Mov19 of type boolean
 *   FR_RDR_Det_Mov20 of type boolean
 *   FR_RDR_Det_Mov21 of type boolean
 *   FR_RDR_Det_Mov22 of type boolean
 *   FR_RDR_Det_Mov23 of type boolean
 *   FR_RDR_Det_Mov24 of type boolean
 *   FR_RDR_Det_Mov25 of type boolean
 *   FR_RDR_Det_Mov26 of type boolean
 *   FR_RDR_Det_Mov27 of type boolean
 *   FR_RDR_Det_Mov28 of type boolean
 *   FR_RDR_Det_Mov29 of type boolean
 *   FR_RDR_Det_Mov30 of type boolean
 *   FR_RDR_Det_Mov31 of type boolean
 *   FR_RDR_Det_Mov32 of type boolean
 *   FR_RDR_Det_Mov33 of type boolean
 *   FR_RDR_Det_Mov34 of type boolean
 *   FR_RDR_Det_Mov35 of type boolean
 *   FR_RDR_Det_Mov36 of type boolean
 *   FR_RDR_Det_Mov37 of type boolean
 *   FR_RDR_Det_Mov38 of type boolean
 *   FR_RDR_Det_Mov39 of type boolean
 *   FR_RDR_Det_Mov40 of type boolean
 *   FR_RDR_Det_Mov41 of type boolean
 *   FR_RDR_Det_Mov42 of type boolean
 *   FR_RDR_Det_Mov43 of type boolean
 *   FR_RDR_Det_Mov44 of type boolean
 *   FR_RDR_Det_Mov45 of type boolean
 *   FR_RDR_Det_Mov46 of type boolean
 *   FR_RDR_Det_Mov47 of type boolean
 *   FR_RDR_Det_Mov48 of type boolean
 *   FR_RDR_Det_Mov49 of type boolean
 *   FR_RDR_Det_Mov50 of type boolean
 *   FR_RDR_Det_Mov51 of type boolean
 *   FR_RDR_Det_Mov52 of type boolean
 *   FR_RDR_Det_Mov53 of type boolean
 *   FR_RDR_Det_Mov54 of type boolean
 *   FR_RDR_Det_Mov55 of type boolean
 *   FR_RDR_Det_Mov56 of type boolean
 *   FR_RDR_Det_Mov57 of type boolean
 *   FR_RDR_Det_Mov58 of type boolean
 *   FR_RDR_Det_Mov59 of type boolean
 *   FR_RDR_Det_Mov60 of type boolean
 *   FR_RDR_Det_Mov61 of type boolean
 *   FR_RDR_Det_Mov62 of type boolean
 *   FR_RDR_Det_Mov63 of type boolean
 *   FR_RDR_Det_Mov64 of type boolean
 *   FR_RDR_Det_Valid01 of type boolean
 *   FR_RDR_Det_Valid02 of type boolean
 *   FR_RDR_Det_Valid03 of type boolean
 *   FR_RDR_Det_Valid04 of type boolean
 *   FR_RDR_Det_Valid05 of type boolean
 *   FR_RDR_Det_Valid06 of type boolean
 *   FR_RDR_Det_Valid07 of type boolean
 *   FR_RDR_Det_Valid08 of type boolean
 *   FR_RDR_Det_Valid09 of type boolean
 *   FR_RDR_Det_Valid10 of type boolean
 *   FR_RDR_Det_Valid11 of type boolean
 *   FR_RDR_Det_Valid12 of type boolean
 *   FR_RDR_Det_Valid13 of type boolean
 *   FR_RDR_Det_Valid14 of type boolean
 *   FR_RDR_Det_Valid15 of type boolean
 *   FR_RDR_Det_Valid16 of type boolean
 *   FR_RDR_Det_Valid17 of type boolean
 *   FR_RDR_Det_Valid18 of type boolean
 *   FR_RDR_Det_Valid19 of type boolean
 *   FR_RDR_Det_Valid20 of type boolean
 *   FR_RDR_Det_Valid21 of type boolean
 *   FR_RDR_Det_Valid22 of type boolean
 *   FR_RDR_Det_Valid23 of type boolean
 *   FR_RDR_Det_Valid24 of type boolean
 *   FR_RDR_Det_Valid25 of type boolean
 *   FR_RDR_Det_Valid26 of type boolean
 *   FR_RDR_Det_Valid27 of type boolean
 *   FR_RDR_Det_Valid28 of type boolean
 *   FR_RDR_Det_Valid29 of type boolean
 *   FR_RDR_Det_Valid30 of type boolean
 *   FR_RDR_Det_Valid31 of type boolean
 *   FR_RDR_Det_Valid32 of type boolean
 *   FR_RDR_Det_Valid33 of type boolean
 *   FR_RDR_Det_Valid34 of type boolean
 *   FR_RDR_Det_Valid35 of type boolean
 *   FR_RDR_Det_Valid36 of type boolean
 *   FR_RDR_Det_Valid37 of type boolean
 *   FR_RDR_Det_Valid38 of type boolean
 *   FR_RDR_Det_Valid39 of type boolean
 *   FR_RDR_Det_Valid40 of type boolean
 *   FR_RDR_Det_Valid41 of type boolean
 *   FR_RDR_Det_Valid42 of type boolean
 *   FR_RDR_Det_Valid43 of type boolean
 *   FR_RDR_Det_Valid44 of type boolean
 *   FR_RDR_Det_Valid45 of type boolean
 *   FR_RDR_Det_Valid46 of type boolean
 *   FR_RDR_Det_Valid47 of type boolean
 *   FR_RDR_Det_Valid48 of type boolean
 *   FR_RDR_Det_Valid49 of type boolean
 *   FR_RDR_Det_Valid50 of type boolean
 *   FR_RDR_Det_Valid51 of type boolean
 *   FR_RDR_Det_Valid52 of type boolean
 *   FR_RDR_Det_Valid53 of type boolean
 *   FR_RDR_Det_Valid54 of type boolean
 *   FR_RDR_Det_Valid55 of type boolean
 *   FR_RDR_Det_Valid56 of type boolean
 *   FR_RDR_Det_Valid57 of type boolean
 *   FR_RDR_Det_Valid58 of type boolean
 *   FR_RDR_Det_Valid59 of type boolean
 *   FR_RDR_Det_Valid60 of type boolean
 *   FR_RDR_Det_Valid61 of type boolean
 *   FR_RDR_Det_Valid62 of type boolean
 *   FR_RDR_Det_Valid63 of type boolean
 *   FR_RDR_Det_Valid64 of type boolean
 * SccRdrBlockage_t: Record with elements
 *   u8_Blockage_Drv of type uint8
 *   u8_Blockage_Init of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   RdrInfo_t *Rte_Pim_RdrInfo(void)
 *
 *********************************************************************************************************************/


#define CpApPCan_START_SEC_CODE
#include "CpApPCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPCan_CODE) Re_CpApPCanInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(COM_DT_SG_RD_DTC_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_ADAS101_De_ADAS101(ADAS101_t *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_FCA_FCA(uint8 *data)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(void)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_RadarDtcInfo_RadarDtcInfo(const RadarDtcInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccRdrBlockage_De_SccRdrBlockage(const SccRdrBlockage_t *data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_RP_PCan_BusOFFStatus_BSW_BswM_MDGP_BswMPCAN_RteModeDclGroup(void)
 *   Modes of Rte_ModeType_BswMPCAN_RteModeDclGroup:
 *   - RTE_MODE_BswMPCAN_RteModeDclGroup_PCANBusoff
 *   - RTE_MODE_BswMPCAN_RteModeDclGroup_PCANNormal
 *   - RTE_TRANSITION_BswMPCAN_RteModeDclGroup
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPCan_CODE) Re_CpApPCanMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_VehicleMY_VehicleMY(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_ADAS101_2Gen_SignalGroup_COM_SG_ADAS101_2Gen_SignalGroup(const COM_DT_SG_ADAS101_2Gen_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS101_3Gen_SignalGroup_COM_SG_ADAS101_3Gen_SignalGroup(const COM_DT_SG_ADAS101_3Gen_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_CodingForRadar_COM_SG_CodingForRadar(const COM_DT_SG_CodingForRadar *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanOut_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPCan_CODE) Re_CpApPCanOut(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPCanOut
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApRdrmsg
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getRdrInfo> of PortPrototype <PP_RdrInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApRdrmsg(RdrInfo_t *Rdrmsg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_RdrInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApRdrmsg_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApPCan_CODE) Re_CpApRdrmsg(P2VAR(RdrInfo_t, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) Rdrmsg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApRdrmsg (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApPCan_STOP_SEC_CODE
#include "CpApPCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
