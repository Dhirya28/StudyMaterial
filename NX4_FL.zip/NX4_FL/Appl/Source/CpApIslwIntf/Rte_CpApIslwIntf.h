/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApIslwIntf.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIslwIntf
 *  Generation Time:  2023-04-20 13:52:35
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApIslwIntf> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPISLWINTF_H
# define _RTE_CPAPISLWINTF_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApIslwIntf_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApIslwIntf
{
  /* PIM Handles section */
  P2VAR(Arr_TsrInfo, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_Arr_TsrInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IslwFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_IslwFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IslwOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_IslwOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApIslwIntf, RTE_CONST, RTE_CONST) Rte_Inst_CpApIslwIntf; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApIslwIntf, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_RP_DrivingSideStatus_De_DrivingSideStatus (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_RxMsgsInFrame (0ULL)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslwIntf_RP_DrivingSideStatus_De_DrivingSideStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslwIntf_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslwIntf_RP_EyeQ_FrameReady_RxMsgsInFrame(P2VAR(uint64, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApIslwIntf_RP_LssMeInfo_De_LssMeInfo(P2VAR(LssMeInfo_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(P2VAR(EYEQMESP_EnvironmentParams_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EYEQMESP_ReadVehicleCalParams_EYEQMESP_ReadVehicleCalParams(P2VAR(EYEQMESP_VehicleCalParams_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C0(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C0); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C1(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C2(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Buffer_C5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Camera_Source(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Camera_Source); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Existence_Probability(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Existence_Probability); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Measurement_Status(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Measurement_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Object_Property(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Object_Property); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Relevancy); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Relevancy_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Lat_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Lat_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Long_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Long_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Name(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Name); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Panel_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Panel_Height_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Panel_Width); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width_STD(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Panel_Width_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Shape(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sign_Shape); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup1_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Position(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup1_Position); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_SignName(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup1_SignName); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup2_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Position(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup2_Position); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_SignName(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sup2_SignName); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Age(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Tracking_Age); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Out_of_Image(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_Tracking_Out_of_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_is_Electronic(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) DSTSR_is_Electronic); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_1(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_10(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_10); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_11(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_11); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_12(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_12); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_2(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_2); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_3(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_3); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_4(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_4); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_5(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_5); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_6(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_6); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_7(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_7); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_8(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_9(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) Reserved_9); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) MainState_pu8, P2VAR(uint8, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) SubState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_NvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_NvMService_IslwFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_NvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApIslwIntf_RP_NvMService_IslwOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_DrivingSideStatus_De_DrivingSideStatus Rte_Read_CpApIslwIntf_RP_DrivingSideStatus_De_DrivingSideStatus
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApIslwIntf_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame Rte_Read_CpApIslwIntf_RP_EyeQ_FrameReady_RxMsgsInFrame
# define Rte_Read_RP_LssMeInfo_De_LssMeInfo Rte_Read_CpApIslwIntf_RP_LssMeInfo_De_LssMeInfo


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApIslwIntf_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams Rte_Call_CpApIslwIntf_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams
# define Rte_Call_RP_EYEQMESP_ReadVehicleCalParams_EYEQMESP_ReadVehicleCalParams Rte_Call_CpApIslwIntf_RP_EYEQMESP_ReadVehicleCalParams_EYEQMESP_ReadVehicleCalParams
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C0 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C0
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C1 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C2 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C2
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C3 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C3
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C4 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C4
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C5 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C5
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Camera_Source Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Camera_Source
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Confidence Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Existence_Probability Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Existence_Probability
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_ID Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_ID
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Measurement_Status Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Measurement_Status
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Object_Property Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Object_Property
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Protocol_Version Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy_Confidence Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Count Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Count
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height_STD Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance_STD Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance_STD Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Name Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Name
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height_STD Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height_STD
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width_STD Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width_STD
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Shape Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Shape
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Confidence Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Position Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Position
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_SignName Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_SignName
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Confidence Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Position Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Position
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_SignName Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_SignName
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sync_ID Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Age Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Age
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Out_of_Image Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Out_of_Image
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_is_Electronic Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_is_Electronic
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_1 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_1
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_10 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_10
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_11 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_11
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_12 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_12
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_2 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_2
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_3 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_3
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_4 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_4
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_5 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_5
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_6 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_6
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_7 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_7
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_8 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_8
# define Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_9 Rte_Call_CpApIslwIntf_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_9
# define Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState Rte_Call_CpApIslwIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApIslwIntf_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_NvMService_IslwFrqNvData_ReadBlock Rte_Call_CpApIslwIntf_RP_NvMService_IslwFrqNvData_ReadBlock
# define Rte_Call_RP_NvMService_IslwFrqNvData_WriteBlock Rte_Call_CpApIslwIntf_RP_NvMService_IslwFrqNvData_WriteBlock
# define Rte_Call_RP_NvMService_IslwOccNvData_ReadBlock Rte_Call_CpApIslwIntf_RP_NvMService_IslwOccNvData_ReadBlock
# define Rte_Call_RP_NvMService_IslwOccNvData_WriteBlock Rte_Call_CpApIslwIntf_RP_NvMService_IslwOccNvData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_Arr_TsrInfo() (Rte_Inst_CpApIslwIntf->Pim_Arr_TsrInfo) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_IslwFrqNvData() (Rte_Inst_CpApIslwIntf->Pim_IslwFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_IslwOccNvData() (Rte_Inst_CpApIslwIntf->Pim_IslwOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   Arr_TsrInfo *Rte_Pim_Arr_TsrInfo(void)
 *   IslwFrqNvData_t *Rte_Pim_IslwFrqNvData(void)
 *   IslwOccNvData_t *Rte_Pim_IslwOccNvData(void)
 *
 *********************************************************************************************************************/


# define CpApIslwIntf_START_SEC_CODE
# include "CpApIslwIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished
FUNC(void, CpApIslwIntf_CODE) CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished
FUNC(void, CpApIslwIntf_CODE) CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_DrivingSideStatus_De_DrivingSideStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *   Std_ReturnType Rte_Read_RP_LssMeInfo_De_LssMeInfo(LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadVehicleCalParams_EYEQMESP_ReadVehicleCalParams(EYEQMESP_VehicleCalParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadVehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C0(uint16 Index, uint16 *DSTSR_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C1(uint16 Index, uint16 *DSTSR_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C2(uint16 Index, uint16 *DSTSR_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C3(uint16 Index, uint8 *DSTSR_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C4(uint16 Index, uint8 *DSTSR_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C5(uint16 Index, uint8 *DSTSR_Buffer_C5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Camera_Source(uint16 Index, uint8 *DSTSR_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Confidence(uint16 Index, uint8 *DSTSR_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Existence_Probability(uint16 Index, uint8 *DSTSR_Existence_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_ID(uint16 Index, uint8 *DSTSR_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Measurement_Status(uint16 Index, uint8 *DSTSR_Measurement_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Object_Property(uint16 Index, uint8 *DSTSR_Object_Property)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Protocol_Version(uint8 *DSTSR_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy(uint16 Index, uint8 *DSTSR_Relevancy)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy_Confidence(uint16 Index, uint8 *DSTSR_Relevancy_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Count(uint8 *DSTSR_Sign_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height(uint16 Index, uint16 *DSTSR_Sign_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height_STD(uint16 Index, uint16 *DSTSR_Sign_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance(uint16 Index, uint16 *DSTSR_Sign_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance_STD(uint16 Index, uint16 *DSTSR_Sign_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance(uint16 Index, uint16 *DSTSR_Sign_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance_STD(uint16 Index, uint16 *DSTSR_Sign_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Name(uint16 Index, uint16 *DSTSR_Sign_Name)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height(uint16 Index, uint16 *DSTSR_Sign_Panel_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height_STD(uint16 Index, uint16 *DSTSR_Sign_Panel_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width(uint16 Index, uint16 *DSTSR_Sign_Panel_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width_STD(uint16 Index, uint16 *DSTSR_Sign_Panel_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Shape(uint16 Index, uint8 *DSTSR_Sign_Shape)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Confidence(uint16 Index, uint8 *DSTSR_Sup1_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Position(uint16 Index, uint8 *DSTSR_Sup1_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_SignName(uint16 Index, uint8 *DSTSR_Sup1_SignName)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Confidence(uint16 Index, uint8 *DSTSR_Sup2_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Position(uint16 Index, uint8 *DSTSR_Sup2_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_SignName(uint16 Index, uint8 *DSTSR_Sup2_SignName)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sync_ID(uint8 *DSTSR_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Age(uint16 Index, uint16 *DSTSR_Tracking_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Out_of_Image(uint16 Index, uint16 *DSTSR_Tracking_Out_of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_is_Electronic(uint16 Index, uint8 *DSTSR_is_Electronic)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_10(uint16 Index, uint8 *Reserved_10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_11(uint16 Index, uint8 *Reserved_11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_12(uint16 Index, uint32 *Reserved_12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_8(uint16 Index, uint16 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_9(uint16 Index, uint8 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfEyeQRead Re_CpApIslwIntfEyeQRead
FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfEyeQRead(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfInit Re_CpApIslwIntfInit
FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfIslwEyeQInput
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getIslwEyeQInput> of PortPrototype <PP_IslwEyeQInput>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApIslwIntfIslwEyeQInput(IslwEyeQInput_t *IslwEyeQInput)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfIslwEyeQInput Re_CpApIslwIntfIslwEyeQInput
FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfIslwEyeQInput(P2VAR(IslwEyeQInput_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwEyeQInput); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfMain Re_CpApIslwIntfMain
FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfReadIslwFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadIslwFrqNvData> of PortPrototype <PP_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfReadIslwFrqNvData(IslwFrqNvData_t *IslwFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfReadIslwFrqNvData Re_CpApIslwIntfReadIslwFrqNvData
FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfReadIslwFrqNvData(P2VAR(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfReadIslwOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadIslwOccNvData> of PortPrototype <PP_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfReadIslwOccNvData(IslwOccNvData_t *IslwOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfReadIslwOccNvData Re_CpApIslwIntfReadIslwOccNvData
FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfReadIslwOccNvData(P2VAR(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfTsrInfo
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getTsrInfo> of PortPrototype <PP_TsrInfo>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApIslwIntfTsrInfo(IslwTSRInfo_t *TsrInfo)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfTsrInfo Re_CpApIslwIntfTsrInfo
FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfTsrInfo(P2VAR(IslwTSRInfo_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) TsrInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfWriteIslwFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteIslwFrqNvData> of PortPrototype <PP_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfWriteIslwFrqNvData(const IslwFrqNvData_t *IslwFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfWriteIslwFrqNvData Re_CpApIslwIntfWriteIslwFrqNvData
FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfWriteIslwFrqNvData(P2CONST(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_DATA) IslwFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfWriteIslwOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteIslwOccNvData> of PortPrototype <PP_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfWriteIslwOccNvData(const IslwOccNvData_t *IslwOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApIslwIntfWriteIslwOccNvData Re_CpApIslwIntfWriteIslwOccNvData
FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfWriteIslwOccNvData(P2CONST(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_DATA) IslwOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApIslwIntf_STOP_SEC_CODE
# include "CpApIslwIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_ReadVehicleCalParams_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType (1U)

# define RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_IslwFrqNvData_ReturnType (1U)

# define RTE_E_IF_IslwOccNvData_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPISLWINTF_H */
