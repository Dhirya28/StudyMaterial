/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApFca.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApFca
 *  Generation Time:  2023-04-20 13:53:21
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApFca>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * TimeInMicrosecondsType
 *   uint32 represents integers with a minimum value of 0 and a maximum value 
 *      of 4294967295. The order-relation on uint32 is: x < y if y - x is positive.
 *      uint32 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39). 
 *      
 *      For example: 1, 0, 12234567, 104400.
 *
 *
 * Operation Prototypes:
 * =====================
 * GetCounterValue of Port Interface Os_Service
 *   This service reads the current count value of a counter (returning either the hardware timer ticks if counter is driven by hardware or the software ticks when user drives counter).
 *
 * GetElapsedValue of Port Interface Os_Service
 *   This service gets the number of ticks between the current tick value and a previously read tick value.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApFca.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * TimeInMicrosecondsType: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * ADAS101_t: Record with elements
 *   CALR of type uint16
 *   VN of type uint16
 *   p_YRS_YawRtVal of type uint16
 *   p_OutTempCSta of type uint8
 *   p_WHL_SpdFLVal of type uint16
 *   p_WHL_SpdFRVal of type uint16
 *   p_WHL_SpdRLVal of type uint16
 *   p_WHL_SpdRRVal of type uint16
 *   p_SAS_AnglVal of type sint16
 *   p_TCU_GearSlctDis of type uint8
 *   p_ICU_MtGearPosRSta of type uint8
 *   p_ENG_EngSta of type uint8
 *   p_ENG_IsgSta of type uint8
 *   p_CF_ECU_SSC_STAT of type uint8
 *   p_HCU_HevRdySta of type uint8
 *   p_ABS_DiagSta of type uint8
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * DeLogicDbgInput_t: Record with elements
 *   u32_DbgDataIn_01 of type uint32
 *   u32_DbgDataIn_02 of type uint32
 *   u32_DbgDataIn_03 of type uint32
 *   u32_DbgDataIn_04 of type uint32
 *   u32_DbgDataIn_05 of type uint32
 *   u32_DbgDataIn_06 of type uint32
 *   u32_DbgDataIn_07 of type uint32
 *   u32_DbgDataIn_08 of type uint32
 *   u32_DbgDataIn_09 of type uint32
 *   u32_DbgDataIn_10 of type uint32
 *   u32_DbgDataIn_11 of type uint32
 *   u32_DbgDataIn_12 of type uint32
 *   u32_DbgDataIn_13 of type uint32
 *   u32_DbgDataIn_14 of type uint32
 *   u32_DbgDataIn_15 of type uint32
 *   u32_DbgDataIn_16 of type uint32
 * DeLogicDbgOutput_t: Record with elements
 *   u32_DbgData_01 of type uint32
 *   u32_DbgData_02 of type uint32
 *   u32_DbgData_03 of type uint32
 *   u32_DbgData_04 of type uint32
 *   u32_DbgData_05 of type uint32
 *   u32_DbgData_06 of type uint32
 *   u32_DbgData_07 of type uint32
 *   u32_DbgData_08 of type uint32
 *   u32_DbgData_09 of type uint32
 *   u32_DbgData_10 of type uint32
 *   u32_DbgData_11 of type uint32
 *   u32_DbgData_12 of type uint32
 *   u32_DbgData_13 of type uint32
 *   u32_DbgData_14 of type uint32
 *   u32_DbgData_15 of type uint32
 *   u32_DbgData_16 of type uint32
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FailSafe_t: Record with elements
 *   FS_CRC of type uint32
 *   FS_Camera_ID of type uint8
 *   FS_Free_Sight of type boolean
 *   FS_Splashes of type uint8
 *   FS_Sun_Ray of type uint8
 *   FS_Low_Sun of type uint8
 *   FS_Blur_Image of type uint8
 *   FS_Partial_Blockage of type uint8
 *   FS_Full_Blockage of type uint8
 *   FS_Frozen_Windshield_Lens of type uint8
 *   FS_Out_Of_Focus of type uint8
 *   FS_C2C_Out_Of_Calib of type uint8
 * FcaAppVersionInfo_t: Record with elements
 *   u16_FcaAppVersion of type uint16
 * FcaEDR_t: Record with elements
 *   EgoVeh_Speed of type uint16
 *   TTC of type uint8
 *   RelativeVelocity of type uint16
 *   LongDistance of type uint16
 *   LatDistance of type uint16
 * FcaFailSafeInfo_t: Record with elements
 *   p_EngineRun of type uint8
 *   p_TrailerMsgTout of type uint8
 *   p_EcuOverVolt_Fail of type uint8
 *   p_EcuUndVolt_Fail of type uint8
 *   p_MalfuncbyCam_Fail of type uint8
 *   p_EmsMsgTout_Fail of type uint8
 *   p_TcuMsgTout_Fail of type uint8
 *   p_EmsSig_Fail of type uint8
 *   p_HcuVcuFcuMsgTout_Fail of type uint8
 *   p_EcanBusOff_Fail of type uint8
 *   p_HcuVcuFcuSig_Fail of type uint8
 *   p_StrAngTout_Fail of type uint8
 *   p_EspMsgTout_Fail of type uint8
 *   p_ABSESPSig_Fail of type uint8
 *   p_AcuMsgTout_Fail of type uint8
 *   p_EscVarErr_Fail of type uint8
 *   p_EscRvsbFCA_Fail of type uint8
 *   p_TcuSig_Fail of type uint8
 *   p_FrRdr_Fail of type uint8
 *   p_IcuMsgTout_Normal_Fail of type uint8
 *   p_IcuMsgTout_JTFcn_Fail of type uint8
 *   p_FuncVarErr_Fail of type uint8
 *   p_StrAngMsg_Fail of type uint8
 *   p_YrSen_Fail of type uint8
 *   p_FcaComm_Fail of type uint8
 *   p_IBUMsgTout_Fail of type uint8
 *   p_RwsMsgTout_Fail of type uint8
 *   p_RwsComm_Fail of type uint8
 *   p_MFSWTout_Fail of type uint8
 *   p_ILCUMsgTout_Fail of type uint8
 *   p_FrRdrOvrTemp_Fail of type uint8
 *   p_FrRdrBlockage_Fail of type uint8
 *   p_FrRdrNotFoundTarget_Fail of type uint8
 *   p_FrRdrInitBlockage_Fail of type uint8
 *   p_FrCmrBlockage_Fail of type uint8
 *   p_FrCmrOvrTemp_Fail of type uint8
 * FcaFrCmrOut_t: Record with elements
 *   FCA_Equip_FR_CMR of type uint8
 * FcaInput_t: Record with elements
 *   SCC_InfoDis of type uint8
 *   SCC_OpSta of type uint8
 * FcaInternalInFromCOFCA_t: Record with elements
 *   CoFCA_FCA_FrOnOffEquipSta of type uint8
 *   CoFCA_FCA_SysFlrSta of type uint8
 *   CoFCA_FCA_WrngLvlSta of type uint8
 *   CoFCA_FCA_VehStpReq of type uint8
 *   CoFCA_FCA_StbltActvReq of type uint8
 *   CoFCA_FCA_HydrlcBstAsstReq of type uint8
 *   CoFCA_FCA_DclReqVal of type uint8
 *   CoFCA_FCA_PrefillActvReq of type uint8
 *   CoFCA_FCA_PartialActvReq of type uint8
 *   CoFCA_FCA_FullActvReq of type uint8
 *   CoFCA_FCA_WarnTimeSta of type uint8
 *   CoFCA_FCA_WrngSndSta of type uint8
 *   CoFCA_FCA_RelVel of type uint16
 *   CoFCA_FCA_TimetoCllsn of type uint8
 *   CoFCA_FCA_WrngTrgtDis of type uint8
 *   CoFCA_ADAS_TrlOffStaDisp of type uint8
 *   CoFCA_FCA_Regulation of type uint8
 *   CoFCA_ADAS_InhbtOffDispSta of type uint8
 *   EDR_COFCA_RelVel of type uint16
 *   EDR_COFCA_TimetoCllsn of type uint8
 *   EDR_COFCA_EgoVehSpeed of type uint16
 *   EDR_COFCA_LongDistance of type uint16
 *   EDR_COFCA_LatDistance of type uint16
 * FcaInternalInFromLSS_t: Record with elements
 *   LSS_TrlrOffDispSta of type uint8
 * FcaNvmSaveVal_t: Record with elements
 *   NVM_YawrateOffset of type uint16
 *   NVM_WarningTime_Guest of type uint8
 *   NVM_WarningTime_USER1 of type uint8
 *   NVM_WarningTime_USER2 of type uint8
 *   NVM_WarningTime_LastProfileID of type uint8
 *   Reserved1 of type uint8
 *   Reserved2 of type uint8
 *   Reserved3 of type uint8
 *   Reserved4 of type uint8
 *   Reserved5 of type uint8
 *   Reserved6 of type uint8
 * FcaOutput_t: Record with elements
 *   FCA_FrOnOffEquipSta of type uint8
 *   FCA_SysFlrSta of type uint8
 *   FCA_WrngLvlSta of type uint8
 *   FCA_VehStpReq of type uint8
 *   FCA_StbltActvReq of type uint8
 *   FCA_HydrlcBstAsstReq of type uint8
 *   FCA_DclReqVal of type uint8
 *   FCA_PrefillActvReq of type uint8
 *   FCA_PartialActvReq of type uint8
 *   FCA_FullActvReq of type uint8
 *   FCA_WarnTimeSta of type uint8
 *   FCA_WrngSndSta of type uint8
 *   FCA_RelVel of type uint16
 *   FCA_TimetoCllsn of type uint8
 *   FCA_WrngTrgtDis of type uint8
 *   ADAS_TrlOffStaDisp of type uint8
 *   FCA_Regulation of type uint8
 *   ADAS_InhbtOffDispSta of type uint8
 * FcaUxOutToIvc_t: Record with elements
 *   ux_TT_FwdSftySymbSta of type uint8
 *   ux_MV_HostVeh1Sta_FCA of type uint8
 *   ux_PU_F_Group1_FCA_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group4_FCA_Warn1_1Sta of type uint8
 *   ux_PU_F_Group7_FCA_FwdSftyFlrSta of type uint8
 *   ux_FCA_SND_ADASWarn1_1Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_FCA of type uint8
 *   ux_PU_F_Group4_Trailer_ADASWarn1_1Sta of type uint8
 * FcfVd_t: Record with elements
 *   FCF_VD_Dyn_CRC of type uint32
 *   FCF_VD_Dyn_Alert of type uint16
 *   FCF_VD_Dyn_ID of type uint8
 *   FCF_VD_Dyn_AEB_Supp of type uint16
 *   FCF_VD_Dyn_FCW_Supp of type uint32
 *   FCF_VD_Dyn_Set_Type of type uint8
 *   FCF_VD_Dyn_TTC_Thresh of type uint16
 *   FCF_VD_Dyn_TTC of type uint16
 * FcfVru_t: Record with elements
 *   FCF_VRU_Dyn_CRC of type uint32
 *   FCF_VRU_Dyn_Alert of type uint16
 *   FCF_VRU_Dyn_PED_ID of type uint8
 *   FCF_VRU_Dyn_Suppress of type uint8
 *   FCF_VRU_Dyn_Set_Type of type uint8
 *   FCF_VRU_Dyn_Curr_In_Path of type boolean
 *   FCF_VRU_Dyn_Pred_In_Path of type boolean
 *   FCF_VRU_Dyn_TTC of type uint16
 *   FCF_VRU_Dyn_TTC_Thresh of type uint16
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 * FrCmrHdrFS_t: Record with elements
 *   FS_Header_CRC of type uint32
 *   FS_Protocol_Version of type uint8
 *   FS_Sync_ID of type uint8
 *   FS_Cameras_Number of type uint8
 *   FS_TSR_Out_OF_Calib of type uint8
 *   FS_Out_Of_Calib of type uint8
 *   FS_Impacted_Technologies of type uint16
 *   FS_Rain of type uint8
 *   FS_Fog of type uint8
 *   FS_C2W_OOR of type uint8
 * FrCmrHdrFcfVd_t: Record with elements
 *   FCF_VD_Dyn_Protocol_Version of type uint8
 *   FCF_VD_Dyn_SyncID of type uint8
 *   FCF_VD_Dyn_Header_CRC of type uint32
 *   FCF_VD_Dyn_AEB_Supp_FCV of type uint16
 *   FCF_VD_Dyn_Alert_FCV of type uint16
 *   FCF_VD_Dyn_ID_FCV of type uint8
 *   FCF_VD_Dyn_HeadWay_Alert of type boolean
 *   FCF_VD_Dyn_HeadWay_Distance of type uint16
 *   FCF_VD_Dyn_HW_Supp_Reason of type uint16
 * FrCmrHdrFcfVru_t: Record with elements
 *   FCF_VRU_Dyn_Protocol_Version of type uint8
 *   FCF_VRU_Dyn_SyncID of type uint8
 * FrCmrHdrLnHost_t: Record with elements
 *   LH_Protocol_Version of type uint8
 *   LH_Sync_ID of type uint8
 *   LH_Lanes_Count of type uint8
 *   LH_Estimated_Width of type uint16
 * FrCmrHdrObj_t: Record with elements
 *   OBJ_Header_CRC of type uint32
 *   OBJ_Protocol_Version of type uint8
 *   OBJ_Sync_ID of type uint8
 *   OBJ_VRU_Count of type uint8
 *   OBJ_VD_Count of type uint8
 *   OBJ_General_OBJ_Count of type uint8
 *   OBJ_Animal_Count of type uint8
 *   OBJ_VD_NIV_Left of type uint8
 *   OBJ_VD_NIV_Right of type uint8
 *   OBJ_VD_CIPV_ID of type uint8
 *   OBJ_VD_CIPV_Lost of type uint8
 *   OBJ_VD_Allow_Acc of type uint8
 *   OBJ_Is_Blocked_Left of type boolean
 *   OBJ_Is_Blocked_Right of type boolean
 * LanesHost_t: Record with elements
 *   LH_CRC of type uint32
 *   LH_Is_Triggered_SDM_Type of type uint8
 *   LH_Is_Triggered_SDM_Model of type uint8
 *   LH_Track_ID of type uint8
 *   LH_Age of type uint8
 *   LH_Confidence of type uint8
 *   LH_Prediction_Reason of type uint8
 *   LH_Availability_State of type uint8
 *   LH_Color of type uint8
 *   LH_Color_Confidence of type uint8
 *   LH_Lanemark_Type of type uint8
 *   LH_DLM_Type of type uint8
 *   LH_DECEL_Type of type uint8
 *   LH_Lanemark_Type_Conf of type uint8
 *   LH_Side of type uint8
 *   LH_Crossing of type boolean
 *   LH_Marker_Width of type uint8
 *   LH_Marker_Width_STD of type uint8
 *   LH_Dash_Average_Available of type boolean
 *   LH_Dash_Average_Length of type uint8
 *   LH_Dash_Average_Gap of type uint8
 *   LH_Is_Multi_Clothoid of type boolean
 *   LH_Line_First_C0 of type float32
 *   LH_Line_First_C1 of type float32
 *   LH_Line_First_C2 of type float32
 *   LH_Line_First_C3 of type float32
 *   LH_First_VR_Start of type uint16
 *   LH_First_VR_End of type uint16
 *   LH_First_Measured_VR_End of type uint16
 *   LH_Second_Measured_VR_End of type uint16
 *   LH_Line_Second_C0 of type float32
 *   LH_Line_Second_C1 of type float32
 *   LH_Line_Second_C2 of type float32
 *   LH_Line_Second_C3 of type float32
 *   LH_Second_VR_Start of type uint16
 *   LH_Second_VR_End of type uint16
 *   LH_Is_Construction_Area of type boolean
 * Objects_t: Record with elements
 *   OBJ_CRC of type uint32
 *   OBJ_ID of type uint8
 *   OBJ_VD_CIPVFlag of type uint8
 *   OBJ_Existence_Probability of type uint8
 *   OBJ_Fusion_Source of type uint16
 *   OBJ_Triggered_SDM of type uint8
 *   OBJ_Motion_Category of type uint8
 *   OBJ_Object_Age of type uint16
 *   OBJ_Measuring_Status of type uint8
 *   OBJ_Object_Class of type uint8
 *   OBJ_Class_Probability of type uint8
 *   OBJ_Camera_Source of type uint8
 *   OBJ_Motion_Status of type uint8
 *   OBJ_Motion_Orientation of type uint8
 *   OBJ_Has_Cut_Lane of type boolean
 *   OBJ_Has_Cut_Path of type boolean
 *   OBJ_Brake_Light_Validity of type boolean
 *   OBJ_Brake_Light of type boolean
 *   OBJ_Turn_Indicator_Right of type boolean
 *   OBJ_Turn_Indicator_Left of type boolean
 *   OBJ_Turn_Indicator_Validity of type boolean
 *   OBJ_Right_Out_Of_Image of type boolean
 *   OBJ_Left_Out_Of_Image of type boolean
 *   OBJ_Right_Out_Of_Image_V of type boolean
 *   OBJ_Left_Out_Of_Image_V of type boolean
 *   OBJ_Top_Out_Of_Image of type boolean
 *   OBJ_Bottom_Out_Of_Image of type boolean
 *   OBJ_Top_Out_Of_Image_V of type boolean
 *   OBJ_Bottom_Out_Of_Image_V of type boolean
 *   OBJ_Lane_Assignment of type uint8
 *   OBJ_Lane_Assignment_V of type boolean
 *   OBJ_Age_Seconds of type uint8
 *   OBJ_Age_Seconds_V of type boolean
 *   OBJ_Width of type uint16
 *   OBJ_Width_V of type boolean
 *   OBJ_Width_STD of type uint16
 *   OBJ_Width_STD_V of type boolean
 *   OBJ_Length of type uint16
 *   OBJ_Length_V of type boolean
 *   OBJ_Length_STD of type uint16
 *   OBJ_Length_STD_V of type boolean
 *   OBJ_Height of type uint16
 *   OBJ_Height_V of type boolean
 *   OBJ_Height_STD of type uint16
 *   OBJ_Height_STD_V of type boolean
 *   OBJ_Abs_Long_Velocity of type uint16
 *   OBJ_Abs_Long_Velocity_V of type boolean
 *   OBJ_Abs_Long_Velocity_STD of type uint16
 *   OBJ_Abs_Long_Vel_STD_V of type boolean
 *   OBJ_Abs_Lat_Velocity of type uint16
 *   OBJ_Abs_Lat_Velocity_V of type boolean
 *   OBJ_Abs_Lat_Velocity_STD of type uint16
 *   OBJ_Abs_Lat_Vel_STD_V of type boolean
 *   OBJ_Abs_Long_Acc of type uint16
 *   OBJ_Abs_Long_Acc_V of type boolean
 *   OBJ_Abs_Long_Acc_STD of type uint16
 *   OBJ_Abs_Long_Acc_STD_V of type boolean
 *   OBJ_Abs_Lat_Acc of type uint16
 *   OBJ_Abs_Lat_Acc_V of type boolean
 *   OBJ_Abs_Lat_Acc_STD of type uint16
 *   OBJ_Abs_Lat_Acc_STD_V of type boolean
 *   OBJ_Abs_Acceleration of type uint16
 *   OBJ_Abs_Acceleration_V of type boolean
 *   OBJ_Abs_Acc_STD of type uint16
 *   OBJ_Abs_Acc_STD_V of type boolean
 *   OBJ_Inv_TTC of type uint16
 *   OBJ_Inv_TTC_V of type boolean
 *   OBJ_Inv_TTC_STD of type uint16
 *   OBJ_Inv_TTC_STD_V of type boolean
 *   OBJ_Relative_Long_Acc of type uint16
 *   OBJ_Relative_Long_Acc_V of type boolean
 *   OBJ_Relative_Long_Acc_STD of type uint16
 *   OBJ_Rel_Long_Acc_STD_V of type boolean
 *   OBJ_Relative_Long_Velocity of type uint16
 *   OBJ_Relative_Long_Velocity_V of type boolean
 *   OBJ_Relative_Long_Vel_STD of type uint16
 *   OBJ_Rel_Long_Vel_STD_V of type boolean
 *   OBJ_Relative_Lat_Velocity of type uint16
 *   OBJ_Relative_Lat_Velocity_V of type boolean
 *   OBJ_Relative_Lat_Velocity_STD of type uint16
 *   OBJ_Rel_Lat_Vel_STD_V of type boolean
 *   OBJ_Long_Distance of type uint16
 *   OBJ_Long_Distance_V of type boolean
 *   OBJ_Long_Distance_STD of type uint16
 *   OBJ_Long_Distance_STD_V of type boolean
 *   OBJ_Lat_Distance of type uint16
 *   OBJ_Lat_Distance_V of type boolean
 *   OBJ_Lat_Distance_STD of type uint16
 *   OBJ_Lat_Distance_STD_V of type boolean
 *   OBJ_Absolute_Speed of type uint16
 *   OBJ_Absolute_Speed_V of type boolean
 *   OBJ_Absolute_Speed_STD of type uint16
 *   OBJ_Absolute_Speed_STD_V of type boolean
 *   OBJ_Heading of type uint16
 *   OBJ_Heading_V of type boolean
 *   OBJ_Heading_STD of type uint16
 *   OBJ_Heading_STD_V of type boolean
 *   OBJ_Angle_Rate_STD of type uint16
 *   OBJ_Angle_Rate_STD_V of type boolean
 *   OBJ_Angle_Rate of type uint16
 *   OBJ_Angle_Rate_V of type boolean
 *   OBJ_Angle_Right of type uint16
 *   OBJ_Angle_Right_V of type boolean
 *   OBJ_Angle_Right_STD of type uint16
 *   OBJ_Angle_Right_STD_V of type boolean
 *   OBJ_Angle_Left of type uint16
 *   OBJ_Angle_Left_V of type boolean
 *   OBJ_Angle_Left_STD of type uint16
 *   OBJ_Angle_Left_STD_V of type boolean
 *   OBJ_Angle_Side of type uint16
 *   OBJ_Angle_Side_V of type boolean
 *   OBJ_Angle_Side_STD of type uint16
 *   OBJ_Angle_Side_STD_V of type boolean
 *   OBJ_Angle_Mid_V of type boolean
 *   OBJ_Angle_Mid of type uint16
 *   OBJ_Angle_Mid_STD of type uint16
 *   OBJ_Angle_Mid_STD_V of type boolean
 *   OBJ_Angle_Bottom_V of type boolean
 *   OBJ_Angle_Bottom of type uint16
 *   OBJ_Angle_Bottom_STD of type uint16
 *   OBJ_Angle_Bottom_STD_V of type boolean
 *   OBJ_Visibility_Side_V of type boolean
 *   OBJ_Visibility_Side of type uint8
 *   OBJ_Is_In_Drivable_Area of type boolean
 *   OBJ_Is_In_Drivable_Area_V of type boolean
 *   OBJ_Is_VeryClose_V of type boolean
 *   OBJ_Is_VeryClose of type boolean
 *   OBJ_Is_EMERGENCY_VCL of type boolean
 *   OBJ_EMERGENCY_LIGHT_COLOR of type uint8
 *   OBJ_EMERGENCY_V of type boolean
 *   OBJ_Open_Door_Left of type boolean
 *   OBJ_Open_Door_Right of type boolean
 *   OBJ_Visible_Left_or_Right of type uint8
 *   OBJ_Visible_Left_or_Right_V of type boolean
 *   OBJ_2W_Is_Motorbike_Probability of type uint8
 *   OBJ_2W_Is_Bicycle_Probability of type uint8
 *   Obj_partially_in_lane of type boolean
 * RdrInfo_t: Record with elements
 *   FR_RDR_Det_CRC01Val of type uint16
 *   FR_RDR_Det_CRC02Val of type uint16
 *   FR_RDR_Det_CRC03Val of type uint16
 *   FR_RDR_Det_CRC04Val of type uint16
 *   FR_RDR_Det_CRC05Val of type uint16
 *   FR_RDR_Det_CRC06Val of type uint16
 *   FR_RDR_Det_CRC07Val of type uint16
 *   FR_RDR_Det_CRC08Val of type uint16
 *   FR_RDR_Det_CRC09Val of type uint16
 *   FR_RDR_Det_CRC10Val of type uint16
 *   FR_RDR_Det_CRC11Val of type uint16
 *   FR_RDR_Det_CRC12Val of type uint16
 *   FR_RDR_Det_CRC13Val of type uint16
 *   FR_RDR_Det_CRC14Val of type uint16
 *   FR_RDR_Det_CRC15Val of type uint16
 *   FR_RDR_Det_CRC16Val of type uint16
 *   FR_RDR_Det_Long01 of type uint16
 *   FR_RDR_Det_Long02 of type uint16
 *   FR_RDR_Det_Long03 of type uint16
 *   FR_RDR_Det_Long04 of type uint16
 *   FR_RDR_Det_Long05 of type uint16
 *   FR_RDR_Det_Long06 of type uint16
 *   FR_RDR_Det_Long07 of type uint16
 *   FR_RDR_Det_Long08 of type uint16
 *   FR_RDR_Det_Long09 of type uint16
 *   FR_RDR_Det_Long10 of type uint16
 *   FR_RDR_Det_Long11 of type uint16
 *   FR_RDR_Det_Long12 of type uint16
 *   FR_RDR_Det_Long13 of type uint16
 *   FR_RDR_Det_Long14 of type uint16
 *   FR_RDR_Det_Long15 of type uint16
 *   FR_RDR_Det_Long16 of type uint16
 *   FR_RDR_Det_Long17 of type uint16
 *   FR_RDR_Det_Long18 of type uint16
 *   FR_RDR_Det_Long19 of type uint16
 *   FR_RDR_Det_Long20 of type uint16
 *   FR_RDR_Det_Long21 of type uint16
 *   FR_RDR_Det_Long22 of type uint16
 *   FR_RDR_Det_Long23 of type uint16
 *   FR_RDR_Det_Long24 of type uint16
 *   FR_RDR_Det_Long25 of type uint16
 *   FR_RDR_Det_Long26 of type uint16
 *   FR_RDR_Det_Long27 of type uint16
 *   FR_RDR_Det_Long28 of type uint16
 *   FR_RDR_Det_Long29 of type uint16
 *   FR_RDR_Det_Long30 of type uint16
 *   FR_RDR_Det_Long31 of type uint16
 *   FR_RDR_Det_Long32 of type uint16
 *   FR_RDR_Det_Long33 of type uint16
 *   FR_RDR_Det_Long34 of type uint16
 *   FR_RDR_Det_Long35 of type uint16
 *   FR_RDR_Det_Long36 of type uint16
 *   FR_RDR_Det_Long37 of type uint16
 *   FR_RDR_Det_Long38 of type uint16
 *   FR_RDR_Det_Long39 of type uint16
 *   FR_RDR_Det_Long40 of type uint16
 *   FR_RDR_Det_Long41 of type uint16
 *   FR_RDR_Det_Long42 of type uint16
 *   FR_RDR_Det_Long43 of type uint16
 *   FR_RDR_Det_Long44 of type uint16
 *   FR_RDR_Det_Long45 of type uint16
 *   FR_RDR_Det_Long46 of type uint16
 *   FR_RDR_Det_Long47 of type uint16
 *   FR_RDR_Det_Long48 of type uint16
 *   FR_RDR_Det_Long49 of type uint16
 *   FR_RDR_Det_Long50 of type uint16
 *   FR_RDR_Det_Long51 of type uint16
 *   FR_RDR_Det_Long52 of type uint16
 *   FR_RDR_Det_Long53 of type uint16
 *   FR_RDR_Det_Long54 of type uint16
 *   FR_RDR_Det_Long55 of type uint16
 *   FR_RDR_Det_Long56 of type uint16
 *   FR_RDR_Det_Long57 of type uint16
 *   FR_RDR_Det_Long58 of type uint16
 *   FR_RDR_Det_Long59 of type uint16
 *   FR_RDR_Det_Long60 of type uint16
 *   FR_RDR_Det_Long61 of type uint16
 *   FR_RDR_Det_Long62 of type uint16
 *   FR_RDR_Det_Long63 of type uint16
 *   FR_RDR_Det_Long64 of type uint16
 *   FR_RDR_Det_Lat01 of type sint16
 *   FR_RDR_Det_Lat02 of type sint16
 *   FR_RDR_Det_Lat03 of type sint16
 *   FR_RDR_Det_Lat04 of type sint16
 *   FR_RDR_Det_Lat05 of type sint16
 *   FR_RDR_Det_Lat06 of type sint16
 *   FR_RDR_Det_Lat07 of type sint16
 *   FR_RDR_Det_Lat08 of type sint16
 *   FR_RDR_Det_Lat09 of type sint16
 *   FR_RDR_Det_Lat10 of type sint16
 *   FR_RDR_Det_Lat11 of type sint16
 *   FR_RDR_Det_Lat12 of type sint16
 *   FR_RDR_Det_Lat13 of type sint16
 *   FR_RDR_Det_Lat14 of type sint16
 *   FR_RDR_Det_Lat15 of type sint16
 *   FR_RDR_Det_Lat16 of type sint16
 *   FR_RDR_Det_Lat17 of type sint16
 *   FR_RDR_Det_Lat18 of type sint16
 *   FR_RDR_Det_Lat19 of type sint16
 *   FR_RDR_Det_Lat20 of type sint16
 *   FR_RDR_Det_Lat21 of type sint16
 *   FR_RDR_Det_Lat22 of type sint16
 *   FR_RDR_Det_Lat23 of type sint16
 *   FR_RDR_Det_Lat24 of type sint16
 *   FR_RDR_Det_Lat25 of type sint16
 *   FR_RDR_Det_Lat26 of type sint16
 *   FR_RDR_Det_Lat27 of type sint16
 *   FR_RDR_Det_Lat28 of type sint16
 *   FR_RDR_Det_Lat29 of type sint16
 *   FR_RDR_Det_Lat30 of type sint16
 *   FR_RDR_Det_Lat31 of type sint16
 *   FR_RDR_Det_Lat32 of type sint16
 *   FR_RDR_Det_Lat33 of type sint16
 *   FR_RDR_Det_Lat34 of type sint16
 *   FR_RDR_Det_Lat35 of type sint16
 *   FR_RDR_Det_Lat36 of type sint16
 *   FR_RDR_Det_Lat37 of type sint16
 *   FR_RDR_Det_Lat38 of type sint16
 *   FR_RDR_Det_Lat39 of type sint16
 *   FR_RDR_Det_Lat40 of type sint16
 *   FR_RDR_Det_Lat41 of type sint16
 *   FR_RDR_Det_Lat42 of type sint16
 *   FR_RDR_Det_Lat43 of type sint16
 *   FR_RDR_Det_Lat44 of type sint16
 *   FR_RDR_Det_Lat45 of type sint16
 *   FR_RDR_Det_Lat46 of type sint16
 *   FR_RDR_Det_Lat47 of type sint16
 *   FR_RDR_Det_Lat48 of type sint16
 *   FR_RDR_Det_Lat49 of type sint16
 *   FR_RDR_Det_Lat50 of type sint16
 *   FR_RDR_Det_Lat51 of type sint16
 *   FR_RDR_Det_Lat52 of type sint16
 *   FR_RDR_Det_Lat53 of type sint16
 *   FR_RDR_Det_Lat54 of type sint16
 *   FR_RDR_Det_Lat55 of type sint16
 *   FR_RDR_Det_Lat56 of type sint16
 *   FR_RDR_Det_Lat57 of type sint16
 *   FR_RDR_Det_Lat58 of type sint16
 *   FR_RDR_Det_Lat59 of type sint16
 *   FR_RDR_Det_Lat60 of type sint16
 *   FR_RDR_Det_Lat61 of type sint16
 *   FR_RDR_Det_Lat62 of type sint16
 *   FR_RDR_Det_Lat63 of type sint16
 *   FR_RDR_Det_Lat64 of type sint16
 *   FR_RDR_Det_Speed01 of type sint16
 *   FR_RDR_Det_Speed02 of type sint16
 *   FR_RDR_Det_Speed03 of type sint16
 *   FR_RDR_Det_Speed04 of type sint16
 *   FR_RDR_Det_Speed05 of type sint16
 *   FR_RDR_Det_Speed06 of type sint16
 *   FR_RDR_Det_Speed07 of type sint16
 *   FR_RDR_Det_Speed08 of type sint16
 *   FR_RDR_Det_Speed09 of type sint16
 *   FR_RDR_Det_Speed10 of type sint16
 *   FR_RDR_Det_Speed11 of type sint16
 *   FR_RDR_Det_Speed12 of type sint16
 *   FR_RDR_Det_Speed13 of type sint16
 *   FR_RDR_Det_Speed14 of type sint16
 *   FR_RDR_Det_Speed15 of type sint16
 *   FR_RDR_Det_Speed16 of type sint16
 *   FR_RDR_Det_Speed17 of type sint16
 *   FR_RDR_Det_Speed18 of type sint16
 *   FR_RDR_Det_Speed19 of type sint16
 *   FR_RDR_Det_Speed20 of type sint16
 *   FR_RDR_Det_Speed21 of type sint16
 *   FR_RDR_Det_Speed22 of type sint16
 *   FR_RDR_Det_Speed23 of type sint16
 *   FR_RDR_Det_Speed24 of type sint16
 *   FR_RDR_Det_Speed25 of type sint16
 *   FR_RDR_Det_Speed26 of type sint16
 *   FR_RDR_Det_Speed27 of type sint16
 *   FR_RDR_Det_Speed28 of type sint16
 *   FR_RDR_Det_Speed29 of type sint16
 *   FR_RDR_Det_Speed30 of type sint16
 *   FR_RDR_Det_Speed31 of type sint16
 *   FR_RDR_Det_Speed32 of type sint16
 *   FR_RDR_Det_Speed33 of type sint16
 *   FR_RDR_Det_Speed34 of type sint16
 *   FR_RDR_Det_Speed35 of type sint16
 *   FR_RDR_Det_Speed36 of type sint16
 *   FR_RDR_Det_Speed37 of type sint16
 *   FR_RDR_Det_Speed38 of type sint16
 *   FR_RDR_Det_Speed39 of type sint16
 *   FR_RDR_Det_Speed40 of type sint16
 *   FR_RDR_Det_Speed41 of type sint16
 *   FR_RDR_Det_Speed42 of type sint16
 *   FR_RDR_Det_Speed43 of type sint16
 *   FR_RDR_Det_Speed44 of type sint16
 *   FR_RDR_Det_Speed45 of type sint16
 *   FR_RDR_Det_Speed46 of type sint16
 *   FR_RDR_Det_Speed47 of type sint16
 *   FR_RDR_Det_Speed48 of type sint16
 *   FR_RDR_Det_Speed49 of type sint16
 *   FR_RDR_Det_Speed50 of type sint16
 *   FR_RDR_Det_Speed51 of type sint16
 *   FR_RDR_Det_Speed52 of type sint16
 *   FR_RDR_Det_Speed53 of type sint16
 *   FR_RDR_Det_Speed54 of type sint16
 *   FR_RDR_Det_Speed55 of type sint16
 *   FR_RDR_Det_Speed56 of type sint16
 *   FR_RDR_Det_Speed57 of type sint16
 *   FR_RDR_Det_Speed58 of type sint16
 *   FR_RDR_Det_Speed59 of type sint16
 *   FR_RDR_Det_Speed60 of type sint16
 *   FR_RDR_Det_Speed61 of type sint16
 *   FR_RDR_Det_Speed62 of type sint16
 *   FR_RDR_Det_Speed63 of type sint16
 *   FR_RDR_Det_Speed64 of type sint16
 *   FR_RDR_Det_SNR01 of type uint16
 *   FR_RDR_Det_SNR02 of type uint16
 *   FR_RDR_Det_SNR03 of type uint16
 *   FR_RDR_Det_SNR04 of type uint16
 *   FR_RDR_Det_SNR05 of type uint16
 *   FR_RDR_Det_SNR06 of type uint16
 *   FR_RDR_Det_SNR07 of type uint16
 *   FR_RDR_Det_SNR08 of type uint16
 *   FR_RDR_Det_SNR09 of type uint16
 *   FR_RDR_Det_SNR10 of type uint16
 *   FR_RDR_Det_SNR11 of type uint16
 *   FR_RDR_Det_SNR12 of type uint16
 *   FR_RDR_Det_SNR13 of type uint16
 *   FR_RDR_Det_SNR14 of type uint16
 *   FR_RDR_Det_SNR15 of type uint16
 *   FR_RDR_Det_SNR16 of type uint16
 *   FR_RDR_Det_SNR17 of type uint16
 *   FR_RDR_Det_SNR18 of type uint16
 *   FR_RDR_Det_SNR19 of type uint16
 *   FR_RDR_Det_SNR20 of type uint16
 *   FR_RDR_Det_SNR21 of type uint16
 *   FR_RDR_Det_SNR22 of type uint16
 *   FR_RDR_Det_SNR23 of type uint16
 *   FR_RDR_Det_SNR24 of type uint16
 *   FR_RDR_Det_SNR25 of type uint16
 *   FR_RDR_Det_SNR26 of type uint16
 *   FR_RDR_Det_SNR27 of type uint16
 *   FR_RDR_Det_SNR28 of type uint16
 *   FR_RDR_Det_SNR29 of type uint16
 *   FR_RDR_Det_SNR30 of type uint16
 *   FR_RDR_Det_SNR31 of type uint16
 *   FR_RDR_Det_SNR32 of type uint16
 *   FR_RDR_Det_SNR33 of type uint16
 *   FR_RDR_Det_SNR34 of type uint16
 *   FR_RDR_Det_SNR35 of type uint16
 *   FR_RDR_Det_SNR36 of type uint16
 *   FR_RDR_Det_SNR37 of type uint16
 *   FR_RDR_Det_SNR38 of type uint16
 *   FR_RDR_Det_SNR39 of type uint16
 *   FR_RDR_Det_SNR40 of type uint16
 *   FR_RDR_Det_SNR41 of type uint16
 *   FR_RDR_Det_SNR42 of type uint16
 *   FR_RDR_Det_SNR43 of type uint16
 *   FR_RDR_Det_SNR44 of type uint16
 *   FR_RDR_Det_SNR45 of type uint16
 *   FR_RDR_Det_SNR46 of type uint16
 *   FR_RDR_Det_SNR47 of type uint16
 *   FR_RDR_Det_SNR48 of type uint16
 *   FR_RDR_Det_SNR49 of type uint16
 *   FR_RDR_Det_SNR50 of type uint16
 *   FR_RDR_Det_SNR51 of type uint16
 *   FR_RDR_Det_SNR52 of type uint16
 *   FR_RDR_Det_SNR53 of type uint16
 *   FR_RDR_Det_SNR54 of type uint16
 *   FR_RDR_Det_SNR55 of type uint16
 *   FR_RDR_Det_SNR56 of type uint16
 *   FR_RDR_Det_SNR57 of type uint16
 *   FR_RDR_Det_SNR58 of type uint16
 *   FR_RDR_Det_SNR59 of type uint16
 *   FR_RDR_Det_SNR60 of type uint16
 *   FR_RDR_Det_SNR61 of type uint16
 *   FR_RDR_Det_SNR62 of type uint16
 *   FR_RDR_Det_SNR63 of type uint16
 *   FR_RDR_Det_SNR64 of type uint16
 *   FR_RDR_Det_AmbigSpeed01 of type sint16
 *   FR_RDR_Det_AmbigSpeed02 of type sint16
 *   FR_RDR_Det_AmbigSpeed03 of type sint16
 *   FR_RDR_Det_AmbigSpeed04 of type sint16
 *   FR_RDR_Det_AmbigSpeed05 of type sint16
 *   FR_RDR_Det_AmbigSpeed06 of type sint16
 *   FR_RDR_Det_AmbigSpeed07 of type sint16
 *   FR_RDR_Det_AmbigSpeed08 of type sint16
 *   FR_RDR_Det_AmbigSpeed09 of type sint16
 *   FR_RDR_Det_AmbigSpeed10 of type sint16
 *   FR_RDR_Det_AmbigSpeed11 of type sint16
 *   FR_RDR_Det_AmbigSpeed12 of type sint16
 *   FR_RDR_Det_AmbigSpeed13 of type sint16
 *   FR_RDR_Det_AmbigSpeed14 of type sint16
 *   FR_RDR_Det_AmbigSpeed15 of type sint16
 *   FR_RDR_Det_AmbigSpeed16 of type sint16
 *   FR_RDR_Det_AmbigSpeed17 of type sint16
 *   FR_RDR_Det_AmbigSpeed18 of type sint16
 *   FR_RDR_Det_AmbigSpeed19 of type sint16
 *   FR_RDR_Det_AmbigSpeed20 of type sint16
 *   FR_RDR_Det_AmbigSpeed21 of type sint16
 *   FR_RDR_Det_AmbigSpeed22 of type sint16
 *   FR_RDR_Det_AmbigSpeed23 of type sint16
 *   FR_RDR_Det_AmbigSpeed24 of type sint16
 *   FR_RDR_Det_AmbigSpeed25 of type sint16
 *   FR_RDR_Det_AmbigSpeed26 of type sint16
 *   FR_RDR_Det_AmbigSpeed27 of type sint16
 *   FR_RDR_Det_AmbigSpeed28 of type sint16
 *   FR_RDR_Det_AmbigSpeed29 of type sint16
 *   FR_RDR_Det_AmbigSpeed30 of type sint16
 *   FR_RDR_Det_AmbigSpeed31 of type sint16
 *   FR_RDR_Det_AmbigSpeed32 of type sint16
 *   FR_RDR_Det_AmbigSpeed33 of type sint16
 *   FR_RDR_Det_AmbigSpeed34 of type sint16
 *   FR_RDR_Det_AmbigSpeed35 of type sint16
 *   FR_RDR_Det_AmbigSpeed36 of type sint16
 *   FR_RDR_Det_AmbigSpeed37 of type sint16
 *   FR_RDR_Det_AmbigSpeed38 of type sint16
 *   FR_RDR_Det_AmbigSpeed39 of type sint16
 *   FR_RDR_Det_AmbigSpeed40 of type sint16
 *   FR_RDR_Det_AmbigSpeed41 of type sint16
 *   FR_RDR_Det_AmbigSpeed42 of type sint16
 *   FR_RDR_Det_AmbigSpeed43 of type sint16
 *   FR_RDR_Det_AmbigSpeed44 of type sint16
 *   FR_RDR_Det_AmbigSpeed45 of type sint16
 *   FR_RDR_Det_AmbigSpeed46 of type sint16
 *   FR_RDR_Det_AmbigSpeed47 of type sint16
 *   FR_RDR_Det_AmbigSpeed48 of type sint16
 *   FR_RDR_Det_AmbigSpeed49 of type sint16
 *   FR_RDR_Det_AmbigSpeed50 of type sint16
 *   FR_RDR_Det_AmbigSpeed51 of type sint16
 *   FR_RDR_Det_AmbigSpeed52 of type sint16
 *   FR_RDR_Det_AmbigSpeed53 of type sint16
 *   FR_RDR_Det_AmbigSpeed54 of type sint16
 *   FR_RDR_Det_AmbigSpeed55 of type sint16
 *   FR_RDR_Det_AmbigSpeed56 of type sint16
 *   FR_RDR_Det_AmbigSpeed57 of type sint16
 *   FR_RDR_Det_AmbigSpeed58 of type sint16
 *   FR_RDR_Det_AmbigSpeed59 of type sint16
 *   FR_RDR_Det_AmbigSpeed60 of type sint16
 *   FR_RDR_Det_AmbigSpeed61 of type sint16
 *   FR_RDR_Det_AmbigSpeed62 of type sint16
 *   FR_RDR_Det_AmbigSpeed63 of type sint16
 *   FR_RDR_Det_AmbigSpeed64 of type sint16
 *   FR_RDR_Obj_CRC01Val of type uint16
 *   FR_RDR_Obj_CRC02Val of type uint16
 *   FR_RDR_Obj_CRC03Val of type uint16
 *   FR_RDR_Obj_CRC04Val of type uint16
 *   FR_RDR_Obj_CRC05Val of type uint16
 *   FR_RDR_Obj_CRC06Val of type uint16
 *   FR_RDR_Obj_CRC07Val of type uint16
 *   FR_RDR_Obj_CRC08Val of type uint16
 *   FR_RDR_Obj_CRC09Val of type uint16
 *   FR_RDR_Obj_CRC10Val of type uint16
 *   FR_RDR_Obj_CRC11Val of type uint16
 *   FR_RDR_Obj_CRC12Val of type uint16
 *   FR_RDR_Obj_CRC13Val of type uint16
 *   FR_RDR_Obj_CRC14Val of type uint16
 *   FR_RDR_Obj_CRC15Val of type uint16
 *   FR_RDR_Obj_CRC16Val of type uint16
 *   FR_RDR_Obj_RelPosX01Val of type uint16
 *   FR_RDR_Obj_RelPosX02Val of type uint16
 *   FR_RDR_Obj_RelPosX03Val of type uint16
 *   FR_RDR_Obj_RelPosX04Val of type uint16
 *   FR_RDR_Obj_RelPosX05Val of type uint16
 *   FR_RDR_Obj_RelPosX06Val of type uint16
 *   FR_RDR_Obj_RelPosX07Val of type uint16
 *   FR_RDR_Obj_RelPosX08Val of type uint16
 *   FR_RDR_Obj_RelPosX09Val of type uint16
 *   FR_RDR_Obj_RelPosX10Val of type uint16
 *   FR_RDR_Obj_RelPosX11Val of type uint16
 *   FR_RDR_Obj_RelPosX12Val of type uint16
 *   FR_RDR_Obj_RelPosX13Val of type uint16
 *   FR_RDR_Obj_RelPosX14Val of type uint16
 *   FR_RDR_Obj_RelPosX15Val of type uint16
 *   FR_RDR_Obj_RelPosX16Val of type uint16
 *   FR_RDR_Obj_RelPosX17Val of type uint16
 *   FR_RDR_Obj_RelPosX18Val of type uint16
 *   FR_RDR_Obj_RelPosX19Val of type uint16
 *   FR_RDR_Obj_RelPosX20Val of type uint16
 *   FR_RDR_Obj_RelPosX21Val of type uint16
 *   FR_RDR_Obj_RelPosX22Val of type uint16
 *   FR_RDR_Obj_RelPosX23Val of type uint16
 *   FR_RDR_Obj_RelPosX24Val of type uint16
 *   FR_RDR_Obj_RelPosX25Val of type uint16
 *   FR_RDR_Obj_RelPosX26Val of type uint16
 *   FR_RDR_Obj_RelPosX27Val of type uint16
 *   FR_RDR_Obj_RelPosX28Val of type uint16
 *   FR_RDR_Obj_RelPosX29Val of type uint16
 *   FR_RDR_Obj_RelPosX30Val of type uint16
 *   FR_RDR_Obj_RelPosX31Val of type uint16
 *   FR_RDR_Obj_RelPosX32Val of type uint16
 *   FR_RDR_Obj_RelPosY01Val of type sint16
 *   FR_RDR_Obj_RelPosY02Val of type sint16
 *   FR_RDR_Obj_RelPosY03Val of type sint16
 *   FR_RDR_Obj_RelPosY04Val of type sint16
 *   FR_RDR_Obj_RelPosY05Val of type sint16
 *   FR_RDR_Obj_RelPosY06Val of type sint16
 *   FR_RDR_Obj_RelPosY07Val of type sint16
 *   FR_RDR_Obj_RelPosY08Val of type sint16
 *   FR_RDR_Obj_RelPosY09Val of type sint16
 *   FR_RDR_Obj_RelPosY10Val of type sint16
 *   FR_RDR_Obj_RelPosY11Val of type sint16
 *   FR_RDR_Obj_RelPosY12Val of type sint16
 *   FR_RDR_Obj_RelPosY13Val of type sint16
 *   FR_RDR_Obj_RelPosY14Val of type sint16
 *   FR_RDR_Obj_RelPosY15Val of type sint16
 *   FR_RDR_Obj_RelPosY16Val of type sint16
 *   FR_RDR_Obj_RelPosY17Val of type sint16
 *   FR_RDR_Obj_RelPosY18Val of type sint16
 *   FR_RDR_Obj_RelPosY19Val of type sint16
 *   FR_RDR_Obj_RelPosY20Val of type sint16
 *   FR_RDR_Obj_RelPosY21Val of type sint16
 *   FR_RDR_Obj_RelPosY22Val of type sint16
 *   FR_RDR_Obj_RelPosY23Val of type sint16
 *   FR_RDR_Obj_RelPosY24Val of type sint16
 *   FR_RDR_Obj_RelPosY25Val of type sint16
 *   FR_RDR_Obj_RelPosY26Val of type sint16
 *   FR_RDR_Obj_RelPosY27Val of type sint16
 *   FR_RDR_Obj_RelPosY28Val of type sint16
 *   FR_RDR_Obj_RelPosY29Val of type sint16
 *   FR_RDR_Obj_RelPosY30Val of type sint16
 *   FR_RDR_Obj_RelPosY31Val of type sint16
 *   FR_RDR_Obj_RelPosY32Val of type sint16
 *   FR_RDR_Obj_RelVelX01Val of type sint16
 *   FR_RDR_Obj_RelVelX02Val of type sint16
 *   FR_RDR_Obj_RelVelX03Val of type sint16
 *   FR_RDR_Obj_RelVelX04Val of type sint16
 *   FR_RDR_Obj_RelVelX05Val of type sint16
 *   FR_RDR_Obj_RelVelX06Val of type sint16
 *   FR_RDR_Obj_RelVelX07Val of type sint16
 *   FR_RDR_Obj_RelVelX08Val of type sint16
 *   FR_RDR_Obj_RelVelX09Val of type sint16
 *   FR_RDR_Obj_RelVelX10Val of type sint16
 *   FR_RDR_Obj_RelVelX11Val of type sint16
 *   FR_RDR_Obj_RelVelX12Val of type sint16
 *   FR_RDR_Obj_RelVelX13Val of type sint16
 *   FR_RDR_Obj_RelVelX14Val of type sint16
 *   FR_RDR_Obj_RelVelX15Val of type sint16
 *   FR_RDR_Obj_RelVelX16Val of type sint16
 *   FR_RDR_Obj_RelVelX17Val of type sint16
 *   FR_RDR_Obj_RelVelX18Val of type sint16
 *   FR_RDR_Obj_RelVelX19Val of type sint16
 *   FR_RDR_Obj_RelVelX20Val of type sint16
 *   FR_RDR_Obj_RelVelX21Val of type sint16
 *   FR_RDR_Obj_RelVelX22Val of type sint16
 *   FR_RDR_Obj_RelVelX23Val of type sint16
 *   FR_RDR_Obj_RelVelX24Val of type sint16
 *   FR_RDR_Obj_RelVelX25Val of type sint16
 *   FR_RDR_Obj_RelVelX26Val of type sint16
 *   FR_RDR_Obj_RelVelX27Val of type sint16
 *   FR_RDR_Obj_RelVelX28Val of type sint16
 *   FR_RDR_Obj_RelVelX29Val of type sint16
 *   FR_RDR_Obj_RelVelX30Val of type sint16
 *   FR_RDR_Obj_RelVelX31Val of type sint16
 *   FR_RDR_Obj_RelVelX32Val of type sint16
 *   FR_RDR_Obj_RelVelY01Val of type sint16
 *   FR_RDR_Obj_RelVelY02Val of type sint16
 *   FR_RDR_Obj_RelVelY03Val of type sint16
 *   FR_RDR_Obj_RelVelY04Val of type sint16
 *   FR_RDR_Obj_RelVelY05Val of type sint16
 *   FR_RDR_Obj_RelVelY06Val of type sint16
 *   FR_RDR_Obj_RelVelY07Val of type sint16
 *   FR_RDR_Obj_RelVelY08Val of type sint16
 *   FR_RDR_Obj_RelVelY09Val of type sint16
 *   FR_RDR_Obj_RelVelY10Val of type sint16
 *   FR_RDR_Obj_RelVelY11Val of type sint16
 *   FR_RDR_Obj_RelVelY12Val of type sint16
 *   FR_RDR_Obj_RelVelY13Val of type sint16
 *   FR_RDR_Obj_RelVelY14Val of type sint16
 *   FR_RDR_Obj_RelVelY15Val of type sint16
 *   FR_RDR_Obj_RelVelY16Val of type sint16
 *   FR_RDR_Obj_RelVelY17Val of type sint16
 *   FR_RDR_Obj_RelVelY18Val of type sint16
 *   FR_RDR_Obj_RelVelY19Val of type sint16
 *   FR_RDR_Obj_RelVelY20Val of type sint16
 *   FR_RDR_Obj_RelVelY21Val of type sint16
 *   FR_RDR_Obj_RelVelY22Val of type sint16
 *   FR_RDR_Obj_RelVelY23Val of type sint16
 *   FR_RDR_Obj_RelVelY24Val of type sint16
 *   FR_RDR_Obj_RelVelY25Val of type sint16
 *   FR_RDR_Obj_RelVelY26Val of type sint16
 *   FR_RDR_Obj_RelVelY27Val of type sint16
 *   FR_RDR_Obj_RelVelY28Val of type sint16
 *   FR_RDR_Obj_RelVelY29Val of type sint16
 *   FR_RDR_Obj_RelVelY30Val of type sint16
 *   FR_RDR_Obj_RelVelY31Val of type sint16
 *   FR_RDR_Obj_RelVelY32Val of type sint16
 *   FR_RDR_Obj_RelAccelX01Val of type sint16
 *   FR_RDR_Obj_RelAccelX02Val of type sint16
 *   FR_RDR_Obj_RelAccelX03Val of type sint16
 *   FR_RDR_Obj_RelAccelX04Val of type sint16
 *   FR_RDR_Obj_RelAccelX05Val of type sint16
 *   FR_RDR_Obj_RelAccelX06Val of type sint16
 *   FR_RDR_Obj_RelAccelX07Val of type sint16
 *   FR_RDR_Obj_RelAccelX08Val of type sint16
 *   FR_RDR_Obj_RelAccelX09Val of type sint16
 *   FR_RDR_Obj_RelAccelX10Val of type sint16
 *   FR_RDR_Obj_RelAccelX11Val of type sint16
 *   FR_RDR_Obj_RelAccelX12Val of type sint16
 *   FR_RDR_Obj_RelAccelX13Val of type sint16
 *   FR_RDR_Obj_RelAccelX14Val of type sint16
 *   FR_RDR_Obj_RelAccelX15Val of type sint16
 *   FR_RDR_Obj_RelAccelX16Val of type sint16
 *   FR_RDR_Obj_RelAccelX17Val of type sint16
 *   FR_RDR_Obj_RelAccelX18Val of type sint16
 *   FR_RDR_Obj_RelAccelX19Val of type sint16
 *   FR_RDR_Obj_RelAccelX20Val of type sint16
 *   FR_RDR_Obj_RelAccelX21Val of type sint16
 *   FR_RDR_Obj_RelAccelX22Val of type sint16
 *   FR_RDR_Obj_RelAccelX23Val of type sint16
 *   FR_RDR_Obj_RelAccelX24Val of type sint16
 *   FR_RDR_Obj_RelAccelX25Val of type sint16
 *   FR_RDR_Obj_RelAccelX26Val of type sint16
 *   FR_RDR_Obj_RelAccelX27Val of type sint16
 *   FR_RDR_Obj_RelAccelX28Val of type sint16
 *   FR_RDR_Obj_RelAccelX29Val of type sint16
 *   FR_RDR_Obj_RelAccelX30Val of type sint16
 *   FR_RDR_Obj_RelAccelX31Val of type sint16
 *   FR_RDR_Obj_RelAccelX32Val of type sint16
 *   FR_RDR_DTC_RadarCRCVal of type uint16
 *   FR_RDR_DTC_RadarErrorCode_1 of type uint16
 *   FR_RDR_DTC_RadarErrorCode_2 of type uint16
 *   FR_RDR_Det_AlvCnt01Val of type uint8
 *   FR_RDR_Det_AlvCnt02Val of type uint8
 *   FR_RDR_Det_AlvCnt03Val of type uint8
 *   FR_RDR_Det_AlvCnt04Val of type uint8
 *   FR_RDR_Det_AlvCnt05Val of type uint8
 *   FR_RDR_Det_AlvCnt06Val of type uint8
 *   FR_RDR_Det_AlvCnt07Val of type uint8
 *   FR_RDR_Det_AlvCnt08Val of type uint8
 *   FR_RDR_Det_AlvCnt09Val of type uint8
 *   FR_RDR_Det_AlvCnt10Val of type uint8
 *   FR_RDR_Det_AlvCnt11Val of type uint8
 *   FR_RDR_Det_AlvCnt12Val of type uint8
 *   FR_RDR_Det_AlvCnt13Val of type uint8
 *   FR_RDR_Det_AlvCnt14Val of type uint8
 *   FR_RDR_Det_AlvCnt15Val of type uint8
 *   FR_RDR_Det_AlvCnt16Val of type uint8
 *   FR_RDR_Det_AssignTag01 of type uint8
 *   FR_RDR_Det_AssignTag02 of type uint8
 *   FR_RDR_Det_AssignTag03 of type uint8
 *   FR_RDR_Det_AssignTag04 of type uint8
 *   FR_RDR_Det_AssignTag05 of type uint8
 *   FR_RDR_Det_AssignTag06 of type uint8
 *   FR_RDR_Det_AssignTag07 of type uint8
 *   FR_RDR_Det_AssignTag08 of type uint8
 *   FR_RDR_Det_AssignTag09 of type uint8
 *   FR_RDR_Det_AssignTag10 of type uint8
 *   FR_RDR_Det_AssignTag11 of type uint8
 *   FR_RDR_Det_AssignTag12 of type uint8
 *   FR_RDR_Det_AssignTag13 of type uint8
 *   FR_RDR_Det_AssignTag14 of type uint8
 *   FR_RDR_Det_AssignTag15 of type uint8
 *   FR_RDR_Det_AssignTag16 of type uint8
 *   FR_RDR_Det_AssignTag17 of type uint8
 *   FR_RDR_Det_AssignTag18 of type uint8
 *   FR_RDR_Det_AssignTag19 of type uint8
 *   FR_RDR_Det_AssignTag20 of type uint8
 *   FR_RDR_Det_AssignTag21 of type uint8
 *   FR_RDR_Det_AssignTag22 of type uint8
 *   FR_RDR_Det_AssignTag23 of type uint8
 *   FR_RDR_Det_AssignTag24 of type uint8
 *   FR_RDR_Det_AssignTag25 of type uint8
 *   FR_RDR_Det_AssignTag26 of type uint8
 *   FR_RDR_Det_AssignTag27 of type uint8
 *   FR_RDR_Det_AssignTag28 of type uint8
 *   FR_RDR_Det_AssignTag29 of type uint8
 *   FR_RDR_Det_AssignTag30 of type uint8
 *   FR_RDR_Det_AssignTag31 of type uint8
 *   FR_RDR_Det_AssignTag32 of type uint8
 *   FR_RDR_Det_AssignTag33 of type uint8
 *   FR_RDR_Det_AssignTag34 of type uint8
 *   FR_RDR_Det_AssignTag35 of type uint8
 *   FR_RDR_Det_AssignTag36 of type uint8
 *   FR_RDR_Det_AssignTag37 of type uint8
 *   FR_RDR_Det_AssignTag38 of type uint8
 *   FR_RDR_Det_AssignTag39 of type uint8
 *   FR_RDR_Det_AssignTag40 of type uint8
 *   FR_RDR_Det_AssignTag41 of type uint8
 *   FR_RDR_Det_AssignTag42 of type uint8
 *   FR_RDR_Det_AssignTag43 of type uint8
 *   FR_RDR_Det_AssignTag44 of type uint8
 *   FR_RDR_Det_AssignTag45 of type uint8
 *   FR_RDR_Det_AssignTag46 of type uint8
 *   FR_RDR_Det_AssignTag47 of type uint8
 *   FR_RDR_Det_AssignTag48 of type uint8
 *   FR_RDR_Det_AssignTag49 of type uint8
 *   FR_RDR_Det_AssignTag50 of type uint8
 *   FR_RDR_Det_AssignTag51 of type uint8
 *   FR_RDR_Det_AssignTag52 of type uint8
 *   FR_RDR_Det_AssignTag53 of type uint8
 *   FR_RDR_Det_AssignTag54 of type uint8
 *   FR_RDR_Det_AssignTag55 of type uint8
 *   FR_RDR_Det_AssignTag56 of type uint8
 *   FR_RDR_Det_AssignTag57 of type uint8
 *   FR_RDR_Det_AssignTag58 of type uint8
 *   FR_RDR_Det_AssignTag59 of type uint8
 *   FR_RDR_Det_AssignTag60 of type uint8
 *   FR_RDR_Det_AssignTag61 of type uint8
 *   FR_RDR_Det_AssignTag62 of type uint8
 *   FR_RDR_Det_AssignTag63 of type uint8
 *   FR_RDR_Det_AssignTag64 of type uint8
 *   FR_RDR_Det_ClusterID01 of type uint8
 *   FR_RDR_Det_ClusterID02 of type uint8
 *   FR_RDR_Det_ClusterID03 of type uint8
 *   FR_RDR_Det_ClusterID04 of type uint8
 *   FR_RDR_Det_ClusterID05 of type uint8
 *   FR_RDR_Det_ClusterID06 of type uint8
 *   FR_RDR_Det_ClusterID07 of type uint8
 *   FR_RDR_Det_ClusterID08 of type uint8
 *   FR_RDR_Det_ClusterID09 of type uint8
 *   FR_RDR_Det_ClusterID10 of type uint8
 *   FR_RDR_Det_ClusterID11 of type uint8
 *   FR_RDR_Det_ClusterID12 of type uint8
 *   FR_RDR_Det_ClusterID13 of type uint8
 *   FR_RDR_Det_ClusterID14 of type uint8
 *   FR_RDR_Det_ClusterID15 of type uint8
 *   FR_RDR_Det_ClusterID16 of type uint8
 *   FR_RDR_Det_ClusterID17 of type uint8
 *   FR_RDR_Det_ClusterID18 of type uint8
 *   FR_RDR_Det_ClusterID19 of type uint8
 *   FR_RDR_Det_ClusterID20 of type uint8
 *   FR_RDR_Det_ClusterID21 of type uint8
 *   FR_RDR_Det_ClusterID22 of type uint8
 *   FR_RDR_Det_ClusterID23 of type uint8
 *   FR_RDR_Det_ClusterID24 of type uint8
 *   FR_RDR_Det_ClusterID25 of type uint8
 *   FR_RDR_Det_ClusterID26 of type uint8
 *   FR_RDR_Det_ClusterID27 of type uint8
 *   FR_RDR_Det_ClusterID28 of type uint8
 *   FR_RDR_Det_ClusterID29 of type uint8
 *   FR_RDR_Det_ClusterID30 of type uint8
 *   FR_RDR_Det_ClusterID31 of type uint8
 *   FR_RDR_Det_ClusterID32 of type uint8
 *   FR_RDR_Det_ClusterID33 of type uint8
 *   FR_RDR_Det_ClusterID34 of type uint8
 *   FR_RDR_Det_ClusterID35 of type uint8
 *   FR_RDR_Det_ClusterID36 of type uint8
 *   FR_RDR_Det_ClusterID37 of type uint8
 *   FR_RDR_Det_ClusterID38 of type uint8
 *   FR_RDR_Det_ClusterID39 of type uint8
 *   FR_RDR_Det_ClusterID40 of type uint8
 *   FR_RDR_Det_ClusterID41 of type uint8
 *   FR_RDR_Det_ClusterID42 of type uint8
 *   FR_RDR_Det_ClusterID43 of type uint8
 *   FR_RDR_Det_ClusterID44 of type uint8
 *   FR_RDR_Det_ClusterID45 of type uint8
 *   FR_RDR_Det_ClusterID46 of type uint8
 *   FR_RDR_Det_ClusterID47 of type uint8
 *   FR_RDR_Det_ClusterID48 of type uint8
 *   FR_RDR_Det_ClusterID49 of type uint8
 *   FR_RDR_Det_ClusterID50 of type uint8
 *   FR_RDR_Det_ClusterID51 of type uint8
 *   FR_RDR_Det_ClusterID52 of type uint8
 *   FR_RDR_Det_ClusterID53 of type uint8
 *   FR_RDR_Det_ClusterID54 of type uint8
 *   FR_RDR_Det_ClusterID55 of type uint8
 *   FR_RDR_Det_ClusterID56 of type uint8
 *   FR_RDR_Det_ClusterID57 of type uint8
 *   FR_RDR_Det_ClusterID58 of type uint8
 *   FR_RDR_Det_ClusterID59 of type uint8
 *   FR_RDR_Det_ClusterID60 of type uint8
 *   FR_RDR_Det_ClusterID61 of type uint8
 *   FR_RDR_Det_ClusterID62 of type uint8
 *   FR_RDR_Det_ClusterID63 of type uint8
 *   FR_RDR_Det_ClusterID64 of type uint8
 *   FR_RDR_Det_TrustV01 of type uint8
 *   FR_RDR_Det_TrustV02 of type uint8
 *   FR_RDR_Det_TrustV03 of type uint8
 *   FR_RDR_Det_TrustV04 of type uint8
 *   FR_RDR_Det_TrustV05 of type uint8
 *   FR_RDR_Det_TrustV06 of type uint8
 *   FR_RDR_Det_TrustV07 of type uint8
 *   FR_RDR_Det_TrustV08 of type uint8
 *   FR_RDR_Det_TrustV09 of type uint8
 *   FR_RDR_Det_TrustV10 of type uint8
 *   FR_RDR_Det_TrustV11 of type uint8
 *   FR_RDR_Det_TrustV12 of type uint8
 *   FR_RDR_Det_TrustV13 of type uint8
 *   FR_RDR_Det_TrustV14 of type uint8
 *   FR_RDR_Det_TrustV15 of type uint8
 *   FR_RDR_Det_TrustV16 of type uint8
 *   FR_RDR_Det_TrustV17 of type uint8
 *   FR_RDR_Det_TrustV18 of type uint8
 *   FR_RDR_Det_TrustV19 of type uint8
 *   FR_RDR_Det_TrustV20 of type uint8
 *   FR_RDR_Det_TrustV21 of type uint8
 *   FR_RDR_Det_TrustV22 of type uint8
 *   FR_RDR_Det_TrustV23 of type uint8
 *   FR_RDR_Det_TrustV24 of type uint8
 *   FR_RDR_Det_TrustV25 of type uint8
 *   FR_RDR_Det_TrustV26 of type uint8
 *   FR_RDR_Det_TrustV27 of type uint8
 *   FR_RDR_Det_TrustV28 of type uint8
 *   FR_RDR_Det_TrustV29 of type uint8
 *   FR_RDR_Det_TrustV30 of type uint8
 *   FR_RDR_Det_TrustV31 of type uint8
 *   FR_RDR_Det_TrustV32 of type uint8
 *   FR_RDR_Det_TrustV33 of type uint8
 *   FR_RDR_Det_TrustV34 of type uint8
 *   FR_RDR_Det_TrustV35 of type uint8
 *   FR_RDR_Det_TrustV36 of type uint8
 *   FR_RDR_Det_TrustV37 of type uint8
 *   FR_RDR_Det_TrustV38 of type uint8
 *   FR_RDR_Det_TrustV39 of type uint8
 *   FR_RDR_Det_TrustV40 of type uint8
 *   FR_RDR_Det_TrustV41 of type uint8
 *   FR_RDR_Det_TrustV42 of type uint8
 *   FR_RDR_Det_TrustV43 of type uint8
 *   FR_RDR_Det_TrustV44 of type uint8
 *   FR_RDR_Det_TrustV45 of type uint8
 *   FR_RDR_Det_TrustV46 of type uint8
 *   FR_RDR_Det_TrustV47 of type uint8
 *   FR_RDR_Det_TrustV48 of type uint8
 *   FR_RDR_Det_TrustV49 of type uint8
 *   FR_RDR_Det_TrustV50 of type uint8
 *   FR_RDR_Det_TrustV51 of type uint8
 *   FR_RDR_Det_TrustV52 of type uint8
 *   FR_RDR_Det_TrustV53 of type uint8
 *   FR_RDR_Det_TrustV54 of type uint8
 *   FR_RDR_Det_TrustV55 of type uint8
 *   FR_RDR_Det_TrustV56 of type uint8
 *   FR_RDR_Det_TrustV57 of type uint8
 *   FR_RDR_Det_TrustV58 of type uint8
 *   FR_RDR_Det_TrustV59 of type uint8
 *   FR_RDR_Det_TrustV60 of type uint8
 *   FR_RDR_Det_TrustV61 of type uint8
 *   FR_RDR_Det_TrustV62 of type uint8
 *   FR_RDR_Det_TrustV63 of type uint8
 *   FR_RDR_Det_TrustV64 of type uint8
 *   FR_RDR_Det_Height01 of type sint8
 *   FR_RDR_Det_Height02 of type sint8
 *   FR_RDR_Det_Height03 of type sint8
 *   FR_RDR_Det_Height04 of type sint8
 *   FR_RDR_Det_Height05 of type sint8
 *   FR_RDR_Det_Height06 of type sint8
 *   FR_RDR_Det_Height07 of type sint8
 *   FR_RDR_Det_Height08 of type sint8
 *   FR_RDR_Det_Height09 of type sint8
 *   FR_RDR_Det_Height10 of type sint8
 *   FR_RDR_Det_Height11 of type sint8
 *   FR_RDR_Det_Height12 of type sint8
 *   FR_RDR_Det_Height13 of type sint8
 *   FR_RDR_Det_Height14 of type sint8
 *   FR_RDR_Det_Height15 of type sint8
 *   FR_RDR_Det_Height16 of type sint8
 *   FR_RDR_Det_Height17 of type sint8
 *   FR_RDR_Det_Height18 of type sint8
 *   FR_RDR_Det_Height19 of type sint8
 *   FR_RDR_Det_Height20 of type sint8
 *   FR_RDR_Det_Height21 of type sint8
 *   FR_RDR_Det_Height22 of type sint8
 *   FR_RDR_Det_Height23 of type sint8
 *   FR_RDR_Det_Height24 of type sint8
 *   FR_RDR_Det_Height25 of type sint8
 *   FR_RDR_Det_Height26 of type sint8
 *   FR_RDR_Det_Height27 of type sint8
 *   FR_RDR_Det_Height28 of type sint8
 *   FR_RDR_Det_Height29 of type sint8
 *   FR_RDR_Det_Height30 of type sint8
 *   FR_RDR_Det_Height31 of type sint8
 *   FR_RDR_Det_Height32 of type sint8
 *   FR_RDR_Det_Height33 of type sint8
 *   FR_RDR_Det_Height34 of type sint8
 *   FR_RDR_Det_Height35 of type sint8
 *   FR_RDR_Det_Height36 of type sint8
 *   FR_RDR_Det_Height37 of type sint8
 *   FR_RDR_Det_Height38 of type sint8
 *   FR_RDR_Det_Height39 of type sint8
 *   FR_RDR_Det_Height40 of type sint8
 *   FR_RDR_Det_Height41 of type sint8
 *   FR_RDR_Det_Height42 of type sint8
 *   FR_RDR_Det_Height43 of type sint8
 *   FR_RDR_Det_Height44 of type sint8
 *   FR_RDR_Det_Height45 of type sint8
 *   FR_RDR_Det_Height46 of type sint8
 *   FR_RDR_Det_Height47 of type sint8
 *   FR_RDR_Det_Height48 of type sint8
 *   FR_RDR_Det_Height49 of type sint8
 *   FR_RDR_Det_Height50 of type sint8
 *   FR_RDR_Det_Height51 of type sint8
 *   FR_RDR_Det_Height52 of type sint8
 *   FR_RDR_Det_Height53 of type sint8
 *   FR_RDR_Det_Height54 of type sint8
 *   FR_RDR_Det_Height55 of type sint8
 *   FR_RDR_Det_Height56 of type sint8
 *   FR_RDR_Det_Height57 of type sint8
 *   FR_RDR_Det_Height58 of type sint8
 *   FR_RDR_Det_Height59 of type sint8
 *   FR_RDR_Det_Height60 of type sint8
 *   FR_RDR_Det_Height61 of type sint8
 *   FR_RDR_Det_Height62 of type sint8
 *   FR_RDR_Det_Height63 of type sint8
 *   FR_RDR_Det_Height64 of type sint8
 *   FR_RDR_Det_Attribute01 of type uint8
 *   FR_RDR_Det_Attribute02 of type uint8
 *   FR_RDR_Det_Attribute03 of type uint8
 *   FR_RDR_Det_Attribute04 of type uint8
 *   FR_RDR_Det_Attribute05 of type uint8
 *   FR_RDR_Det_Attribute06 of type uint8
 *   FR_RDR_Det_Attribute07 of type uint8
 *   FR_RDR_Det_Attribute08 of type uint8
 *   FR_RDR_Det_Attribute09 of type uint8
 *   FR_RDR_Det_Attribute10 of type uint8
 *   FR_RDR_Det_Attribute11 of type uint8
 *   FR_RDR_Det_Attribute12 of type uint8
 *   FR_RDR_Det_Attribute13 of type uint8
 *   FR_RDR_Det_Attribute14 of type uint8
 *   FR_RDR_Det_Attribute15 of type uint8
 *   FR_RDR_Det_Attribute16 of type uint8
 *   FR_RDR_Det_Attribute17 of type uint8
 *   FR_RDR_Det_Attribute18 of type uint8
 *   FR_RDR_Det_Attribute19 of type uint8
 *   FR_RDR_Det_Attribute20 of type uint8
 *   FR_RDR_Det_Attribute21 of type uint8
 *   FR_RDR_Det_Attribute22 of type uint8
 *   FR_RDR_Det_Attribute23 of type uint8
 *   FR_RDR_Det_Attribute24 of type uint8
 *   FR_RDR_Det_Attribute25 of type uint8
 *   FR_RDR_Det_Attribute26 of type uint8
 *   FR_RDR_Det_Attribute27 of type uint8
 *   FR_RDR_Det_Attribute28 of type uint8
 *   FR_RDR_Det_Attribute29 of type uint8
 *   FR_RDR_Det_Attribute30 of type uint8
 *   FR_RDR_Det_Attribute31 of type uint8
 *   FR_RDR_Det_Attribute32 of type uint8
 *   FR_RDR_Det_Attribute33 of type uint8
 *   FR_RDR_Det_Attribute34 of type uint8
 *   FR_RDR_Det_Attribute35 of type uint8
 *   FR_RDR_Det_Attribute36 of type uint8
 *   FR_RDR_Det_Attribute37 of type uint8
 *   FR_RDR_Det_Attribute38 of type uint8
 *   FR_RDR_Det_Attribute39 of type uint8
 *   FR_RDR_Det_Attribute40 of type uint8
 *   FR_RDR_Det_Attribute41 of type uint8
 *   FR_RDR_Det_Attribute42 of type uint8
 *   FR_RDR_Det_Attribute43 of type uint8
 *   FR_RDR_Det_Attribute44 of type uint8
 *   FR_RDR_Det_Attribute45 of type uint8
 *   FR_RDR_Det_Attribute46 of type uint8
 *   FR_RDR_Det_Attribute47 of type uint8
 *   FR_RDR_Det_Attribute48 of type uint8
 *   FR_RDR_Det_Attribute49 of type uint8
 *   FR_RDR_Det_Attribute50 of type uint8
 *   FR_RDR_Det_Attribute51 of type uint8
 *   FR_RDR_Det_Attribute52 of type uint8
 *   FR_RDR_Det_Attribute53 of type uint8
 *   FR_RDR_Det_Attribute54 of type uint8
 *   FR_RDR_Det_Attribute55 of type uint8
 *   FR_RDR_Det_Attribute56 of type uint8
 *   FR_RDR_Det_Attribute57 of type uint8
 *   FR_RDR_Det_Attribute58 of type uint8
 *   FR_RDR_Det_Attribute59 of type uint8
 *   FR_RDR_Det_Attribute60 of type uint8
 *   FR_RDR_Det_Attribute61 of type uint8
 *   FR_RDR_Det_Attribute62 of type uint8
 *   FR_RDR_Det_Attribute63 of type uint8
 *   FR_RDR_Det_Attribute64 of type uint8
 *   FR_RDR_Det_TrustA01 of type uint8
 *   FR_RDR_Det_TrustA02 of type uint8
 *   FR_RDR_Det_TrustA03 of type uint8
 *   FR_RDR_Det_TrustA04 of type uint8
 *   FR_RDR_Det_TrustA05 of type uint8
 *   FR_RDR_Det_TrustA06 of type uint8
 *   FR_RDR_Det_TrustA07 of type uint8
 *   FR_RDR_Det_TrustA08 of type uint8
 *   FR_RDR_Det_TrustA09 of type uint8
 *   FR_RDR_Det_TrustA10 of type uint8
 *   FR_RDR_Det_TrustA11 of type uint8
 *   FR_RDR_Det_TrustA12 of type uint8
 *   FR_RDR_Det_TrustA13 of type uint8
 *   FR_RDR_Det_TrustA14 of type uint8
 *   FR_RDR_Det_TrustA15 of type uint8
 *   FR_RDR_Det_TrustA16 of type uint8
 *   FR_RDR_Det_TrustA17 of type uint8
 *   FR_RDR_Det_TrustA18 of type uint8
 *   FR_RDR_Det_TrustA19 of type uint8
 *   FR_RDR_Det_TrustA20 of type uint8
 *   FR_RDR_Det_TrustA21 of type uint8
 *   FR_RDR_Det_TrustA22 of type uint8
 *   FR_RDR_Det_TrustA23 of type uint8
 *   FR_RDR_Det_TrustA24 of type uint8
 *   FR_RDR_Det_TrustA25 of type uint8
 *   FR_RDR_Det_TrustA26 of type uint8
 *   FR_RDR_Det_TrustA27 of type uint8
 *   FR_RDR_Det_TrustA28 of type uint8
 *   FR_RDR_Det_TrustA29 of type uint8
 *   FR_RDR_Det_TrustA30 of type uint8
 *   FR_RDR_Det_TrustA31 of type uint8
 *   FR_RDR_Det_TrustA32 of type uint8
 *   FR_RDR_Det_TrustA33 of type uint8
 *   FR_RDR_Det_TrustA34 of type uint8
 *   FR_RDR_Det_TrustA35 of type uint8
 *   FR_RDR_Det_TrustA36 of type uint8
 *   FR_RDR_Det_TrustA37 of type uint8
 *   FR_RDR_Det_TrustA38 of type uint8
 *   FR_RDR_Det_TrustA39 of type uint8
 *   FR_RDR_Det_TrustA40 of type uint8
 *   FR_RDR_Det_TrustA41 of type uint8
 *   FR_RDR_Det_TrustA42 of type uint8
 *   FR_RDR_Det_TrustA43 of type uint8
 *   FR_RDR_Det_TrustA44 of type uint8
 *   FR_RDR_Det_TrustA45 of type uint8
 *   FR_RDR_Det_TrustA46 of type uint8
 *   FR_RDR_Det_TrustA47 of type uint8
 *   FR_RDR_Det_TrustA48 of type uint8
 *   FR_RDR_Det_TrustA49 of type uint8
 *   FR_RDR_Det_TrustA50 of type uint8
 *   FR_RDR_Det_TrustA51 of type uint8
 *   FR_RDR_Det_TrustA52 of type uint8
 *   FR_RDR_Det_TrustA53 of type uint8
 *   FR_RDR_Det_TrustA54 of type uint8
 *   FR_RDR_Det_TrustA55 of type uint8
 *   FR_RDR_Det_TrustA56 of type uint8
 *   FR_RDR_Det_TrustA57 of type uint8
 *   FR_RDR_Det_TrustA58 of type uint8
 *   FR_RDR_Det_TrustA59 of type uint8
 *   FR_RDR_Det_TrustA60 of type uint8
 *   FR_RDR_Det_TrustA61 of type uint8
 *   FR_RDR_Det_TrustA62 of type uint8
 *   FR_RDR_Det_TrustA63 of type uint8
 *   FR_RDR_Det_TrustA64 of type uint8
 *   FR_RDR_Obj_AlvCnt01Val of type uint8
 *   FR_RDR_Obj_AlvCnt02Val of type uint8
 *   FR_RDR_Obj_AlvCnt03Val of type uint8
 *   FR_RDR_Obj_AlvCnt04Val of type uint8
 *   FR_RDR_Obj_AlvCnt05Val of type uint8
 *   FR_RDR_Obj_AlvCnt06Val of type uint8
 *   FR_RDR_Obj_AlvCnt07Val of type uint8
 *   FR_RDR_Obj_AlvCnt08Val of type uint8
 *   FR_RDR_Obj_AlvCnt09Val of type uint8
 *   FR_RDR_Obj_AlvCnt10Val of type uint8
 *   FR_RDR_Obj_AlvCnt11Val of type uint8
 *   FR_RDR_Obj_AlvCnt12Val of type uint8
 *   FR_RDR_Obj_AlvCnt13Val of type uint8
 *   FR_RDR_Obj_AlvCnt14Val of type uint8
 *   FR_RDR_Obj_AlvCnt15Val of type uint8
 *   FR_RDR_Obj_AlvCnt16Val of type uint8
 *   FR_RDR_Obj_TrkSta01Sta of type uint8
 *   FR_RDR_Obj_TrkSta02Sta of type uint8
 *   FR_RDR_Obj_TrkSta03Sta of type uint8
 *   FR_RDR_Obj_TrkSta04Sta of type uint8
 *   FR_RDR_Obj_TrkSta05Sta of type uint8
 *   FR_RDR_Obj_TrkSta06Sta of type uint8
 *   FR_RDR_Obj_TrkSta07Sta of type uint8
 *   FR_RDR_Obj_TrkSta08Sta of type uint8
 *   FR_RDR_Obj_TrkSta09Sta of type uint8
 *   FR_RDR_Obj_TrkSta10Sta of type uint8
 *   FR_RDR_Obj_TrkSta11Sta of type uint8
 *   FR_RDR_Obj_TrkSta12Sta of type uint8
 *   FR_RDR_Obj_TrkSta13Sta of type uint8
 *   FR_RDR_Obj_TrkSta14Sta of type uint8
 *   FR_RDR_Obj_TrkSta15Sta of type uint8
 *   FR_RDR_Obj_TrkSta16Sta of type uint8
 *   FR_RDR_Obj_TrkSta17Sta of type uint8
 *   FR_RDR_Obj_TrkSta18Sta of type uint8
 *   FR_RDR_Obj_TrkSta19Sta of type uint8
 *   FR_RDR_Obj_TrkSta20Sta of type uint8
 *   FR_RDR_Obj_TrkSta21Sta of type uint8
 *   FR_RDR_Obj_TrkSta22Sta of type uint8
 *   FR_RDR_Obj_TrkSta23Sta of type uint8
 *   FR_RDR_Obj_TrkSta24Sta of type uint8
 *   FR_RDR_Obj_TrkSta25Sta of type uint8
 *   FR_RDR_Obj_TrkSta26Sta of type uint8
 *   FR_RDR_Obj_TrkSta27Sta of type uint8
 *   FR_RDR_Obj_TrkSta28Sta of type uint8
 *   FR_RDR_Obj_TrkSta29Sta of type uint8
 *   FR_RDR_Obj_TrkSta30Sta of type uint8
 *   FR_RDR_Obj_TrkSta31Sta of type uint8
 *   FR_RDR_Obj_TrkSta32Sta of type uint8
 *   FR_RDR_Obj_MvngFlag01Sta of type uint8
 *   FR_RDR_Obj_MvngFlag02Sta of type uint8
 *   FR_RDR_Obj_MvngFlag03Sta of type uint8
 *   FR_RDR_Obj_MvngFlag04Sta of type uint8
 *   FR_RDR_Obj_MvngFlag05Sta of type uint8
 *   FR_RDR_Obj_MvngFlag06Sta of type uint8
 *   FR_RDR_Obj_MvngFlag07Sta of type uint8
 *   FR_RDR_Obj_MvngFlag08Sta of type uint8
 *   FR_RDR_Obj_MvngFlag09Sta of type uint8
 *   FR_RDR_Obj_MvngFlag10Sta of type uint8
 *   FR_RDR_Obj_MvngFlag11Sta of type uint8
 *   FR_RDR_Obj_MvngFlag12Sta of type uint8
 *   FR_RDR_Obj_MvngFlag13Sta of type uint8
 *   FR_RDR_Obj_MvngFlag14Sta of type uint8
 *   FR_RDR_Obj_MvngFlag15Sta of type uint8
 *   FR_RDR_Obj_MvngFlag16Sta of type uint8
 *   FR_RDR_Obj_MvngFlag17Sta of type uint8
 *   FR_RDR_Obj_MvngFlag18Sta of type uint8
 *   FR_RDR_Obj_MvngFlag19Sta of type uint8
 *   FR_RDR_Obj_MvngFlag20Sta of type uint8
 *   FR_RDR_Obj_MvngFlag21Sta of type uint8
 *   FR_RDR_Obj_MvngFlag22Sta of type uint8
 *   FR_RDR_Obj_MvngFlag23Sta of type uint8
 *   FR_RDR_Obj_MvngFlag24Sta of type uint8
 *   FR_RDR_Obj_MvngFlag25Sta of type uint8
 *   FR_RDR_Obj_MvngFlag26Sta of type uint8
 *   FR_RDR_Obj_MvngFlag27Sta of type uint8
 *   FR_RDR_Obj_MvngFlag28Sta of type uint8
 *   FR_RDR_Obj_MvngFlag29Sta of type uint8
 *   FR_RDR_Obj_MvngFlag30Sta of type uint8
 *   FR_RDR_Obj_MvngFlag31Sta of type uint8
 *   FR_RDR_Obj_MvngFlag32Sta of type uint8
 *   FR_RDR_Obj_QualLvl01Sta of type uint8
 *   FR_RDR_Obj_QualLvl02Sta of type uint8
 *   FR_RDR_Obj_QualLvl03Sta of type uint8
 *   FR_RDR_Obj_QualLvl04Sta of type uint8
 *   FR_RDR_Obj_QualLvl05Sta of type uint8
 *   FR_RDR_Obj_QualLvl06Sta of type uint8
 *   FR_RDR_Obj_QualLvl07Sta of type uint8
 *   FR_RDR_Obj_QualLvl08Sta of type uint8
 *   FR_RDR_Obj_QualLvl09Sta of type uint8
 *   FR_RDR_Obj_QualLvl10Sta of type uint8
 *   FR_RDR_Obj_QualLvl11Sta of type uint8
 *   FR_RDR_Obj_QualLvl12Sta of type uint8
 *   FR_RDR_Obj_QualLvl13Sta of type uint8
 *   FR_RDR_Obj_QualLvl14Sta of type uint8
 *   FR_RDR_Obj_QualLvl15Sta of type uint8
 *   FR_RDR_Obj_QualLvl16Sta of type uint8
 *   FR_RDR_Obj_QualLvl17Sta of type uint8
 *   FR_RDR_Obj_QualLvl18Sta of type uint8
 *   FR_RDR_Obj_QualLvl19Sta of type uint8
 *   FR_RDR_Obj_QualLvl20Sta of type uint8
 *   FR_RDR_Obj_QualLvl21Sta of type uint8
 *   FR_RDR_Obj_QualLvl22Sta of type uint8
 *   FR_RDR_Obj_QualLvl23Sta of type uint8
 *   FR_RDR_Obj_QualLvl24Sta of type uint8
 *   FR_RDR_Obj_QualLvl25Sta of type uint8
 *   FR_RDR_Obj_QualLvl26Sta of type uint8
 *   FR_RDR_Obj_QualLvl27Sta of type uint8
 *   FR_RDR_Obj_QualLvl28Sta of type uint8
 *   FR_RDR_Obj_QualLvl29Sta of type uint8
 *   FR_RDR_Obj_QualLvl30Sta of type uint8
 *   FR_RDR_Obj_QualLvl31Sta of type uint8
 *   FR_RDR_Obj_QualLvl32Sta of type uint8
 *   FR_RDR_Obj_AlvAge01Val of type uint8
 *   FR_RDR_Obj_AlvAge02Val of type uint8
 *   FR_RDR_Obj_AlvAge03Val of type uint8
 *   FR_RDR_Obj_AlvAge04Val of type uint8
 *   FR_RDR_Obj_AlvAge05Val of type uint8
 *   FR_RDR_Obj_AlvAge06Val of type uint8
 *   FR_RDR_Obj_AlvAge07Val of type uint8
 *   FR_RDR_Obj_AlvAge08Val of type uint8
 *   FR_RDR_Obj_AlvAge09Val of type uint8
 *   FR_RDR_Obj_AlvAge10Val of type uint8
 *   FR_RDR_Obj_AlvAge11Val of type uint8
 *   FR_RDR_Obj_AlvAge12Val of type uint8
 *   FR_RDR_Obj_AlvAge13Val of type uint8
 *   FR_RDR_Obj_AlvAge14Val of type uint8
 *   FR_RDR_Obj_AlvAge15Val of type uint8
 *   FR_RDR_Obj_AlvAge16Val of type uint8
 *   FR_RDR_Obj_AlvAge17Val of type uint8
 *   FR_RDR_Obj_AlvAge18Val of type uint8
 *   FR_RDR_Obj_AlvAge19Val of type uint8
 *   FR_RDR_Obj_AlvAge20Val of type uint8
 *   FR_RDR_Obj_AlvAge21Val of type uint8
 *   FR_RDR_Obj_AlvAge22Val of type uint8
 *   FR_RDR_Obj_AlvAge23Val of type uint8
 *   FR_RDR_Obj_AlvAge24Val of type uint8
 *   FR_RDR_Obj_AlvAge25Val of type uint8
 *   FR_RDR_Obj_AlvAge26Val of type uint8
 *   FR_RDR_Obj_AlvAge27Val of type uint8
 *   FR_RDR_Obj_AlvAge28Val of type uint8
 *   FR_RDR_Obj_AlvAge29Val of type uint8
 *   FR_RDR_Obj_AlvAge30Val of type uint8
 *   FR_RDR_Obj_AlvAge31Val of type uint8
 *   FR_RDR_Obj_AlvAge32Val of type uint8
 *   FR_RDR_Obj_CoastAge01Val of type uint8
 *   FR_RDR_Obj_CoastAge02Val of type uint8
 *   FR_RDR_Obj_CoastAge03Val of type uint8
 *   FR_RDR_Obj_CoastAge04Val of type uint8
 *   FR_RDR_Obj_CoastAge05Val of type uint8
 *   FR_RDR_Obj_CoastAge06Val of type uint8
 *   FR_RDR_Obj_CoastAge07Val of type uint8
 *   FR_RDR_Obj_CoastAge08Val of type uint8
 *   FR_RDR_Obj_CoastAge09Val of type uint8
 *   FR_RDR_Obj_CoastAge10Val of type uint8
 *   FR_RDR_Obj_CoastAge11Val of type uint8
 *   FR_RDR_Obj_CoastAge12Val of type uint8
 *   FR_RDR_Obj_CoastAge13Val of type uint8
 *   FR_RDR_Obj_CoastAge14Val of type uint8
 *   FR_RDR_Obj_CoastAge15Val of type uint8
 *   FR_RDR_Obj_CoastAge16Val of type uint8
 *   FR_RDR_Obj_CoastAge17Val of type uint8
 *   FR_RDR_Obj_CoastAge18Val of type uint8
 *   FR_RDR_Obj_CoastAge19Val of type uint8
 *   FR_RDR_Obj_CoastAge20Val of type uint8
 *   FR_RDR_Obj_CoastAge21Val of type uint8
 *   FR_RDR_Obj_CoastAge22Val of type uint8
 *   FR_RDR_Obj_CoastAge23Val of type uint8
 *   FR_RDR_Obj_CoastAge24Val of type uint8
 *   FR_RDR_Obj_CoastAge25Val of type uint8
 *   FR_RDR_Obj_CoastAge26Val of type uint8
 *   FR_RDR_Obj_CoastAge27Val of type uint8
 *   FR_RDR_Obj_CoastAge28Val of type uint8
 *   FR_RDR_Obj_CoastAge29Val of type uint8
 *   FR_RDR_Obj_CoastAge30Val of type uint8
 *   FR_RDR_Obj_CoastAge31Val of type uint8
 *   FR_RDR_Obj_CoastAge32Val of type uint8
 *   FR_RDR_Obj_MedRangeMod01Val of type uint8
 *   FR_RDR_Obj_MedRangeMod02Val of type uint8
 *   FR_RDR_Obj_MedRangeMod03Val of type uint8
 *   FR_RDR_Obj_MedRangeMod04Val of type uint8
 *   FR_RDR_Obj_MedRangeMod05Val of type uint8
 *   FR_RDR_Obj_MedRangeMod06Val of type uint8
 *   FR_RDR_Obj_MedRangeMod07Val of type uint8
 *   FR_RDR_Obj_MedRangeMod08Val of type uint8
 *   FR_RDR_Obj_MedRangeMod09Val of type uint8
 *   FR_RDR_Obj_MedRangeMod10Val of type uint8
 *   FR_RDR_Obj_MedRangeMod11Val of type uint8
 *   FR_RDR_Obj_MedRangeMod12Val of type uint8
 *   FR_RDR_Obj_MedRangeMod13Val of type uint8
 *   FR_RDR_Obj_MedRangeMod14Val of type uint8
 *   FR_RDR_Obj_MedRangeMod15Val of type uint8
 *   FR_RDR_Obj_MedRangeMod16Val of type uint8
 *   FR_RDR_Obj_MedRangeMod17Val of type uint8
 *   FR_RDR_Obj_MedRangeMod18Val of type uint8
 *   FR_RDR_Obj_MedRangeMod19Val of type uint8
 *   FR_RDR_Obj_MedRangeMod20Val of type uint8
 *   FR_RDR_Obj_MedRangeMod21Val of type uint8
 *   FR_RDR_Obj_MedRangeMod22Val of type uint8
 *   FR_RDR_Obj_MedRangeMod23Val of type uint8
 *   FR_RDR_Obj_MedRangeMod24Val of type uint8
 *   FR_RDR_Obj_MedRangeMod25Val of type uint8
 *   FR_RDR_Obj_MedRangeMod26Val of type uint8
 *   FR_RDR_Obj_MedRangeMod27Val of type uint8
 *   FR_RDR_Obj_MedRangeMod28Val of type uint8
 *   FR_RDR_Obj_MedRangeMod29Val of type uint8
 *   FR_RDR_Obj_MedRangeMod30Val of type uint8
 *   FR_RDR_Obj_MedRangeMod31Val of type uint8
 *   FR_RDR_Obj_MedRangeMod32Val of type uint8
 *   FR_RDR_Obj_RefObjID01Val of type uint8
 *   FR_RDR_Obj_RefObjID02Val of type uint8
 *   FR_RDR_Obj_RefObjID03Val of type uint8
 *   FR_RDR_Obj_RefObjID04Val of type uint8
 *   FR_RDR_Obj_RefObjID05Val of type uint8
 *   FR_RDR_Obj_RefObjID06Val of type uint8
 *   FR_RDR_Obj_RefObjID07Val of type uint8
 *   FR_RDR_Obj_RefObjID08Val of type uint8
 *   FR_RDR_Obj_RefObjID09Val of type uint8
 *   FR_RDR_Obj_RefObjID10Val of type uint8
 *   FR_RDR_Obj_RefObjID11Val of type uint8
 *   FR_RDR_Obj_RefObjID12Val of type uint8
 *   FR_RDR_Obj_RefObjID13Val of type uint8
 *   FR_RDR_Obj_RefObjID14Val of type uint8
 *   FR_RDR_Obj_RefObjID15Val of type uint8
 *   FR_RDR_Obj_RefObjID16Val of type uint8
 *   FR_RDR_Obj_RefObjID17Val of type uint8
 *   FR_RDR_Obj_RefObjID18Val of type uint8
 *   FR_RDR_Obj_RefObjID19Val of type uint8
 *   FR_RDR_Obj_RefObjID20Val of type uint8
 *   FR_RDR_Obj_RefObjID21Val of type uint8
 *   FR_RDR_Obj_RefObjID22Val of type uint8
 *   FR_RDR_Obj_RefObjID23Val of type uint8
 *   FR_RDR_Obj_RefObjID24Val of type uint8
 *   FR_RDR_Obj_RefObjID25Val of type uint8
 *   FR_RDR_Obj_RefObjID26Val of type uint8
 *   FR_RDR_Obj_RefObjID27Val of type uint8
 *   FR_RDR_Obj_RefObjID28Val of type uint8
 *   FR_RDR_Obj_RefObjID29Val of type uint8
 *   FR_RDR_Obj_RefObjID30Val of type uint8
 *   FR_RDR_Obj_RefObjID31Val of type uint8
 *   FR_RDR_Obj_RefObjID32Val of type uint8
 *   FR_RDR_DTC_RadarAliveCounter of type uint8
 *   FR_RDR_DTC_BatteryVoltageHigh of type uint8
 *   FR_RDR_DTC_BatteryVoltageLow of type uint8
 *   FR_RDR_DTC_RadarHwError of type uint8
 *   FR_RDR_DTC_SystemOutOfCalibration_EOL of type uint8
 *   FR_RDR_DTC_SystemOutOfCalibration_DRV of type uint8
 *   FR_RDR_DTC_Blockage_Init of type uint8
 *   FR_RDR_DTC_Blockage_Drv of type uint8
 *   FR_RDR_DTC_RadarHwTempCondition_High of type uint8
 *   FR_RDR_DTC_RadarHwTempCondition_Low of type uint8
 *   FR_RDR_DTC_RadarCANCommError of type uint8
 *   FR_RDR_Det_Mov01 of type boolean
 *   FR_RDR_Det_Mov02 of type boolean
 *   FR_RDR_Det_Mov03 of type boolean
 *   FR_RDR_Det_Mov04 of type boolean
 *   FR_RDR_Det_Mov05 of type boolean
 *   FR_RDR_Det_Mov06 of type boolean
 *   FR_RDR_Det_Mov07 of type boolean
 *   FR_RDR_Det_Mov08 of type boolean
 *   FR_RDR_Det_Mov09 of type boolean
 *   FR_RDR_Det_Mov10 of type boolean
 *   FR_RDR_Det_Mov11 of type boolean
 *   FR_RDR_Det_Mov12 of type boolean
 *   FR_RDR_Det_Mov13 of type boolean
 *   FR_RDR_Det_Mov14 of type boolean
 *   FR_RDR_Det_Mov15 of type boolean
 *   FR_RDR_Det_Mov16 of type boolean
 *   FR_RDR_Det_Mov17 of type boolean
 *   FR_RDR_Det_Mov18 of type boolean
 *   FR_RDR_Det_Mov19 of type boolean
 *   FR_RDR_Det_Mov20 of type boolean
 *   FR_RDR_Det_Mov21 of type boolean
 *   FR_RDR_Det_Mov22 of type boolean
 *   FR_RDR_Det_Mov23 of type boolean
 *   FR_RDR_Det_Mov24 of type boolean
 *   FR_RDR_Det_Mov25 of type boolean
 *   FR_RDR_Det_Mov26 of type boolean
 *   FR_RDR_Det_Mov27 of type boolean
 *   FR_RDR_Det_Mov28 of type boolean
 *   FR_RDR_Det_Mov29 of type boolean
 *   FR_RDR_Det_Mov30 of type boolean
 *   FR_RDR_Det_Mov31 of type boolean
 *   FR_RDR_Det_Mov32 of type boolean
 *   FR_RDR_Det_Mov33 of type boolean
 *   FR_RDR_Det_Mov34 of type boolean
 *   FR_RDR_Det_Mov35 of type boolean
 *   FR_RDR_Det_Mov36 of type boolean
 *   FR_RDR_Det_Mov37 of type boolean
 *   FR_RDR_Det_Mov38 of type boolean
 *   FR_RDR_Det_Mov39 of type boolean
 *   FR_RDR_Det_Mov40 of type boolean
 *   FR_RDR_Det_Mov41 of type boolean
 *   FR_RDR_Det_Mov42 of type boolean
 *   FR_RDR_Det_Mov43 of type boolean
 *   FR_RDR_Det_Mov44 of type boolean
 *   FR_RDR_Det_Mov45 of type boolean
 *   FR_RDR_Det_Mov46 of type boolean
 *   FR_RDR_Det_Mov47 of type boolean
 *   FR_RDR_Det_Mov48 of type boolean
 *   FR_RDR_Det_Mov49 of type boolean
 *   FR_RDR_Det_Mov50 of type boolean
 *   FR_RDR_Det_Mov51 of type boolean
 *   FR_RDR_Det_Mov52 of type boolean
 *   FR_RDR_Det_Mov53 of type boolean
 *   FR_RDR_Det_Mov54 of type boolean
 *   FR_RDR_Det_Mov55 of type boolean
 *   FR_RDR_Det_Mov56 of type boolean
 *   FR_RDR_Det_Mov57 of type boolean
 *   FR_RDR_Det_Mov58 of type boolean
 *   FR_RDR_Det_Mov59 of type boolean
 *   FR_RDR_Det_Mov60 of type boolean
 *   FR_RDR_Det_Mov61 of type boolean
 *   FR_RDR_Det_Mov62 of type boolean
 *   FR_RDR_Det_Mov63 of type boolean
 *   FR_RDR_Det_Mov64 of type boolean
 *   FR_RDR_Det_Valid01 of type boolean
 *   FR_RDR_Det_Valid02 of type boolean
 *   FR_RDR_Det_Valid03 of type boolean
 *   FR_RDR_Det_Valid04 of type boolean
 *   FR_RDR_Det_Valid05 of type boolean
 *   FR_RDR_Det_Valid06 of type boolean
 *   FR_RDR_Det_Valid07 of type boolean
 *   FR_RDR_Det_Valid08 of type boolean
 *   FR_RDR_Det_Valid09 of type boolean
 *   FR_RDR_Det_Valid10 of type boolean
 *   FR_RDR_Det_Valid11 of type boolean
 *   FR_RDR_Det_Valid12 of type boolean
 *   FR_RDR_Det_Valid13 of type boolean
 *   FR_RDR_Det_Valid14 of type boolean
 *   FR_RDR_Det_Valid15 of type boolean
 *   FR_RDR_Det_Valid16 of type boolean
 *   FR_RDR_Det_Valid17 of type boolean
 *   FR_RDR_Det_Valid18 of type boolean
 *   FR_RDR_Det_Valid19 of type boolean
 *   FR_RDR_Det_Valid20 of type boolean
 *   FR_RDR_Det_Valid21 of type boolean
 *   FR_RDR_Det_Valid22 of type boolean
 *   FR_RDR_Det_Valid23 of type boolean
 *   FR_RDR_Det_Valid24 of type boolean
 *   FR_RDR_Det_Valid25 of type boolean
 *   FR_RDR_Det_Valid26 of type boolean
 *   FR_RDR_Det_Valid27 of type boolean
 *   FR_RDR_Det_Valid28 of type boolean
 *   FR_RDR_Det_Valid29 of type boolean
 *   FR_RDR_Det_Valid30 of type boolean
 *   FR_RDR_Det_Valid31 of type boolean
 *   FR_RDR_Det_Valid32 of type boolean
 *   FR_RDR_Det_Valid33 of type boolean
 *   FR_RDR_Det_Valid34 of type boolean
 *   FR_RDR_Det_Valid35 of type boolean
 *   FR_RDR_Det_Valid36 of type boolean
 *   FR_RDR_Det_Valid37 of type boolean
 *   FR_RDR_Det_Valid38 of type boolean
 *   FR_RDR_Det_Valid39 of type boolean
 *   FR_RDR_Det_Valid40 of type boolean
 *   FR_RDR_Det_Valid41 of type boolean
 *   FR_RDR_Det_Valid42 of type boolean
 *   FR_RDR_Det_Valid43 of type boolean
 *   FR_RDR_Det_Valid44 of type boolean
 *   FR_RDR_Det_Valid45 of type boolean
 *   FR_RDR_Det_Valid46 of type boolean
 *   FR_RDR_Det_Valid47 of type boolean
 *   FR_RDR_Det_Valid48 of type boolean
 *   FR_RDR_Det_Valid49 of type boolean
 *   FR_RDR_Det_Valid50 of type boolean
 *   FR_RDR_Det_Valid51 of type boolean
 *   FR_RDR_Det_Valid52 of type boolean
 *   FR_RDR_Det_Valid53 of type boolean
 *   FR_RDR_Det_Valid54 of type boolean
 *   FR_RDR_Det_Valid55 of type boolean
 *   FR_RDR_Det_Valid56 of type boolean
 *   FR_RDR_Det_Valid57 of type boolean
 *   FR_RDR_Det_Valid58 of type boolean
 *   FR_RDR_Det_Valid59 of type boolean
 *   FR_RDR_Det_Valid60 of type boolean
 *   FR_RDR_Det_Valid61 of type boolean
 *   FR_RDR_Det_Valid62 of type boolean
 *   FR_RDR_Det_Valid63 of type boolean
 *   FR_RDR_Det_Valid64 of type boolean
 * SccInputFromFca_t: Record with elements
 *   u8_Radar_Match_Ch_1 of type uint8
 *   u8_Radar_Match_Ch_2 of type uint8
 *   u8_Radar_Match_Ch_3 of type uint8
 *   u8_Radar_Match_Ch_4 of type uint8
 *   u8_Radar_Match_Ch_5 of type uint8
 *   u8_Radar_Match_Ch_6 of type uint8
 *   u8_Radar_Match_Ch_7 of type uint8
 *   u8_Radar_Match_Ch_8 of type uint8
 *   u8_Radar_Match_ID_1 of type uint8
 *   u8_Radar_Match_ID_2 of type uint8
 *   u8_Radar_Match_ID_3 of type uint8
 *   u8_Radar_Match_ID_4 of type uint8
 *   u8_Radar_Match_ID_5 of type uint8
 *   u8_Radar_Match_ID_6 of type uint8
 *   u8_Radar_Match_ID_7 of type uint8
 *   u8_Radar_Match_ID_8 of type uint8
 *   u8_Radar_Match_Flag_1 of type uint8
 *   u8_Radar_Match_Flag_2 of type uint8
 *   u8_Radar_Match_Flag_3 of type uint8
 *   u8_Radar_Match_Flag_4 of type uint8
 *   u8_Radar_Match_Flag_5 of type uint8
 *   u8_Radar_Match_Flag_6 of type uint8
 *   u8_Radar_Match_Flag_7 of type uint8
 *   u8_Radar_Match_Flag_8 of type uint8
 *   u8_Radar_Match_Value_1 of type uint8
 *   u8_Radar_Match_Value_2 of type uint8
 *   u8_Radar_Match_Value_3 of type uint8
 *   u8_Radar_Match_Value_4 of type uint8
 *   u8_Radar_Match_Value_5 of type uint8
 *   u8_Radar_Match_Value_6 of type uint8
 *   u8_Radar_Match_Value_7 of type uint8
 *   u8_Radar_Match_Value_8 of type uint8
 *   u16_Radar_Match_Value1_1 of type uint16
 *   u16_Radar_Match_Value1_2 of type uint16
 *   u16_Radar_Match_Value1_3 of type uint16
 *   u16_Radar_Match_Value1_4 of type uint16
 *   u16_Radar_Match_Value1_5 of type uint16
 *   u16_Radar_Match_Value1_6 of type uint16
 *   u16_Radar_Match_Value1_7 of type uint16
 *   u16_Radar_Match_Value1_8 of type uint16
 * ZfAppCameraState_t: Record with elements
 *   CameraState_u8 of type uint8
 *   Camera_SubState_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u8 of type uint8
 *
 *********************************************************************************************************************/


#define CpApFca_START_SEC_CODE
#include "CpApFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataRead(FcaNvmSaveVal_t *FcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FcaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFcaInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFcaInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFcaInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaVersionReq
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_FcaAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_CpApFcaAppVersionInfo(void)
 *   void Rte_Exit_ExclusiveArea_CpApFcaAppVersionInfo(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApFcaVersionReq(FcaAppVersionInfo_t *FcaAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FcaAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFcaVersionReq_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApFca_CODE) Re_CpApFcaVersionReq(P2VAR(FcaAppVersionInfo_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FcaAppVestionInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFcaVersionReq (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCTG
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCTG_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCTG(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCTG
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcJT_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcJT(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcJT
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcVEH
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcVEH_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcVEH(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcVEH
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcVRU
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcVRU_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcVRU(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCmdcVRU
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCtgJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCtgJT_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCtgJT(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcCtgJT
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcOIF
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcOIF_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcOIF(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcOIF
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcVmpJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcVmpJT_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_EbcVmpJT(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_EbcVmpJT
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_FcaOUTPUT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_ADAS101_De_ADAS101(const ADAS101_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaEDR_De_FcaInternalOutToEDR(const FcaEDR_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaFrCmrOut_De_FcaFrCmrOut(const FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaOutput_De_FcaOutput(const FcaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaUxOutToIvc_De_FcaUxOutToIvc(const FcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInputFromFca_De_SccInputFromFca(const SccInputFromFca_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataWrite(const FcaNvmSaveVal_t *FcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FcaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_FcaOUTPUT_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_FcaOUTPUT(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_FcaOUTPUT
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_FcaSDF
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn01_De_FcaDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn02_De_FcaDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn03_De_FcaDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn04_De_FcaDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn05_De_FcaDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn06_De_FcaDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFailSafeInfo_De_FcaFailSafeInfo(FcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInput_De_FcaInput(FcaInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA(FcaInternalInFromCOFCA_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(FcaInternalInFromLSS_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd(FrCmrHdrFcfVd_t *FrCmrHdrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru(FrCmrHdrFcfVru_t *FrCmrHdrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_RdrInfo_getRdrInfo(RdrInfo_t *Rdrmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_RdrInfo_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_FcaSDF_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_FcaSDF(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_FcaSDF
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_IntegratedSTM
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_IntegratedSTM_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApFca_CODE) Re_CpApFca_IntegratedSTM(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApFca_IntegratedSTM
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApFca_STOP_SEC_CODE
#include "CpApFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCmdcCYL)  **************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCmdcPED_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCmdcCYL_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCmdcPED)  **************************/


/***  End of saved code  ************************************************************************************/
#endif


#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFcaAppVersionInfo)  ***********************/

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_IntegratedSTM)  ***********************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCmdcVRU)  **************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_FcaOUTPUT)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_FcaSDF)  ******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCAInit_doc)  **********************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcOIF)  ******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCmdcJT)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_FcaOUTPUT_doc)  ****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcOIF_doc)  *******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcVmpJT_doc)  *****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCmdcVRU_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCmdcVEH)  **************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcVmpJT)  ****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCtgJT_doc)  *****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCTG_doc)  *******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_IntegratedSTM_doc)  ************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCAInit)  *********************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCTG)  ******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCmdcVEH_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_FcaSDF_doc)  *******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApFCA_EbcCtgJT)  ****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFcaAppVersionInfo_doc)  ************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApFCA_EbcCmdcJT_doc)  ****************************/


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
