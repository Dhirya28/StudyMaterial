/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApIslw.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIslw
 *  Generation Time:  2023-04-20 13:53:22
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApIslw>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * TimeInMicrosecondsType
 *   uint32 represents integers with a minimum value of 0 and a maximum value 
 *      of 4294967295. The order-relation on uint32 is: x < y if y - x is positive.
 *      uint32 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39). 
 *      
 *      For example: 1, 0, 12234567, 104400.
 *
 *
 * Operation Prototypes:
 * =====================
 * GetCounterValue of Port Interface Os_Service
 *   This service reads the current count value of a counter (returning either the hardware timer ticks if counter is driven by hardware or the software ticks when user drives counter).
 *
 * GetElapsedValue of Port Interface Os_Service
 *   This service gets the number of ticks between the current tick value and a previously read tick value.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApIslw.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * TimeInMicrosecondsType: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Array Types:
 * ============
 * Rte_DT_IslwFrqNvData_t_24: Array with 3 element(s) of type Rte_DT_IslwFrqNvData_t_24_0
 * Rte_DT_IslwFrqNvData_t_24_0: Array with 1 element(s) of type uint8
 *
 * Record Types:
 * =============
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * DeLogicDbgInput_t: Record with elements
 *   u32_DbgDataIn_01 of type uint32
 *   u32_DbgDataIn_02 of type uint32
 *   u32_DbgDataIn_03 of type uint32
 *   u32_DbgDataIn_04 of type uint32
 *   u32_DbgDataIn_05 of type uint32
 *   u32_DbgDataIn_06 of type uint32
 *   u32_DbgDataIn_07 of type uint32
 *   u32_DbgDataIn_08 of type uint32
 *   u32_DbgDataIn_09 of type uint32
 *   u32_DbgDataIn_10 of type uint32
 *   u32_DbgDataIn_11 of type uint32
 *   u32_DbgDataIn_12 of type uint32
 *   u32_DbgDataIn_13 of type uint32
 *   u32_DbgDataIn_14 of type uint32
 *   u32_DbgDataIn_15 of type uint32
 *   u32_DbgDataIn_16 of type uint32
 * DeLogicDbgOutput_t: Record with elements
 *   u32_DbgData_01 of type uint32
 *   u32_DbgData_02 of type uint32
 *   u32_DbgData_03 of type uint32
 *   u32_DbgData_04 of type uint32
 *   u32_DbgData_05 of type uint32
 *   u32_DbgData_06 of type uint32
 *   u32_DbgData_07 of type uint32
 *   u32_DbgData_08 of type uint32
 *   u32_DbgData_09 of type uint32
 *   u32_DbgData_10 of type uint32
 *   u32_DbgData_11 of type uint32
 *   u32_DbgData_12 of type uint32
 *   u32_DbgData_13 of type uint32
 *   u32_DbgData_14 of type uint32
 *   u32_DbgData_15 of type uint32
 *   u32_DbgData_16 of type uint32
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FailSafe_t: Record with elements
 *   FS_CRC of type uint32
 *   FS_Camera_ID of type uint8
 *   FS_Free_Sight of type boolean
 *   FS_Splashes of type uint8
 *   FS_Sun_Ray of type uint8
 *   FS_Low_Sun of type uint8
 *   FS_Blur_Image of type uint8
 *   FS_Partial_Blockage of type uint8
 *   FS_Full_Blockage of type uint8
 *   FS_Frozen_Windshield_Lens of type uint8
 *   FS_Out_Of_Focus of type uint8
 *   FS_C2C_Out_Of_Calib of type uint8
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 * FrCmrHdrFS_t: Record with elements
 *   FS_Header_CRC of type uint32
 *   FS_Protocol_Version of type uint8
 *   FS_Sync_ID of type uint8
 *   FS_Cameras_Number of type uint8
 *   FS_TSR_Out_OF_Calib of type uint8
 *   FS_Out_Of_Calib of type uint8
 *   FS_Impacted_Technologies of type uint16
 *   FS_Rain of type uint8
 *   FS_Fog of type uint8
 *   FS_C2W_OOR of type uint8
 * IslaUxOutToIvc_t: Record with elements
 *   ux_TT_ISLA_SpdLimTrffcSgnSta of type uint8
 *   ux_TT_ISLA_SpdLimTrffcSgnVal of type uint8
 *   ux_TT_ISLA_TrffcSgnCntryInfoSta of type uint8
 *   ux_TT_ISLA_AddtnlTrffcSgnSta of type uint8
 *   ux_TT_ISLA_SuppTrffcSgnSta of type uint8
 *   ux_ISLA_TrffcSgnBlnkngSta of type uint8
 *   ux_SMV_SetSpdSta_ISLA of type uint8
 *   ux_SMV_ISLA_SetSpdSymbSta of type uint8
 *   ux_ISLA_SetSpdSymbBlnkngSta of type uint8
 *   ux_PU_F_Group7_ISLA_FlrSta of type uint8
 *   ux_PU_M_Group2_ISLA_ADASWarn1_1Sta of type uint8
 *   ux_SND_ADAS_Warn1_3Sta of type uint8
 * IslwAppVersionInfo_t: Record with elements
 *   u16_IslwAppVersion of type uint16
 * IslwEyeQInput_t: Record with elements
 *   u8_TSR_Sign_Count of type uint8
 *   u8_TSR_Sync_ID of type uint8
 *   u8_DrivingSideME of type uint8
 * IslwFailInfo_t: Record with elements
 *   u8_Timeout_HU_Navi_ISLW_PE_00 of type uint8
 *   u8_Timeout_HU_MON_PE_01 of type uint8
 *   u8_ActiveFault of type uint8
 *   u8_BlockageFault of type uint8
 * IslwFrqNvData_t: Record with elements
 *   u16_Nvm_Navi_CountryCode of type uint16
 *   u8_SLIF_Speed_Display_Cluster of type uint8
 *   u8_SLIF_Speed_Display_Navi of type uint8
 *   u8_SLIF_VS_Unit of type uint8
 *   u8_Navi_SLIF_LinkClass_NVM of type uint8
 *   u8_SLIF_Former_Speed_Limit_From of type uint8
 *   u8_Nvm_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_ISLA_OptUsmSta of type uint8
 *   u8_Nvm_ISLA_Cntry of type uint8
 *   b_Nvm_Navi_On of type boolean
 *   u8_Nvm_ISLA_Cntry1USMSta of type uint8
 *   u8_Nvm_ISLA_Cntry2USMSta of type uint8
 *   u8_Nvm_ISLA_CntryVerTyp of type uint8
 *   u8_Nvm_USER_ID of type uint8
 *   u8_Nvm_OffsetUSM_User1 of type uint8
 *   u8_Nvm_OffsetUSM_User2 of type uint8
 *   u8_Nvm_OffsetUSM_Geust of type uint8
 *   u8_Nvm_NRS_USM_User1 of type uint8
 *   u8_Nvm_NRS_USM_User2 of type uint8
 *   u8_Nvm_NRS_USM_Guest of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_SunRay_Status of type uint8
 *   u8_RawValueCamolny_CLUMain of type uint8
 *   Reserved of type Rte_DT_IslwFrqNvData_t_24
 * IslwInput_t: Record with elements
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u16_aReqValue of type uint16
 * IslwOccNvData_t: Record with elements
 *   u32_SLIF_MIN_TSR_DIST_MOTORWAY_SIGN_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_PASS_JC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_ENTER_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_IC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXPIRE_TIMER_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_NON_HW of type uint32
 *   u32_SLIF_Rain_Decision_Period of type uint32
 *   u32_SLIF_Rain_Off_Decision_Period of type uint32
 *   u32_SLIF_MAX_TSR_DIST_EXTRA_DELAY_NOSPDLMT_BY_NAVI of type uint32
 *   u32_SLIF_MAX_TSR_DIST_LATRANGE_ARROW_SIGN_HWEXIT of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_ARROW_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_RAIN_SIGN_HW of type uint32
 *   u32_SLIF_MIN_TSR_SAS_TURNDEC of type uint32
 *   u32_SLIF_BLOCKAGE_RUNTIME of type uint32
 *   u8_SLIF_SET_TSR_TIMER_MODE of type uint8
 *   u8_Nvm_Occ_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_AutoUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_OptUsmSta of type uint8
 *   u16_IslwAppVersion of type uint16
 *   Reserved1 of type uint16
 *   Reserved2 of type uint16
 *   Reserved3 of type uint16
 *   Reserved4 of type uint16
 *   Reserved5 of type uint16
 *   Reserved6 of type uint16
 *   Reserved7 of type uint16
 * IslwOutput_t: Record with elements
 *   u8_ISLW_Status of type uint8
 *   u8_ISLW_Spd_Dis_CLU_Main of type uint8
 *   u8_ISLW_Spd_Dis_NAVI_Main of type uint8
 *   u8_ISLA_SpdwOffst of type uint8
 *   u8_ISLA_SwIgnoreReq of type uint8
 *   u8_ISLA_SpdChgReq of type uint8
 *   u8_ISLA_SpdWrn of type uint8
 *   u8_ISLA_SymFlashMod of type uint8
 *   u8_ISLA_Popup of type uint8
 *   u8_ISLA_OptUsmSta of type uint8
 *   u8_ISLA_OffstUsmSta of type uint8
 *   u8_ISLA_Cntry of type uint8
 *   u8_ISLA_AddtnlSign of type uint8
 *   u8_ISLA_AutoSetSpdSta of type uint8
 *   u8_ISLA_CondInfoDisp of type uint8
 *   u8_ISLA_SndReqSta of type uint8
 *   u8_ISLA_NAOffstUSMSta of type uint8
 *   u8_ISLA_EUCntry1USMSta of type uint8
 *   u8_ISLA_EUCntry2USMSta of type uint8
 *   u8_ISLA_EUCntryVertyp of type uint8
 *   u8_ISLA_NACntry1USMSta of type uint8
 *   u8_ISLA_NACntry2USMSta of type uint8
 *   u8_ISLA_NACntryVertyp of type uint8
 *   u8_ISLA_SpdLimVal of type uint8
 *   u8_ISLA_TSRSpdLimEnfrcmtSta of type uint8
 * IslwTSRInfo_t: Record with elements
 *   u16_TSR_Sign_Name of type uint16
 *   u8_TSR_Relevancy of type uint8
 *   u8_TSR_Sup1_SignName of type uint8
 *   u8_TSR_Sup2_SignName of type uint8
 *   u16_TSR_Sign_Long_Distance of type uint16
 *   u16_TSR_Sign_Lateral_Distance of type uint16
 *   u16_TSR_Sign_Height of type uint16
 *   u8_TSR_ID of type uint8
 *   u8_TSR_Sup1_Confidence of type uint8
 *   u8_TSR_Sup2_Confidence of type uint8
 *   u8_TSR_Sign_Shape of type uint8
 *   u8_TSR_Sign_Is_Electronic of type boolean
 *   u8_TSR_Confidence of type uint8
 *   u16_TSR_Sign_Long_Distance_STD of type uint16
 *   u16_TSR_Sign_Lat_Distance_STD of type uint16
 *   u16_TSR_Sign_Height_STD of type uint16
 *   u16_TSR_Sign_Panel_Width of type uint16
 *   u16_TSR_Sign_Panel_Height of type uint16
 *   u16_TSR_Sign_Panel_Width_STD of type uint16
 *   u16_TSR_Sign_Panel_Height_STD of type uint16
 *   u16_Tracking_Out_of_Image of type uint16
 *   u16_TSR_Tracking_Age of type uint16
 * LanesHost_t: Record with elements
 *   LH_CRC of type uint32
 *   LH_Is_Triggered_SDM_Type of type uint8
 *   LH_Is_Triggered_SDM_Model of type uint8
 *   LH_Track_ID of type uint8
 *   LH_Age of type uint8
 *   LH_Confidence of type uint8
 *   LH_Prediction_Reason of type uint8
 *   LH_Availability_State of type uint8
 *   LH_Color of type uint8
 *   LH_Color_Confidence of type uint8
 *   LH_Lanemark_Type of type uint8
 *   LH_DLM_Type of type uint8
 *   LH_DECEL_Type of type uint8
 *   LH_Lanemark_Type_Conf of type uint8
 *   LH_Side of type uint8
 *   LH_Crossing of type boolean
 *   LH_Marker_Width of type uint8
 *   LH_Marker_Width_STD of type uint8
 *   LH_Dash_Average_Available of type boolean
 *   LH_Dash_Average_Length of type uint8
 *   LH_Dash_Average_Gap of type uint8
 *   LH_Is_Multi_Clothoid of type boolean
 *   LH_Line_First_C0 of type float32
 *   LH_Line_First_C1 of type float32
 *   LH_Line_First_C2 of type float32
 *   LH_Line_First_C3 of type float32
 *   LH_First_VR_Start of type uint16
 *   LH_First_VR_End of type uint16
 *   LH_First_Measured_VR_End of type uint16
 *   LH_Second_Measured_VR_End of type uint16
 *   LH_Line_Second_C0 of type float32
 *   LH_Line_Second_C1 of type float32
 *   LH_Line_Second_C2 of type float32
 *   LH_Line_Second_C3 of type float32
 *   LH_Second_VR_Start of type uint16
 *   LH_Second_VR_End of type uint16
 *   LH_Is_Construction_Area of type boolean
 * ZfAppCameraState_t: Record with elements
 *   CameraState_u8 of type uint8
 *   Camera_SubState_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u8 of type uint8
 *
 *********************************************************************************************************************/


#define CpApIslw_START_SEC_CODE
#include "CpApIslw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwFrqNvData_ReadIslwFrqNvData(IslwFrqNvData_t *IslwFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwOccNvData_ReadIslwOccNvData(IslwOccNvData_t *IslwOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslw_CODE) Re_CpApIslwInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn01_De_IslwDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn02_De_IslwDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn03_De_IslwDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn04_De_IslwDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn05_De_IslwDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwDbgIn06_De_IslwDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwFailInfo_De_IslwFailInfo(IslwFailInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwInput_De_IslwInput(IslwInput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_IslaUxOutToIvc_De_IslaUxOutToIvc(const IslaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwOutput_De_IslwOutput(const IslwOutput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwEyeQInput_getIslwEyeQInput(IslwEyeQInput_t *IslwEyeQInput)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IslwFrqNvData_WriteIslwFrqNvData(const IslwFrqNvData_t *IslwFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwOccNvData_WriteIslwOccNvData(const IslwOccNvData_t *IslwOccNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwOccNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_TsrInfo_getTsrInfo(IslwTSRInfo_t *TsrInfo)
 *     Synchronous Server Invocation. Timeout: None
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslw_CODE) Re_CpApIslwMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_IslwAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwVersionReq(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwVersionReq_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIslw_CODE) Re_CpApIslwVersionReq(P2VAR(IslwAppVersionInfo_t, AUTOMATIC, RTE_CPAPISLW_APPL_VAR) IslwAppVestionInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwVersionReq (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApIslw_STOP_SEC_CODE
#include "CpApIslw_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApIslwVersionInfo_doc)  **************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApIslwVersionInfo)  *************************/

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
