/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApLss.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLss
 *  Generation Time:  2023-04-20 13:52:40
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApLss> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPLSS_H
# define _RTE_CPAPLSS_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApLss_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApLss
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApLss, RTE_CONST, RTE_CONST) Rte_Inst_CpApLss; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApLss, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_Core2ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_DawOutToLss_De_DawOutToLss(P2VAR(DawOutToLss_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(P2VAR(LssCanSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn01_De_LssDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn02_De_LssDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn03_De_LssDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn04_De_LssDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn05_De_LssDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssDbgIn06_De_LssDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssInput_De_LssInput(P2VAR(LssInput_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_LssMeInfo_De_LssMeInfo(P2VAR(LssMeInfo_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApLss_RP_MrmUxOutToLss_De_MrmUxOutToIvc(P2VAR(LssMrmUxOutToIvc_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS(P2CONST(CoFcaInternalInFromLSS_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(P2CONST(FcaInternalInFromLSS_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssOutput_De_LssOutput(P2CONST(LssOutput_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_LssUxOutToIvc_De_LssUxOutToIvc(P2CONST(LssUxOutToIvc_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApLss_PP_SccInternalInFromLSS_De_SccInternalInFromLSS(P2CONST(SccInternalInFromLSS_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrHdrLDW_getFrCmrHdrLDW(P2VAR(FrCmrHdrLDW_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrHdrLDW); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(P2VAR(FrCmrHdrLnHost_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrHdrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrHdrLnRdEdg_getFrCmrHdrLnRdEdg(P2VAR(FrCmrHdrLnRdEdg_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrHdrLnRdEdg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrLDW_getFrCmrLDW(P2VAR(LDW_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrLDW); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrLnRdEdg_getFrCmrLnRdEdg(P2VAR(LanesRoadEdge_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrLnRdEdg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_LssFrqNvData_ReadLssFrqNvData(P2VAR(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) LssFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_LssFrqNvData_WriteLssFrqNvData(P2CONST(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSS_APPL_DATA) LssFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApLss_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApLss_RP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_DawOutToLss_De_DawOutToLss Rte_Read_CpApLss_RP_DawOutToLss_De_DawOutToLss
# define Rte_Read_RP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo Rte_Read_CpApLss_RP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo
# define Rte_Read_RP_LssDbgIn01_De_LssDbgIn01 Rte_Read_CpApLss_RP_LssDbgIn01_De_LssDbgIn01
# define Rte_Read_RP_LssDbgIn02_De_LssDbgIn02 Rte_Read_CpApLss_RP_LssDbgIn02_De_LssDbgIn02
# define Rte_Read_RP_LssDbgIn03_De_LssDbgIn03 Rte_Read_CpApLss_RP_LssDbgIn03_De_LssDbgIn03
# define Rte_Read_RP_LssDbgIn04_De_LssDbgIn04 Rte_Read_CpApLss_RP_LssDbgIn04_De_LssDbgIn04
# define Rte_Read_RP_LssDbgIn05_De_LssDbgIn05 Rte_Read_CpApLss_RP_LssDbgIn05_De_LssDbgIn05
# define Rte_Read_RP_LssDbgIn06_De_LssDbgIn06 Rte_Read_CpApLss_RP_LssDbgIn06_De_LssDbgIn06
# define Rte_Read_RP_LssInput_De_LssInput Rte_Read_CpApLss_RP_LssInput_De_LssInput
# define Rte_Read_RP_LssMeInfo_De_LssMeInfo Rte_Read_CpApLss_RP_LssMeInfo_De_LssMeInfo
# define Rte_Read_RP_MrmUxOutToLss_De_MrmUxOutToIvc Rte_Read_CpApLss_RP_MrmUxOutToLss_De_MrmUxOutToIvc


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS Rte_Write_CpApLss_PP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS
# define Rte_Write_PP_FcaInternalInFromLSS_De_FcaInternalInFromLSS Rte_Write_CpApLss_PP_FcaInternalInFromLSS_De_FcaInternalInFromLSS
# define Rte_Write_PP_LssLogicDbgOutput01_De_LssLogicDbgOutput01 Rte_Write_CpApLss_PP_LssLogicDbgOutput01_De_LssLogicDbgOutput01
# define Rte_Write_PP_LssLogicDbgOutput02_De_LssLogicDbgOutput02 Rte_Write_CpApLss_PP_LssLogicDbgOutput02_De_LssLogicDbgOutput02
# define Rte_Write_PP_LssLogicDbgOutput03_De_LssLogicDbgOutput03 Rte_Write_CpApLss_PP_LssLogicDbgOutput03_De_LssLogicDbgOutput03
# define Rte_Write_PP_LssLogicDbgOutput04_De_LssLogicDbgOutput04 Rte_Write_CpApLss_PP_LssLogicDbgOutput04_De_LssLogicDbgOutput04
# define Rte_Write_PP_LssLogicDbgOutput05_De_LssLogicDbgOutput05 Rte_Write_CpApLss_PP_LssLogicDbgOutput05_De_LssLogicDbgOutput05
# define Rte_Write_PP_LssLogicDbgOutput06_De_LssLogicDbgOutput06 Rte_Write_CpApLss_PP_LssLogicDbgOutput06_De_LssLogicDbgOutput06
# define Rte_Write_PP_LssLogicDbgOutput07_De_LssLogicDbgOutput07 Rte_Write_CpApLss_PP_LssLogicDbgOutput07_De_LssLogicDbgOutput07
# define Rte_Write_PP_LssLogicDbgOutput08_De_LssLogicDbgOutput08 Rte_Write_CpApLss_PP_LssLogicDbgOutput08_De_LssLogicDbgOutput08
# define Rte_Write_PP_LssLogicDbgOutput09_De_LssLogicDbgOutput09 Rte_Write_CpApLss_PP_LssLogicDbgOutput09_De_LssLogicDbgOutput09
# define Rte_Write_PP_LssLogicDbgOutput10_De_LssLogicDbgOutput10 Rte_Write_CpApLss_PP_LssLogicDbgOutput10_De_LssLogicDbgOutput10
# define Rte_Write_PP_LssLogicDbgOutput11_De_LssLogicDbgOutput11 Rte_Write_CpApLss_PP_LssLogicDbgOutput11_De_LssLogicDbgOutput11
# define Rte_Write_PP_LssLogicDbgOutput12_De_LssLogicDbgOutput12 Rte_Write_CpApLss_PP_LssLogicDbgOutput12_De_LssLogicDbgOutput12
# define Rte_Write_PP_LssLogicDbgOutput13_De_LssLogicDbgOutput13 Rte_Write_CpApLss_PP_LssLogicDbgOutput13_De_LssLogicDbgOutput13
# define Rte_Write_PP_LssLogicDbgOutput14_De_LssLogicDbgOutput14 Rte_Write_CpApLss_PP_LssLogicDbgOutput14_De_LssLogicDbgOutput14
# define Rte_Write_PP_LssLogicDbgOutput15_De_LssLogicDbgOutput15 Rte_Write_CpApLss_PP_LssLogicDbgOutput15_De_LssLogicDbgOutput15
# define Rte_Write_PP_LssLogicDbgOutput16_De_LssLogicDbgOutput16 Rte_Write_CpApLss_PP_LssLogicDbgOutput16_De_LssLogicDbgOutput16
# define Rte_Write_PP_LssLogicDbgOutput17_De_LssLogicDbgOutput17 Rte_Write_CpApLss_PP_LssLogicDbgOutput17_De_LssLogicDbgOutput17
# define Rte_Write_PP_LssLogicDbgOutput18_De_LssLogicDbgOutput18 Rte_Write_CpApLss_PP_LssLogicDbgOutput18_De_LssLogicDbgOutput18
# define Rte_Write_PP_LssLogicDbgOutput19_De_LssLogicDbgOutput19 Rte_Write_CpApLss_PP_LssLogicDbgOutput19_De_LssLogicDbgOutput19
# define Rte_Write_PP_LssLogicDbgOutput20_De_LssLogicDbgOutput20 Rte_Write_CpApLss_PP_LssLogicDbgOutput20_De_LssLogicDbgOutput20
# define Rte_Write_PP_LssOutput_De_LssOutput Rte_Write_CpApLss_PP_LssOutput_De_LssOutput
# define Rte_Write_PP_LssUxOutToIvc_De_LssUxOutToIvc Rte_Write_CpApLss_PP_LssUxOutToIvc_De_LssUxOutToIvc
# define Rte_Write_PP_SccInternalInFromLSS_De_SccInternalInFromLSS Rte_Write_CpApLss_PP_SccInternalInFromLSS_De_SccInternalInFromLSS


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApLss_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApLss_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApLss_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApLss_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApLss_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrHdrLDW_getFrCmrHdrLDW Rte_Call_CpApLss_RP_FrCmrHdrLDW_getFrCmrHdrLDW
# define Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost Rte_Call_CpApLss_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost
# define Rte_Call_RP_FrCmrHdrLnRdEdg_getFrCmrHdrLnRdEdg Rte_Call_CpApLss_RP_FrCmrHdrLnRdEdg_getFrCmrHdrLnRdEdg
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApLss_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrLDW_getFrCmrLDW Rte_Call_CpApLss_RP_FrCmrLDW_getFrCmrLDW
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApLss_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_FrCmrLnRdEdg_getFrCmrLnRdEdg Rte_Call_CpApLss_RP_FrCmrLnRdEdg_getFrCmrLnRdEdg
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApLss_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_LssFrqNvData_ReadLssFrqNvData Rte_Call_CpApLss_RP_LssFrqNvData_ReadLssFrqNvData
# define Rte_Call_RP_LssFrqNvData_WriteLssFrqNvData Rte_Call_CpApLss_RP_LssFrqNvData_WriteLssFrqNvData
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApLss_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApLss_RP_Os_Service_GetElapsedValue




# define CpApLss_START_SEC_CODE
# include "CpApLss_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssDebugOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssDebugOut Re_CpApLssDebugOut
FUNC(void, CpApLss_CODE) Re_CpApLssDebugOut(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssFrqNvData_ReadLssFrqNvData(LssFrqNvData_t *LssFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssInit Re_CpApLssInit
FUNC(void, CpApLss_CODE) Re_CpApLssInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutToLss_De_DawOutToLss(DawOutToLss_t *data)
 *   Std_ReturnType Rte_Read_RP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(LssCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn01_De_LssDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn02_De_LssDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn03_De_LssDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn04_De_LssDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn05_De_LssDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn06_De_LssDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssInput_De_LssInput(LssInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssMeInfo_De_LssMeInfo(LssMeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_MrmUxOutToLss_De_MrmUxOutToIvc(LssMrmUxOutToIvc_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLDW_getFrCmrHdrLDW(FrCmrHdrLDW_t *FrCmrHdrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnRdEdg_getFrCmrHdrLnRdEdg(FrCmrHdrLnRdEdg_t *FrCmrHdrLnRdEdg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnRdEdg_getFrCmrLnRdEdg(LanesRoadEdge_t *FrCmrLnRdEdg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnRdEdg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssIsp Re_CpApLssIsp
FUNC(void, CpApLss_CODE) Re_CpApLssIsp(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssLfa
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssLfa Re_CpApLssLfa
FUNC(void, CpApLss_CODE) Re_CpApLssLfa(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssLka
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssLka Re_CpApLssLka
FUNC(void, CpApLss_CODE) Re_CpApLssLka(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssOsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS(const CoFcaInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(const FcaInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Write_PP_LssOutput_De_LssOutput(const LssOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssUxOutToIvc_De_LssUxOutToIvc(const LssUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInternalInFromLSS_De_SccInternalInFromLSS(const SccInternalInFromLSS_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_LssFrqNvData_WriteLssFrqNvData(const LssFrqNvData_t *LssFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssOsp Re_CpApLssOsp
FUNC(void, CpApLss_CODE) Re_CpApLssOsp(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_LssAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssVersionReq(LssAppVersionInfo_t *LssAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApLssVersionReq Re_CpApLssVersionReq
FUNC(Std_ReturnType, CpApLss_CODE) Re_CpApLssVersionReq(P2VAR(LssAppVersionInfo_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) LssAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApLss_STOP_SEC_CODE
# include "CpApLss_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLDW_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrLDW_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrLnRdEdg_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_IF_LssAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_LssFrqNvData_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPLSS_H */
