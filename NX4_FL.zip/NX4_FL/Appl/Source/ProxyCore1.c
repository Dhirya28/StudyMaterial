/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  ProxyCore1.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  ProxyCore1
 *  Generation Time:  2023-04-20 13:53:34
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <ProxyCore1>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Dem_EventStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_ServiceIdType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_ProxyCore1.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * dtRef_const_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * float64: Real in interval [-DBL_MAX...DBL_MAX] with double precision including NaN (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint32: Integer in interval [-2147483648...2147483647] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Dem_EventStatusType: Enumeration of integer in interval [0...255] with enumerators
 *   DEM_EVENT_STATUS_PASSED (0U)
 *   DEM_EVENT_STATUS_FAILED (1U)
 *   DEM_EVENT_STATUS_PREPASSED (2U)
 *   DEM_EVENT_STATUS_PREFAILED (3U)
 *   DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED (4U)
 *   DEM_EVENT_STATUS_PASSED_CONDITIONS_NOT_FULFILLED (5U)
 *   DEM_EVENT_STATUS_FAILED_CONDITIONS_NOT_FULFILLED (6U)
 *   DEM_EVENT_STATUS_PREPASSED_CONDITIONS_NOT_FULFILLED (7U)
 *   DEM_EVENT_STATUS_PREFAILED_CONDITIONS_NOT_FULFILLED (8U)
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 * NvM_ServiceIdType: Enumeration of integer in interval [6...12] with enumerators
 *   NVM_READ_BLOCK (6U)
 *   NVM_WRITE_BLOCK (7U)
 *   NVM_RESTORE_BLOCK_DEFAULTS (8U)
 *   NVM_ERASE_BLOCK (9U)
 *   NVM_INVALIDATE_NV_BLOCK (11U)
 *   NVM_READ_ALL (12U)
 *
 * Array Types:
 * ============
 * Rte_DT_DawOccNvData_t_11: Array with 3 element(s) of type uint8
 * Rte_DT_EYEQCAM_CamHwCalParams_t_2: Array with 32 element(s) of type uint8
 * Rte_DT_EYEQCAM_CamHwCalParams_t_3: Array with 2 element(s) of type uint8
 * Rte_DT_EYEQCAM_CamHwCalParams_t_4: Array with 12 element(s) of type uint8
 * Rte_DT_EYEQDG_LastFSDataRcd_t_10: Array with 7 element(s) of type uint16
 * Rte_DT_EYEQDG_SafetyFuncConfig_t_12: Array with 8 element(s) of type uint16
 * Rte_DT_EYEQMESP_AutoFixCalData_t_8: Array with 14 element(s) of type uint8
 * Rte_DT_EYEQMESP_CamDistorParams_t_29: Array with 6 element(s) of type uint16
 * Rte_DT_EYEQMESP_CameraFocused_t_6: Array with 22 element(s) of type uint8
 * Rte_DT_EYEQMESP_TargetCalParamsLimits_t_10: Array with 10 element(s) of type uint16
 * Rte_DT_EYEQMESP_TargetCalibData_t_8: Array with 14 element(s) of type uint8
 * Rte_DT_EYEQMESP_VehicleCalParams_t_14: Array with 7 element(s) of type uint8
 * Rte_DT_EYEQ_SysCfgFlgsRcd_t_2: Array with 14 element(s) of type uint8
 * Rte_DT_EyeQFfsSrvc_FfsHash_t_2: Array with 32 element(s) of type uint8
 * Rte_DT_EyeQIDMGRC_SerialNumberPCB_t_2: Array with 16 element(s) of type uint8
 * Rte_DT_HKMC_TraceabilityInformation_t_1: Array with 6 element(s) of type uint8
 * Rte_DT_HKMC_TraceabilityInformation_t_7: Array with 9 element(s) of type uint8
 * Rte_DT_IslwFrqNvData_t_24: Array with 3 element(s) of type Rte_DT_IslwFrqNvData_t_24_0
 * Rte_DT_IslwFrqNvData_t_24_0: Array with 1 element(s) of type uint8
 * Rte_DT_SECURITY_RNGInitCount_t_3: Array with 2 element(s) of type uint8
 * Rte_DT_ZFECUHwNrDataId_t_0: Array with 16 element(s) of type uint8
 * Rte_DT_ZFECUHwVerNrDataId_t_0: Array with 16 element(s) of type uint8
 * Rte_DT_ZFManfrECUSerialNr_t_0: Array with 16 element(s) of type uint8
 * u8_array_3: Array with 3 element(s) of type uint8
 *
 * Record Types:
 * =============
 * DawFrqNvData_t: Record with elements
 *   s16_STEERING_ANGLE_BIAS of type sint16
 *   s16_TORQUE_BIAS of type sint16
 *   u8_Threshold_Long_Jerk of type uint8
 *   u8_LVDA_OnOff of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_LowVisibility_Status of type uint8
 *   u8_ProfileVal_Guest of type uint8
 *   u8_ProfileVal_User1 of type uint8
 *   u8_ProfileVal_User2 of type uint8
 *   u8_ProfileVal_User3 of type uint8
 *   u8_ProfileVal_User4 of type uint8
 *   u8_ProfileVal_User5 of type uint8
 *   u8_ProfileVal_User6 of type uint8
 *   u8_ProfileVal_User7 of type uint8
 *   u8_ProfileVal_User8 of type uint8
 *   u8_ProfileVal_User9 of type uint8
 *   u8_Profile_LastUser of type uint8
 * DawOccNvData_t: Record with elements
 *   u16_LVDA_CHK_INTEGRITY_DIST_M of type uint16
 *   u16_LVDA_CHK_INTEGRITY_SPD_MPS of type uint16
 *   u8_PAR_MIN_DISTANCE of type uint8
 *   u8_PAR_MIN_SPEED of type uint8
 *   u8_PAR_DISTANCE_FV of type uint8
 *   u8_PAR_TIME_STOP of type uint8
 *   u8_PAR_SPEED_FV of type uint8
 *   u8_PAR_MOVING_DISTANCE_FV of type uint8
 *   u8_PAR_TIME_LVDA_POPUP of type uint8
 *   u8_LVDA_TIME_TRG_ALRM_SMPL of type uint8
 *   u8_LVDA_CHK_INTEGRITY_TIME_SMPL of type uint8
 *   u8a_Reserved of type Rte_DT_DawOccNvData_t_11
 * DvTest_Mode_t: Record with elements
 *   DvTest_Mode of type uint8
 *   Reserved_u8 of type u8_array_3
 * EYEQCAM_CamHwCalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   OTP_Data_au8 of type Rte_DT_EYEQCAM_CamHwCalParams_t_2
 *   Chip_Revision_Number_u8 of type Rte_DT_EYEQCAM_CamHwCalParams_t_3
 *   Reserved_u8 of type Rte_DT_EYEQCAM_CamHwCalParams_t_4
 *   calCRC_u16 of type uint16
 * EYEQC_SpeedFactorCalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   SPF_SCA_Mean_X_f32 of type float32
 *   SPF_SCA_Mean_Y_f32 of type float32
 *   SPF_SCA_Cov_XX_f32 of type float32
 *   SPF_SCA_Cov_XY_f32 of type float32
 *   SPF_SCA_Cov_YY_f32 of type float32
 *   SPF_SCA_Weight_f32 of type float32
 *   SPF_SCA_Factor_Mean_f32 of type float32
 *   SPF_SCA_Factor_Variance_f32 of type float32
 *   SFI_Sca_Revision_s32 of type sint32
 *   Reserved_0_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EYEQDG_LastFSDataRcd_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   FSSevrMisAlgmntTmr_u32 of type uint32
 *   FS_outOfFocus_Cntr_u8 of type uint8
 *   Last_FS_Partial_Blockage_u8 of type uint8
 *   Last_FS_Full_Blockage_u8 of type uint8
 *   Last_FS_Out_Of_Focus_u8 of type uint8
 *   Last_FS_Out_Of_Calib_u8 of type uint8
 *   LastTriggerSPC_u8 of type uint8
 *   FS_Reserved_1_u16 of type uint16
 *   Reserved3_u16 of type Rte_DT_EYEQDG_LastFSDataRcd_t_10
 *   CalCRC_u16 of type uint16
 * EYEQDG_SafetyFuncConfig_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   IsGeneralSafetyCritical_u8 of type uint8
 *   IsAEBSafetyCritical_u8 of type uint8
 *   IsPEDSafetyCritical_u8 of type uint8
 *   IsVDSafetyCritical_u8 of type uint8
 *   IsRoadSafetyCritical_u8 of type uint8
 *   IsRoadEdgeSafetyCritical_u8 of type uint8
 *   IsDecelerationSafetyCritical_u8 of type uint8
 *   IsMeasurementsSafetyCritical_u8 of type uint8
 *   IsFreeSpaceSafetyCritical_u8 of type uint8
 *   Reserved_0_u8 of type uint8
 *   Reserved_1_u16 of type Rte_DT_EYEQDG_SafetyFuncConfig_t_12
 *   calCRC_u16 of type uint16
 * EYEQMESP_AutoFixCalData_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Autofix_Yaw_u16 of type uint16
 *   Autofix_Horizon_u16 of type uint16
 *   Autofix_Roll_f32 of type float32
 *   Autofix_Cam_Height_u16 of type uint16
 *   CalStatus_u8 of type uint8
 *   Reserved_1_u8 of type uint8
 *   Reserved_2_u8 of type Rte_DT_EYEQMESP_AutoFixCalData_t_8
 *   CalCRC_u16 of type uint16
 * EYEQMESP_CamDistorParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Reserved4_u8 of type uint8
 *   Reserved0_u8 of type uint8
 *   DistortionModelType_0_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   CODX_f64 of type float64
 *   CODY_f64 of type float64
 *   DistorParams0_f64 of type float64
 *   DistorParams1_f64 of type float64
 *   DistorParams2_f64 of type float64
 *   DistorParams3_f64 of type float64
 *   DistorParams4_f64 of type float64
 *   DistorParams5_f64 of type float64
 *   DistorParams6_f64 of type float64
 *   DistorParams7_f64 of type float64
 *   DistorParams8_f64 of type float64
 *   DistorParams9_f64 of type float64
 *   DistorParams10_f64 of type float64
 *   DistorParams11_f64 of type float64
 *   DistorParams12_f64 of type float64
 *   DistorParams13_f64 of type float64
 *   DistorParams14_f64 of type float64
 *   DistorParams15_f64 of type float64
 *   FocalLengthX_f64 of type float64
 *   FocalLengthY_f64 of type float64
 *   Skew_f64 of type float64
 *   PrincipalPointX_f64 of type float64
 *   PrincipalPointY_f64 of type float64
 *   Reserved2_u16 of type Rte_DT_EYEQMESP_CamDistorParams_t_29
 *   Reserved3_u8 of type uint8
 *   CalStatus_u8 of type uint8
 *   CalCRC_u16 of type uint16
 * EYEQMESP_CameraFocused_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Focused_Main_u8 of type uint8
 *   Focused_Narrow_u8 of type uint8
 *   Focused_Fisheye_u8 of type uint8
 *   Reserved_0_u8 of type uint8
 *   Reserved_1_u8 of type Rte_DT_EYEQMESP_CameraFocused_t_6
 *   calCRC_u16 of type uint16
 * EYEQMESP_EnvironmentParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   LeftWheel_u16 of type uint16
 *   RightWheel_u16 of type uint16
 *   RefPX_Front_Bumper_u16 of type uint16
 *   CamToFrontAxle_u16 of type uint16
 *   CamToRearAxle_u16 of type uint16
 *   WheelWidth_u8 of type uint8
 *   WheelRadius_u8 of type uint8
 *   MinHorizon_u16 of type uint16
 *   MaxHorizon_u16 of type uint16
 *   MinYaw_u16 of type uint16
 *   MaxYaw_u16 of type uint16
 *   MaxRoll_u16 of type uint16
 *   Top_Crop_u16 of type uint16
 *   Bottom_Crop_u16 of type uint16
 *   Steering_Ratio_u16 of type uint16
 *   GPSToCam_dx_u16 of type uint16
 *   GPSToCam_dy_u16 of type uint16
 *   GPSToCam_dz_u16 of type uint16
 *   GPSToCam_dx_V_u8 of type uint8
 *   GPSToCam_dy_V_u8 of type uint8
 *   GPSToCam_dz_V_u8 of type uint8
 *   Top_Crop_V_u8 of type uint8
 *   Steering_Ratio_V_u8 of type uint8
 *   WheelWidth_V_u8 of type uint8
 *   WheelRadius_V_u8 of type uint8
 *   LeftWheel_V_u8 of type uint8
 *   RightWheel_V_u8 of type uint8
 *   RefPX_Front_Bumper_V_u8 of type uint8
 *   CamToFrontAxle_V_u8 of type uint8
 *   CamToRearAxle_V_u8 of type uint8
 *   MinHorizon_V_u8 of type uint8
 *   MaxHorizon_V_u8 of type uint8
 *   MinYaw_V_u8 of type uint8
 *   MaxYaw_V_u8 of type uint8
 *   MaxRoll_V_u8 of type uint8
 *   Bottom_Crop_V_u8 of type uint8
 *   fixedGpsLatency_u8 of type uint8
 *   fixedGpsLatency_V_u8 of type uint8
 *   receiverFrequency_u8 of type uint8
 *   receiverFrequency_V_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_SfrMtfvMode_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Reserved_0_u8 of type uint8
 *   MtfvMode_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   Reserved_2_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_TAC2InitParamsNVM_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   TAC_Mode_u8 of type uint8
 *   TAC_BottomLeftSquare_0_u8 of type uint8
 *   TAC_BottomLeftSquare_1_u8 of type uint8
 *   TAC_BottomLeftSquare_2_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_0_u16 of type uint16
 *   TAC_TargetInfo_Lat_Distance_1_u16 of type uint16
 *   TAC_TargetInfo_Lat_Distance_2_u16 of type uint16
 *   TAC_TargetInfo_Height_0_u16 of type uint16
 *   TAC_TargetInfo_Height_1_u16 of type uint16
 *   TAC_TargetInfo_Height_2_u16 of type uint16
 *   TAC_Camera_Height_u16 of type uint16
 *   TAC_Camera_Z_u16 of type uint16
 *   TAC_Max_Horizon_u8 of type uint8
 *   TAC_Min_Horizon_u8 of type uint8
 *   TAC_Max_Yaw_u8 of type uint8
 *   TAC_Min_Yaw_u8 of type uint8
 *   TAC_Max_RollAngle_u8 of type uint8
 *   TAC_Bottom_u8 of type uint8
 *   TAC_Targets_Num_u8 of type uint8
 *   TAC_Reserved0_u8 of type uint8
 *   TAC_SquareSideSize_u16 of type uint16
 *   TAC_Reserved1_u16 of type uint16
 *   TAC_Mode_V_u8 of type uint8
 *   TAC_BottomLeftSquare_0_V_u8 of type uint8
 *   TAC_BottomLeftSquare_1_V_u8 of type uint8
 *   TAC_BottomLeftSquare_2_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_0_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_1_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_2_V_u8 of type uint8
 *   TAC_TargetInfo_Height_0_V_u8 of type uint8
 *   TAC_TargetInfo_Height_1_V_u8 of type uint8
 *   TAC_TargetInfo_Height_2_V_u8 of type uint8
 *   TAC_Camera_Height_V_u8 of type uint8
 *   TAC_Camera_Z_V_u8 of type uint8
 *   TAC_Max_Horizon_V_u8 of type uint8
 *   TAC_Min_Horizon_V_u8 of type uint8
 *   TAC_Max_Yaw_V_u8 of type uint8
 *   TAC_Min_Yaw_V_u8 of type uint8
 *   TAC_Max_RollAngle_V_u8 of type uint8
 *   TAC_SquareSideSize_V_u8 of type uint8
 *   TAC_Bottom_V_u8 of type uint8
 *   TAC_Targets_Num_V_u8 of type uint8
 *   TAC_Camera_Z_Close_u8 of type uint8
 *   TAC_SquareSideSize_Close_u8 of type uint8
 *   Tac2_Num_Squares_Row_u8 of type uint8
 *   Tac2_Num_Squares_Col_u8 of type uint8
 *   TAC_Camera_Z_Close_V_u8 of type uint8
 *   TAC_SquareSideSize_Close_V_u8 of type uint8
 *   Tac2_Num_Squares_Row_V_u8 of type uint8
 *   Tac2_Num_Squares_Col_V_u8 of type uint8
 *   TAC_Reserved2_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_TargetCalParamsLimits_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Yaw_Min_u16 of type uint16
 *   Yaw_Max_u16 of type uint16
 *   Horizon_Min_u16 of type uint16
 *   Horizon_Max_u16 of type uint16
 *   rollAngle_Min_f32 of type float32
 *   rollAngle_Max_f32 of type float32
 *   CameraHeight_Min_u16 of type uint16
 *   CameraHeight_Max_u16 of type uint16
 *   Reserved_0_u16 of type Rte_DT_EYEQMESP_TargetCalParamsLimits_t_10
 *   Reserved_1_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EYEQMESP_TargetCalibData_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Yaw_u16 of type uint16
 *   Pitch_u16 of type uint16
 *   Roll_Angle_f32 of type float32
 *   Cam_Height_u16 of type uint16
 *   IsAutoTriggered_u8 of type uint8
 *   CalStatus_u8 of type uint8
 *   Reserved0_u8 of type Rte_DT_EYEQMESP_TargetCalibData_t_8
 *   CalCRC_u16 of type uint16
 * EYEQMESP_VehicleCalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Region_Code_u8 of type uint8
 *   Driving_Side_u8 of type uint8
 *   Pitch_Base_u16 of type uint16
 *   Yaw_Base_u16 of type uint16
 *   Cam_Height_Base_u16 of type uint16
 *   Roll_Angle_Base_f32 of type float32
 *   HilModeEnable_u8 of type uint8
 *   OverrideActualTargetCalParams_u8 of type uint8
 *   Disable_Ethernet_Logging_u8 of type uint8
 *   Disable_Ethernet_Logging_V_u8 of type uint8
 *   ActivateEDR_u16 of type uint16
 *   ActivateEDR_V_u8 of type uint8
 *   Reserved1_u8 of type Rte_DT_EYEQMESP_VehicleCalParams_t_14
 *   CalCRC_u16 of type uint16
 * EYEQTHSD_ThermalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   EyeQThermalStrategyEnabled_u8 of type uint8
 *   ThermistorHysteresisCheckEnable_u8 of type uint8
 *   ThermalDiagnosticDebounceLimit_u8 of type uint8
 *   MainImagerDieCheckEnable_u8 of type uint8
 *   FishEyeImagerDieCheckEnable_u8 of type uint8
 *   NarrowImagerDieCheckEnable_u8 of type uint8
 *   EyeQDieCheckEnable_u8 of type uint8
 *   DDRDieCheckEnable_u8 of type uint8
 *   MainImagerThermistorCheckEnable_u8 of type uint8
 *   FishEyeImagerThermistorCheckEnable_u8 of type uint8
 *   NarrowImagerThermistorCheckEnable_u8 of type uint8
 *   EyeQThermistorCheckEnable_u8 of type uint8
 *   DDRThermistorCheckEnable_u8 of type uint8
 *   AurixThermistorCheckEnable_u8 of type uint8
 *   MainImagerDieHighUpperThreshold_s8 of type sint8
 *   FishEyeImagerDieHighUpperThreshold_s8 of type sint8
 *   NarrowImagerDieHighUpperThreshold_s8 of type sint8
 *   MainImagerDieLowLowerThreshold_s8 of type sint8
 *   FishEyeImagerDieLowLowerThreshold_s8 of type sint8
 *   NarrowImagerDieLowLowerThreshold_s8 of type sint8
 *   EyeQDieHighUpperThreshold_s16 of type sint16
 *   EyeQDieLowLowerThreshold_s16 of type sint16
 *   AurixDie1HighUpperThreshold_u16 of type uint16
 *   AurixDie1HighLowerThreshold_u16 of type uint16
 *   AurixDie2HighUpperThreshold_u16 of type uint16
 *   AurixDie2HighLowerThreshold_u16 of type uint16
 *   AurixDie1LowLowerThreshold_u16 of type uint16
 *   AurixDie2LowLowerThreshold_u16 of type uint16
 *   MainImagerThermistorHighUpperThreshold_u16 of type uint16
 *   MainImagerThermistorHighLowerThreshold_u16 of type uint16
 *   FishEyeImagerThermistorHighUpperThreshold_u16 of type uint16
 *   FishEyeImagerThermistorHighLowerThreshold_u16 of type uint16
 *   NarrowImagerThermistorHighUpperThreshold_u16 of type uint16
 *   NarrowImagerThermistorHighLowerThreshold_u16 of type uint16
 *   EyeQThermistorHighUpperThreshold_u16 of type uint16
 *   EyeQThermistorHighLowerThreshold_u16 of type uint16
 *   DDRThermistorHighUpperThreshold_u16 of type uint16
 *   DDRThermistorHighLowerThreshold_u16 of type uint16
 *   AurixThermistorHighUpperThreshold_u16 of type uint16
 *   AurixThermistorHighLowerThreshold_u16 of type uint16
 *   SensorDiagMainImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagMainImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagFishEyeImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagFishEyeImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagNarrowImagerThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagNarrowImagerThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagEyeQThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagEyeQThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagDDRThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagDDRThermistorLowerThreshold_u16 of type uint16
 *   SensorDiagAurixThermistorUpperThreshold_u16 of type uint16
 *   SensorDiagAurixThermistorLowerThreshold_u16 of type uint16
 *   Reserved0_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EYEQTHSD_ThermalShutdownValues_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   MainImagerThermistorTemparature_u16 of type uint16
 *   FishEyeImagerThermistorTemparature_u16 of type uint16
 *   NarrowImagerThermistorTemparature_u16 of type uint16
 *   AurixThermistorTemparature_u16 of type uint16
 *   EyeQThermistorTemparature_u16 of type uint16
 *   DDRThermistorTemparature_u16 of type uint16
 *   AurixDie1Temparature_u16 of type uint16
 *   AurixDie2Temparature_u16 of type uint16
 *   EyeQDieTemparature1_s16 of type sint16
 *   EyeQDieTemparature2_s16 of type sint16
 *   MainImagerDieTemparature1_s8 of type sint8
 *   MainImagerDieTemparature2_s8 of type sint8
 *   FishEyeImagerDieTemparature1_s8 of type sint8
 *   FishEyeImagerDieTemparature2_s8 of type sint8
 *   NarrowImagerDieTemparature1_s8 of type sint8
 *   NarrowImagerDieTemparature2_s8 of type sint8
 *   DDRDieTemparature_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   ThermalShutdownCounter_u32 of type uint32
 *   Reserved2_u32 of type uint32
 *   Reserved0_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EYEQ_SysCfgFlgsRcd_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Flags_au8 of type Rte_DT_EYEQ_SysCfgFlgsRcd_t_2
 *   calCRC_u16 of type uint16
 * EyeQC_DriveSide_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   CalStatus_u8 of type uint8
 *   DrivingSide_u8 of type uint8
 *   calCRC_u16 of type uint16
 * EyeQC_RegionCode_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   CalStatus_u8 of type uint8
 *   RegionCode_u8 of type uint8
 *   calCRC_u16 of type uint16
 * EyeQFfsSrvc_FfsHash_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   OTP_Data_au8 of type Rte_DT_EyeQFfsSrvc_FfsHash_t_2
 *   IsFfsHashCalculated_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EyeQIDMGRC_SerialNumberPCB_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   SerialNumber_au8 of type Rte_DT_EyeQIDMGRC_SerialNumberPCB_t_2
 *   Reserved_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EyeQ_SetNextBootMode_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   CalStatus_u8 of type uint8
 *   SetNextBootMode_u8 of type uint8
 *   ExtrinsicCalStatus_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u16 of type uint16
 *   calCRC_u16 of type uint16
 * EyeQ_SetNextManualExposureVal_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Reserved0_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   EyeQ_SetNextManualExposureVal_u16 of type uint16
 *   Reserved2_u16 of type uint16
 *   calCRC_u16 of type uint16
 * HKMC_TraceabilityInformation_t: Record with elements
 *   TraceabilityIDLetter of type uint8
 *   ManufacturingDate of type Rte_DT_HKMC_TraceabilityInformation_t_1
 *   RotationWorking of type uint8
 *   ManufacturingFactory of type uint8
 *   ManufacturingLine of type uint8
 *   Data_4M of type uint8
 *   SerialNumberIDLetter of type uint8
 *   SerialNumber of type Rte_DT_HKMC_TraceabilityInformation_t_7
 *   Reserved1_u8 of type uint8
 *   calCRC_u16 of type uint16
 * HbaFrqNvData_t: Record with elements
 *   u8_HBA_OnOff of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_LowVisibility_Status of type uint8
 *   u8_ProfileVal_Guest of type uint8
 *   u8_ProfileVal_User1 of type uint8
 *   u8_ProfileVal_User2 of type uint8
 *   u8_ProfileVal_User3 of type uint8
 *   u8_ProfileVal_User4 of type uint8
 *   u8_ProfileVal_User5 of type uint8
 *   u8_ProfileVal_User6 of type uint8
 *   u8_ProfileVal_User7 of type uint8
 *   u8_ProfileVal_User8 of type uint8
 *   u8_ProfileVal_User9 of type uint8
 *   u8_Profile_LastUser of type uint8
 *   Reserved1 of type uint8
 * HbaOccNvData_t: Record with elements
 *   u16_HBA_MIDDLE_EAST_OFF_DIST of type uint16
 *   u16_HBA_MIDDLE_EAST_ON_DELAY_TIME of type uint16
 *   u16_Cam_Blockage_Time of type uint16
 *   u8_HBA_START_VS of type uint8
 *   u8_HBA_END_VS of type uint8
 *   u8_HBA_START_VS_US of type uint8
 *   u8_HBA_END_VS_US of type uint8
 *   u8_HBA_START_VS_LIMIT of type uint8
 *   u8_HBA_END_VS_LIMIT of type uint8
 *   u8_HBA_START_VS_LIMIT_US of type uint8
 *   u8_HBA_END_VS_LIMIT_US of type uint8
 *   Reserved1 of type uint8
 *   Reserved2 of type uint8
 * IoHwAb_HeaterInfo_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   HeaterCounter_u32 of type uint32
 *   HeaterStatus_u8 of type uint8
 *   Reserved_1_u8 of type uint8
 *   Reserved_2_u16 of type uint16
 *   Reserved_3_u16 of type uint16
 *   calCRC_u16 of type uint16
 * IslwFrqNvData_t: Record with elements
 *   u16_Nvm_Navi_CountryCode of type uint16
 *   u8_SLIF_Speed_Display_Cluster of type uint8
 *   u8_SLIF_Speed_Display_Navi of type uint8
 *   u8_SLIF_VS_Unit of type uint8
 *   u8_Navi_SLIF_LinkClass_NVM of type uint8
 *   u8_SLIF_Former_Speed_Limit_From of type uint8
 *   u8_Nvm_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_ISLA_OptUsmSta of type uint8
 *   u8_Nvm_ISLA_Cntry of type uint8
 *   b_Nvm_Navi_On of type boolean
 *   u8_Nvm_ISLA_Cntry1USMSta of type uint8
 *   u8_Nvm_ISLA_Cntry2USMSta of type uint8
 *   u8_Nvm_ISLA_CntryVerTyp of type uint8
 *   u8_Nvm_USER_ID of type uint8
 *   u8_Nvm_OffsetUSM_User1 of type uint8
 *   u8_Nvm_OffsetUSM_User2 of type uint8
 *   u8_Nvm_OffsetUSM_Geust of type uint8
 *   u8_Nvm_NRS_USM_User1 of type uint8
 *   u8_Nvm_NRS_USM_User2 of type uint8
 *   u8_Nvm_NRS_USM_Guest of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_SunRay_Status of type uint8
 *   u8_RawValueCamolny_CLUMain of type uint8
 *   Reserved of type Rte_DT_IslwFrqNvData_t_24
 * IslwOccNvData_t: Record with elements
 *   u32_SLIF_MIN_TSR_DIST_MOTORWAY_SIGN_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_PASS_JC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_ENTER_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_IC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXPIRE_TIMER_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_NON_HW of type uint32
 *   u32_SLIF_Rain_Decision_Period of type uint32
 *   u32_SLIF_Rain_Off_Decision_Period of type uint32
 *   u32_SLIF_MAX_TSR_DIST_EXTRA_DELAY_NOSPDLMT_BY_NAVI of type uint32
 *   u32_SLIF_MAX_TSR_DIST_LATRANGE_ARROW_SIGN_HWEXIT of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_ARROW_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_RAIN_SIGN_HW of type uint32
 *   u32_SLIF_MIN_TSR_SAS_TURNDEC of type uint32
 *   u32_SLIF_BLOCKAGE_RUNTIME of type uint32
 *   u8_SLIF_SET_TSR_TIMER_MODE of type uint8
 *   u8_Nvm_Occ_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_AutoUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_OptUsmSta of type uint8
 *   u16_IslwAppVersion of type uint16
 *   Reserved1 of type uint16
 *   Reserved2 of type uint16
 *   Reserved3 of type uint16
 *   Reserved4 of type uint16
 *   Reserved5 of type uint16
 *   Reserved6 of type uint16
 *   Reserved7 of type uint16
 * LssFrqNvData_t: Record with elements
 *   s16_NVM_r_SteerWhlAgOffs of type sint16
 *   s16_NVM_r_YawRateOffs of type sint16
 *   s16_NVM_r_StrColTqOffs of type sint16
 *   s16_Nvm_Rom_HdngAngOffset of type sint16
 *   u8_NVM_r_LkasUsmOpt of type uint8
 *   u8_NVM_r_LkasUsmOptDelay of type uint8
 *   u8_NVM_r_LFA_Opt_USM of type uint8
 *   u8_Rom_SysOff of type uint8
 *   u8_NVM_LKA_Status of type uint8
 *   u8_NVM_LFA_Status of type uint8
 *   u8_NVM_HdaStatus_User1 of type uint8
 *   u8_NVM_HdaStatus_User2 of type uint8
 *   u8_NVM_HdaStatus_Guest of type uint8
 *   u8_NVM_ProfileIDRVal of type uint8
 *   u8_NVM_WarnSndUSMSta of type uint8
 *   Reserved of type uint8
 * SECURITY_RNGInitCount_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   RNGInitCnt_au32 of type uint32
 *   Reserved2_au8 of type Rte_DT_SECURITY_RNGInitCount_t_3
 *   calCRC_u16 of type uint16
 * ZFECUHwNrDataId_t: Record with elements
 *   ZFECUHwNrDataId of type Rte_DT_ZFECUHwNrDataId_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 * ZFECUHwVerNrDataId_t: Record with elements
 *   ZFECUHwVerNrDataId of type Rte_DT_ZFECUHwVerNrDataId_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 * ZFManfrECUSerialNr_t: Record with elements
 *   IDMGRC_SerialNumberECU of type Rte_DT_ZFManfrECUSerialNr_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   DawFrqNvData_t *Rte_Pim_DawFrqNvData(void)
 *   DawOccNvData_t *Rte_Pim_DawOccNvData(void)
 *   DvTest_Mode_t *Rte_Pim_DvTest_Mode(void)
 *   EYEQCAM_CamHwCalParams_t *Rte_Pim_EYEQCAM_CamHwCalParams_Main(void)
 *   EYEQC_SpeedFactorCalParams_t *Rte_Pim_EYEQC_SpeedFactorPrimary(void)
 *   EYEQC_SpeedFactorCalParams_t *Rte_Pim_EYEQC_SpeedFactorSecondary(void)
 *   EYEQDG_LastFSDataRcd_t *Rte_Pim_EYEQDG_LastFSDataRcdPrimary(void)
 *   EYEQDG_LastFSDataRcd_t *Rte_Pim_EYEQDG_LastFSDataRcdSecondary(void)
 *   EYEQDG_SafetyFuncConfig_t *Rte_Pim_EYEQDG_SafetyFuncConfig(void)
 *   EYEQMESP_AutoFixCalData_t *Rte_Pim_EYEQMESP_AutoFixCalPrimary(void)
 *   EYEQMESP_AutoFixCalData_t *Rte_Pim_EYEQMESP_AutoFixCalSecondary(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsFisheye(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsMain(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsNarrow(void)
 *   EYEQMESP_CameraFocused_t *Rte_Pim_EYEQMESP_CameraFocused(void)
 *   EYEQMESP_EnvironmentParams_t *Rte_Pim_EYEQMESP_EnvironmentParams(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPCCalibrationPrimary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPCCalibrationSecondary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPTACCalibration(void)
 *   EYEQMESP_SfrMtfvMode_t *Rte_Pim_EYEQMESP_SfrMtfvMode(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_TAC2CalibrationPrimary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_TAC2CalibrationSecondary(void)
 *   EYEQMESP_TAC2InitParamsNVM_t *Rte_Pim_EYEQMESP_TAC2InitParams(void)
 *   EYEQMESP_TargetCalParamsLimits_t *Rte_Pim_EYEQMESP_TargetCalParamsLimits(void)
 *   EYEQMESP_VehicleCalParams_t *Rte_Pim_EYEQMESP_VehicleCalParams(void)
 *   EYEQ_SysCfgFlgsRcd_t *Rte_Pim_EYEQSYS_EyeQSysCfg(void)
 *   EYEQTHSD_ThermalParams_t *Rte_Pim_EYEQTHSD_ThermalParams(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownPrimary(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownSecondary(void)
 *   EyeQC_DriveSide_t *Rte_Pim_EyeQC_DriveSidePrimary(void)
 *   EyeQC_DriveSide_t *Rte_Pim_EyeQC_DriveSideSecondary(void)
 *   EyeQC_RegionCode_t *Rte_Pim_EyeQC_RegionCodePrimary(void)
 *   EyeQC_RegionCode_t *Rte_Pim_EyeQC_RegionCodeSecondary(void)
 *   EyeQFfsSrvc_FfsHash_t *Rte_Pim_EyeQFfsSrvc_FfsHash(void)
 *   EyeQIDMGRC_SerialNumberPCB_t *Rte_Pim_EyeQIDMGRC_SerialNumberPCB(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary(void)
 *   EyeQ_SetNextBootMode_t *Rte_Pim_EyeQ_SetNextBootMode(void)
 *   EyeQ_SetNextManualExposureVal_t *Rte_Pim_EyeQ_SetNextManualExposureVal(void)
 *   HKMC_TraceabilityInformation_t *Rte_Pim_HKMC_TraceabilityInformation(void)
 *   HbaFrqNvData_t *Rte_Pim_HbaFrqNvData(void)
 *   HbaOccNvData_t *Rte_Pim_HbaOccNvData(void)
 *   IslwFrqNvData_t *Rte_Pim_IslwFrqNvData(void)
 *   IslwOccNvData_t *Rte_Pim_IslwOccNvData(void)
 *   LssFrqNvData_t *Rte_Pim_LssFrqNvData(void)
 *   SECURITY_RNGInitCount_t *Rte_Pim_SECURITY_RNGInitCount(void)
 *   ZFECUHwNrDataId_t *Rte_Pim_ZFECUHwNrDataId(void)
 *   ZFECUHwVerNrDataId_t *Rte_Pim_ZFECUHwVerNrDataId(void)
 *   ZFManfrECUSerialNr_t *Rte_Pim_ZFManfrECUSerialNr(void)
 *
 *********************************************************************************************************************/


#define ProxyCore1_START_SEC_CODE
#include "ProxyCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <BswServicesReady> of PortPrototype <RP_BswServicesReady>
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) ProxyCore1_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_ProxyCore1Ready_ProxyCore1Ready(uint8 mode)
 *   Modes of Rte_ModeType_ProxyCore1Ready:
 *   - RTE_MODE_ProxyCore1Ready_False
 *   - RTE_MODE_ProxyCore1Ready_True
 *   - RTE_TRANSITION_ProxyCore1Ready
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DvTest_Mode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_LssFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_Run_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, ProxyCore1_CODE) ProxyCore1_Run(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: ProxyCore1_Run
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define ProxyCore1_STOP_SEC_CODE
#include "ProxyCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
