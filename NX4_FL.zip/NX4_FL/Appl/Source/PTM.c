/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  PTM.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  PTM
 *  Generation Time:  2023-04-20 13:53:35
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <PTM>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_Adc_ValueGroupType
 *   uint16 represents integers with a minimum value of 0 and a maximum value of 65535.
 *      The order-relation on uint16 is: x < y if y - x is positive.
 *      uint16 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 1267, +10000.
 *
 * Rte_Dio_LevelType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_PTM.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * Rte_Adc_ValueGroupType: Integer in interval [0...65535]
 * Rte_Dio_LevelType: Integer in interval [0...255]
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Array Types:
 * ============
 * EYEQMESP_SFRBufferType: Array with 112 element(s) of type uint8
 * Rte_DT_HKMC_TraceabilityInformation_t_1: Array with 6 element(s) of type uint8
 * Rte_DT_HKMC_TraceabilityInformation_t_7: Array with 9 element(s) of type uint8
 * Rte_DT_PtmEepDumpRecord_t_0: Array with 32 element(s) of type uint8
 * Rte_DT_ZFECUHwNrDataId_t_0: Array with 16 element(s) of type uint8
 * Rte_DT_ZFECUHwVerNrDataId_t_0: Array with 16 element(s) of type uint8
 * Rte_DT_ZFManfrECUSerialNr_t_0: Array with 16 element(s) of type uint8
 * u8_array_3: Array with 3 element(s) of type uint8
 *
 * Record Types:
 * =============
 * DvTest_Mode_t: Record with elements
 *   DvTest_Mode of type uint8
 *   Reserved_u8 of type u8_array_3
 * HKMC_TraceabilityInformation_t: Record with elements
 *   TraceabilityIDLetter of type uint8
 *   ManufacturingDate of type Rte_DT_HKMC_TraceabilityInformation_t_1
 *   RotationWorking of type uint8
 *   ManufacturingFactory of type uint8
 *   ManufacturingLine of type uint8
 *   Data_4M of type uint8
 *   SerialNumberIDLetter of type uint8
 *   SerialNumber of type Rte_DT_HKMC_TraceabilityInformation_t_7
 *   Reserved1_u8 of type uint8
 *   calCRC_u16 of type uint16
 * PtmEepDumpRecord_t: Record with elements
 *   Data_au8 of type Rte_DT_PtmEepDumpRecord_t_0
 * ZFECUHwNrDataId_t: Record with elements
 *   ZFECUHwNrDataId of type Rte_DT_ZFECUHwNrDataId_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 * ZFECUHwVerNrDataId_t: Record with elements
 *   ZFECUHwVerNrDataId of type Rte_DT_ZFECUHwVerNrDataId_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 * ZFManfrECUSerialNr_t: Record with elements
 *   IDMGRC_SerialNumberECU of type Rte_DT_ZFManfrECUSerialNr_t_0
 *   Reserved_u16 of type uint16
 *   calCRC_u16 of type uint16
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   DvTest_Mode_t *Rte_Pim_DvTest_Mode(void)
 *   HKMC_TraceabilityInformation_t *Rte_Pim_HKMC_TraceabilityInformation(void)
 *   ZFECUHwNrDataId_t *Rte_Pim_ZFECUHwNrDataId(void)
 *   ZFECUHwVerNrDataId_t *Rte_Pim_ZFECUHwVerNrDataId(void)
 *   ZFManfrECUSerialNr_t *Rte_Pim_ZFManfrECUSerialNr(void)
 *
 *********************************************************************************************************************/


#define PTM_START_SEC_CODE
#include "PTM_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_DvTest_Mode_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_NvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PTM_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_GetPtmEepDump_GetEepDump(uint32 nvmAddr_u32, PtmEepDumpRecord_t *ramAddr_u8, uint16 numBytes_u16, uint16 operation)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V0_MON_IoHwAb_Get_ADC_1V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V0_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V1_MON_IoHwAb_Get_ADC_1V1_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V1_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V8_DDR_MON_IoHwAb_Get_ADC_1V8_DDR_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V8_DDR_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_1V8_MON_IoHwAb_Get_ADC_1V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_1V8_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_2V8_MON_IoHwAb_Get_ADC_3V3_2V8_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_2V8_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_FEYE_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_MAIN_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_MON_IoHwAb_Get_ADC_3V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_3V3_NARROW_MON_ADC_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_5V0_MON_IoHwAb_Get_ADC_5V0_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_5V0_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_ADC_REF_CAL_IoHwAb_Get_ADC_ADC_REF_CAL(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_ADC_REF_CAL_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTSC_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_AURIX_DIE_DTS_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_EQ4_MON_TEMP_IoHwAb_Get_ADC_EQ4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_EQ4_MON_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_FEYE_TEMP_MON_IoHwAb_Get_ADC_FEYE_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_FEYE_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_LKA_SW_INPUT_IoHwAb_Get_ADC_LKA_SW_INPUT(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_LKA_SW_INPUT_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_IoHwAb_Get_ADC_LPDDR4_MON_TEMP(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_LPDDR4_MON_TEMP_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MAIN_TEMP_MON_IoHwAb_Get_ADC_MAIN_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MAIN_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_MICRO_TEMP_MON_IoHwAb_Get_ADC_MICRO_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_MICRO_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_NARROW_TEMP_MON_IoHwAb_Get_ADC_NARROW_TEMP_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_NARROW_TEMP_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_PSU_1V3_MON_IoHwAb_Get_ADC_PSU_1V3_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_PSU_1V3_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_PSU_IMAGER_MON_IoHwAb_Get_ADC_PSU_IMAGER_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_PSU_IMAGER_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_SENSE_HEATER_IoHwAb_Get_ADC_SENSE_HEATER(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_SENSE_HEATER_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_ADC_VBATT_MON_IoHwAb_Get_ADC_VBATT_MON(Rte_Adc_ValueGroupType *DataBufferPointer_u16)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_ADC_VBATT_MON_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_1V5_PSU_MICRO_EN_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_1V8_PSU_MICRO_EN_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_0_IoHwAb_Get_Dio_Debug_0(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_0_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_1_IoHwAb_Get_Dio_Debug_1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_2_IoHwAb_Get_Dio_Debug_2(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_2_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Debug_3_IoHwAb_Get_Dio_Debug_3(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Debug_3_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Diag_Out_Sw_En_IoHwAb_Get_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Diag_Out_Sw_En_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Errout_IoHwAb_Get_Dio_Eq4_Errout(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Errout_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev0_Pm_IoHwAb_Get_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev0_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev1_Pm_IoHwAb_Get_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev1_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev2_Pm_IoHwAb_Get_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev2_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev3_Pm_IoHwAb_Get_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev3_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Rev4_Pm_IoHwAb_Get_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Rev4_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eq4_Xint_IoHwAb_Get_Dio_Eq4_Xint(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eq4_Xint_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_EyeQ_Init_Ready_IoHwAb_Get_Dio_EyeQ_Init_Ready(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_EyeQ_Init_Ready_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio11_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio12_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio13_App_Mode_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio14_Boot_Status_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio15_Boot_Status_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio16_IoHwAb_Get_Dio_Eyeq4_Gpio16(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio16_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio17_IoHwAb_Get_Dio_Eyeq4_Gpio17(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio17_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio18_On_Die_Temp_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Eyeq4_Gpio_Rb1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Gpio_Ra2_Timer_Sync_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Heater_Ch0_IoHwAb_Get_Dio_Heater_Ch0(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Heater_Ch0_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Heater_Diag_En_IoHwAb_Get_Dio_Heater_Diag_En(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Heater_Diag_En_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Micro_Eq4_Por_N_Pm_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Micro_Sfi_Enable_IoHwAb_Get_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Micro_Sfi_Enable_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Off_Battery_Enable_IoHwAb_Get_Dio_Off_Battery_Enable(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Off_Battery_Enable_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V1_IoHwAb_Get_Dio_Psu_En_1V1(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V1_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_IoHwAb_Get_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_1V8_Ddr_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_IoHwAb_Get_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType *Level_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IoHwAb_Get_Dio_Psu_En_Vision_Supplies_ReturnType
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN_IoHwAb_Set_Dio_1V5_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN_IoHwAb_Set_Dio_1V8_PSU_MICRO_EN(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_0_IoHwAb_Set_Dio_Debug_0(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_1_IoHwAb_Set_Dio_Debug_1(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_2_IoHwAb_Set_Dio_Debug_2(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Debug_3_IoHwAb_Set_Dio_Debug_3(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Diag_Out_Sw_En_IoHwAb_Set_Dio_Diag_Out_Sw_En(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev0_Pm_IoHwAb_Set_Dio_Eq4_Rev0_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev1_Pm_IoHwAb_Set_Dio_Eq4_Rev1_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev2_Pm_IoHwAb_Set_Dio_Eq4_Rev2_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev3_Pm_IoHwAb_Set_Dio_Eq4_Rev3_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Rev4_Pm_IoHwAb_Set_Dio_Eq4_Rev4_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eq4_Xint_IoHwAb_Set_Dio_Eq4_Xint(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio11_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio12_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode_IoHwAb_Set_Dio_Eyeq4_Gpio13_App_Mode(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp_IoHwAb_Set_Dio_Eyeq4_Gpio18_On_Die_Temp(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Heater_Ch0_IoHwAb_Set_Dio_Heater_Ch0(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Heater_Diag_En_IoHwAb_Set_Dio_Heater_Diag_En(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm_IoHwAb_Set_Dio_Micro_Eq4_Por_N_Pm(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Micro_Sfi_Enable_IoHwAb_Set_Dio_Micro_Sfi_Enable(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Off_Battery_Enable_IoHwAb_Set_Dio_Off_Battery_Enable(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V1_IoHwAb_Set_Dio_Psu_En_1V1(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_1V8_Ddr_IoHwAb_Set_Dio_Psu_En_1V8_Ddr(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_IoHwAb_Set_Dio_Psu_En_Vision_Supplies_IoHwAb_Set_Dio_Psu_En_Vision_Supplies(Rte_Dio_LevelType Level_u8)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_DvTest_Mode_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetCurrentSFRTestStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRData(uint8 *sfrBuffer_pau8, uint16 *paramsCount_pu16, boolean *reqStatus_pb, uint8 *SampleStatus_pu8)
 *     Argument sfrBuffer_pau8: uint8* is of type EYEQMESP_SFRBufferType
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_GetSFRTestResults(sint8 cameraType_s8, boolean *isCameraFocused_pb, uint8 *failFlags_pu8, uint8 *nvmStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_SendSFRAnalysisResults(sint8 cameraType_s8, boolean isCameraFocused_bo, boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StartSFRProcessReq(boolean *status_pb, sint8 cameraType_s8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SFR_EYEQMESP_TO_APPL_EYEQMESP_StopSFRProcess(boolean *status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SFR_EYEQMESP_TO_APPL_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_Run_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, PTM_CODE) PTM_Run(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PTM_Run
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define PTM_STOP_SEC_CODE
#include "PTM_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
