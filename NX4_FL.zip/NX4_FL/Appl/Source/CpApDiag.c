/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApDiag.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApDiag
 *  Generation Time:  2023-04-20 13:53:20
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApDiag>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Dcm_OpStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Dem_EventStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Dem_UdsStatusByteType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApDiag.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * COM_DT_BatteryVoltageHigh: Integer in interval [0...255]
 * COM_DT_BatteryVoltageLow: Integer in interval [0...255]
 * COM_DT_Blockage_Drv: Integer in interval [0...255]
 * COM_DT_Blockage_Init: Integer in interval [0...255]
 * COM_DT_CLU_OdoVal: Integer in interval [0...4294967295]
 * COM_DT_FR_RDR_CrcVal: Integer in interval [0...65535]
 * COM_DT_RD_DTC_AlvCntVal: Integer in interval [0...255]
 * COM_DT_RadarCANCommError: Integer in interval [0...255]
 * COM_DT_RadarErrorCode_No1: Integer in interval [0...65535]
 * COM_DT_RadarErrorCode_No2: Integer in interval [0...65535]
 * COM_DT_RadarHwError: Integer in interval [0...255]
 * COM_DT_RadarHwTempCondition_High: Integer in interval [0...255]
 * COM_DT_RadarHwTempCondition_Low: Integer in interval [0...255]
 * COM_DT_SystemOutOfCalibration_DRV: Integer in interval [0...255]
 * COM_DT_SystemOutOfCalibration_EOL: Integer in interval [0...255]
 * CpApDiag_Status: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * dtRef_const_VOID: DataReference
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Dcm_OpStatusType: Enumeration of integer in interval [0...64] with enumerators
 *   DCM_INITIAL (0U)
 *   DCM_PENDING (1U)
 *   DCM_CANCEL (2U)
 *   DCM_FORCE_RCRRP_OK (3U)
 *   DCM_FORCE_RCRRP_NOT_OK (64U)
 * Dem_EventStatusType: Enumeration of integer in interval [0...255] with enumerators
 *   DEM_EVENT_STATUS_PASSED (0U)
 *   DEM_EVENT_STATUS_FAILED (1U)
 *   DEM_EVENT_STATUS_PREPASSED (2U)
 *   DEM_EVENT_STATUS_PREFAILED (3U)
 *   DEM_EVENT_STATUS_FDC_THRESHOLD_REACHED (4U)
 *   DEM_EVENT_STATUS_PASSED_CONDITIONS_NOT_FULFILLED (5U)
 *   DEM_EVENT_STATUS_FAILED_CONDITIONS_NOT_FULFILLED (6U)
 *   DEM_EVENT_STATUS_PREPASSED_CONDITIONS_NOT_FULFILLED (7U)
 *   DEM_EVENT_STATUS_PREFAILED_CONDITIONS_NOT_FULFILLED (8U)
 * Dem_UdsStatusByteType: Enumeration of integer in interval [0...255] with enumerators
 *   DEM_UDS_STATUS_TF (1U)
 *   DEM_UDS_STATUS_TF_BflMask 1U (0b00000001)
 *   DEM_UDS_STATUS_TF_BflPn 0
 *   DEM_UDS_STATUS_TF_BflLn 1
 *   DEM_UDS_STATUS_TFTOC (2U)
 *   DEM_UDS_STATUS_TFTOC_BflMask 2U (0b00000010)
 *   DEM_UDS_STATUS_TFTOC_BflPn 1
 *   DEM_UDS_STATUS_TFTOC_BflLn 1
 *   DEM_UDS_STATUS_PDTC (4U)
 *   DEM_UDS_STATUS_PDTC_BflMask 4U (0b00000100)
 *   DEM_UDS_STATUS_PDTC_BflPn 2
 *   DEM_UDS_STATUS_PDTC_BflLn 1
 *   DEM_UDS_STATUS_CDTC (8U)
 *   DEM_UDS_STATUS_CDTC_BflMask 8U (0b00001000)
 *   DEM_UDS_STATUS_CDTC_BflPn 3
 *   DEM_UDS_STATUS_CDTC_BflLn 1
 *   DEM_UDS_STATUS_TNCSLC (16U)
 *   DEM_UDS_STATUS_TNCSLC_BflMask 16U (0b00010000)
 *   DEM_UDS_STATUS_TNCSLC_BflPn 4
 *   DEM_UDS_STATUS_TNCSLC_BflLn 1
 *   DEM_UDS_STATUS_TFSLC (32U)
 *   DEM_UDS_STATUS_TFSLC_BflMask 32U (0b00100000)
 *   DEM_UDS_STATUS_TFSLC_BflPn 5
 *   DEM_UDS_STATUS_TFSLC_BflLn 1
 *   DEM_UDS_STATUS_TNCTOC (64U)
 *   DEM_UDS_STATUS_TNCTOC_BflMask 64U (0b01000000)
 *   DEM_UDS_STATUS_TNCTOC_BflPn 6
 *   DEM_UDS_STATUS_TNCTOC_BflLn 1
 *   DEM_UDS_STATUS_WIR (128U)
 *   DEM_UDS_STATUS_WIR_BflMask 128U (0b10000000)
 *   DEM_UDS_STATUS_WIR_BflPn 7
 *   DEM_UDS_STATUS_WIR_BflLn 1
 * NvM_RequestResultType: Enumeration of integer in interval [0...255] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Array Types:
 * ============
 * Dcm_Data20ByteType: Array with 20 element(s) of type uint8
 *
 * Record Types:
 * =============
 * CoFcaFailSafeInfo_t: Record with elements
 *   p_EngineRun of type uint8
 *   p_TrailerMsgTout of type uint8
 *   p_EcuOverVolt_Fail of type uint8
 *   p_EcuUndVolt_Fail of type uint8
 *   p_MalfuncbyCam_Fail of type uint8
 *   p_EmsMsgTout_Fail of type uint8
 *   p_TcuMsgTout_Fail of type uint8
 *   p_EmsSig_Fail of type uint8
 *   p_HcuVcuFcuMsgTout_Fail of type uint8
 *   p_EcanBusOff_Fail of type uint8
 *   p_HcuVcuFcuSig_Fail of type uint8
 *   p_StrAngTout_Fail of type uint8
 *   p_EspMsgTout_Fail of type uint8
 *   p_ABSESPSig_Fail of type uint8
 *   p_AcuMsgTout_Fail of type uint8
 *   p_EscVarErr_Fail of type uint8
 *   p_EscRvsbFCA_Fail of type uint8
 *   p_TcuSig_Fail of type uint8
 *   p_IcuMsgTout_Normal_Fail of type uint8
 *   p_FuncVarErr_Fail of type uint8
 *   p_StrAngMsg_Fail of type uint8
 *   p_YrSen_Fail of type uint8
 *   p_FcaComm_Fail of type uint8
 *   p_IBUMsgTout_Fail of type uint8
 *   p_RwsMsgTout_Fail of type uint8
 *   p_RwsComm_Fail of type uint8
 *   p_ILCUMsgTout_Fail of type uint8
 *   p_FrCmrBlockage_Fail of type uint8
 *   p_FrCmrOvrTemp_Fail of type uint8
 * DawFailInfo_t: Record with elements
 *   u8_ActiveFault of type uint8
 *   u8_BlockageFault of type uint8
 *   u8_TemperatureFault of type uint8
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FcaFailSafeInfoTrailerMsgTout_t: Record with elements
 *   u8_TrailerMsgTout of type uint8
 * FcaFailSafeInfo_t: Record with elements
 *   p_EngineRun of type uint8
 *   p_TrailerMsgTout of type uint8
 *   p_EcuOverVolt_Fail of type uint8
 *   p_EcuUndVolt_Fail of type uint8
 *   p_MalfuncbyCam_Fail of type uint8
 *   p_EmsMsgTout_Fail of type uint8
 *   p_TcuMsgTout_Fail of type uint8
 *   p_EmsSig_Fail of type uint8
 *   p_HcuVcuFcuMsgTout_Fail of type uint8
 *   p_EcanBusOff_Fail of type uint8
 *   p_HcuVcuFcuSig_Fail of type uint8
 *   p_StrAngTout_Fail of type uint8
 *   p_EspMsgTout_Fail of type uint8
 *   p_ABSESPSig_Fail of type uint8
 *   p_AcuMsgTout_Fail of type uint8
 *   p_EscVarErr_Fail of type uint8
 *   p_EscRvsbFCA_Fail of type uint8
 *   p_TcuSig_Fail of type uint8
 *   p_FrRdr_Fail of type uint8
 *   p_IcuMsgTout_Normal_Fail of type uint8
 *   p_IcuMsgTout_JTFcn_Fail of type uint8
 *   p_FuncVarErr_Fail of type uint8
 *   p_StrAngMsg_Fail of type uint8
 *   p_YrSen_Fail of type uint8
 *   p_FcaComm_Fail of type uint8
 *   p_IBUMsgTout_Fail of type uint8
 *   p_RwsMsgTout_Fail of type uint8
 *   p_RwsComm_Fail of type uint8
 *   p_MFSWTout_Fail of type uint8
 *   p_ILCUMsgTout_Fail of type uint8
 *   p_FrRdrOvrTemp_Fail of type uint8
 *   p_FrRdrBlockage_Fail of type uint8
 *   p_FrRdrNotFoundTarget_Fail of type uint8
 *   p_FrRdrInitBlockage_Fail of type uint8
 *   p_FrCmrBlockage_Fail of type uint8
 *   p_FrCmrOvrTemp_Fail of type uint8
 * HbaFailInfo_t: Record with elements
 *   u8_ActiveFault of type uint8
 *   u8_BlockageFault of type uint8
 *   u8_TemperatureFault of type uint8
 * IslwFailInfo_t: Record with elements
 *   u8_Timeout_HU_Navi_ISLW_PE_00 of type uint8
 *   u8_Timeout_HU_MON_PE_01 of type uint8
 *   u8_ActiveFault of type uint8
 *   u8_BlockageFault of type uint8
 * LssCanSigFailSafeInfo_t: Record with elements
 *   b_OverrideDTCforCal of type uint8
 *   b_OverrideDTC of type uint8
 *   b_LfaFail of type uint8
 *   b_Navi_Fault of type uint8
 *   b_HDA_Fault of type uint8
 *   b_LdwFail of type uint8
 *   b_LkaFail of type uint8
 *   b_LkaHwSwFail of type uint8
 *   b_CMRTempSta of type uint8
 *   b_BlockageSta of type uint8
 * RadarDtcInfo_t: Record with elements
 *   BatteryVoltageHigh of type COM_DT_BatteryVoltageHigh
 *   BatteryVoltageLow of type COM_DT_BatteryVoltageLow
 *   Blockage_Drv of type COM_DT_Blockage_Drv
 *   Blockage_Init of type COM_DT_Blockage_Init
 *   RadarCANCommError of type COM_DT_RadarCANCommError
 *   RadarErrorCode_No1 of type COM_DT_RadarErrorCode_No1
 *   RadarErrorCode_No2 of type COM_DT_RadarErrorCode_No2
 *   RadarHwError of type COM_DT_RadarHwError
 *   RadarHwTempCondition_High of type COM_DT_RadarHwTempCondition_High
 *   RadarHwTempCondition_Low of type COM_DT_RadarHwTempCondition_Low
 *   RD_DTC_AlvCntVal of type COM_DT_RD_DTC_AlvCntVal
 *   SystemOutOfCalibration_DRV of type COM_DT_SystemOutOfCalibration_DRV
 *   SystemOutOfCalibration_EOL of type COM_DT_SystemOutOfCalibration_EOL
 *   RD_DTC_CRCVal of type COM_DT_FR_RDR_CrcVal
 * ReversibleFailreDataType_t: Record with elements
 *   FR_CMR_Blockage of type uint8
 *   FR_CMR_Over_Temp of type uint8
 *   FR_CMR_SW_Reset of type uint8
 *   FR_CMR_HW_Reset of type uint8
 *   FR_RDR_Bloackage of type uint8
 *   FR_RDR_Over_Temp of type uint8
 *   FR_RDR_SW_Reset of type uint8
 *   FR_RDR_HW_Reset of type uint8
 *   OdometerValue of type uint32
 * SccCanSigFailSafeInfo_t: Record with elements
 *   b_C110117_Battery_Voltage_High of type boolean
 *   b_C110216_Battery_Voltage_Low of type boolean
 *   b_C160449_ECU_Hardware_Error of type boolean
 *   b_C160649_ECU_Software_Error of type boolean
 *   b_C160A87_Local_CAN_Bus_Off of type boolean
 *   b_C160C87_Local_CAN_Time_Out of type boolean
 *   b_C161187_CAN_Time_Out_EMS of type boolean
 *   b_C161487_CAN_Time_Out_HCU of type boolean
 *   b_C161287_CAN_Time_Out_TCU of type boolean
 *   b_C161386_CAN_Signal_Error_EMS of type boolean
 *   b_C161C86_CAN_Signal_Error_HCU of type boolean
 *   b_C161E87_E_CAN_Bus_Off of type boolean
 *   b_C162387_CAN_Time_Out_SAS of type boolean
 *   b_C162587_CAN_Time_Out_ABS_ESP of type boolean
 *   b_C162887_CAN_Time_Out_CLU of type boolean
 *   b_C164286_CAN_Msg_Failure_brake of type boolean
 *   b_C164686_CAN_Signal_Error_TCU of type boolean
 *   b_C165686_CAN_Signal_Error_CLU of type boolean
 *   b_C28B881_ESP_Reversible_Error of type boolean
 *   b_C170246_Variant_Coding_Error of type boolean
 *   b_C174281_Variant_Error_ESC of type boolean
 *   b_B26A687_CAN_Time_Out_ICU of type boolean
 *   b_C183186_CAN_Signal_Error_NAVI of type boolean
 *   b_C184286_YRS_Not_valid of type boolean
 *   b_C186387_CAN_Time_Out_NAVI_forHDA of type boolean
 *   b_C272146_System_Calibration_Required of type boolean
 *   b_C272246_System_Out_Calibration of type boolean
 *   b_No222_CAN_Msg_Failure_brake_DiagMode of type boolean
 *   b_C166987_CAN_Time_Out_ACU of type boolean
 *   b_C183C86_CAN_Msg_Failure_ICU of type boolean
 *   b_C181486_CAN_Msg_Failure_SAS of type boolean
 *   b_C16B902_FCASCC_Communication_Error of type boolean
 *   b_C135F81_HCU_Trq_Ctrl_Unavailable of type boolean
 *   b_C167A87_CAN_Time_Out_NAVI of type boolean
 *   b_C2A2397_Front_Camera_Blockage of type boolean
 *   b_C2A274B_Front_Camera_OverTemp of type boolean
 *   b_B26A987_CANTime_Out_HOD of type boolean
 *   b_C225387_CANTime_Out_IBU of type boolean
 *   b_C186A87_CANTime_Out_ILCU_LH of type boolean
 *   b_C186B87_CANTime_Out_ILCU_RH of type boolean
 *   b_C185087_CANTime_Out_MFSW of type boolean
 *   b_C168787_CANTime_Out_VSM2 of type boolean
 *   b_C168886_VSM2_Signal_Error of type boolean
 *   b_C223986_MDPS_Steering_Control_Failure_LKA of type boolean
 *   b_C290386_Invalid_Signal_HOD of type boolean
 *   b_C28C586_Lateral_Control_Failure of type boolean
 *   b_C170255_Variant_Coding_Error of type boolean
 *   b_C183129_CAN_Signal_Error_NAVI of type boolean
 *   b_C28AC87_CANTime_Out_SWRC of type boolean
 *   b_C183D86_CANMsg_Failure_SWRC of type boolean
 * SccRdrBlockage_t: Record with elements
 *   u8_Blockage_Drv of type uint8
 *   u8_Blockage_Init of type uint8
 * SccRdrSigFailSafeInfo_t: Record with elements
 *   b_No140_FrRdrHw_Fail of type boolean
 *   b_No141_FrRdrAlignment_Fail of type boolean
 *   b_No142_FrRdrVolt_Fail of type boolean
 *   b_No143_FrRdrComm_Fail of type boolean
 *   b_No144_FrRdrOvrTemp_Fail of type boolean
 *   b_C28B181_CAN_Signal_Error_FR_RDR of type boolean
 *   u8_FrRdrBlockage_Fail of type uint8
 *   u8_FrRdrInitBlockage_Fail of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_1_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_2_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_3_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_4_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_5_MirrorBlock(void)
 *
 *********************************************************************************************************************/


#define CpApDiag_START_SEC_CODE
#include "CpApDiag_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_ControlDTCSetting
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ControlDTCSetting> of PortPrototype <PP_ControlDTCSetting>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_Re_ControlDTCSetting(uint8 DTCCantrolData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_ControlDTCSetting_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_ControlDTCSetting_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApDiag_CODE) Os_Call_Re_ControlDTCSetting(uint8 DTCCantrolData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_Re_ControlDTCSetting (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApDiag_CODE) Re_CpApDiagInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_De_Eng_Power9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(FcaFailSafeInfoTrailerMsgTout_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaWarnLampCond_De_FcaWarnLampCond(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_GetOdoVal_De_OdoVal(COM_DT_CLU_OdoVal *data)
 *   Std_ReturnType Rte_Read_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_RadarDtcInfo_RadarDtcInfo(RadarDtcInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_SccRdrBlockage_De_SccRdrBlockage(SccRdrBlockage_t *data)
 *   Std_ReturnType Rte_Read_RP_SccWarnLampCond_De_SccWarnLampCond(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo(const CoFcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_DawFailInfo_De_DawFailInfo(const DawFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaFailSafeInfo_De_FcaFailSafeInfo(const FcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaFailInfo_De_HbaFailInfo(const HbaFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwFailInfo_De_IslwFailInfo(const IslwFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(const LssCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo(const SccCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo(const SccRdrSigFailSafeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_ABS_ESC_Diagmode_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_CYPRESSFLASHTESTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_535F81_HCU_Enblsts_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_GND_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_OPEN_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_PRESSED_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560449_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560649_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560A87_BUS_OFF_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560C87_TimeOut_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561287_HTCU_04_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561287_TCU_01_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_EMS_02_10_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_AccelPdVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_HevRdySta_Invld_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561E87_ECAN_Busoff_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562387_SAS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Abs_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Esc01_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_500_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_Clu02_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_GearSlctDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_Invalid_CLU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_566987_IMU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568787_MDPS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570246_Eng_TransmsmTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570246_NoVarErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570255_MDPS_Type_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583129_NaviInvSig_NSCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_NAVI_ISLW_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_NaviInvSig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_LongAccelVal_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584886_BCM_10_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_585087_MFSW_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_ADAS_MDPS_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_08_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_10_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_672246_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B181_RDR_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B881_ESP_Rev_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_6A2397_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_6A274B_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_02_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_04_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_07_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_BAT_HIGHFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_BAT_LOWFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_Rdr_BatFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_NOCALIBRATIONFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Drv_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Init_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_CanCommFailure_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_HwFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_HwTempCondition_High_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_NoTargetFound_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_SWRC_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_SWRC_NoReception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_THERMALSHUTDOWNFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Unintended_RdrConfig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_WDGTSTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560449_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560449_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_672246_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_672246_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_ABS_ESC_Diagmode_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_BAT_LOWFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_CYPRESSFLASHTESTFAIL_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC672146_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_AliveCntErr_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_BatFail_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_Init_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_CanCommFailure_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_EolAlign_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwFail_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwTempCondition_High_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_535F81_HCU_Enblsts_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_GND_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_OPEN_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_PRESSED_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560449_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560649_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560A87_BUS_OFF_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560C87_TimeOut_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_02_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_03_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_05_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_07_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_11_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561287_HTCU_04_10_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561287_TCU_01_10_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_EMS_02_10_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_AccelPdlVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_HEV_AccelPdVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_HEV_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561C86_HCU_03_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561C86_HCU_HevRdySta_Invld_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561E87_ECAN_Busoff_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562387_SAS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Abs_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Esc01_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SPLIT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_2K_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_500_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_Clu02_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_01_AVH_Sta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_CylPrsrVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_03_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_Whl_01_ABS_ESC_01_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_HTCU_05_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_TCU_Alvcnt_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_TCU_GearSlctDis_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCCrsMainSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCLFASwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SpdUnitTyp_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_Invalid_CLU_01_10ms_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_566987_IMU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_CLU_PE_05_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_MON_GW_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568787_MDPS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_MDPS_LkaPlgInSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_Daw_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_56B902_ESC_FCA_AvlblSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_56B902_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570246_Eng_TransmsmTyp_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570246_NoVarErr_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570255_MDPS_Type_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_574281_FCA_EquipSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_574281_SCC_OptTyp_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583129_NaviInvSig_NSCC_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_30K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_NAVI_ISLW_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_NaviInvSig_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_LFASwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_LongAccelVal_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584886_BCM_10_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_585087_MFSW_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_HDA_NAVI_Timeout_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_12K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_60K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_ADAS_MDPS_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_Actvsta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_625387_BCM_08_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_625387_BCM_10_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_672246_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68AC87_LKA_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68AC87_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B181_EMS_07_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B181_RDR_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B881_ESP_Rev_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B981_ESP_Rev_Error_FCA_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_6A2397_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_6A274B_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_02_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_04_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_07_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_BAT_HIGHFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_NOCALIBRATIONFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_Rdr_NoTargetFound_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_SWRC_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_SWRC_NoReception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_THERMALSHUTDOWNFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_Unintended_RdrConfig_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_WDGTSTFAIL_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApDiag_CODE) Re_CpApDiagMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagOut_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApDiag_CODE) Re_CpApDiagOut(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApDiagOut
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApplClearDTC
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ApplClearDTC> of PortPrototype <PP_ApplClearDTC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_Re_CpApplClearDTC(void)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApplClearDTC_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApDiag_CODE) Os_Call_Re_CpApplClearDTC(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_Re_CpApplClearDTC
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data20ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApDiag_CODE) Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) Data) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_GetAppDiagFltStatus
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <GetAppDiagFltStatus> of PortPrototype <PP_AppDiagFaultStatus>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_GetAppDiagFltStatus(void)
 *   void Rte_Exit_ExclusiveArea_GetAppDiagFltStatus(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_GetAppDiagFltStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApDiag_CODE) Re_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) faultStatus_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_GetAppDiagFltStatus (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SetAppDiagFaultStatus
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetAppDiagFltStatus> of PortPrototype <PP_AppDiagFaultStatus>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_SetAppDiagFaultStatus(void)
 *   void Rte_Exit_ExclusiveArea_SetAppDiagFaultStatus(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_Re_SetAppDiagFaultStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_SetAppDiagFaultStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApDiag_CODE) Os_Call_Re_SetAppDiagFaultStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Os_Call_Re_SetAppDiagFaultStatus (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApDiag_STOP_SEC_CODE
#include "CpApDiag_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: runnable implementation:Re_ControlDTCSetting)  ***************************/

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
