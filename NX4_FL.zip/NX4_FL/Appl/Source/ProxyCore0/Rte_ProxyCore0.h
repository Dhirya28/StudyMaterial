/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_ProxyCore0.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  ProxyCore0
 *  Generation Time:  2023-04-20 13:53:14
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <ProxyCore0> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_PROXYCORE0_H
# define _RTE_PROXYCORE0_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_ProxyCore0_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_ProxyCore0
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_ProxyCore0, RTE_CONST, RTE_CONST) Rte_Inst_ProxyCore0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_ProxyCore0, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Switch_ProxyCore0_PP_ProxyCore0Ready_ProxyCore0Ready(uint8 nextMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Switch_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Switch_PP_ProxyCore0Ready_ProxyCore0Ready Rte_Switch_ProxyCore0_PP_ProxyCore0Ready_ProxyCore0Ready


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished
# define Rte_Call_RP_NvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished Rte_Call_ProxyCore0_RP_NvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished




# define ProxyCore0_START_SEC_CODE
# include "ProxyCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetEventStatus> of PortPrototype <PP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK
 *   RTE_E_IF_Proxy_DiagnosticMonitor_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus ProxyCore0_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_DvTest_Mode_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_DvTest_Mode_ReadBlock ProxyCore0_NvMService_DvTest_Mode_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_DvTest_Mode_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_DvTest_Mode_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_DvTest_Mode_WriteBlock ProxyCore0_NvMService_DvTest_Mode_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_DvTest_Mode_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQCAM_CamHwCalParams_Main>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQCAM_CamHwCalParams_Main>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQC_SpeedFactorPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_ReadBlock ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQC_SpeedFactorPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_WriteBlock ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQC_SpeedFactorPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQC_SpeedFactorSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_ReadBlock ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQC_SpeedFactorSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_WriteBlock ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQC_SpeedFactorSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQDG_LastFSDataRcdPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQDG_LastFSDataRcdPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQDG_LastFSDataRcdSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQDG_LastFSDataRcdSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQDG_SafetyFuncConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_ReadBlock ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQDG_SafetyFuncConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_WriteBlock ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQDG_SafetyFuncConfig_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_AutoFixCalPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_AutoFixCalPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_AutoFixCalSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_AutoFixCalSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsFisheye>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsFisheye>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsMain>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_ReadBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsMain>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_WriteBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsMain_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsNarrow>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_CamDistorParamsNarrow>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CameraFocused_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_CameraFocused>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CameraFocused_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CameraFocused_ReadBlock ProxyCore0_NvMService_EYEQMESP_CameraFocused_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CameraFocused_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_CameraFocused_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_CameraFocused>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_CameraFocused_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_CameraFocused_WriteBlock ProxyCore0_NvMService_EYEQMESP_CameraFocused_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_CameraFocused_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_EnvironmentParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_ReadBlock ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_EnvironmentParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_WriteBlock ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_EnvironmentParams_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPCCalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPCCalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPCCalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPCCalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPTACCalibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_ReadBlock ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_SPTACCalibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_WriteBlock ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SPTACCalibration_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_SfrMtfvMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_ReadBlock ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_SfrMtfvMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_WriteBlock ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_SfrMtfvMode_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2CalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2CalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2CalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2CalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_ReadBlock ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_WriteBlock ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TAC2InitParams_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_TargetCalParamsLimits>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_TargetCalParamsLimits>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQMESP_VehicleCalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_ReadBlock ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQMESP_VehicleCalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_WriteBlock ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQMESP_VehicleCalParams_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQSYS_EyeQSysCfg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_ReadBlock ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQSYS_EyeQSysCfg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_WriteBlock ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQSYS_EyeQSysCfg_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalParams_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalParams_ReadBlock ProxyCore0_NvMService_EYEQTHSD_ThermalParams_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalParams_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalParams_WriteBlock ProxyCore0_NvMService_EYEQTHSD_ThermalParams_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_DriveSidePrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQC_DriveSidePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_DriveSidePrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_DriveSidePrimary_ReadBlock ProxyCore0_NvMService_EyeQC_DriveSidePrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_DriveSidePrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_DriveSidePrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQC_DriveSidePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_DriveSidePrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_DriveSidePrimary_WriteBlock ProxyCore0_NvMService_EyeQC_DriveSidePrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_DriveSidePrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_DriveSideSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQC_DriveSideSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_DriveSideSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_DriveSideSecondary_ReadBlock ProxyCore0_NvMService_EyeQC_DriveSideSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_DriveSideSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_DriveSideSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQC_DriveSideSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_DriveSideSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_DriveSideSecondary_WriteBlock ProxyCore0_NvMService_EyeQC_DriveSideSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_DriveSideSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_RegionCodePrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQC_RegionCodePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_RegionCodePrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_RegionCodePrimary_ReadBlock ProxyCore0_NvMService_EyeQC_RegionCodePrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_RegionCodePrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_RegionCodePrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQC_RegionCodePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_RegionCodePrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_RegionCodePrimary_WriteBlock ProxyCore0_NvMService_EyeQC_RegionCodePrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_RegionCodePrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQC_RegionCodeSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_ReadBlock ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQC_RegionCodeSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_WriteBlock ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQC_RegionCodeSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQFfsSrvc_FfsHash>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_ReadBlock ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQFfsSrvc_FfsHash>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_WriteBlock ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQFfsSrvc_FfsHash_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQIDMGRC_SerialNumberPCB>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQIDMGRC_SerialNumberPCB>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQ_SetNextBootMode_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQ_SetNextBootMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQ_SetNextBootMode_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQ_SetNextBootMode_ReadBlock ProxyCore0_NvMService_EyeQ_SetNextBootMode_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQ_SetNextBootMode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQ_SetNextBootMode_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQ_SetNextBootMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQ_SetNextBootMode_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQ_SetNextBootMode_WriteBlock ProxyCore0_NvMService_EyeQ_SetNextBootMode_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQ_SetNextBootMode_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_EyeQ_SetNextManualExposureVal>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_ReadBlock ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_EyeQ_SetNextManualExposureVal>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_WriteBlock ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_EyeQ_SetNextManualExposureVal_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_HKMC_TraceabilityInformation_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_HKMC_TraceabilityInformation_ReadBlock ProxyCore0_NvMService_HKMC_TraceabilityInformation_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_HKMC_TraceabilityInformation_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_HKMC_TraceabilityInformation_WriteBlock ProxyCore0_NvMService_HKMC_TraceabilityInformation_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_SECURITY_RNGInitCount_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_SECURITY_RNGInitCount>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_SECURITY_RNGInitCount_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_SECURITY_RNGInitCount_ReadBlock ProxyCore0_NvMService_SECURITY_RNGInitCount_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_SECURITY_RNGInitCount_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_SECURITY_RNGInitCount_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_SECURITY_RNGInitCount>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_SECURITY_RNGInitCount_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_SECURITY_RNGInitCount_WriteBlock ProxyCore0_NvMService_SECURITY_RNGInitCount_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_SECURITY_RNGInitCount_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFECUHwNrDataId_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFECUHwNrDataId_ReadBlock ProxyCore0_NvMService_ZFECUHwNrDataId_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFECUHwNrDataId_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFECUHwNrDataId_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFECUHwNrDataId_WriteBlock ProxyCore0_NvMService_ZFECUHwNrDataId_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFECUHwNrDataId_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFECUHwVerNrDataId_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFECUHwVerNrDataId_ReadBlock ProxyCore0_NvMService_ZFECUHwVerNrDataId_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFECUHwVerNrDataId_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFECUHwVerNrDataId_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFECUHwVerNrDataId_WriteBlock ProxyCore0_NvMService_ZFECUHwVerNrDataId_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFECUHwVerNrDataId_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFManfrECUSerialNr_ReadBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadBlock> of PortPrototype <PP_NvMService_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFManfrECUSerialNr_ReadBlock ProxyCore0_NvMService_ZFManfrECUSerialNr_ReadBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_NvMService_ZFManfrECUSerialNr_WriteBlock
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteBlock> of PortPrototype <PP_NvMService_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType ProxyCore0_NvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_VOID SrcPtr)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_Proxy_NvMServices_E_NOK
 *   RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_NvMService_ZFManfrECUSerialNr_WriteBlock ProxyCore0_NvMService_ZFManfrECUSerialNr_WriteBlock
FUNC(Std_ReturnType, ProxyCore0_CODE) ProxyCore0_NvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore0_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_ProxyCore0Ready_ProxyCore0Ready(uint8 mode)
 *   Modes of Rte_ModeType_ProxyCore0Ready:
 *   - RTE_MODE_ProxyCore0Ready_False
 *   - RTE_MODE_ProxyCore0Ready_True
 *   - RTE_TRANSITION_ProxyCore0Ready
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_NvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_RequestResultType JobResult)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore0_Run ProxyCore0_Run
FUNC(void, ProxyCore0_CODE) ProxyCore0_Run(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define ProxyCore0_STOP_SEC_CODE
# include "ProxyCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_Proxy_DiagnosticMonitor_E_NOK (1U)

# define RTE_E_IF_Proxy_DiagnosticMonitor_E_OK (0U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_PROXYCORE0_H */
