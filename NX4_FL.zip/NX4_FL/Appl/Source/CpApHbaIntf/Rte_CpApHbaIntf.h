/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApHbaIntf.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApHbaIntf
 *  Generation Time:  2023-04-20 13:52:33
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApHbaIntf> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPHBAINTF_H
# define _RTE_CPAPHBAINTF_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApHbaIntf_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApHbaIntf
{
  /* PIM Handles section */
  P2VAR(HbaFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HbaFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HbaOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HbaOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApHbaIntf, RTE_CONST, RTE_CONST) Rte_Inst_CpApHbaIntf; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApHbaIntf, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_RxMsgsInFrame (0ULL)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHbaIntf_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApHbaIntf_RP_EyeQ_FrameReady_RxMsgsInFrame(P2VAR(uint64, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApHbaIntf_PP_HbaInput_De_HbaInput(P2CONST(HbaInput_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Brightness_Score(P2VAR(float32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Brightness_Score); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Decision(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Decision); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Inactive_Reason(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Inactive_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Reason(P2VAR(uint32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Running_Mode(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Running_Mode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HLB_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Left(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Angular_Velocity_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Right(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Angular_Velocity_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_H(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Atten_Cent_Angle_H); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_Lat(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Atten_Cent_Angle_Lat); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Bottom_Angle(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Bottom_Angle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Brightness); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness_Score(P2VAR(float32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Brightness_Score); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Left(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_CL_Distance_Left); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Right(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_CL_Distance_Right); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Sub_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_CL_Sub_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Confidence(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Consecutive_Detection(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Consecutive_Detection); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Distance); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance_STD(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Distance_STD); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Decision(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_HLB_Decision); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Reason(P2VAR(uint32, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_HLB_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Inactive_Reason(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Inactive_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Is_New(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Is_New); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Left_Angle(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Left_Angle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Right_Angle(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Right_Angle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Running_Mode(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Running_Mode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sub_Type(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Sub_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Top_Angle(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Top_Angle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Type(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Type); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_VD_ID(uint16 Index, P2VAR(uint16, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_VD_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Vehicles_Count(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) LSV_Vehicles_Count); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) MainState_pu8, P2VAR(uint8, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) SubState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_NvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_NvMService_HbaFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_NvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApHbaIntf_RP_NvMService_HbaOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApHbaIntf_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame Rte_Read_CpApHbaIntf_RP_EyeQ_FrameReady_RxMsgsInFrame


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_HbaInput_De_HbaInput Rte_Write_CpApHbaIntf_PP_HbaInput_De_HbaInput


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Brightness_Score Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Brightness_Score
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Decision Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Decision
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Inactive_Reason Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Inactive_Reason
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Protocol_Version Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Reason Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Reason
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Running_Mode Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Running_Mode
# define Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Sync_ID Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Left Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Left
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Right Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Right
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_H Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_H
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_Lat Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_Lat
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Bottom_Angle Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Bottom_Angle
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness_Score Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness_Score
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Left Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Left
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Right Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Right
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Sub_Type Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Sub_Type
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Confidence Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Confidence
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Consecutive_Detection Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Consecutive_Detection
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance_STD Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance_STD
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Decision Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Decision
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Reason Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Reason
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_ID Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_ID
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Inactive_Reason Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Inactive_Reason
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Is_New Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Is_New
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Left_Angle Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Left_Angle
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Protocol_Version Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Right_Angle Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Right_Angle
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Running_Mode Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Running_Mode
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sub_Type Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sub_Type
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sync_ID Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Top_Angle Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Top_Angle
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Type Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Type
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_VD_ID Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_VD_ID
# define Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Vehicles_Count Rte_Call_CpApHbaIntf_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Vehicles_Count
# define Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState Rte_Call_CpApHbaIntf_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApHbaIntf_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_NvMService_HbaFrqNvData_ReadBlock Rte_Call_CpApHbaIntf_RP_NvMService_HbaFrqNvData_ReadBlock
# define Rte_Call_RP_NvMService_HbaFrqNvData_WriteBlock Rte_Call_CpApHbaIntf_RP_NvMService_HbaFrqNvData_WriteBlock
# define Rte_Call_RP_NvMService_HbaOccNvData_ReadBlock Rte_Call_CpApHbaIntf_RP_NvMService_HbaOccNvData_ReadBlock
# define Rte_Call_RP_NvMService_HbaOccNvData_WriteBlock Rte_Call_CpApHbaIntf_RP_NvMService_HbaOccNvData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_HbaFrqNvData() (Rte_Inst_CpApHbaIntf->Pim_HbaFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_HbaOccNvData() (Rte_Inst_CpApHbaIntf->Pim_HbaOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   HbaFrqNvData_t *Rte_Pim_HbaFrqNvData(void)
 *   HbaOccNvData_t *Rte_Pim_HbaOccNvData(void)
 *
 *********************************************************************************************************************/


# define CpApHbaIntf_START_SEC_CODE
# include "CpApHbaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished
FUNC(void, CpApHbaIntf_CODE) CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished
FUNC(void, CpApHbaIntf_CODE) CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_HbaInput_De_HbaInput(const HbaInput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Brightness_Score(float32 *HLB_Brightness_Score)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Decision(uint8 *HLB_Decision)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Inactive_Reason(uint8 *HLB_Inactive_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Protocol_Version(uint8 *HLB_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Reason(uint32 *HLB_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Running_Mode(uint8 *HLB_Running_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Sync_ID(uint8 *HLB_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Left(uint16 Index, uint16 *LSV_Angular_Velocity_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Right(uint16 Index, uint16 *LSV_Angular_Velocity_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_H(uint16 Index, uint16 *LSV_Atten_Cent_Angle_H)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_Lat(uint16 Index, uint16 *LSV_Atten_Cent_Angle_Lat)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Bottom_Angle(uint16 Index, uint16 *LSV_Bottom_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness(uint16 Index, uint32 *LSV_Brightness)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness_Score(float32 *LSV_Brightness_Score)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Left(uint16 Index, uint16 *LSV_CL_Distance_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Right(uint16 Index, uint16 *LSV_CL_Distance_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Sub_Type(uint16 Index, uint8 *LSV_CL_Sub_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Confidence(uint16 Index, uint8 *LSV_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Consecutive_Detection(uint16 Index, uint8 *LSV_Consecutive_Detection)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance(uint16 Index, uint16 *LSV_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance_STD(uint16 Index, uint8 *LSV_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Decision(uint8 *LSV_HLB_Decision)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Reason(uint32 *LSV_HLB_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_ID(uint16 Index, uint8 *LSV_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Inactive_Reason(uint8 *LSV_Inactive_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Is_New(uint16 Index, uint8 *LSV_Is_New)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Left_Angle(uint16 Index, uint16 *LSV_Left_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Protocol_Version(uint8 *LSV_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Right_Angle(uint16 Index, uint16 *LSV_Right_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Running_Mode(uint8 *LSV_Running_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sub_Type(uint16 Index, uint16 *LSV_Sub_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sync_ID(uint8 *LSV_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Top_Angle(uint16 Index, uint16 *LSV_Top_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Type(uint16 Index, uint8 *LSV_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_VD_ID(uint16 Index, uint16 *LSV_VD_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Vehicles_Count(uint8 *LSV_Vehicles_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaIntfEyeQRead Re_CpApHbaIntfEyeQRead
FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfEyeQRead(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaIntfInit Re_CpApHbaIntfInit
FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaIntfMain Re_CpApHbaIntfMain
FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaReadHbaFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaFrqNvDataRead> of PortPrototype <PP_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaReadHbaFrqNvData(HbaFrqNvData_t *HbaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaReadHbaFrqNvData Re_CpApHbaReadHbaFrqNvData
FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaReadHbaFrqNvData(P2VAR(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HbaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaReadHbaOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaOccNvDataRead> of PortPrototype <PP_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaReadHbaOccNvData(HbaOccNvData_t *HbaOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaReadHbaOccNvData Re_CpApHbaReadHbaOccNvData
FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaReadHbaOccNvData(P2VAR(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HbaOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaWriteHbaFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaFrqNvDataWrite> of PortPrototype <PP_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaWriteHbaFrqNvData(const HbaFrqNvData_t *HbaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaWriteHbaFrqNvData Re_CpApHbaWriteHbaFrqNvData
FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaWriteHbaFrqNvData(P2CONST(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_DATA) HbaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaWriteHbaOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaOccNvDataWrite> of PortPrototype <PP_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaWriteHbaOccNvData(const HbaOccNvData_t *HbaOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApHbaWriteHbaOccNvData Re_CpApHbaWriteHbaOccNvData
FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaWriteHbaOccNvData(P2CONST(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_DATA) HbaOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApHbaIntf_STOP_SEC_CODE
# include "CpApHbaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType (1U)

# define RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_HbaFrqNvData_ReturnType (1U)

# define RTE_E_IF_HbaOccNvData_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPHBAINTF_H */
