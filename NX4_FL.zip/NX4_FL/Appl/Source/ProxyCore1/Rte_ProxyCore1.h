/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_ProxyCore1.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  ProxyCore1
 *  Generation Time:  2023-04-20 13:53:16
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <ProxyCore1> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_PROXYCORE1_H
# define _RTE_PROXYCORE1_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_ProxyCore1_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_ProxyCore1
{
  /* PIM Handles section */
  P2VAR(DawFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DawFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(DawOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DawOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(DvTest_Mode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DvTest_Mode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQCAM_CamHwCalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQCAM_CamHwCalParams_Main; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQC_SpeedFactorCalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQC_SpeedFactorPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQC_SpeedFactorCalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQC_SpeedFactorSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQDG_LastFSDataRcd_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQDG_LastFSDataRcdPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQDG_LastFSDataRcd_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQDG_LastFSDataRcdSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQDG_SafetyFuncConfig_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQDG_SafetyFuncConfig; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_AutoFixCalData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_AutoFixCalPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_AutoFixCalData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_AutoFixCalSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_CamDistorParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_CamDistorParamsFisheye; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_CamDistorParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_CamDistorParamsMain; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_CamDistorParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_CamDistorParamsNarrow; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_CameraFocused_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_CameraFocused; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_EnvironmentParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_EnvironmentParams; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalibData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_SPCCalibrationPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalibData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_SPCCalibrationSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalibData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_SPTACCalibration; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_SfrMtfvMode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_SfrMtfvMode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalibData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_TAC2CalibrationPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalibData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_TAC2CalibrationSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TAC2InitParamsNVM_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_TAC2InitParams; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_TargetCalParamsLimits_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_TargetCalParamsLimits; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQMESP_VehicleCalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQMESP_VehicleCalParams; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQ_SysCfgFlgsRcd_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQSYS_EyeQSysCfg; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQTHSD_ThermalParams_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalParams; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQTHSD_ThermalShutdownValues_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalShutdownPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EYEQTHSD_ThermalShutdownValues_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EYEQTHSD_ThermalShutdownSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQC_DriveSide_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQC_DriveSidePrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQC_DriveSide_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQC_DriveSideSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQC_RegionCode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQC_RegionCodePrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQC_RegionCode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQC_RegionCodeSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQFfsSrvc_FfsHash_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQFfsSrvc_FfsHash; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQIDMGRC_SerialNumberPCB_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQIDMGRC_SerialNumberPCB; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IoHwAb_HeaterInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQIoHwAb_HeaterInfoPrimary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IoHwAb_HeaterInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQIoHwAb_HeaterInfoSecondary; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQ_SetNextBootMode_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQ_SetNextBootMode; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(EyeQ_SetNextManualExposureVal_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EyeQ_SetNextManualExposureVal; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HKMC_TraceabilityInformation_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HKMC_TraceabilityInformation; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HbaFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HbaFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HbaOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_HbaOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IslwFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_IslwFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(IslwOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_IslwOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(LssFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_LssFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(SECURITY_RNGInitCount_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_SECURITY_RNGInitCount; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFECUHwNrDataId_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFECUHwNrDataId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFECUHwVerNrDataId_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFECUHwVerNrDataId; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ZFManfrECUSerialNr_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ZFManfrECUSerialNr; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_ProxyCore1, RTE_CONST, RTE_CONST) Rte_Inst_ProxyCore1; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_ProxyCore1, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Switch_ProxyCore1_PP_ProxyCore1Ready_ProxyCore1Ready(uint8 nextMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DawFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DawOccNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_DvTest_Mode_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CameraFocused_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CameraFocused_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSidePrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSidePrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSideSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSideSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodePrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodePrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextBootMode_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextBootMode_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaOccNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwOccNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_LssFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_SECURITY_RNGInitCount_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_SECURITY_RNGInitCount_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwNrDataId_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwVerNrDataId_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Switch_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Switch_PP_ProxyCore1Ready_ProxyCore1Ready Rte_Switch_ProxyCore1_PP_ProxyCore1Ready_ProxyCore1Ready


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus Rte_Call_ProxyCore1_RP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus
# define Rte_Call_RP_ProxyNvMService_DawFrqNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DawFrqNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_DawFrqNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DawFrqNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_DawOccNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DawOccNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_DawOccNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DawOccNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_DvTest_Mode_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DvTest_Mode_ReadBlock
# define Rte_Call_RP_ProxyNvMService_DvTest_Mode_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_DvTest_Mode_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CameraFocused_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_CameraFocused_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalParams_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalParams_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSidePrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSidePrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSideSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_DriveSideSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodePrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodePrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextBootMode_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextBootMode_WriteBlock
# define Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_ReadBlock
# define Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_WriteBlock
# define Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HKMC_TraceabilityInformation_ReadBlock
# define Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HKMC_TraceabilityInformation_WriteBlock
# define Rte_Call_RP_ProxyNvMService_HbaFrqNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaFrqNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_HbaFrqNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaFrqNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_HbaOccNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaOccNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_HbaOccNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_HbaOccNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_IslwFrqNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwFrqNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_IslwFrqNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwFrqNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_IslwOccNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwOccNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_IslwOccNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_IslwOccNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_LssFrqNvData_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_LssFrqNvData_ReadBlock
# define Rte_Call_RP_ProxyNvMService_LssFrqNvData_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_LssFrqNvData_WriteBlock
# define Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_SECURITY_RNGInitCount_ReadBlock
# define Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_SECURITY_RNGInitCount_WriteBlock
# define Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwNrDataId_ReadBlock
# define Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwNrDataId_WriteBlock
# define Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwVerNrDataId_ReadBlock
# define Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFECUHwVerNrDataId_WriteBlock
# define Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_ReadBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFManfrECUSerialNr_ReadBlock
# define Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_WriteBlock Rte_Call_ProxyCore1_RP_ProxyNvMService_ZFManfrECUSerialNr_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_DawFrqNvData() (Rte_Inst_ProxyCore1->Pim_DawFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_DawOccNvData() (Rte_Inst_ProxyCore1->Pim_DawOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_DvTest_Mode() (Rte_Inst_ProxyCore1->Pim_DvTest_Mode) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQCAM_CamHwCalParams_Main() (Rte_Inst_ProxyCore1->Pim_EYEQCAM_CamHwCalParams_Main) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQC_SpeedFactorPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQC_SpeedFactorPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQC_SpeedFactorSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQC_SpeedFactorSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQDG_LastFSDataRcdPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQDG_LastFSDataRcdPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQDG_LastFSDataRcdSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQDG_LastFSDataRcdSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQDG_SafetyFuncConfig() (Rte_Inst_ProxyCore1->Pim_EYEQDG_SafetyFuncConfig) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_AutoFixCalPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_AutoFixCalPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_AutoFixCalSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_AutoFixCalSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_CamDistorParamsFisheye() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_CamDistorParamsFisheye) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_CamDistorParamsMain() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_CamDistorParamsMain) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_CamDistorParamsNarrow() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_CamDistorParamsNarrow) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_CameraFocused() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_CameraFocused) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_EnvironmentParams() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_EnvironmentParams) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_SPCCalibrationPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_SPCCalibrationPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_SPCCalibrationSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_SPCCalibrationSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_SPTACCalibration() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_SPTACCalibration) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_SfrMtfvMode() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_SfrMtfvMode) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_TAC2CalibrationPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_TAC2CalibrationPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_TAC2CalibrationSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_TAC2CalibrationSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_TAC2InitParams() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_TAC2InitParams) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_TargetCalParamsLimits() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_TargetCalParamsLimits) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQMESP_VehicleCalParams() (Rte_Inst_ProxyCore1->Pim_EYEQMESP_VehicleCalParams) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQSYS_EyeQSysCfg() (Rte_Inst_ProxyCore1->Pim_EYEQSYS_EyeQSysCfg) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQTHSD_ThermalParams() (Rte_Inst_ProxyCore1->Pim_EYEQTHSD_ThermalParams) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQTHSD_ThermalShutdownPrimary() (Rte_Inst_ProxyCore1->Pim_EYEQTHSD_ThermalShutdownPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EYEQTHSD_ThermalShutdownSecondary() (Rte_Inst_ProxyCore1->Pim_EYEQTHSD_ThermalShutdownSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQC_DriveSidePrimary() (Rte_Inst_ProxyCore1->Pim_EyeQC_DriveSidePrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQC_DriveSideSecondary() (Rte_Inst_ProxyCore1->Pim_EyeQC_DriveSideSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQC_RegionCodePrimary() (Rte_Inst_ProxyCore1->Pim_EyeQC_RegionCodePrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQC_RegionCodeSecondary() (Rte_Inst_ProxyCore1->Pim_EyeQC_RegionCodeSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQFfsSrvc_FfsHash() (Rte_Inst_ProxyCore1->Pim_EyeQFfsSrvc_FfsHash) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQIDMGRC_SerialNumberPCB() (Rte_Inst_ProxyCore1->Pim_EyeQIDMGRC_SerialNumberPCB) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary() (Rte_Inst_ProxyCore1->Pim_EyeQIoHwAb_HeaterInfoPrimary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary() (Rte_Inst_ProxyCore1->Pim_EyeQIoHwAb_HeaterInfoSecondary) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQ_SetNextBootMode() (Rte_Inst_ProxyCore1->Pim_EyeQ_SetNextBootMode) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_EyeQ_SetNextManualExposureVal() (Rte_Inst_ProxyCore1->Pim_EyeQ_SetNextManualExposureVal) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_HKMC_TraceabilityInformation() (Rte_Inst_ProxyCore1->Pim_HKMC_TraceabilityInformation) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_HbaFrqNvData() (Rte_Inst_ProxyCore1->Pim_HbaFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_HbaOccNvData() (Rte_Inst_ProxyCore1->Pim_HbaOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_IslwFrqNvData() (Rte_Inst_ProxyCore1->Pim_IslwFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_IslwOccNvData() (Rte_Inst_ProxyCore1->Pim_IslwOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_LssFrqNvData() (Rte_Inst_ProxyCore1->Pim_LssFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_SECURITY_RNGInitCount() (Rte_Inst_ProxyCore1->Pim_SECURITY_RNGInitCount) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFECUHwNrDataId() (Rte_Inst_ProxyCore1->Pim_ZFECUHwNrDataId) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFECUHwVerNrDataId() (Rte_Inst_ProxyCore1->Pim_ZFECUHwVerNrDataId) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ZFManfrECUSerialNr() (Rte_Inst_ProxyCore1->Pim_ZFManfrECUSerialNr) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   DawFrqNvData_t *Rte_Pim_DawFrqNvData(void)
 *   DawOccNvData_t *Rte_Pim_DawOccNvData(void)
 *   DvTest_Mode_t *Rte_Pim_DvTest_Mode(void)
 *   EYEQCAM_CamHwCalParams_t *Rte_Pim_EYEQCAM_CamHwCalParams_Main(void)
 *   EYEQC_SpeedFactorCalParams_t *Rte_Pim_EYEQC_SpeedFactorPrimary(void)
 *   EYEQC_SpeedFactorCalParams_t *Rte_Pim_EYEQC_SpeedFactorSecondary(void)
 *   EYEQDG_LastFSDataRcd_t *Rte_Pim_EYEQDG_LastFSDataRcdPrimary(void)
 *   EYEQDG_LastFSDataRcd_t *Rte_Pim_EYEQDG_LastFSDataRcdSecondary(void)
 *   EYEQDG_SafetyFuncConfig_t *Rte_Pim_EYEQDG_SafetyFuncConfig(void)
 *   EYEQMESP_AutoFixCalData_t *Rte_Pim_EYEQMESP_AutoFixCalPrimary(void)
 *   EYEQMESP_AutoFixCalData_t *Rte_Pim_EYEQMESP_AutoFixCalSecondary(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsFisheye(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsMain(void)
 *   EYEQMESP_CamDistorParams_t *Rte_Pim_EYEQMESP_CamDistorParamsNarrow(void)
 *   EYEQMESP_CameraFocused_t *Rte_Pim_EYEQMESP_CameraFocused(void)
 *   EYEQMESP_EnvironmentParams_t *Rte_Pim_EYEQMESP_EnvironmentParams(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPCCalibrationPrimary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPCCalibrationSecondary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_SPTACCalibration(void)
 *   EYEQMESP_SfrMtfvMode_t *Rte_Pim_EYEQMESP_SfrMtfvMode(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_TAC2CalibrationPrimary(void)
 *   EYEQMESP_TargetCalibData_t *Rte_Pim_EYEQMESP_TAC2CalibrationSecondary(void)
 *   EYEQMESP_TAC2InitParamsNVM_t *Rte_Pim_EYEQMESP_TAC2InitParams(void)
 *   EYEQMESP_TargetCalParamsLimits_t *Rte_Pim_EYEQMESP_TargetCalParamsLimits(void)
 *   EYEQMESP_VehicleCalParams_t *Rte_Pim_EYEQMESP_VehicleCalParams(void)
 *   EYEQ_SysCfgFlgsRcd_t *Rte_Pim_EYEQSYS_EyeQSysCfg(void)
 *   EYEQTHSD_ThermalParams_t *Rte_Pim_EYEQTHSD_ThermalParams(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownPrimary(void)
 *   EYEQTHSD_ThermalShutdownValues_t *Rte_Pim_EYEQTHSD_ThermalShutdownSecondary(void)
 *   EyeQC_DriveSide_t *Rte_Pim_EyeQC_DriveSidePrimary(void)
 *   EyeQC_DriveSide_t *Rte_Pim_EyeQC_DriveSideSecondary(void)
 *   EyeQC_RegionCode_t *Rte_Pim_EyeQC_RegionCodePrimary(void)
 *   EyeQC_RegionCode_t *Rte_Pim_EyeQC_RegionCodeSecondary(void)
 *   EyeQFfsSrvc_FfsHash_t *Rte_Pim_EyeQFfsSrvc_FfsHash(void)
 *   EyeQIDMGRC_SerialNumberPCB_t *Rte_Pim_EyeQIDMGRC_SerialNumberPCB(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoPrimary(void)
 *   IoHwAb_HeaterInfo_t *Rte_Pim_EyeQIoHwAb_HeaterInfoSecondary(void)
 *   EyeQ_SetNextBootMode_t *Rte_Pim_EyeQ_SetNextBootMode(void)
 *   EyeQ_SetNextManualExposureVal_t *Rte_Pim_EyeQ_SetNextManualExposureVal(void)
 *   HKMC_TraceabilityInformation_t *Rte_Pim_HKMC_TraceabilityInformation(void)
 *   HbaFrqNvData_t *Rte_Pim_HbaFrqNvData(void)
 *   HbaOccNvData_t *Rte_Pim_HbaOccNvData(void)
 *   IslwFrqNvData_t *Rte_Pim_IslwFrqNvData(void)
 *   IslwOccNvData_t *Rte_Pim_IslwOccNvData(void)
 *   LssFrqNvData_t *Rte_Pim_LssFrqNvData(void)
 *   SECURITY_RNGInitCount_t *Rte_Pim_SECURITY_RNGInitCount(void)
 *   ZFECUHwNrDataId_t *Rte_Pim_ZFECUHwNrDataId(void)
 *   ZFECUHwVerNrDataId_t *Rte_Pim_ZFECUHwVerNrDataId(void)
 *   ZFManfrECUSerialNr_t *Rte_Pim_ZFManfrECUSerialNr(void)
 *
 *********************************************************************************************************************/


# define ProxyCore1_START_SEC_CODE
# include "ProxyCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <BswServicesReady> of PortPrototype <RP_BswServicesReady>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_Init ProxyCore1_Init
FUNC(void, ProxyCore1_CODE) ProxyCore1_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_DvTest_Mode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_DvTest_Mode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQCAM_CamHwCalParams_Main_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQC_SpeedFactorSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_LastFSDataRcdSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQDG_SafetyFuncConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_AutoFixCalSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsFisheye_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsMain_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CamDistorParamsNarrow_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_CameraFocused_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_EnvironmentParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPCCalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SPTACCalibration_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_SfrMtfvMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2CalibrationSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_TargetCalParamsLimits_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQMESP_VehicleCalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQSYS_EyeQSysCfg_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EYEQTHSD_ThermalShutdownSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSidePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_DriveSideSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodePrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQC_RegionCodeSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQFfsSrvc_FfsHash_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIDMGRC_SerialNumberPCB_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoPrimary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQIoHwAb_HeaterInfoSecondary_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextBootMode_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_EyeQ_SetNextManualExposureVal_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HKMC_TraceabilityInformation_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_SECURITY_RNGInitCount_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFECUHwVerNrDataId_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished
FUNC(void, ProxyCore1_CODE) Os_Call_ProxyCore1_ProxyNvMNotifyJobFinished_ZFManfrECUSerialNr_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: ProxyCore1_Run
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_ProxyCore1Ready_ProxyCore1Ready(uint8 mode)
 *   Modes of Rte_ModeType_ProxyCore1Ready:
 *   - RTE_MODE_ProxyCore1Ready_False
 *   - RTE_MODE_ProxyCore1Ready_True
 *   - RTE_TRANSITION_ProxyCore1Ready
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALDYNWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CALSTCWrongModeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_CMNMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPMsgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_APPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_AppDiagVerifiersNotOK_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ApplDiag2Bit9SetBit10Clr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BOOTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_BootDiagMsgMissingErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CALSTCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CMNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CONARVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_CatalogIDInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_ChallengeRepetitionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DDRChipFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DFAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_DSTFSVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQFFSCorruptionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQSafetyMsgCRCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtBISTErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPARITYErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_EyeQStuckAtPLLErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFCVDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVDDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FCFVRUDYNVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FLSFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCamCCFT_CrcFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCodingFrmFlashFldErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppConfigErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppCpsStlFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppDdrDriftCompFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppFSErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppGVPUstateTerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppI2CVideoGrabFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamEepromErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSensIdMisErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCamSerCnvtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitCameraInitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppInitFromFlashFailErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppPatternTestErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAppSerdesGrabErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrApplI2cTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrAsilCameraErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrDiagAsilFailedErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrEdrWroteToFlashErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPLLCompErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FatalErrPVGeneralErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FlashMemoryFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_FrameMismatchtErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HLBVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HRVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_HZDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQCommDeadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCEyeQInitCalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_IPCMECompatibilityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_InvalidRegionCodeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LDWVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNADJVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNAPPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNCRVESTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNHSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNREVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LNSTDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCRFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_LSCVCVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingFirstChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MissingMsgErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_MsgTimeOutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_OBJTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RDGMTAVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_REMVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RPFLVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_RSDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SAFETYVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SFRVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLINVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNLNDVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SMNMRKVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPDFVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_SyncFrmIndexErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TFLSTVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_TTPVerErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_UnSupportedEyeQVersionErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_VehicleMsgTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_DG_WrongChallengeResponseErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQEDRAppError_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQInputSignalIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_ERROUTFatalErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_EyeQOpModeTransErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_FFSHashFailureErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMgr_SysVerifiReqTRWErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQMsgSizeMismatch_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_AppAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_BootAuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_EyeQSUSD_SequenceErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFHdrCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FLSFObjCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_OutOfFocusErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_FS_SevereMisAlignTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_BuffersMisalignmentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_PartialByteErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI0StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPCDRV_QSPI2StatusErrorFlagsErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ConsFrmNotRcvdErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_FrmSeqErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_ImproperFrmSizeErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_IncompleteMultiFrmErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_InvalidMESPHdrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_MespRspTimeoutErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IPC_UnKnwnAppIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_InternalDataIntegrityErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedHighErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_IoHwAb_ERROUTShortedtoGndErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_AutoFixCalSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsFisheyeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsMainCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamDistorParamsNarrowCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CamHwCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_CameraFocusedCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSidePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_DriveSideSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EnvironmentParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_EyeQSysCfgCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_FfsHashCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdPrimaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_LastFSDataRcdSecondaryCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodePrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_RegionCodeSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPCCalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SPTACCalibrationCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SafetyCriticalFuncConfigCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SecurityRNGInitCountCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SerialNumberPCBCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextBootModeCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SetNextManualExposureValCrCErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SfrMtfvModeCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_SpeedFactorCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationPrimaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2CalibrationSecondaryCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TAC2InitParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_TargetCalParamsLimitsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_ThermalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_NvM_VehicleCalParamsCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit04Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit06Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit07Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit09Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit11Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit13Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit18Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit21Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit24Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit25Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit26Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit27Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit29Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit30Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit31Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit34Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit35Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit37Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit38Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit40Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit44Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit45Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit49Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit50Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit53Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit54Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_SafetyDiagBit59Err_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixDieErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_AurixThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_DDRThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_EyeQThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_FishEyeImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_MainImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_EyeQEvt_ThermalDiag_NarrowImagerThermistorErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_BrokenWireDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_ConverterDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ADC_PullDownDiagErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_BoardRevInvalidErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtFlashFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_ResetLimitExceeded_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_ExtWdg_WdgTestFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Gpio18VerificationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OpenCircuitErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_OverCurrentErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToBattErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_Heater_ShortToLoadErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_HeaterInfoCrcErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_NvM_TagIDErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V1PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_1V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3FeyePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3MainPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3NarrowPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_3V3_2V8PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_5V0PwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_ImagerPwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTOverVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VBATTUnderVoltageErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_IoHwAbEvt_PwrMgr_VCorePwrErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SecurityEvt_EyeQSBS_AuthenticationErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DawOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DvTest_Mode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_DvTest_Mode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQCAM_CamHwCalParams_Main_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQC_SpeedFactorSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_LastFSDataRcdSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQDG_SafetyFuncConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_AutoFixCalSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsFisheye_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsMain_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CamDistorParamsNarrow_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_CameraFocused_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_EnvironmentParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPCCalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SPTACCalibration_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_SfrMtfvMode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2CalibrationSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TAC2InitParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_TargetCalParamsLimits_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQMESP_VehicleCalParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQSYS_EyeQSysCfg_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalParams_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EYEQTHSD_ThermalShutdownSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSidePrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_DriveSideSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodePrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQC_RegionCodeSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQFfsSrvc_FfsHash_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIDMGRC_SerialNumberPCB_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoPrimary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQIoHwAb_HeaterInfoSecondary_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextBootMode_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_EyeQ_SetNextManualExposureVal_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HKMC_TraceabilityInformation_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_HbaOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_IslwOccNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_LssFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_SECURITY_RNGInitCount_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwNrDataId_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFECUHwVerNrDataId_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ProxyNvMService_ZFManfrECUSerialNr_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_ProxyCore1_Run ProxyCore1_Run
FUNC(void, ProxyCore1_CODE) ProxyCore1_Run(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define ProxyCore1_STOP_SEC_CODE
# include "ProxyCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_DiagnosticMonitor_E_NOT_OK (1U)

# define RTE_E_NvMService_AC3_SRBS_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_PROXYCORE1_H */
