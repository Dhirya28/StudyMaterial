/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApDiag.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApDiag
 *  Generation Time:  2023-04-20 13:52:25
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApDiag> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPDIAG_H
# define _RTE_CPAPDIAG_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApDiag_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApDiag
{
  /* PIM Handles section */
  P2VAR(ReversibleFailreDataType_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_ReversibleFailureData_1_MirrorBlock; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ReversibleFailreDataType_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_ReversibleFailureData_2_MirrorBlock; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ReversibleFailreDataType_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_ReversibleFailureData_3_MirrorBlock; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ReversibleFailreDataType_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_ReversibleFailureData_4_MirrorBlock; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(ReversibleFailreDataType_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NvBlockNeed_ReversibleFailureData_5_MirrorBlock; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApDiag, RTE_CONST, RTE_CONST) Rte_Inst_CpApDiag; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApDiag, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_Eng_Power9v_De_Eng_Power9v (0U)
# define Rte_InitValue_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v (0U)
# define Rte_InitValue_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF (0U)
# define Rte_InitValue_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_FcaWarnLampCond_De_FcaWarnLampCond (0U)
# define Rte_InitValue_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc (0U)
# define Rte_InitValue_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc (0U)
# define Rte_InitValue_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA (0U)
# define Rte_InitValue_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF (0U)
# define Rte_InitValue_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v (0U)
# define Rte_InitValue_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v (0U)
# define Rte_InitValue_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus (0U)
# define Rte_InitValue_RP_SccWarnLampCond_De_SccWarnLampCond (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_Power9v_De_Eng_Power9v(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(P2VAR(FcaFailSafeInfoTrailerMsgTout_t, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_FcaWarnLampCond_De_FcaWarnLampCond(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_GetOdoVal_De_OdoVal(P2VAR(COM_DT_CLU_OdoVal, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_RadarDtcInfo_RadarDtcInfo(P2VAR(RadarDtcInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_SccRdrBlockage_De_SccRdrBlockage(P2VAR(SccRdrBlockage_t, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApDiag_RP_SccWarnLampCond_De_SccWarnLampCond(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo(P2CONST(CoFcaFailSafeInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_DawFailInfo_De_DawFailInfo(P2CONST(DawFailInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_FcaFailSafeInfo_De_FcaFailSafeInfo(P2CONST(FcaFailSafeInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_HbaFailInfo_De_HbaFailInfo(P2CONST(HbaFailInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_IslwFailInfo_De_IslwFailInfo(P2CONST(IslwFailInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(P2CONST(LssCanSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo(P2CONST(SccCanSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApDiag_PP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo(P2CONST(SccRdrSigFailSafeInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_ABS_ESC_Diagmode_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_CYPRESSFLASHTESTFAIL_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_535F81_HCU_Enblsts_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_GND_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_OPEN_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_PRESSED_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560449_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560649_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560A87_BUS_OFF_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560C87_TimeOut_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561287_HTCU_04_10_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561287_TCU_01_10_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_EMS_02_10_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_HEV_AccelPdVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561C86_HCU_HevRdySta_Invld_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561E87_ECAN_Busoff_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562387_SAS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Abs_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Esc01_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_500_CLU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_Clu02_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_TCU_GearSlctDis_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_Invalid_CLU_01_10ms_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_566987_IMU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568787_MDPS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570246_Eng_TransmsmTyp_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570246_NoVarErr_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570255_MDPS_Type_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583129_NaviInvSig_NSCC_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_NAVI_ISLW_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_NaviInvSig_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_LongAccelVal_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584886_BCM_10_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_585087_MFSW_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_ADAS_MDPS_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_625387_BCM_08_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_625387_BCM_10_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_672246_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B181_RDR_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B881_ESP_Rev_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_6A2397_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_6A274B_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_02_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_04_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_07_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_BAT_HIGHFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_BAT_LOWFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_Rdr_BatFail_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_NOCALIBRATIONFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_Blockage_Drv_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_Blockage_Init_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_CanCommFailure_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_EolAlign_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_HwFail_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_HwTempCondition_High_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_NoTargetFound_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_SWRC_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_SWRC_NoReception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_THERMALSHUTDOWNFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_Unintended_RdrConfig_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticInfo_WDGTSTFAIL_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_ABS_ESC_Diagmode_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_ABS_ESC_Diagmode_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_BAT_LOWFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_BAT_LOWFAULT_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_WDG_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_WDG_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560649_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560649_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561687_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561687_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562385_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562385_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562585_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562585_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Abs_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Abs_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Esc01_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Esc01_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Clu02_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Clu02_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x563886_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x563886_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565C87_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565C87_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x566086_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x566086_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568785_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568785_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B802_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B802_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574181_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574181_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574686_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574686_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586A87_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586A87_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586B87_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586B87_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x672146_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x672146_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_GND_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_GND_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560449_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560449_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560C87_TimeOut_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560C87_TimeOut_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_672246_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_672246_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A2397_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A2397_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A274B_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A274B_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_Rdr_NoTargetFound_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_Rdr_NoTargetFound_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_NoReception_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_NoReception_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_Unintended_RdrConfig_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_Unintended_RdrConfig_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_WDGTSTFAIL_GetEventStatus(P2VAR(Dem_UdsStatusByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) UDSStatusByte); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_DiagnosticMonitor_WDGTSTFAIL_SetEventStatus(Dem_EventStatusType EventStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_ABS_ESC_Diagmode_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_BAT_LOWFAULT_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_CYPRESSFLASHTESTFAIL_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC672146_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_AliveCntErr_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_BatFail_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_Init_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_CanCommFailure_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_EolAlign_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_HwFail_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_HwTempCondition_High_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_535F81_HCU_Enblsts_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_GND_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_OPEN_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_PRESSED_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_560449_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_560649_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_560A87_BUS_OFF_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_560C87_TimeOut_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_02_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_03_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_05_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_07_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_11_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561287_HTCU_04_10_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561287_TCU_01_10_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_EMS_02_10_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_AccelPdlVal_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_HEV_AccelPdVal_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_HEV_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561C86_HCU_03_10ms_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561C86_HCU_HevRdySta_Invld_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_561E87_ECAN_Busoff_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562387_SAS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Abs_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Esc01_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Whl01_Esc03_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Whl01_Esc03_SPLIT_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_2K_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_500_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_Clu02_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_01_AVH_Sta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_CylPrsrVal_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_WHL_01_10_ESC_03_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_Whl_01_ABS_ESC_01_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_HTCU_05_10ms_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_TCU_Alvcnt_Crc_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_TCU_GearSlctDis_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SWRCCrsMainSwSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SWRCLFASwSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SpdUnitTyp_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_Invalid_CLU_01_10ms_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_566987_IMU_01_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_CLU_PE_05_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_MON_GW_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_568787_MDPS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_MDPS_LkaPlgInSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_Mdps_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_Mdps_Invalid_Daw_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_56B902_ESC_FCA_AvlblSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_56B902_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_570246_Eng_TransmsmTyp_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_570246_NoVarErr_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_570255_MDPS_Type_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_574281_FCA_EquipSta_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_574281_SCC_OptTyp_Invalid_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583129_NaviInvSig_NSCC_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_HU_NAVIStatus_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_HU_NAVIStatus_30K_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_NAVI_ISLW_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_NaviInvSig_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_583D86_SAS_SWRC_LFASwSta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_LongAccelVal_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_584886_BCM_10_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_585087_MFSW_01_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_HDA_NAVI_Timeout_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_12K_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_60K_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_ADAS_MDPS_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_MDPS_ADAS_Actvsta_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_625387_BCM_08_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_625387_BCM_10_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_672246_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68AC87_LKA_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68AC87_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68B181_EMS_07_10ms_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68B181_RDR_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68B881_ESP_Rev_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68B981_ESP_Rev_Error_FCA_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_6A2397_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_6A274B_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_02_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_04_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_07_Noreception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_DTC_BAT_HIGHFAULT_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_NOCALIBRATIONFAULT_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_Rdr_NoTargetFound_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_SWRC_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_SWRC_NoReception_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_THERMALSHUTDOWNFAULT_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_Unintended_RdrConfig_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EventStatus_WDGTSTFAIL_SetWIRStatus(boolean WIRStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Fog(P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) FS_Fog); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) FS_Full_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) FS_Partial_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) FS_Sun_Ray); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData1_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData1_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData1_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData2_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData2_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData2_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData3_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData3_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData3_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData4_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData4_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData4_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData5_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData5_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDiag_RP_ReversibleFailureData5_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

FUNC(void, RTE_CODE) Rte_Enter_CpApDiag_ExclusiveArea_GetAppDiagFltStatus(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(void, RTE_CODE) Rte_Exit_CpApDiag_ExclusiveArea_GetAppDiagFltStatus(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

FUNC(void, RTE_CODE) Rte_Enter_CpApDiag_ExclusiveArea_SetAppDiagFaultStatus(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(void, RTE_CODE) Rte_Exit_CpApDiag_ExclusiveArea_SetAppDiagFaultStatus(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF
# define Rte_Read_RP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF
# define Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eng_EnableCANDtc_De_Eng_EnableCANDtc Rte_Read_CpApDiag_RP_Eng_EnableCANDtc_De_Eng_EnableCANDtc
# define Rte_Read_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF Rte_Read_CpApDiag_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF
# define Rte_Read_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eng_Power9v_De_Eng_Power9v Rte_Read_CpApDiag_RP_Eng_Power9v_De_Eng_Power9v
# define Rte_Read_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF
# define Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF Rte_Read_CpApDiag_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF
# define Rte_Read_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v
# define Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF
# define Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF
# define Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF
# define Rte_Read_RP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout Rte_Read_CpApDiag_RP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout
# define Rte_Read_RP_FcaWarnLampCond_De_FcaWarnLampCond Rte_Read_CpApDiag_RP_FcaWarnLampCond_De_FcaWarnLampCond
# define Rte_Read_RP_GetOdoVal_De_OdoVal Rte_Read_CpApDiag_RP_GetOdoVal_De_OdoVal
# define Rte_Read_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc Rte_Read_CpApDiag_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc
# define Rte_Read_RP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc Rte_Read_CpApDiag_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc
# define Rte_Read_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA Rte_Read_CpApDiag_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA
# define Rte_Read_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF
# define Rte_Read_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc Rte_Read_CpApDiag_RP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc
# define Rte_Read_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v Rte_Read_CpApDiag_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v
# define Rte_Read_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v Rte_Read_CpApDiag_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v
# define Rte_Read_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus Rte_Read_CpApDiag_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus
# define Rte_Read_RP_RadarDtcInfo_RadarDtcInfo Rte_Read_CpApDiag_RP_RadarDtcInfo_RadarDtcInfo
# define Rte_Read_RP_SccRdrBlockage_De_SccRdrBlockage Rte_Read_CpApDiag_RP_SccRdrBlockage_De_SccRdrBlockage
# define Rte_Read_RP_SccWarnLampCond_De_SccWarnLampCond Rte_Read_CpApDiag_RP_SccWarnLampCond_De_SccWarnLampCond


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo Rte_Write_CpApDiag_PP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo
# define Rte_Write_PP_DawFailInfo_De_DawFailInfo Rte_Write_CpApDiag_PP_DawFailInfo_De_DawFailInfo
# define Rte_Write_PP_FcaFailSafeInfo_De_FcaFailSafeInfo Rte_Write_CpApDiag_PP_FcaFailSafeInfo_De_FcaFailSafeInfo
# define Rte_Write_PP_HbaFailInfo_De_HbaFailInfo Rte_Write_CpApDiag_PP_HbaFailInfo_De_HbaFailInfo
# define Rte_Write_PP_IslwFailInfo_De_IslwFailInfo Rte_Write_CpApDiag_PP_IslwFailInfo_De_IslwFailInfo
# define Rte_Write_PP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo Rte_Write_CpApDiag_PP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo
# define Rte_Write_PP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo Rte_Write_CpApDiag_PP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo
# define Rte_Write_PP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo Rte_Write_CpApDiag_PP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_DiagnosticInfo_ABS_ESC_Diagmode_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_ABS_ESC_Diagmode_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_CYPRESSFLASHTESTFAIL_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_CYPRESSFLASHTESTFAIL_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_535F81_HCU_Enblsts_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_535F81_HCU_Enblsts_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_GND_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_GND_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_OPEN_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_OPEN_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_PRESSED_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_553211_LKA_PRESSED_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_560449_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560449_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_560649_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560649_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_560A87_BUS_OFF_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560A87_BUS_OFF_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_560C87_TimeOut_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_560C87_TimeOut_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_02_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_02_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_03_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_03_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_05_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_05_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_07_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_07_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_11_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561187_EMS_11_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561287_HTCU_04_10_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561287_HTCU_04_10_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561287_TCU_01_10_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561287_TCU_01_10_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_EMS_02_10_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_EMS_02_10_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_AccelPdVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_HEV_AccelPdVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_03_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561C86_HCU_03_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_HevRdySta_Invld_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561C86_HCU_HevRdySta_Invld_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_561E87_ECAN_Busoff_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_561E87_ECAN_Busoff_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562387_SAS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562387_SAS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562587_Abs_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Abs_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562587_Esc01_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Esc01_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562887_2K_CLU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_2K_CLU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562887_500_CLU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_500_CLU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_562887_Clu02_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_562887_Clu02_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_01_AVH_Sta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_01_AVH_Sta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_SCC_EnblReq_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_ESC_SCC_EnblReq_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564686_HTCU_05_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_HTCU_05_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_GearSlctDis_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_564686_TCU_GearSlctDis_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SpdUnitTyp_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_CLU_SpdUnitTyp_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_565686_Invalid_CLU_01_10ms_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_565686_Invalid_CLU_01_10ms_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_566987_IMU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_566987_IMU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_568787_MDPS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568787_MDPS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_Daw_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_Daw_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_570246_Eng_TransmsmTyp_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570246_Eng_TransmsmTyp_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_570246_NoVarErr_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570246_NoVarErr_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_570255_MDPS_Type_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_570255_MDPS_Type_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583129_NaviInvSig_NSCC_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583129_NaviInvSig_NSCC_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_30K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_30K_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583186_NAVI_ISLW_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_NAVI_ISLW_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583186_NaviInvSig_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583186_NaviInvSig_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_LongAccelVal_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584286_IMU_LongAccelVal_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_584886_BCM_10_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_584886_BCM_10_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_585087_MFSW_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_585087_MFSW_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_623986_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_623986_ADAS_MDPS_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_ADAS_MDPS_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_08_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_625387_BCM_08_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_10_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_625387_BCM_10_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_672246_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_672246_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68AC87_SWRC_03_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68AC87_SWRC_03_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68B181_EMS_07_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B181_EMS_07_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68B181_RDR_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B181_RDR_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68B881_ESP_Rev_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B881_ESP_Rev_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_6A2397_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_6A2397_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_6A274B_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_6A274B_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_02_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_02_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_04_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_04_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_07_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_B26A687_ICU_07_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_BAT_HIGHFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_BAT_HIGHFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_BAT_LOWFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_BAT_LOWFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_DTC_Rdr_BatFail_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_DTC_Rdr_BatFail_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_NOCALIBRATIONFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_NOCALIBRATIONFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Drv_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_Blockage_Drv_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Init_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_Blockage_Init_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_CanCommFailure_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_CanCommFailure_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_EolAlign_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_EolAlign_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_HwFail_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_HwFail_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_HwTempCondition_High_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_HwTempCondition_High_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Rdr_NoTargetFound_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Rdr_NoTargetFound_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_SWRC_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_SWRC_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_SWRC_NoReception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_SWRC_NoReception_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_THERMALSHUTDOWNFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_THERMALSHUTDOWNFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_Unintended_RdrConfig_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_Unintended_RdrConfig_GetEventStatus
# define Rte_Call_RP_DiagnosticInfo_WDGTSTFAIL_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticInfo_WDGTSTFAIL_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_ABS_ESC_Diagmode_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_ABS_ESC_Diagmode_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_BAT_LOWFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_BAT_LOWFAULT_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_WDG_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560449_WDG_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560649_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x560649_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561687_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561687_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562385_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562385_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562585_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562585_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Abs_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Abs_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Esc01_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Esc01_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Clu02_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Clu02_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x563886_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x563886_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565C87_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x565C87_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x566086_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x566086_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568785_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568785_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B802_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x56B802_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574181_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574181_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574686_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x574686_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586A87_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586A87_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586B87_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x586B87_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x672146_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_0x672146_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_GND_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_GND_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560449_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560449_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560449_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560449_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560C87_TimeOut_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_560C87_TimeOut_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_672246_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_672246_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_672246_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_672246_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A2397_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A2397_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A274B_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_6A274B_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_Rdr_NoTargetFound_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_Rdr_NoTargetFound_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_NoReception_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_SWRC_NoReception_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_Unintended_RdrConfig_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_Unintended_RdrConfig_SetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_GetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_WDGTSTFAIL_GetEventStatus
# define Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_SetEventStatus Rte_Call_CpApDiag_RP_DiagnosticMonitor_WDGTSTFAIL_SetEventStatus
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApDiag_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_EventStatus_ABS_ESC_Diagmode_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_ABS_ESC_Diagmode_SetWIRStatus
# define Rte_Call_RP_EventStatus_BAT_LOWFAULT_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_BAT_LOWFAULT_SetWIRStatus
# define Rte_Call_RP_EventStatus_CYPRESSFLASHTESTFAIL_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_CYPRESSFLASHTESTFAIL_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC672146_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC672146_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_AliveCntErr_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_AliveCntErr_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_BatFail_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_BatFail_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_Init_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_Init_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_CanCommFailure_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_CanCommFailure_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_EolAlign_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_EolAlign_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwFail_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_HwFail_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwTempCondition_High_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_0x56B081_Rdr_HwTempCondition_High_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_535F81_HCU_Enblsts_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_535F81_HCU_Enblsts_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_553211_LKA_GND_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_GND_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_553211_LKA_OPEN_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_OPEN_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_553211_LKA_PRESSED_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_553211_LKA_PRESSED_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_560449_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_560449_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_560649_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_560649_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_560A87_BUS_OFF_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_560A87_BUS_OFF_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_560C87_TimeOut_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_560C87_TimeOut_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_01_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_01_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_02_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_02_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_03_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_03_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_05_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_05_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_07_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_07_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561187_EMS_11_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561187_EMS_11_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561287_HTCU_04_10_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561287_HTCU_04_10_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561287_TCU_01_10_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561287_TCU_01_10_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_EMS_02_10_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_EMS_02_10_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_ENG_AccelPdlVal_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_AccelPdlVal_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_ENG_EngSpdErrSta_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_ENG_EngSpdErrSta_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_HEV_AccelPdVal_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_HEV_AccelPdVal_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561386_HEV_EngSpdErrSta_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561386_HEV_EngSpdErrSta_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561C86_HCU_03_10ms_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561C86_HCU_03_10ms_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561C86_HCU_HevRdySta_Invld_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561C86_HCU_HevRdySta_Invld_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_561E87_ECAN_Busoff_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_561E87_ECAN_Busoff_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562387_SAS_01_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562387_SAS_01_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562587_Abs_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Abs_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562587_Esc01_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Esc01_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Whl01_Esc03_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SPLIT_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562587_Whl01_Esc03_SPLIT_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562887_2K_CLU_01_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_2K_CLU_01_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562887_500_CLU_01_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_500_CLU_01_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_562887_Clu02_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_562887_Clu02_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_ESC_01_AVH_Sta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_01_AVH_Sta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_ESC_CylPrsrVal_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_CylPrsrVal_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_ESC_SCC_EnblReq_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_ESC_SCC_EnblReq_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_03_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_WHL_01_10_ESC_03_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564286_Whl_01_ABS_ESC_01_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564286_Whl_01_ABS_ESC_01_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564686_HTCU_05_10ms_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_HTCU_05_10ms_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564686_TCU_Alvcnt_Crc_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_TCU_Alvcnt_Crc_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_564686_TCU_GearSlctDis_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_564686_TCU_GearSlctDis_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCCrsMainSwSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SWRCCrsMainSwSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCLFASwSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SWRCLFASwSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_565686_CLU_SpdUnitTyp_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_CLU_SpdUnitTyp_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_565686_Invalid_CLU_01_10ms_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_565686_Invalid_CLU_01_10ms_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_566987_IMU_01_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_566987_IMU_01_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_567A87_HU_CLU_PE_05_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_CLU_PE_05_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_567A87_HU_MON_GW_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_MON_GW_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_568787_MDPS_01_10ms_Missing_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_568787_MDPS_01_10ms_Missing_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_568886_MDPS_LkaPlgInSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_MDPS_LkaPlgInSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_Mdps_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_Daw_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_568886_Mdps_Invalid_Daw_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_56B902_ESC_FCA_AvlblSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_56B902_ESC_FCA_AvlblSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_56B902_ESC_SCC_EnblReq_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_56B902_ESC_SCC_EnblReq_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_570246_Eng_TransmsmTyp_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_570246_Eng_TransmsmTyp_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_570246_NoVarErr_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_570246_NoVarErr_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_570255_MDPS_Type_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_570255_MDPS_Type_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_574281_FCA_EquipSta_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_574281_FCA_EquipSta_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_574281_SCC_OptTyp_Invalid_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_574281_SCC_OptTyp_Invalid_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583129_NaviInvSig_NSCC_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583129_NaviInvSig_NSCC_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_HU_NAVIStatus_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_30K_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_HU_NAVIStatus_30K_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583186_NAVI_ISLW_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_NAVI_ISLW_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583186_NaviInvSig_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583186_NaviInvSig_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_LFASwSta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_583D86_SAS_SWRC_LFASwSta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_584286_IMU_LongAccelVal_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_584286_IMU_LongAccelVal_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_584886_BCM_10_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_584886_BCM_10_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_585087_MFSW_01_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_585087_MFSW_01_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_586387_HDA_NAVI_Timeout_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_HDA_NAVI_Timeout_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_12K_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_12K_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_60K_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_60K_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_623986_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_623986_ADAS_MDPS_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_ADAS_MDPS_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_Actvsta_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_623986_MDPS_ADAS_Actvsta_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_625387_BCM_08_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_625387_BCM_08_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_625387_BCM_10_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_625387_BCM_10_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_672246_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_672246_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68AC87_LKA_SWRC_03_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68AC87_LKA_SWRC_03_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68AC87_SWRC_03_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68AC87_SWRC_03_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68B181_EMS_07_10ms_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68B181_EMS_07_10ms_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68B181_RDR_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68B181_RDR_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68B881_ESP_Rev_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68B881_ESP_Rev_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68B981_ESP_Rev_Error_FCA_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68B981_ESP_Rev_Error_FCA_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_6A2397_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_6A2397_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_6A274B_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_6A274B_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_B26A687_ICU_02_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_02_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_B26A687_ICU_04_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_04_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_B26A687_ICU_07_Noreception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_B26A687_ICU_07_Noreception_SetWIRStatus
# define Rte_Call_RP_EventStatus_DTC_BAT_HIGHFAULT_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_DTC_BAT_HIGHFAULT_SetWIRStatus
# define Rte_Call_RP_EventStatus_NOCALIBRATIONFAULT_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_NOCALIBRATIONFAULT_SetWIRStatus
# define Rte_Call_RP_EventStatus_Rdr_NoTargetFound_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_Rdr_NoTargetFound_SetWIRStatus
# define Rte_Call_RP_EventStatus_SWRC_Alv_Crc_Error_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_SWRC_Alv_Crc_Error_SetWIRStatus
# define Rte_Call_RP_EventStatus_SWRC_NoReception_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_SWRC_NoReception_SetWIRStatus
# define Rte_Call_RP_EventStatus_THERMALSHUTDOWNFAULT_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_THERMALSHUTDOWNFAULT_SetWIRStatus
# define Rte_Call_RP_EventStatus_Unintended_RdrConfig_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_Unintended_RdrConfig_SetWIRStatus
# define Rte_Call_RP_EventStatus_WDGTSTFAIL_SetWIRStatus Rte_Call_CpApDiag_RP_EventStatus_WDGTSTFAIL_SetWIRStatus
# define Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Fog Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Fog
# define Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage
# define Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage
# define Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray Rte_Call_CpApDiag_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray
# define Rte_Call_RP_ReversibleFailureData1_GetErrorStatus Rte_Call_CpApDiag_RP_ReversibleFailureData1_GetErrorStatus
# define Rte_Call_RP_ReversibleFailureData1_ReadBlock Rte_Call_CpApDiag_RP_ReversibleFailureData1_ReadBlock
# define Rte_Call_RP_ReversibleFailureData1_WriteBlock Rte_Call_CpApDiag_RP_ReversibleFailureData1_WriteBlock
# define Rte_Call_RP_ReversibleFailureData2_GetErrorStatus Rte_Call_CpApDiag_RP_ReversibleFailureData2_GetErrorStatus
# define Rte_Call_RP_ReversibleFailureData2_ReadBlock Rte_Call_CpApDiag_RP_ReversibleFailureData2_ReadBlock
# define Rte_Call_RP_ReversibleFailureData2_WriteBlock Rte_Call_CpApDiag_RP_ReversibleFailureData2_WriteBlock
# define Rte_Call_RP_ReversibleFailureData3_GetErrorStatus Rte_Call_CpApDiag_RP_ReversibleFailureData3_GetErrorStatus
# define Rte_Call_RP_ReversibleFailureData3_ReadBlock Rte_Call_CpApDiag_RP_ReversibleFailureData3_ReadBlock
# define Rte_Call_RP_ReversibleFailureData3_WriteBlock Rte_Call_CpApDiag_RP_ReversibleFailureData3_WriteBlock
# define Rte_Call_RP_ReversibleFailureData4_GetErrorStatus Rte_Call_CpApDiag_RP_ReversibleFailureData4_GetErrorStatus
# define Rte_Call_RP_ReversibleFailureData4_ReadBlock Rte_Call_CpApDiag_RP_ReversibleFailureData4_ReadBlock
# define Rte_Call_RP_ReversibleFailureData4_WriteBlock Rte_Call_CpApDiag_RP_ReversibleFailureData4_WriteBlock
# define Rte_Call_RP_ReversibleFailureData5_GetErrorStatus Rte_Call_CpApDiag_RP_ReversibleFailureData5_GetErrorStatus
# define Rte_Call_RP_ReversibleFailureData5_ReadBlock Rte_Call_CpApDiag_RP_ReversibleFailureData5_ReadBlock
# define Rte_Call_RP_ReversibleFailureData5_WriteBlock Rte_Call_CpApDiag_RP_ReversibleFailureData5_WriteBlock


/**********************************************************************************************************************
 * Exclusive Areas
 *********************************************************************************************************************/

# define Rte_Enter_ExclusiveArea_GetAppDiagFltStatus Rte_Enter_CpApDiag_ExclusiveArea_GetAppDiagFltStatus /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */
# define Rte_Exit_ExclusiveArea_GetAppDiagFltStatus Rte_Exit_CpApDiag_ExclusiveArea_GetAppDiagFltStatus /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */

# define Rte_Enter_ExclusiveArea_SetAppDiagFaultStatus Rte_Enter_CpApDiag_ExclusiveArea_SetAppDiagFaultStatus /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */
# define Rte_Exit_ExclusiveArea_SetAppDiagFaultStatus Rte_Exit_CpApDiag_ExclusiveArea_SetAppDiagFaultStatus /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_NvBlockNeed_ReversibleFailureData_1_MirrorBlock() (Rte_Inst_CpApDiag->Pim_NvBlockNeed_ReversibleFailureData_1_MirrorBlock) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_ReversibleFailureData_2_MirrorBlock() (Rte_Inst_CpApDiag->Pim_NvBlockNeed_ReversibleFailureData_2_MirrorBlock) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_ReversibleFailureData_3_MirrorBlock() (Rte_Inst_CpApDiag->Pim_NvBlockNeed_ReversibleFailureData_3_MirrorBlock) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_ReversibleFailureData_4_MirrorBlock() (Rte_Inst_CpApDiag->Pim_NvBlockNeed_ReversibleFailureData_4_MirrorBlock) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NvBlockNeed_ReversibleFailureData_5_MirrorBlock() (Rte_Inst_CpApDiag->Pim_NvBlockNeed_ReversibleFailureData_5_MirrorBlock) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_1_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_2_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_3_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_4_MirrorBlock(void)
 *   ReversibleFailreDataType_t *Rte_Pim_NvBlockNeed_ReversibleFailureData_5_MirrorBlock(void)
 *
 *********************************************************************************************************************/


# define CpApDiag_START_SEC_CODE
# include "CpApDiag_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_ControlDTCSetting
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ControlDTCSetting> of PortPrototype <PP_ControlDTCSetting>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_Re_ControlDTCSetting(uint8 DTCCantrolData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_ControlDTCSetting_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_ControlDTCSetting Os_Call_Re_ControlDTCSetting
FUNC(Std_ReturnType, CpApDiag_CODE) Os_Call_Re_ControlDTCSetting(uint8 DTCCantrolData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDiagInit Re_CpApDiagInit
FUNC(void, CpApDiag_CODE) Re_CpApDiagInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_De_Eng_Power9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(FcaFailSafeInfoTrailerMsgTout_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaWarnLampCond_De_FcaWarnLampCond(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_GetOdoVal_De_OdoVal(COM_DT_CLU_OdoVal *data)
 *   Std_ReturnType Rte_Read_RP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_RadarDtcInfo_RadarDtcInfo(RadarDtcInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_SccRdrBlockage_De_SccRdrBlockage(SccRdrBlockage_t *data)
 *   Std_ReturnType Rte_Read_RP_SccWarnLampCond_De_SccWarnLampCond(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo(const CoFcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_DawFailInfo_De_DawFailInfo(const DawFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaFailSafeInfo_De_FcaFailSafeInfo(const FcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaFailInfo_De_HbaFailInfo(const HbaFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwFailInfo_De_IslwFailInfo(const IslwFailInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(const LssCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccCanSigFailSafeInfo_De_SccCanSigFailSafeInfo(const SccCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccRdrSigFailSafeInfo_De_SccRdrSigFailSafeInfo(const SccRdrSigFailSafeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_ABS_ESC_Diagmode_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_CYPRESSFLASHTESTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_535F81_HCU_Enblsts_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_GND_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_OPEN_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_553211_LKA_PRESSED_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560449_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560649_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560A87_BUS_OFF_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_560C87_TimeOut_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561287_HTCU_04_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561287_TCU_01_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_EMS_02_10_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_AccelPdVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561C86_HCU_HevRdySta_Invld_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_561E87_ECAN_Busoff_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562387_SAS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Abs_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Esc01_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_500_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_562887_Clu02_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_564686_TCU_GearSlctDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_565686_Invalid_CLU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_566987_IMU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568787_MDPS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570246_Eng_TransmsmTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570246_NoVarErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_570255_MDPS_Type_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583129_NaviInvSig_NSCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_NAVI_ISLW_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583186_NaviInvSig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584286_IMU_LongAccelVal_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_584886_BCM_10_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_585087_MFSW_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_ADAS_MDPS_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_08_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_625387_BCM_10_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_672246_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B181_RDR_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B881_ESP_Rev_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_6A2397_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_6A274B_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_02_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_04_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_B26A687_ICU_07_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_BAT_HIGHFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_BAT_LOWFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_DTC_Rdr_BatFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_NOCALIBRATIONFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Drv_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_Blockage_Init_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_CanCommFailure_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_HwFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_HwTempCondition_High_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Rdr_NoTargetFound_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_SWRC_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_SWRC_NoReception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_THERMALSHUTDOWNFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_Unintended_RdrConfig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticInfo_WDGTSTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticInfo_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_ABS_ESC_Diagmode_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_BAT_LOWFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_CYPRESSFLASHTESTFAIL_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_EXTFLASHFAILURE_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_ThermalShutdown_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560449_WDG_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x560649_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_HTCU_04_10_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561287_TCU_01_10_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561386_HEV_AccelPdVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561687_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x561C86_HCU_HevRdySta_Invalid_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_DrvAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562078_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562385_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562387_SAS_01_10ms_Missing_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562585_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Abs_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Esc01_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562587_Whl01_Esc03_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Clu02_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_HuMonPe_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x562887_Swrc03_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x563886_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_HCU_SCC_Enbl_Sta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x564686_TCU_GearSlctDis_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565686_Invalid_CLU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x565C87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x566086_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x567286_SAS_Invalid_LFA_HDA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568785_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x568787_MDPS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_AliveCntErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_BatFail_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Drv_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_Blockage_Init_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_CanCommFailure_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_EolAlign_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwFail_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B081_Rdr_HwTempCondition_High_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x56B802_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_Eng_TransmsmTyp_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x570246_NoVarErr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574181_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x574686_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287ICU_04_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x581287_ICU_02_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_NaviInvSig_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x583186_PosV2CyclicCntr_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_10_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584787_BCM_8_200_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_CLU_PE_05_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_Navi_ISLW_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x584987_HU_XX_PE_01_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586A87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x586B87_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_0x672146_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_535F81_HCU_Enblsts_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_GND_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_OPEN_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_553211_LKA_PRESSED_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560449_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560449_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560A87_BUS_OFF_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_560C87_TimeOut_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_01_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_02_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_05_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_07_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561187_EMS_11_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_EMS_02_10_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AccelPdlVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_ENG_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561386_HEV_EngSpdErrSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561C86_HCU_03_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_561E87_ECAN_Busoff_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562587_Whl01_Esc03_SPLIT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_2K_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_562887_500_CLU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_01_AVH_Sta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_CylPrsrVal_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_WHL_01_10_ESC_03_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564286_Whl_01_ABS_ESC_01_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_HTCU_05_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_Alvcnt_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_564686_TCU_GearSlctrDis_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCCrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SWRCLFASwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_CLU_SpdUnitTyp_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_565686_Invalid_TCU_01_10ms_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_566987_IMU_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_CLU_PE_05_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_MON_GW_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_MDPS_LkaPlgInSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_568886_Mdps_Invalid_Daw_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_FCA_AvlblSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_56B902_ESC_SCC_EnblReq_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_570255_MDPS_Type_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_FCA_EquipSta_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_574281_SCC_OptTyp_Invalid_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583129_NaviInvSig_NSCC_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_HU_NAVIStatus_30K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583186_NAVI_ISLW_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_583D86_SAS_SWRC_LFASwSta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584286_IMU_LongAccelVal_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_584886_BCM_10_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_585087_MFSW_01_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_12K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_586387_NAVIPOSPETIMEOUT_60K_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_ADAS_MDPS_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_623986_MDPS_ADAS_Actvsta_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_08_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_625387_BCM_10_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_672246_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_672246_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_LKA_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68AC87_SWRC_03_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_EMS_07_10ms_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B181_RDR_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B881_ESP_Rev_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68B981_ESP_Rev_Error_FCA_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A2397_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_6A274B_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_02_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_04_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_B26A687_ICU_07_Noreception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_DTC_BAT_HIGHFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_NOCALIBRATIONFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Rdr_NoTargetFound_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_Alv_Crc_Error_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_SWRC_NoReception_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_THERMALSHUTDOWNFAULT_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_Unintended_RdrConfig_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_GetEventStatus(Dem_UdsStatusByteType *UDSStatusByte)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_DiagnosticMonitor_WDGTSTFAIL_SetEventStatus(Dem_EventStatusType EventStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DiagnosticMonitor_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_ABS_ESC_Diagmode_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_BAT_LOWFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_CYPRESSFLASHTESTFAIL_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC672146_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_AliveCntErr_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_BatFail_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_Blockage_Drv_Init_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_CanCommFailure_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_EolAlign_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwFail_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_0x56B081_Rdr_HwTempCondition_High_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_535F81_HCU_Enblsts_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_GND_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_OPEN_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_553211_LKA_PRESSED_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560449_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560649_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560A87_BUS_OFF_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_560C87_TimeOut_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_02_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_03_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_05_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_07_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561187_EMS_11_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561287_HTCU_04_10_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561287_TCU_01_10_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_EMS_02_10_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_AccelPdlVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_AppAccelPdlSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_ENG_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_HEV_AccelPdVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561386_HEV_EngSpdErrSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561487_HCU_03_10ms_Missing_FCASCC_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561C86_HCU_03_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561C86_HCU_HevRdySta_Invld_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_561E87_ECAN_Busoff_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562387_SAS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Abs_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Esc01_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562587_Whl01_Esc03_SPLIT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_2K_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_500_CLU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_562887_Clu02_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_01_AVH_Sta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_03_FCA_Avlbl_PermNA_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_CylPrsrVal_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_01_03_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_WHL_01_10_ESC_03_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564286_Whl_01_ABS_ESC_01_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_HTCU_05_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_TCU_Alvcnt_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_564686_TCU_GearSlctDis_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCCrsMainSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SWRCLFASwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_CLU_SpdUnitTyp_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_565686_Invalid_CLU_01_10ms_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_566987_IMU_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_CLU_PE_05_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_GW_CLU_NAVI_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_MON_GW_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_567A87_HU_Navi_ISLW_PE_00_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568787_MDPS_01_10ms_Missing_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_MDPS_LkaPlgInSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_568886_Mdps_Invalid_Daw_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_56B902_ESC_FCA_AvlblSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_56B902_ESC_SCC_EnblReq_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570246_Eng_TransmsmTyp_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570246_NoVarErr_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_570255_MDPS_Type_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_574281_FCA_EquipSta_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_574281_SCC_OptTyp_Invalid_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_581486_SAS_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583129_NaviInvSig_NSCC_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_HU_NAVIStatus_30K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_NAVI_ISLW_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583186_NaviInvSig_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583C86_ICU_02_Warn_DrvDrSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_CrsMainSwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_583D86_SAS_SWRC_LFASwSta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_01_Alv_Crc_Error_Redundant_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584286_IMU_LongAccelVal_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_584886_BCM_10_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_585087_MFSW_01_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_HDA_NAVI_Timeout_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_12K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_586387_NAVIPOSPETIMEOUT_60K_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_ADAS_MDPS_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_623986_MDPS_ADAS_Actvsta_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_625387_BCM_08_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_625387_BCM_10_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_672246_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68AC87_LKA_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68AC87_SWRC_03_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B181_EMS_07_10ms_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B181_RDR_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B881_ESP_Rev_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68B981_ESP_Rev_Error_FCA_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_68C586_MDPS_ADAS_AciFltSig_Lv2_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_6A2397_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_6A274B_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_02_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_04_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_B26A687_ICU_07_Noreception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_DTC_BAT_HIGHFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_NOCALIBRATIONFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_Rdr_NoTargetFound_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_SWRC_Alv_Crc_Error_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_SWRC_NoReception_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_THERMALSHUTDOWNFAULT_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_Unintended_RdrConfig_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_EventStatus_WDGTSTFAIL_SetWIRStatus(boolean WIRStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_EventStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData1_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData2_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData3_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData4_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_ReversibleFailureData5_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC2_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDiagMain Re_CpApDiagMain
FUNC(void, CpApDiag_CODE) Re_CpApDiagMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDiagOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDiagOut Re_CpApDiagOut
FUNC(void, CpApDiag_CODE) Re_CpApDiagOut(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApplClearDTC
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ApplClearDTC> of PortPrototype <PP_ApplClearDTC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_Re_CpApplClearDTC(void)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApplClearDTC Os_Call_Re_CpApplClearDTC
FUNC(void, CpApDiag_CODE) Os_Call_Re_CpApplClearDTC(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data20ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApDiag_CODE) Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApDiag_CODE) Re_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data20ByteType, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_GetAppDiagFltStatus
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <GetAppDiagFltStatus> of PortPrototype <PP_AppDiagFaultStatus>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_GetAppDiagFltStatus(void)
 *   void Rte_Exit_ExclusiveArea_GetAppDiagFltStatus(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_GetAppDiagFltStatus Re_GetAppDiagFltStatus
FUNC(Std_ReturnType, CpApDiag_CODE) Re_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPDIAG_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SetAppDiagFaultStatus
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <SetAppDiagFltStatus> of PortPrototype <PP_AppDiagFaultStatus>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_SetAppDiagFaultStatus(void)
 *   void Rte_Exit_ExclusiveArea_SetAppDiagFaultStatus(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Os_Call_Re_SetAppDiagFaultStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SetAppDiagFaultStatus Os_Call_Re_SetAppDiagFaultStatus
FUNC(Std_ReturnType, CpApDiag_CODE) Os_Call_Re_SetAppDiagFaultStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApDiag_STOP_SEC_CODE
# include "CpApDiag_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_Data_By_Identifier_ReversibleFailureData_0xEFFF_Read_E_NOT_OK (1U)

# define RTE_E_DiagnosticInfo_E_NOT_OK (1U)

# define RTE_E_DiagnosticMonitor_E_NOT_OK (1U)

# define RTE_E_EventStatus_E_NOT_OK (1U)

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_ControlDTCSetting_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore1_FLSF_ReturnType (1U)

# define RTE_E_NvMService_AC2_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPDIAG_H */
