/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApFcaIntf.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApFcaIntf
 *  Generation Time:  2023-04-20 13:52:30
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApFcaIntf> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPFCAINTF_H
# define _RTE_CPAPFCAINTF_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApFcaIntf_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApFcaIntf
{
  /* PIM Handles section */
  P2VAR(FcaNvmSaveVal_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_FcaFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApFcaIntf, RTE_CONST, RTE_CONST) Rte_Inst_CpApFcaIntf; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApFcaIntf, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFcaIntf_RP_NvMService_FcaFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFcaIntf_RP_NvMService_FcaFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_NvMService_FcaFrqNvData_ReadBlock Rte_Call_CpApFcaIntf_RP_NvMService_FcaFrqNvData_ReadBlock
# define Rte_Call_RP_NvMService_FcaFrqNvData_WriteBlock Rte_Call_CpApFcaIntf_RP_NvMService_FcaFrqNvData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_FcaFrqNvData() (Rte_Inst_CpApFcaIntf->Pim_FcaFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   FcaNvmSaveVal_t *Rte_Pim_FcaFrqNvData(void)
 *
 *********************************************************************************************************************/


# define CpApFcaIntf_START_SEC_CODE
# include "CpApFcaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApFcaIntf_NvMNotifyJobFinished_FcaFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_FcaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Os_Call_CpApFcaIntf_NvMNotifyJobFinished_FcaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApFcaIntf_NvMNotifyJobFinished_FcaFrqNvData_JobFinished Os_Call_CpApFcaIntf_NvMNotifyJobFinished_FcaFrqNvData_JobFinished
FUNC(void, CpApFcaIntf_CODE) Os_Call_CpApFcaIntf_NvMNotifyJobFinished_FcaFrqNvData_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFcaIntfInit Re_CpApFcaIntfInit
FUNC(void, CpApFcaIntf_CODE) Re_CpApFcaIntfInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_FcaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_FcaFrqNvData_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFcaIntfMain Re_CpApFcaIntfMain
FUNC(void, CpApFcaIntf_CODE) Re_CpApFcaIntfMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FcaFrqNvDataRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <FcaFrqNvDataRead> of PortPrototype <PP_FcaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_FcaFrqNvDataRead(FcaNvmSaveVal_t *FcaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FcaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_FcaFrqNvDataRead Re_FcaFrqNvDataRead
FUNC(Std_ReturnType, CpApFcaIntf_CODE) Re_FcaFrqNvDataRead(P2VAR(FcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPFCAINTF_APPL_VAR) FcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FcaFrqNvDataWrite
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <FcaFrqNvDataWrite> of PortPrototype <PP_FcaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_FcaFrqNvDataWrite(const FcaNvmSaveVal_t *FcaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FcaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_FcaFrqNvDataWrite Re_FcaFrqNvDataWrite
FUNC(Std_ReturnType, CpApFcaIntf_CODE) Re_FcaFrqNvDataWrite(P2CONST(FcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPFCAINTF_APPL_DATA) FcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApFcaIntf_STOP_SEC_CODE
# include "CpApFcaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_FcaFrqNvData_ReturnType (1U)

# define RTE_E_NvMService_AC3_SRBS_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPFCAINTF_H */
