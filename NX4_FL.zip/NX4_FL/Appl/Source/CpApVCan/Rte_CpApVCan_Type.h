/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApVCan_Type.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApVCan
 *  Generation Time:  2023-04-20 13:52:55
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application types header file for SW-C <CpApVCan> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPVCAN_TYPE_H
# define _RTE_CPAPVCAN_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"

/**********************************************************************************************************************
 * Range, Invalidation, Enumeration and Bit Field Definitions
 *********************************************************************************************************************/

# ifndef Cx0_ABS_control_inactive
#  define Cx0_ABS_control_inactive (0U)
# endif

# ifndef Cx1_ABS_control_active
#  define Cx1_ABS_control_active (1U)
# endif

# ifndef Cx2_Not_used
#  define Cx2_Not_used (2U)
# endif

# ifndef Cx3_Error_Indicator
#  define Cx3_Error_Indicator (3U)
# endif

# ifndef Cx0_ABS_is_not_defective
#  define Cx0_ABS_is_not_defective (0U)
# endif

# ifndef Cx1_ABS_is_defective
#  define Cx1_ABS_is_defective (1U)
# endif

# ifndef Cx0_ABS_Warning_lamp_OFF
#  define Cx0_ABS_Warning_lamp_OFF (0U)
# endif

# ifndef Cx1_ABS_Warning_lamp_ON
#  define Cx1_ABS_Warning_lamp_ON (1U)
# endif

# ifndef Cx0_Not_request
#  define Cx0_Not_request (0U)
# endif

# ifndef Cx1_Door_unlock_request
#  define Cx1_Door_unlock_request (1U)
# endif

# ifndef Cx2_RESERVED
#  define Cx2_RESERVED (2U)
# endif

# ifndef Cx3_RESERVED
#  define Cx3_RESERVED (3U)
# endif

# ifndef Cx0_Default
#  define Cx0_Default (0U)
# endif

# ifndef Cx1_Inhibit_off_in_regulationCluster
#  define Cx1_Inhibit_off_in_regulationCluster (1U)
# endif

# ifndef Cx2_Inhibit_off_in_regulationHUNIT
#  define Cx2_Inhibit_off_in_regulationHUNIT (2U)
# endif

# ifndef Cx3_Inhibit_off_in_HDP
#  define Cx3_Inhibit_off_in_HDP (3U)
# endif

# ifndef Cx4_Reserved
#  define Cx4_Reserved (4U)
# endif

# ifndef Cx5_Reserved
#  define Cx5_Reserved (5U)
# endif

# ifndef Cx6_Reserved
#  define Cx6_Reserved (6U)
# endif

# ifndef Cx7_Invalid
#  define Cx7_Invalid (7U)
# endif

# ifndef Cx0_Normal
#  define Cx0_Normal (0U)
# endif

# ifndef Cx1_Auto_Off_by_Trailer_connected
#  define Cx1_Auto_Off_by_Trailer_connected (1U)
# endif

# ifndef Cx2_Reserved
#  define Cx2_Reserved (2U)
# endif

# ifndef Cx3_Reserved
#  define Cx3_Reserved (3U)
# endif

# ifndef Cx0_De_activate_TOI
#  define Cx0_De_activate_TOI (0U)
# endif

# ifndef Cx1_Activate_TOI
#  define Cx1_Activate_TOI (1U)
# endif

# ifndef Cx3_Error_indicator
#  define Cx3_Error_indicator (3U)
# endif

# ifndef Cx0_No_Fault
#  define Cx0_No_Fault (0U)
# endif

# ifndef Cx1_Fault
#  define Cx1_Fault (1U)
# endif

# ifndef Cx3_Error_indicatorr
#  define Cx3_Error_indicatorr (3U)
# endif

# ifndef Cx0_Lamp_On
#  define Cx0_Lamp_On (0U)
# endif

# ifndef Cx1_Lamp_Off
#  define Cx1_Lamp_Off (1U)
# endif

# ifndef Cx0_AVH_Off_Lamp_Status
#  define Cx0_AVH_Off_Lamp_Status (0U)
# endif

# ifndef Cx1_AVH_failure_Lamp_Status
#  define Cx1_AVH_failure_Lamp_Status (1U)
# endif

# ifndef Cx2_AVH_ACTIVE_Lamp_Status
#  define Cx2_AVH_ACTIVE_Lamp_Status (2U)
# endif

# ifndef Cx3_AVH_READY_Lamp_Status
#  define Cx3_AVH_READY_Lamp_Status (3U)
# endif

# ifndef Cx4_Lamp_Status
#  define Cx4_Lamp_Status (4U)
# endif

# ifndef Cx5_Lamp_Status
#  define Cx5_Lamp_Status (5U)
# endif

# ifndef Cx6_Lamp_Status
#  define Cx6_Lamp_Status (6U)
# endif

# ifndef Cx0_Init
#  define Cx0_Init (0U)
# endif

# ifndef Cx1_No_Input
#  define Cx1_No_Input (1U)
# endif

# ifndef Cx2_Cancel_Input
#  define Cx2_Cancel_Input (2U)
# endif

# ifndef Cx3_Invalid
#  define Cx3_Invalid (3U)
# endif

# ifndef Cx0_Impossible_to_display
#  define Cx0_Impossible_to_display (0U)
# endif

# ifndef Cx1_Possible_to_display
#  define Cx1_Possible_to_display (1U)
# endif

# ifndef CxFFFF_Error
#  define CxFFFF_Error (65535U)
# endif

# ifndef Cx0_Passive
#  define Cx0_Passive (0U)
# endif

# ifndef Cx1_Clutch_off
#  define Cx1_Clutch_off (1U)
# endif

# ifndef Cx2_Torque_limit
#  define Cx2_Torque_limit (2U)
# endif

# ifndef Cx3_Error
#  define Cx3_Error (3U)
# endif

# ifndef Cx0_No_request_from_ESC
#  define Cx0_No_request_from_ESC (0U)
# endif

# ifndef Cx1_Request_duty_limit_from_ESC
#  define Cx1_Request_duty_limit_from_ESC (1U)
# endif

# ifndef Cx0_Maximum_limitation_mode
#  define Cx0_Maximum_limitation_mode (0U)
# endif

# ifndef Cx1_Minimum_limitation_mode
#  define Cx1_Minimum_limitation_mode (1U)
# endif

# ifndef Cx0_Before_Delivery_Welcome_Off_
#  define Cx0_Before_Delivery_Welcome_Off_ (0U)
# endif

# ifndef Cx1_After_Delivery_Welcome_On_
#  define Cx1_After_Delivery_Welcome_On_ (1U)
# endif

# ifndef Cx2_Not_Used
#  define Cx2_Not_Used (2U)
# endif

# ifndef Cx0_No_Warning
#  define Cx0_No_Warning (0U)
# endif

# ifndef Cx1_Left_Warning
#  define Cx1_Left_Warning (1U)
# endif

# ifndef Cx2_Right_Warning
#  define Cx2_Right_Warning (2U)
# endif

# ifndef Cx3_Left_Control
#  define Cx3_Left_Control (3U)
# endif

# ifndef Cx4_Right_Control
#  define Cx4_Right_Control (4U)
# endif

# ifndef Cx6_Not_used
#  define Cx6_Not_used (6U)
# endif

# ifndef Cx7_Error_indicator
#  define Cx7_Error_indicator (7U)
# endif

# ifndef Cx0_Off
#  define Cx0_Off (0U)
# endif

# ifndef Cx1_P
#  define Cx1_P (1U)
# endif

# ifndef Cx0_Close
#  define Cx0_Close (0U)
# endif

# ifndef Cx1_Open
#  define Cx1_Open (1U)
# endif

# ifndef Cx1_Off
#  define Cx1_Off (1U)
# endif

# ifndef Cx2_On
#  define Cx2_On (2U)
# endif

# ifndef Cx0_SSC_OFF_Normal_
#  define Cx0_SSC_OFF_Normal_ (0U)
# endif

# ifndef Cx1_SSC_ON
#  define Cx1_SSC_ON (1U)
# endif

# ifndef Cx3_Failure_Detected
#  define Cx3_Failure_Detected (3U)
# endif

# ifndef Cx0_No_strategy_Normal_Drive_
#  define Cx0_No_strategy_Normal_Drive_ (0U)
# endif

# ifndef Cx1_IDC_strategy
#  define Cx1_IDC_strategy (1U)
# endif

# ifndef Cx2_SSC_strategy
#  define Cx2_SSC_strategy (2U)
# endif

# ifndef Cx1_Fault_operation
#  define Cx1_Fault_operation (1U)
# endif

# ifndef Cx2_TimeOut
#  define Cx2_TimeOut (2U)
# endif

# ifndef Cx1_ResetReq
#  define Cx1_ResetReq (1U)
# endif

# ifndef Cx1FF_Error
#  define Cx1FF_Error (511U)
# endif

# ifndef Cx0_Detent_Off
#  define Cx0_Detent_Off (0U)
# endif

# ifndef Cx1_Detent_On
#  define Cx1_Detent_On (1U)
# endif

# ifndef Cx1_Yes
#  define Cx1_Yes (1U)
# endif

# ifndef Cx2_No
#  define Cx2_No (2U)
# endif

# ifndef Cx1_Reset_Request
#  define Cx1_Reset_Request (1U)
# endif

# ifndef Cx1_On
#  define Cx1_On (1U)
# endif

# ifndef Cx0_Low_fuel_Warning_is_off
#  define Cx0_Low_fuel_Warning_is_off (0U)
# endif

# ifndef Cx1_Low_fuel_Warning_is_on
#  define Cx1_Low_fuel_Warning_is_on (1U)
# endif

# ifndef Cx1_Key_On
#  define Cx1_Key_On (1U)
# endif

# ifndef Cx0_Non_refuel_detected
#  define Cx0_Non_refuel_detected (0U)
# endif

# ifndef Cx1_Refuel_detected
#  define Cx1_Refuel_detected (1U)
# endif

# ifndef Cx0_Refuel_Popup_is_off
#  define Cx0_Refuel_Popup_is_off (0U)
# endif

# ifndef Cx1_Refuel_Popup_is_on
#  define Cx1_Refuel_Popup_is_on (1U)
# endif

# ifndef Cx00_Reserved
#  define Cx00_Reserved (0U)
# endif

# ifndef Cx01_Step_1
#  define Cx01_Step_1 (1U)
# endif

# ifndef Cx02_Step_2
#  define Cx02_Step_2 (2U)
# endif

# ifndef Cx03_Step_3
#  define Cx03_Step_3 (3U)
# endif

# ifndef Cx04_Step_4
#  define Cx04_Step_4 (4U)
# endif

# ifndef Cx05_Step_5
#  define Cx05_Step_5 (5U)
# endif

# ifndef Cx06_Step_6
#  define Cx06_Step_6 (6U)
# endif

# ifndef Cx07_Step_7
#  define Cx07_Step_7 (7U)
# endif

# ifndef Cx08_Step_8
#  define Cx08_Step_8 (8U)
# endif

# ifndef Cx09_Step_9
#  define Cx09_Step_9 (9U)
# endif

# ifndef Cx0A_Step_10
#  define Cx0A_Step_10 (10U)
# endif

# ifndef Cx0B_Step_11
#  define Cx0B_Step_11 (11U)
# endif

# ifndef Cx0C_Step_12
#  define Cx0C_Step_12 (12U)
# endif

# ifndef Cx0D_Step_13
#  define Cx0D_Step_13 (13U)
# endif

# ifndef Cx0E_Step_14
#  define Cx0E_Step_14 (14U)
# endif

# ifndef Cx0F_Step_15
#  define Cx0F_Step_15 (15U)
# endif

# ifndef Cx10_Step_16
#  define Cx10_Step_16 (16U)
# endif

# ifndef Cx11_Step_17
#  define Cx11_Step_17 (17U)
# endif

# ifndef Cx12_Step_18
#  define Cx12_Step_18 (18U)
# endif

# ifndef Cx13_Step_19
#  define Cx13_Step_19 (19U)
# endif

# ifndef Cx14_Step_20_Reset_Value_
#  define Cx14_Step_20_Reset_Value_ (20U)
# endif

# ifndef Cx15_Step_21_Detent_
#  define Cx15_Step_21_Detent_ (21U)
# endif

# ifndef Cx0_Lamp_OFF
#  define Cx0_Lamp_OFF (0U)
# endif

# ifndef Cx1_Lamp_On
#  define Cx1_Lamp_On (1U)
# endif

# ifndef Cx2_Lamp_Flashing
#  define Cx2_Lamp_Flashing (2U)
# endif

# ifndef Cx3_ACU_message_error
#  define Cx3_ACU_message_error (3U)
# endif

# ifndef Cx6_Initialization
#  define Cx6_Initialization (6U)
# endif

# ifndef Cx7_Lamp_Circuit_Failure
#  define Cx7_Lamp_Circuit_Failure (7U)
# endif

# ifndef Cx1_On_Road
#  define Cx1_On_Road (1U)
# endif

# ifndef Cx2_Off_Road
#  define Cx2_Off_Road (2U)
# endif

# ifndef Cx0_Not_Used
#  define Cx0_Not_Used (0U)
# endif

# ifndef Cx1_km
#  define Cx1_km (1U)
# endif

# ifndef Cx2_mile
#  define Cx2_mile (2U)
# endif

# ifndef Cx3_Invailid
#  define Cx3_Invailid (3U)
# endif

# ifndef Cx0_Not_Control_Default_
#  define Cx0_Not_Control_Default_ (0U)
# endif

# ifndef Cx1_Control
#  define Cx1_Control (1U)
# endif

# ifndef Cx1_Open_Status
#  define Cx1_Open_Status (1U)
# endif

# ifndef Cx3_Invaild
#  define Cx3_Invaild (3U)
# endif

# ifndef Cx0_Not_Connected
#  define Cx0_Not_Connected (0U)
# endif

# ifndef Cx1_Connected
#  define Cx1_Connected (1U)
# endif

# ifndef Cx0_Active
#  define Cx0_Active (0U)
# endif

# ifndef Cx1_Deactive
#  define Cx1_Deactive (1U)
# endif

# ifndef Cx0_OK
#  define Cx0_OK (0U)
# endif

# ifndef Cx1_Failed
#  define Cx1_Failed (1U)
# endif

# ifndef Cx0_No_Option_default_
#  define Cx0_No_Option_default_ (0U)
# endif

# ifndef Cx0_DBC_Enabled
#  define Cx0_DBC_Enabled (0U)
# endif

# ifndef Cx1_DBC_Disabled_by_system_fault
#  define Cx1_DBC_Disabled_by_system_fault (1U)
# endif

# ifndef Cx0_DBC_Function_lamp_OFF
#  define Cx0_DBC_Function_lamp_OFF (0U)
# endif

# ifndef Cx1_DBC_Function_lamp_ON
#  define Cx1_DBC_Function_lamp_ON (1U)
# endif

# ifndef Cx2_DBC_Function_lamp_BLINKING_2Hz_
#  define Cx2_DBC_Function_lamp_BLINKING_2Hz_ (2U)
# endif

# ifndef Cx0_DBC_Warning_lamp_OFF
#  define Cx0_DBC_Warning_lamp_OFF (0U)
# endif

# ifndef Cx1_DBC_Warning_lamp_ON
#  define Cx1_DBC_Warning_lamp_ON (1U)
# endif

# ifndef Cx0_Drivetrain_Both_Clutch_Open
#  define Cx0_Drivetrain_Both_Clutch_Open (0U)
# endif

# ifndef Cx1_Odd_Clutch_Slipping
#  define Cx1_Odd_Clutch_Slipping (1U)
# endif

# ifndef Cx2_Even_Clutch_Slipping
#  define Cx2_Even_Clutch_Slipping (2U)
# endif

# ifndef Cx3_Clutch_Locked
#  define Cx3_Clutch_Locked (3U)
# endif

# ifndef Cx0_No_Request
#  define Cx0_No_Request (0U)
# endif

# ifndef Cx1_Idle_Request
#  define Cx1_Idle_Request (1U)
# endif

# ifndef Cx0_No_error
#  define Cx0_No_error (0U)
# endif

# ifndef Cx1_Engine_speed_sensor_defective
#  define Cx1_Engine_speed_sensor_defective (1U)
# endif

# ifndef Cx0_No_request
#  define Cx0_No_request (0U)
# endif

# ifndef Cx1_Fuel_Cut_Request
#  define Cx1_Fuel_Cut_Request (1U)
# endif

# ifndef Cx1_Error_on_Torque_Measurement
#  define Cx1_Error_on_Torque_Measurement (1U)
# endif

# ifndef Cx0_No_Inhibit
#  define Cx0_No_Inhibit (0U)
# endif

# ifndef Cx1_Regen_Inhibit
#  define Cx1_Regen_Inhibit (1U)
# endif

# ifndef Cx800_reduction_to_0_torque
#  define Cx800_reduction_to_0_torque (-2048)
# endif

# ifndef Cx000_No_request
#  define Cx000_No_request (0)
# endif

# ifndef Cx7FF_Max_Increase
#  define Cx7FF_Max_Increase (2047)
# endif

# ifndef Cx1_Torque_increase_Request
#  define Cx1_Torque_increase_Request (1U)
# endif

# ifndef Cx0_Not_defective
#  define Cx0_Not_defective (0U)
# endif

# ifndef Cx1_Defective
#  define Cx1_Defective (1U)
# endif

# ifndef Cx1_Drive_Mode_Case1
#  define Cx1_Drive_Mode_Case1 (1U)
# endif

# ifndef Cx2_Drive_Mode_Case2
#  define Cx2_Drive_Mode_Case2 (2U)
# endif

# ifndef Cx3_Drive_Mode_Case3
#  define Cx3_Drive_Mode_Case3 (3U)
# endif

# ifndef Cx4_Drive_Mode_Case4
#  define Cx4_Drive_Mode_Case4 (4U)
# endif

# ifndef Cx5_Drive_Mode_Case5
#  define Cx5_Drive_Mode_Case5 (5U)
# endif

# ifndef Cx6_Drive_Mode_Case6
#  define Cx6_Drive_Mode_Case6 (6U)
# endif

# ifndef Cx7_Drive_Mode_Case7
#  define Cx7_Drive_Mode_Case7 (7U)
# endif

# ifndef Cx8_Drive_Mode_Case8
#  define Cx8_Drive_Mode_Case8 (8U)
# endif

# ifndef Cx9_Drive_Mode_Case9
#  define Cx9_Drive_Mode_Case9 (9U)
# endif

# ifndef CxA_Drive_Mode_Case10
#  define CxA_Drive_Mode_Case10 (10U)
# endif

# ifndef CxB_Drive_Mode_Case11
#  define CxB_Drive_Mode_Case11 (11U)
# endif

# ifndef CxC_Drive_Mode_Case12
#  define CxC_Drive_Mode_Case12 (12U)
# endif

# ifndef CxD_Drive_Mode_Case13
#  define CxD_Drive_Mode_Case13 (13U)
# endif

# ifndef CxE_Drive_Mode_Case14
#  define CxE_Drive_Mode_Case14 (14U)
# endif

# ifndef CxF_Invalid
#  define CxF_Invalid (15U)
# endif

# ifndef Cx0_Not_used
#  define Cx0_Not_used (0U)
# endif

# ifndef Cx1_Step_1
#  define Cx1_Step_1 (1U)
# endif

# ifndef Cx2_Step_2
#  define Cx2_Step_2 (2U)
# endif

# ifndef Cx3_Step_3
#  define Cx3_Step_3 (3U)
# endif

# ifndef Cx4_Step_4
#  define Cx4_Step_4 (4U)
# endif

# ifndef Cx5_Step_5
#  define Cx5_Step_5 (5U)
# endif

# ifndef Cx6_Step_6
#  define Cx6_Step_6 (6U)
# endif

# ifndef Cx7_Step_7
#  define Cx7_Step_7 (7U)
# endif

# ifndef Cx1_AUTO
#  define Cx1_AUTO (1U)
# endif

# ifndef Cx2_2WD
#  define Cx2_2WD (2U)
# endif

# ifndef Cx3_4WD
#  define Cx3_4WD (3U)
# endif

# ifndef Cx0_OFF
#  define Cx0_OFF (0U)
# endif

# ifndef Cx1_ON
#  define Cx1_ON (1U)
# endif

# ifndef Cx0_Glow_plug_off_request
#  define Cx0_Glow_plug_off_request (0U)
# endif

# ifndef Cx1_Glow_plug_on_request
#  define Cx1_Glow_plug_on_request (1U)
# endif

# ifndef Cx2_System_Error
#  define Cx2_System_Error (2U)
# endif

# ifndef Cx0_Lock
#  define Cx0_Lock (0U)
# endif

# ifndef Cx1_Unlock
#  define Cx1_Unlock (1U)
# endif

# ifndef Cx1_Lock
#  define Cx1_Lock (1U)
# endif

# ifndef Cx0_ECD_is_not_active
#  define Cx0_ECD_is_not_active (0U)
# endif

# ifndef Cx1_ECD_is_active_operating_
#  define Cx1_ECD_is_active_operating_ (1U)
# endif

# ifndef Cx0_ISG_Stop_not_Enable
#  define Cx0_ISG_Stop_not_Enable (0U)
# endif

# ifndef Cx1_ISG_Stop_Enable
#  define Cx1_ISG_Stop_Enable (1U)
# endif

# ifndef Cx0_No_Safety_Function_operation
#  define Cx0_No_Safety_Function_operation (0U)
# endif

# ifndef Cx1_Safety_Function_operation
#  define Cx1_Safety_Function_operation (1U)
# endif

# ifndef Cx1_display_Boost_by_motor
#  define Cx1_display_Boost_by_motor (1U)
# endif

# ifndef Cx2_display_Recuperation
#  define Cx2_display_Recuperation (2U)
# endif

# ifndef Cx3_reserved
#  define Cx3_reserved (3U)
# endif

# ifndef Cx1_Auto_cruise_Disengaged
#  define Cx1_Auto_cruise_Disengaged (1U)
# endif

# ifndef Cx2_No_Auto_cruise_Engaged
#  define Cx2_No_Auto_cruise_Engaged (2U)
# endif

# ifndef Cx0_No_acknowledgement
#  define Cx0_No_acknowledgement (0U)
# endif

# ifndef Cx1_Acknowledgement_engine_stopped
#  define Cx1_Acknowledgement_engine_stopped (1U)
# endif

# ifndef Cx0_Battery_Warning_Lamp_OFF
#  define Cx0_Battery_Warning_Lamp_OFF (0U)
# endif

# ifndef Cx1_Battery_Warning_Lamp_ON
#  define Cx1_Battery_Warning_Lamp_ON (1U)
# endif

# ifndef Cx0_Clutch_is_not_operating
#  define Cx0_Clutch_is_not_operating (0U)
# endif

# ifndef Cx1_Clutch_is_operating
#  define Cx1_Clutch_is_operating (1U)
# endif

# ifndef Cx0_DPF_Normal_State
#  define Cx0_DPF_Normal_State (0U)
# endif

# ifndef Cx1_DPF_Warning_State_Level_1
#  define Cx1_DPF_Warning_State_Level_1 (1U)
# endif

# ifndef Cx2_DPF_Warning_State_Level_2
#  define Cx2_DPF_Warning_State_Level_2 (2U)
# endif

# ifndef Cx0_No_display
#  define Cx0_No_display (0U)
# endif

# ifndef Cx1_Gear_Position_1_display
#  define Cx1_Gear_Position_1_display (1U)
# endif

# ifndef Cx2_Gear_Position_2_display
#  define Cx2_Gear_Position_2_display (2U)
# endif

# ifndef Cx3_Gear_Position_3_display
#  define Cx3_Gear_Position_3_display (3U)
# endif

# ifndef Cx4_Gear_Position_4_display
#  define Cx4_Gear_Position_4_display (4U)
# endif

# ifndef Cx5_Gear_Position_5_display
#  define Cx5_Gear_Position_5_display (5U)
# endif

# ifndef Cx6_Gear_Position_6_display
#  define Cx6_Gear_Position_6_display (6U)
# endif

# ifndef Cx7_Gear_Position_7_display
#  define Cx7_Gear_Position_7_display (7U)
# endif

# ifndef Cx8_Gear_Position_8_display
#  define Cx8_Gear_Position_8_display (8U)
# endif

# ifndef Cx9_Gear_Position_9_display
#  define Cx9_Gear_Position_9_display (9U)
# endif

# ifndef CxA_Gear_Position_10_display
#  define CxA_Gear_Position_10_display (10U)
# endif

# ifndef CxF_Error_indicator
#  define CxF_Error_indicator (15U)
# endif

# ifndef Cx0_Active_Eco_Drive_is_not_active
#  define Cx0_Active_Eco_Drive_is_not_active (0U)
# endif

# ifndef Cx1_Active_Eco_Drive_is_active
#  define Cx1_Active_Eco_Drive_is_active (1U)
# endif

# ifndef Cx0_NCC_Inhibition_OFF
#  define Cx0_NCC_Inhibition_OFF (0U)
# endif

# ifndef Cx1_NCC_Inhibition_ON
#  define Cx1_NCC_Inhibition_ON (1U)
# endif

# ifndef Cx0_Engine_Stop_or_Starting_Phase
#  define Cx0_Engine_Stop_or_Starting_Phase (0U)
# endif

# ifndef Cx1_Engine_Running
#  define Cx1_Engine_Running (1U)
# endif

# ifndef Cx0_Engine_Stop
#  define Cx0_Engine_Stop (0U)
# endif

# ifndef Cx1_Cranking
#  define Cx1_Cranking (1U)
# endif

# ifndef Cx2_Stalled
#  define Cx2_Stalled (2U)
# endif

# ifndef Cx3_Running
#  define Cx3_Running (3U)
# endif

# ifndef Cx7_Fault
#  define Cx7_Fault (7U)
# endif

# ifndef Cx0_epsilon
#  define Cx0_epsilon (0U)
# endif

# ifndef Cx1_gamma
#  define Cx1_gamma (1U)
# endif

# ifndef Cx2_kappa
#  define Cx2_kappa (2U)
# endif

# ifndef Cx3_theta
#  define Cx3_theta (3U)
# endif

# ifndef Cx4_nu
#  define Cx4_nu (4U)
# endif

# ifndef Cx5_lambda
#  define Cx5_lambda (5U)
# endif

# ifndef Cx6_tau
#  define Cx6_tau (6U)
# endif

# ifndef CxA_S
#  define CxA_S (10U)
# endif

# ifndef CxB_A
#  define CxB_A (11U)
# endif

# ifndef CxC_R
#  define CxC_R (12U)
# endif

# ifndef CxD_U
#  define CxD_U (13U)
# endif

# ifndef CxE_D
#  define CxE_D (14U)
# endif

# ifndef Cx0_LPI
#  define Cx0_LPI (0U)
# endif

# ifndef Cx1_MPI
#  define Cx1_MPI (1U)
# endif

# ifndef Cx2_GDI
#  define Cx2_GDI (2U)
# endif

# ifndef Cx3_TGDI
#  define Cx3_TGDI (3U)
# endif

# ifndef Cx4_CVVL
#  define Cx4_CVVL (4U)
# endif

# ifndef Cx5_CVVD
#  define Cx5_CVVD (5U)
# endif

# ifndef Cx6_PDI
#  define Cx6_PDI (6U)
# endif

# ifndef Cx7_FFV
#  define Cx7_FFV (7U)
# endif

# ifndef Cx8_TCI
#  define Cx8_TCI (8U)
# endif

# ifndef Cx9_VGT
#  define Cx9_VGT (9U)
# endif

# ifndef CxA_Turbo
#  define CxA_Turbo (10U)
# endif

# ifndef CxB_E_SC
#  define CxB_E_SC (11U)
# endif

# ifndef CxE_Not_used
#  define CxE_Not_used (14U)
# endif

# ifndef Cx0_FF
#  define Cx0_FF (0U)
# endif

# ifndef Cx1_FR
#  define Cx1_FR (1U)
# endif

# ifndef Cx0_Non_ETC
#  define Cx0_Non_ETC (0U)
# endif

# ifndef Cx1_ETC
#  define Cx1_ETC (1U)
# endif

# ifndef Cx0_Engine_control_is_available
#  define Cx0_Engine_control_is_available (0U)
# endif

# ifndef Cx1_ETC_Limphome_mode_by_ECU
#  define Cx1_ETC_Limphome_mode_by_ECU (1U)
# endif

# ifndef Cx0_Fuel_cap_isn_t_opened
#  define Cx0_Fuel_cap_isn_t_opened (0U)
# endif

# ifndef Cx1_Fuel_cap_is_opened
#  define Cx1_Fuel_cap_is_opened (1U)
# endif

# ifndef Cx0_Engine_not_in_fuel_cut_off
#  define Cx0_Engine_not_in_fuel_cut_off (0U)
# endif

# ifndef Cx1_Engine_in_fuel_cut_off
#  define Cx1_Engine_in_fuel_cut_off (1U)
# endif

# ifndef Cx0_Gear_Shiftdown_Display_Off
#  define Cx0_Gear_Shiftdown_Display_Off (0U)
# endif

# ifndef Cx1_Gear_Shiftdown_Display_On
#  define Cx1_Gear_Shiftdown_Display_On (1U)
# endif

# ifndef Cx0_Gear_Shiftup_Display_Off
#  define Cx0_Gear_Shiftup_Display_Off (0U)
# endif

# ifndef Cx1_Gear_Shiftup_Display_On
#  define Cx1_Gear_Shiftup_Display_On (1U)
# endif

# ifndef Cx0_Lamp_Off
#  define Cx0_Lamp_Off (0U)
# endif

# ifndef Cx0_Immobilizer_lamp_OFF
#  define Cx0_Immobilizer_lamp_OFF (0U)
# endif

# ifndef Cx1_Immobilizer_lamp_ON
#  define Cx1_Immobilizer_lamp_ON (1U)
# endif

# ifndef Cx0_Immobilizer_active
#  define Cx0_Immobilizer_active (0U)
# endif

# ifndef Cx1_Immobilizer_passive
#  define Cx1_Immobilizer_passive (1U)
# endif

# ifndef Cx0_Request_buzzer_OFF
#  define Cx0_Request_buzzer_OFF (0U)
# endif

# ifndef Cx1_Request_buzzer_ON
#  define Cx1_Request_buzzer_ON (1U)
# endif

# ifndef Cx0_ISG_is_not_equipped
#  define Cx0_ISG_is_not_equipped (0U)
# endif

# ifndef Cx1_ISG_is_equipped
#  define Cx1_ISG_is_equipped (1U)
# endif

# ifndef Cx0_Not_fuel_consumption
#  define Cx0_Not_fuel_consumption (0U)
# endif

# ifndef Cx1_Fuel_consumption_1mL_
#  define Cx1_Fuel_consumption_1mL_ (1U)
# endif

# ifndef Cx0_ISG_Inhibit_Lamp_OFF
#  define Cx0_ISG_Inhibit_Lamp_OFF (0U)
# endif

# ifndef Cx1_ISG_Inhibit_Lamp_ON
#  define Cx1_ISG_Inhibit_Lamp_ON (1U)
# endif

# ifndef Cx0_Off_state
#  define Cx0_Off_state (0U)
# endif

# ifndef Cx1_Standby
#  define Cx1_Standby (1U)
# endif

# ifndef Cx2_Ready
#  define Cx2_Ready (2U)
# endif

# ifndef Cx3_Lanch
#  define Cx3_Lanch (3U)
# endif

# ifndef Cx4_Error_indicator
#  define Cx4_Error_indicator (4U)
# endif

# ifndef Cx0_Check_Engine_lamp_OFF
#  define Cx0_Check_Engine_lamp_OFF (0U)
# endif

# ifndef Cx1_Check_Engine_lamp_ON
#  define Cx1_Check_Engine_lamp_ON (1U)
# endif

# ifndef Cx0_NCC_OFF_Normal_
#  define Cx0_NCC_OFF_Normal_ (0U)
# endif

# ifndef Cx1_NCC_ON
#  define Cx1_NCC_ON (1U)
# endif

# ifndef Cx0_Oil_life_monitoring_Not_applied
#  define Cx0_Oil_life_monitoring_Not_applied (0U)
# endif

# ifndef Cx1_Oil_life_monitoring_Applied
#  define Cx1_Oil_life_monitoring_Applied (1U)
# endif

# ifndef Cx0_OIL_LEVEL_LAMP_Off
#  define Cx0_OIL_LEVEL_LAMP_Off (0U)
# endif

# ifndef Cx1_OIL_LEVEL_LAMP_On
#  define Cx1_OIL_LEVEL_LAMP_On (1U)
# endif

# ifndef Cx0_Oil_Pressure_Warning_Lamp_OFF
#  define Cx0_Oil_Pressure_Warning_Lamp_OFF (0U)
# endif

# ifndef Cx1_Oil_Pressure_Warning_Lamp_ON
#  define Cx1_Oil_Pressure_Warning_Lamp_ON (1U)
# endif

# ifndef Cx0_Engine_only
#  define Cx0_Engine_only (0U)
# endif

# ifndef Cx1_Engine_MHSG_48V_
#  define Cx1_Engine_MHSG_48V_ (1U)
# endif

# ifndef Cx3_Not_used
#  define Cx3_Not_used (3U)
# endif

# ifndef Cx0_AMS
#  define Cx0_AMS (0U)
# endif

# ifndef Cx1_ISG
#  define Cx1_ISG (1U)
# endif

# ifndef Cx0_No_AMS
#  define Cx0_No_AMS (0U)
# endif

# ifndef Cx1_1G_Generation_AMS
#  define Cx1_1G_Generation_AMS (1U)
# endif

# ifndef Cx2_1_5G_Generation_AMS
#  define Cx2_1_5G_Generation_AMS (2U)
# endif

# ifndef Cx3_2G_Generation_AMS
#  define Cx3_2G_Generation_AMS (3U)
# endif

# ifndef Cx7_Reserved
#  define Cx7_Reserved (7U)
# endif

# ifndef Cx0_Positive_action_is_not_active
#  define Cx0_Positive_action_is_not_active (0U)
# endif

# ifndef Cx1_Positive_action_is_active
#  define Cx1_Positive_action_is_active (1U)
# endif

# ifndef Cx1_SldDisengaged
#  define Cx1_SldDisengaged (1U)
# endif

# ifndef Cx2_NoSldEngaged
#  define Cx2_NoSldEngaged (2U)
# endif

# ifndef Cx3_ErrorIndicator
#  define Cx3_ErrorIndicator (3U)
# endif

# ifndef Cx0_No_Failure_detected
#  define Cx0_No_Failure_detected (0U)
# endif

# ifndef Cx1_Failure_detected
#  define Cx1_Failure_detected (1U)
# endif

# ifndef Cx0_Split_injection_OFF
#  define Cx0_Split_injection_OFF (0U)
# endif

# ifndef Cx1_Split_injection_ON
#  define Cx1_Split_injection_ON (1U)
# endif

# ifndef Cx00_AT_vehicle_Step_Shift_AT_
#  define Cx00_AT_vehicle_Step_Shift_AT_ (0U)
# endif

# ifndef Cx09_E_CLUTCH_vehicle
#  define Cx09_E_CLUTCH_vehicle (9U)
# endif

# ifndef Cx0A_CVT_vehicle_CVT_AT_
#  define Cx0A_CVT_vehicle_CVT_AT_ (10U)
# endif

# ifndef Cx0B_DCT_vehicle_DCT_AT_
#  define Cx0B_DCT_vehicle_DCT_AT_ (11U)
# endif

# ifndef Cx0E_AMT_vehicle
#  define Cx0E_AMT_vehicle (14U)
# endif

# ifndef Cx0F_MT_vehicle
#  define Cx0F_MT_vehicle (15U)
# endif

# ifndef Cx1FF_Error_indicator
#  define Cx1FF_Error_indicator (511U)
# endif

# ifndef Cx1_Release_request
#  define Cx1_Release_request (1U)
# endif

# ifndef Cx2_Close_request_in_comfort_mode
#  define Cx2_Close_request_in_comfort_mode (2U)
# endif

# ifndef Cx3_Close_request_in_secure_mode
#  define Cx3_Close_request_in_secure_mode (3U)
# endif

# ifndef Cx1_Comfortable_tone_Sound_once_
#  define Cx1_Comfortable_tone_Sound_once_ (1U)
# endif

# ifndef Cx2_Uncomfortable_tone
#  define Cx2_Uncomfortable_tone (2U)
# endif

# ifndef Cx1_Dynamic_braking_request
#  define Cx1_Dynamic_braking_request (1U)
# endif

# ifndef Cx1_Emergency_EPB_Mode_Request
#  define Cx1_Emergency_EPB_Mode_Request (1U)
# endif

# ifndef Cx2_Normal_EPB_Mode_Request
#  define Cx2_Normal_EPB_Mode_Request (2U)
# endif

# ifndef Cx3_Not_Used
#  define Cx3_Not_Used (3U)
# endif

# ifndef Cx0_Not_valid
#  define Cx0_Not_valid (0U)
# endif

# ifndef Cx1_EPB_No_failure
#  define Cx1_EPB_No_failure (1U)
# endif

# ifndef Cx2_EPB_Initialization_State
#  define Cx2_EPB_Initialization_State (2U)
# endif

# ifndef Cx3_EPB_Diagnostic
#  define Cx3_EPB_Diagnostic (3U)
# endif

# ifndef Cx4_EPB_Temporarily_Not_Available
#  define Cx4_EPB_Temporarily_Not_Available (4U)
# endif

# ifndef Cx5_EPB_Permanently_Not_Available
#  define Cx5_EPB_Permanently_Not_Available (5U)
# endif

# ifndef Cx0_See_details_in_EPB_FRC_ERR
#  define Cx0_See_details_in_EPB_FRC_ERR (0U)
# endif

# ifndef Cx1_Released
#  define Cx1_Released (1U)
# endif

# ifndef Cx2_Clamped
#  define Cx2_Clamped (2U)
# endif

# ifndef Cx3_Clamping_in_progress
#  define Cx3_Clamping_in_progress (3U)
# endif

# ifndef Cx4_Releasing_in_progress
#  define Cx4_Releasing_in_progress (4U)
# endif

# ifndef Cx5_Dynamic_braking_via_EPB
#  define Cx5_Dynamic_braking_via_EPB (5U)
# endif

# ifndef Cx6_Releasing_in_progress_by_switch
#  define Cx6_Releasing_in_progress_by_switch (6U)
# endif

# ifndef Cx7_Clamping_in_progress_by_switch
#  define Cx7_Clamping_in_progress_by_switch (7U)
# endif

# ifndef Cx0_REQ_EPB_ACT_signal_is_invalid
#  define Cx0_REQ_EPB_ACT_signal_is_invalid (0U)
# endif

# ifndef Cx1_REQ_EPB_ACT_signal_is_valid
#  define Cx1_REQ_EPB_ACT_signal_is_valid (1U)
# endif

# ifndef Cx0_Neutral_position
#  define Cx0_Neutral_position (0U)
# endif

# ifndef Cx1_Apply_position_pull_
#  define Cx1_Apply_position_pull_ (1U)
# endif

# ifndef Cx2_Release_position_push_
#  define Cx2_Release_position_push_ (2U)
# endif

# ifndef Cx3_Switch_failure
#  define Cx3_Switch_failure (3U)
# endif

# ifndef Cx0_BCA_R_available
#  define Cx0_BCA_R_available (0U)
# endif

# ifndef Cx1_BCA_R_braking_is_started
#  define Cx1_BCA_R_braking_is_started (1U)
# endif

# ifndef Cx2_BCA_R_braking_is_ended
#  define Cx2_BCA_R_braking_is_ended (2U)
# endif

# ifndef Cx3_BCA_R_braking_error
#  define Cx3_BCA_R_braking_error (3U)
# endif

# ifndef Cx1_Activate_brake_lights
#  define Cx1_Activate_brake_lights (1U)
# endif

# ifndef Cx0_Undetected
#  define Cx0_Undetected (0U)
# endif

# ifndef Cx1_Detected
#  define Cx1_Detected (1U)
# endif

# ifndef Cx0_DBS_control_is_inactive
#  define Cx0_DBS_control_is_inactive (0U)
# endif

# ifndef Cx1_DBS_control_is_active
#  define Cx1_DBS_control_is_active (1U)
# endif

# ifndef Cx0_Disable_deceleration_control
#  define Cx0_Disable_deceleration_control (0U)
# endif

# ifndef Cx1_Enable_deceleration_control
#  define Cx1_Enable_deceleration_control (1U)
# endif

# ifndef Cx0_Brake_pedal_not_pressed
#  define Cx0_Brake_pedal_not_pressed (0U)
# endif

# ifndef Cx1_Brake_pedal_pressed
#  define Cx1_Brake_pedal_pressed (1U)
# endif

# ifndef Cx0_No_override
#  define Cx0_No_override (0U)
# endif

# ifndef Cx1_Override_by_acceleration_pedal
#  define Cx1_Override_by_acceleration_pedal (1U)
# endif

# ifndef Cx2_Override_by_deceleration
#  define Cx2_Override_by_deceleration (2U)
# endif

# ifndef Cx0_FCA_Brake_is_not_in_activation
#  define Cx0_FCA_Brake_is_not_in_activation (0U)
# endif

# ifndef Cx1_FCA_Pre_Brake
#  define Cx1_FCA_Pre_Brake (1U)
# endif

# ifndef Cx2_FCA_Full_Brake
#  define Cx2_FCA_Full_Brake (2U)
# endif

# ifndef Cx1_Fast_Open
#  define Cx1_Fast_Open (1U)
# endif

# ifndef Cx2_Slow_Open
#  define Cx2_Slow_Open (2U)
# endif

# ifndef Cx3_Torque_Limit
#  define Cx3_Torque_Limit (3U)
# endif

# ifndef Cx4_eLSD_Fail_OPEN
#  define Cx4_eLSD_Fail_OPEN (4U)
# endif

# ifndef Cx7_Error
#  define Cx7_Error (7U)
# endif

# ifndef Cx0_Normal_Mode
#  define Cx0_Normal_Mode (0U)
# endif

# ifndef Cx1_Sports_Mode
#  define Cx1_Sports_Mode (1U)
# endif

# ifndef Cx2_Off_Mode
#  define Cx2_Off_Mode (2U)
# endif

# ifndef Cx3_ESC_OFF_SW_is_defective_failed_
#  define Cx3_ESC_OFF_SW_is_defective_failed_ (3U)
# endif

# ifndef Cx0_PCA_available
#  define Cx0_PCA_available (0U)
# endif

# ifndef Cx1_PCA_brake_started
#  define Cx1_PCA_brake_started (1U)
# endif

# ifndef Cx2_PCA_brake_ended
#  define Cx2_PCA_brake_ended (2U)
# endif

# ifndef Cx3_PCA_disable
#  define Cx3_PCA_disable (3U)
# endif

# ifndef Cx0_Parking_brake_is_not_activated
#  define Cx0_Parking_brake_is_not_activated (0U)
# endif

# ifndef Cx1_Parking_brake_is_activated
#  define Cx1_Parking_brake_is_activated (1U)
# endif

# ifndef Cx0_RCCA_availble
#  define Cx0_RCCA_availble (0U)
# endif

# ifndef Cx1_RCCA_brake_started
#  define Cx1_RCCA_brake_started (1U)
# endif

# ifndef Cx2_RCCA_braking_is_ended
#  define Cx2_RCCA_braking_is_ended (2U)
# endif

# ifndef Cx3_RCCA_braking_error
#  define Cx3_RCCA_braking_error (3U)
# endif

# ifndef Cx0_Inactive
#  define Cx0_Inactive (0U)
# endif

# ifndef Cx1_Active
#  define Cx1_Active (1U)
# endif

# ifndef Cx1_ESC_Initial
#  define Cx1_ESC_Initial (1U)
# endif

# ifndef Cx2_ESC_New_Start
#  define Cx2_ESC_New_Start (2U)
# endif

# ifndef Cx3_ESC_Ready
#  define Cx3_ESC_Ready (3U)
# endif

# ifndef Cx4_Not_used
#  define Cx4_Not_used (4U)
# endif

# ifndef Cx5_ESC_Assist
#  define Cx5_ESC_Assist (5U)
# endif

# ifndef Cx6_ESC_Assist_Fail
#  define Cx6_ESC_Assist_Fail (6U)
# endif

# ifndef Cx7_ESC_Abort
#  define Cx7_ESC_Abort (7U)
# endif

# ifndef Cx8_ESC_Ready_Fail
#  define Cx8_ESC_Ready_Fail (8U)
# endif

# ifndef Cx0_ESC_Sport_Lamp_OFF
#  define Cx0_ESC_Sport_Lamp_OFF (0U)
# endif

# ifndef Cx1_ESC_Sport_Lamp_ON
#  define Cx1_ESC_Sport_Lamp_ON (1U)
# endif

# ifndef Cx0_No_stand_still_detected
#  define Cx0_No_stand_still_detected (0U)
# endif

# ifndef Cx1_stand_still_detected
#  define Cx1_stand_still_detected (1U)
# endif

# ifndef Cx0_VSM_control_inactive
#  define Cx0_VSM_control_inactive (0U)
# endif

# ifndef Cx1_VSM_control_active
#  define Cx1_VSM_control_active (1U)
# endif

# ifndef Cx0_VSM_is_not_defective
#  define Cx0_VSM_is_not_defective (0U)
# endif

# ifndef Cx1_VSM_is_defective
#  define Cx1_VSM_is_defective (1U)
# endif

# ifndef Cx0_Available
#  define Cx0_Available (0U)
# endif

# ifndef Cx1_Temporarily_not_available
#  define Cx1_Temporarily_not_available (1U)
# endif

# ifndef Cx2_Permanently_not_available
#  define Cx2_Permanently_not_available (2U)
# endif

# ifndef Cx3_FCA_Communication_Error
#  define Cx3_FCA_Communication_Error (3U)
# endif

# ifndef Cx0_FCA_is_not_equipped
#  define Cx0_FCA_is_not_equipped (0U)
# endif

# ifndef Cx1_FCA_is_equipped
#  define Cx1_FCA_is_equipped (1U)
# endif

# ifndef Cx3_Not_Coded
#  define Cx3_Not_Coded (3U)
# endif

# ifndef Cx0_No_Coding
#  define Cx0_No_Coding (0U)
# endif

# ifndef Cx1_Sensor_Fusion_FCA
#  define Cx1_Sensor_Fusion_FCA (1U)
# endif

# ifndef Cx2_Camera_only_FCA
#  define Cx2_Camera_only_FCA (2U)
# endif

# ifndef Cx3_No_FCA_Option
#  define Cx3_No_FCA_Option (3U)
# endif

# ifndef Cx4_ADAS_DRV_Option
#  define Cx4_ADAS_DRV_Option (4U)
# endif

# ifndef Cx1_A_CANFD_Bus_off
#  define Cx1_A_CANFD_Bus_off (1U)
# endif

# ifndef Cx2_A_CANFD_Timeout
#  define Cx2_A_CANFD_Timeout (2U)
# endif

# ifndef Cx0_Coded
#  define Cx0_Coded (0U)
# endif

# ifndef Cx1_Not_coded
#  define Cx1_Not_coded (1U)
# endif

# ifndef Cx1_Valid_EM_Target
#  define Cx1_Valid_EM_Target (1U)
# endif

# ifndef Cx0_Not_applied
#  define Cx0_Not_applied (0U)
# endif

# ifndef Cx1_Applied
#  define Cx1_Applied (1U)
# endif

# ifndef Cx0_Not_Applied
#  define Cx0_Not_Applied (0U)
# endif

# ifndef Cx0_HBA_Indicator_Lamp_Off
#  define Cx0_HBA_Indicator_Lamp_Off (0U)
# endif

# ifndef Cx1_HBA_Indicator_Lamp_On_Green_
#  define Cx1_HBA_Indicator_Lamp_On_Green_ (1U)
# endif

# ifndef Cx2_HBA_Indicator_Lamp_On_White_
#  define Cx2_HBA_Indicator_Lamp_On_White_ (2U)
# endif

# ifndef Cx0_None_HBA_Option_Default_
#  define Cx0_None_HBA_Option_Default_ (0U)
# endif

# ifndef Cx1_HBA_Function_Off
#  define Cx1_HBA_Function_Off (1U)
# endif

# ifndef Cx2_HBA_Function_On
#  define Cx2_HBA_Function_On (2U)
# endif

# ifndef Cx3_Invalid_Fail_
#  define Cx3_Invalid_Fail_ (3U)
# endif

# ifndef Cx1_HBA_Option
#  define Cx1_HBA_Option (1U)
# endif

# ifndef Cx0_Level_0_Open_
#  define Cx0_Level_0_Open_ (0U)
# endif

# ifndef Cx1_Level_1
#  define Cx1_Level_1 (1U)
# endif

# ifndef Cx2_Level_2
#  define Cx2_Level_2 (2U)
# endif

# ifndef Cx3_Levle_3_Close_
#  define Cx3_Levle_3_Close_ (3U)
# endif

# ifndef Cx0_Impossible
#  define Cx0_Impossible (0U)
# endif

# ifndef Cx1_Possible
#  define Cx1_Possible (1U)
# endif

# ifndef Cx0_Not_Permitted
#  define Cx0_Not_Permitted (0U)
# endif

# ifndef Cx1_Permitted
#  define Cx1_Permitted (1U)
# endif

# ifndef Cx0_None
#  define Cx0_None (0U)
# endif

# ifndef Cx1_Blower_off_request
#  define Cx1_Blower_off_request (1U)
# endif

# ifndef Cx1_Lamp_On_Request
#  define Cx1_Lamp_On_Request (1U)
# endif

# ifndef Cx1_Ready
#  define Cx1_Ready (1U)
# endif

# ifndef Cx2_Act
#  define Cx2_Act (2U)
# endif

# ifndef Cx0_default
#  define Cx0_default (0U)
# endif

# ifndef Cx1_CC_Disengaged
#  define Cx1_CC_Disengaged (1U)
# endif

# ifndef Cx2_No_CC_Engage_Condition
#  define Cx2_No_CC_Engage_Condition (2U)
# endif

# ifndef Cx1_Set
#  define Cx1_Set (1U)
# endif

# ifndef Cx0_Eco_mode
#  define Cx0_Eco_mode (0U)
# endif

# ifndef Cx1_Normal_mode
#  define Cx1_Normal_mode (1U)
# endif

# ifndef Cx2_Sport_mode
#  define Cx2_Sport_mode (2U)
# endif

# ifndef Cx1_User_DUC_Setting_Page_On
#  define Cx1_User_DUC_Setting_Page_On (1U)
# endif

# ifndef Cx2_DUC_Setting_Cancel_Page_On
#  define Cx2_DUC_Setting_Cancel_Page_On (2U)
# endif

# ifndef Cx3_DUC_Setting_Confirm_Page_On
#  define Cx3_DUC_Setting_Confirm_Page_On (3U)
# endif

# ifndef Cx4_DUC_Setting_Inhibit
#  define Cx4_DUC_Setting_Inhibit (4U)
# endif

# ifndef Cx0_EMS_real_APS_use
#  define Cx0_EMS_real_APS_use (0U)
# endif

# ifndef Cx1_HCU_Estimated_APS_use
#  define Cx1_HCU_Estimated_APS_use (1U)
# endif

# ifndef Cx0_GDM_Lamp_Off
#  define Cx0_GDM_Lamp_Off (0U)
# endif

# ifndef Cx1_GDM_Lamp_On
#  define Cx1_GDM_Lamp_On (1U)
# endif

# ifndef Cx0_READY_LAMP_OFF
#  define Cx0_READY_LAMP_OFF (0U)
# endif

# ifndef Cx1_READY_LAMP_ON
#  define Cx1_READY_LAMP_ON (1U)
# endif

# ifndef Cx3_READY_LAMP_BLINKING
#  define Cx3_READY_LAMP_BLINKING (3U)
# endif

# ifndef Cx0_HCU_not_Ready
#  define Cx0_HCU_not_Ready (0U)
# endif

# ifndef Cx1_HCU_Control_Board_Ready
#  define Cx1_HCU_Control_Board_Ready (1U)
# endif

# ifndef Cx0_HEV_not_ready
#  define Cx0_HEV_not_ready (0U)
# endif

# ifndef Cx1_HEV_Drivable
#  define Cx1_HEV_Drivable (1U)
# endif

# ifndef Cx1_Vehicle_Stop
#  define Cx1_Vehicle_Stop (1U)
# endif

# ifndef Cx2_EV_Propulsion
#  define Cx2_EV_Propulsion (2U)
# endif

# ifndef Cx3_Power_Assist
#  define Cx3_Power_Assist (3U)
# endif

# ifndef Cx4_Engine_Only_Propulsion
#  define Cx4_Engine_Only_Propulsion (4U)
# endif

# ifndef Cx5_Engine_Generation
#  define Cx5_Engine_Generation (5U)
# endif

# ifndef Cx6_Regeneration
#  define Cx6_Regeneration (6U)
# endif

# ifndef Cx7_Engine_Brake
#  define Cx7_Engine_Brake (7U)
# endif

# ifndef Cx8_Power_Researve
#  define Cx8_Power_Researve (8U)
# endif

# ifndef Cx9_Engine_Generation_Motor_Drive
#  define Cx9_Engine_Generation_Motor_Drive (9U)
# endif

# ifndef CxA_Engine_Generation_Regeneration
#  define CxA_Engine_Generation_Regeneration (10U)
# endif

# ifndef CxB_Engine_Brake_Regeneration
#  define CxB_Engine_Brake_Regeneration (11U)
# endif

# ifndef Cx1_LDC_Off_request
#  define Cx1_LDC_Off_request (1U)
# endif

# ifndef Cx0_UVC_Off
#  define Cx0_UVC_Off (0U)
# endif

# ifndef Cx1_UVC_On
#  define Cx1_UVC_On (1U)
# endif

# ifndef Cx1_Limp_off_the_road
#  define Cx1_Limp_off_the_road (1U)
# endif

# ifndef Cx1_MIL_On_Request
#  define Cx1_MIL_On_Request (1U)
# endif

# ifndef Cx1_Manual_Resume
#  define Cx1_Manual_Resume (1U)
# endif

# ifndef Cx2_Automatic_Resume
#  define Cx2_Automatic_Resume (2U)
# endif

# ifndef Cx1_Request
#  define Cx1_Request (1U)
# endif

# ifndef Cx1_SAC_Off_Popup_Request
#  define Cx1_SAC_Off_Popup_Request (1U)
# endif

# ifndef Cx0_Paddle_Step_0
#  define Cx0_Paddle_Step_0 (0U)
# endif

# ifndef Cx1_Paddle_Step_1
#  define Cx1_Paddle_Step_1 (1U)
# endif

# ifndef Cx2_Paddle_Step_2
#  define Cx2_Paddle_Step_2 (2U)
# endif

# ifndef Cx3_Paddle_Step_3
#  define Cx3_Paddle_Step_3 (3U)
# endif

# ifndef Cx4_Paddle_Step_4
#  define Cx4_Paddle_Step_4 (4U)
# endif

# ifndef Cx5_reserve
#  define Cx5_reserve (5U)
# endif

# ifndef Cx6_reserve
#  define Cx6_reserve (6U)
# endif

# ifndef Cx7_default
#  define Cx7_default (7U)
# endif

# ifndef Cx0_AUTO_Mode_Off
#  define Cx0_AUTO_Mode_Off (0U)
# endif

# ifndef Cx1_AUTO_Mode_On
#  define Cx1_AUTO_Mode_On (1U)
# endif

# ifndef Cx0_Charge_sustaining_CS_mode
#  define Cx0_Charge_sustaining_CS_mode (0U)
# endif

# ifndef Cx1_Charge_depleting_CD_mode
#  define Cx1_Charge_depleting_CD_mode (1U)
# endif

# ifndef Cx0_Temperature_0_deg
#  define Cx0_Temperature_0_deg (0U)
# endif

# ifndef Cx1_Temperature_1_deg
#  define Cx1_Temperature_1_deg (1U)
# endif

# ifndef Cx2_Temperature_2_deg
#  define Cx2_Temperature_2_deg (2U)
# endif

# ifndef Cx3_Temperature_3_deg
#  define Cx3_Temperature_3_deg (3U)
# endif

# ifndef Cx0_counter
#  define Cx0_counter (0U)
# endif

# ifndef Cx1_counter
#  define Cx1_counter (1U)
# endif

# ifndef Cx2_counter
#  define Cx2_counter (2U)
# endif

# ifndef Cx3_counter
#  define Cx3_counter (3U)
# endif

# ifndef Cx0_Override_clear
#  define Cx0_Override_clear (0U)
# endif

# ifndef Cx1_Override_set
#  define Cx1_Override_set (1U)
# endif

# ifndef Cx0_SCC_Impossible
#  define Cx0_SCC_Impossible (0U)
# endif

# ifndef Cx1_SCC_Possible
#  define Cx1_SCC_Possible (1U)
# endif

# ifndef Cx0_Sun
#  define Cx0_Sun (0U)
# endif

# ifndef Cx1_Mon
#  define Cx1_Mon (1U)
# endif

# ifndef Cx2_Tue
#  define Cx2_Tue (2U)
# endif

# ifndef Cx3_Wed
#  define Cx3_Wed (3U)
# endif

# ifndef Cx4_Thu
#  define Cx4_Thu (4U)
# endif

# ifndef Cx5_Fri
#  define Cx5_Fri (5U)
# endif

# ifndef Cx6_Sat
#  define Cx6_Sat (6U)
# endif

# ifndef Cx1_Slowdown_state
#  define Cx1_Slowdown_state (1U)
# endif

# ifndef Cx1_Disabled
#  define Cx1_Disabled (1U)
# endif

# ifndef Cx2_Enabled
#  define Cx2_Enabled (2U)
# endif

# ifndef Cx0_Off_Manual_
#  define Cx0_Off_Manual_ (0U)
# endif

# ifndef Cx1_On_AUTO_
#  define Cx1_On_AUTO_ (1U)
# endif

# ifndef Cx0_Vehicle_Hold_Off
#  define Cx0_Vehicle_Hold_Off (0U)
# endif

# ifndef Cx1_Vehicle_Hold_On
#  define Cx1_Vehicle_Hold_On (1U)
# endif

# ifndef Cx0_Speed_Limiter_Not_Operation
#  define Cx0_Speed_Limiter_Not_Operation (0U)
# endif

# ifndef Cx1_Speed_Limiter_Operation
#  define Cx1_Speed_Limiter_Operation (1U)
# endif

# ifndef Cx2_Speed_Limiter_Standby
#  define Cx2_Speed_Limiter_Standby (2U)
# endif

# ifndef Cx3_Error_Inicator
#  define Cx3_Error_Inicator (3U)
# endif

# ifndef Cx1_Service_Lamp_On_Request
#  define Cx1_Service_Lamp_On_Request (1U)
# endif

# ifndef Cx0_Normal_made
#  define Cx0_Normal_made (0U)
# endif

# ifndef Cx1_2WD_Test_mode
#  define Cx1_2WD_Test_mode (1U)
# endif

# ifndef Cx1_Start_Inhibit
#  define Cx1_Start_Inhibit (1U)
# endif

# ifndef Cx1_Start_Inhibit_state
#  define Cx1_Start_Inhibit_state (1U)
# endif

# ifndef Cx0_Start_disable
#  define Cx0_Start_disable (0U)
# endif

# ifndef Cx1_Start_Enable
#  define Cx1_Start_Enable (1U)
# endif

# ifndef Cx0_System_OFF_Default_
#  define Cx0_System_OFF_Default_ (0U)
# endif

# ifndef Cx1_System_STANDBY
#  define Cx1_System_STANDBY (1U)
# endif

# ifndef Cx2_System_ACTIVE
#  define Cx2_System_ACTIVE (2U)
# endif

# ifndef Cx1_Gray
#  define Cx1_Gray (1U)
# endif

# ifndef Cx2_Green
#  define Cx2_Green (2U)
# endif

# ifndef Cx3_White_blink
#  define Cx3_White_blink (3U)
# endif

# ifndef Cx0_Off_
#  define Cx0_Off_ (0U)
# endif

# ifndef Cx1_Additional_Warning_Sound
#  define Cx1_Additional_Warning_Sound (1U)
# endif

# ifndef Cx0_
#  define Cx0_ (0U)
# endif

# ifndef Cx1_Freeze_AC_clutch
#  define Cx1_Freeze_AC_clutch (1U)
# endif

# ifndef Cx0_Open
#  define Cx0_Open (0U)
# endif

# ifndef Cx1_Slip
#  define Cx1_Slip (1U)
# endif

# ifndef Cx2_Locked
#  define Cx2_Locked (2U)
# endif

# ifndef Cx3_Locked_Micro_Slip
#  define Cx3_Locked_Micro_Slip (3U)
# endif

# ifndef Cx0_Not_Ready
#  define Cx0_Not_Ready (0U)
# endif

# ifndef Cx1_Controllable
#  define Cx1_Controllable (1U)
# endif

# ifndef Cx00_SOS
#  define Cx00_SOS (0U)
# endif

# ifndef Cx01_ECO
#  define Cx01_ECO (1U)
# endif

# ifndef Cx02_DS
#  define Cx02_DS (2U)
# endif

# ifndef Cx03_ECO_LD1
#  define Cx03_ECO_LD1 (3U)
# endif

# ifndef Cx04_ECO_LD2
#  define Cx04_ECO_LD2 (4U)
# endif

# ifndef Cx05_ECO_LD3
#  define Cx05_ECO_LD3 (5U)
# endif

# ifndef Cx06_ECO_LD1_HAT
#  define Cx06_ECO_LD1_HAT (6U)
# endif

# ifndef Cx07_ECO_LD2_HAT
#  define Cx07_ECO_LD2_HAT (7U)
# endif

# ifndef Cx08_ECO_LD3_HAT
#  define Cx08_ECO_LD3_HAT (8U)
# endif

# ifndef Cx09_DS_LD1
#  define Cx09_DS_LD1 (9U)
# endif

# ifndef Cx0A_DS_LD2
#  define Cx0A_DS_LD2 (10U)
# endif

# ifndef Cx0B_DS_LD3
#  define Cx0B_DS_LD3 (11U)
# endif

# ifndef Cx0C_SOC_L
#  define Cx0C_SOC_L (12U)
# endif

# ifndef Cx0D_SOC_N
#  define Cx0D_SOC_N (13U)
# endif

# ifndef Cx0E_SOC_H
#  define Cx0E_SOC_H (14U)
# endif

# ifndef Cx0F_Highway
#  define Cx0F_Highway (15U)
# endif

# ifndef Cx10_ACC_NLD
#  define Cx10_ACC_NLD (16U)
# endif

# ifndef Cx11_ACC_LD1
#  define Cx11_ACC_LD1 (17U)
# endif

# ifndef Cx12_ACC_LD2
#  define Cx12_ACC_LD2 (18U)
# endif

# ifndef Cx13_ACC_LD3
#  define Cx13_ACC_LD3 (19U)
# endif

# ifndef Cx14_Manual
#  define Cx14_Manual (20U)
# endif

# ifndef Cx15_Manual_LD
#  define Cx15_Manual_LD (21U)
# endif

# ifndef Cx16_CLT_PRT
#  define Cx16_CLT_PRT (22U)
# endif

# ifndef Cx17_TCS_NLD
#  define Cx17_TCS_NLD (23U)
# endif

# ifndef Cx18_TCS_LD
#  define Cx18_TCS_LD (24U)
# endif

# ifndef Cx19_NORMAL
#  define Cx19_NORMAL (25U)
# endif

# ifndef Cx1A_ECO_DLD
#  define Cx1A_ECO_DLD (26U)
# endif

# ifndef Cx1B_DS_DLD
#  define Cx1B_DS_DLD (27U)
# endif

# ifndef Cx1C_EVEN
#  define Cx1C_EVEN (28U)
# endif

# ifndef Cx1D_ODD
#  define Cx1D_ODD (29U)
# endif

# ifndef Cx1E_CD_EV_Mode_
#  define Cx1E_CD_EV_Mode_ (30U)
# endif

# ifndef Cx1F_Reserve
#  define Cx1F_Reserve (31U)
# endif

# ifndef Cx0_CS_Open
#  define Cx0_CS_Open (0U)
# endif

# ifndef Cx1_CS_TakeUp
#  define Cx1_CS_TakeUp (1U)
# endif

# ifndef Cx2_CS_Engage
#  define Cx2_CS_Engage (2U)
# endif

# ifndef Cx3_CS_Shift
#  define Cx3_CS_Shift (3U)
# endif

# ifndef Cx4_CS_Drive
#  define Cx4_CS_Drive (4U)
# endif

# ifndef Cx5_CS_Disengage
#  define Cx5_CS_Disengage (5U)
# endif

# ifndef Cx6_CS_SpinRequest
#  define Cx6_CS_SpinRequest (6U)
# endif

# ifndef Cx7_CS_TestMode
#  define Cx7_CS_TestMode (7U)
# endif

# ifndef Cx8_CS_Initialize
#  define Cx8_CS_Initialize (8U)
# endif

# ifndef Cx9_CS_Fail
#  define Cx9_CS_Fail (9U)
# endif

# ifndef Cx1_EOL_request
#  define Cx1_EOL_request (1U)
# endif

# ifndef Cx0_No_Fuel_Cut_request
#  define Cx0_No_Fuel_Cut_request (0U)
# endif

# ifndef Cx1_Activation_of_Fuel_Cut_request
#  define Cx1_Activation_of_Fuel_Cut_request (1U)
# endif

# ifndef Cx0_Neutral_Initial_Value_
#  define Cx0_Neutral_Initial_Value_ (0U)
# endif

# ifndef Cx1_1st_speed
#  define Cx1_1st_speed (1U)
# endif

# ifndef Cx2_2nd_speed
#  define Cx2_2nd_speed (2U)
# endif

# ifndef Cx3_3rd_speed
#  define Cx3_3rd_speed (3U)
# endif

# ifndef Cx4_4th_speed
#  define Cx4_4th_speed (4U)
# endif

# ifndef Cx5_5th_speed
#  define Cx5_5th_speed (5U)
# endif

# ifndef Cx6_6th_speed
#  define Cx6_6th_speed (6U)
# endif

# ifndef Cx8_Reserved
#  define Cx8_Reserved (8U)
# endif

# ifndef Cx9_Reserved
#  define Cx9_Reserved (9U)
# endif

# ifndef CxA_Reserved
#  define CxA_Reserved (10U)
# endif

# ifndef CxB_Reserved
#  define CxB_Reserved (11U)
# endif

# ifndef CxC_Reserved
#  define CxC_Reserved (12U)
# endif

# ifndef CxD_Reserved
#  define CxD_Reserved (13U)
# endif

# ifndef CxE_Reserved
#  define CxE_Reserved (14U)
# endif

# ifndef CxF_Reserved
#  define CxF_Reserved (15U)
# endif

# ifndef Cx0_Anti_jerk_not_inhibit
#  define Cx0_Anti_jerk_not_inhibit (0U)
# endif

# ifndef Cx1_Anti_jerk_inhibit
#  define Cx1_Anti_jerk_inhibit (1U)
# endif

# ifndef Cx0_gN
#  define Cx0_gN (0U)
# endif

# ifndef Cx1_g1
#  define Cx1_g1 (1U)
# endif

# ifndef Cx2_g2
#  define Cx2_g2 (2U)
# endif

# ifndef Cx3_g3
#  define Cx3_g3 (3U)
# endif

# ifndef Cx4_g4
#  define Cx4_g4 (4U)
# endif

# ifndef Cx5_g5
#  define Cx5_g5 (5U)
# endif

# ifndef Cx6_g6
#  define Cx6_g6 (6U)
# endif

# ifndef Cx7_None
#  define Cx7_None (7U)
# endif

# ifndef Cx8_None
#  define Cx8_None (8U)
# endif

# ifndef Cx9_None
#  define Cx9_None (9U)
# endif

# ifndef CxA_None
#  define CxA_None (10U)
# endif

# ifndef CxB_None
#  define CxB_None (11U)
# endif

# ifndef CxC_None
#  define CxC_None (12U)
# endif

# ifndef CxD_None
#  define CxD_None (13U)
# endif

# ifndef CxE_None
#  define CxE_None (14U)
# endif

# ifndef CxF_gR
#  define CxF_gR (15U)
# endif

# ifndef Cx0_Not_complete
#  define Cx0_Not_complete (0U)
# endif

# ifndef Cx1_Complete
#  define Cx1_Complete (1U)
# endif

# ifndef Cx1_OBD_error
#  define Cx1_OBD_error (1U)
# endif

# ifndef Cx00_No_shift
#  define Cx00_No_shift (0U)
# endif

# ifndef Cx01_A0_Prepataion_for_shift_
#  define Cx01_A0_Prepataion_for_shift_ (1U)
# endif

# ifndef Cx02_A1_Prepataion_for_shift_
#  define Cx02_A1_Prepataion_for_shift_ (2U)
# endif

# ifndef Cx03_A2_Prepataion_for_shift_
#  define Cx03_A2_Prepataion_for_shift_ (3U)
# endif

# ifndef Cx04_A3_Prepataion_for_shift_
#  define Cx04_A3_Prepataion_for_shift_ (4U)
# endif

# ifndef Cx05_B1_Beginning_of_shift_
#  define Cx05_B1_Beginning_of_shift_ (5U)
# endif

# ifndef Cx06_B2_Beginning_of_shift_
#  define Cx06_B2_Beginning_of_shift_ (6U)
# endif

# ifndef Cx07_B3_Beginning_of_shift_
#  define Cx07_B3_Beginning_of_shift_ (7U)
# endif

# ifndef Cx08_B4_Beginning_of_shift_
#  define Cx08_B4_Beginning_of_shift_ (8U)
# endif

# ifndef Cx09_C1_Duration_of_actual_shift_
#  define Cx09_C1_Duration_of_actual_shift_ (9U)
# endif

# ifndef Cx0A_C2_Duration_of_actual_shift_
#  define Cx0A_C2_Duration_of_actual_shift_ (10U)
# endif

# ifndef Cx0B_C3_Duration_of_actual_shift_
#  define Cx0B_C3_Duration_of_actual_shift_ (11U)
# endif

# ifndef Cx0C_D1_Duration_of_actual_shift_
#  define Cx0C_D1_Duration_of_actual_shift_ (12U)
# endif

# ifndef Cx0D_E1_Finishing_shift_
#  define Cx0D_E1_Finishing_shift_ (13U)
# endif

# ifndef Cx0E_E2_Finishing_shift_
#  define Cx0E_E2_Finishing_shift_ (14U)
# endif

# ifndef Cx0F_E3_Finishing_shift_
#  define Cx0F_E3_Finishing_shift_ (15U)
# endif

# ifndef Cx10_END_Shift_End_
#  define Cx10_END_Shift_End_ (16U)
# endif

# ifndef Cx0_No_DR_or_RD_lurch_control
#  define Cx0_No_DR_or_RD_lurch_control (0U)
# endif

# ifndef Cx1_DR_lurch_control_active
#  define Cx1_DR_lurch_control_active (1U)
# endif

# ifndef Cx2_RD_lurch_control_active
#  define Cx2_RD_lurch_control_active (2U)
# endif

# ifndef Cx0_Not_ready
#  define Cx0_Not_ready (0U)
# endif

# ifndef Cx1_Torque_increase_controls
#  define Cx1_Torque_increase_controls (1U)
# endif

# ifndef Cx00_static
#  define Cx00_static (0U)
# endif

# ifndef Cx01_Pon_UP
#  define Cx01_Pon_UP (1U)
# endif

# ifndef Cx02_Poff_UP
#  define Cx02_Poff_UP (2U)
# endif

# ifndef Cx03_reserve
#  define Cx03_reserve (3U)
# endif

# ifndef Cx04_Pon_DN
#  define Cx04_Pon_DN (4U)
# endif

# ifndef Cx05_PoffDn_manual_
#  define Cx05_PoffDn_manual_ (5U)
# endif

# ifndef Cx06_NSTP_to_5_4_3_2
#  define Cx06_NSTP_to_5_4_3_2 (6U)
# endif

# ifndef Cx07_NSTP_to_1
#  define Cx07_NSTP_to_1 (7U)
# endif

# ifndef Cx08_reserve
#  define Cx08_reserve (8U)
# endif

# ifndef Cx09_reserve
#  define Cx09_reserve (9U)
# endif

# ifndef Cx0A_reserve
#  define Cx0A_reserve (10U)
# endif

# ifndef Cx0B_reserve
#  define Cx0B_reserve (11U)
# endif

# ifndef Cx0C_reserve
#  define Cx0C_reserve (12U)
# endif

# ifndef Cx0D_reserve
#  define Cx0D_reserve (13U)
# endif

# ifndef Cx0E_reserve
#  define Cx0E_reserve (14U)
# endif

# ifndef Cx1_Blockage
#  define Cx1_Blockage (1U)
# endif

# ifndef Cx2_Failure
#  define Cx2_Failure (2U)
# endif

# ifndef Cx0_No_driving_cycle_active
#  define Cx0_No_driving_cycle_active (0U)
# endif

# ifndef Cx1_Driving_cycle_active
#  define Cx1_Driving_cycle_active (1U)
# endif

# ifndef Cx0_No_Full_Load
#  define Cx0_No_Full_Load (0U)
# endif

# ifndef Cx1_Full_Load
#  define Cx1_Full_Load (1U)
# endif

# ifndef Cx0_ES_Engine_Stop_
#  define Cx0_ES_Engine_Stop_ (0U)
# endif

# ifndef Cx1_ST_Start_
#  define Cx1_ST_Start_ (1U)
# endif

# ifndef Cx2_IS_Idle_speed_
#  define Cx2_IS_Idle_speed_ (2U)
# endif

# ifndef Cx3_PL_Part_Load_
#  define Cx3_PL_Part_Load_ (3U)
# endif

# ifndef Cx4_PU_Pull_
#  define Cx4_PU_Pull_ (4U)
# endif

# ifndef Cx5_PUC_Fuel_Cut_off_
#  define Cx5_PUC_Fuel_Cut_off_ (5U)
# endif

# ifndef Cx0_no_error
#  define Cx0_no_error (0U)
# endif

# ifndef Cx1_engine_speed_sensor_defective
#  define Cx1_engine_speed_sensor_defective (1U)
# endif

# ifndef Cx0_Fuel_Gasoline_ETC_No
#  define Cx0_Fuel_Gasoline_ETC_No (0U)
# endif

# ifndef Cx1_Fuel_LPI_LPG_ETC_No
#  define Cx1_Fuel_LPI_LPG_ETC_No (1U)
# endif

# ifndef Cx2_Fuel_Diesel_ETC_No
#  define Cx2_Fuel_Diesel_ETC_No (2U)
# endif

# ifndef Cx4_Fuel_Gasoline_ETC_Applied
#  define Cx4_Fuel_Gasoline_ETC_Applied (4U)
# endif

# ifndef Cx5_Fuel_LPI_LPG_ETC_Applied
#  define Cx5_Fuel_LPI_LPG_ETC_Applied (5U)
# endif

# ifndef Cx6_Fuel_Diesel_ETC_Applied
#  define Cx6_Fuel_Diesel_ETC_Applied (6U)
# endif

# ifndef Cx7_GDI_type_engine
#  define Cx7_GDI_type_engine (7U)
# endif

# ifndef Cx0_No_firing
#  define Cx0_No_firing (0U)
# endif

# ifndef Cx1_First_firing
#  define Cx1_First_firing (1U)
# endif

# ifndef Cx0_Permit
#  define Cx0_Permit (0U)
# endif

# ifndef Cx1_Inhibit
#  define Cx1_Inhibit (1U)
# endif

# ifndef Cx0_Engine_Not_in_fuel_cut_off
#  define Cx0_Engine_Not_in_fuel_cut_off (0U)
# endif

# ifndef Cx0_GPF_Normal_State
#  define Cx0_GPF_Normal_State (0U)
# endif

# ifndef Cx1_GPF_Warning_State_Level_1
#  define Cx1_GPF_Warning_State_Level_1 (1U)
# endif

# ifndef Cx2_GPF_Warning_State_Level_2
#  define Cx2_GPF_Warning_State_Level_2 (2U)
# endif

# ifndef Cx0_No_LSH_UP_preheating
#  define Cx0_No_LSH_UP_preheating (0U)
# endif

# ifndef Cx1_LSH_UP_preheating_activated
#  define Cx1_LSH_UP_preheating_activated (1U)
# endif

# ifndef Cx0_Not_RBM_driving_cycle_completed
#  define Cx0_Not_RBM_driving_cycle_completed (0U)
# endif

# ifndef Cx1_RBM_driving_cycle_completed
#  define Cx1_RBM_driving_cycle_completed (1U)
# endif

# ifndef CxFF_Error_indicator
#  define CxFF_Error_indicator (255U)
# endif

# ifndef Cx0_Not_warm_up_cycle_completed
#  define Cx0_Not_warm_up_cycle_completed (0U)
# endif

# ifndef Cx1_Warm_up_cycle_completed
#  define Cx1_Warm_up_cycle_completed (1U)
# endif

# ifndef Cx1_TCU_Controllable
#  define Cx1_TCU_Controllable (1U)
# endif

# ifndef Cx0_Not_Request
#  define Cx0_Not_Request (0U)
# endif

# ifndef Cx00_PR_NML
#  define Cx00_PR_NML (0U)
# endif

# ifndef Cx01_PR_MED
#  define Cx01_PR_MED (1U)
# endif

# ifndef Cx02_PR_SPTY
#  define Cx02_PR_SPTY (2U)
# endif

# ifndef Cx03_PR_LD1
#  define Cx03_PR_LD1 (3U)
# endif

# ifndef Cx04_PR_LD2
#  define Cx04_PR_LD2 (4U)
# endif

# ifndef Cx05_PR_LD3
#  define Cx05_PR_LD3 (5U)
# endif

# ifndef Cx06_PR_DLD
#  define Cx06_PR_DLD (6U)
# endif

# ifndef Cx07_PR_LD1_H
#  define Cx07_PR_LD1_H (7U)
# endif

# ifndef Cx08_PR_LD2_H
#  define Cx08_PR_LD2_H (8U)
# endif

# ifndef Cx09_PR_LD3_H
#  define Cx09_PR_LD3_H (9U)
# endif

# ifndef Cx0A_PR_PRT
#  define Cx0A_PR_PRT (10U)
# endif

# ifndef Cx0B_PR_WRM_UP
#  define Cx0B_PR_WRM_UP (11U)
# endif

# ifndef Cx0C_PR_BLUE
#  define Cx0C_PR_BLUE (12U)
# endif

# ifndef Cx0D_PR_ECO_ATC
#  define Cx0D_PR_ECO_ATC (13U)
# endif

# ifndef Cx0E_PR_LD_ATC
#  define Cx0E_PR_LD_ATC (14U)
# endif

# ifndef Cx0F_PR_LD_ATC_H
#  define Cx0F_PR_LD_ATC_H (15U)
# endif

# ifndef Cx10_PR_HWY
#  define Cx10_PR_HWY (16U)
# endif

# ifndef Cx11_PR_SOL_L
#  define Cx11_PR_SOL_L (17U)
# endif

# ifndef Cx12_PR_SOL_M
#  define Cx12_PR_SOL_M (18U)
# endif

# ifndef Cx13_PR_SOL_H
#  define Cx13_PR_SOL_H (19U)
# endif

# ifndef Cx14_PR_REGEN
#  define Cx14_PR_REGEN (20U)
# endif

# ifndef Cx15_PR_TF_LO
#  define Cx15_PR_TF_LO (21U)
# endif

# ifndef Cx16_PR_TCS
#  define Cx16_PR_TCS (22U)
# endif

# ifndef Cx17_PR_LD_TCS
#  define Cx17_PR_LD_TCS (23U)
# endif

# ifndef Cx18_PR_DS
#  define Cx18_PR_DS (24U)
# endif

# ifndef Cx19_PR_EV_BLUE
#  define Cx19_PR_EV_BLUE (25U)
# endif

# ifndef Cx1A_PR_EV_NML
#  define Cx1A_PR_EV_NML (26U)
# endif

# ifndef Cx1B_PR_EV_SOC_H
#  define Cx1B_PR_EV_SOC_H (27U)
# endif

# ifndef Cx1C_PR_EV_SOC_L
#  define Cx1C_PR_EV_SOC_L (28U)
# endif

# ifndef Cx1D_PR_EV_HWY
#  define Cx1D_PR_EV_HWY (29U)
# endif

# ifndef Cx1E_PR_SOS
#  define Cx1E_PR_SOS (30U)
# endif

# ifndef Cx1F_PR_ECO_ATC_EV
#  define Cx1F_PR_ECO_ATC_EV (31U)
# endif

# ifndef Cx20_PR_LD_ATC_EV
#  define Cx20_PR_LD_ATC_EV (32U)
# endif

# ifndef Cx21_PR_LD_ATC_HI_EV
#  define Cx21_PR_LD_ATC_HI_EV (33U)
# endif

# ifndef Cx22_PR_LD2_ATC
#  define Cx22_PR_LD2_ATC (34U)
# endif

# ifndef Cx23_PR_LD3_ATC
#  define Cx23_PR_LD3_ATC (35U)
# endif

# ifndef Cx24_PR_LD2_ATC_H
#  define Cx24_PR_LD2_ATC_H (36U)
# endif

# ifndef Cx25_PR_LD3_ATC_H
#  define Cx25_PR_LD3_ATC_H (37U)
# endif

# ifndef Cx26_PR_EC_PRT
#  define Cx26_PR_EC_PRT (38U)
# endif

# ifndef Cx7_
#  define Cx7_ (7U)
# endif

# ifndef Cx8_
#  define Cx8_ (8U)
# endif

# ifndef Cx9_
#  define Cx9_ (9U)
# endif

# ifndef Cx1_On_Mode
#  define Cx1_On_Mode (1U)
# endif

# ifndef Cx2_Head_Unit_Update_Mode
#  define Cx2_Head_Unit_Update_Mode (2U)
# endif

# ifndef Cx1_Day
#  define Cx1_Day (1U)
# endif

# ifndef Cx2_Night
#  define Cx2_Night (2U)
# endif

# ifndef Cx0_Km
#  define Cx0_Km (0U)
# endif

# ifndef Cx1_Mile
#  define Cx1_Mile (1U)
# endif

# ifndef Cx0_Not_support
#  define Cx0_Not_support (0U)
# endif

# ifndef Cx1_Support
#  define Cx1_Support (1U)
# endif

# ifndef Cx0_Deactivated
#  define Cx0_Deactivated (0U)
# endif

# ifndef Cx1_Activated
#  define Cx1_Activated (1U)
# endif

# ifndef Cx2_reserved
#  define Cx2_reserved (2U)
# endif

# ifndef Cx1_Mute_On
#  define Cx1_Mute_On (1U)
# endif

# ifndef Cx0_Non_Navi
#  define Cx0_Non_Navi (0U)
# endif

# ifndef Cx1_Navi
#  define Cx1_Navi (1U)
# endif

# ifndef Cx0_Not_Support
#  define Cx0_Not_Support (0U)
# endif

# ifndef Cx2_Unknown
#  define Cx2_Unknown (2U)
# endif

# ifndef Cx0_Unknown
#  define Cx0_Unknown (0U)
# endif

# ifndef Cx1_Korea
#  define Cx1_Korea (1U)
# endif

# ifndef Cx2_North_America
#  define Cx2_North_America (2U)
# endif

# ifndef Cx3_Europe
#  define Cx3_Europe (3U)
# endif

# ifndef Cx4_Middle_East
#  define Cx4_Middle_East (4U)
# endif

# ifndef Cx5_Australia
#  define Cx5_Australia (5U)
# endif

# ifndef Cx6_South_America
#  define Cx6_South_America (6U)
# endif

# ifndef Cx7_China
#  define Cx7_China (7U)
# endif

# ifndef Cx8_Russia
#  define Cx8_Russia (8U)
# endif

# ifndef Cx9_Turkey
#  define Cx9_Turkey (9U)
# endif

# ifndef CxA_India
#  define CxA_India (10U)
# endif

# ifndef CxB_Japan
#  define CxB_Japan (11U)
# endif

# ifndef Cx0_Booting
#  define Cx0_Booting (0U)
# endif

# ifndef Cx1_Normal_Operation
#  define Cx1_Normal_Operation (1U)
# endif

# ifndef Cx2_No_SD_Card_Map_
#  define Cx2_No_SD_Card_Map_ (2U)
# endif

# ifndef Cx8000_Invalid
#  define Cx8000_Invalid (32768U)
# endif

# ifndef Cx0_Ready
#  define Cx0_Ready (0U)
# endif

# ifndef Cx1_Checking
#  define Cx1_Checking (1U)
# endif

# ifndef Cx3F_Invalid
#  define Cx3F_Invalid (63U)
# endif

# ifndef Cx2_Off
#  define Cx2_Off (2U)
# endif

# ifndef Cx0_inactive
#  define Cx0_inactive (0U)
# endif

# ifndef Cx1_active
#  define Cx1_active (1U)
# endif

# ifndef Cx3_invalid
#  define Cx3_invalid (3U)
# endif

# ifndef Cx1_Disable
#  define Cx1_Disable (1U)
# endif

# ifndef Cx2_Enable
#  define Cx2_Enable (2U)
# endif

# ifndef Cx0_Default_Normal_
#  define Cx0_Default_Normal_ (0U)
# endif

# ifndef Cx1_Learning
#  define Cx1_Learning (1U)
# endif

# ifndef Cx2_Neutralizing
#  define Cx2_Neutralizing (2U)
# endif

# ifndef Cx1_Learning_
#  define Cx1_Learning_ (1U)
# endif

# ifndef Cx1_Calling
#  define Cx1_Calling (1U)
# endif

# ifndef Cx2_Smoking
#  define Cx2_Smoking (2U)
# endif

# ifndef Cx3_Drinking
#  define Cx3_Drinking (3U)
# endif

# ifndef Cx4_RESERVED1
#  define Cx4_RESERVED1 (4U)
# endif

# ifndef Cx5_RESERVED2
#  define Cx5_RESERVED2 (5U)
# endif

# ifndef Cx6_RESERVED3
#  define Cx6_RESERVED3 (6U)
# endif

# ifndef Cx1_On_the_Road
#  define Cx1_On_the_Road (1U)
# endif

# ifndef Cx2_Left_side_Mirror
#  define Cx2_Left_side_Mirror (2U)
# endif

# ifndef Cx3_Right_side_Mirror
#  define Cx3_Right_side_Mirror (3U)
# endif

# ifndef Cx4_Cluster
#  define Cx4_Cluster (4U)
# endif

# ifndef Cx5_Avnt
#  define Cx5_Avnt (5U)
# endif

# ifndef Cx6_Room_Mirror
#  define Cx6_Room_Mirror (6U)
# endif

# ifndef Cx0_Level0
#  define Cx0_Level0 (0U)
# endif

# ifndef Cx1_Level1
#  define Cx1_Level1 (1U)
# endif

# ifndef Cx2_Level2
#  define Cx2_Level2 (2U)
# endif

# ifndef Cx3_Level3
#  define Cx3_Level3 (3U)
# endif

# ifndef Cx4_Level4
#  define Cx4_Level4 (4U)
# endif

# ifndef Cx5_Level5
#  define Cx5_Level5 (5U)
# endif

# ifndef Cx6_RESERVED
#  define Cx6_RESERVED (6U)
# endif

# ifndef Cx0_Opened
#  define Cx0_Opened (0U)
# endif

# ifndef Cx1_Closed
#  define Cx1_Closed (1U)
# endif

# ifndef Cx1_Not_detected
#  define Cx1_Not_detected (1U)
# endif

# ifndef Cx2_Detected
#  define Cx2_Detected (2U)
# endif

# ifndef Cx1_Real_Face
#  define Cx1_Real_Face (1U)
# endif

# ifndef Cx2_Fake_Face
#  define Cx2_Fake_Face (2U)
# endif

# ifndef Cx0_KSS_1_4_Alert_Rather_Alert_
#  define Cx0_KSS_1_4_Alert_Rather_Alert_ (0U)
# endif

# ifndef Cx1_KSS_5_Neither_alert_nor_sleepy_
#  define Cx1_KSS_5_Neither_alert_nor_sleepy_ (1U)
# endif

# ifndef Cx2_KSS_6_Some_sign_of_sleepiness_
#  define Cx2_KSS_6_Some_sign_of_sleepiness_ (2U)
# endif

# ifndef Cx3_KSS_7_over_Sleepy_
#  define Cx3_KSS_7_over_Sleepy_ (3U)
# endif

# ifndef Cx4_Microsleep
#  define Cx4_Microsleep (4U)
# endif

# ifndef Cx5_Sleep
#  define Cx5_Sleep (5U)
# endif

# ifndef Cx7_RESERVED
#  define Cx7_RESERVED (7U)
# endif

# ifndef Cx0_No_Talk
#  define Cx0_No_Talk (0U)
# endif

# ifndef Cx1_Talk
#  define Cx1_Talk (1U)
# endif

# ifndef Cx0_No_Yawn
#  define Cx0_No_Yawn (0U)
# endif

# ifndef Cx1_Yawn
#  define Cx1_Yawn (1U)
# endif

# ifndef Cx1_ADAS_Message_Not_Recognized
#  define Cx1_ADAS_Message_Not_Recognized (1U)
# endif

# ifndef Cx1_No_option_None_Haptic_Option_
#  define Cx1_No_option_None_Haptic_Option_ (1U)
# endif

# ifndef Cx2_Option
#  define Cx2_Option (2U)
# endif

# ifndef Cx1_N_Gear_position_Request_Active
#  define Cx1_N_Gear_position_Request_Active (1U)
# endif

# ifndef Cx0_Buzzer_is_Off
#  define Cx0_Buzzer_is_Off (0U)
# endif

# ifndef Cx1_Buzzer_is_On
#  define Cx1_Buzzer_is_On (1U)
# endif

# ifndef Cx0_AHB_is_normal_mode
#  define Cx0_AHB_is_normal_mode (0U)
# endif

# ifndef Cx1_AHB_is_degraded_mode
#  define Cx1_AHB_is_degraded_mode (1U)
# endif

# ifndef Cx2_AHB_is_defective_mode
#  define Cx2_AHB_is_defective_mode (2U)
# endif

# ifndef Cx0_AHB_is_not_diagnostic_mode
#  define Cx0_AHB_is_not_diagnostic_mode (0U)
# endif

# ifndef Cx1_AHB_is_diagnostic_mode
#  define Cx1_AHB_is_diagnostic_mode (1U)
# endif

# ifndef Cx1_Drift_Mode_ON
#  define Cx1_Drift_Mode_ON (1U)
# endif

# ifndef Cx2_Drift_Mode_OFF
#  define Cx2_Drift_Mode_OFF (2U)
# endif

# ifndef Cx1_Drift_Mode_Activate_ON_
#  define Cx1_Drift_Mode_Activate_ON_ (1U)
# endif

# ifndef Cx2_Drift_Mode_Deactivate_OFF_
#  define Cx2_Drift_Mode_Deactivate_OFF_ (2U)
# endif

# ifndef Cx3_Defective
#  define Cx3_Defective (3U)
# endif

# ifndef Cx0_Invalid
#  define Cx0_Invalid (0U)
# endif

# ifndef Cx1_Valid
#  define Cx1_Valid (1U)
# endif

# ifndef Cx1_Inhibit_Transition_To_4WD
#  define Cx1_Inhibit_Transition_To_4WD (1U)
# endif

# ifndef Cx1_Fail
#  define Cx1_Fail (1U)
# endif

# ifndef Cx0_RSC_is_not_active
#  define Cx0_RSC_is_not_active (0U)
# endif

# ifndef Cx1_RSC_is_active
#  define Cx1_RSC_is_active (1U)
# endif

# ifndef Cx0_RBS_Warning_Lamp_OFF
#  define Cx0_RBS_Warning_Lamp_OFF (0U)
# endif

# ifndef Cx1_RBS_Warning_Lamp_ON
#  define Cx1_RBS_Warning_Lamp_ON (1U)
# endif

# ifndef Cx0_Vacuum_pump_NOT_defective
#  define Cx0_Vacuum_pump_NOT_defective (0U)
# endif

# ifndef Cx1_Vacuum_pump_defective_failed_
#  define Cx1_Vacuum_pump_defective_failed_ (1U)
# endif

# ifndef Cx0_AHB_Warning_Lamp_is_Off
#  define Cx0_AHB_Warning_Lamp_is_Off (0U)
# endif

# ifndef Cx1_AHB_Warning_Lamp_is_On
#  define Cx1_AHB_Warning_Lamp_is_On (1U)
# endif

# ifndef Cx0_None_Option_Default_
#  define Cx0_None_Option_Default_ (0U)
# endif

# ifndef Cx1_Normal
#  define Cx1_Normal (1U)
# endif

# ifndef Cx2_Blockage_Status
#  define Cx2_Blockage_Status (2U)
# endif

# ifndef Cx0_Bright
#  define Cx0_Bright (0U)
# endif

# ifndef Cx1_Dark
#  define Cx1_Dark (1U)
# endif

# ifndef Cx0_No_Value
#  define Cx0_No_Value (0U)
# endif

# ifndef Cx1_1_10m
#  define Cx1_1_10m (1U)
# endif

# ifndef Cx2_11_20m
#  define Cx2_11_20m (2U)
# endif

# ifndef Cx3_21_30m
#  define Cx3_21_30m (3U)
# endif

# ifndef Cx4_31_40m
#  define Cx4_31_40m (4U)
# endif

# ifndef Cx5_41_50m
#  define Cx5_41_50m (5U)
# endif

# ifndef Cx6_51_60m
#  define Cx6_51_60m (6U)
# endif

# ifndef Cx7_61_70m
#  define Cx7_61_70m (7U)
# endif

# ifndef Cx8_71_80m
#  define Cx8_71_80m (8U)
# endif

# ifndef Cx9_81_90m
#  define Cx9_81_90m (9U)
# endif

# ifndef CxA_91_100m
#  define CxA_91_100m (10U)
# endif

# ifndef CxB_101_200m
#  define CxB_101_200m (11U)
# endif

# ifndef CxC_201_300m
#  define CxC_201_300m (12U)
# endif

# ifndef CxD_301_400m
#  define CxD_301_400m (13U)
# endif

# ifndef CxE_401m_
#  define CxE_401m_ (14U)
# endif

# ifndef Cx0_Not_Display
#  define Cx0_Not_Display (0U)
# endif

# ifndef Cx1_Display_Not_blinking_
#  define Cx1_Display_Not_blinking_ (1U)
# endif

# ifndef Cx2_Display_blinking_
#  define Cx2_Display_blinking_ (2U)
# endif

# ifndef Cx0_Auto_Set_Speed_Off
#  define Cx0_Auto_Set_Speed_Off (0U)
# endif

# ifndef Cx1_Auto_Set_Speed_On
#  define Cx1_Auto_Set_Speed_On (1U)
# endif

# ifndef Cx0_None_Auto_Function_Delete_Menu_
#  define Cx0_None_Auto_Function_Delete_Menu_ (0U)
# endif

# ifndef Cx1_Auto_Off
#  define Cx1_Auto_Off (1U)
# endif

# ifndef Cx2_Auto_On
#  define Cx2_Auto_On (2U)
# endif

# ifndef Cx3_Invalid_GRAY_
#  define Cx3_Invalid_GRAY_ (3U)
# endif

# ifndef Cx0_None_Offset_Function
#  define Cx0_None_Offset_Function (0U)
# endif

# ifndef Cx1_10kph_or_10mph
#  define Cx1_10kph_or_10mph (1U)
# endif

# ifndef Cx2_5kph_or_5mph
#  define Cx2_5kph_or_5mph (2U)
# endif

# ifndef Cx3_0kph_or_0mph
#  define Cx3_0kph_or_0mph (3U)
# endif

# ifndef Cx4_5kph_or_5mph
#  define Cx4_5kph_or_5mph (4U)
# endif

# ifndef Cx5_10kph_or_10mph
#  define Cx5_10kph_or_10mph (5U)
# endif

# ifndef Cx7_Invalid_GRAY_
#  define Cx7_Invalid_GRAY_ (7U)
# endif

# ifndef Cx1_10kph_or_5mph
#  define Cx1_10kph_or_5mph (1U)
# endif

# ifndef Cx2_5kph_or_3mph
#  define Cx2_5kph_or_3mph (2U)
# endif

# ifndef Cx4_5kph_or_3mph
#  define Cx4_5kph_or_3mph (4U)
# endif

# ifndef Cx5_10kph_or_5mph
#  define Cx5_10kph_or_5mph (5U)
# endif

# ifndef Cx0_No_Recognition_Default_
#  define Cx0_No_Recognition_Default_ (0U)
# endif

# ifndef Cx1_Recognition
#  define Cx1_Recognition (1U)
# endif

# ifndef Cx0_None_ISLW_Option_Default_
#  define Cx0_None_ISLW_Option_Default_ (0U)
# endif

# ifndef Cx1_System_Disabled_by_USM
#  define Cx1_System_Disabled_by_USM (1U)
# endif

# ifndef Cx2_System_Enable_by_USM
#  define Cx2_System_Enable_by_USM (2U)
# endif

# ifndef Cx3_Invalid_
#  define Cx3_Invalid_ (3U)
# endif

# ifndef Cx0_None_Default_
#  define Cx0_None_Default_ (0U)
# endif

# ifndef Cx1_Overlap_Sign
#  define Cx1_Overlap_Sign (1U)
# endif

# ifndef Cx0_Normal_Default_
#  define Cx0_Normal_Default_ (0U)
# endif

# ifndef Cx1_System_Fail
#  define Cx1_System_Fail (1U)
# endif

# ifndef Cx2_ISLW_Temporary_Unavailable
#  define Cx2_ISLW_Temporary_Unavailable (2U)
# endif

# ifndef Cx3_Off
#  define Cx3_Off (3U)
# endif

# ifndef Cx0_No_Left_Line_Departure
#  define Cx0_No_Left_Line_Departure (0U)
# endif

# ifndef Cx1_Left_Line_Departure
#  define Cx1_Left_Line_Departure (1U)
# endif

# ifndef Cx0_No_Right_Line_Departure
#  define Cx0_No_Right_Line_Departure (0U)
# endif

# ifndef Cx1_Right_Line_Departure
#  define Cx1_Right_Line_Departure (1U)
# endif

# ifndef Cx1_Lane_Departure_Warning
#  define Cx1_Lane_Departure_Warning (1U)
# endif

# ifndef Cx3_Haptic_Warning_Display
#  define Cx3_Haptic_Warning_Display (3U)
# endif

# ifndef Cx1_Unavailable_Grey_On_
#  define Cx1_Unavailable_Grey_On_ (1U)
# endif

# ifndef Cx2_Lane_Recognized_Green_On_
#  define Cx2_Lane_Recognized_Green_On_ (2U)
# endif

# ifndef Cx3_Lane_Departure_Green_Blink_
#  define Cx3_Lane_Departure_Green_Blink_ (3U)
# endif

# ifndef Cx4_System_Fail_Orange_On_
#  define Cx4_System_Fail_Orange_On_ (4U)
# endif

# ifndef Cx5_Not_Calibrated_Orange_Blink_
#  define Cx5_Not_Calibrated_Orange_Blink_ (5U)
# endif

# ifndef Cx6_Off_for_Regulation_Orange_On_
#  define Cx6_Off_for_Regulation_Orange_On_ (6U)
# endif

# ifndef Cx7_Temp_Unavailable_Orange_On_
#  define Cx7_Temp_Unavailable_Orange_On_ (7U)
# endif

# ifndef Cx1_USM_Off
#  define Cx1_USM_Off (1U)
# endif

# ifndef Cx2_USM_On
#  define Cx2_USM_On (2U)
# endif

# ifndef Cx2_Direct_Off
#  define Cx2_Direct_Off (2U)
# endif

# ifndef Cx1_High_On
#  define Cx1_High_On (1U)
# endif

# ifndef Cx2_High_Inactive
#  define Cx2_High_Inactive (2U)
# endif

# ifndef Cx5_Reseved
#  define Cx5_Reseved (5U)
# endif

# ifndef Cx6_Not_Used
#  define Cx6_Not_Used (6U)
# endif

# ifndef Cx7_Error_Indicator
#  define Cx7_Error_Indicator (7U)
# endif

# ifndef Cx1_Low_On
#  define Cx1_Low_On (1U)
# endif

# ifndef Cx2_Low_Inactive
#  define Cx2_Low_Inactive (2U)
# endif

# ifndef Cx0_Light_Sw_Off
#  define Cx0_Light_Sw_Off (0U)
# endif

# ifndef Cx1_Tail_Sw_On
#  define Cx1_Tail_Sw_On (1U)
# endif

# ifndef Cx2_HeadLamp_Low_Sw_On
#  define Cx2_HeadLamp_Low_Sw_On (2U)
# endif

# ifndef Cx3_AutoLight_Sw_On
#  define Cx3_AutoLight_Sw_On (3U)
# endif

# ifndef Cx0_Off_Inactive_
#  define Cx0_Off_Inactive_ (0U)
# endif

# ifndef Cx1_On_Active_
#  define Cx1_On_Active_ (1U)
# endif

# ifndef Cx1_Active_Off_Flasher_Off_
#  define Cx1_Active_Off_Flasher_Off_ (1U)
# endif

# ifndef Cx2_Active_On_Flasher_On_
#  define Cx2_Active_On_Flasher_On_ (2U)
# endif

# ifndef Cx1_MDPS_Fault
#  define Cx1_MDPS_Fault (1U)
# endif

# ifndef Cx2_Fault_Except_MDPS
#  define Cx2_Fault_Except_MDPS (2U)
# endif

# ifndef Cx3_Both_Fault
#  define Cx3_Both_Fault (3U)
# endif

# ifndef Cx0_Comfort_Mode
#  define Cx0_Comfort_Mode (0U)
# endif

# ifndef Cx1_Sport_Mode
#  define Cx1_Sport_Mode (1U)
# endif

# ifndef Cx2_Sport_Mode
#  define Cx2_Sport_Mode (2U)
# endif

# ifndef Cx3_Chauffeur_Mode
#  define Cx3_Chauffeur_Mode (3U)
# endif

# ifndef Cx4_Mild_Mode
#  define Cx4_Mild_Mode (4U)
# endif

# ifndef Cx5_RESERVED
#  define Cx5_RESERVED (5U)
# endif

# ifndef Cx0_Current_Consumption_is_Low
#  define Cx0_Current_Consumption_is_Low (0U)
# endif

# ifndef Cx1_Current_Consumption_is_High
#  define Cx1_Current_Consumption_is_High (1U)
# endif

# ifndef Cx0_Not_in_fail_state
#  define Cx0_Not_in_fail_state (0U)
# endif

# ifndef Cx1_In_fail_state
#  define Cx1_In_fail_state (1U)
# endif

# ifndef Cx0_No_fault
#  define Cx0_No_fault (0U)
# endif

# ifndef Cx1_Faulty
#  define Cx1_Faulty (1U)
# endif

# ifndef Cx1_Unavailable
#  define Cx1_Unavailable (1U)
# endif

# ifndef Cx1_Loam_Flag_Warning_Display
#  define Cx1_Loam_Flag_Warning_Display (1U)
# endif

# ifndef Cx0_No_Failure
#  define Cx0_No_Failure (0U)
# endif

# ifndef Cx1_Failure_about_Pa_can_message
#  define Cx1_Failure_about_Pa_can_message (1U)
# endif

# ifndef Cx0_C_MDPS
#  define Cx0_C_MDPS (0U)
# endif

# ifndef Cx1_R_MDPS_Dual_Pinion_
#  define Cx1_R_MDPS_Dual_Pinion_ (1U)
# endif

# ifndef Cx2_R_MDPS_Belt_
#  define Cx2_R_MDPS_Belt_ (2U)
# endif

# ifndef Cx0_VSM_Control_inactivated
#  define Cx0_VSM_Control_inactivated (0U)
# endif

# ifndef Cx1_VSM_Control_Activated
#  define Cx1_VSM_Control_Activated (1U)
# endif

# ifndef Cx0_MDPS_is_not_defective
#  define Cx0_MDPS_is_not_defective (0U)
# endif

# ifndef Cx1_MDPS_is_defective
#  define Cx1_MDPS_is_defective (1U)
# endif

# ifndef Cx0_VSM1_signal_is_not_error
#  define Cx0_VSM1_signal_is_not_error (0U)
# endif

# ifndef Cx1_VSM_signal_is_error
#  define Cx1_VSM_signal_is_error (1U)
# endif

# ifndef Cx0_Not_Support_Country
#  define Cx0_Not_Support_Country (0U)
# endif

# ifndef Cx1_Support_Country
#  define Cx1_Support_Country (1U)
# endif

# ifndef Cx0_Driving_Side_Left
#  define Cx0_Driving_Side_Left (0U)
# endif

# ifndef Cx1_Driving_Side_Right
#  define Cx1_Driving_Side_Right (1U)
# endif

# ifndef Cx1_HERE
#  define Cx1_HERE (1U)
# endif

# ifndef Cx2_TomTom
#  define Cx2_TomTom (2U)
# endif

# ifndef Cx3_Zenrin
#  define Cx3_Zenrin (3U)
# endif

# ifndef Cx4_HMNS
#  define Cx4_HMNS (4U)
# endif

# ifndef Cx5_Baidu
#  define Cx5_Baidu (5U)
# endif

# ifndef Cx0_Kilometers_per_hour
#  define Cx0_Kilometers_per_hour (0U)
# endif

# ifndef Cx1_Mile_per_hour
#  define Cx1_Mile_per_hour (1U)
# endif

# ifndef Cx0_Passive_or_TCS_function
#  define Cx0_Passive_or_TCS_function (0U)
# endif

# ifndef Cx1_MSR_control_active
#  define Cx1_MSR_control_active (1U)
# endif

# ifndef Cx1_Fold
#  define Cx1_Fold (1U)
# endif

# ifndef Cx2_Unfold
#  define Cx2_Unfold (2U)
# endif

# ifndef Cx00_Unknown
#  define Cx00_Unknown (0U)
# endif

# ifndef Cx01_Under100m
#  define Cx01_Under100m (1U)
# endif

# ifndef Cx02_100m
#  define Cx02_100m (2U)
# endif

# ifndef Cx03_200m
#  define Cx03_200m (3U)
# endif

# ifndef Cx04_300m
#  define Cx04_300m (4U)
# endif

# ifndef Cx05_400m
#  define Cx05_400m (5U)
# endif

# ifndef Cx06_500m
#  define Cx06_500m (6U)
# endif

# ifndef Cx07_600m
#  define Cx07_600m (7U)
# endif

# ifndef Cx08_700m
#  define Cx08_700m (8U)
# endif

# ifndef Cx09_800m
#  define Cx09_800m (9U)
# endif

# ifndef Cx0A_900m
#  define Cx0A_900m (10U)
# endif

# ifndef Cx0B_1000m
#  define Cx0B_1000m (11U)
# endif

# ifndef Cx0C_1100m
#  define Cx0C_1100m (12U)
# endif

# ifndef Cx0D_1200m
#  define Cx0D_1200m (13U)
# endif

# ifndef Cx0E_1300m
#  define Cx0E_1300m (14U)
# endif

# ifndef Cx0F_1400m
#  define Cx0F_1400m (15U)
# endif

# ifndef Cx10_1500m
#  define Cx10_1500m (16U)
# endif

# ifndef Cx11_1600m
#  define Cx11_1600m (17U)
# endif

# ifndef Cx12_1700m
#  define Cx12_1700m (18U)
# endif

# ifndef Cx13_1800m
#  define Cx13_1800m (19U)
# endif

# ifndef Cx14_1900m
#  define Cx14_1900m (20U)
# endif

# ifndef Cx15_2000m
#  define Cx15_2000m (21U)
# endif

# ifndef Cx16_2100m
#  define Cx16_2100m (22U)
# endif

# ifndef Cx17_2200m
#  define Cx17_2200m (23U)
# endif

# ifndef Cx18_2300m
#  define Cx18_2300m (24U)
# endif

# ifndef Cx19_2400m
#  define Cx19_2400m (25U)
# endif

# ifndef Cx1A_2500m
#  define Cx1A_2500m (26U)
# endif

# ifndef Cx1B_2600m
#  define Cx1B_2600m (27U)
# endif

# ifndef Cx1C_2700m
#  define Cx1C_2700m (28U)
# endif

# ifndef Cx1D_2800m
#  define Cx1D_2800m (29U)
# endif

# ifndef Cx1E_2900m
#  define Cx1E_2900m (30U)
# endif

# ifndef Cx1F_3000m
#  define Cx1F_3000m (31U)
# endif

# ifndef Cx20_3100m
#  define Cx20_3100m (32U)
# endif

# ifndef Cx21_3200m
#  define Cx21_3200m (33U)
# endif

# ifndef Cx22_3300m
#  define Cx22_3300m (34U)
# endif

# ifndef Cx23_3400m
#  define Cx23_3400m (35U)
# endif

# ifndef Cx24_3500m
#  define Cx24_3500m (36U)
# endif

# ifndef Cx25_3600m
#  define Cx25_3600m (37U)
# endif

# ifndef Cx26_3700m
#  define Cx26_3700m (38U)
# endif

# ifndef Cx27_3800m
#  define Cx27_3800m (39U)
# endif

# ifndef Cx28_3900m
#  define Cx28_3900m (40U)
# endif

# ifndef Cx29_4000m
#  define Cx29_4000m (41U)
# endif

# ifndef Cx2A_4100m
#  define Cx2A_4100m (42U)
# endif

# ifndef Cx2B_4200m
#  define Cx2B_4200m (43U)
# endif

# ifndef Cx2C_4300m
#  define Cx2C_4300m (44U)
# endif

# ifndef Cx2D_4400m
#  define Cx2D_4400m (45U)
# endif

# ifndef Cx2E_4500m
#  define Cx2E_4500m (46U)
# endif

# ifndef Cx2F_4600m
#  define Cx2F_4600m (47U)
# endif

# ifndef Cx30_4700m
#  define Cx30_4700m (48U)
# endif

# ifndef Cx31_4800m
#  define Cx31_4800m (49U)
# endif

# ifndef Cx32_4900m
#  define Cx32_4900m (50U)
# endif

# ifndef Cx33_5000m
#  define Cx33_5000m (51U)
# endif

# ifndef Cx34_5100m
#  define Cx34_5100m (52U)
# endif

# ifndef Cx35_5200m
#  define Cx35_5200m (53U)
# endif

# ifndef Cx36_5300m
#  define Cx36_5300m (54U)
# endif

# ifndef Cx37_5400m
#  define Cx37_5400m (55U)
# endif

# ifndef Cx38_5500m
#  define Cx38_5500m (56U)
# endif

# ifndef Cx39_5600m
#  define Cx39_5600m (57U)
# endif

# ifndef Cx3A_5700m
#  define Cx3A_5700m (58U)
# endif

# ifndef Cx3B_5800m
#  define Cx3B_5800m (59U)
# endif

# ifndef Cx3C_5900m
#  define Cx3C_5900m (60U)
# endif

# ifndef Cx3D_6000m
#  define Cx3D_6000m (61U)
# endif

# ifndef Cx3E_Over6_000m
#  define Cx3E_Over6_000m (62U)
# endif

# ifndef Cx1_Freeway
#  define Cx1_Freeway (1U)
# endif

# ifndef Cx2_Arterial_Cityfreeway_
#  define Cx2_Arterial_Cityfreeway_ (2U)
# endif

# ifndef Cx3_County
#  define Cx3_County (3U)
# endif

# ifndef Cx4_Collector
#  define Cx4_Collector (4U)
# endif

# ifndef Cx5_Local
#  define Cx5_Local (5U)
# endif

# ifndef Cx6_Etc_ferry_unpaved_
#  define Cx6_Etc_ferry_unpaved_ (6U)
# endif

# ifndef Cx01_Under_5kph_mph_
#  define Cx01_Under_5kph_mph_ (1U)
# endif

# ifndef Cx02_7kph_mph_
#  define Cx02_7kph_mph_ (2U)
# endif

# ifndef Cx03_10kph_mph_
#  define Cx03_10kph_mph_ (3U)
# endif

# ifndef Cx04_15kph_mph_
#  define Cx04_15kph_mph_ (4U)
# endif

# ifndef Cx05_20kph_mph_
#  define Cx05_20kph_mph_ (5U)
# endif

# ifndef Cx06_25kph_mph_
#  define Cx06_25kph_mph_ (6U)
# endif

# ifndef Cx07_30kph_mph_
#  define Cx07_30kph_mph_ (7U)
# endif

# ifndef Cx08_35kph_mph_
#  define Cx08_35kph_mph_ (8U)
# endif

# ifndef Cx09_40kph_mph_
#  define Cx09_40kph_mph_ (9U)
# endif

# ifndef Cx0A_45kph_mph_
#  define Cx0A_45kph_mph_ (10U)
# endif

# ifndef Cx0B_50kph_mph_
#  define Cx0B_50kph_mph_ (11U)
# endif

# ifndef Cx0C_55kph_mph_
#  define Cx0C_55kph_mph_ (12U)
# endif

# ifndef Cx0D_60kph_mph_
#  define Cx0D_60kph_mph_ (13U)
# endif

# ifndef Cx0E_65kph_mph_
#  define Cx0E_65kph_mph_ (14U)
# endif

# ifndef Cx0F_70kph_mph_
#  define Cx0F_70kph_mph_ (15U)
# endif

# ifndef Cx10_75kph_mph_
#  define Cx10_75kph_mph_ (16U)
# endif

# ifndef Cx11_80kph_mph_
#  define Cx11_80kph_mph_ (17U)
# endif

# ifndef Cx12_85kph_mph_
#  define Cx12_85kph_mph_ (18U)
# endif

# ifndef Cx13_90kph_mph_
#  define Cx13_90kph_mph_ (19U)
# endif

# ifndef Cx14_95kph_mph_
#  define Cx14_95kph_mph_ (20U)
# endif

# ifndef Cx15_100kph_mph_
#  define Cx15_100kph_mph_ (21U)
# endif

# ifndef Cx16_105kph_mph_
#  define Cx16_105kph_mph_ (22U)
# endif

# ifndef Cx17_110kph_mph_
#  define Cx17_110kph_mph_ (23U)
# endif

# ifndef Cx18_115kph_mph_
#  define Cx18_115kph_mph_ (24U)
# endif

# ifndef Cx19_120kph_mph_
#  define Cx19_120kph_mph_ (25U)
# endif

# ifndef Cx1A_130kph_mph_
#  define Cx1A_130kph_mph_ (26U)
# endif

# ifndef Cx1B_140kph_mph_
#  define Cx1B_140kph_mph_ (27U)
# endif

# ifndef Cx1C_150kph_mph_
#  define Cx1C_150kph_mph_ (28U)
# endif

# ifndef Cx1D_160kph_mph_
#  define Cx1D_160kph_mph_ (29U)
# endif

# ifndef Cx1E_Unlimited
#  define Cx1E_Unlimited (30U)
# endif

# ifndef Cx1F_Invalid
#  define Cx1F_Invalid (31U)
# endif

# ifndef Cx1E_Over160kph_mph_
#  define Cx1E_Over160kph_mph_ (30U)
# endif

# ifndef Cx0_False
#  define Cx0_False (0U)
# endif

# ifndef Cx1_True
#  define Cx1_True (1U)
# endif

# ifndef Cx0_Not_coded
#  define Cx0_Not_coded (0U)
# endif

# ifndef Cx1_Coded
#  define Cx1_Coded (1U)
# endif

# ifndef Cx0_nomarl
#  define Cx0_nomarl (0U)
# endif

# ifndef Cx1_pad_wear
#  define Cx1_pad_wear (1U)
# endif

# ifndef Cx3_invaild_or_Error
#  define Cx3_invaild_or_Error (3U)
# endif

# ifndef Cx1_to_RSPA_Remote_Cranking
#  define Cx1_to_RSPA_Remote_Cranking (1U)
# endif

# ifndef Cx2_to_Normal_Cranking
#  define Cx2_to_Normal_Cranking (2U)
# endif

# ifndef Cx3_to_IG_OFF
#  define Cx3_to_IG_OFF (3U)
# endif

# ifndef Cx1_Soft_Brake
#  define Cx1_Soft_Brake (1U)
# endif

# ifndef Cx2_Hard_1_Brake
#  define Cx2_Hard_1_Brake (2U)
# endif

# ifndef Cx3_Hard_2_Brake
#  define Cx3_Hard_2_Brake (3U)
# endif

# ifndef Cx1_release_request
#  define Cx1_release_request (1U)
# endif

# ifndef Cx2_normal_apply
#  define Cx2_normal_apply (2U)
# endif

# ifndef Cx0_Initial_Inactive_
#  define Cx0_Initial_Inactive_ (0U)
# endif

# ifndef Cx1_HeadLamp_On
#  define Cx1_HeadLamp_On (1U)
# endif

# ifndef Cx1_Change_Request
#  define Cx1_Change_Request (1U)
# endif

# ifndef Cx0_init
#  define Cx0_init (0U)
# endif

# ifndef Cx1_Not_found
#  define Cx1_Not_found (1U)
# endif

# ifndef Cx2_Reverse_perpendicular
#  define Cx2_Reverse_perpendicular (2U)
# endif

# ifndef Cx3_Reverse_parallel
#  define Cx3_Reverse_parallel (3U)
# endif

# ifndef Cx4_Reverse_diagonal
#  define Cx4_Reverse_diagonal (4U)
# endif

# ifndef Cx5_Forward_diagonal
#  define Cx5_Forward_diagonal (5U)
# endif

# ifndef Cx1_OS_Mirror_Fold
#  define Cx1_OS_Mirror_Fold (1U)
# endif

# ifndef Cx2_OS_Mirror_Unfold
#  define Cx2_OS_Mirror_Unfold (2U)
# endif

# ifndef Cx0_RSPA_not_applied
#  define Cx0_RSPA_not_applied (0U)
# endif

# ifndef Cx1_RSPA_applied
#  define Cx1_RSPA_applied (1U)
# endif

# ifndef Cx1_SmartPhone
#  define Cx1_SmartPhone (1U)
# endif

# ifndef Cx2_Fob
#  define Cx2_Fob (2U)
# endif

# ifndef Cx0_RSPA_not_recognized
#  define Cx0_RSPA_not_recognized (0U)
# endif

# ifndef Cx1_Init
#  define Cx1_Init (1U)
# endif

# ifndef Cx2_New_Start
#  define Cx2_New_Start (2U)
# endif

# ifndef Cx3_Ready_OK
#  define Cx3_Ready_OK (3U)
# endif

# ifndef Cx4_Assist_Req
#  define Cx4_Assist_Req (4U)
# endif

# ifndef Cx5_Assist_OK
#  define Cx5_Assist_OK (5U)
# endif

# ifndef Cx6_Assist_Fail
#  define Cx6_Assist_Fail (6U)
# endif

# ifndef Cx7_Abort
#  define Cx7_Abort (7U)
# endif

# ifndef Cx8_Ready_Fail
#  define Cx8_Ready_Fail (8U)
# endif

# ifndef Cx1_Stop_control_is_required
#  define Cx1_Stop_control_is_required (1U)
# endif

# ifndef Cx0_Idle
#  define Cx0_Idle (0U)
# endif

# ifndef Cx2_R
#  define Cx2_R (2U)
# endif

# ifndef Cx3_N
#  define Cx3_N (3U)
# endif

# ifndef Cx4_D
#  define Cx4_D (4U)
# endif

# ifndef Cx3_Level_3
#  define Cx3_Level_3 (3U)
# endif

# ifndef Cx4_Level_4
#  define Cx4_Level_4 (4U)
# endif

# ifndef Cx5_Level_5
#  define Cx5_Level_5 (5U)
# endif

# ifndef Cx0_No_Driver_Override
#  define Cx0_No_Driver_Override (0U)
# endif

# ifndef Cx1_Driver_Override
#  define Cx1_Driver_Override (1U)
# endif

# ifndef Cx0_SCC_is_not_equipped
#  define Cx0_SCC_is_not_equipped (0U)
# endif

# ifndef Cx1_SCC_is_equipped
#  define Cx1_SCC_is_equipped (1U)
# endif

# ifndef Cx1_Limited_No_Limitation
#  define Cx1_Limited_No_Limitation (1U)
# endif

# ifndef Cx2_Acceleration_Limited
#  define Cx2_Acceleration_Limited (2U)
# endif

# ifndef Cx3_Deceleration_Limited
#  define Cx3_Deceleration_Limited (3U)
# endif

# ifndef Cx0_No_switch_off_condition_detected
#  define Cx0_No_switch_off_condition_detected (0U)
# endif

# ifndef Cx1_Switch_off_condition_detected
#  define Cx1_Switch_off_condition_detected (1U)
# endif

# ifndef Cx1_Enable_SCC_torque_request
#  define Cx1_Enable_SCC_torque_request (1U)
# endif

# ifndef Cx1_Lamp_ON_UREA_EMPTY_
#  define Cx1_Lamp_ON_UREA_EMPTY_ (1U)
# endif

# ifndef Cx1_Lamp_ON
#  define Cx1_Lamp_ON (1U)
# endif

# ifndef Cx0_Not_Calculated_Route_MPP_
#  define Cx0_Not_Calculated_Route_MPP_ (0U)
# endif

# ifndef Cx1_Part_of_Calculated_Route
#  define Cx1_Part_of_Calculated_Route (1U)
# endif

# ifndef Cx2_Off_Route_or_Recalculating
#  define Cx2_Off_Route_or_Recalculating (2U)
# endif

# ifndef Cx0_Part_of_a_divided_road
#  define Cx0_Part_of_a_divided_road (0U)
# endif

# ifndef Cx1_Not_part_of_a_divided_road
#  define Cx1_Not_part_of_a_divided_road (1U)
# endif

# ifndef Cx2_Arterial_City_freeway_
#  define Cx2_Arterial_City_freeway_ (2U)
# endif

# ifndef Cx1A_125kph_mph_
#  define Cx1A_125kph_mph_ (26U)
# endif

# ifndef Cx1B_130kph_mph_
#  define Cx1B_130kph_mph_ (27U)
# endif

# ifndef Cx1C_135kph_mph_
#  define Cx1C_135kph_mph_ (28U)
# endif

# ifndef Cx1D_140kph_mph_
#  define Cx1D_140kph_mph_ (29U)
# endif

# ifndef Cx0_ACC_OFF
#  define Cx0_ACC_OFF (0U)
# endif

# ifndef Cx1_ACC_ON
#  define Cx1_ACC_ON (1U)
# endif

# ifndef Cx0_No_Auth
#  define Cx0_No_Auth (0U)
# endif

# ifndef Cx1_Preauthentication
#  define Cx1_Preauthentication (1U)
# endif

# ifndef Cx2_Authentication
#  define Cx2_Authentication (2U)
# endif

# ifndef Cx3_Fast_Restart
#  define Cx3_Fast_Restart (3U)
# endif

# ifndef Cx0_Cluster_ACC_Indicator_Off
#  define Cx0_Cluster_ACC_Indicator_Off (0U)
# endif

# ifndef Cx1_Cluster_ACC_Indicator_On
#  define Cx1_Cluster_ACC_Indicator_On (1U)
# endif

# ifndef Cx0_IGN1_Off
#  define Cx0_IGN1_Off (0U)
# endif

# ifndef Cx1_IGN1_On
#  define Cx1_IGN1_On (1U)
# endif

# ifndef Cx0_IGN2_Off
#  define Cx0_IGN2_Off (0U)
# endif

# ifndef Cx1_IGN2_On
#  define Cx1_IGN2_On (1U)
# endif

# ifndef Cx1_Remote_Key_Cranking_Mode
#  define Cx1_Remote_Key_Cranking_Mode (1U)
# endif

# ifndef Cx1_Remote_Key_Engine_Running
#  define Cx1_Remote_Key_Engine_Running (1U)
# endif

# ifndef Cx2_Unlock
#  define Cx2_Unlock (2U)
# endif

# ifndef Cx0_Starter_Relay_Output_Off
#  define Cx0_Starter_Relay_Output_Off (0U)
# endif

# ifndef Cx1_Starter_Relay_Output_On
#  define Cx1_Starter_Relay_Output_On (1U)
# endif

# ifndef Cx1_Tele_Cranking_Mode
#  define Cx1_Tele_Cranking_Mode (1U)
# endif

# ifndef Cx1_Tele_Engine_Running
#  define Cx1_Tele_Engine_Running (1U)
# endif

# ifndef Cx00_Off
#  define Cx00_Off (0U)
# endif

# ifndef Cx01_OFF_TO_START
#  define Cx01_OFF_TO_START (1U)
# endif

# ifndef Cx02_WAIT_ESCL_UNLOCK_ACC
#  define Cx02_WAIT_ESCL_UNLOCK_ACC (2U)
# endif

# ifndef Cx03_ACC
#  define Cx03_ACC (3U)
# endif

# ifndef Cx04_ACC_SEARCH
#  define Cx04_ACC_SEARCH (4U)
# endif

# ifndef Cx05_ACC_TO_START
#  define Cx05_ACC_TO_START (5U)
# endif

# ifndef Cx06_IGN
#  define Cx06_IGN (6U)
# endif

# ifndef Cx07_IGN_SEARCH
#  define Cx07_IGN_SEARCH (7U)
# endif

# ifndef Cx08_WAIT_ESCL_UNLOCK_OFF_TO_START
#  define Cx08_WAIT_ESCL_UNLOCK_OFF_TO_START (8U)
# endif

# ifndef Cx09_WAIT_ESCL_UNLOCK_START
#  define Cx09_WAIT_ESCL_UNLOCK_START (9U)
# endif

# ifndef Cx0A_WAIT_IGN1_ACC
#  define Cx0A_WAIT_IGN1_ACC (10U)
# endif

# ifndef Cx0B_WAIT_IGN1_ACC_SEARCH
#  define Cx0B_WAIT_IGN1_ACC_SEARCH (11U)
# endif

# ifndef Cx0C_WAIT_IGN1_ACC_TO_START
#  define Cx0C_WAIT_IGN1_ACC_TO_START (12U)
# endif

# ifndef Cx0D_WAIT_IGN1_UNLOCK_OFF_TO_START
#  define Cx0D_WAIT_IGN1_UNLOCK_OFF_TO_START (13U)
# endif

# ifndef Cx0E_WAIT_IGN1_UNLOCK_START
#  define Cx0E_WAIT_IGN1_UNLOCK_START (14U)
# endif

# ifndef Cx0F_START
#  define Cx0F_START (15U)
# endif

# ifndef Cx10_ENGINE_RUNNING
#  define Cx10_ENGINE_RUNNING (16U)
# endif

# ifndef Cx11_Reserved
#  define Cx11_Reserved (17U)
# endif

# ifndef Cx12_Reserved
#  define Cx12_Reserved (18U)
# endif

# ifndef Cx13_Reserved
#  define Cx13_Reserved (19U)
# endif

# ifndef Cx14_Reserved
#  define Cx14_Reserved (20U)
# endif

# ifndef Cx15_Reserved
#  define Cx15_Reserved (21U)
# endif

# ifndef Cx16_Reserved
#  define Cx16_Reserved (22U)
# endif

# ifndef Cx17_Reserved
#  define Cx17_Reserved (23U)
# endif

# ifndef Cx18_Reserved
#  define Cx18_Reserved (24U)
# endif

# ifndef Cx19_Reserved
#  define Cx19_Reserved (25U)
# endif

# ifndef Cx1A_Reserved
#  define Cx1A_Reserved (26U)
# endif

# ifndef Cx1B_Reserved
#  define Cx1B_Reserved (27U)
# endif

# ifndef Cx1C_Reserved
#  define Cx1C_Reserved (28U)
# endif

# ifndef Cx1D_Reserved
#  define Cx1D_Reserved (29U)
# endif

# ifndef Cx1E_Not_Used
#  define Cx1E_Not_Used (30U)
# endif

# ifndef Cx1F_Error_Indicator
#  define Cx1F_Error_Indicator (31U)
# endif

# ifndef Cx0_Released
#  define Cx0_Released (0U)
# endif

# ifndef Cx1_Pressed
#  define Cx1_Pressed (1U)
# endif

# ifndef Cx1_ON_CAN_Type_
#  define Cx1_ON_CAN_Type_ (1U)
# endif

# ifndef Cx1_Thermal_Protection_Active
#  define Cx1_Thermal_Protection_Active (1U)
# endif

# ifndef Cx2_Initialized_Status
#  define Cx2_Initialized_Status (2U)
# endif

# ifndef Cx3_Undefined_ECU_Error
#  define Cx3_Undefined_ECU_Error (3U)
# endif

# ifndef Cx4_Switch_Error
#  define Cx4_Switch_Error (4U)
# endif

# ifndef Cx5_Voltage_error
#  define Cx5_Voltage_error (5U)
# endif

# ifndef Cx6_Complex_Error
#  define Cx6_Complex_Error (6U)
# endif

# ifndef Cx0_passive_gear_change_allowed_
#  define Cx0_passive_gear_change_allowed_ (0U)
# endif

# ifndef Cx1_active_gear_change_not_allowed_
#  define Cx1_active_gear_change_not_allowed_ (1U)
# endif

# ifndef Cx1_Pre_TCS_Active
#  define Cx1_Pre_TCS_Active (1U)
# endif

# ifndef Cx1_Brake_On_Request
#  define Cx1_Brake_On_Request (1U)
# endif

# ifndef Cx0_CDA_transition_is_available
#  define Cx0_CDA_transition_is_available (0U)
# endif

# ifndef Cx1_TCU_prohibits_CDA_transition
#  define Cx1_TCU_prohibits_CDA_transition (1U)
# endif

# ifndef Cx0_TCU_TrgtGearSta
#  define Cx0_TCU_TrgtGearSta (0U)
# endif

# ifndef Cx1_TCU_CluTrgtGearSta
#  define Cx1_TCU_CluTrgtGearSta (1U)
# endif

# ifndef Cx2_Eco
#  define Cx2_Eco (2U)
# endif

# ifndef Cx3_Eco_
#  define Cx3_Eco_ (3U)
# endif

# ifndef Cx4_Sport
#  define Cx4_Sport (4U)
# endif

# ifndef Cx5_Sport_
#  define Cx5_Sport_ (5U)
# endif

# ifndef Cx6_Snow
#  define Cx6_Snow (6U)
# endif

# ifndef Cx000_Max_reduction
#  define Cx000_Max_reduction (0)
# endif

# ifndef Cx7FF_No_reduction
#  define Cx7FF_No_reduction (2047)
# endif

# ifndef Cx0_No_blink
#  define Cx0_No_blink (0U)
# endif

# ifndef Cx1_Request_lamp_blinking
#  define Cx1_Request_lamp_blinking (1U)
# endif

# ifndef Cx0_no_gear_change
#  define Cx0_no_gear_change (0U)
# endif

# ifndef Cx1_gear_change_is_active
#  define Cx1_gear_change_is_active (1U)
# endif

# ifndef Cx3_3_Speed_AT_or_DCT
#  define Cx3_3_Speed_AT_or_DCT (3U)
# endif

# ifndef Cx4_4_Speed_AT_or_DCT
#  define Cx4_4_Speed_AT_or_DCT (4U)
# endif

# ifndef Cx5_5_Speed_AT_or_DCT
#  define Cx5_5_Speed_AT_or_DCT (5U)
# endif

# ifndef Cx6_6_Speed_AT_or_DCT
#  define Cx6_6_Speed_AT_or_DCT (6U)
# endif

# ifndef Cx7_7_Speed_AT_or_DCT
#  define Cx7_7_Speed_AT_or_DCT (7U)
# endif

# ifndef Cx8_8_Speed_AT_or_DCT
#  define Cx8_8_Speed_AT_or_DCT (8U)
# endif

# ifndef Cx0_No_IDLE_UP_request
#  define Cx0_No_IDLE_UP_request (0U)
# endif

# ifndef Cx1_IDLE_UP_request
#  define Cx1_IDLE_UP_request (1U)
# endif

# ifndef Cx0_TCU_inhibits_the_ISG_function
#  define Cx0_TCU_inhibits_the_ISG_function (0U)
# endif

# ifndef Cx1_ISG_is_available
#  define Cx1_ISG_is_available (1U)
# endif

# ifndef Cx0_No_NC
#  define Cx0_No_NC (0U)
# endif

# ifndef Cx1_NC_Entry
#  define Cx1_NC_Entry (1U)
# endif

# ifndef Cx2_NC_Applied
#  define Cx2_NC_Applied (2U)
# endif

# ifndef Cx3_NC_Exit
#  define Cx3_NC_Exit (3U)
# endif

# ifndef Cx0_Normal_ECO_
#  define Cx0_Normal_ECO_ (0U)
# endif

# ifndef Cx1_Uphill_1_Optional_
#  define Cx1_Uphill_1_Optional_ (1U)
# endif

# ifndef Cx2_Uphill_2_Optional_
#  define Cx2_Uphill_2_Optional_ (2U)
# endif

# ifndef Cx4_Downhill_1_Optional_
#  define Cx4_Downhill_1_Optional_ (4U)
# endif

# ifndef Cx5_Cruise_Optional_
#  define Cx5_Cruise_Optional_ (5U)
# endif

# ifndef Cx6_Cruise_Uphill_1_Optional_
#  define Cx6_Cruise_Uphill_1_Optional_ (6U)
# endif

# ifndef Cx7_Cruise_Uphill_2_Optional_
#  define Cx7_Cruise_Uphill_2_Optional_ (7U)
# endif

# ifndef Cx8_Active_ECO_Optional_
#  define Cx8_Active_ECO_Optional_ (8U)
# endif

# ifndef Cx9_Sport_Drive_Optional_
#  define Cx9_Sport_Drive_Optional_ (9U)
# endif

# ifndef CxF_None_of_the_above
#  define CxF_None_of_the_above (15U)
# endif

# ifndef Cx0_Smart_Shift_not_Applied
#  define Cx0_Smart_Shift_not_Applied (0U)
# endif

# ifndef Cx1_Smart_Shift_Applied
#  define Cx1_Smart_Shift_Applied (1U)
# endif

# ifndef Cx00_Invalid
#  define Cx00_Invalid (0U)
# endif

# ifndef Cx14_Step_20
#  define Cx14_Step_20 (20U)
# endif

# ifndef Cx15_Step_21
#  define Cx15_Step_21 (21U)
# endif

# ifndef Cx16_Step_22
#  define Cx16_Step_22 (22U)
# endif

# ifndef Cx17_Step_23
#  define Cx17_Step_23 (23U)
# endif

# ifndef Cx18_Step_24
#  define Cx18_Step_24 (24U)
# endif

# ifndef Cx19_Step_25
#  define Cx19_Step_25 (25U)
# endif

# ifndef Cx1A_Invalid
#  define Cx1A_Invalid (26U)
# endif

# ifndef Cx1B_Invalid
#  define Cx1B_Invalid (27U)
# endif

# ifndef Cx1C_Invalid
#  define Cx1C_Invalid (28U)
# endif

# ifndef Cx1D_Invalid
#  define Cx1D_Invalid (29U)
# endif

# ifndef Cx1E_Invalid
#  define Cx1E_Invalid (30U)
# endif

# ifndef Cx0_No_lock_up_control
#  define Cx0_No_lock_up_control (0U)
# endif

# ifndef Cx1_Slip_lock_up
#  define Cx1_Slip_lock_up (1U)
# endif

# ifndef Cx2_Fully_lock_up
#  define Cx2_Fully_lock_up (2U)
# endif

# ifndef Cx3_Off_slip_lock_up
#  define Cx3_Off_slip_lock_up (3U)
# endif

# ifndef Cx0_Reserved
#  define Cx0_Reserved (0U)
# endif

# ifndef Cx1_Step_A
#  define Cx1_Step_A (1U)
# endif

# ifndef Cx2_CVT
#  define Cx2_CVT (2U)
# endif

# ifndef Cx3_DCT
#  define Cx3_DCT (3U)
# endif

# ifndef Cx4_AMT
#  define Cx4_AMT (4U)
# endif

# ifndef Cx5_eClutch_2pedal_
#  define Cx5_eClutch_2pedal_ (5U)
# endif

# ifndef Cx6_eClutch_3pedal_
#  define Cx6_eClutch_3pedal_ (6U)
# endif

# ifndef CxFF_Error_Indicator
#  define CxFF_Error_Indicator (255U)
# endif

# ifndef Cx2_Warning
#  define Cx2_Warning (2U)
# endif

# ifndef Cx0_Default_
#  define Cx0_Default_ (0U)
# endif

# ifndef Cx0_Default_NoneFCA_
#  define Cx0_Default_NoneFCA_ (0U)
# endif

# ifndef Cx1_Function_Off
#  define Cx1_Function_Off (1U)
# endif

# ifndef Cx2_Function_On
#  define Cx2_Function_On (2U)
# endif

# ifndef Cx1_Auto_off
#  define Cx1_Auto_off (1U)
# endif

# ifndef Cx2_Auto_on
#  define Cx2_Auto_on (2U)
# endif

# ifndef Cx1_toggle
#  define Cx1_toggle (1U)
# endif

# ifndef Cx1_10kph_10mph
#  define Cx1_10kph_10mph (1U)
# endif

# ifndef Cx2_5kph_5mph
#  define Cx2_5kph_5mph (2U)
# endif

# ifndef Cx3_0kph_0mph
#  define Cx3_0kph_0mph (3U)
# endif

# ifndef Cx4_5kph_5mph
#  define Cx4_5kph_5mph (4U)
# endif

# ifndef Cx5_10kph_10mph
#  define Cx5_10kph_10mph (5U)
# endif

# ifndef Cx1_Reset
#  define Cx1_Reset (1U)
# endif

# ifndef Cx1_Drive_mode
#  define Cx1_Drive_mode (1U)
# endif

# ifndef Cx2_SCC_ML
#  define Cx2_SCC_ML (2U)
# endif

# ifndef Cx2_Assist
#  define Cx2_Assist (2U)
# endif

# ifndef Cx1_Disable_Off_
#  define Cx1_Disable_Off_ (1U)
# endif

# ifndef Cx2_Enable_On_
#  define Cx2_Enable_On_ (2U)
# endif

# ifndef Cx1_level_1
#  define Cx1_level_1 (1U)
# endif

# ifndef Cx2_level_2
#  define Cx2_level_2 (2U)
# endif

# ifndef Cx3_level_3
#  define Cx3_level_3 (3U)
# endif

# ifndef Cx4_level_4
#  define Cx4_level_4 (4U)
# endif

# ifndef Cx5_level_5
#  define Cx5_level_5 (5U)
# endif

# ifndef Cx6_Off
#  define Cx6_Off (6U)
# endif

# ifndef Cx1_Level0_mute_
#  define Cx1_Level0_mute_ (1U)
# endif

# ifndef Cx2_Level1
#  define Cx2_Level1 (2U)
# endif

# ifndef Cx3_Level2
#  define Cx3_Level2 (3U)
# endif

# ifndef Cx4_Level3
#  define Cx4_Level3 (4U)
# endif

# ifndef Cx0_No_reset
#  define Cx0_No_reset (0U)
# endif

# ifndef Cx1_Reset_EngineOil_Life_Cycle_
#  define Cx1_Reset_EngineOil_Life_Cycle_ (1U)
# endif

# ifndef Cx2_Driving
#  define Cx2_Driving (2U)
# endif

# ifndef Cx3_Refuel
#  define Cx3_Refuel (3U)
# endif

# ifndef Cx0_Default_Value
#  define Cx0_Default_Value (0U)
# endif

# ifndef Cx2_step_1
#  define Cx2_step_1 (2U)
# endif

# ifndef Cx3_step_2
#  define Cx3_step_2 (3U)
# endif

# ifndef Cx4_step_3
#  define Cx4_step_3 (4U)
# endif

# ifndef Cx5_step_4
#  define Cx5_step_4 (5U)
# endif

# ifndef Cx6_reserved
#  define Cx6_reserved (6U)
# endif

# ifndef Cx1_10kph_5mph
#  define Cx1_10kph_5mph (1U)
# endif

# ifndef Cx2_5kph_3mph
#  define Cx2_5kph_3mph (2U)
# endif

# ifndef Cx3_0
#  define Cx3_0 (3U)
# endif

# ifndef Cx4_5kph_3mph
#  define Cx4_5kph_3mph (4U)
# endif

# ifndef Cx5_10kph_5mph
#  define Cx5_10kph_5mph (5U)
# endif

# ifndef Cx1_PAB_Off
#  define Cx1_PAB_Off (1U)
# endif

# ifndef Cx2_PAB_On
#  define Cx2_PAB_On (2U)
# endif

# ifndef Cx0_Unbelted
#  define Cx0_Unbelted (0U)
# endif

# ifndef Cx1_Belted
#  define Cx1_Belted (1U)
# endif

# ifndef Cx0_No_event
#  define Cx0_No_event (0U)
# endif

# ifndef Cx1_hood_open_close
#  define Cx1_hood_open_close (1U)
# endif

# ifndef Cx0_Off_UnSeated_
#  define Cx0_Off_UnSeated_ (0U)
# endif

# ifndef Cx1_On_Seated_
#  define Cx1_On_Seated_ (1U)
# endif

# ifndef Cx0_Auto_Wash_Mode_Off
#  define Cx0_Auto_Wash_Mode_Off (0U)
# endif

# ifndef Cx1_Auto_Wash_Mode_On
#  define Cx1_Auto_Wash_Mode_On (1U)
# endif

# ifndef Cx0_else
#  define Cx0_else (0U)
# endif

# ifndef Cx1_Parking_Position
#  define Cx1_Parking_Position (1U)
# endif

# ifndef Cx0_Non_Rain_Sensor_Option
#  define Cx0_Non_Rain_Sensor_Option (0U)
# endif

# ifndef Cx1_Rain_Sensor_Option
#  define Cx1_Rain_Sensor_Option (1U)
# endif

# ifndef Cx1_Rain_Detected
#  define Cx1_Rain_Detected (1U)
# endif

# ifndef Cx2_Low
#  define Cx2_Low (2U)
# endif

# ifndef Cx3_High
#  define Cx3_High (3U)
# endif

# ifndef Cx4_Fault_1
#  define Cx4_Fault_1 (4U)
# endif

# ifndef CxE_Not_Used
#  define CxE_Not_Used (14U)
# endif

# ifndef CxF_Error_Indicator
#  define CxF_Error_Indicator (15U)
# endif

# ifndef Cx0_EBD_is_not_defective
#  define Cx0_EBD_is_not_defective (0U)
# endif

# ifndef Cx1_EBD_is_defective
#  define Cx1_EBD_is_defective (1U)
# endif

# ifndef Cx0_EBD_Warning_lamp_OFF
#  define Cx0_EBD_Warning_lamp_OFF (0U)
# endif

# ifndef Cx1_EBD_Warning_lamp_ON
#  define Cx1_EBD_Warning_lamp_ON (1U)
# endif

# ifndef Cx0_No_warning
#  define Cx0_No_warning (0U)
# endif

# ifndef Cx1_Prefill_Warning_level1_
#  define Cx1_Prefill_Warning_level1_ (1U)
# endif

# ifndef Cx2_Partial_brake_Warning_level2_
#  define Cx2_Partial_brake_Warning_level2_ (2U)
# endif

# ifndef Cx3_Full_brake_Warning_level3_
#  define Cx3_Full_brake_Warning_level3_ (3U)
# endif

# ifndef Cx0_No_Full_act
#  define Cx0_No_Full_act (0U)
# endif

# ifndef Cx1_Full_act
#  define Cx1_Full_act (1U)
# endif

# ifndef Cx0_Standard_threshold
#  define Cx0_Standard_threshold (0U)
# endif

# ifndef Cx1_Lowered_threshold_1
#  define Cx1_Lowered_threshold_1 (1U)
# endif

# ifndef Cx2_Lowered_threshold_2
#  define Cx2_Lowered_threshold_2 (2U)
# endif

# ifndef Cx3_Lowered_threshold_3
#  define Cx3_Lowered_threshold_3 (3U)
# endif

# ifndef Cx3_Assist
#  define Cx3_Assist (3U)
# endif

# ifndef Cx0_No_Partial_act
#  define Cx0_No_Partial_act (0U)
# endif

# ifndef Cx1_Partail_act_
#  define Cx1_Partail_act_ (1U)
# endif

# ifndef Cx0_No_pre_fill
#  define Cx0_No_pre_fill (0U)
# endif

# ifndef Cx1_Pre_fill_act
#  define Cx1_Pre_fill_act (1U)
# endif

# ifndef Cx1_FCA_Amber_warning_on
#  define Cx1_FCA_Amber_warning_on (1U)
# endif

# ifndef Cx2_FCA_Red_warning_blinking
#  define Cx2_FCA_Red_warning_blinking (2U)
# endif

# ifndef Cx0_ReleaseNoalert
#  define Cx0_ReleaseNoalert (0U)
# endif

# ifndef Cx1_Pre_crash_full_retraction
#  define Cx1_Pre_crash_full_retraction (1U)
# endif

# ifndef Cx2_Hapticwarning
#  define Cx2_Hapticwarning (2U)
# endif

# ifndef Cx1_Sensor_fusion
#  define Cx1_Sensor_fusion (1U)
# endif

# ifndef Cx2_RadarorSensor_fusion
#  define Cx2_RadarorSensor_fusion (2U)
# endif

# ifndef Cx3_Service_Required
#  define Cx3_Service_Required (3U)
# endif

# ifndef Cx4_Camera_only
#  define Cx4_Camera_only (4U)
# endif

# ifndef Cx5_Sensor_fusion_in_ADAS_DRV
#  define Cx5_Sensor_fusion_in_ADAS_DRV (5U)
# endif

# ifndef Cx6_Sensor_fusion_in_Camera
#  define Cx6_Sensor_fusion_in_Camera (6U)
# endif

# ifndef Cx1_Late
#  define Cx1_Late (1U)
# endif

# ifndef Cx2_Normal
#  define Cx2_Normal (2U)
# endif

# ifndef Cx1_Warning_level_1
#  define Cx1_Warning_level_1 (1U)
# endif

# ifndef Cx2_Warning_level_2
#  define Cx2_Warning_level_2 (2U)
# endif

# ifndef Cx3_Warning_level_3
#  define Cx3_Warning_level_3 (3U)
# endif

# ifndef Cx1_Warning_1
#  define Cx1_Warning_1 (1U)
# endif

# ifndef Cx2_Warning_2
#  define Cx2_Warning_2 (2U)
# endif

# ifndef Cx3_Warning_3
#  define Cx3_Warning_3 (3U)
# endif

# ifndef Cx00_None
#  define Cx00_None (0U)
# endif

# ifndef Cx01_FCA_Pedestrian
#  define Cx01_FCA_Pedestrian (1U)
# endif

# ifndef Cx02_Reserved
#  define Cx02_Reserved (2U)
# endif

# ifndef Cx03_FCA_Cyclist
#  define Cx03_FCA_Cyclist (3U)
# endif

# ifndef Cx04_Reserved
#  define Cx04_Reserved (4U)
# endif

# ifndef Cx05_FCA_Car
#  define Cx05_FCA_Car (5U)
# endif

# ifndef Cx06_Reserved
#  define Cx06_Reserved (6U)
# endif

# ifndef Cx07_FCA_JC_L_
#  define Cx07_FCA_JC_L_ (7U)
# endif

# ifndef Cx08_FCA_JC_R_
#  define Cx08_FCA_JC_R_ (8U)
# endif

# ifndef Cx09_Reserved
#  define Cx09_Reserved (9U)
# endif

# ifndef Cx0A_Reserved
#  define Cx0A_Reserved (10U)
# endif

# ifndef Cx0B_FCA_JT_L_
#  define Cx0B_FCA_JT_L_ (11U)
# endif

# ifndef Cx0C_FCA_JT_R_
#  define Cx0C_FCA_JT_R_ (12U)
# endif

# ifndef Cx0D_Reserved
#  define Cx0D_Reserved (13U)
# endif

# ifndef Cx0E_Reserved
#  define Cx0E_Reserved (14U)
# endif

# ifndef Cx1_On_Not_Active_
#  define Cx1_On_Not_Active_ (1U)
# endif

# ifndef Cx2_On_Active_
#  define Cx2_On_Active_ (2U)
# endif

# ifndef Cx2_No_Blockage
#  define Cx2_No_Blockage (2U)
# endif

# ifndef Cx1_Camera_Failure
#  define Cx1_Camera_Failure (1U)
# endif

# ifndef Cx2_IR_LED_Failure
#  define Cx2_IR_LED_Failure (2U)
# endif

# ifndef Cx1_ECU_Failure
#  define Cx1_ECU_Failure (1U)
# endif

# ifndef Cx1_InProgress
#  define Cx1_InProgress (1U)
# endif

# ifndef Cx2_Pause
#  define Cx2_Pause (2U)
# endif

# ifndef Cx3_InUse
#  define Cx3_InUse (3U)
# endif

# ifndef Cx4_RESERVED
#  define Cx4_RESERVED (4U)
# endif

# ifndef Cx4_Ready
#  define Cx4_Ready (4U)
# endif

# ifndef Cx5_Active
#  define Cx5_Active (5U)
# endif

# ifndef Cx1_Failure
#  define Cx1_Failure (1U)
# endif

# ifndef Cx1_Distraction_Warning
#  define Cx1_Distraction_Warning (1U)
# endif

# ifndef Cx2_Drowsiness_Warning
#  define Cx2_Drowsiness_Warning (2U)
# endif

# ifndef Cx5_Degradation_Warning
#  define Cx5_Degradation_Warning (5U)
# endif

# ifndef Cx6_Blockage_Warning
#  define Cx6_Blockage_Warning (6U)
# endif

# ifndef Cx7_Failure_Warning
#  define Cx7_Failure_Warning (7U)
# endif

# ifndef Cx1_Not_in_time_zone
#  define Cx1_Not_in_time_zone (1U)
# endif

# ifndef Cx2_In_time_zone
#  define Cx2_In_time_zone (2U)
# endif

# ifndef Cx1_Entrance
#  define Cx1_Entrance (1U)
# endif

# ifndef Cx2_Exit
#  define Cx2_Exit (2U)
# endif

# ifndef Cx3_Branch
#  define Cx3_Branch (3U)
# endif

# ifndef Cx4_Restarea
#  define Cx4_Restarea (4U)
# endif

# ifndef Cx2_IC
#  define Cx2_IC (2U)
# endif

# ifndef Cx3_JC
#  define Cx3_JC (3U)
# endif

# ifndef Cx5_Arterial_Country
#  define Cx5_Arterial_Country (5U)
# endif

# ifndef Cx6_Roundabout
#  define Cx6_Roundabout (6U)
# endif

# ifndef Cx1_KPH
#  define Cx1_KPH (1U)
# endif

# ifndef Cx2_MPH
#  define Cx2_MPH (2U)
# endif

# ifndef Cx1_Normal_Toll
#  define Cx1_Normal_Toll (1U)
# endif

# ifndef Cx2_Elect_Toll
#  define Cx2_Elect_Toll (2U)
# endif

# ifndef Cx1_Exist
#  define Cx1_Exist (1U)
# endif

# ifndef NVM_REQ_OK
#  define NVM_REQ_OK (0U)
# endif

# ifndef NVM_REQ_NOT_OK
#  define NVM_REQ_NOT_OK (1U)
# endif

# ifndef NVM_REQ_PENDING
#  define NVM_REQ_PENDING (2U)
# endif

# ifndef NVM_REQ_INTEGRITY_FAILED
#  define NVM_REQ_INTEGRITY_FAILED (3U)
# endif

# ifndef NVM_REQ_BLOCK_SKIPPED
#  define NVM_REQ_BLOCK_SKIPPED (4U)
# endif

# ifndef NVM_REQ_NV_INVALIDATED
#  define NVM_REQ_NV_INVALIDATED (5U)
# endif

# ifndef NVM_REQ_CANCELED
#  define NVM_REQ_CANCELED (6U)
# endif

# ifndef NVM_REQ_REDUNDANCY_FAILED
#  define NVM_REQ_REDUNDANCY_FAILED (7U)
# endif

# ifndef NVM_REQ_RESTORED_FROM_ROM
#  define NVM_REQ_RESTORED_FROM_ROM (8U)
# endif

# ifndef Cx0_System_without_error
#  define Cx0_System_without_error (0U)
# endif

# ifndef Cx1_Performance_degredation
#  define Cx1_Performance_degredation (1U)
# endif

# ifndef Cx2_System_temporairy_unavailable
#  define Cx2_System_temporairy_unavailable (2U)
# endif

# ifndef Cx3_SCC_Service_Required
#  define Cx3_SCC_Service_Required (3U)
# endif

# ifndef Cx0_No_takeover_request
#  define Cx0_No_takeover_request (0U)
# endif

# ifndef Cx1_Takeover_request
#  define Cx1_Takeover_request (1U)
# endif

# ifndef CxFF_Error
#  define CxFF_Error (255U)
# endif



/**********************************************************************************************************************
 * Definitions for Mode Management
 *********************************************************************************************************************/
# ifndef RTE_MODETYPE_BswMVCAN_RteModeDclGroup
#  define RTE_MODETYPE_BswMVCAN_RteModeDclGroup
typedef uint8 Rte_ModeType_BswMVCAN_RteModeDclGroup;
# endif

# define RTE_MODE_CpApVCan_BswMVCAN_RteModeDclGroup_VCAN_BUSOFF (0U)
# ifndef RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_BUSOFF
#  define RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_BUSOFF (0U)
# endif
# define RTE_MODE_CpApVCan_BswMVCAN_RteModeDclGroup_VCAN_Normal (1U)
# ifndef RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_Normal
#  define RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_Normal (1U)
# endif
# define RTE_TRANSITION_CpApVCan_BswMVCAN_RteModeDclGroup (2U)
# ifndef RTE_TRANSITION_BswMVCAN_RteModeDclGroup
#  define RTE_TRANSITION_BswMVCAN_RteModeDclGroup (2U)
# endif

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPVCAN_TYPE_H */
