/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApWdgMonCore1.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApWdgMonCore1
 *  Generation Time:  2023-04-20 13:52:58
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApWdgMonCore1> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPWDGMONCORE1_H
# define _RTE_CPAPWDGMONCORE1_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApWdgMonCore1_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApWdgMonCore1
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApWdgMonCore1, RTE_CONST, RTE_CONST) Rte_Inst_CpApWdgMonCore1; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApWdgMonCore1, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApWdgMonCore1_PP_AppWdgMonInfo_Core1_AppWdgMonInfo(P2CONST(AppWdgMonInfo, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_50ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_5ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_CoFca_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Cvd_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Fca_Algo_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Fca_Input_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Scc_Algo_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Scc_Input_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Proxy_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_DeactivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetFirstExpiredSEID(P2VAR(WdgM_SupervisedEntityIdType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetGlobalStatus(P2VAR(WdgM_GlobalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetLocalStatus(WdgM_SupervisedEntityIdType SEID, P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetMode(P2VAR(WdgM_ModeType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Mode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_PerformReset(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_SetMode(WdgM_ModeType Mode, uint16 CallerID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_10ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_50ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_5ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Cvd_10ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Fca_Algo_20ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Fca_Input_20ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Scc_Algo_20ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Scc_Input_20ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Proxy_10ms_ASILB_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE1_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_AppWdgMonInfo_Core1_AppWdgMonInfo Rte_Write_CpApWdgMonCore1_PP_AppWdgMonInfo_Core1_AppWdgMonInfo


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_10ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_10ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_50ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_50ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_5ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_5ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_CoFca_20ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_CoFca_20ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_Cvd_10ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Cvd_10ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_Fca_Algo_20ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Fca_Algo_20ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_Fca_Input_20ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Fca_Input_20ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_Scc_Algo_20ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Scc_Algo_20ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Appl_Scc_Input_20ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Appl_Scc_Input_20ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core1_Proxy_10ms_ASILB_CheckpointReached Rte_Call_CpApWdgMonCore1_WdgM_AliveSupervision_Core1_Proxy_10ms_ASILB_CheckpointReached
# define Rte_Call_WdgM_General_Core1_ActivateSupervisionEntity Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_ActivateSupervisionEntity
# define Rte_Call_WdgM_General_Core1_DeactivateSupervisionEntity Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_DeactivateSupervisionEntity
# define Rte_Call_WdgM_General_Core1_GetFirstExpiredSEID Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetFirstExpiredSEID
# define Rte_Call_WdgM_General_Core1_GetGlobalStatus Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetGlobalStatus
# define Rte_Call_WdgM_General_Core1_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetLocalStatus
# define Rte_Call_WdgM_General_Core1_GetMode Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_GetMode
# define Rte_Call_WdgM_General_Core1_PerformReset Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_PerformReset
# define Rte_Call_WdgM_General_Core1_SetMode Rte_Call_CpApWdgMonCore1_WdgM_General_Core1_SetMode
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_10ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_10ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_50ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_50ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_5ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_5ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_Cvd_10ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Cvd_10ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_Fca_Algo_20ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Fca_Algo_20ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_Fca_Input_20ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Fca_Input_20ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Algo_20ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Scc_Algo_20ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Input_20ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Appl_Scc_Input_20ms_ASILB_GetLocalStatus
# define Rte_Call_WdgM_LocalStatus_Core1_Proxy_10ms_ASILB_GetLocalStatus Rte_Call_CpApWdgMonCore1_WdgM_LocalStatus_Core1_Proxy_10ms_ASILB_GetLocalStatus




# define CpApWdgMonCore1_START_SEC_CODE
# include "CpApWdgMonCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApWdgMonCore1_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_AppWdgMonInfo_Core1_AppWdgMonInfo(const AppWdgMonInfo *data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_DeactivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_GetFirstExpiredSEID(WdgM_SupervisedEntityIdType *SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_GetGlobalStatus(WdgM_GlobalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_GetLocalStatus(WdgM_SupervisedEntityIdType SEID, WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_GetMode(WdgM_ModeType *Mode)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_PerformReset(void)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core1_SetMode(WdgM_ModeType Mode, uint16 CallerID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_10ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_50ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_5ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Cvd_10ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Fca_Algo_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Fca_Input_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Algo_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Input_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Proxy_10ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApWdgMonCore1_Main Re_CpApWdgMonCore1_Main
FUNC(void, CpApWdgMonCore1_CODE) Re_CpApWdgMonCore1_Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_10ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_10ms_ASILB Re_WdgM_AliveMon_Core1_Appl_10ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_10ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_50ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 50ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_50ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_50ms_ASILB Re_WdgM_AliveMon_Core1_Appl_50ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_50ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_5ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_5ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_5ms_ASILB Re_WdgM_AliveMon_Core1_Appl_5ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_5ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_CoFca_20ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_CoFca_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_CoFca_20ms_ASILB Re_WdgM_AliveMon_Core1_Appl_CoFca_20ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_CoFca_20ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Cvd_10ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_Cvd_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Cvd_10ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Cvd_10ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Cvd_10ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Fca_Algo_20ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_Fca_Algo_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Fca_Algo_20ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Fca_Algo_20ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Fca_Algo_20ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Fca_Input_20ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_Fca_Input_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Fca_Input_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Fca_Input_20ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Fca_Input_20ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Fca_Input_20ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Proxy_10ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Proxy_10ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Proxy_10ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Proxy_10ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Proxy_10ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Scc_Algo_20ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_Scc_Algo_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Algo_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Scc_Algo_20ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Scc_Algo_20ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Scc_Algo_20ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core1_Appl_Scc_Input_20ms_ASILB
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core1_Appl_Scc_Input_20ms_ASILB_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core1_Appl_Scc_Input_20ms_ASILB_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core1_Appl_Scc_Input_20ms_ASILB Re_WdgM_AliveMon_Core1_Appl_Scc_Input_20ms_ASILB
FUNC(void, CpApWdgMonCore1_CODE) Re_WdgM_AliveMon_Core1_Appl_Scc_Input_20ms_ASILB(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApWdgMonCore1_STOP_SEC_CODE
# include "CpApWdgMonCore1_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_WdgM_AliveSupervision_E_NOT_OK (1U)

# define RTE_E_WdgM_General_E_NOT_OK (1U)

# define RTE_E_WdgM_LocalStatus_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPWDGMONCORE1_H */
