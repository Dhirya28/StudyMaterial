/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApUdsPlatform.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUdsPlatform
 *  Generation Time:  2023-04-20 13:53:25
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApUdsPlatform>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Dcm_NegativeResponseCodeType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Dcm_OpStatusType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * NvM_ServiceIdType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApUdsPlatform.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * CpApDiag_Status: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * dtRef_const_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Dcm_NegativeResponseCodeType: Enumeration of integer in interval [0...254] with enumerators
 *   DCM_E_POSITIVERESPONSE (0U)
 *   DCM_E_GENERALREJECT (16U)
 *   DCM_E_SERVICENOTSUPPORTED (17U)
 *   DCM_E_SUBFUNCTIONNOTSUPPORTED (18U)
 *   DCM_E_INCORRECTMESSAGELENGTHORINVALIDFORMAT (19U)
 *   DCM_E_RESPONSETOOLONG (20U)
 *   DCM_E_BUSYREPEATREQUEST (33U)
 *   DCM_E_CONDITIONSNOTCORRECT (34U)
 *   DCM_E_REQUESTSEQUENCEERROR (36U)
 *   DCM_E_NORESPONSEFROMSUBNETCOMPONENT (37U)
 *   DCM_E_FAILUREPREVENTSEXECUTIONOFREQUESTEDACTION (38U)
 *   DCM_E_REQUESTOUTOFRANGE (49U)
 *   DCM_E_SECURITYACCESSDENIED (51U)
 *   DCM_E_INVALIDKEY (53U)
 *   DCM_E_EXCEEDNUMBEROFATTEMPTS (54U)
 *   DCM_E_REQUIREDTIMEDELAYNOTEXPIRED (55U)
 *   DCM_E_UPLOADDOWNLOADNOTACCEPTED (112U)
 *   DCM_E_TRANSFERDATASUSPENDED (113U)
 *   DCM_E_GENERALPROGRAMMINGFAILURE (114U)
 *   DCM_E_WRONGBLOCKSEQUENCECOUNTER (115U)
 *   DCM_E_REQUESTCORRECTLYRECEIVEDRESPONSEPENDING (120U)
 *   DCM_E_SUBFUNCTIONNOTSUPPORTEDINACTIVESESSION (126U)
 *   DCM_E_SERVICENOTSUPPORTEDINACTIVESESSION (127U)
 *   DCM_E_RPMTOOHIGH (129U)
 *   DCM_E_RPMTOOLOW (130U)
 *   DCM_E_ENGINEISRUNNING (131U)
 *   DCM_E_ENGINEISNOTRUNNING (132U)
 *   DCM_E_ENGINERUNTIMETOOLOW (133U)
 *   DCM_E_TEMPERATURETOOHIGH (134U)
 *   DCM_E_TEMPERATURETOOLOW (135U)
 *   DCM_E_VEHICLESPEEDTOOHIGH (136U)
 *   DCM_E_VEHICLESPEEDTOOLOW (137U)
 *   DCM_E_THROTTLE_PEDALTOOHIGH (138U)
 *   DCM_E_THROTTLE_PEDALTOOLOW (139U)
 *   DCM_E_TRANSMISSIONRANGENOTINNEUTRAL (140U)
 *   DCM_E_TRANSMISSIONRANGENOTINGEAR (141U)
 *   DCM_E_BRAKESWITCH_NOTCLOSED (143U)
 *   DCM_E_SHIFTERLEVERNOTINPARK (144U)
 *   DCM_E_TORQUECONVERTERCLUTCHLOCKED (145U)
 *   DCM_E_VOLTAGETOOHIGH (146U)
 *   DCM_E_VOLTAGETOOLOW (147U)
 *   DCM_E_VMSCNC_0 (240U)
 *   DCM_E_VMSCNC_1 (241U)
 *   DCM_E_VMSCNC_2 (242U)
 *   DCM_E_VMSCNC_3 (243U)
 *   DCM_E_VMSCNC_4 (244U)
 *   DCM_E_VMSCNC_5 (245U)
 *   DCM_E_VMSCNC_6 (246U)
 *   DCM_E_VMSCNC_7 (247U)
 *   DCM_E_VMSCNC_8 (248U)
 *   DCM_E_VMSCNC_9 (249U)
 *   DCM_E_VMSCNC_A (250U)
 *   DCM_E_VMSCNC_B (251U)
 *   DCM_E_VMSCNC_C (252U)
 *   DCM_E_VMSCNC_D (253U)
 *   DCM_E_VMSCNC_E (254U)
 * Dcm_OpStatusType: Enumeration of integer in interval [0...64] with enumerators
 *   DCM_INITIAL (0U)
 *   DCM_PENDING (1U)
 *   DCM_CANCEL (2U)
 *   DCM_FORCE_RCRRP_OK (3U)
 *   DCM_FORCE_RCRRP_NOT_OK (64U)
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 * NvM_ServiceIdType: Enumeration of integer in interval [6...12] with enumerators
 *   NVM_READ_BLOCK (6U)
 *   NVM_WRITE_BLOCK (7U)
 *   NVM_RESTORE_BLOCK_DEFAULTS (8U)
 *   NVM_ERASE_BLOCK (9U)
 *   NVM_INVALIDATE_NV_BLOCK (11U)
 *   NVM_READ_ALL (12U)
 *
 * Array Types:
 * ============
 * Dcm_Data3ByteType: Array with 3 element(s) of type uint8
 * Dcm_Data8ByteType: Array with 8 element(s) of type uint8
 * PlatformCode: Array with 3 element(s) of type uint8
 * Rte_DT_EYEQMESP_VehicleCalParams_t_14: Array with 7 element(s) of type uint8
 * Rte_DT_PtmEepDumpRecord_t_0: Array with 32 element(s) of type uint8
 * VehicleName: Array with 8 element(s) of type uint8
 *
 * Record Types:
 * =============
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * EYEQMESP_EnvironmentParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   LeftWheel_u16 of type uint16
 *   RightWheel_u16 of type uint16
 *   RefPX_Front_Bumper_u16 of type uint16
 *   CamToFrontAxle_u16 of type uint16
 *   CamToRearAxle_u16 of type uint16
 *   WheelWidth_u8 of type uint8
 *   WheelRadius_u8 of type uint8
 *   MinHorizon_u16 of type uint16
 *   MaxHorizon_u16 of type uint16
 *   MinYaw_u16 of type uint16
 *   MaxYaw_u16 of type uint16
 *   MaxRoll_u16 of type uint16
 *   Top_Crop_u16 of type uint16
 *   Bottom_Crop_u16 of type uint16
 *   Steering_Ratio_u16 of type uint16
 *   GPSToCam_dx_u16 of type uint16
 *   GPSToCam_dy_u16 of type uint16
 *   GPSToCam_dz_u16 of type uint16
 *   GPSToCam_dx_V_u8 of type uint8
 *   GPSToCam_dy_V_u8 of type uint8
 *   GPSToCam_dz_V_u8 of type uint8
 *   Top_Crop_V_u8 of type uint8
 *   Steering_Ratio_V_u8 of type uint8
 *   WheelWidth_V_u8 of type uint8
 *   WheelRadius_V_u8 of type uint8
 *   LeftWheel_V_u8 of type uint8
 *   RightWheel_V_u8 of type uint8
 *   RefPX_Front_Bumper_V_u8 of type uint8
 *   CamToFrontAxle_V_u8 of type uint8
 *   CamToRearAxle_V_u8 of type uint8
 *   MinHorizon_V_u8 of type uint8
 *   MaxHorizon_V_u8 of type uint8
 *   MinYaw_V_u8 of type uint8
 *   MaxYaw_V_u8 of type uint8
 *   MaxRoll_V_u8 of type uint8
 *   Bottom_Crop_V_u8 of type uint8
 *   fixedGpsLatency_u8 of type uint8
 *   fixedGpsLatency_V_u8 of type uint8
 *   receiverFrequency_u8 of type uint8
 *   receiverFrequency_V_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_TAC2InitParamsNVM_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   TAC_Mode_u8 of type uint8
 *   TAC_BottomLeftSquare_0_u8 of type uint8
 *   TAC_BottomLeftSquare_1_u8 of type uint8
 *   TAC_BottomLeftSquare_2_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_0_u16 of type uint16
 *   TAC_TargetInfo_Lat_Distance_1_u16 of type uint16
 *   TAC_TargetInfo_Lat_Distance_2_u16 of type uint16
 *   TAC_TargetInfo_Height_0_u16 of type uint16
 *   TAC_TargetInfo_Height_1_u16 of type uint16
 *   TAC_TargetInfo_Height_2_u16 of type uint16
 *   TAC_Camera_Height_u16 of type uint16
 *   TAC_Camera_Z_u16 of type uint16
 *   TAC_Max_Horizon_u8 of type uint8
 *   TAC_Min_Horizon_u8 of type uint8
 *   TAC_Max_Yaw_u8 of type uint8
 *   TAC_Min_Yaw_u8 of type uint8
 *   TAC_Max_RollAngle_u8 of type uint8
 *   TAC_Bottom_u8 of type uint8
 *   TAC_Targets_Num_u8 of type uint8
 *   TAC_Reserved0_u8 of type uint8
 *   TAC_SquareSideSize_u16 of type uint16
 *   TAC_Reserved1_u16 of type uint16
 *   TAC_Mode_V_u8 of type uint8
 *   TAC_BottomLeftSquare_0_V_u8 of type uint8
 *   TAC_BottomLeftSquare_1_V_u8 of type uint8
 *   TAC_BottomLeftSquare_2_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_0_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_1_V_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_2_V_u8 of type uint8
 *   TAC_TargetInfo_Height_0_V_u8 of type uint8
 *   TAC_TargetInfo_Height_1_V_u8 of type uint8
 *   TAC_TargetInfo_Height_2_V_u8 of type uint8
 *   TAC_Camera_Height_V_u8 of type uint8
 *   TAC_Camera_Z_V_u8 of type uint8
 *   TAC_Max_Horizon_V_u8 of type uint8
 *   TAC_Min_Horizon_V_u8 of type uint8
 *   TAC_Max_Yaw_V_u8 of type uint8
 *   TAC_Min_Yaw_V_u8 of type uint8
 *   TAC_Max_RollAngle_V_u8 of type uint8
 *   TAC_SquareSideSize_V_u8 of type uint8
 *   TAC_Bottom_V_u8 of type uint8
 *   TAC_Targets_Num_V_u8 of type uint8
 *   TAC_Camera_Z_Close_u8 of type uint8
 *   TAC_SquareSideSize_Close_u8 of type uint8
 *   Tac2_Num_Squares_Row_u8 of type uint8
 *   Tac2_Num_Squares_Col_u8 of type uint8
 *   TAC_Camera_Z_Close_V_u8 of type uint8
 *   TAC_SquareSideSize_Close_V_u8 of type uint8
 *   Tac2_Num_Squares_Row_V_u8 of type uint8
 *   Tac2_Num_Squares_Col_V_u8 of type uint8
 *   TAC_Reserved2_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_VehicleCalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Region_Code_u8 of type uint8
 *   Driving_Side_u8 of type uint8
 *   Pitch_Base_u16 of type uint16
 *   Yaw_Base_u16 of type uint16
 *   Cam_Height_Base_u16 of type uint16
 *   Roll_Angle_Base_f32 of type float32
 *   HilModeEnable_u8 of type uint8
 *   OverrideActualTargetCalParams_u8 of type uint8
 *   Disable_Ethernet_Logging_u8 of type uint8
 *   Disable_Ethernet_Logging_V_u8 of type uint8
 *   ActivateEDR_u16 of type uint16
 *   ActivateEDR_V_u8 of type uint8
 *   Reserved1_u8 of type Rte_DT_EYEQMESP_VehicleCalParams_t_14
 *   CalCRC_u16 of type uint16
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 * Plant_TAC2InitParamsNVM_t: Record with elements
 *   TAC_Mode_u8 of type uint8
 *   TAC_BottomLeftSquare_0_u8 of type uint8
 *   TAC_BottomLeftSquare_1_u8 of type uint8
 *   TAC_Targets_Num_u8 of type uint8
 *   TAC_TargetInfo_Lat_Distance_0_u16 of type uint16
 *   TAC_TargetInfo_Lat_Distance_1_u16 of type uint16
 *   TAC_TargetInfo_Height_0_u16 of type uint16
 *   TAC_TargetInfo_Height_1_u16 of type uint16
 *   TAC_Camera_Height_u16 of type uint16
 *   TAC_Camera_Z_u16 of type uint16
 *   TAC_Max_Horizon_u8 of type uint8
 *   TAC_Min_Horizon_u8 of type uint8
 *   TAC_Max_Yaw_u8 of type uint8
 *   TAC_Min_Yaw_u8 of type uint8
 *   TAC_Max_RollAngle_u8 of type uint8
 *   TAC_Bottom_u8 of type uint8
 *   TAC_SquareSideSize_u16 of type uint16
 * PtmEepDumpRecord_t: Record with elements
 *   Data_au8 of type Rte_DT_PtmEepDumpRecord_t_0
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   EOLInfo_t *Rte_Pim_EolInfo_222E(void)
 *   FeatureConfig_t *Rte_Pim_FeatureConfig(void)
 *   FeatureVehicle_t *Rte_Pim_FeatureVehicle(void)
 *   Plant_TAC2InitParamsNVM_t *Rte_Pim_PlantTAC2InitParamsNVM(void)
 *
 *********************************************************************************************************************/


#define CpApUdsPlatform_START_SEC_CODE
#include "CpApUdsPlatform_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_EOLInfo_EOLInfo(const EOLInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureConfig_FeatureConfig(const FeatureConfig_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureVehicle_FeatureVehicle(const FeatureVehicle_t *data)
 *   Std_ReturnType Rte_Write_PP_Eol_ADAS_DRV_ADAS_DRV(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_Codingcomplete_Codingcomplete(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_CountryCode_CountryCode(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DAW_DAW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DriveType_DriveType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_FCA_FCA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HBA_HBA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HDA_HDA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISG_ISG(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISLW_ISLW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LFA_LFA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LKALDW_LKALDW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LampTypeLbeam_LampTypeLbeam(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_MDPSType_MDPSType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_NSCC_NSCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_SCC_SCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_TransAxle_TransAxle(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_VehicleMY_VehicleMY(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PlatformCode_PlatformCode(const uint8 *data)
 *     Argument data: uint8* is of type PlatformCode
 *   Std_ReturnType Rte_Write_PP_VehicleName_VehicleName(const uint8 *data)
 *     Argument data: uint8* is of type VehicleName
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SetAppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureVehicle_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) CpApUdsPlatform_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getEOLInfo
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getEOLInfo> of PortPrototype <PP_EOLInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getEOLInfo(EOLInfo_t *EOLInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EOLInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getEOLInfo_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) EOLInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getEOLInfo (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getFeatureConfig
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureConfig> of PortPrototype <PP_FeatureConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getFeatureConfig_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) FeatureConfig) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getFeatureConfig (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getFeatureVehicle
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureVehicle> of PortPrototype <PP_FeatureVehicle>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getFeatureVehicle_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) FeatureVehicle) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApUdsPlatform_getFeatureVehicle (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_A0FF_SystemConfigParameter_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_A0FF_SystemConfigParameter>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_A0FF_SystemConfigParameter_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_A0FF_SystemConfigParameter_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_A0FF_SystemConfigParameter_ReadData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_A0FF_SystemConfigParameter_ReadData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_A0FF_SystemConfigParameter_WriteData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteData> of PortPrototype <DataServices_Data_A0FF_SystemConfigParameter>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureConfig_FeatureConfig(const FeatureConfig_t *data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_A0FF_SystemConfigParameter_WriteData(const uint8 *Data, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Data: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_A0FF_SystemConfigParameter_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_A0FF_SystemConfigParameter_WriteData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_WriteData(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_A0FF_SystemConfigParameter_WriteData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_C0DE_ECU_Configuration_at_EOL>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteData> of PortPrototype <DataServices_Data_C0DE_ECU_Configuration_at_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_EOLInfo_EOLInfo(const EOLInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Eol_ADAS_DRV_ADAS_DRV(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_Codingcomplete_Codingcomplete(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_CountryCode_CountryCode(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DAW_DAW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DriveType_DriveType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_FCA_FCA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HBA_HBA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HDA_HDA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISG_ISG(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISLW_ISLW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LFA_LFA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LKALDW_LKALDW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LampTypeLbeam_LampTypeLbeam(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_MDPSType_MDPSType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_NSCC_NSCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_SCC_SCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_TransAxle_TransAxle(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_VehicleMY_VehicleMY(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Tac2FreshStart_De_Tac2FreshStart(boolean data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_GetWriteEnvironmentParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_GetWriteTAC2InitParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams(EYEQMESP_TAC2InitParamsNVM_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_GetWriteVehicleCalParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams(EYEQMESP_VehicleCalParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SetAppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_EOLInfo_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EOLInfo_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_SetDataIndex(uint8 DataIndex)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData(const uint8 *Data, Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Data: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_E_NOT_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_EOLInfo_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EOLInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_EOLInfo_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_EOLInfo_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_EOLInfo_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_EOLInfo_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_FeatureConfig_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_FeatureConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_FeatureConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_FeatureConfig_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_FeatureConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_FeatureConfig_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_FeatureVehicle>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApUdsPlatformMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_SccFunctionCallwithEOL_SccFunctionCallwithEOL(uint8 mode)
 *   Modes of Rte_ModeType_SccFunctionCallwithEOL:
 *   - RTE_MODE_SccFunctionCallwithEOL_SccFunctionalityDisabled
 *   - RTE_MODE_SccFunctionCallwithEOL_SccFunctionalityEnabled
 *   - RTE_TRANSITION_SccFunctionCallwithEOL
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApUdsPlatformMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) Re_CpApUdsPlatformMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApUdsPlatformMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_GetEepDump
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <GetEepDump> of PortPrototype <PP_GetPtmEepDump>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_GetEepDump(uint32 nvmAddr_u32, PtmEepDumpRecord_t *ramAddr_u8, uint16 numBytes_u16, uint16 operation)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_GetEepDump_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApUdsPlatform_CODE) Re_GetEepDump(uint32 nvmAddr_u32, P2VAR(PtmEepDumpRecord_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ramAddr_u8, uint16 numBytes_u16, uint16 operation) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_GetEepDump
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApUdsPlatform_STOP_SEC_CODE
#include "CpApUdsPlatform_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: runnable implementation:DataServices_Data_F101_ECU_Configuration_at_EOL_ReadData)  */

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:DataServices_Data_F101_ECU_Configuration_at_EOL_WriteData_doc)  */


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:DataServices_Data_F101_ECU_Configuration_at_EOL_WriteData)  */

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:DataServices_Data_F101_ECU_Configuration_at_EOL_ReadData_doc)  */


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
