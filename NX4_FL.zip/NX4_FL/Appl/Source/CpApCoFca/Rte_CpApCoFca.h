/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApCoFca.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApCoFca
 *  Generation Time:  2023-04-20 13:52:20
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApCoFca> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPCOFCA_H
# define _RTE_CPAPCOFCA_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApCoFca_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApCoFca
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApCoFca, RTE_CONST, RTE_CONST) Rte_Inst_CpApCoFca; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApCoFca, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn01_De_CoFcaDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn02_De_CoFcaDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn03_De_CoFcaDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn04_De_CoFcaDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn05_De_CoFcaDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaDbgIn06_De_CoFcaDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo(P2VAR(CoFcaFailSafeInfo_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS(P2VAR(CoFcaInternalInFromLSS_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApCoFca_RP_Core1ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaEDR_De_EDR_Output(P2CONST(CoFcaEDR_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(P2CONST(CoFcaFrCmrOut_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaOutput_De_CoFcaOutput(P2CONST(CoFcaOutput_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc(P2CONST(CoFcaUxOutToIvc_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApCoFca_PP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA(P2CONST(FcaInternalInFromCOFCA_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_CoFcaFrqNvData_CoFcaFrqNvDataRead(P2VAR(CoFcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) CoFcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_CoFcaFrqNvData_CoFcaFrqNvDataWrite(P2CONST(CoFcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_DATA) CoFcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrFcfVd_getFrCmrFcfVd(P2VAR(FcfVd_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrFcfVru_getFrCmrFcfVru(P2VAR(FcfVru_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrHdrFS_getFrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd(P2VAR(FrCmrHdrFcfVd_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrHdrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru(P2VAR(FrCmrHdrFcfVru_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrHdrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApCoFca_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */

FUNC(void, RTE_CODE) Rte_Enter_CpApCoFca_ExclusiveArea_CpApCoFcaAppVersionInfo(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(void, RTE_CODE) Rte_Exit_CpApCoFca_ExclusiveArea_CpApCoFcaAppVersionInfo(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_CoFcaDbgIn01_De_CoFcaDbgIn01 Rte_Read_CpApCoFca_RP_CoFcaDbgIn01_De_CoFcaDbgIn01
# define Rte_Read_RP_CoFcaDbgIn02_De_CoFcaDbgIn02 Rte_Read_CpApCoFca_RP_CoFcaDbgIn02_De_CoFcaDbgIn02
# define Rte_Read_RP_CoFcaDbgIn03_De_CoFcaDbgIn03 Rte_Read_CpApCoFca_RP_CoFcaDbgIn03_De_CoFcaDbgIn03
# define Rte_Read_RP_CoFcaDbgIn04_De_CoFcaDbgIn04 Rte_Read_CpApCoFca_RP_CoFcaDbgIn04_De_CoFcaDbgIn04
# define Rte_Read_RP_CoFcaDbgIn05_De_CoFcaDbgIn05 Rte_Read_CpApCoFca_RP_CoFcaDbgIn05_De_CoFcaDbgIn05
# define Rte_Read_RP_CoFcaDbgIn06_De_CoFcaDbgIn06 Rte_Read_CpApCoFca_RP_CoFcaDbgIn06_De_CoFcaDbgIn06
# define Rte_Read_RP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo Rte_Read_CpApCoFca_RP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo
# define Rte_Read_RP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS Rte_Read_CpApCoFca_RP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS
# define Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApCoFca_RP_Core1ZfAppCameraState_De_ZfAppCameraState


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_CoFcaEDR_De_EDR_Output Rte_Write_CpApCoFca_PP_CoFcaEDR_De_EDR_Output
# define Rte_Write_PP_CoFcaFrCmrOut_De_CoFcaFrCmrOut Rte_Write_CpApCoFca_PP_CoFcaFrCmrOut_De_CoFcaFrCmrOut
# define Rte_Write_PP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01
# define Rte_Write_PP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02
# define Rte_Write_PP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03
# define Rte_Write_PP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04
# define Rte_Write_PP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05
# define Rte_Write_PP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06
# define Rte_Write_PP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07
# define Rte_Write_PP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08
# define Rte_Write_PP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09
# define Rte_Write_PP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10
# define Rte_Write_PP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11
# define Rte_Write_PP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12
# define Rte_Write_PP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13
# define Rte_Write_PP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14
# define Rte_Write_PP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15
# define Rte_Write_PP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16
# define Rte_Write_PP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17
# define Rte_Write_PP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18
# define Rte_Write_PP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19
# define Rte_Write_PP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20 Rte_Write_CpApCoFca_PP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20
# define Rte_Write_PP_CoFcaOutput_De_CoFcaOutput Rte_Write_CpApCoFca_PP_CoFcaOutput_De_CoFcaOutput
# define Rte_Write_PP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc Rte_Write_CpApCoFca_PP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc
# define Rte_Write_PP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA Rte_Write_CpApCoFca_PP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApCoFca_RP_CANmsg_getCanmsg
# define Rte_Call_RP_CoFcaFrqNvData_CoFcaFrqNvDataRead Rte_Call_CpApCoFca_RP_CoFcaFrqNvData_CoFcaFrqNvDataRead
# define Rte_Call_RP_CoFcaFrqNvData_CoFcaFrqNvDataWrite Rte_Call_CpApCoFca_RP_CoFcaFrqNvData_CoFcaFrqNvDataWrite
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApCoFca_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApCoFca_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApCoFca_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApCoFca_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd Rte_Call_CpApCoFca_RP_FrCmrFcfVd_getFrCmrFcfVd
# define Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru Rte_Call_CpApCoFca_RP_FrCmrFcfVru_getFrCmrFcfVru
# define Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS Rte_Call_CpApCoFca_RP_FrCmrHdrFS_getFrCmrHdrFS
# define Rte_Call_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd Rte_Call_CpApCoFca_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd
# define Rte_Call_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru Rte_Call_CpApCoFca_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApCoFca_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApCoFca_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApCoFca_RP_Os_Service_GetElapsedValue


/**********************************************************************************************************************
 * Exclusive Areas
 *********************************************************************************************************************/

# define Rte_Enter_ExclusiveArea_CpApCoFcaAppVersionInfo Rte_Enter_CpApCoFca_ExclusiveArea_CpApCoFcaAppVersionInfo /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */
# define Rte_Exit_ExclusiveArea_CpApCoFcaAppVersionInfo Rte_Exit_CpApCoFca_ExclusiveArea_CpApCoFcaAppVersionInfo /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */




# define CpApCoFca_START_SEC_CODE
# include "CpApCoFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApCoFCAInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CoFcaFrqNvData_CoFcaFrqNvDataRead(CoFcaNvmSaveVal_t *CoFcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CoFcaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApCoFCAInit Re_CpApCoFCAInit
FUNC(void, CpApCoFca_CODE) Re_CpApCoFCAInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApCoFCAMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn01_De_CoFcaDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn02_De_CoFcaDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn03_De_CoFcaDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn04_De_CoFcaDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn05_De_CoFcaDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaDbgIn06_De_CoFcaDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaFailSafeInfo_De_CoFcaFailSafeInfo(CoFcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS(CoFcaInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CoFcaEDR_De_EDR_Output(const CoFcaEDR_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(const CoFcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaOutput_De_CoFcaOutput(const CoFcaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc(const CoFcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA(const FcaInternalInFromCOFCA_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_CoFcaFrqNvData_CoFcaFrqNvDataWrite(const CoFcaNvmSaveVal_t *CoFcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CoFcaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd(FrCmrHdrFcfVd_t *FrCmrHdrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru(FrCmrHdrFcfVru_t *FrCmrHdrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApCoFCAMain Re_CpApCoFCAMain
FUNC(void, CpApCoFca_CODE) Re_CpApCoFCAMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApCoFcaAppVersionInfo
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfoValidate> of PortPrototype <PP_CoFcaAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_CpApCoFcaAppVersionInfo(void)
 *   void Rte_Exit_ExclusiveArea_CpApCoFcaAppVersionInfo(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApCoFcaAppVersionInfo(CoFcaAppVersionInfo_t *CoFcaAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_CoFcaAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApCoFcaAppVersionInfo Re_CpApCoFcaAppVersionInfo
FUNC(Std_ReturnType, CpApCoFca_CODE) Re_CpApCoFcaAppVersionInfo(P2VAR(CoFcaAppVersionInfo_t, AUTOMATIC, RTE_CPAPCOFCA_APPL_VAR) CoFcaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApCoFca_STOP_SEC_CODE
# include "CpApCoFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_CoFcaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_CoFcaFrqNvData_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPCOFCA_H */
