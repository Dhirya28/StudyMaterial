/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApPCan.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPCan
 *  Generation Time:  2023-04-20 13:52:45
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApPCan> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPPCAN_H
# define _RTE_CPAPPCAN_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApPCan_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApPCan
{
  /* PIM Handles section */
  P2VAR(RdrInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_RdrInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApPCan, RTE_CONST, RTE_CONST) Rte_Inst_CpApPCan; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApPCan, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus (0U)
# define Rte_InitValue_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_Eol_FCA_FCA (0U)
# define Rte_InitValue_RP_Eol_VehicleMY_VehicleMY (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(P2VAR(COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(P2VAR(COM_DT_SG_RD_DTC_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_RP_ADAS101_De_ADAS101(P2VAR(ADAS101_t, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_RP_Eol_FCA_FCA(P2VAR(uint8, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApPCan_RP_Eol_VehicleMY_VehicleMY(P2VAR(uint8, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApPCan_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_COM_SG_ADAS101_2Gen_SignalGroup_COM_SG_ADAS101_2Gen_SignalGroup(P2CONST(COM_DT_SG_ADAS101_2Gen_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_COM_SG_ADAS101_3Gen_SignalGroup_COM_SG_ADAS101_3Gen_SignalGroup(P2CONST(COM_DT_SG_ADAS101_3Gen_SignalGroup, AUTOMATIC, RTE_CPAPPCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_COM_SG_CodingForRadar_COM_SG_CodingForRadar(P2CONST(COM_DT_SG_CodingForRadar, AUTOMATIC, RTE_CPAPPCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_PP_RadarDtcInfo_RadarDtcInfo(P2CONST(RadarDtcInfo_t, AUTOMATIC, RTE_CPAPPCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApPCan_PP_SccRdrBlockage_De_SccRdrBlockage(P2CONST(SccRdrBlockage_t, AUTOMATIC, RTE_CPAPPCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApPCan_RP_PCan_BusOFFStatus_BSW_BswM_MDGP_BswMPCAN_RteModeDclGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApPCan_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApPCan_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup
# define Rte_Read_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup Rte_Read_CpApPCan_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup
# define Rte_Read_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup Rte_Read_CpApPCan_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup
# define Rte_Read_RP_ADAS101_De_ADAS101 Rte_Read_CpApPCan_RP_ADAS101_De_ADAS101
# define Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApPCan_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_Eol_FCA_FCA Rte_Read_CpApPCan_RP_Eol_FCA_FCA
# define Rte_Read_RP_Eol_VehicleMY_VehicleMY Rte_Read_CpApPCan_RP_Eol_VehicleMY_VehicleMY


/**********************************************************************************************************************
 * Rte_IsUpdated_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup Rte_IsUpdated_CpApPCan_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_COM_SG_ADAS101_2Gen_SignalGroup_COM_SG_ADAS101_2Gen_SignalGroup Rte_Write_CpApPCan_COM_SG_ADAS101_2Gen_SignalGroup_COM_SG_ADAS101_2Gen_SignalGroup
# define Rte_Write_COM_SG_ADAS101_3Gen_SignalGroup_COM_SG_ADAS101_3Gen_SignalGroup Rte_Write_CpApPCan_COM_SG_ADAS101_3Gen_SignalGroup_COM_SG_ADAS101_3Gen_SignalGroup
# define Rte_Write_COM_SG_CodingForRadar_COM_SG_CodingForRadar Rte_Write_CpApPCan_COM_SG_CodingForRadar_COM_SG_CodingForRadar
# define Rte_Write_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus Rte_Write_CpApPCan_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus
# define Rte_Write_PP_RadarDtcInfo_RadarDtcInfo Rte_Write_CpApPCan_PP_RadarDtcInfo_RadarDtcInfo
# define Rte_Write_PP_SccRdrBlockage_De_SccRdrBlockage Rte_Write_CpApPCan_PP_SccRdrBlockage_De_SccRdrBlockage


/**********************************************************************************************************************
 * Rte_Mode_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Mode_RP_PCan_BusOFFStatus_BSW_BswM_MDGP_BswMPCAN_RteModeDclGroup Rte_Mode_CpApPCan_RP_PCan_BusOFFStatus_BSW_BswM_MDGP_BswMPCAN_RteModeDclGroup


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus Rte_Call_CpApPCan_RP_AppDiagFaultStatus_GetAppDiagFltStatus
# define Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApPCan_RP_AppDiagFaultStatus_SetAppDiagFltStatus


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_RdrInfo() (Rte_Inst_CpApPCan->Pim_RdrInfo) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   RdrInfo_t *Rte_Pim_RdrInfo(void)
 *
 *********************************************************************************************************************/


# define CpApPCan_START_SEC_CODE
# include "CpApPCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPCanInit Re_CpApPCanInit
FUNC(void, CpApPCan_CODE) Re_CpApPCanInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_05_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_06_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_07_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_08_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_09_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_10_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_11_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_12_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_13_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_14_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_15_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Det_16_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_05_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_06_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_07_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_08_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_09_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_10_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_11_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_12_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_13_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_14_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_15_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(COM_DT_SG_L_FR_RDR_Obj_16_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(COM_DT_SG_RD_DTC_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_ADAS101_De_ADAS101(ADAS101_t *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_FCA_FCA(uint8 *data)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_02_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_03_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_05_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_06_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_07_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_08_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_09_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_10_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_11_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_12_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_13_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_14_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_15_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Det_16_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_02_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_03_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_05_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_06_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_07_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_08_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_09_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_10_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_11_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_12_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_13_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_14_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_15_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup_COM_SG_L_FR_RDR_Obj_16_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_RD_DTC_SignalGroup_COM_SG_RD_DTC_SignalGroup(void)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_RadarDtcInfo_RadarDtcInfo(const RadarDtcInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_SccRdrBlockage_De_SccRdrBlockage(const SccRdrBlockage_t *data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_RP_PCan_BusOFFStatus_BSW_BswM_MDGP_BswMPCAN_RteModeDclGroup(void)
 *   Modes of Rte_ModeType_BswMPCAN_RteModeDclGroup:
 *   - RTE_MODE_BswMPCAN_RteModeDclGroup_PCANBusoff
 *   - RTE_MODE_BswMPCAN_RteModeDclGroup_PCANNormal
 *   - RTE_TRANSITION_BswMPCAN_RteModeDclGroup
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPCanMain Re_CpApPCanMain
FUNC(void, CpApPCan_CODE) Re_CpApPCanMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPCanOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_VehicleMY_VehicleMY(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_ADAS101_2Gen_SignalGroup_COM_SG_ADAS101_2Gen_SignalGroup(const COM_DT_SG_ADAS101_2Gen_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS101_3Gen_SignalGroup_COM_SG_ADAS101_3Gen_SignalGroup(const COM_DT_SG_ADAS101_3Gen_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_CodingForRadar_COM_SG_CodingForRadar(const COM_DT_SG_CodingForRadar *data)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApPCanOut Re_CpApPCanOut
FUNC(void, CpApPCan_CODE) Re_CpApPCanOut(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApRdrmsg
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getRdrInfo> of PortPrototype <PP_RdrInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApRdrmsg(RdrInfo_t *Rdrmsg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_RdrInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApRdrmsg Re_CpApRdrmsg
FUNC(Std_ReturnType, CpApPCan_CODE) Re_CpApRdrmsg(P2VAR(RdrInfo_t, AUTOMATIC, RTE_CPAPPCAN_APPL_VAR) Rdrmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApPCan_STOP_SEC_CODE
# include "CpApPCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_RdrInfo_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPPCAN_H */
