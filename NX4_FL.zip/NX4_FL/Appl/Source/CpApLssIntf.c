/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApLssIntf.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLssIntf
 *  Generation Time:  2023-04-20 13:53:23
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApLssIntf>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApLssIntf.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Record Types:
 * =============
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * LssFrqNvData_t: Record with elements
 *   s16_NVM_r_SteerWhlAgOffs of type sint16
 *   s16_NVM_r_YawRateOffs of type sint16
 *   s16_NVM_r_StrColTqOffs of type sint16
 *   s16_Nvm_Rom_HdngAngOffset of type sint16
 *   u8_NVM_r_LkasUsmOpt of type uint8
 *   u8_NVM_r_LkasUsmOptDelay of type uint8
 *   u8_NVM_r_LFA_Opt_USM of type uint8
 *   u8_Rom_SysOff of type uint8
 *   u8_NVM_LKA_Status of type uint8
 *   u8_NVM_LFA_Status of type uint8
 *   u8_NVM_HdaStatus_User1 of type uint8
 *   u8_NVM_HdaStatus_User2 of type uint8
 *   u8_NVM_HdaStatus_Guest of type uint8
 *   u8_NVM_ProfileIDRVal of type uint8
 *   u8_NVM_WarnSndUSMSta of type uint8
 *   Reserved of type uint8
 * LssMeInfo_t: Record with elements
 *   b_MEFailSafeLKA of type uint8
 *   u8_DrivingSideME of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   LssFrqNvData_t *Rte_Pim_LssFrqNvData(void)
 *
 *********************************************************************************************************************/


#define CpApLssIntf_START_SEC_CODE
#include "CpApLssIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLssIntf_CODE) CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApLssIntf_NvMNotifyJobFinished_LssFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_DrivingSideStatus_De_DrivingSideStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_LssMeInfo_De_LssMeInfo(const LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_CRC(uint32 *COM_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Cam_Frame_ID(uint32 *COM_Cam_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_DayTime_Indicator(uint8 *COM_DayTime_Indicator)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Delta_Sync(uint32 *COM_Delta_Sync)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side(uint8 *COM_Driving_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Driving_Side_V(uint8 *COM_Driving_Side_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Exposure_Type(uint8 *COM_Exposure_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_EyeQ_Frame_ID(uint32 *COM_EyeQ_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Frame_MCU_TS_Start(uint64 *COM_Frame_MCU_TS_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_HIL_Mode_Status(uint8 *COM_HIL_Mode_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road(uint8 *COM_Is_HighSpeed_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_HighSpeed_Road_V(uint8 *COM_Is_HighSpeed_Road_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Is_In_Tunnel(uint8 *COM_Is_In_Tunnel)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Error(uint8 *COM_Last_Clock_Sync_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_Clock_Sync_Skew(uint32 *COM_Last_Clock_Sync_Skew)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Last_MCU_Sync_TS(uint64 *COM_Last_MCU_Sync_TS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_1(uint32 *COM_ProtocolCycle_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ProtocolCycle_2(uint32 *COM_ProtocolCycle_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Protocol_Version(uint8 *COM_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code(uint8 *COM_Region_Code)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Region_Code_V(uint8 *COM_Region_Code_V)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_ReportingCycleMode(uint8 *COM_ReportingCycleMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Sync_Frame_ID(uint8 *COM_Sync_Frame_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_CMN_EYEQDG_Get_CMN_COM_Tunnel_Conf(uint8 *COM_Tunnel_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_CMN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, uint8 *FS_Blur_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(uint16 *FS_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, uint8 *FS_C2C_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(uint8 *FS_C2W_OOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, uint32 *FS_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, uint8 *FS_Camera_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(uint8 *FS_Cameras_Number)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, uint8 *FS_Free_Sight)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, uint8 *FS_Frozen_Windshield_Lens)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(uint32 *FS_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(uint16 *FS_Impacted_Technologies)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, uint8 *FS_Low_Sun)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(uint8 *FS_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, uint8 *FS_Out_Of_Focus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(uint8 *FS_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(uint8 *FS_Rain)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, uint8 *FS_Splashes)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(uint8 *FS_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(uint8 *FS_TSR_Out_OF_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(float32 *LDW_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(float32 *LDW_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(uint8 *LDW_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, uint32 *LDW_Suppression_Reason_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, uint32 *LDW_Suppression_Reason_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(uint8 *LDW_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, float32 *LDW_Time_To_Warning_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, float32 *LDW_Time_To_Warning_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, uint8 *LDW_Warning_Status_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, uint8 *LDW_Warning_Status_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(uint8 *LAP_Exit_Merge_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(uint8 *LAP_INTP_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, uint8 *LAP_INTP_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(uint8 *LAP_INTP_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, uint16 *LAP_INTP_Distance_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, uint8 *LAP_INTP_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, uint8 *LAP_INTP_Is_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, uint8 *LAP_INTP_Is_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, uint16 *LAP_INTP_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, uint16 *LAP_INTP_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, uint8 *LAP_INTP_Role)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, uint8 *LAP_INTP_SRD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, uint8 *LAP_INTP_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(uint8 *LAP_Is_Highway_Exit_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(uint8 *LAP_Is_Highway_Exit_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(uint8 *LAP_Is_Highway_Merge_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(uint8 *LAP_Is_Highway_Merge_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(uint8 *LAP_Path_Pred_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(uint32 *LAP_Path_Pred_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(uint8 *LAP_Path_Pred_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(float32 *LAP_Path_Pred_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(float32 *LAP_Path_Pred_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(float32 *LAP_Path_Pred_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(float32 *LAP_Path_Pred_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(uint16 *LAP_Path_Pred_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(uint8 *LAP_Path_Pred_First_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(uint16 *LAP_Path_Pred_Half_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(float32 *LAP_Path_Pred_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(float32 *LAP_Path_Pred_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(float32 *LAP_Path_Pred_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(float32 *LAP_Path_Pred_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(uint8 *LAP_Path_Pred_Second_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(uint16 *LAP_Path_Pred_second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(uint8 *LAP_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(uint8 *LAP_Snow_On_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(uint8 *LAP_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(uint8 *LAP_Vertical_Surface_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(float32 *LAP_Vertical_Surface_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(float32 *LAP_Vertical_Surface_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(float32 *LAP_Vertical_Surface_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(float32 *LAP_Vertical_Surface_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(uint16 *LAP_Vertical_Surface_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfEyeQRead_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfEyeQRead(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfEyeQRead
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_LssFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LssMeInfo_De_LssMeInfo(const LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_LssFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLssIntf_CODE) Re_CpApLssIntfMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfReadLssFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadLssFrqNvData> of PortPrototype <PP_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssIntfReadLssFrqNvData(LssFrqNvData_t *LssFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfReadLssFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLssIntf_CODE) Re_CpApLssIntfReadLssFrqNvData(P2VAR(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_VAR) LssFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfReadLssFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIntfWriteLssFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteLssFrqNvData> of PortPrototype <PP_LssFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssIntfWriteLssFrqNvData(const LssFrqNvData_t *LssFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfWriteLssFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLssIntf_CODE) Re_CpApLssIntfWriteLssFrqNvData(P2CONST(LssFrqNvData_t, AUTOMATIC, RTE_CPAPLSSINTF_APPL_DATA) LssFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIntfWriteLssFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApLssIntf_STOP_SEC_CODE
#include "CpApLssIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
