/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApUds.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUds
 *  Generation Time:  2023-04-20 13:52:50
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApUds> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPUDS_H
# define _RTE_CPAPUDS_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApUds_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApUds
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApUds, RTE_CONST, RTE_CONST) Rte_Inst_CpApUds; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApUds, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_ECU_Reset_Enabled_De_ECU_Reset (FALSE)
# define Rte_InitValue_RP_Eol_Codingcomplete_Codingcomplete (0U)
# define Rte_InitValue_RP_HCU_HevRdySta_De_HCU_HevRdySta (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_RP_BattMonData_De_BattMonData(P2VAR(BattMonData_t, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_RP_ENG_STAT_De_VCan_ENG_EngSta(P2VAR(VCan_ENG_EngSta_t, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_RP_Eol_Codingcomplete_Codingcomplete(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_RP_HCU_HevRdySta_De_HCU_HevRdySta(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUds_PP_ECU_Reset_Enabled_De_ECU_Reset(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_RP_ControlDTCSetting_ControlDTCSetting(uint8 DTCCantrolData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_RP_CpApplClearDTC_ApplClearDTC(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_IrvRead_CpApUds_Re_SupplierRequestNotification_Zf_Confirmation_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(void, RTE_CODE) Rte_IrvWrite_CpApUds_Re_SupplierRequestNotification_Zf_Indication_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_BattMonData_De_BattMonData Rte_Read_CpApUds_RP_BattMonData_De_BattMonData
# define Rte_Read_RP_ENG_STAT_De_VCan_ENG_EngSta Rte_Read_CpApUds_RP_ENG_STAT_De_VCan_ENG_EngSta
# define Rte_Read_RP_Eol_Codingcomplete_Codingcomplete Rte_Read_CpApUds_RP_Eol_Codingcomplete_Codingcomplete
# define Rte_Read_RP_HCU_HevRdySta_De_HCU_HevRdySta Rte_Read_CpApUds_RP_HCU_HevRdySta_De_HCU_HevRdySta


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_ECU_Reset_Enabled_De_ECU_Reset Rte_Write_CpApUds_PP_ECU_Reset_Enabled_De_ECU_Reset


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus Rte_Call_CpApUds_RP_AppDiagFaultStatus_GetAppDiagFltStatus
# define Rte_Call_RP_ControlDTCSetting_ControlDTCSetting Rte_Call_CpApUds_RP_ControlDTCSetting_ControlDTCSetting
# define Rte_Call_RP_CpApplClearDTC_ApplClearDTC Rte_Call_CpApUds_RP_CpApplClearDTC_ApplClearDTC


/**********************************************************************************************************************
 * Inter-runnable variables
 *********************************************************************************************************************/

/* PRQA S 3453 L1 */ /* MD_MSR_19.7 */
# define Rte_IrvRead_Re_SupplierRequestNotification_Zf_Confirmation_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv() \
  Rte_IrvRead_CpApUds_Re_SupplierRequestNotification_Zf_Confirmation_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv()
/* PRQA L:L1 */

/* PRQA S 3453 L1 */ /* MD_MSR_19.7 */
# define Rte_IrvWrite_Re_SupplierRequestNotification_Zf_Indication_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(data) \
  Rte_IrvWrite_CpApUds_Re_SupplierRequestNotification_Zf_Indication_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(data)
/* PRQA L:L1 */




# define CpApUds_START_SEC_CODE
# include "CpApUds_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApUds_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApUds_Init Re_CpApUds_Init
FUNC(void, CpApUds_CODE) Re_CpApUds_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApUds_ProgramReset
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <JUMPTOBOOTLOADER> of ModeDeclarationGroupPrototype <DcmEcuReset> of PortPrototype <DcmEcuReset>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApUds_ProgramReset Re_CpApUds_ProgramReset
FUNC(void, CpApUds_CODE) Re_CpApUds_ProgramReset(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_ReadECUSoftwareUNIT1IVD_0xF1C1
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_ECUSoftwareUNIT1IVDDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_ReadECUSoftwareUNIT1IVD_0xF1C1(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data32ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_ECUSoftwareUNIT1IVDDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_ECUSoftwareUNIT1IVDDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_ReadECUSoftwareUNIT1IVD_0xF1C1 Re_ReadECUSoftwareUNIT1IVD_0xF1C1
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_CODE) Re_ReadECUSoftwareUNIT1IVD_0xF1C1(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_CODE) Re_ReadECUSoftwareUNIT1IVD_0xF1C1(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data32ByteType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SecurityAccess_Level_9_CompareKey
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <CompareKey> of PortPrototype <SecurityAccess_Level_9>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_SecurityAccess_Level_9_CompareKey(const uint8 *Key, Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Key: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_SecurityAccess_Level_9_DCM_E_COMPARE_KEY_FAILED
 *   RTE_E_SecurityAccess_Level_9_DCM_E_PENDING
 *   RTE_E_SecurityAccess_Level_9_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SecurityAccess_Level_9_CompareKey Re_SecurityAccess_Level_9_CompareKey
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_CODE) Re_SecurityAccess_Level_9_CompareKey(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_DATA) Key, Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_CODE) Re_SecurityAccess_Level_9_CompareKey(P2CONST(Dcm_Data8ByteType, AUTOMATIC, RTE_CPAPUDS_APPL_DATA) Key, Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SecurityAccess_Level_9_GetSeed
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <GetSeed> of PortPrototype <SecurityAccess_Level_9>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_SecurityAccess_Level_9_GetSeed(Dcm_OpStatusType OpStatus, uint8 *Seed, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Seed: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_SecurityAccess_Level_9_DCM_E_PENDING
 *   RTE_E_SecurityAccess_Level_9_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SecurityAccess_Level_9_GetSeed Re_SecurityAccess_Level_9_GetSeed
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_CODE) Re_SecurityAccess_Level_9_GetSeed(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) Seed, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_CODE) Re_SecurityAccess_Level_9_GetSeed(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data8ByteType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) Seed, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SupplierRequestNotification_Zf_Confirmation
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Confirmation> of PortPrototype <ServiceRequestNotification_Zf>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_ECU_Reset_Enabled_De_ECU_Reset(boolean data)
 *
 * Inter Runnable Variables:
 * =========================
 *   Explicit Read Access:
 *   ---------------------
 *   uint8 Rte_IrvRead_Re_SupplierRequestNotification_Zf_Confirmation_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(void)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CpApplClearDTC_ApplClearDTC(void)
 *     Synchronous Server Invocation. Timeout: None
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_SupplierRequestNotification_Zf_Confirmation(uint8 SID, uint8 ReqType, uint16 SourceAddress, Dcm_ConfirmationStatusType ConfirmationStatus)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_ServiceRequestNotification_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SupplierRequestNotification_Zf_Confirmation Re_SupplierRequestNotification_Zf_Confirmation
FUNC(Std_ReturnType, CpApUds_CODE) Re_SupplierRequestNotification_Zf_Confirmation(uint8 SID, uint8 ReqType, uint16 SourceAddress, Dcm_ConfirmationStatusType ConfirmationStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SupplierRequestNotification_Zf_Indication
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Indication> of PortPrototype <ServiceRequestNotification_Zf>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_BattMonData_De_BattMonData(BattMonData_t *data)
 *   Std_ReturnType Rte_Read_RP_ENG_STAT_De_VCan_ENG_EngSta(VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Read_RP_Eol_Codingcomplete_Codingcomplete(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 *data)
 *
 * Inter Runnable Variables:
 * =========================
 *   Explicit Write Access:
 *   ----------------------
 *   void Rte_IrvWrite_Re_SupplierRequestNotification_Zf_Indication_SupplierRequestNotification_CpApUds_ControlDtcSetting_sub_function_Irv(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_ControlDTCSetting_ControlDTCSetting(uint8 DTCCantrolData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_ControlDTCSetting_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_SupplierRequestNotification_Zf_Indication(uint8 SID, const uint8 *RequestData, uint16 DataSize, uint8 ReqType, uint16 SourceAddress, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument RequestData: uint8* is of type Dcm_Data4000ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_ServiceRequestNotification_E_NOT_OK
 *   RTE_E_ServiceRequestNotification_E_REQUEST_NOT_ACCEPTED
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SupplierRequestNotification_Zf_Indication Re_SupplierRequestNotification_Zf_Indication
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_CODE) Re_SupplierRequestNotification_Zf_Indication(uint8 SID, P2CONST(uint8, AUTOMATIC, RTE_CPAPUDS_APPL_DATA) RequestData, uint16 DataSize, uint8 ReqType, uint16 SourceAddress, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_CODE) Re_SupplierRequestNotification_Zf_Indication(uint8 SID, P2CONST(Dcm_Data4000ByteType, AUTOMATIC, RTE_CPAPUDS_APPL_DATA) RequestData, uint16 DataSize, uint8 ReqType, uint16 SourceAddress, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

# define CpApUds_STOP_SEC_CODE
# include "CpApUds_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_DataServices_Data_ECUSoftwareUNIT1IVDDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_ECUSoftwareUNIT1IVDDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_ControlDTCSetting_ReturnType (1U)

# define RTE_E_SecurityAccess_Level_9_DCM_E_COMPARE_KEY_FAILED (11U)

# define RTE_E_SecurityAccess_Level_9_DCM_E_PENDING (10U)

# define RTE_E_SecurityAccess_Level_9_E_NOT_OK (1U)

# define RTE_E_ServiceRequestNotification_E_NOT_OK (1U)

# define RTE_E_ServiceRequestNotification_E_REQUEST_NOT_ACCEPTED (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPUDS_H */
