/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApIvc.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIvc
 *  Generation Time:  2023-04-20 13:53:22
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApIvc>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * TimeInMicrosecondsType
 *   uint32 represents integers with a minimum value of 0 and a maximum value 
 *      of 4294967295. The order-relation on uint32 is: x < y if y - x is positive.
 *      uint32 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39). 
 *      
 *      For example: 1, 0, 12234567, 104400.
 *
 *
 * Operation Prototypes:
 * =====================
 * GetCounterValue of Port Interface Os_Service
 *   This service reads the current count value of a counter (returning either the hardware timer ticks if counter is driven by hardware or the software ticks when user drives counter).
 *
 * GetElapsedValue of Port Interface Os_Service
 *   This service gets the number of ticks between the current tick value and a previously read tick value.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApIvc.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * TimeInMicrosecondsType: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * CoFcaUxOutToIvc_t: Record with elements
 *   ux_TT_FwdSftySymbSta of type uint8
 *   ux_MV_HostVeh1Sta_FCA of type uint8
 *   ux_PU_F_Group1_FCA_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group4_FCA_Warn1_1Sta of type uint8
 *   ux_PU_F_Group7_FCA_FwdSftyFlrSta of type uint8
 *   ux_FCA_SND_ADASWarn1_1Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_FCA of type uint8
 *   ux_PU_F_Group4_Trailer_ADASWarn1_1Sta of type uint8
 * DawUxOutToIvc_t: Record with elements
 *   ux_TT_DAW_SymbSta of type uint8
 *   ux_PU_F_Group1_DAW_Warn1_2Sta of type uint8
 *   ux_PU_F_Group4_DAW_WarnSta of type uint8
 *   ux_PU_F_Group7_DAW_FlrSta of type uint8
 *   ux_DAW_SND_ADASWarn1_2Sta of type uint8
 * DeLogicDbgInput_t: Record with elements
 *   u32_DbgDataIn_01 of type uint32
 *   u32_DbgDataIn_02 of type uint32
 *   u32_DbgDataIn_03 of type uint32
 *   u32_DbgDataIn_04 of type uint32
 *   u32_DbgDataIn_05 of type uint32
 *   u32_DbgDataIn_06 of type uint32
 *   u32_DbgDataIn_07 of type uint32
 *   u32_DbgDataIn_08 of type uint32
 *   u32_DbgDataIn_09 of type uint32
 *   u32_DbgDataIn_10 of type uint32
 *   u32_DbgDataIn_11 of type uint32
 *   u32_DbgDataIn_12 of type uint32
 *   u32_DbgDataIn_13 of type uint32
 *   u32_DbgDataIn_14 of type uint32
 *   u32_DbgDataIn_15 of type uint32
 *   u32_DbgDataIn_16 of type uint32
 * DeLogicDbgOutput_t: Record with elements
 *   u32_DbgData_01 of type uint32
 *   u32_DbgData_02 of type uint32
 *   u32_DbgData_03 of type uint32
 *   u32_DbgData_04 of type uint32
 *   u32_DbgData_05 of type uint32
 *   u32_DbgData_06 of type uint32
 *   u32_DbgData_07 of type uint32
 *   u32_DbgData_08 of type uint32
 *   u32_DbgData_09 of type uint32
 *   u32_DbgData_10 of type uint32
 *   u32_DbgData_11 of type uint32
 *   u32_DbgData_12 of type uint32
 *   u32_DbgData_13 of type uint32
 *   u32_DbgData_14 of type uint32
 *   u32_DbgData_15 of type uint32
 *   u32_DbgData_16 of type uint32
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FcaUxOutToIvc_t: Record with elements
 *   ux_TT_FwdSftySymbSta of type uint8
 *   ux_MV_HostVeh1Sta_FCA of type uint8
 *   ux_PU_F_Group1_FCA_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group4_FCA_Warn1_1Sta of type uint8
 *   ux_PU_F_Group7_FCA_FwdSftyFlrSta of type uint8
 *   ux_FCA_SND_ADASWarn1_1Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_FCA of type uint8
 *   ux_PU_F_Group4_Trailer_ADASWarn1_1Sta of type uint8
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * HbaUxOutToIvc_t: Record with elements
 *   ux_TT_HBA_SymbSta of type uint8
 *   ux_PU_F_Group7_HBA_FlrSta of type uint8
 * IslaUxOutToIvc_t: Record with elements
 *   ux_TT_ISLA_SpdLimTrffcSgnSta of type uint8
 *   ux_TT_ISLA_SpdLimTrffcSgnVal of type uint8
 *   ux_TT_ISLA_TrffcSgnCntryInfoSta of type uint8
 *   ux_TT_ISLA_AddtnlTrffcSgnSta of type uint8
 *   ux_TT_ISLA_SuppTrffcSgnSta of type uint8
 *   ux_ISLA_TrffcSgnBlnkngSta of type uint8
 *   ux_SMV_SetSpdSta_ISLA of type uint8
 *   ux_SMV_ISLA_SetSpdSymbSta of type uint8
 *   ux_ISLA_SetSpdSymbBlnkngSta of type uint8
 *   ux_PU_F_Group7_ISLA_FlrSta of type uint8
 *   ux_PU_M_Group2_ISLA_ADASWarn1_1Sta of type uint8
 *   ux_SND_ADAS_Warn1_3Sta of type uint8
 * IvcAppVersionInfo_t: Record with elements
 *   u16_IvcAppVersion of type uint16
 * IvcHptOutput_t: Record with elements
 *   u8_HPT_StrWhlWarn1Sta of type uint8
 * IvcMv1Output_t: Record with elements
 *   u8_MV_DrvLnCtLnSta of type uint8
 *   u8_MV_LtLnSta of type uint8
 *   u8_MV_RtLnSta of type uint8
 *   u8_MV_DrvLnRdsVal of type uint8
 *   u8_MV_LtLnOffstVal of type uint8
 *   u8_MV_RtLnOffstVal of type uint8
 *   u8_MV_VehDstSta of type uint8
 *   u16_MV_VehDstVal of type uint16
 * IvcMv2Output_t: Record with elements
 *   u8_MV_HostVeh1Sta of type uint8
 *   u8_MV_FrObjSta of type uint8
 *   u16_MV_FrObjLongPosVal of type uint16
 *   s8_MV_FrObjLatPosVal of type sint8
 * IvcPuFOutput_t: Record with elements
 *   u8_PU_F_Group1_ADASWarn1_1Sta of type uint8
 *   u8_PU_F_Group1_ADASWarn1_2Sta of type uint8
 *   u8_PU_F_Group4_ADASWarn1_1Sta of type uint8
 *   u8_PU_F_Group7_FwdSftyFlrSta of type uint8
 *   u8_PU_F_Group7_LnSftyFlrSta of type uint8
 *   u8_PU_F_Group7_ISLA_FlrSta of type uint8
 *   u8_PU_F_Group7_DAW_FlrSta of type uint8
 *   u8_PU_F_Group7_HBA_FlrSta of type uint8
 *   u8_PU_F_Group7_SCC_FlrSta of type uint8
 *   u8_PU_F_Group7_LFA_FlrSta of type uint8
 *   u8_PU_F_Group7_HDA_FlrSta of type uint8
 *   u8_PU_F_Group7_MRM_FlrSta of type uint8
 *   u8_PU_F_Group7_DrvrAsstFlr1Sta of type uint8
 * IvcPuMOutput_t: Record with elements
 *   u8_PU_M_Group2_ADASWarn1_1Sta of type uint8
 * IvcSmvOutput_t: Record with elements
 *   u8_SMV_FrObjSta of type uint8
 *   u8_SMV_VehDstLvlVal of type uint8
 *   u8_SMV_VehDstLvlSta of type uint8
 *   u8_SMV_HostVehSta of type uint8
 *   u8_SMV_SetSpdSta of type uint8
 *   u8_SMV_SetSpdVal of type uint8
 *   u8_SMV_HDA_SymbSta of type uint8
 *   u8_SMV_ISLA_SetSpdSymbSta of type uint8
 *   u8_SMV_NSCC_SymbSta of type uint8
 *   u8_SMV_LFA_SymbSta of type uint8
 *   u8_SMV_DrvAsstHUDSymbSta of type uint8
 * IvcSndOutput_t: Record with elements
 *   u8_SND_ADASWarn1_1Sta of type uint8
 *   u8_SND_ADASWarn1_2Sta of type uint8
 *   u8_SND_ADASWarn1_3Sta of type uint8
 *   u8_SND_ADASWarn1_4Sta of type uint8
 *   u8_SND_ADASWarn1_5Sta of type uint8
 * IvcSymbStaOutput_t: Record with elements
 *   u8_TT_FwdSftySymbSta of type uint8
 *   u8_TT_LnSftySymbSta of type uint8
 *   u8_TT_DAW_SymbSta of type uint8
 *   u8_TT_HBA_SymbSta of type uint8
 * IvcTrffcSgnOutput_t: Record with elements
 *   u8_TT_ISLA_SpdLimTrffcSgnSta of type uint8
 *   u8_TT_ISLA_SpdLimTrffcSgnVal of type uint8
 *   u8_TT_ISLA_TrffcSgnCntryInfoSta of type uint8
 *   u8_TT_ISLA_AddtnlTrffcSgnSta of type uint8
 *   u8_TT_ISLA_SuppTrffcSgnSta of type uint8
 * IvcVarOutput_t: Record with elements
 *   u32_VAR_Opt1Sta of type uint32
 * LssUxOutToIvc_t: Record with elements
 *   ux_TT_LnSftySymbSta of type uint8
 *   ux_SMV_HDA_SymbSta of type uint8
 *   ux_SMV_LFA_SymbSta of type uint8
 *   ux_MV_DrvLnCtLnSta of type uint8
 *   ux_MV_LtLnSta_LKA of type uint8
 *   ux_MV_LtLnSta_LFA of type uint8
 *   ux_MV_RtLnSta_LKA of type uint8
 *   ux_MV_RtLnSta_LFA of type uint8
 *   ux_MV_HostVeh1Sta_LKA of type uint8
 *   ux_MV_HostVeh1Sta_LFA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_LKA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_LFA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_HDA of type uint8
 *   ux_PU_F_Group7_LnSftyFlrSta of type uint8
 *   ux_PU_F_Group7_LFA_FlrSta of type uint8
 *   ux_PU_F_Group7_HDA_FlrSta of type uint8
 *   ux_LKA_SND_ADASWarn1_2Sta of type uint8
 *   ux_LFA_SND_ADASWarn1_2Sta of type uint8
 *   ux_HDA_SND_ADASWarn1_2Sta of type uint8
 *   ux_LFA_SND_ADASWarn1_4Sta of type uint8
 *   ux_SND_ADASWarn1_5Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_LKA of type uint8
 * MrmUxOutToIvc_t: Record with elements
 *   ux_PU_F_Group1_ADASWarn1_2Sta_MRM of type uint8
 *   ux_MRM_SND_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group7_MRM_FlrSta of type uint8
 * SccUxOutToIvc_t: Record with elements
 *   ux_SMV_FrObjSta of type uint8
 *   ux_SMV_VehDstLvlVal of type uint8
 *   ux_SMV_VehDstLvlSta of type uint8
 *   ux_SMV_HostVehSta of type uint8
 *   ux_SMV_SetSpdSta_SCC of type uint8
 *   ux_SMV_SetSpdVal of type uint8
 *   ux_SMV_NSCC_SymbSta of type uint8
 *   ux_SMV_DrvAsstHUDSymbSta of type uint8
 *   ux_MV_VehDstSta of type uint8
 *   ux_MV_VehDstVal of type uint16
 *   ux_MV_HostVeh1Sta_SCC of type uint8
 *   ux_MV_FrObjSta of type uint8
 *   ux_MV_FrObjLongPosVal of type uint16
 *   ux_MV_FrObjLatPosVal of type sint8
 *   ux_PU_F_Group1_SCC_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group4_SCC_ADASWarn1_1Sta of type uint8
 *   ux_PU_F_Group7_SCC_FlrSta of type uint8
 *   ux_PU_M_Group2_SCC_ADASWarn1_1Sta of type uint8
 *   ux_PU_M_Group2_NSCC_ADASWarn1_1Sta of type uint8
 *   ux_SCC_SND_ADASWarn1_1Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_SCC of type uint8
 *
 *********************************************************************************************************************/


#define CpApIvc_START_SEC_CODE
#include "CpApIvc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIvc_CODE) Re_CpApIvcInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcMain10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFcaUxOutToIvc_De_CoFcaUxOutToIvc(CoFcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_DawUxOutToIvc_De_DawUxOutToIvc(DawUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaUxOutToIvc_De_FcaUxOutToIvc(FcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaUxOutToIvc_De_HbaUxOutToIvc(HbaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_IslaUxOutToIvc_De_IslaUxOutToIvc(IslaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn01_De_IvcDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn02_De_IvcDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn03_De_IvcDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn04_De_IvcDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn05_De_IvcDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcDbgIn06_De_IvcDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssUxOutToIvc_De_LssUxOutToIvc(LssUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_MrmUxOutToIvc_De_MrmUxOutToIvc(MrmUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Read_RP_SccUxOutToIvc_De_SccUxOutToIvc(SccUxOutToIvc_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_IvcHptOutput_De_IvcHptOutput(const IvcHptOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcMv1Output_De_IvcMv1Output(const IvcMv1Output_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcMv2Output_De_IvcMv2Output(const IvcMv2Output_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcPuFOutput_De_IvcPuFOutput(const IvcPuFOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcPuMOutput_De_IvcPuMOutput(const IvcPuMOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSmvOutput_De_IvcSmvOutput(const IvcSmvOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSndOutput_De_IvcSndOutput(const IvcSndOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcSymbStaOutput_De_IvcSymbStaOutput(const IvcSymbStaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(const IvcTrffcSgnOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcVarOutput_De_IvcVarOutput(const IvcVarOutput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcMain10ms_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIvc_CODE) Re_CpApIvcMain10ms(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcMain10ms
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIvcVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_IvcAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIvcVersionReq(IvcAppVersionInfo_t *IvcAppVersionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IvcAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcVersionReq_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIvc_CODE) Re_CpApIvcVersionReq(P2VAR(IvcAppVersionInfo_t, AUTOMATIC, RTE_CPAPIVC_APPL_VAR) IvcAppVersionInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIvcVersionReq (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApIvc_STOP_SEC_CODE
#include "CpApIvc_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
