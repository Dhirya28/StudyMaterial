/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApZfCore0.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApZfCore0
 *  Generation Time:  2023-04-20 13:53:26
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApZfCore0>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * Rte_DT_VdVruSuppFlagInfo_t_0
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_1
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_2
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * Rte_DT_VdVruSuppFlagInfo_t_3
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApZfCore0.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * COM_DT_CLU_OdoVal: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Rte_DT_VdVruSuppFlagInfo_t_0: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_1: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_2: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 * Rte_DT_VdVruSuppFlagInfo_t_3: Enumeration of integer in interval [0...255] with enumerators
 *   Cx55_NO_SUPRESS (85U)
 *   CxAA_SUPRESS (170U)
 *
 * Record Types:
 * =============
 * EYEQMESP_GenInitWheelInfo_t: Record with elements
 *   WheelRadius_FL_u16 of type uint16
 *   WheelRadius_FR_u16 of type uint16
 *   WheelRadius_RL_u16 of type uint16
 *   WheelRadius_RR_u16 of type uint16
 *   WheelTickSize_FL_u16 of type uint16
 *   WheelTickSize_FR_u16 of type uint16
 *   WheelTickSize_RL_u16 of type uint16
 *   WheelTickSize_RR_u16 of type uint16
 *   WheelRadius_FL_V_u8 of type uint8
 *   WheelRadius_FR_V_u8 of type uint8
 *   WheelRadius_RL_V_u8 of type uint8
 *   WheelRadius_RR_V_u8 of type uint8
 *   WheelTickSize_FL_V_u8 of type uint8
 *   WheelTickSize_FR_V_u8 of type uint8
 *   WheelTickSize_RL_V_u8 of type uint8
 *   WheelTickSize_RR_V_u8 of type uint8
 * EYEQ_FailSafeStatus_t: Record with elements
 *   FeatureDisableStatus_u16 of type uint16
 *   ACCFeatureDisableReason_u16 of type uint16
 *   AEBVDFeatureDisableReason_u16 of type uint16
 *   FCWVDFeatureDisableReason_u16 of type uint16
 *   AEBPDFeatureDisableReason_u16 of type uint16
 *   FCWPDFeatureDisableReason_u16 of type uint16
 *   LKALDWLCFeatureDisableReason_u16 of type uint16
 *   FREESPACEFeatureDisableReason_u16 of type uint16
 *   HLBGFHBFeatureDisableReason_u16 of type uint16
 *   TSRFeatureDisableReason_u16 of type uint16
 *   ROADFeatureDisableReason_u16 of type uint16
 *   HEATERFeatureDisableReason_u16 of type uint16
 *   Reserved_1_u16 of type uint16
 *   FsCRC_u16 of type uint16
 * MeInputCommData_t: Record with elements
 *   VehicleSpeed_u16 of type uint16
 *   VehicleSpeedValid_u8 of type uint8
 *   YawRate_u16 of type uint16
 *   YawRateValid_u8 of type uint8
 *   LatAccel_u16 of type uint16
 *   LatAccelValid_u8 of type uint8
 *   WiperStatus_u8 of type uint8
 *   WiperStatusValid_u8 of type uint8
 *   ReverseIndicator_u8 of type uint8
 *   ReverseIndicatorValid_u8 of type uint8
 *   SteeringWheelAngle_s16 of type sint16
 *   SteeringWheelAngleValid_u8 of type uint8
 *   AccelPedalValue_u8 of type uint8
 *   AccelPedalValid_u8 of type uint8
 *   AccelRate_u16 of type uint16
 *   AccelRateValid_u8 of type uint8
 *   BrakePedalPressed_u8 of type uint8
 *   BrakePedalPressedValid_u8 of type uint8
 *   VehicleDisplaySpeed_u16 of type uint16
 *   VehicleDisplaySpeedValid_u8 of type uint8
 *   TurnSwitchStatus_u8 of type uint8
 *   HighBeamActive_u8 of type uint8
 *   FogLightActive_u8 of type uint8
 *   VehicleCode_u8 of type uint8
 *   fcaGapSensitivity_u8 of type uint8
 *   fcaGapSensitivityValid_u8 of type uint8
 *   pcwGapSensitivity_u8 of type uint8
 *   pcwGapSensitivityValid_u8 of type uint8
 * VdVruSuppFlagInfo_t: Record with elements
 *   VRU_FCW_PD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_0
 *   VRU_AEB_PD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_1
 *   VD_AEB_VD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_2
 *   VD_FCW_VD_Supp_Status_u8 of type Rte_DT_VdVruSuppFlagInfo_t_3
 *
 *********************************************************************************************************************/


#define CpApZfCore0_START_SEC_CODE
#include "CpApZfCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_GetCatalogID
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_GetCatalogID> of PortPrototype <PP_IoHwAb_PowerMgr_GetCatalogID>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_PowerMgr_GetCatalogID(uint8 *EyeQCatalogId_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_GetCatalogID_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApZfCore0_CODE) IoHwAb_PowerMgr_GetCatalogID(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) EyeQCatalogId_pu8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: IoHwAb_PowerMgr_GetCatalogID (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMGR_NotifyToSendInitMsgsInTac2Mode> of PortPrototype <PP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZfCore0_CODE) Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore0Ready> of PortPrototype <RP_ProxyCore0Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_Codingcomplete_Codingcomplete(uint8 *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZfCore0_CODE) Re_CpApZfCore0Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_ECU_Reset_Enabled_De_ECU_Reset(boolean *data)
 *   Std_ReturnType Rte_Read_RP_EYEQ_FailSafeStatus_EYEQ_FailSafeStatus(EYEQ_FailSafeStatus_t *data)
 *   Std_ReturnType Rte_Read_RP_ExtWdgFltState_De_ExtWdgFltState(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_MeInputCommData_De_MeInputCommData(MeInputCommData_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_High_Beam_Active(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Code(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_External_Temp(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_External_Temp_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivity(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivityValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivity(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivityValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_NoCalibration_Fault_NoCalibration_Fault(boolean data)
 *   Std_ReturnType Rte_Write_PP_VdVruSupp_De_VdVruSuppFlagInfo(const VdVruSuppFlagInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQP_IsEyeQThermalShutdown_EYEQP_IsEyeQThermalShutdown(boolean *EyeQThermalShutdown_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQP_IsEyeQThermalShutdown_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQS_GetEyeQCurrentMainState_EYEQS_GetEyeQCurrentMainState(uint8 *EyeQCurrentMainState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQS_GetEyeQCurrentMainState_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSYSS_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSYSS_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_MAN_SetManfNextBootMode_MAN_SetManfNextBootMode(uint8 NextManfBootMode_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_MAN_SetManfNextBootMode_ReturnType
 *   Std_ReturnType Rte_Call_RP_Man_IsSetManfNextBootModeCompleted_Man_IsSetManfNextBootModeCompleted(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Man_IsSetManfNextBootModeCompleted_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0Main_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZfCore0_CODE) Re_CpApZfCore0Main(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0Main
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EyeQMgr_GetDistanceTraveled> of PortPrototype <PP_EyeQMgr_GetDistanceTraveled>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CpApZfCore0_GetOdoVal_De_OdoVal(COM_DT_CLU_OdoVal *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled(uint32 *odoMeterValue_u32, boolean *odoMeterDataStatus_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EyeQMgr_GetDistanceTraveled_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApZfCore0_CODE) Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled(P2VAR(uint32, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) odoMeterValue_u32, P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) odoMeterDataStatus_pb) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EYEQMESP_GetGenInitWheelInfo
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_GetGenInitWheelInfo> of PortPrototype <PP_EYEQMESP_GetGenInitWheelInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_EYEQMESP_GetGenInitWheelInfo(EYEQMESP_GenInitWheelInfo_t *wheelInfo_p, boolean *status_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EYEQMESP_GetGenInitWheelInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EYEQMESP_GetGenInitWheelInfo_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApZfCore0_CODE) Re_EYEQMESP_GetGenInitWheelInfo(P2VAR(EYEQMESP_GenInitWheelInfo_t, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) wheelInfo_p, P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) status_pb) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_EYEQMESP_GetGenInitWheelInfo (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateSFRNVMWriteStatus> of PortPrototype <PP_SFR_APPL_TO_EYEQMESP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus(boolean status_bo)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZfCore0_CODE) Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus(boolean status_bo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateSFRStatus> of PortPrototype <PP_SFR_APPL_TO_EYEQMESP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus(uint8 status_u8)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZfCore0_CODE) Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus(uint8 status_u8) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApZfCore0_STOP_SEC_CODE
#include "CpApZfCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
