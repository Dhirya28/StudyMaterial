/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApZfCore0.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApZfCore0
 *  Generation Time:  2023-04-20 13:53:03
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApZfCore0> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPZFCORE0_H
# define _RTE_CPAPZFCORE0_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApZfCore0_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApZfCore0
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApZfCore0, RTE_CONST, RTE_CONST) Rte_Inst_CpApZfCore0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApZfCore0, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Braking (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Is_On (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Accel_Rate (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle (0)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_High_Beam_Active (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Lat_Accel (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_SPC_Trigger (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_StandStill (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_StandStill_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle (0)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_FL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_FR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta (0)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_RL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_RR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Code (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Wiper_Status (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_Driver_Awareness (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_Driver_Awareness_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_External_Temp (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_External_Temp_Valid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_fcaGapSensitivity (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_fcaGapSensitivityValid (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_pcwGapSensitivity (0U)
# define Rte_InitValue_PP_EYEQDG_CARSNS_pcwGapSensitivityValid (0U)
# define Rte_InitValue_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown (FALSE)
# define Rte_InitValue_PP_SR_NoCalibration_Fault_NoCalibration_Fault (FALSE)
# define Rte_InitValue_RP_CpApZfCore0_GetOdoVal_De_OdoVal (0U)
# define Rte_InitValue_RP_ECU_Reset_Enabled_De_ECU_Reset (FALSE)
# define Rte_InitValue_RP_Eol_Codingcomplete_Codingcomplete (0U)
# define Rte_InitValue_RP_ExtWdgFltState_De_ExtWdgFltState (85U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_CpApZfCore0_GetOdoVal_De_OdoVal(P2VAR(COM_DT_CLU_OdoVal, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_ECU_Reset_Enabled_De_ECU_Reset(P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_EYEQ_FailSafeStatus_EYEQ_FailSafeStatus(P2VAR(EYEQ_FailSafeStatus_t, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_Eol_Codingcomplete_Codingcomplete(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_ExtWdgFltState_De_ExtWdgFltState(P2VAR(uint32, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZfCore0_RP_MeInputCommData_De_MeInputCommData(P2VAR(MeInputCommData_t, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Braking(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Is_On(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Rate(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle(sint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_High_Beam_Active(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Lat_Accel(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_SPC_Trigger(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_StandStill(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_StandStill_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle(sint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_FL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_FR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta(sint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_RL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_RR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Code(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Wiper_Status(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_Driver_Awareness(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_Driver_Awareness_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_External_Temp(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_External_Temp_Valid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR(uint16 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_fcaGapSensitivity(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_fcaGapSensitivityValid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_pcwGapSensitivity(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_pcwGapSensitivityValid(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_SR_NoCalibration_Fault_NoCalibration_Fault(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZfCore0_PP_VdVruSupp_De_VdVruSuppFlagInfo(P2CONST(VdVruSuppFlagInfo_t, AUTOMATIC, RTE_CPAPZFCORE0_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_EYEQP_IsEyeQThermalShutdown_EYEQP_IsEyeQThermalShutdown(P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) EyeQThermalShutdown_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_EYEQS_GetEyeQCurrentMainState_EYEQS_GetEyeQCurrentMainState(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) EyeQCurrentMainState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_EyeQSYSS_CoreSystemState_EyeQSYSS_CoreSystemState(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) MainState_pu8, P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) SubState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_MAN_SetManfNextBootMode_MAN_SetManfNextBootMode(uint8 NextManfBootMode_u8, P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZfCore0_RP_Man_IsSetManfNextBootModeCompleted_Man_IsSetManfNextBootModeCompleted(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_CpApZfCore0_GetOdoVal_De_OdoVal Rte_Read_CpApZfCore0_RP_CpApZfCore0_GetOdoVal_De_OdoVal
# define Rte_Read_RP_ECU_Reset_Enabled_De_ECU_Reset Rte_Read_CpApZfCore0_RP_ECU_Reset_Enabled_De_ECU_Reset
# define Rte_Read_RP_EYEQ_FailSafeStatus_EYEQ_FailSafeStatus Rte_Read_CpApZfCore0_RP_EYEQ_FailSafeStatus_EYEQ_FailSafeStatus
# define Rte_Read_RP_Eol_Codingcomplete_Codingcomplete Rte_Read_CpApZfCore0_RP_Eol_Codingcomplete_Codingcomplete
# define Rte_Read_RP_ExtWdgFltState_De_ExtWdgFltState Rte_Read_CpApZfCore0_RP_ExtWdgFltState_De_ExtWdgFltState
# define Rte_Read_RP_MeInputCommData_De_MeInputCommData Rte_Read_CpApZfCore0_RP_MeInputCommData_De_MeInputCommData


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Braking
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Is_On
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Rate
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_High_Beam_Active Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_High_Beam_Active
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Lat_Accel
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_SPC_Trigger
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_StandStill
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_StandStill_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_FL_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_FR_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_RL_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_RR_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Code Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Code
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Wiper_Status
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar
# define Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar
# define Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_Driver_Awareness
# define Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_Driver_Awareness_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_External_Temp Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_External_Temp
# define Rte_Write_PP_EYEQDG_CARSNS_External_Temp_Valid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_External_Temp_Valid
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR
# define Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V
# define Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivity Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_fcaGapSensitivity
# define Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivityValid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_fcaGapSensitivityValid
# define Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivity Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_pcwGapSensitivity
# define Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivityValid Rte_Write_CpApZfCore0_PP_EYEQDG_CARSNS_pcwGapSensitivityValid
# define Rte_Write_PP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8 Rte_Write_CpApZfCore0_PP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8
# define Rte_Write_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown Rte_Write_CpApZfCore0_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown
# define Rte_Write_PP_SR_NoCalibration_Fault_NoCalibration_Fault Rte_Write_CpApZfCore0_PP_SR_NoCalibration_Fault_NoCalibration_Fault
# define Rte_Write_PP_VdVruSupp_De_VdVruSuppFlagInfo Rte_Write_CpApZfCore0_PP_VdVruSupp_De_VdVruSuppFlagInfo


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode Rte_Call_CpApZfCore0_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
# define Rte_Call_RP_EYEQP_IsEyeQThermalShutdown_EYEQP_IsEyeQThermalShutdown Rte_Call_CpApZfCore0_RP_EYEQP_IsEyeQThermalShutdown_EYEQP_IsEyeQThermalShutdown
# define Rte_Call_RP_EYEQS_GetEyeQCurrentMainState_EYEQS_GetEyeQCurrentMainState Rte_Call_CpApZfCore0_RP_EYEQS_GetEyeQCurrentMainState_EYEQS_GetEyeQCurrentMainState
# define Rte_Call_RP_EyeQSYSS_CoreSystemState_EyeQSYSS_CoreSystemState Rte_Call_CpApZfCore0_RP_EyeQSYSS_CoreSystemState_EyeQSYSS_CoreSystemState
# define Rte_Call_RP_MAN_SetManfNextBootMode_MAN_SetManfNextBootMode Rte_Call_CpApZfCore0_RP_MAN_SetManfNextBootMode_MAN_SetManfNextBootMode
# define Rte_Call_RP_Man_IsSetManfNextBootModeCompleted_Man_IsSetManfNextBootModeCompleted Rte_Call_CpApZfCore0_RP_Man_IsSetManfNextBootModeCompleted_Man_IsSetManfNextBootModeCompleted




# define CpApZfCore0_START_SEC_CODE
# include "CpApZfCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: IoHwAb_PowerMgr_GetCatalogID
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <IoHwAb_PowerMgr_GetCatalogID> of PortPrototype <PP_IoHwAb_PowerMgr_GetCatalogID>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType IoHwAb_PowerMgr_GetCatalogID(uint8 *EyeQCatalogId_pu8)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_IoHwAb_PowerMgr_GetCatalogID IoHwAb_PowerMgr_GetCatalogID
FUNC(Std_ReturnType, CpApZfCore0_CODE) IoHwAb_PowerMgr_GetCatalogID(P2VAR(uint8, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) EyeQCatalogId_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMGR_NotifyToSendInitMsgsInTac2Mode> of PortPrototype <PP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
FUNC(void, CpApZfCore0_CODE) Re_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore0Ready> of PortPrototype <RP_ProxyCore0Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_Codingcomplete_Codingcomplete(uint8 *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZfCore0Init Re_CpApZfCore0Init
FUNC(void, CpApZfCore0_CODE) Re_CpApZfCore0Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_ECU_Reset_Enabled_De_ECU_Reset(boolean *data)
 *   Std_ReturnType Rte_Read_RP_EYEQ_FailSafeStatus_EYEQ_FailSafeStatus(EYEQ_FailSafeStatus_t *data)
 *   Std_ReturnType Rte_Read_RP_ExtWdgFltState_De_ExtWdgFltState(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_MeInputCommData_De_MeInputCommData(MeInputCommData_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_BrakeValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_AEB_Brake_Activated(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Braking_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Is_On_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Acc_Status_Available_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Pedal_Value(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Accel_Rate_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Ambient_Light_Level_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Position(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Brake_Pedal_Pressed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Effective_Steer_Axle_Angle(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Fog_Light_Active(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_FrontWheelsAngle_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_High_Beam_Active(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Lat_Accel_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Movable_Parts_Unlocked_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Reverse_Indicator_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_SPC_Trigger_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_StandStill_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Steering_Wheel_Angle_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta(sint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Delta_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Height_Deprecated(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Pitch_Delta_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Susp_Roll_Delta_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Turn_Switch_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_VSpeed_HiPrecision_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Code(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Display_Speed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Speed_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Vehicle_Yaw_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_Wiper_Status_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_Capital(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_FirstChar(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_CIN_gpsCountryCode_SecondChar(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_Driver_Awareness_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_External_Temp(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_External_Temp_Valid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Acc_Pitch_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_PitchRate_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Gyro_RollRate_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Tire_Preassure_Psi_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelSpeed_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_FR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RL(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_WheelTicks_RR(uint16 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_FR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RL_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_GSensor_Wheel_Direction_RR_V(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivity(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_fcaGapSensitivityValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivity(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EYEQDG_CARSNS_pcwGapSensitivityValid(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SR_EyeQThermalShutdown_IsEyeQThermalShutdown(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_NoCalibration_Fault_NoCalibration_Fault(boolean data)
 *   Std_ReturnType Rte_Write_PP_VdVruSupp_De_VdVruSuppFlagInfo(const VdVruSuppFlagInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQP_IsEyeQThermalShutdown_EYEQP_IsEyeQThermalShutdown(boolean *EyeQThermalShutdown_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQP_IsEyeQThermalShutdown_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQS_GetEyeQCurrentMainState_EYEQS_GetEyeQCurrentMainState(uint8 *EyeQCurrentMainState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQS_GetEyeQCurrentMainState_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSYSS_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSYSS_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_MAN_SetManfNextBootMode_MAN_SetManfNextBootMode(uint8 NextManfBootMode_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_MAN_SetManfNextBootMode_ReturnType
 *   Std_ReturnType Rte_Call_RP_Man_IsSetManfNextBootModeCompleted_Man_IsSetManfNextBootModeCompleted(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Man_IsSetManfNextBootModeCompleted_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZfCore0Main Re_CpApZfCore0Main
FUNC(void, CpApZfCore0_CODE) Re_CpApZfCore0Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EyeQMgr_GetDistanceTraveled> of PortPrototype <PP_EyeQMgr_GetDistanceTraveled>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CpApZfCore0_GetOdoVal_De_OdoVal(COM_DT_CLU_OdoVal *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled(uint32 *odoMeterValue_u32, boolean *odoMeterDataStatus_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EyeQMgr_GetDistanceTraveled_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled
FUNC(Std_ReturnType, CpApZfCore0_CODE) Re_CpApZfCore0_EyeQMgr_GetDistanceTraveled(P2VAR(uint32, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) odoMeterValue_u32, P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) odoMeterDataStatus_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EYEQMESP_GetGenInitWheelInfo
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_GetGenInitWheelInfo> of PortPrototype <PP_EYEQMESP_GetGenInitWheelInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_EYEQMESP_GetGenInitWheelInfo(EYEQMESP_GenInitWheelInfo_t *wheelInfo_p, boolean *status_pb)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EYEQMESP_GetGenInitWheelInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_EYEQMESP_GetGenInitWheelInfo Re_EYEQMESP_GetGenInitWheelInfo
FUNC(Std_ReturnType, CpApZfCore0_CODE) Re_EYEQMESP_GetGenInitWheelInfo(P2VAR(EYEQMESP_GenInitWheelInfo_t, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) wheelInfo_p, P2VAR(boolean, AUTOMATIC, RTE_CPAPZFCORE0_APPL_VAR) status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateSFRNVMWriteStatus> of PortPrototype <PP_SFR_APPL_TO_EYEQMESP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus(boolean status_bo)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus
FUNC(void, CpApZfCore0_CODE) Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRNVMWriteStatus(boolean status_bo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateSFRStatus> of PortPrototype <PP_SFR_APPL_TO_EYEQMESP>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus(uint8 status_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus
FUNC(void, CpApZfCore0_CODE) Re_SFR_APPL_TO_EYEQMESP_EYEQMESP_UpdateSFRStatus(uint8 status_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApZfCore0_STOP_SEC_CODE
# include "CpApZfCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_EYEQMESP_GetGenInitWheelInfo_ReturnType (1U)

# define RTE_E_IF_EYEQP_IsEyeQThermalShutdown_ReturnType (1U)

# define RTE_E_IF_EYEQS_GetEyeQCurrentMainState_ReturnType (1U)

# define RTE_E_IF_EyeQMgr_GetDistanceTraveled_ReturnType (1U)

# define RTE_E_IF_EyeQSYSS_CoreSystemState_ReturnType (1U)

# define RTE_E_IF_IoHwAb_PowerMgr_GetCatalogID_ReturnType (1U)

# define RTE_E_IF_MAN_SetManfNextBootMode_ReturnType (1U)

# define RTE_E_IF_Man_IsSetManfNextBootModeCompleted_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPZFCORE0_H */
