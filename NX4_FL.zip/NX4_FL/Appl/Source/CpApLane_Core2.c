/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApLane_Core2.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLane_Core2
 *  Generation Time:  2023-04-20 13:53:22
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApLane_Core2>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CpApLane_Core2.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * sint8: Integer in interval [-128...127] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Array Types:
 * ============
 * Rte_DT_ArrFrCmrLDW_0: Array with 4 element(s) of type LDW_t
 * Rte_DT_ArrFrCmrLnAdj_0: Array with 4 element(s) of type LanesAdjacent_t
 * Rte_DT_ArrFrCmrLnAppl_0: Array with 12 element(s) of type LanesApplications_t
 * Rte_DT_ArrFrCmrLnHost_0: Array with 2 element(s) of type LanesHost_t
 * Rte_DT_ArrFrCmrLnRdEdg_0: Array with 4 element(s) of type LanesRoadEdge_t
 *
 * Record Types:
 * =============
 * ArrFrCmrLDW: Record with elements
 *   FrCmrLDW of type Rte_DT_ArrFrCmrLDW_0
 * ArrFrCmrLnAdj: Record with elements
 *   FrCmrLnAdj of type Rte_DT_ArrFrCmrLnAdj_0
 * ArrFrCmrLnAppl: Record with elements
 *   FrCmrLnAppl of type Rte_DT_ArrFrCmrLnAppl_0
 * ArrFrCmrLnHost: Record with elements
 *   FrCmrLnHost of type Rte_DT_ArrFrCmrLnHost_0
 * ArrFrCmrLnRdEdg: Record with elements
 *   FrCmrLnRdEdg of type Rte_DT_ArrFrCmrLnRdEdg_0
 * EYEQMESP_EnvironmentParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   LeftWheel_u16 of type uint16
 *   RightWheel_u16 of type uint16
 *   RefPX_Front_Bumper_u16 of type uint16
 *   CamToFrontAxle_u16 of type uint16
 *   CamToRearAxle_u16 of type uint16
 *   WheelWidth_u8 of type uint8
 *   WheelRadius_u8 of type uint8
 *   MinHorizon_u16 of type uint16
 *   MaxHorizon_u16 of type uint16
 *   MinYaw_u16 of type uint16
 *   MaxYaw_u16 of type uint16
 *   MaxRoll_u16 of type uint16
 *   Top_Crop_u16 of type uint16
 *   Bottom_Crop_u16 of type uint16
 *   Steering_Ratio_u16 of type uint16
 *   GPSToCam_dx_u16 of type uint16
 *   GPSToCam_dy_u16 of type uint16
 *   GPSToCam_dz_u16 of type uint16
 *   GPSToCam_dx_V_u8 of type uint8
 *   GPSToCam_dy_V_u8 of type uint8
 *   GPSToCam_dz_V_u8 of type uint8
 *   Top_Crop_V_u8 of type uint8
 *   Steering_Ratio_V_u8 of type uint8
 *   WheelWidth_V_u8 of type uint8
 *   WheelRadius_V_u8 of type uint8
 *   LeftWheel_V_u8 of type uint8
 *   RightWheel_V_u8 of type uint8
 *   RefPX_Front_Bumper_V_u8 of type uint8
 *   CamToFrontAxle_V_u8 of type uint8
 *   CamToRearAxle_V_u8 of type uint8
 *   MinHorizon_V_u8 of type uint8
 *   MaxHorizon_V_u8 of type uint8
 *   MinYaw_V_u8 of type uint8
 *   MaxYaw_V_u8 of type uint8
 *   MaxRoll_V_u8 of type uint8
 *   Bottom_Crop_V_u8 of type uint8
 *   fixedGpsLatency_u8 of type uint8
 *   fixedGpsLatency_V_u8 of type uint8
 *   receiverFrequency_u8 of type uint8
 *   receiverFrequency_V_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * FrCmrHdrLDW_t: Record with elements
 *   LDW_Protocol_Version of type uint8
 *   LDW_Sync_ID of type uint8
 * FrCmrHdrLnAdj_t: Record with elements
 *   LA_Protocol_Version of type uint8
 *   LA_Sync_ID of type uint8
 *   LA_Adjacent_Count of type uint8
 * FrCmrHdrLnAppl_t: Record with elements
 *   LAP_Protocol_Version of type uint8
 *   LAP_Sync_ID of type uint8
 *   LAP_Is_Construction_Area of type boolean
 *   LAP_INTP_Available of type boolean
 *   LAP_INTP_Count of type uint8
 *   LAP_Exit_Merge_Available of type boolean
 *   LAP_Is_Highway_Merge_Left of type boolean
 *   LAP_Is_Highway_Merge_Right of type boolean
 *   LAP_Is_Highway_Exit_Left of type boolean
 *   LAP_Is_Highway_Exit_Right of type boolean
 *   LAP_Vertical_Surface_Available of type boolean
 *   LAP_Vertical_Surface_C0 of type uint16
 *   LAP_Vertical_Surface_C1 of type uint16
 *   LAP_Vertical_Surface_C2 of type uint16
 *   LAP_Vertical_Surface_C3 of type uint32
 *   LAP_Vertical_Surface_VR_End of type uint16
 *   LAP_Path_Pred_CRC of type uint32
 *   LAP_Path_Pred_Available of type boolean
 *   LAP_Path_Pred_First_Valid of type boolean
 *   LAP_Path_Pred_Second_Valid of type boolean
 *   LAP_Path_Pred_Half_Width of type uint16
 *   LAP_Path_Pred_Conf of type uint8
 *   LAP_Is_Triggered_SDM_Model of type uint8
 *   LAP_Path_Pred_First_VR_End of type uint16
 *   LAP_Path_Pred_second_VR_End of type uint16
 *   LAP_Path_Pred_First_C0 of type uint32
 *   LAP_Path_Pred_First_C1 of type uint32
 *   LAP_Path_Pred_First_C2 of type uint32
 *   LAP_Path_Pred_First_C3 of type uint32
 *   LAP_Path_Pred_Second_C0 of type uint32
 *   LAP_Path_Pred_Second_C1 of type uint32
 *   LAP_Path_Pred_Second_C2 of type uint32
 *   LAP_Path_Pred_Second_C3 of type uint32
 * FrCmrHdrLnHost_t: Record with elements
 *   LH_Protocol_Version of type uint8
 *   LH_Sync_ID of type uint8
 *   LH_Lanes_Count of type uint8
 *   LH_Estimated_Width of type uint16
 * FrCmrHdrLnRdEdg_t: Record with elements
 *   LRE_Header_CRC of type uint32
 *   LRE_Protocol_Version of type uint8
 *   LRE_Sync_ID of type uint8
 *   LRE_Count of type uint8
 * LDW_t: Record with elements
 *   LDW_Suppression_Reason_Left of type uint32
 *   LDW_Suppression_Reason_Right of type uint32
 *   LDW_Time_To_Warning_Left of type float32
 *   LDW_Time_To_Warning_Right of type float32
 *   LDW_Warning_Status_Left of type uint8
 *   LDW_Warning_Status_Right of type uint8
 * LanesAdjacent_t: Record with elements
 *   LA_Lane_Track_ID of type uint8
 *   LA_Age of type uint8
 *   LA_Exist_Probability of type uint8
 *   LA_Color of type uint8
 *   LA_Color_Conf of type uint8
 *   LA_Prediction_Type of type boolean
 *   LA_Prediction_Source of type boolean
 *   LA_View_Range_Start of type uint16
 *   LA_View_Range_End of type uint16
 *   LA_Measured_VR_End of type uint16
 *   LA_Lanemark_Type of type uint8
 *   LA_DLM_Type of type uint8
 *   LA_Lanemark_Type_Conf of type uint8
 *   LA_Line_Role of type uint8
 *   LA_Marker_Width of type uint8
 *   LA_Marker_Width_STD of type uint8
 *   LA_Line_C3 of type float32
 *   LA_Line_C2 of type float32
 *   LA_Line_C1 of type float32
 *   LA_Line_C0 of type float32
 * LanesApplications_t: Record with elements
 *   LAP_INTP_ID of type uint8
 *   LAP_INTP_Age of type uint16
 *   LAP_INTP_Exist_Probability of type uint8
 *   LAP_INTP_Is_Valid of type boolean
 *   LAP_INTP_Line_Role of type uint8
 *   LAP_INTP_Type of type boolean
 *   LAP_INTP_Is_Start of type boolean
 *   LAP_INTP_Lat_Distance of type uint16
 *   LAP_INTP_Long_Distance of type uint16
 * LanesHost_t: Record with elements
 *   LH_CRC of type uint32
 *   LH_Is_Triggered_SDM_Type of type uint8
 *   LH_Is_Triggered_SDM_Model of type uint8
 *   LH_Track_ID of type uint8
 *   LH_Age of type uint8
 *   LH_Confidence of type uint8
 *   LH_Prediction_Reason of type uint8
 *   LH_Availability_State of type uint8
 *   LH_Color of type uint8
 *   LH_Color_Confidence of type uint8
 *   LH_Lanemark_Type of type uint8
 *   LH_DLM_Type of type uint8
 *   LH_DECEL_Type of type uint8
 *   LH_Lanemark_Type_Conf of type uint8
 *   LH_Side of type uint8
 *   LH_Crossing of type boolean
 *   LH_Marker_Width of type uint8
 *   LH_Marker_Width_STD of type uint8
 *   LH_Dash_Average_Available of type boolean
 *   LH_Dash_Average_Length of type uint8
 *   LH_Dash_Average_Gap of type uint8
 *   LH_Is_Multi_Clothoid of type boolean
 *   LH_Line_First_C0 of type float32
 *   LH_Line_First_C1 of type float32
 *   LH_Line_First_C2 of type float32
 *   LH_Line_First_C3 of type float32
 *   LH_First_VR_Start of type uint16
 *   LH_First_VR_End of type uint16
 *   LH_First_Measured_VR_End of type uint16
 *   LH_Second_Measured_VR_End of type uint16
 *   LH_Line_Second_C0 of type float32
 *   LH_Line_Second_C1 of type float32
 *   LH_Line_Second_C2 of type float32
 *   LH_Line_Second_C3 of type float32
 *   LH_Second_VR_Start of type uint16
 *   LH_Second_VR_End of type uint16
 *   LH_Is_Construction_Area of type boolean
 * LanesRoadEdge_t: Record with elements
 *   LRE_Element_CRC of type uint32
 *   LRE_ID of type uint8
 *   LRE_Age of type uint8
 *   LRE_Confidence of type uint8
 *   LRE_Type of type uint8
 *   LRE_Prediction_Reason of type uint8
 *   LRE_Availability_State of type uint8
 *   LRE_Height of type uint8
 *   LRE_Height_STD of type uint8
 *   LRE_View_Range_Start of type uint16
 *   LRE_View_Range_End of type uint16
 *   LRE_Measured_VR_End of type uint16
 *   LRE_Side of type uint8
 *   LRE_Is_Triggered_SDM_Model of type uint8
 *   LRE_Line_C3 of type float32
 *   LRE_Line_C2 of type float32
 *   LRE_Line_C1 of type float32
 *   LRE_Line_C0 of type float32
 *   LRE_Position of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrLDW *Rte_Pim_ArrFrCmrLDW(void)
 *   ArrFrCmrLnAdj *Rte_Pim_ArrFrCmrLnAdj(void)
 *   ArrFrCmrLnAppl *Rte_Pim_ArrFrCmrLnAppl(void)
 *   ArrFrCmrLnHost *Rte_Pim_ArrFrCmrLnHost(void)
 *   ArrFrCmrLnRdEdg *Rte_Pim_ArrFrCmrLnRdEdg(void)
 *
 *********************************************************************************************************************/


#define CpApLane_Core2_START_SEC_CODE
#include "CpApLane_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLDW
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLDW> of PortPrototype <PP_FrCmrHdrLDW>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLDW(FrCmrHdrLDW_t *FrCmrHdrLDW)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLDW_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLDW_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLDW(P2VAR(FrCmrHdrLDW_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLDW) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLDW (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnAdj
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnAdj> of PortPrototype <PP_FrCmrHdrLnAdj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnAdj(FrCmrHdrLnAdj_t *FrCmrHdrLnAdj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnAdj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnAdj_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnAdj(P2VAR(FrCmrHdrLnAdj_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnAdj) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnAdj (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnAppl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnAppl> of PortPrototype <PP_FrCmrHdrLnAppl>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnAppl(FrCmrHdrLnAppl_t *FrCmrHdrLnAppl)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnAppl_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnAppl_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnAppl(P2VAR(FrCmrHdrLnAppl_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnAppl) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnAppl (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnHost
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnHost> of PortPrototype <PP_FrCmrHdrLnHost>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnHost_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnHost(P2VAR(FrCmrHdrLnHost_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnHost) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnHost (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrHdrLnRdEdg
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrLnRdEdg> of PortPrototype <PP_FrCmrHdrLnRdEdg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrHdrLnRdEdg(FrCmrHdrLnRdEdg_t *FrCmrHdrLnRdEdg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnRdEdg_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrHdrLnRdEdg(P2VAR(FrCmrHdrLnRdEdg_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrHdrLnRdEdg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrHdrLnRdEdg (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLDW
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLDW> of PortPrototype <PP_FrCmrLDW>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLDW(LDW_t *FrCmrLDW)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLDW_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLDW_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLDW(P2VAR(LDW_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLDW) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLDW (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnAdj
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnAdj> of PortPrototype <PP_FrCmrLnAdj>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnAdj(LanesAdjacent_t *FrCmrLnAdj)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnAdj_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnAdj_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnAdj(P2VAR(LanesAdjacent_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnAdj) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnAdj (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnAppl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnAppl> of PortPrototype <PP_FrCmrLnAppl>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnAppl(LanesApplications_t *FrCmrLnAppl)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnAppl_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnAppl_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnAppl(P2VAR(LanesApplications_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnAppl) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnAppl (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnHost
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnHost> of PortPrototype <PP_FrCmrLnHost>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnHost_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnHost_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnHost) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnHost (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_FrCmrLnRdEdg
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrLnRdEdg> of PortPrototype <PP_FrCmrLnRdEdg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLane_Core2_FrCmrLnRdEdg(LanesRoadEdge_t *FrCmrLnRdEdg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrLnRdEdg_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnRdEdg_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLane_Core2_CODE) Re_CpApLane_Core2_FrCmrLnRdEdg(P2VAR(LanesRoadEdge_t, AUTOMATIC, RTE_CPAPLANE_CORE2_APPL_VAR) FrCmrLnRdEdg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_FrCmrLnRdEdg (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLane_Core2_CODE) Re_CpApLane_Core2_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLane_Core2_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Application_version(uint32 *APP_Application_version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Brain_drops_counter(uint32 *APP_Brain_drops_counter)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_CRC32(uint32 *APP_CRC32)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt1(uint32 *APP_Camera1_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_VideoErrorFlags_pt2(uint32 *APP_Camera1_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_1(sint8 *APP_Camera1_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera1_temperature_2(sint8 *APP_Camera1_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt1(uint32 *APP_Camera2_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_VideoErrorFlags_pt2(uint32 *APP_Camera2_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_1(sint8 *APP_Camera2_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera2_temperature_2(sint8 *APP_Camera2_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt1(uint32 *APP_Camera3_VideoErrorFlags_pt1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_VideoErrorFlags_pt2(uint32 *APP_Camera3_VideoErrorFlags_pt2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_1(sint8 *APP_Camera3_temperature_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Camera3_temperature_2(sint8 *APP_Camera3_temperature_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_1(uint16 *APP_Diagnostics_part_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Diagnostics_part_2(uint16 *APP_Diagnostics_part_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_External_Video_Error(uint16 *APP_External_Video_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature1(sint16 *APP_EyeQTemperature1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQTemperature2(sint16 *APP_EyeQTemperature2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Current_Timestamp(uint32 *APP_EyeQ_Current_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Process_Index(uint32 *APP_EyeQ_Process_Index)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_EyeQ_Timestamp(uint32 *APP_EyeQ_Timestamp)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_FE_OPTICAL_PATH_DEVICE_ID(uint8 *APP_FE_OPTICAL_PATH_DEVICE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Fatal_Error(uint8 *APP_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Camera_Data(uint32 *APP_Internal_Camera_Data)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Internal_Fatal_Error(uint32 *APP_Internal_Fatal_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Minor_Error(uint16 *APP_Minor_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_1(uint8 *APP_RSRV_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_2(uint8 *APP_RSRV_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_4(uint8 *APP_RSRV_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_5(sint8 *APP_RSRV_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_6(sint8 *APP_RSRV_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_7(sint8 *APP_RSRV_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_8(sint8 *APP_RSRV_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_RSRV_9(sint8 *APP_RSRV_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Rx(uint32 *APP_SPI_Bus_Load_Rx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Bus_Load_Tx(uint32 *APP_SPI_Bus_Load_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_SPI_Retransmit_Tx(uint32 *APP_SPI_Retransmit_Tx)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Sub_State(uint8 *APP_Sub_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Temperature_DDR(sint8 *APP_Temperature_DDR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_cameras_information(uint8 *APP_Valid_cameras_information)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Valid_second_cam_temp_info(uint8 *APP_Valid_second_cam_temp_info)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag1(uint8 *APP_ZQ_Cal_internal_diag1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_ZQ_Cal_internal_diag2(uint8 *APP_ZQ_Cal_internal_diag2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_appMode(uint32 *APP_appMode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_spiErrors(uint8 *APP_spiErrors)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_Application_Message_Version(uint8 *Application_Message_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C0(float32 *LDW_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Buffer_C1(float32 *LDW_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Protocol_Version(uint8 *LDW_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Left(uint16 Index, uint32 *LDW_Suppression_Reason_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Suppression_Reason_Right(uint16 Index, uint32 *LDW_Suppression_Reason_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Sync_ID(uint8 *LDW_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Left(uint16 Index, float32 *LDW_Time_To_Warning_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Time_To_Warning_Right(uint16 Index, float32 *LDW_Time_To_Warning_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Left(uint16 Index, uint8 *LDW_Warning_Status_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_LDW_Warning_Status_Right(uint16 Index, uint8 *LDW_Warning_Status_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_2(uint16 Index, uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_3(uint16 Index, uint16 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LDW_EYEQDG_Get_LDW_Reserved_4(uint16 Index, uint32 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Adjacent_Count(uint8 *LA_Adjacent_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Age(uint16 Index, uint8 *LA_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Availability_State(uint16 Index, uint8 *LA_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color(uint16 Index, uint8 *LA_Color)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Color_Conf(uint16 Index, uint8 *LA_Color_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Confidence(uint16 Index, uint8 *LA_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DECEL_Type(uint16 Index, uint8 *LA_DECEL_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_DLM_Type(uint16 Index, uint8 *LA_DLM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lane_Track_ID(uint16 Index, uint8 *LA_Lane_Track_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type(uint16 Index, uint8 *LA_Lanemark_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Lanemark_Type_Conf(uint16 Index, uint8 *LA_Lanemark_Type_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C0(uint16 Index, float32 *LA_Line_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C1(uint16 Index, float32 *LA_Line_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C2(uint16 Index, float32 *LA_Line_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_C3(uint16 Index, float32 *LA_Line_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Line_Side(uint16 Index, uint8 *LA_Line_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width(uint16 Index, uint8 *LA_Marker_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Marker_Width_STD(uint16 Index, uint8 *LA_Marker_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Measured_VR_End(uint16 Index, uint16 *LA_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Prediction_Reason(uint16 Index, uint8 *LA_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Protocol_Version(uint8 *LA_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_Sync_ID(uint8 *LA_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_End(uint16 Index, uint16 *LA_View_Range_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LA_View_Range_Start(uint16 Index, uint16 *LA_View_Range_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_LH_Buffer_C1(uint16 Index, uint8 *LH_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNADJ_EYEQDG_Get_LNADJ_Reserved_4(uint16 Index, uint32 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNADJ_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c3(uint8 *LAP_Buffer_c3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c4(uint8 *LAP_Buffer_c4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Buffer_c5(uint8 *LAP_Buffer_c5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Exit_Merge_Available(uint8 *LAP_Exit_Merge_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Available(uint8 *LAP_INTP_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Confidence(uint16 Index, uint8 *LAP_INTP_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Count(uint8 *LAP_INTP_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Distance_Age(uint16 Index, uint16 *LAP_INTP_Distance_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_ID(uint16 Index, uint8 *LAP_INTP_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Start(uint16 Index, uint8 *LAP_INTP_Is_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Is_Valid(uint16 Index, uint8 *LAP_INTP_Is_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Lat_Distance(uint16 Index, uint16 *LAP_INTP_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Long_Distance(uint16 Index, uint16 *LAP_INTP_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Role(uint16 Index, uint8 *LAP_INTP_Role)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_SRD(uint16 Index, uint8 *LAP_INTP_SRD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_INTP_Type(uint16 Index, uint8 *LAP_INTP_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Left(uint8 *LAP_Is_Highway_Exit_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Exit_Right(uint8 *LAP_Is_Highway_Exit_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Left(uint8 *LAP_Is_Highway_Merge_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Is_Highway_Merge_Right(uint8 *LAP_Is_Highway_Merge_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Available(uint8 *LAP_Path_Pred_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_CRC(uint32 *LAP_Path_Pred_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Conf(uint8 *LAP_Path_Pred_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C0(float32 *LAP_Path_Pred_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C1(float32 *LAP_Path_Pred_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C2(float32 *LAP_Path_Pred_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_C3(float32 *LAP_Path_Pred_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_VR_End(uint16 *LAP_Path_Pred_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_First_Valid(uint8 *LAP_Path_Pred_First_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Half_Width(uint16 *LAP_Path_Pred_Half_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Is_Triggered_SDM_Model(uint8 *LAP_Path_Pred_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C0(float32 *LAP_Path_Pred_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C1(float32 *LAP_Path_Pred_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C2(float32 *LAP_Path_Pred_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_C3(float32 *LAP_Path_Pred_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_Second_Valid(uint8 *LAP_Path_Pred_Second_Valid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Path_Pred_second_VR_End(uint16 *LAP_Path_Pred_second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Protocol_Version(uint8 *LAP_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Snow_On_Road(uint8 *LAP_Snow_On_Road)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Sync_ID(uint8 *LAP_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_Available(uint8 *LAP_Vertical_Surface_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C0(float32 *LAP_Vertical_Surface_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C1(float32 *LAP_Vertical_Surface_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C2(float32 *LAP_Vertical_Surface_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_C3(float32 *LAP_Vertical_Surface_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_LAP_Vertical_Surface_VR_End(uint16 *LAP_Vertical_Surface_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_2(uint16 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_3(uint32 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_4(uint16 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_5(uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_6(uint32 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_8(uint16 Index, uint8 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_Get_LNAPP_Reserved_9(uint16 Index, uint32 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNAPP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNAPP_EYEQDG_LNAPP_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Age(uint16 Index, uint8 *LH_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Availability_State(uint16 Index, uint8 *LH_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Buffer_C3(uint16 Index, uint8 *LH_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_CRC(uint16 Index, uint32 *LH_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color(uint16 Index, uint8 *LH_Color)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Color_Confidence(uint16 Index, uint8 *LH_Color_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Confidence(uint16 Index, uint8 *LH_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Crossing(uint16 Index, uint8 *LH_Crossing)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DECEL_Type(uint16 Index, uint8 *LH_DECEL_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_DLM_Type(uint16 Index, uint8 *LH_DLM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Available(uint16 Index, uint8 *LH_Dash_Average_Available)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Gap(uint16 Index, uint8 *LH_Dash_Average_Gap)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Dash_Average_Length(uint16 Index, uint8 *LH_Dash_Average_Length)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Estimated_Width(uint16 *LH_Estimated_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_Measured_VR_End(uint16 Index, uint16 *LH_First_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_End(uint16 Index, uint16 *LH_First_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_First_VR_Start(uint16 Index, uint16 *LH_First_VR_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Construction_Area(uint16 Index, uint8 *LH_Is_Construction_Area)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Multi_Clothoid(uint16 Index, uint8 *LH_Is_Multi_Clothoid)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Model(uint16 Index, uint8 *LH_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Is_Triggered_SDM_Type(uint16 Index, uint8 *LH_Is_Triggered_SDM_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type(uint16 Index, uint8 *LH_Lanemark_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanemark_Type_Conf(uint16 Index, uint8 *LH_Lanemark_Type_Conf)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Lanes_Count(uint8 *LH_Lanes_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C0(uint16 Index, float32 *LH_Line_First_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C1(uint16 Index, float32 *LH_Line_First_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C2(uint16 Index, float32 *LH_Line_First_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_First_C3(uint16 Index, float32 *LH_Line_First_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C0(uint16 Index, float32 *LH_Line_Second_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C1(uint16 Index, float32 *LH_Line_Second_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C2(uint16 Index, float32 *LH_Line_Second_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Line_Second_C3(uint16 Index, float32 *LH_Line_Second_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width(uint16 Index, uint8 *LH_Marker_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Marker_Width_STD(uint16 Index, uint8 *LH_Marker_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Prediction_Reason(uint16 Index, uint8 *LH_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Protocol_Version(uint8 *LH_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_Measured_VR_End(uint16 Index, uint16 *LH_Second_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_End(uint16 Index, uint16 *LH_Second_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Second_VR_Start(uint16 Index, uint16 *LH_Second_VR_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Side(uint16 Index, uint8 *LH_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Sync_ID(uint8 *LH_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_LH_Track_ID(uint16 Index, uint8 *LH_Track_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_2(uint32 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_6(uint16 Index, uint16 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_Get_LNHST_Reserved_7(uint16 Index, uint32 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNHST_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNHST_EYEQDG_LNHST_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Age(uint16 Index, uint8 *LRE_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Availability_State(uint16 Index, uint8 *LRE_Availability_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Buffer_C4(uint16 Index, uint8 *LRE_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Confidence(uint16 Index, uint8 *LRE_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Count(uint8 *LRE_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_Buffer(uint16 Index, uint32 *LRE_Element_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Element_CRC(uint16 Index, uint32 *LRE_Element_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_Buffer(uint16 *LRE_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Header_CRC(uint32 *LRE_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height(uint16 Index, uint8 *LRE_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Height_STD(uint16 Index, uint8 *LRE_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_ID(uint16 Index, uint8 *LRE_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Is_Triggered_SDM_Model(uint16 Index, uint8 *LRE_Is_Triggered_SDM_Model)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C0(uint16 Index, float32 *LRE_Line_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C1(uint16 Index, float32 *LRE_Line_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C2(uint16 Index, float32 *LRE_Line_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Line_C3(uint16 Index, float32 *LRE_Line_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Measured_VR_End(uint16 Index, uint16 *LRE_Measured_VR_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Position(uint16 Index, uint8 *LRE_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Prediction_Reason(uint16 Index, uint8 *LRE_Prediction_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Protocol_Version(uint8 *LRE_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Side(uint16 Index, uint8 *LRE_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Sync_ID(uint8 *LRE_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_Type(uint16 Index, uint8 *LRE_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_End(uint16 Index, uint16 *LRE_View_Range_End)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_LRE_View_Range_Start(uint16 Index, uint16 *LRE_View_Range_Start)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_1(uint32 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_Get_LNRE_Reserved_4(uint16 Index, uint16 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LNRE_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LNRE_EYEQDG_LNRE_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_Main_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLane_Core2_CODE) Re_CpApLane_Core2_Main(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLane_Core2_Main
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApLane_Core2_STOP_SEC_CODE
#include "CpApLane_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
