/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApUds_sid2e22.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUds_sid2e22
 *  Generation Time:  2023-04-20 13:52:51
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApUds_sid2e22> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPUDS_SID2E22_H
# define _RTE_CPAPUDS_SID2E22_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApUds_sid2e22_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApUds_sid2e22
{
  /* PIM Handles section */
  P2VAR(Nvm8ByteDataRead_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_AplFingerPrint; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(Nvm8ByteDataRead_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_BootFingerPrint; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(Nvm8ByteDataRead_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DataFingerPrint; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(NvMVersionDataRead, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_NVMVersion; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(HKMC_ReleaseInfo_record, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_PIM_HKMC_ReleaseInfo; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(Nvm8ByteDataRead_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ReProgCounter; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApUds_sid2e22, RTE_CONST, RTE_CONST) Rte_Inst_CpApUds_sid2e22; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApUds_sid2e22, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_RP_BattVoltRaw_De_BattVoltRaw (0U)
# define Rte_InitValue_RP_Eol_CountryCode_CountryCode (0U)
# define Rte_InitValue_RP_Eol_DriveType_DriveType (0U)
# define Rte_InitValue_RP_Eol_TransAxle_TransAxle (0U)
# define Rte_InitValue_RP_LkaSwitchOn_De_LkaSwitchOn (FALSE)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_ActivateToi_De_ActivateToi(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_BattVoltRaw_De_BattVoltRaw(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_Core22Core1AppInfo_De_AppVersionInfo(P2VAR(Core2AppVersionInfo_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_Eol_CountryCode_CountryCode(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_Eol_DriveType_DriveType(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_Eol_TransAxle_TransAxle(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_EscActive_De_EscActive(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_GearReverse_De_GearReverse(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_GearReverse_De_GearReverseValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_LateralAcceleration_De_LateralAcceleration(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_LateralAcceleration_De_LateralAccelerationValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_LeftIndicatorOn_De_LeftIndicatorOn(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_LkaSwitchOn_De_LkaSwitchOn(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_LkaToiFault_De_LkaToiFault(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_PlatformCode_PlatformCode(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_PlatformCode_PlatformCode(P2VAR(PlatformCode, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_RightIndicatorOn_De_RightIndicatorOn(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_SteeringAngle_De_SteeringAngle(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_SteeringAngle_De_SteeringAngleValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_SteeringAngleSpeed_De_SteeringAngleSpeed(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_VehicleName_VehicleName(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_VehicleName_VehicleName(P2VAR(VehicleName, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_VehicleSpeed_De_VehicleSpeed(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_VehicleSpeed_De_VehicleSpeedValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_VsmActive_De_VsmActive(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_WiperOn_De_WiperOn(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_YawRate_De_YawRate(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid2e22_RP_YawRate_De_YawRateValid(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_CoFcaAppVersionInfo_AppVersionInfoValidate(P2VAR(CoFcaAppVersionInfo_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) CoFcaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_DCMServices_GetSesCtrlType(P2VAR(Dcm_SesCtrlType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) SesCtrlType); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetAutofixCalParams_EYEQC_GetAutofixCalParams(P2VAR(EYEQMESP_AutoFixCalData_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) EyeQAutofixCalParams_ps, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetCurrentBaseCalStatus_EYEQC_GetCurrentBaseCalStatus(P2VAR(EYEQMESP_CalStatusType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) currentBaseCalStatus_p); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams(P2VAR(EYEQMESP_TargetCalibData_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) EyeQCalParams_ps, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams(P2VAR(EYEQMESP_EnvironmentParams_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_GetCurrentBaseCalType_EYEQMESP_GetCurrentBaseCalType(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) baseCalType_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams(P2VAR(EYEQMESP_TAC2InitParamsNVM_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams(P2VAR(EYEQMESP_VehicleCalParams_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_EyeQCddSatCore1_CMN_EYEQDG_Get_CMN_COM_Driving_Side(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) COM_Driving_Side); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_FcaAppVersionInfo_AppVersionInfo(P2VAR(FcaAppVersionInfo_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) FcaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_NvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_NvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_SccAppVersionInfo_AppVersionInfo(P2VAR(SccAppVersionInfo_t, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) SccAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid2e22_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_ActivateToi_De_ActivateToi Rte_Read_CpApUds_sid2e22_RP_ActivateToi_De_ActivateToi
# define Rte_Read_RP_BattVoltRaw_De_BattVoltRaw Rte_Read_CpApUds_sid2e22_RP_BattVoltRaw_De_BattVoltRaw
# define Rte_Read_RP_Core22Core1AppInfo_De_AppVersionInfo Rte_Read_CpApUds_sid2e22_RP_Core22Core1AppInfo_De_AppVersionInfo
# define Rte_Read_RP_Eol_CountryCode_CountryCode Rte_Read_CpApUds_sid2e22_RP_Eol_CountryCode_CountryCode
# define Rte_Read_RP_Eol_DriveType_DriveType Rte_Read_CpApUds_sid2e22_RP_Eol_DriveType_DriveType
# define Rte_Read_RP_Eol_TransAxle_TransAxle Rte_Read_CpApUds_sid2e22_RP_Eol_TransAxle_TransAxle
# define Rte_Read_RP_EscActive_De_EscActive Rte_Read_CpApUds_sid2e22_RP_EscActive_De_EscActive
# define Rte_Read_RP_GearReverse_De_GearReverse Rte_Read_CpApUds_sid2e22_RP_GearReverse_De_GearReverse
# define Rte_Read_RP_GearReverse_De_GearReverseValid Rte_Read_CpApUds_sid2e22_RP_GearReverse_De_GearReverseValid
# define Rte_Read_RP_LateralAcceleration_De_LateralAcceleration Rte_Read_CpApUds_sid2e22_RP_LateralAcceleration_De_LateralAcceleration
# define Rte_Read_RP_LateralAcceleration_De_LateralAccelerationValid Rte_Read_CpApUds_sid2e22_RP_LateralAcceleration_De_LateralAccelerationValid
# define Rte_Read_RP_LeftIndicatorOn_De_LeftIndicatorOn Rte_Read_CpApUds_sid2e22_RP_LeftIndicatorOn_De_LeftIndicatorOn
# define Rte_Read_RP_LkaSwitchOn_De_LkaSwitchOn Rte_Read_CpApUds_sid2e22_RP_LkaSwitchOn_De_LkaSwitchOn
# define Rte_Read_RP_LkaToiFault_De_LkaToiFault Rte_Read_CpApUds_sid2e22_RP_LkaToiFault_De_LkaToiFault
# define Rte_Read_RP_PlatformCode_PlatformCode Rte_Read_CpApUds_sid2e22_RP_PlatformCode_PlatformCode
# define Rte_Read_RP_RightIndicatorOn_De_RightIndicatorOn Rte_Read_CpApUds_sid2e22_RP_RightIndicatorOn_De_RightIndicatorOn
# define Rte_Read_RP_SteeringAngle_De_SteeringAngle Rte_Read_CpApUds_sid2e22_RP_SteeringAngle_De_SteeringAngle
# define Rte_Read_RP_SteeringAngle_De_SteeringAngleValid Rte_Read_CpApUds_sid2e22_RP_SteeringAngle_De_SteeringAngleValid
# define Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeed Rte_Read_CpApUds_sid2e22_RP_SteeringAngleSpeed_De_SteeringAngleSpeed
# define Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeedValid Rte_Read_CpApUds_sid2e22_RP_SteeringAngleSpeed_De_SteeringAngleSpeedValid
# define Rte_Read_RP_VehicleName_VehicleName Rte_Read_CpApUds_sid2e22_RP_VehicleName_VehicleName
# define Rte_Read_RP_VehicleSpeed_De_VehicleSpeed Rte_Read_CpApUds_sid2e22_RP_VehicleSpeed_De_VehicleSpeed
# define Rte_Read_RP_VehicleSpeed_De_VehicleSpeedValid Rte_Read_CpApUds_sid2e22_RP_VehicleSpeed_De_VehicleSpeedValid
# define Rte_Read_RP_VsmActive_De_VsmActive Rte_Read_CpApUds_sid2e22_RP_VsmActive_De_VsmActive
# define Rte_Read_RP_WiperOn_De_WiperOn Rte_Read_CpApUds_sid2e22_RP_WiperOn_De_WiperOn
# define Rte_Read_RP_YawRate_De_YawRate Rte_Read_CpApUds_sid2e22_RP_YawRate_De_YawRate
# define Rte_Read_RP_YawRate_De_YawRateValid Rte_Read_CpApUds_sid2e22_RP_YawRate_De_YawRateValid


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CoFcaAppVersionInfo_AppVersionInfoValidate Rte_Call_CpApUds_sid2e22_RP_CoFcaAppVersionInfo_AppVersionInfoValidate
# define Rte_Call_RP_DCMServices_GetSesCtrlType Rte_Call_CpApUds_sid2e22_RP_DCMServices_GetSesCtrlType
# define Rte_Call_RP_EYEQC_GetAutofixCalParams_EYEQC_GetAutofixCalParams Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetAutofixCalParams_EYEQC_GetAutofixCalParams
# define Rte_Call_RP_EYEQC_GetCurrentBaseCalStatus_EYEQC_GetCurrentBaseCalStatus Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetCurrentBaseCalStatus_EYEQC_GetCurrentBaseCalStatus
# define Rte_Call_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams Rte_Call_CpApUds_sid2e22_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams
# define Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams
# define Rte_Call_RP_EYEQMESP_GetCurrentBaseCalType_EYEQMESP_GetCurrentBaseCalType Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_GetCurrentBaseCalType_EYEQMESP_GetCurrentBaseCalType
# define Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams
# define Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams Rte_Call_CpApUds_sid2e22_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams
# define Rte_Call_RP_EyeQCddSatCore1_CMN_EYEQDG_Get_CMN_COM_Driving_Side Rte_Call_CpApUds_sid2e22_RP_EyeQCddSatCore1_CMN_EYEQDG_Get_CMN_COM_Driving_Side
# define Rte_Call_RP_FcaAppVersionInfo_AppVersionInfo Rte_Call_CpApUds_sid2e22_RP_FcaAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock Rte_Call_CpApUds_sid2e22_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock
# define Rte_Call_RP_NvMService_ZFECUHwNrDataId_ReadBlock Rte_Call_CpApUds_sid2e22_RP_NvMService_ZFECUHwNrDataId_ReadBlock
# define Rte_Call_RP_NvMService_ZFECUHwVerNrDataId_ReadBlock Rte_Call_CpApUds_sid2e22_RP_NvMService_ZFECUHwVerNrDataId_ReadBlock
# define Rte_Call_RP_SccAppVersionInfo_AppVersionInfo Rte_Call_CpApUds_sid2e22_RP_SccAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApUds_sid2e22_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_AplFingerPrint() (Rte_Inst_CpApUds_sid2e22->Pim_AplFingerPrint) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_BootFingerPrint() (Rte_Inst_CpApUds_sid2e22->Pim_BootFingerPrint) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_DataFingerPrint() (Rte_Inst_CpApUds_sid2e22->Pim_DataFingerPrint) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_NVMVersion() (Rte_Inst_CpApUds_sid2e22->Pim_NVMVersion) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_PIM_HKMC_ReleaseInfo() (Rte_Inst_CpApUds_sid2e22->Pim_PIM_HKMC_ReleaseInfo) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_ReProgCounter() (Rte_Inst_CpApUds_sid2e22->Pim_ReProgCounter) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   Nvm8ByteDataRead_t *Rte_Pim_AplFingerPrint(void)
 *   Nvm8ByteDataRead_t *Rte_Pim_BootFingerPrint(void)
 *   Nvm8ByteDataRead_t *Rte_Pim_DataFingerPrint(void)
 *   NvMVersionDataRead *Rte_Pim_NVMVersion(void)
 *   HKMC_ReleaseInfo_record *Rte_Pim_PIM_HKMC_ReleaseInfo(void)
 *   Nvm8ByteDataRead_t *Rte_Pim_ReProgCounter(void)
 *
 *********************************************************************************************************************/


# define CpApUds_sid2e22_START_SEC_CODE
# include "CpApUds_sid2e22_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid2e22_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SetAppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid2e22_Init CpApUds_sid2e22_Init
FUNC(void, CpApUds_sid2e22_CODE) CpApUds_sid2e22_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid2e22_getHKMC_ReleaseInfo
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getHKMC_ReleaseInfo> of PortPrototype <PP_HKMC_ReleaseInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUds_sid2e22_getHKMC_ReleaseInfo(HKMC_ReleaseInfo_record *HKMC_ReleaseInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HKMC_ReleaseInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid2e22_getHKMC_ReleaseInfo CpApUds_sid2e22_getHKMC_ReleaseInfo
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) CpApUds_sid2e22_getHKMC_ReleaseInfo(P2VAR(HKMC_ReleaseInfo_record, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) HKMC_ReleaseInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid2e22_getNvMVersion
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getNvMVersion> of PortPrototype <PP_NvMVersion>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUds_sid2e22_getNvMVersion(NvMVersionDataRead *NvMVersion)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_NvMVersion_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid2e22_getNvMVersion CpApUds_sid2e22_getNvMVersion
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) CpApUds_sid2e22_getNvMVersion(P2VAR(NvMVersionDataRead, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) NvMVersion); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0100_Number_of_flash_ROM_rewritings>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data5ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0100_Number_of_flash_ROM_rewritings_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0100_Number_of_flash_ROM_rewritings_ReadData(P2VAR(Dcm_Data5ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0101_Calibration_Status_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0101_Calibration_Status>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetCurrentBaseCalStatus_EYEQC_GetCurrentBaseCalStatus(EYEQMESP_CalStatusType *currentBaseCalStatus_p)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetCurrentBaseCalStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_GetCurrentBaseCalType_EYEQMESP_GetCurrentBaseCalType(uint8 *baseCalType_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_GetCurrentBaseCalType_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0101_Calibration_Status_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data5ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0101_Calibration_Status_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0101_Calibration_Status_ReadData DataServices_Data_0101_Calibration_Status_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0101_Calibration_Status_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0101_Calibration_Status_ReadData(P2VAR(Dcm_Data5ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0102_Calibration_Value_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0102_Calibration_Value>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams(EYEQMESP_TargetCalibData_t *EyeQCalParams_ps, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetCurrentCalParams_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0102_Calibration_Value_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data11ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0102_Calibration_Value_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0102_Calibration_Value_ReadData DataServices_Data_0102_Calibration_Value_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0102_Calibration_Value_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0102_Calibration_Value_ReadData(P2VAR(Dcm_Data11ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0103_AutoFix_Calibration_Data_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0103_AutoFix_Calibration_Data>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetAutofixCalParams_EYEQC_GetAutofixCalParams(EYEQMESP_AutoFixCalData_t *EyeQAutofixCalParams_ps, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetAutofixCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_CMN_EYEQDG_Get_CMN_COM_Driving_Side(uint8 *COM_Driving_Side)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_CMN_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0103_AutoFix_Calibration_Data_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data10ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0103_AutoFix_Calibration_Data_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0103_AutoFix_Calibration_Data_ReadData DataServices_Data_0103_AutoFix_Calibration_Data_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0103_AutoFix_Calibration_Data_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0103_AutoFix_Calibration_Data_ReadData(P2VAR(Dcm_Data10ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0105_Display_Vehicle_Speed_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0105_Display_Vehicle_Speed>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_VehicleSpeed_De_VehicleSpeed(float32 *data)
 *   Std_ReturnType Rte_Read_RP_VehicleSpeed_De_VehicleSpeedValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0105_Display_Vehicle_Speed_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0105_Display_Vehicle_Speed_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0105_Display_Vehicle_Speed_ReadData DataServices_Data_0105_Display_Vehicle_Speed_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0105_Display_Vehicle_Speed_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0105_Display_Vehicle_Speed_ReadData(P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0106_Yaw_Rate_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0106_Yaw_Rate>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_YawRate_De_YawRate(float32 *data)
 *   Std_ReturnType Rte_Read_RP_YawRate_De_YawRateValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0106_Yaw_Rate_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0106_Yaw_Rate_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0106_Yaw_Rate_ReadData DataServices_Data_0106_Yaw_Rate_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0106_Yaw_Rate_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0106_Yaw_Rate_ReadData(P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0107_Lateral_Acceleration_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0107_Lateral_Acceleration>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_LateralAcceleration_De_LateralAcceleration(float32 *data)
 *   Std_ReturnType Rte_Read_RP_LateralAcceleration_De_LateralAccelerationValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0107_Lateral_Acceleration_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0107_Lateral_Acceleration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0107_Lateral_Acceleration_ReadData DataServices_Data_0107_Lateral_Acceleration_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0107_Lateral_Acceleration_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0107_Lateral_Acceleration_ReadData(P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_0109_Steering_Angle_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_0109_Steering_Angle>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_SteeringAngle_De_SteeringAngle(float32 *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngle_De_SteeringAngleValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_0109_Steering_Angle_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_0109_Steering_Angle_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_0109_Steering_Angle_ReadData DataServices_Data_0109_Steering_Angle_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0109_Steering_Angle_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_0109_Steering_Angle_ReadData(P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_010A_Steering_Wheel_Speed_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_010A_Steering_Wheel_Speed>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_010A_Steering_Wheel_Speed_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data5ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_010A_Steering_Wheel_Speed_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_010A_Steering_Wheel_Speed_ReadData DataServices_Data_010A_Steering_Wheel_Speed_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_010A_Steering_Wheel_Speed_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_010A_Steering_Wheel_Speed_ReadData(P2VAR(Dcm_Data5ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_A9FF_SystemParameters_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_A9FF_SystemParameters>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetAutofixCalParams_EYEQC_GetAutofixCalParams(EYEQMESP_AutoFixCalData_t *EyeQAutofixCalParams_ps, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetAutofixCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams(EYEQMESP_TAC2InitParamsNVM_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams(EYEQMESP_VehicleCalParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_A9FF_SystemParameters_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data40ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_A9FF_SystemParameters_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_A9FF_SystemParameters_ReadData DataServices_Data_A9FF_SystemParameters_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_A9FF_SystemParameters_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_A9FF_SystemParameters_ReadData(P2VAR(Dcm_Data40ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_AAFF_TAC2InitParameters_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_AAFF_TAC2InitParameters>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_AAFF_TAC2InitParameters_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data33ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_AAFF_TAC2InitParameters_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_AAFF_TAC2InitParameters_ReadData DataServices_Data_AAFF_TAC2InitParameters_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_AAFF_TAC2InitParameters_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_AAFF_TAC2InitParameters_ReadData(P2VAR(Dcm_Data33ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_AAFF_TAC2InitParameters_WriteData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteData> of PortPrototype <DataServices_Data_AAFF_TAC2InitParameters>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_AAFF_TAC2InitParameters_WriteData(const uint8 *Data, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Data: uint8* is of type Dcm_Data33ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_AAFF_TAC2InitParameters_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_AAFF_TAC2InitParameters_WriteData DataServices_Data_AAFF_TAC2InitParameters_WriteData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_AAFF_TAC2InitParameters_WriteData(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_DATA) Data, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_AAFF_TAC2InitParameters_WriteData(P2CONST(Dcm_Data33ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_DATA) Data, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F010_InputOutputDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F010_InputOutputDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_ActivateToi_De_ActivateToi(boolean *data)
 *   Std_ReturnType Rte_Read_RP_EscActive_De_EscActive(boolean *data)
 *   Std_ReturnType Rte_Read_RP_GearReverse_De_GearReverse(boolean *data)
 *   Std_ReturnType Rte_Read_RP_GearReverse_De_GearReverseValid(boolean *data)
 *   Std_ReturnType Rte_Read_RP_LateralAcceleration_De_LateralAcceleration(float32 *data)
 *   Std_ReturnType Rte_Read_RP_LateralAcceleration_De_LateralAccelerationValid(boolean *data)
 *   Std_ReturnType Rte_Read_RP_LeftIndicatorOn_De_LeftIndicatorOn(boolean *data)
 *   Std_ReturnType Rte_Read_RP_LkaSwitchOn_De_LkaSwitchOn(boolean *data)
 *   Std_ReturnType Rte_Read_RP_LkaToiFault_De_LkaToiFault(boolean *data)
 *   Std_ReturnType Rte_Read_RP_RightIndicatorOn_De_RightIndicatorOn(boolean *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngle_De_SteeringAngle(float32 *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngle_De_SteeringAngleValid(boolean *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 *data)
 *   Std_ReturnType Rte_Read_RP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean *data)
 *   Std_ReturnType Rte_Read_RP_VehicleSpeed_De_VehicleSpeed(float32 *data)
 *   Std_ReturnType Rte_Read_RP_VehicleSpeed_De_VehicleSpeedValid(boolean *data)
 *   Std_ReturnType Rte_Read_RP_VsmActive_De_VsmActive(boolean *data)
 *   Std_ReturnType Rte_Read_RP_WiperOn_De_WiperOn(boolean *data)
 *   Std_ReturnType Rte_Read_RP_YawRate_De_YawRate(float32 *data)
 *   Std_ReturnType Rte_Read_RP_YawRate_De_YawRateValid(boolean *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F010_InputOutputDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data22ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F010_InputOutputDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F010_InputOutputDataIdentifier_ReadData DataServices_Data_F010_InputOutputDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F010_InputOutputDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F010_InputOutputDataIdentifier_ReadData(P2VAR(Dcm_Data22ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F011_CameraAlignmentCalibData_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F011_CameraAlignmentCalibData>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetCurrentBaseCalStatus_EYEQC_GetCurrentBaseCalStatus(EYEQMESP_CalStatusType *currentBaseCalStatus_p)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetCurrentBaseCalStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams(EYEQMESP_TargetCalibData_t *EyeQCalParams_ps, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetCurrentCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_GetCurrentBaseCalType_EYEQMESP_GetCurrentBaseCalType(uint8 *baseCalType_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_GetCurrentBaseCalType_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F011_CameraAlignmentCalibData_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data12ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F011_CameraAlignmentCalibData_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F011_CameraAlignmentCalibData_ReadData DataServices_Data_F011_CameraAlignmentCalibData_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F011_CameraAlignmentCalibData_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F011_CameraAlignmentCalibData_ReadData(P2VAR(Dcm_Data12ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F012_RollAngle_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F012_RollAngle>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetCurrentCalParams_EYEQC_GetCurrentCalParams(EYEQMESP_TargetCalibData_t *EyeQCalParams_ps, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetCurrentCalParams_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F012_RollAngle_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F012_RollAngle_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F012_RollAngle_ReadData DataServices_Data_F012_RollAngle_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F012_RollAngle_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F012_RollAngle_ReadData(P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F015_Ignition_Feed_Voltage_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F015_Ignition_Feed_Voltage_Read>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_BattVoltRaw_De_BattVoltRaw(uint16 *data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F015_Ignition_Feed_Voltage_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F015_Ignition_Feed_Voltage_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F015_Ignition_Feed_Voltage_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F015_Ignition_Feed_Voltage_Read DataServices_Data_F015_Ignition_Feed_Voltage_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F015_Ignition_Feed_Voltage_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F015_Ignition_Feed_Voltage_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_CountryCode_CountryCode(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_TransAxle_TransAxle(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PlatformCode_PlatformCode(uint8 *data)
 *     Argument data: uint8* is of type PlatformCode
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data47ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_ReadData(P2VAR(Dcm_Data47ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F17A_ReProgrammingCounter_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F17A_ReprogrammingCounter>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F17A_ReProgrammingCounter_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data12ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F17A_ReprogrammingCounter_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F17A_ReProgrammingCounter_ReadData DataServices_Data_F17A_ReProgrammingCounter_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F17A_ReProgrammingCounter_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F17A_ReProgrammingCounter_ReadData(P2VAR(Dcm_Data12ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F183_BootSoftwareFingerprint_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F183_BootSoftwareFingerprint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F183_BootSoftwareFingerprint_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data12ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F183_BootSoftwareFingerprint_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F183_BootSoftwareFingerprint_ReadData DataServices_Data_F183_BootSoftwareFingerprint_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F183_BootSoftwareFingerprint_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F183_BootSoftwareFingerprint_ReadData(P2VAR(Dcm_Data12ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F184_ApplicationSWFingerprint_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F184_ApplicationSWFingerprint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F184_ApplicationSWFingerprint_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data12ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F184_ApplicationSWFingerprint_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F184_ApplicationSWFingerprint_ReadData DataServices_Data_F184_ApplicationSWFingerprint_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F184_ApplicationSWFingerprint_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F184_ApplicationSWFingerprint_ReadData(P2VAR(Dcm_Data12ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F185_DataFingerPrint_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F185_DataFingerPrint>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F185_DataFingerPrint_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data12ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F185_DataFingerPrint_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F185_DataFingerPrint_ReadData DataServices_Data_F185_DataFingerPrint_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F185_DataFingerPrint_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F185_DataFingerPrint_ReadData(P2VAR(Dcm_Data12ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_DCMServices_GetSesCtrlType(Dcm_SesCtrlType *SesCtrlType)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_DCMServices_E_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data1ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_ReadData(P2VAR(Dcm_Data1ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F187_VehicleManufacture_SparePartNumberDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data10ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F187_VehicleManufacture_SparePartNumberDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F187_VehicleManufacture_SparePartNumberDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F187_VehicleManufacturer_SparePartNumber_ReadData(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data10ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F18B_ECUManufacturingDate_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F18B_ECUManufacturingDate>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F18B_ECUManufacturingDate_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data4ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F18B_ECUManufacturingDate_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F18B_ECUManufacturingDate_ReadData DataServices_Data_F18B_ECUManufacturingDate_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18B_ECUManufacturingDate_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18B_ECUManufacturingDate_ReadData(P2VAR(Dcm_Data4ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F18C_ECUSerialNumberDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HKMC_TraceabilityInformation_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data5ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F18C_ECUSerialNumberDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18C_ECUSerialNumberDataIdentifier_ReadData(P2VAR(Dcm_Data5ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Eol_CountryCode_CountryCode(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_DriveType_DriveType(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_Eol_TransAxle_TransAxle(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_VehicleName_VehicleName(uint8 *data)
 *     Argument data: uint8* is of type VehicleName
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data59ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_ReadData(P2VAR(Dcm_Data59ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data4ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data4ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F192_ECUHardwareNumber_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F192_ECUHardwareNumber>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFECUHwNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F192_ECUHardwareNumber_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data14ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F192_ECUHardwareNumber_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F192_ECUHardwareNumber_ReadData DataServices_Data_F192_ECUHardwareNumber_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F192_ECUHardwareNumber_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F192_ECUHardwareNumber_ReadData(P2VAR(Dcm_Data14ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_ZFECUHwVerNrDataId_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data1ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_ReadData(P2VAR(Dcm_Data1ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core22Core1AppInfo_De_AppVersionInfo(Core2AppVersionInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CoFcaAppVersionInfo_AppVersionInfoValidate(CoFcaAppVersionInfo_t *CoFcaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CoFcaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FcaAppVersionInfo_AppVersionInfo(FcaAppVersionInfo_t *FcaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CS_FcaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_SccAppVersionInfo_AppVersionInfo(SccAppVersionInfo_t *SccAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SccAppVersionInfo_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data67ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_ReadData(P2VAR(Dcm_Data67ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data3ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F197_SystemNameOrEngineType
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F197_SystemNameOrEngineType_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F197_SystemNameOrEngineType(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data6ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_Data_By_Identifier_SystemNameOrEngineType_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_Data_By_Identifier_SystemNameOrEngineType_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F197_SystemNameOrEngineType DataServices_Data_F197_SystemNameOrEngineType
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F197_SystemNameOrEngineType(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F197_SystemNameOrEngineType(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data6ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data4ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data4ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data4ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_ReadData(P2VAR(Dcm_Data4ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data1ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data1ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data17ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data17ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data136ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_F1EF_LocalRXWINDataIdentifier_1_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_F1EF_LocalRXWINDataIdentifier_1_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_F1EF_LocalRXWINDataIdentifier_Read(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data136ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_FD00_Active_Faults_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_FD00_Active_Faults>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_FD00_Active_Faults_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data48ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_FD00_Active_Faults_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_FD00_Active_Faults_ReadData DataServices_Data_FD00_Active_Faults_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_FD00_Active_Faults_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_FD00_Active_Faults_ReadData(P2VAR(Dcm_Data48ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_FD01_Stored_Faults_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_FD01_Stored_Faults>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_FD01_Stored_Faults_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data48ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_FD01_Stored_Faults_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_FD01_Stored_Faults_ReadData DataServices_Data_FD01_Stored_Faults_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_FD01_Stored_Faults_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid2e22_CODE) DataServices_Data_FD01_Stored_Faults_ReadData(P2VAR(Dcm_Data48ByteType, AUTOMATIC, RTE_CPAPUDS_SID2E22_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

# define CpApUds_sid2e22_STOP_SEC_CODE
# include "CpApUds_sid2e22_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_DCMServices_E_OK (0U)

# define RTE_E_DataServices_Data_0100_Number_of_flash_ROM_rewritings_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0101_Calibration_Status_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0102_Calibration_Value_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0103_AutoFix_Calibration_Data_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0105_Display_Vehicle_Speed_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0106_Yaw_Rate_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0107_Lateral_Acceleration_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_0109_Steering_Angle_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_010A_Steering_Wheel_Speed_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_A9FF_SystemParameters_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_AAFF_TAC2InitParameters_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_Data_By_Identifier_SystemNameOrEngineType_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_Data_By_Identifier_SystemNameOrEngineType_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F010_InputOutputDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F011_CameraAlignmentCalibData_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F012_RollAngle_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F015_Ignition_Feed_Voltage_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F015_Ignition_Feed_Voltage_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F100_VehicleManufacturerECUSoftwareVersionNumberDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F17A_ReprogrammingCounter_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F183_BootSoftwareFingerprint_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F184_ApplicationSWFingerprint_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F185_DataFingerPrint_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F186_ActiveDiagnosticSessionDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F187_VehicleManufacture_SparePartNumberDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F187_VehicleManufacture_SparePartNumberDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F18B_ECUManufacturingDate_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F18C_ECUSerialNumberDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F18E_VehicleManufacturerKitAssemblyPartNumberDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F191_VehicleManufacturerECUHardwareNumberDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F192_ECUHardwareNumber_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F193_SystemSupplierECUHardwareVersionNumberDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F194_SystemSupplierECUSoftwareNumberDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F195_SystemSupplierECUSoftwareVersionNumberDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F1A0_SoftwareVersionforHKMCVehicleManufactureDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F1A1_ECUSupplierCodeDataIdentifier_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F1B0_ECUSoftwareUNITnumberDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F1B1_ECUSoftwareUNIT1VersionDataIdentifier_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_F1EF_LocalRXWINDataIdentifier_1_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_F1EF_LocalRXWINDataIdentifier_1_Read_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_FD00_Active_Faults_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_FD01_Stored_Faults_E_NOT_OK (1U)

# define RTE_E_IF_CS_FcaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_CoFcaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_EYEQC_GetAutofixCalParams_ReturnType (1U)

# define RTE_E_IF_EYEQC_GetCurrentBaseCalStatus_ReturnType (1U)

# define RTE_E_IF_EYEQC_GetCurrentCalParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_GetCurrentBaseCalType_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore1_CMN_ReturnType (1U)

# define RTE_E_IF_HKMC_ReleaseInfo_ReturnType (1U)

# define RTE_E_IF_NvMVersion_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# define RTE_E_IF_SccAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_SetAppDiagFaultStatus_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPUDS_SID2E22_H */
