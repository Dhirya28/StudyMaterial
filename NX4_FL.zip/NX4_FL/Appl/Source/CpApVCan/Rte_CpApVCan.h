/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApVCan.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApVCan
 *  Generation Time:  2023-04-20 13:52:55
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApVCan> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPVCAN_H
# define _RTE_CPAPVCAN_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApVCan_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApVCan
{
  /* PIM Handles section */
  P2VAR(CVD_VehicleTrackWidths, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_PIM_Cvd_TrackWidthInputs; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApVCan, RTE_CONST, RTE_CONST) Rte_Inst_CpApVCan; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApVCan, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_ActivateToi_De_ActivateToi (FALSE)
# define Rte_InitValue_PP_ECU_SSC_STAT_De_ECU_SSC_STAT (0U)
# define Rte_InitValue_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status (0U)
# define Rte_InitValue_PP_EscActive_De_EscActive (FALSE)
# define Rte_InitValue_PP_FcaWarnLampCond_De_FcaWarnLampCond (0U)
# define Rte_InitValue_PP_GearReverse_De_GearReverse (FALSE)
# define Rte_InitValue_PP_GearReverse_De_GearReverseValid (FALSE)
# define Rte_InitValue_PP_HCU_HevRdySta_De_HCU_HevRdySta (0U)
# define Rte_InitValue_PP_LateralAcceleration_De_LateralAcceleration (0.0F)
# define Rte_InitValue_PP_LateralAcceleration_De_LateralAccelerationValid (FALSE)
# define Rte_InitValue_PP_LeftIndicatorOn_De_LeftIndicatorOn (FALSE)
# define Rte_InitValue_PP_LkaToiFault_De_LkaToiFault (FALSE)
# define Rte_InitValue_PP_RightIndicatorOn_De_RightIndicatorOn (FALSE)
# define Rte_InitValue_PP_SccWarnLampCond_De_SccWarnLampCond (0U)
# define Rte_InitValue_PP_SteeringAngle_De_SteeringAngle (0.0F)
# define Rte_InitValue_PP_SteeringAngle_De_SteeringAngleValid (FALSE)
# define Rte_InitValue_PP_SteeringAngleSpeed_De_SteeringAngleSpeed (0.0F)
# define Rte_InitValue_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid (FALSE)
# define Rte_InitValue_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus (0U)
# define Rte_InitValue_PP_VCan_GetOdoValue_De_OdoVal (0U)
# define Rte_InitValue_PP_VehicleSpeed_De_VehicleSpeed (0.0F)
# define Rte_InitValue_PP_VehicleSpeed_De_VehicleSpeedValid (FALSE)
# define Rte_InitValue_PP_VsmActive_De_VsmActive (FALSE)
# define Rte_InitValue_PP_WiperOn_De_WiperOn (FALSE)
# define Rte_InitValue_PP_YawRate_De_YawRate (0.0F)
# define Rte_InitValue_PP_YawRate_De_YawRateValid (FALSE)
# define Rte_InitValue_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc (0U)
# define Rte_InitValue_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(P2VAR(COM_DT_SG_ABS_ESC_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(P2VAR(COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(P2VAR(COM_DT_SG_BCM_07_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(P2VAR(COM_DT_SG_BCM_08_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(P2VAR(COM_DT_SG_BCM_10_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(P2VAR(COM_DT_SG_BCM_13_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(P2VAR(COM_DT_SG_CLU_01_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(P2VAR(COM_DT_SG_CLU_02_100ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(P2VAR(COM_DT_SG_CLU_04_00ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(P2VAR(COM_DT_SG_CLU_12_00ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(P2VAR(COM_DT_SG_CLU_13_00ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(P2VAR(COM_DT_SG_CLU_14_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(P2VAR(COM_DT_SG_CLU_25_00ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(P2VAR(COM_DT_SG_CTM_01_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(P2VAR(COM_DT_SG_DATC_17_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(P2VAR(COM_DT_SG_EMS_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(P2VAR(COM_DT_SG_EMS_02_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(P2VAR(COM_DT_SG_EMS_03_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(P2VAR(COM_DT_SG_EMS_05_100ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(P2VAR(COM_DT_SG_EMS_07_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(P2VAR(COM_DT_SG_EMS_11_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(P2VAR(COM_DT_SG_EPB_01_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(P2VAR(COM_DT_SG_ESC_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(P2VAR(COM_DT_SG_ESC_03_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(P2VAR(COM_DT_SG_HCU_03_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(P2VAR(COM_DT_SG_HCU_05_100ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(P2VAR(COM_DT_SG_HTCU_04_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(P2VAR(COM_DT_SG_HTCU_05_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(P2VAR(COM_DT_SG_HU_CLU_PE_05_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(P2VAR(COM_DT_SG_HU_GW_PE_01_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(P2VAR(COM_DT_SG_HU_MON_PE_01_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(P2VAR(COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(P2VAR(COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(P2VAR(COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(P2VAR(COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(P2VAR(COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(P2VAR(COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(P2VAR(COM_DT_SG_HU_USM_E_14_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(P2VAR(COM_DT_SG_IAU_16_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(P2VAR(COM_DT_SG_ICC_HS_01_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(P2VAR(COM_DT_SG_ICC_HS_04_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(P2VAR(COM_DT_SG_ICSC_02_100ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(P2VAR(COM_DT_SG_ICU_02_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(P2VAR(COM_DT_SG_ICU_04_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(P2VAR(COM_DT_SG_ICU_07_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(P2VAR(COM_DT_SG_IEB_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(P2VAR(COM_DT_SG_IMU_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(P2VAR(COM_DT_SG_MDPS_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(P2VAR(COM_DT_SG_MFSW_01_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(P2VAR(COM_DT_SG_SAS_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(P2VAR(COM_DT_SG_SMK_02_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(P2VAR(COM_DT_SG_SWRC_03_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(P2VAR(COM_DT_SG_TCU_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(P2VAR(COM_DT_SG_WHL_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_CoFCAEDR_Output_De_EDR_Output(P2VAR(CoFcaEDR_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(P2VAR(CoFcaFrCmrOut_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_CoFcaOutput_De_CoFcaOutput(P2VAR(CoFcaOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_CvdOutputData_De_CvdOutputData(P2VAR(CvdOutputData_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_DawOutput_De_DawOutput(P2VAR(DawOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(P2VAR(uint8, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_FcaEDR_Output_De_FcaInternalOutToEDR(P2VAR(FcaEDR_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_FcaFrCmrOut_De_FcaFrCmrOut(P2VAR(FcaFrCmrOut_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_FcaOutput_De_FcaOutput(P2VAR(FcaOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_HbaOutput_De_HbaOutput(P2VAR(HbaOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IslwOutput_De_IslwOutput(P2VAR(IslwOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcHptOutput_De_IvcHptOutput(P2VAR(IvcHptOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcMv1Output_De_IvcMv1Output(P2VAR(IvcMv1Output_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcMv2Output_De_IvcMv2Output(P2VAR(IvcMv2Output_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcPuFOutput_De_IvcPuFOutput(P2VAR(IvcPuFOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcPuMOutput_De_IvcPuMOutput(P2VAR(IvcPuMOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcSmvOutput_De_IvcSmvOutput(P2VAR(IvcSmvOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcSndOutput_De_IvcSndOutput(P2VAR(IvcSndOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcSymbStaOutput_De_IvcSymbStaOutput(P2VAR(IvcSymbStaOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(P2VAR(IvcTrffcSgnOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_IvcVarOutput_De_IvcVarOutput(P2VAR(IvcVarOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_LssOutput_De_LssOutput(P2VAR(LssOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts(P2VAR(uint8, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApVCan_RP_SccOutput_De_SccOutput(P2VAR(SccOutput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(boolean, RTE_CODE) Rte_IsUpdated_CpApVCan_RP_CvdOutputData_De_CvdOutputData(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_10_20ms_SignalGroup_COM_SG_ADAS_CMD_10_20ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_20_20ms_SignalGroup_COM_SG_ADAS_CMD_20_20ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_21_50ms_SignalGroup_COM_SG_ADAS_CMD_21_50ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_30_10ms_SignalGroup_COM_SG_ADAS_CMD_30_10ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_31_50ms_SignalGroup_COM_SG_ADAS_CMD_31_50ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_CMD_35_10ms_SignalGroup_COM_SG_ADAS_CMD_35_10ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_INFO_01_200ms_SignalGroup_COM_SG_ADAS_INFO_01_200ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_UX_01_50ms_SignalGroup_COM_SG_ADAS_UX_01_50ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_UX_01_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_ADAS_UX_02_50ms_SignalGroup_COM_SG_ADAS_UX_02_50ms_SignalGroup(P2CONST(COM_DT_SG_ADAS_UX_02_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_FR_CMR_01_10ms_SignalGroup_COM_SG_FR_CMR_01_10ms_SignalGroup(P2CONST(COM_DT_SG_FR_CMR_01_10ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_FR_CMR_02_100ms_SignalGroup_COM_SG_FR_CMR_02_100ms_SignalGroup(P2CONST(COM_DT_SG_FR_CMR_02_100ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup(P2CONST(COM_DT_SG_FR_CMR_03_50ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_COM_SG_FR_CMR_04_40ms_SignalGroup_COM_SG_FR_CMR_04_40ms_SignalGroup(P2CONST(COM_DT_SG_FR_CMR_04_40ms_SignalGroup, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_ActivateToi_De_ActivateToi(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_CVD_ReadTrackWidth_TrackWidth(P2CONST(Cvd_TrackWidthInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_Core1ToCore2VCan_CANmsg(P2CONST(CANmsg_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_CvdInputData_De_CvdInputData(P2CONST(CvdInputData_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_DawInput_De_DawInput(P2CONST(DawInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_EDR_Input_Data_EDRInputData(P2CONST(EDR_InputData, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_ENG_EngSta_De_VCan_ENG_EngSta(P2CONST(VCan_ENG_EngSta_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_ENG_IsgSta_De_VCan_ENG_IsgSta(P2CONST(VCan_ENG_IsgSta_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_EscActive_De_EscActive(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(P2CONST(FcaFailSafeInfoTrailerMsgTout_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_FcaInput_De_FcaInput(P2CONST(FcaInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_FcaWarnLampCond_De_FcaWarnLampCond(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_GearReverse_De_GearReverse(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_GearReverse_De_GearReverseValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_IslwInput_De_IslwInput(P2CONST(IslwInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_LateralAcceleration_De_LateralAcceleration(float32 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_LateralAcceleration_De_LateralAccelerationValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_LeftIndicatorOn_De_LeftIndicatorOn(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_LkaToiFault_De_LkaToiFault(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_LssInput_De_LssInput(P2CONST(LssInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_RightIndicatorOn_De_RightIndicatorOn(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SR_MeInputCommData_De_MeInputCommData(P2CONST(MeInputCommData_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SccInput_De_SccInput(P2CONST(SccInput_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SccInputFromVCan_De_SccInputFromVCan(P2CONST(SccInputFromVCan_t, AUTOMATIC, RTE_CPAPVCAN_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SccWarnLampCond_De_SccWarnLampCond(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SteeringAngle_De_SteeringAngle(float32 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SteeringAngle_De_SteeringAngleValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_VCan_GetOdoValue_De_OdoVal(COM_DT_CLU_OdoVal data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_VehicleSpeed_De_VehicleSpeed(float32 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_VehicleSpeed_De_VehicleSpeedValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_VsmActive_De_VsmActive(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_WiperOn_De_WiperOn(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_YawRate_De_YawRate(float32 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApVCan_PP_YawRate_De_YawRateValid(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApVCan_RP_VCan_BusOFFStatus_BSW_BswM_MDGP_BswMVCAN_RteModeDclGroup(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_PP_EDR_Trigger_EDR_Trigger_Function(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_FrCmrLDW_getFrCmrLDW(P2VAR(LDW_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) FrCmrLDW); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApVCan_RP_HKMC_ReleaseInfo_getHKMC_ReleaseInfo(P2VAR(HKMC_ReleaseInfo_record, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) HKMC_ReleaseInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup
# define Rte_Read_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup
# define Rte_Read_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup
# define Rte_Read_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup
# define Rte_Read_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup
# define Rte_Read_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup
# define Rte_Read_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup
# define Rte_Read_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup
# define Rte_Read_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup
# define Rte_Read_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup
# define Rte_Read_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup
# define Rte_Read_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup
# define Rte_Read_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup
# define Rte_Read_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup
# define Rte_Read_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup
# define Rte_Read_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup
# define Rte_Read_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup
# define Rte_Read_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup
# define Rte_Read_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup
# define Rte_Read_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup
# define Rte_Read_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup
# define Rte_Read_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup Rte_Read_CpApVCan_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup
# define Rte_Read_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup
# define Rte_Read_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup
# define Rte_Read_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup
# define Rte_Read_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup Rte_Read_CpApVCan_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup
# define Rte_Read_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup
# define Rte_Read_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup
# define Rte_Read_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup
# define Rte_Read_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup
# define Rte_Read_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup
# define Rte_Read_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup
# define Rte_Read_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup
# define Rte_Read_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro
# define Rte_Read_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa
# define Rte_Read_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup
# define Rte_Read_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup
# define Rte_Read_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup Rte_Read_CpApVCan_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup
# define Rte_Read_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup
# define Rte_Read_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup
# define Rte_Read_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup
# define Rte_Read_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup
# define Rte_Read_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup
# define Rte_Read_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup
# define Rte_Read_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup
# define Rte_Read_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup
# define Rte_Read_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup
# define Rte_Read_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup
# define Rte_Read_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup
# define Rte_Read_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup
# define Rte_Read_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup Rte_Read_CpApVCan_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup
# define Rte_Read_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup Rte_Read_CpApVCan_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup
# define Rte_Read_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup
# define Rte_Read_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup Rte_Read_CpApVCan_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup
# define Rte_Read_RP_CoFCAEDR_Output_De_EDR_Output Rte_Read_CpApVCan_RP_CoFCAEDR_Output_De_EDR_Output
# define Rte_Read_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut Rte_Read_CpApVCan_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut
# define Rte_Read_RP_CoFcaOutput_De_CoFcaOutput Rte_Read_CpApVCan_RP_CoFcaOutput_De_CoFcaOutput
# define Rte_Read_RP_CvdOutputData_De_CvdOutputData Rte_Read_CpApVCan_RP_CvdOutputData_De_CvdOutputData
# define Rte_Read_RP_DawOutput_De_DawOutput Rte_Read_CpApVCan_RP_DawOutput_De_DawOutput
# define Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc Rte_Read_CpApVCan_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc
# define Rte_Read_RP_FcaEDR_Output_De_FcaInternalOutToEDR Rte_Read_CpApVCan_RP_FcaEDR_Output_De_FcaInternalOutToEDR
# define Rte_Read_RP_FcaFrCmrOut_De_FcaFrCmrOut Rte_Read_CpApVCan_RP_FcaFrCmrOut_De_FcaFrCmrOut
# define Rte_Read_RP_FcaOutput_De_FcaOutput Rte_Read_CpApVCan_RP_FcaOutput_De_FcaOutput
# define Rte_Read_RP_HbaOutput_De_HbaOutput Rte_Read_CpApVCan_RP_HbaOutput_De_HbaOutput
# define Rte_Read_RP_IslwOutput_De_IslwOutput Rte_Read_CpApVCan_RP_IslwOutput_De_IslwOutput
# define Rte_Read_RP_IvcHptOutput_De_IvcHptOutput Rte_Read_CpApVCan_RP_IvcHptOutput_De_IvcHptOutput
# define Rte_Read_RP_IvcMv1Output_De_IvcMv1Output Rte_Read_CpApVCan_RP_IvcMv1Output_De_IvcMv1Output
# define Rte_Read_RP_IvcMv2Output_De_IvcMv2Output Rte_Read_CpApVCan_RP_IvcMv2Output_De_IvcMv2Output
# define Rte_Read_RP_IvcPuFOutput_De_IvcPuFOutput Rte_Read_CpApVCan_RP_IvcPuFOutput_De_IvcPuFOutput
# define Rte_Read_RP_IvcPuMOutput_De_IvcPuMOutput Rte_Read_CpApVCan_RP_IvcPuMOutput_De_IvcPuMOutput
# define Rte_Read_RP_IvcSmvOutput_De_IvcSmvOutput Rte_Read_CpApVCan_RP_IvcSmvOutput_De_IvcSmvOutput
# define Rte_Read_RP_IvcSndOutput_De_IvcSndOutput Rte_Read_CpApVCan_RP_IvcSndOutput_De_IvcSndOutput
# define Rte_Read_RP_IvcSymbStaOutput_De_IvcSymbStaOutput Rte_Read_CpApVCan_RP_IvcSymbStaOutput_De_IvcSymbStaOutput
# define Rte_Read_RP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput Rte_Read_CpApVCan_RP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput
# define Rte_Read_RP_IvcVarOutput_De_IvcVarOutput Rte_Read_CpApVCan_RP_IvcVarOutput_De_IvcVarOutput
# define Rte_Read_RP_LssOutput_De_LssOutput Rte_Read_CpApVCan_RP_LssOutput_De_LssOutput
# define Rte_Read_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts Rte_Read_CpApVCan_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts
# define Rte_Read_RP_SccOutput_De_SccOutput Rte_Read_CpApVCan_RP_SccOutput_De_SccOutput


/**********************************************************************************************************************
 * Rte_IsUpdated_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_IsUpdated_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup
# define Rte_IsUpdated_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup
# define Rte_IsUpdated_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup
# define Rte_IsUpdated_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup
# define Rte_IsUpdated_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro
# define Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa
# define Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup
# define Rte_IsUpdated_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup
# define Rte_IsUpdated_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup
# define Rte_IsUpdated_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup
# define Rte_IsUpdated_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup
# define Rte_IsUpdated_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup Rte_IsUpdated_CpApVCan_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup
# define Rte_IsUpdated_RP_CvdOutputData_De_CvdOutputData Rte_IsUpdated_CpApVCan_RP_CvdOutputData_De_CvdOutputData


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_COM_SG_ADAS_CMD_10_20ms_SignalGroup_COM_SG_ADAS_CMD_10_20ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_10_20ms_SignalGroup_COM_SG_ADAS_CMD_10_20ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_CMD_20_20ms_SignalGroup_COM_SG_ADAS_CMD_20_20ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_20_20ms_SignalGroup_COM_SG_ADAS_CMD_20_20ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_CMD_21_50ms_SignalGroup_COM_SG_ADAS_CMD_21_50ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_21_50ms_SignalGroup_COM_SG_ADAS_CMD_21_50ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_CMD_30_10ms_SignalGroup_COM_SG_ADAS_CMD_30_10ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_30_10ms_SignalGroup_COM_SG_ADAS_CMD_30_10ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_CMD_31_50ms_SignalGroup_COM_SG_ADAS_CMD_31_50ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_31_50ms_SignalGroup_COM_SG_ADAS_CMD_31_50ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_CMD_35_10ms_SignalGroup_COM_SG_ADAS_CMD_35_10ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_CMD_35_10ms_SignalGroup_COM_SG_ADAS_CMD_35_10ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_INFO_01_200ms_SignalGroup_COM_SG_ADAS_INFO_01_200ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_INFO_01_200ms_SignalGroup_COM_SG_ADAS_INFO_01_200ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_UX_01_50ms_SignalGroup_COM_SG_ADAS_UX_01_50ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_UX_01_50ms_SignalGroup_COM_SG_ADAS_UX_01_50ms_SignalGroup
# define Rte_Write_COM_SG_ADAS_UX_02_50ms_SignalGroup_COM_SG_ADAS_UX_02_50ms_SignalGroup Rte_Write_CpApVCan_COM_SG_ADAS_UX_02_50ms_SignalGroup_COM_SG_ADAS_UX_02_50ms_SignalGroup
# define Rte_Write_COM_SG_FR_CMR_01_10ms_SignalGroup_COM_SG_FR_CMR_01_10ms_SignalGroup Rte_Write_CpApVCan_COM_SG_FR_CMR_01_10ms_SignalGroup_COM_SG_FR_CMR_01_10ms_SignalGroup
# define Rte_Write_COM_SG_FR_CMR_02_100ms_SignalGroup_COM_SG_FR_CMR_02_100ms_SignalGroup Rte_Write_CpApVCan_COM_SG_FR_CMR_02_100ms_SignalGroup_COM_SG_FR_CMR_02_100ms_SignalGroup
# define Rte_Write_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup Rte_Write_CpApVCan_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup
# define Rte_Write_COM_SG_FR_CMR_04_40ms_SignalGroup_COM_SG_FR_CMR_04_40ms_SignalGroup Rte_Write_CpApVCan_COM_SG_FR_CMR_04_40ms_SignalGroup_COM_SG_FR_CMR_04_40ms_SignalGroup
# define Rte_Write_PP_ActivateToi_De_ActivateToi Rte_Write_CpApVCan_PP_ActivateToi_De_ActivateToi
# define Rte_Write_PP_CVD_ReadTrackWidth_TrackWidth Rte_Write_CpApVCan_PP_CVD_ReadTrackWidth_TrackWidth
# define Rte_Write_PP_Core1ToCore2VCan_CANmsg Rte_Write_CpApVCan_PP_Core1ToCore2VCan_CANmsg
# define Rte_Write_PP_CvdInputData_De_CvdInputData Rte_Write_CpApVCan_PP_CvdInputData_De_CvdInputData
# define Rte_Write_PP_DawInput_De_DawInput Rte_Write_CpApVCan_PP_DawInput_De_DawInput
# define Rte_Write_PP_ECU_SSC_STAT_De_ECU_SSC_STAT Rte_Write_CpApVCan_PP_ECU_SSC_STAT_De_ECU_SSC_STAT
# define Rte_Write_PP_EDR_Input_Data_EDRInputData Rte_Write_CpApVCan_PP_EDR_Input_Data_EDRInputData
# define Rte_Write_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status Rte_Write_CpApVCan_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status
# define Rte_Write_PP_ENG_EngSta_De_VCan_ENG_EngSta Rte_Write_CpApVCan_PP_ENG_EngSta_De_VCan_ENG_EngSta
# define Rte_Write_PP_ENG_IsgSta_De_VCan_ENG_IsgSta Rte_Write_CpApVCan_PP_ENG_IsgSta_De_VCan_ENG_IsgSta
# define Rte_Write_PP_EscActive_De_EscActive Rte_Write_CpApVCan_PP_EscActive_De_EscActive
# define Rte_Write_PP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout Rte_Write_CpApVCan_PP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout
# define Rte_Write_PP_FcaInput_De_FcaInput Rte_Write_CpApVCan_PP_FcaInput_De_FcaInput
# define Rte_Write_PP_FcaWarnLampCond_De_FcaWarnLampCond Rte_Write_CpApVCan_PP_FcaWarnLampCond_De_FcaWarnLampCond
# define Rte_Write_PP_GearReverse_De_GearReverse Rte_Write_CpApVCan_PP_GearReverse_De_GearReverse
# define Rte_Write_PP_GearReverse_De_GearReverseValid Rte_Write_CpApVCan_PP_GearReverse_De_GearReverseValid
# define Rte_Write_PP_HCU_HevRdySta_De_HCU_HevRdySta Rte_Write_CpApVCan_PP_HCU_HevRdySta_De_HCU_HevRdySta
# define Rte_Write_PP_IslwInput_De_IslwInput Rte_Write_CpApVCan_PP_IslwInput_De_IslwInput
# define Rte_Write_PP_LateralAcceleration_De_LateralAcceleration Rte_Write_CpApVCan_PP_LateralAcceleration_De_LateralAcceleration
# define Rte_Write_PP_LateralAcceleration_De_LateralAccelerationValid Rte_Write_CpApVCan_PP_LateralAcceleration_De_LateralAccelerationValid
# define Rte_Write_PP_LeftIndicatorOn_De_LeftIndicatorOn Rte_Write_CpApVCan_PP_LeftIndicatorOn_De_LeftIndicatorOn
# define Rte_Write_PP_LkaToiFault_De_LkaToiFault Rte_Write_CpApVCan_PP_LkaToiFault_De_LkaToiFault
# define Rte_Write_PP_LssInput_De_LssInput Rte_Write_CpApVCan_PP_LssInput_De_LssInput
# define Rte_Write_PP_RightIndicatorOn_De_RightIndicatorOn Rte_Write_CpApVCan_PP_RightIndicatorOn_De_RightIndicatorOn
# define Rte_Write_PP_SR_MeInputCommData_De_MeInputCommData Rte_Write_CpApVCan_PP_SR_MeInputCommData_De_MeInputCommData
# define Rte_Write_PP_SccInput_De_SccInput Rte_Write_CpApVCan_PP_SccInput_De_SccInput
# define Rte_Write_PP_SccInputFromVCan_De_SccInputFromVCan Rte_Write_CpApVCan_PP_SccInputFromVCan_De_SccInputFromVCan
# define Rte_Write_PP_SccWarnLampCond_De_SccWarnLampCond Rte_Write_CpApVCan_PP_SccWarnLampCond_De_SccWarnLampCond
# define Rte_Write_PP_SteeringAngle_De_SteeringAngle Rte_Write_CpApVCan_PP_SteeringAngle_De_SteeringAngle
# define Rte_Write_PP_SteeringAngle_De_SteeringAngleValid Rte_Write_CpApVCan_PP_SteeringAngle_De_SteeringAngleValid
# define Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeed Rte_Write_CpApVCan_PP_SteeringAngleSpeed_De_SteeringAngleSpeed
# define Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid Rte_Write_CpApVCan_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid
# define Rte_Write_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus Rte_Write_CpApVCan_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus
# define Rte_Write_PP_VCan_GetOdoValue_De_OdoVal Rte_Write_CpApVCan_PP_VCan_GetOdoValue_De_OdoVal
# define Rte_Write_PP_VehicleSpeed_De_VehicleSpeed Rte_Write_CpApVCan_PP_VehicleSpeed_De_VehicleSpeed
# define Rte_Write_PP_VehicleSpeed_De_VehicleSpeedValid Rte_Write_CpApVCan_PP_VehicleSpeed_De_VehicleSpeedValid
# define Rte_Write_PP_VsmActive_De_VsmActive Rte_Write_CpApVCan_PP_VsmActive_De_VsmActive
# define Rte_Write_PP_WiperOn_De_WiperOn Rte_Write_CpApVCan_PP_WiperOn_De_WiperOn
# define Rte_Write_PP_YawRate_De_YawRate Rte_Write_CpApVCan_PP_YawRate_De_YawRate
# define Rte_Write_PP_YawRate_De_YawRateValid Rte_Write_CpApVCan_PP_YawRate_De_YawRateValid


/**********************************************************************************************************************
 * Rte_Mode_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Mode_RP_VCan_BusOFFStatus_BSW_BswM_MDGP_BswMVCAN_RteModeDclGroup Rte_Mode_CpApVCan_RP_VCan_BusOFFStatus_BSW_BswM_MDGP_BswMVCAN_RteModeDclGroup


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_NvMService_AC2_NvBlockNeed_GetErrorStatus Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_GetErrorStatus
# define Rte_Call_NvMService_AC2_NvBlockNeed_ReadBlock Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_ReadBlock
# define Rte_Call_NvMService_AC2_NvBlockNeed_WriteBlock Rte_Call_CpApVCan_NvMService_AC2_NvBlockNeed_WriteBlock
# define Rte_Call_PP_EDR_Trigger_EDR_Trigger_Function Rte_Call_CpApVCan_PP_EDR_Trigger_EDR_Trigger_Function
# define Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus Rte_Call_CpApVCan_RP_AppDiagFaultStatus_GetAppDiagFltStatus
# define Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApVCan_RP_AppDiagFaultStatus_SetAppDiagFltStatus
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApVCan_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApVCan_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApVCan_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrLDW_getFrCmrLDW Rte_Call_CpApVCan_RP_FrCmrLDW_getFrCmrLDW
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApVCan_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApVCan_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_HKMC_ReleaseInfo_getHKMC_ReleaseInfo Rte_Call_CpApVCan_RP_HKMC_ReleaseInfo_getHKMC_ReleaseInfo


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_PIM_Cvd_TrackWidthInputs() (Rte_Inst_CpApVCan->Pim_PIM_Cvd_TrackWidthInputs) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   CVD_VehicleTrackWidths *Rte_Pim_PIM_Cvd_TrackWidthInputs(void)
 *
 *********************************************************************************************************************/


# define CpApVCan_START_SEC_CODE
# include "CpApVCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_HKMC_ReleaseInfo_getHKMC_ReleaseInfo(HKMC_ReleaseInfo_record *HKMC_ReleaseInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HKMC_ReleaseInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApVCanInit Re_CpApVCanInit
FUNC(void, CpApVCan_CODE) Re_CpApVCanInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(COM_DT_SG_ABS_ESC_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(COM_DT_SG_ADAS_PRK_21_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(COM_DT_SG_BCM_07_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(COM_DT_SG_BCM_08_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(COM_DT_SG_BCM_10_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(COM_DT_SG_BCM_13_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(COM_DT_SG_CLU_01_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(COM_DT_SG_CLU_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(COM_DT_SG_CLU_04_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(COM_DT_SG_CLU_12_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(COM_DT_SG_CLU_13_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(COM_DT_SG_CLU_14_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(COM_DT_SG_CLU_25_00ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(COM_DT_SG_CTM_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(COM_DT_SG_DATC_17_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(COM_DT_SG_EMS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(COM_DT_SG_EMS_02_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(COM_DT_SG_EMS_03_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(COM_DT_SG_EMS_05_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(COM_DT_SG_EMS_07_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(COM_DT_SG_EMS_11_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(COM_DT_SG_EPB_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(COM_DT_SG_ESC_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(COM_DT_SG_ESC_03_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(COM_DT_SG_HCU_03_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(COM_DT_SG_HCU_05_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(COM_DT_SG_HTCU_04_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(COM_DT_SG_HTCU_05_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(COM_DT_SG_HU_CLU_PE_05_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(COM_DT_SG_HU_GW_PE_01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(COM_DT_SG_HU_MON_PE_01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_META_E_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_POS_PE_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(COM_DT_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(COM_DT_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(COM_DT_SG_HU_NAVI_V2_3_SEG_E_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(COM_DT_SG_HU_Navi_ISLW_PE_00_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(COM_DT_SG_HU_USM_E_14_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(COM_DT_SG_IAU_16_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(COM_DT_SG_ICC_HS_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(COM_DT_SG_ICC_HS_04_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(COM_DT_SG_ICSC_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(COM_DT_SG_ICU_02_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(COM_DT_SG_ICU_04_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(COM_DT_SG_ICU_07_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(COM_DT_SG_IEB_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(COM_DT_SG_IMU_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(COM_DT_SG_MDPS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(COM_DT_SG_MFSW_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(COM_DT_SG_SAS_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(COM_DT_SG_SMK_02_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(COM_DT_SG_SWRC_03_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(COM_DT_SG_TCU_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(COM_DT_SG_WHL_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_CoFCAEDR_Output_De_EDR_Output(CoFcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(CoFcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaOutput_De_CoFcaOutput(CoFcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CvdOutputData_De_CvdOutputData(CvdOutputData_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutput_De_DawOutput(DawOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_FcaEDR_Output_De_FcaInternalOutToEDR(FcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFrCmrOut_De_FcaFrCmrOut(FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaOutput_De_FcaOutput(FcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaOutput_De_HbaOutput(HbaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwOutput_De_IslwOutput(IslwOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcHptOutput_De_IvcHptOutput(IvcHptOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcMv1Output_De_IvcMv1Output(IvcMv1Output_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcMv2Output_De_IvcMv2Output(IvcMv2Output_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcPuFOutput_De_IvcPuFOutput(IvcPuFOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcPuMOutput_De_IvcPuMOutput(IvcPuMOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSmvOutput_De_IvcSmvOutput(IvcSmvOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSndOutput_De_IvcSndOutput(IvcSndOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcSymbStaOutput_De_IvcSymbStaOutput(IvcSymbStaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcTrffcSgnOutput_De_IvcTrffcSgnOutput(IvcTrffcSgnOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcVarOutput_De_IvcVarOutput(IvcVarOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssOutput_De_LssOutput(LssOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SR_LdwFuncTestSts_De_LdwFuncTestSts(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_SccOutput_De_SccOutput(SccOutput_t *data)
 *   boolean Rte_IsUpdated_COM_SG_ABS_ESC_01_10ms_SignalGroup_COM_SG_ABS_ESC_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ADAS_PRK_21_20ms_SignalGroup_COM_SG_ADAS_PRK_21_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_07_200ms_SignalGroup_COM_SG_BCM_07_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_08_200ms_SignalGroup_COM_SG_BCM_08_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_10_200ms_SignalGroup_COM_SG_BCM_10_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_BCM_13_200ms_SignalGroup_COM_SG_BCM_13_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_01_20ms_SignalGroup_COM_SG_CLU_01_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_02_100ms_SignalGroup_COM_SG_CLU_02_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_04_00ms_SignalGroup_COM_SG_CLU_04_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_12_00ms_SignalGroup_COM_SG_CLU_12_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_13_00ms_SignalGroup_COM_SG_CLU_13_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_14_200ms_SignalGroup_COM_SG_CLU_14_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CLU_25_00ms_SignalGroup_COM_SG_CLU_25_00ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_CTM_01_200ms_SignalGroup_COM_SG_CTM_01_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_DATC_17_200ms_SignalGroup_COM_SG_DATC_17_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_01_10ms_SignalGroup_COM_SG_EMS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_02_10ms_SignalGroup_COM_SG_EMS_02_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_03_10ms_SignalGroup_COM_SG_EMS_03_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_05_100ms_SignalGroup_COM_SG_EMS_05_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_07_10ms_SignalGroup_COM_SG_EMS_07_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EMS_11_10ms_SignalGroup_COM_SG_EMS_11_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_EPB_01_50ms_SignalGroup_COM_SG_EPB_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ESC_01_10ms_SignalGroup_COM_SG_ESC_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ESC_03_20ms_SignalGroup_COM_SG_ESC_03_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HCU_03_10ms_SignalGroup_COM_SG_HCU_03_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HCU_05_100ms_SignalGroup_COM_SG_HCU_05_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HTCU_04_10ms_SignalGroup_COM_SG_HTCU_04_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HTCU_05_10ms_SignalGroup_COM_SG_HTCU_05_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_CLU_PE_05_SignalGroup_COM_SG_HU_CLU_PE_05_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_GW_PE_01_SignalGroup_COM_SG_HU_GW_PE_01_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_MON_PE_01_SignalGroup_COM_SG_HU_MON_PE_01_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup_COM_SG_HU_NAVI_V2_3_META_E_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup_COM_SG_HU_NAVI_V2_3_POS_PE_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro_COM_SG_HU_NAVI_V2_3_PROLONG_E_SignalGro(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa_COM_SG_HU_NAVI_V2_3_PROSHORT_E_00_Signa(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup_COM_SG_HU_NAVI_V2_3_SEG_E_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup_COM_SG_HU_Navi_ISLW_PE_00_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_HU_USM_E_14_SignalGroup_COM_SG_HU_USM_E_14_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IAU_16_200ms_SignalGroup_COM_SG_IAU_16_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICC_HS_01_50ms_SignalGroup_COM_SG_ICC_HS_01_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICC_HS_04_50ms_SignalGroup_COM_SG_ICC_HS_04_50ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICSC_02_100ms_SignalGroup_COM_SG_ICSC_02_100ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_02_200ms_SignalGroup_COM_SG_ICU_02_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_04_200ms_SignalGroup_COM_SG_ICU_04_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_ICU_07_200ms_SignalGroup_COM_SG_ICU_07_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IEB_01_10ms_SignalGroup_COM_SG_IEB_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_IMU_01_10ms_SignalGroup_COM_SG_IMU_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_MDPS_01_10ms_SignalGroup_COM_SG_MDPS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_MFSW_01_200ms_SignalGroup_COM_SG_MFSW_01_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SAS_01_10ms_SignalGroup_COM_SG_SAS_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SMK_02_200ms_SignalGroup_COM_SG_SMK_02_200ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_SWRC_03_20ms_SignalGroup_COM_SG_SWRC_03_20ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_TCU_01_10ms_SignalGroup_COM_SG_TCU_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_COM_SG_WHL_01_10ms_SignalGroup_COM_SG_WHL_01_10ms_SignalGroup(void)
 *   boolean Rte_IsUpdated_RP_CvdOutputData_De_CvdOutputData(void)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CVD_ReadTrackWidth_TrackWidth(const Cvd_TrackWidthInput_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2VCan_CANmsg(const CANmsg_t *data)
 *   Std_ReturnType Rte_Write_PP_CvdInputData_De_CvdInputData(const CvdInputData_t *data)
 *   Std_ReturnType Rte_Write_PP_DawInput_De_DawInput(const DawInput_t *data)
 *   Std_ReturnType Rte_Write_PP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(uint8 data)
 *   Std_ReturnType Rte_Write_PP_ENG_EngSta_De_VCan_ENG_EngSta(const VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Write_PP_ENG_IsgSta_De_VCan_ENG_IsgSta(const VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Write_PP_EscActive_De_EscActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_FcaFailSafeInfoTrailerMsgTout_De_FcaFailSafeInfoTrailerMsgTout(const FcaFailSafeInfoTrailerMsgTout_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaInput_De_FcaInput(const FcaInput_t *data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverse(boolean data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverseValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 data)
 *   Std_ReturnType Rte_Write_PP_IslwInput_De_IslwInput(const IslwInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAcceleration(float32 data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAccelerationValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_LeftIndicatorOn_De_LeftIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_RightIndicatorOn_De_RightIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_MeInputCommData_De_MeInputCommData(const MeInputCommData_t *data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngle(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngleValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_VCan_GetOdoValue_De_OdoVal(COM_DT_CLU_OdoVal data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VsmActive_De_VsmActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_WiperOn_De_WiperOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRate(float32 data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRateValid(boolean data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_RP_VCan_BusOFFStatus_BSW_BswM_MDGP_BswMVCAN_RteModeDclGroup(void)
 *   Modes of Rte_ModeType_BswMVCAN_RteModeDclGroup:
 *   - RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_BUSOFF
 *   - RTE_MODE_BswMVCAN_RteModeDclGroup_VCAN_Normal
 *   - RTE_TRANSITION_BswMVCAN_RteModeDclGroup
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_NvMService_AC2_NvBlockNeed_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApVCanMain Re_CpApVCanMain
FUNC(void, CpApVCan_CODE) Re_CpApVCanMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApVCanOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFcaFrCmrOut_De_CoFcaFrCmrOut(CoFcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaOutput_De_CoFcaOutput(CoFcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutput_De_DawOutput(DawOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFrCmrOut_De_FcaFrCmrOut(FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaOutput_De_FcaOutput(FcaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaOutput_De_HbaOutput(HbaOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwOutput_De_IslwOutput(IslwOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssOutput_De_LssOutput(LssOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccOutput_De_SccOutput(SccOutput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_10_20ms_SignalGroup_COM_SG_ADAS_CMD_10_20ms_SignalGroup(const COM_DT_SG_ADAS_CMD_10_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_20_20ms_SignalGroup_COM_SG_ADAS_CMD_20_20ms_SignalGroup(const COM_DT_SG_ADAS_CMD_20_20ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_21_50ms_SignalGroup_COM_SG_ADAS_CMD_21_50ms_SignalGroup(const COM_DT_SG_ADAS_CMD_21_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_30_10ms_SignalGroup_COM_SG_ADAS_CMD_30_10ms_SignalGroup(const COM_DT_SG_ADAS_CMD_30_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_31_50ms_SignalGroup_COM_SG_ADAS_CMD_31_50ms_SignalGroup(const COM_DT_SG_ADAS_CMD_31_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_CMD_35_10ms_SignalGroup_COM_SG_ADAS_CMD_35_10ms_SignalGroup(const COM_DT_SG_ADAS_CMD_35_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_INFO_01_200ms_SignalGroup_COM_SG_ADAS_INFO_01_200ms_SignalGroup(const COM_DT_SG_ADAS_INFO_01_200ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_UX_01_50ms_SignalGroup_COM_SG_ADAS_UX_01_50ms_SignalGroup(const COM_DT_SG_ADAS_UX_01_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_ADAS_UX_02_50ms_SignalGroup_COM_SG_ADAS_UX_02_50ms_SignalGroup(const COM_DT_SG_ADAS_UX_02_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_01_10ms_SignalGroup_COM_SG_FR_CMR_01_10ms_SignalGroup(const COM_DT_SG_FR_CMR_01_10ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_02_100ms_SignalGroup_COM_SG_FR_CMR_02_100ms_SignalGroup(const COM_DT_SG_FR_CMR_02_100ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup(const COM_DT_SG_FR_CMR_03_50ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_04_40ms_SignalGroup_COM_SG_FR_CMR_04_40ms_SignalGroup(const COM_DT_SG_FR_CMR_04_40ms_SignalGroup *data)
 *   Std_ReturnType Rte_Write_PP_ActivateToi_De_ActivateToi(boolean data)
 *   Std_ReturnType Rte_Write_PP_CVD_ReadTrackWidth_TrackWidth(const Cvd_TrackWidthInput_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2VCan_CANmsg(const CANmsg_t *data)
 *   Std_ReturnType Rte_Write_PP_CvdInputData_De_CvdInputData(const CvdInputData_t *data)
 *   Std_ReturnType Rte_Write_PP_DawInput_De_DawInput(const DawInput_t *data)
 *   Std_ReturnType Rte_Write_PP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 data)
 *   Std_ReturnType Rte_Write_PP_EDR_Input_Data_EDRInputData(const EDR_InputData *data)
 *   Std_ReturnType Rte_Write_PP_ENG_EngSta_De_VCan_ENG_EngSta(const VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Write_PP_ENG_IsgSta_De_VCan_ENG_IsgSta(const VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Write_PP_EscActive_De_EscActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_FcaInput_De_FcaInput(const FcaInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaWarnLampCond_De_FcaWarnLampCond(uint8 data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverse(boolean data)
 *   Std_ReturnType Rte_Write_PP_GearReverse_De_GearReverseValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 data)
 *   Std_ReturnType Rte_Write_PP_IslwInput_De_IslwInput(const IslwInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAcceleration(float32 data)
 *   Std_ReturnType Rte_Write_PP_LateralAcceleration_De_LateralAccelerationValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_LeftIndicatorOn_De_LeftIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_LkaToiFault_De_LkaToiFault(boolean data)
 *   Std_ReturnType Rte_Write_PP_LssInput_De_LssInput(const LssInput_t *data)
 *   Std_ReturnType Rte_Write_PP_RightIndicatorOn_De_RightIndicatorOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_SR_MeInputCommData_De_MeInputCommData(const MeInputCommData_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInput_De_SccInput(const SccInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInputFromVCan_De_SccInputFromVCan(const SccInputFromVCan_t *data)
 *   Std_ReturnType Rte_Write_PP_SccWarnLampCond_De_SccWarnLampCond(uint8 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngle(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngle_De_SteeringAngleValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_SteeringAngleSpeed_De_SteeringAngleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 data)
 *   Std_ReturnType Rte_Write_PP_VCan_GetOdoValue_De_OdoVal(COM_DT_CLU_OdoVal data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeed(float32 data)
 *   Std_ReturnType Rte_Write_PP_VehicleSpeed_De_VehicleSpeedValid(boolean data)
 *   Std_ReturnType Rte_Write_PP_VsmActive_De_VsmActive(boolean data)
 *   Std_ReturnType Rte_Write_PP_WiperOn_De_WiperOn(boolean data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRate(float32 data)
 *   Std_ReturnType Rte_Write_PP_YawRate_De_YawRateValid(boolean data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EDR_Trigger_EDR_Trigger_Function(void)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApVCanOut Re_CpApVCanOut
FUNC(void, CpApVCan_CODE) Re_CpApVCanOut(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_EDRInputData_50ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 50ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_CoFCAEDR_Output_De_EDR_Output(CoFcaEDR_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaEDR_Output_De_FcaInternalOutToEDR(FcaEDR_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_EDR_Input_Data_EDRInputData(const EDR_InputData *data)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_EDRInputData_50ms Re_EDRInputData_50ms
FUNC(void, CpApVCan_CODE) Re_EDRInputData_50ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_FrCmr03_50ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 50ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_FR_CMR_03_50ms_SignalGroup_COM_SG_FR_CMR_03_50ms_SignalGroup(const COM_DT_SG_FR_CMR_03_50ms_SignalGroup *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_FrCmr03_50ms Re_FrCmr03_50ms
FUNC(void, CpApVCan_CODE) Re_FrCmr03_50ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_getCanmsg
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getCanmsg> of PortPrototype <PP_CANmsg>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_getCanmsg(CANmsg_t *CANmsg)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_CANmsg_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_getCanmsg Re_getCanmsg
FUNC(Std_ReturnType, CpApVCan_CODE) Re_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPVCAN_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApVCan_STOP_SEC_CODE
# include "CpApVCan_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrLDW_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_IF_HKMC_ReleaseInfo_ReturnType (1U)

# define RTE_E_NvMService_AC3_SRBS_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPVCAN_H */
