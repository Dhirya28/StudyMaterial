/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApWdgMonCore0.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApWdgMonCore0
 *  Generation Time:  2023-04-20 13:52:57
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApWdgMonCore0> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPWDGMONCORE0_H
# define _RTE_CPAPWDGMONCORE0_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApWdgMonCore0_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApWdgMonCore0
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApWdgMonCore0, RTE_CONST, RTE_CONST) Rte_Inst_CpApWdgMonCore0; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApWdgMonCore0, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApWdgMonCore0_RP_AppWdgMonInfo_Core1_AppWdgMonInfo(P2VAR(AppWdgMonInfo, AUTOMATIC, RTE_CPAPWDGMONCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApWdgMonCore0_RP_AppWdgMonInfo_Core2_AppWdgMonInfo(P2VAR(AppWdgMonInfo, AUTOMATIC, RTE_CPAPWDGMONCORE0_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(uint8, RTE_CODE) Rte_Mode_CpApWdgMonCore0_WdgM_GlobalMode_Core0_currentMode(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_10ms_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_2ms_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_5ms_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_EyeQSBS_CheckpointReached(WdgM_CheckpointIdType CPID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_GetFirstExpiredSEID(P2VAR(WdgM_SupervisedEntityIdType, AUTOMATIC, RTE_CPAPWDGMONCORE0_APPL_VAR) SEID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_GetGlobalStatus(P2VAR(WdgM_GlobalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE0_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApWdgMonCore0_WdgM_LocalStatus_Core0_2ms_GetLocalStatus(P2VAR(WdgM_LocalStatusType, AUTOMATIC, RTE_CPAPWDGMONCORE0_APPL_VAR) Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_AppWdgMonInfo_Core1_AppWdgMonInfo Rte_Read_CpApWdgMonCore0_RP_AppWdgMonInfo_Core1_AppWdgMonInfo
# define Rte_Read_RP_AppWdgMonInfo_Core2_AppWdgMonInfo Rte_Read_CpApWdgMonCore0_RP_AppWdgMonInfo_Core2_AppWdgMonInfo


/**********************************************************************************************************************
 * Rte_Mode_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Mode_WdgM_GlobalMode_Core0_currentMode Rte_Mode_CpApWdgMonCore0_WdgM_GlobalMode_Core0_currentMode


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_WdgM_AliveSupervision_Core0_10ms_CheckpointReached Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_10ms_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core0_2ms_CheckpointReached Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_2ms_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core0_5ms_CheckpointReached Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_5ms_CheckpointReached
# define Rte_Call_WdgM_AliveSupervision_Core0_EyeQSBS_CheckpointReached Rte_Call_CpApWdgMonCore0_WdgM_AliveSupervision_Core0_EyeQSBS_CheckpointReached
# define Rte_Call_WdgM_General_Core0_ActivateSupervisionEntity Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_ActivateSupervisionEntity
# define Rte_Call_WdgM_General_Core0_GetFirstExpiredSEID Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_GetFirstExpiredSEID
# define Rte_Call_WdgM_General_Core0_GetGlobalStatus Rte_Call_CpApWdgMonCore0_WdgM_General_Core0_GetGlobalStatus
# define Rte_Call_WdgM_LocalStatus_Core0_2ms_GetLocalStatus Rte_Call_CpApWdgMonCore0_WdgM_LocalStatus_Core0_2ms_GetLocalStatus




# define CpApWdgMonCore0_START_SEC_CODE
# include "CpApWdgMonCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApWdgMonCore0_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApWdgMonCore0_Init Re_CpApWdgMonCore0_Init
FUNC(void, CpApWdgMonCore0_CODE) Re_CpApWdgMonCore0_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApWdgMonCore0_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_AppWdgMonInfo_Core1_AppWdgMonInfo(AppWdgMonInfo *data)
 *   Std_ReturnType Rte_Read_RP_AppWdgMonInfo_Core2_AppWdgMonInfo(AppWdgMonInfo *data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_WdgM_GlobalMode_Core0_currentMode(void)
 *   Modes of Rte_ModeType_WdgM_Mode:
 *   - RTE_MODE_WdgM_Mode_SUPERVISION_DEACTIVATED
 *   - RTE_MODE_WdgM_Mode_SUPERVISION_EXPIRED
 *   - RTE_MODE_WdgM_Mode_SUPERVISION_FAILED
 *   - RTE_MODE_WdgM_Mode_SUPERVISION_OK
 *   - RTE_MODE_WdgM_Mode_SUPERVISION_STOPPED
 *   - RTE_TRANSITION_WdgM_Mode
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_General_Core0_ActivateSupervisionEntity(WdgM_SupervisedEntityIdType SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core0_GetFirstExpiredSEID(WdgM_SupervisedEntityIdType *SEID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_General_Core0_GetGlobalStatus(WdgM_GlobalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_General_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApWdgMonCore0_Main Re_CpApWdgMonCore0_Main
FUNC(void, CpApWdgMonCore0_CODE) Re_CpApWdgMonCore0_Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core0_10ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core0_10ms_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core0_10ms Re_WdgM_AliveMon_Core0_10ms
FUNC(void, CpApWdgMonCore0_CODE) Re_WdgM_AliveMon_Core0_10ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core0_2ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 2ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core0_2ms_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *   Std_ReturnType Rte_Call_WdgM_LocalStatus_Core0_2ms_GetLocalStatus(WdgM_LocalStatusType *Status)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_LocalStatus_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core0_2ms Re_WdgM_AliveMon_Core0_2ms
FUNC(void, CpApWdgMonCore0_CODE) Re_WdgM_AliveMon_Core0_2ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core0_5ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core0_5ms_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core0_5ms Re_WdgM_AliveMon_Core0_5ms
FUNC(void, CpApWdgMonCore0_CODE) Re_WdgM_AliveMon_Core0_5ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_WdgM_AliveMon_Core0_EyeQSBS
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_WdgM_AliveSupervision_Core0_EyeQSBS_CheckpointReached(WdgM_CheckpointIdType CPID)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_WdgM_AliveSupervision_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_WdgM_AliveMon_Core0_EyeQSBS Re_WdgM_AliveMon_Core0_EyeQSBS
FUNC(void, CpApWdgMonCore0_CODE) Re_WdgM_AliveMon_Core0_EyeQSBS(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApWdgMonCore0_STOP_SEC_CODE
# include "CpApWdgMonCore0_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_WdgM_AliveSupervision_E_NOT_OK (1U)

# define RTE_E_WdgM_General_E_NOT_OK (1U)

# define RTE_E_WdgM_LocalStatus_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPWDGMONCORE0_H */
