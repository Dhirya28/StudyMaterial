/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApIslwIntf.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApIslwIntf
 *  Generation Time:  2023-04-20 13:53:22
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApIslwIntf>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApIslwIntf.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Array Types:
 * ============
 * Rte_DT_Arr_TsrInfo_0: Array with 10 element(s) of type IslwTSRInfo_t
 * Rte_DT_EYEQMESP_VehicleCalParams_t_14: Array with 7 element(s) of type uint8
 * Rte_DT_IslwFrqNvData_t_24: Array with 3 element(s) of type Rte_DT_IslwFrqNvData_t_24_0
 * Rte_DT_IslwFrqNvData_t_24_0: Array with 1 element(s) of type uint8
 *
 * Record Types:
 * =============
 * Arr_TsrInfo: Record with elements
 *   IslwTSRInfo of type Rte_DT_Arr_TsrInfo_0
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * EYEQMESP_EnvironmentParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   LeftWheel_u16 of type uint16
 *   RightWheel_u16 of type uint16
 *   RefPX_Front_Bumper_u16 of type uint16
 *   CamToFrontAxle_u16 of type uint16
 *   CamToRearAxle_u16 of type uint16
 *   WheelWidth_u8 of type uint8
 *   WheelRadius_u8 of type uint8
 *   MinHorizon_u16 of type uint16
 *   MaxHorizon_u16 of type uint16
 *   MinYaw_u16 of type uint16
 *   MaxYaw_u16 of type uint16
 *   MaxRoll_u16 of type uint16
 *   Top_Crop_u16 of type uint16
 *   Bottom_Crop_u16 of type uint16
 *   Steering_Ratio_u16 of type uint16
 *   GPSToCam_dx_u16 of type uint16
 *   GPSToCam_dy_u16 of type uint16
 *   GPSToCam_dz_u16 of type uint16
 *   GPSToCam_dx_V_u8 of type uint8
 *   GPSToCam_dy_V_u8 of type uint8
 *   GPSToCam_dz_V_u8 of type uint8
 *   Top_Crop_V_u8 of type uint8
 *   Steering_Ratio_V_u8 of type uint8
 *   WheelWidth_V_u8 of type uint8
 *   WheelRadius_V_u8 of type uint8
 *   LeftWheel_V_u8 of type uint8
 *   RightWheel_V_u8 of type uint8
 *   RefPX_Front_Bumper_V_u8 of type uint8
 *   CamToFrontAxle_V_u8 of type uint8
 *   CamToRearAxle_V_u8 of type uint8
 *   MinHorizon_V_u8 of type uint8
 *   MaxHorizon_V_u8 of type uint8
 *   MinYaw_V_u8 of type uint8
 *   MaxYaw_V_u8 of type uint8
 *   MaxRoll_V_u8 of type uint8
 *   Bottom_Crop_V_u8 of type uint8
 *   fixedGpsLatency_u8 of type uint8
 *   fixedGpsLatency_V_u8 of type uint8
 *   receiverFrequency_u8 of type uint8
 *   receiverFrequency_V_u8 of type uint8
 *   Reserved_1_u16 of type uint16
 *   CalCRC_u16 of type uint16
 * EYEQMESP_VehicleCalParams_t: Record with elements
 *   TagID_u16 of type uint16
 *   Version_u16 of type uint16
 *   Region_Code_u8 of type uint8
 *   Driving_Side_u8 of type uint8
 *   Pitch_Base_u16 of type uint16
 *   Yaw_Base_u16 of type uint16
 *   Cam_Height_Base_u16 of type uint16
 *   Roll_Angle_Base_f32 of type float32
 *   HilModeEnable_u8 of type uint8
 *   OverrideActualTargetCalParams_u8 of type uint8
 *   Disable_Ethernet_Logging_u8 of type uint8
 *   Disable_Ethernet_Logging_V_u8 of type uint8
 *   ActivateEDR_u16 of type uint16
 *   ActivateEDR_V_u8 of type uint8
 *   Reserved1_u8 of type Rte_DT_EYEQMESP_VehicleCalParams_t_14
 *   CalCRC_u16 of type uint16
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * IslwEyeQInput_t: Record with elements
 *   u8_TSR_Sign_Count of type uint8
 *   u8_TSR_Sync_ID of type uint8
 *   u8_DrivingSideME of type uint8
 * IslwFrqNvData_t: Record with elements
 *   u16_Nvm_Navi_CountryCode of type uint16
 *   u8_SLIF_Speed_Display_Cluster of type uint8
 *   u8_SLIF_Speed_Display_Navi of type uint8
 *   u8_SLIF_VS_Unit of type uint8
 *   u8_Navi_SLIF_LinkClass_NVM of type uint8
 *   u8_SLIF_Former_Speed_Limit_From of type uint8
 *   u8_Nvm_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_ISLA_OptUsmSta of type uint8
 *   u8_Nvm_ISLA_Cntry of type uint8
 *   b_Nvm_Navi_On of type boolean
 *   u8_Nvm_ISLA_Cntry1USMSta of type uint8
 *   u8_Nvm_ISLA_Cntry2USMSta of type uint8
 *   u8_Nvm_ISLA_CntryVerTyp of type uint8
 *   u8_Nvm_USER_ID of type uint8
 *   u8_Nvm_OffsetUSM_User1 of type uint8
 *   u8_Nvm_OffsetUSM_User2 of type uint8
 *   u8_Nvm_OffsetUSM_Geust of type uint8
 *   u8_Nvm_NRS_USM_User1 of type uint8
 *   u8_Nvm_NRS_USM_User2 of type uint8
 *   u8_Nvm_NRS_USM_Guest of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_SunRay_Status of type uint8
 *   u8_RawValueCamolny_CLUMain of type uint8
 *   Reserved of type Rte_DT_IslwFrqNvData_t_24
 * IslwOccNvData_t: Record with elements
 *   u32_SLIF_MIN_TSR_DIST_MOTORWAY_SIGN_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_PASS_JC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_ENTER_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_IC_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXIT_FREEWAY_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MIN_TSR_DIST_EXPIRE_TIMER_AFT_NO_SIGN of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_10_50_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_51_80_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_81_140_SIGN_NON_HW of type uint32
 *   u32_SLIF_Rain_Decision_Period of type uint32
 *   u32_SLIF_Rain_Off_Decision_Period of type uint32
 *   u32_SLIF_MAX_TSR_DIST_EXTRA_DELAY_NOSPDLMT_BY_NAVI of type uint32
 *   u32_SLIF_MAX_TSR_DIST_LATRANGE_ARROW_SIGN_HWEXIT of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_NOPASSING_SIGN_NON_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_ARROW_SIGN_HW of type uint32
 *   u32_SLIF_MAX_TSR_DIST_RECOGND_RAIN_SIGN_HW of type uint32
 *   u32_SLIF_MIN_TSR_SAS_TURNDEC of type uint32
 *   u32_SLIF_BLOCKAGE_RUNTIME of type uint32
 *   u8_SLIF_SET_TSR_TIMER_MODE of type uint8
 *   u8_Nvm_Occ_ISLA_OffstUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_AutoUsmSta of type uint8
 *   u8_Nvm_Occ_ISLA_OptUsmSta of type uint8
 *   u16_IslwAppVersion of type uint16
 *   Reserved1 of type uint16
 *   Reserved2 of type uint16
 *   Reserved3 of type uint16
 *   Reserved4 of type uint16
 *   Reserved5 of type uint16
 *   Reserved6 of type uint16
 *   Reserved7 of type uint16
 * IslwTSRInfo_t: Record with elements
 *   u16_TSR_Sign_Name of type uint16
 *   u8_TSR_Relevancy of type uint8
 *   u8_TSR_Sup1_SignName of type uint8
 *   u8_TSR_Sup2_SignName of type uint8
 *   u16_TSR_Sign_Long_Distance of type uint16
 *   u16_TSR_Sign_Lateral_Distance of type uint16
 *   u16_TSR_Sign_Height of type uint16
 *   u8_TSR_ID of type uint8
 *   u8_TSR_Sup1_Confidence of type uint8
 *   u8_TSR_Sup2_Confidence of type uint8
 *   u8_TSR_Sign_Shape of type uint8
 *   u8_TSR_Sign_Is_Electronic of type boolean
 *   u8_TSR_Confidence of type uint8
 *   u16_TSR_Sign_Long_Distance_STD of type uint16
 *   u16_TSR_Sign_Lat_Distance_STD of type uint16
 *   u16_TSR_Sign_Height_STD of type uint16
 *   u16_TSR_Sign_Panel_Width of type uint16
 *   u16_TSR_Sign_Panel_Height of type uint16
 *   u16_TSR_Sign_Panel_Width_STD of type uint16
 *   u16_TSR_Sign_Panel_Height_STD of type uint16
 *   u16_Tracking_Out_of_Image of type uint16
 *   u16_TSR_Tracking_Age of type uint16
 * LssMeInfo_t: Record with elements
 *   b_MEFailSafeLKA of type uint8
 *   u8_DrivingSideME of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   Arr_TsrInfo *Rte_Pim_Arr_TsrInfo(void)
 *   IslwFrqNvData_t *Rte_Pim_IslwFrqNvData(void)
 *   IslwOccNvData_t *Rte_Pim_IslwOccNvData(void)
 *
 *********************************************************************************************************************/


#define CpApIslwIntf_START_SEC_CODE
#include "CpApIslwIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApIslwIntf_NvMNotifyJobFinished_IslwFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApIslwIntf_NvMNotifyJobFinished_IslwOccNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_DrivingSideStatus_De_DrivingSideStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *   Std_ReturnType Rte_Read_RP_LssMeInfo_De_LssMeInfo(LssMeInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadEnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadEnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_ReadVehicleCalParams_EYEQMESP_ReadVehicleCalParams(EYEQMESP_VehicleCalParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_ReadVehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C0(uint16 Index, uint16 *DSTSR_Buffer_C0)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C1(uint16 Index, uint16 *DSTSR_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C2(uint16 Index, uint16 *DSTSR_Buffer_C2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C3(uint16 Index, uint8 *DSTSR_Buffer_C3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C4(uint16 Index, uint8 *DSTSR_Buffer_C4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Buffer_C5(uint16 Index, uint8 *DSTSR_Buffer_C5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Camera_Source(uint16 Index, uint8 *DSTSR_Camera_Source)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Confidence(uint16 Index, uint8 *DSTSR_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Existence_Probability(uint16 Index, uint8 *DSTSR_Existence_Probability)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_ID(uint16 Index, uint8 *DSTSR_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Measurement_Status(uint16 Index, uint8 *DSTSR_Measurement_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Object_Property(uint16 Index, uint8 *DSTSR_Object_Property)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Protocol_Version(uint8 *DSTSR_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy(uint16 Index, uint8 *DSTSR_Relevancy)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Relevancy_Confidence(uint16 Index, uint8 *DSTSR_Relevancy_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Count(uint8 *DSTSR_Sign_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height(uint16 Index, uint16 *DSTSR_Sign_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Height_STD(uint16 Index, uint16 *DSTSR_Sign_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance(uint16 Index, uint16 *DSTSR_Sign_Lat_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Lat_Distance_STD(uint16 Index, uint16 *DSTSR_Sign_Lat_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance(uint16 Index, uint16 *DSTSR_Sign_Long_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Long_Distance_STD(uint16 Index, uint16 *DSTSR_Sign_Long_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Name(uint16 Index, uint16 *DSTSR_Sign_Name)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height(uint16 Index, uint16 *DSTSR_Sign_Panel_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Height_STD(uint16 Index, uint16 *DSTSR_Sign_Panel_Height_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width(uint16 Index, uint16 *DSTSR_Sign_Panel_Width)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Panel_Width_STD(uint16 Index, uint16 *DSTSR_Sign_Panel_Width_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sign_Shape(uint16 Index, uint8 *DSTSR_Sign_Shape)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Confidence(uint16 Index, uint8 *DSTSR_Sup1_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_Position(uint16 Index, uint8 *DSTSR_Sup1_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup1_SignName(uint16 Index, uint8 *DSTSR_Sup1_SignName)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Confidence(uint16 Index, uint8 *DSTSR_Sup2_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_Position(uint16 Index, uint8 *DSTSR_Sup2_Position)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sup2_SignName(uint16 Index, uint8 *DSTSR_Sup2_SignName)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Sync_ID(uint8 *DSTSR_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Age(uint16 Index, uint16 *DSTSR_Tracking_Age)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_Tracking_Out_of_Image(uint16 Index, uint16 *DSTSR_Tracking_Out_of_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_DSTSR_is_Electronic(uint16 Index, uint8 *DSTSR_is_Electronic)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_1(uint8 *Reserved_1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_10(uint16 Index, uint8 *Reserved_10)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_11(uint16 Index, uint8 *Reserved_11)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_12(uint16 Index, uint32 *Reserved_12)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_2(uint16 Index, uint8 *Reserved_2)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_3(uint16 Index, uint8 *Reserved_3)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_4(uint16 Index, uint8 *Reserved_4)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_5(uint16 Index, uint8 *Reserved_5)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_6(uint16 Index, uint8 *Reserved_6)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_7(uint16 Index, uint8 *Reserved_7)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_8(uint16 Index, uint16 *Reserved_8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_DSTFS_EYEQDG_Get_DSTFS_Reserved_9(uint16 Index, uint8 *Reserved_9)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_DSTFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfEyeQRead_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfEyeQRead(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfEyeQRead
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfIslwEyeQInput
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getIslwEyeQInput> of PortPrototype <PP_IslwEyeQInput>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApIslwIntfIslwEyeQInput(IslwEyeQInput_t *IslwEyeQInput)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfIslwEyeQInput_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfIslwEyeQInput(P2VAR(IslwEyeQInput_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwEyeQInput) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfIslwEyeQInput
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_IslwOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfReadIslwFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadIslwFrqNvData> of PortPrototype <PP_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfReadIslwFrqNvData(IslwFrqNvData_t *IslwFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfReadIslwFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfReadIslwFrqNvData(P2VAR(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfReadIslwFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfReadIslwOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadIslwOccNvData> of PortPrototype <PP_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfReadIslwOccNvData(IslwOccNvData_t *IslwOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfReadIslwOccNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfReadIslwOccNvData(P2VAR(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) IslwOccNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfReadIslwOccNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfTsrInfo
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getTsrInfo> of PortPrototype <PP_TsrInfo>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApIslwIntfTsrInfo(IslwTSRInfo_t *TsrInfo)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfTsrInfo_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApIslwIntf_CODE) Re_CpApIslwIntfTsrInfo(P2VAR(IslwTSRInfo_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_VAR) TsrInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfTsrInfo
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfWriteIslwFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteIslwFrqNvData> of PortPrototype <PP_IslwFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfWriteIslwFrqNvData(const IslwFrqNvData_t *IslwFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfWriteIslwFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfWriteIslwFrqNvData(P2CONST(IslwFrqNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_DATA) IslwFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfWriteIslwFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApIslwIntfWriteIslwOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteIslwOccNvData> of PortPrototype <PP_IslwOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApIslwIntfWriteIslwOccNvData(const IslwOccNvData_t *IslwOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_IslwOccNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfWriteIslwOccNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApIslwIntf_CODE) Re_CpApIslwIntfWriteIslwOccNvData(P2CONST(IslwOccNvData_t, AUTOMATIC, RTE_CPAPISLWINTF_APPL_DATA) IslwOccNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApIslwIntfWriteIslwOccNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApIslwIntf_STOP_SEC_CODE
#include "CpApIslwIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApIslwIntfOut)  *****************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApIslwIntfOut_doc)  ******************************/


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
