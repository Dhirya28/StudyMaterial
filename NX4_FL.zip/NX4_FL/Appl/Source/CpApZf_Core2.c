/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApZf_Core2.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApZf_Core2
 *  Generation Time:  2023-04-20 13:53:26
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApZf_Core2>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CpApZf_Core2.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Array Types:
 * ============
 * Rte_DT_ArrFrCmrFS_0: Array with 3 element(s) of type FailSafe_t
 *
 * Record Types:
 * =============
 * ArrFrCmrFS: Record with elements
 *   FrCmrFS of type Rte_DT_ArrFrCmrFS_0
 * Core2AppVersionInfo_t: Record with elements
 *   HbaAppVersionInfo of type uint16
 *   IslwAppVersionInfo of type uint16
 *   LssAppVersionInfo of type uint16
 *   DawAppVersionInfo of type uint16
 *   IvcAppVersionInfo of type uint16
 * DawAppVersionInfo_t: Record with elements
 *   u16_DawAppVersion of type uint16
 * FailSafe_t: Record with elements
 *   FS_CRC of type uint32
 *   FS_Camera_ID of type uint8
 *   FS_Free_Sight of type boolean
 *   FS_Splashes of type uint8
 *   FS_Sun_Ray of type uint8
 *   FS_Low_Sun of type uint8
 *   FS_Blur_Image of type uint8
 *   FS_Partial_Blockage of type uint8
 *   FS_Full_Blockage of type uint8
 *   FS_Frozen_Windshield_Lens of type uint8
 *   FS_Out_Of_Focus of type uint8
 *   FS_C2C_Out_Of_Calib of type uint8
 * FrCmrHdrFS_t: Record with elements
 *   FS_Header_CRC of type uint32
 *   FS_Protocol_Version of type uint8
 *   FS_Sync_ID of type uint8
 *   FS_Cameras_Number of type uint8
 *   FS_TSR_Out_OF_Calib of type uint8
 *   FS_Out_Of_Calib of type uint8
 *   FS_Impacted_Technologies of type uint16
 *   FS_Rain of type uint8
 *   FS_Fog of type uint8
 *   FS_C2W_OOR of type uint8
 * HbaAppVersionInfo_t: Record with elements
 *   u16_HbaAppVersion of type uint16
 * IsMsgVaildObjtAEBStatus_t: Record with elements
 *   VDStatus_u8 of type uint8
 *   VRUStatus_u8 of type uint8
 *   ObjtStatus_u8 of type uint8
 * IslwAppVersionInfo_t: Record with elements
 *   u16_IslwAppVersion of type uint16
 * IvcAppVersionInfo_t: Record with elements
 *   u16_IvcAppVersion of type uint16
 * LssAppVersionInfo_t: Record with elements
 *   u16_LssAppVersion of type uint16
 * ZfAppCameraState_t: Record with elements
 *   CameraState_u8 of type uint8
 *   Camera_SubState_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u8 of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrFS *Rte_Pim_ArrFrCmrFS(void)
 *
 *********************************************************************************************************************/


#define CpApZf_Core2_START_SEC_CODE
#include "CpApZf_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_FrCmrFS
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFS> of PortPrototype <PP_FrCmrFS>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZf_Core2_FrCmrFS(FailSafe_t *FrCmrFS)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFS_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_FrCmrFS_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApZf_Core2_CODE) Re_CpApZf_Core2_FrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FrCmrFS) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_FrCmrFS (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_FrCmrHdrFS
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFS> of PortPrototype <PP_FrCmrHdrFS>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZf_Core2_FrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFS_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_FrCmrHdrFS_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApZf_Core2_CODE) Re_CpApZf_Core2_FrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FrCmrHdrFS) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_FrCmrHdrFS (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core22Core1AppInfo_De_AppVersionInfo(const Core2AppVersionInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DawAppVersionInfo_AppVersionInfo(DawAppVersionInfo_t *DawAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaAppVersionInfo_AppVersionInfo(HbaAppVersionInfo_t *HbaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwAppVersionInfo_AppVersionInfo(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssAppVersionInfo_AppVersionInfo(LssAppVersionInfo_t *LssAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZf_Core2_CODE) Re_CpApZf_Core2_Init(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_Init
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(IsMsgVaildObjtAEBStatus_t *data)
 *   Std_ReturnType Rte_Read_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core22Core1AppInfo_De_AppVersionInfo(const Core2AppVersionInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Core2ZfAppCameraState_De_ZfAppCameraState(const ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Write_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DawAppVersionInfo_AppVersionInfo(DawAppVersionInfo_t *DawAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, uint8 *FS_Blur_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(uint16 *FS_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, uint8 *FS_C2C_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(uint8 *FS_C2W_OOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, uint32 *FS_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, uint8 *FS_Camera_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(uint8 *FS_Cameras_Number)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, uint8 *FS_Free_Sight)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, uint8 *FS_Frozen_Windshield_Lens)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(uint32 *FS_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(uint16 *FS_Impacted_Technologies)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, uint8 *FS_Low_Sun)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(uint8 *FS_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, uint8 *FS_Out_Of_Focus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(uint8 *FS_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(uint8 *FS_Rain)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, uint8 *FS_Splashes)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(uint8 *FS_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(uint8 *FS_TSR_Out_OF_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaAppVersionInfo_AppVersionInfo(HbaAppVersionInfo_t *HbaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwAppVersionInfo_AppVersionInfo(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IvcAppVersionInfo_AppVersionInfo(IvcAppVersionInfo_t *IvcAppVersionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IvcAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssAppVersionInfo_AppVersionInfo(LssAppVersionInfo_t *LssAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_Main_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApZf_Core2_CODE) Re_CpApZf_Core2_Main(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApZf_Core2_Main
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApZf_Core2_STOP_SEC_CODE
#include "CpApZf_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
