/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApUds_sid31.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUds_sid31
 *  Generation Time:  2023-04-20 13:52:53
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApUds_sid31> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPUDS_SID31_H
# define _RTE_CPAPUDS_SID31_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApUds_sid31_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApUds_sid31
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApUds_sid31, RTE_CONST, RTE_CONST) Rte_Inst_CpApUds_sid31; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApUds_sid31, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_LdwFuncTestSts_De_LdwFuncTestSts (0U)
# define Rte_InitValue_RP_Tac2FreshStart_De_Tac2FreshStart (FALSE)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApUds_sid31_RP_Tac2FreshStart_De_Tac2FreshStart(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUds_sid31_PP_LdwFuncTestSts_De_LdwFuncTestSts(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) faultStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ProcResults_pu8, P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode_pu16, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) EYEQCGetClearCalProcResults_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) EyeQStartClearingAllCamAlignCals_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Buffer(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Cam_Height); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Cam_Height_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Cam_Height_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Progress(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Cam_Height_Progress); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Cam_Height_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_Buffer(P2VAR(uint32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Header_Buffer); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pause_Reason(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pause_Reason); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Confidence(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Deg(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Deg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Progress(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Progress); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Px(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Px); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Pitch_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Roll); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Confidence(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Roll_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Roll_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Progress(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Roll_Progress); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Roll_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Run_Mode(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Run_Mode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Cam_Height_Dist); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Cam_Height_Time); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Pitch_Dist); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Time(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Pitch_Time); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Dist(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Roll_Dist); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Time(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Roll_Time); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Yaw_Dist); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Time(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Total_Yaw_Time); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Confidence(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Confidence); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Deg(P2VAR(float32, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Deg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Error(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Error); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Progress(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Progress); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Px(P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Px); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Status(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) CLB_DYN_Yaw_Status); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) EyeQSPTACStartCloseTargetAnalysisStatus_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis(P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) EyeQSPTACStartFarTargetAnalysisStatus_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode(uint8 VisionModeType_u8, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) Status_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) spcProcessStatus_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess(uint8 spcType_u8, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) startSPCProcess_pb, boolean freshStart_bo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ProcCmdResults_pu8, P2VAR(uint16, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode_pu16, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) SPTAC_EyeQSPTACProcStatus_pb); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUds_sid31_RP_TAC2_EYEQMESP_TO_APPL_EYEQMESP_StartTAC2ProcessReq(boolean freshStart_bo, P2VAR(boolean, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) startTAC2Process_pb, boolean disableNVMWrite_bo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Tac2FreshStart_De_Tac2FreshStart Rte_Read_CpApUds_sid31_RP_Tac2FreshStart_De_Tac2FreshStart


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_LdwFuncTestSts_De_LdwFuncTestSts Rte_Write_CpApUds_sid31_PP_LdwFuncTestSts_De_LdwFuncTestSts


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq Rte_Call_CpApUds_sid31_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq
# define Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus Rte_Call_CpApUds_sid31_RP_AppDiagFaultStatus_GetAppDiagFltStatus
# define Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApUds_sid31_RP_AppDiagFaultStatus_SetAppDiagFltStatus
# define Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults Rte_Call_CpApUds_sid31_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults
# define Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals Rte_Call_CpApUds_sid31_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Buffer Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Buffer
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_CRC Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_CRC
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Error Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Error
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Progress Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Progress
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Status Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Status
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_Buffer Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_Buffer
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_CRC Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_CRC
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pause_Reason Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pause_Reason
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Confidence Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Confidence
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Deg Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Deg
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Error Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Error
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Progress Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Progress
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Px Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Px
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Status Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Status
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Protocol_Version Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Protocol_Version
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Confidence Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Confidence
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Error Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Error
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Progress Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Progress
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Status Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Status
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Run_Mode Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Run_Mode
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Sync_ID Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Sync_ID
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Time Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Time
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Dist Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Dist
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Time Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Time
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Time Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Time
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Confidence Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Confidence
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Deg Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Deg
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Error Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Error
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Progress Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Progress
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Px Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Px
# define Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Status Rte_Call_CpApUds_sid31_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Status
# define Rte_Call_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis Rte_Call_CpApUds_sid31_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis
# define Rte_Call_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis Rte_Call_CpApUds_sid31_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis
# define Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApUds_sid31_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode Rte_Call_CpApUds_sid31_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode
# define Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus Rte_Call_CpApUds_sid31_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus
# define Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess Rte_Call_CpApUds_sid31_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess
# define Rte_Call_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus Rte_Call_CpApUds_sid31_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus
# define Rte_Call_RP_TAC2_EYEQMESP_TO_APPL_EYEQMESP_StartTAC2ProcessReq Rte_Call_CpApUds_sid31_RP_TAC2_EYEQMESP_TO_APPL_EYEQMESP_StartTAC2ProcessReq




# define CpApUds_sid31_START_SEC_CODE
# include "CpApUds_sid31_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_40ms
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid31_40ms CpApUds_sid31_40ms
FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_40ms(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid31_Init CpApUds_sid31_Init
FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUds_sid31_UpdateTAC2Status
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EYEQMESP_UpdateTAC2Status> of PortPrototype <PP_UpdateTAC2Status>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApUds_sid31_UpdateTAC2Status(uint8 status_u8)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUds_sid31_UpdateTAC2Status CpApUds_sid31_UpdateTAC2Status
FUNC(void, CpApUds_sid31_CODE) CpApUds_sid31_UpdateTAC2Status(uint8 status_u8); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Buffer(uint16 *CLB_DYN_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_CRC(uint32 *CLB_DYN_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height(uint16 *CLB_DYN_Cam_Height)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence(uint8 *CLB_DYN_Cam_Height_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Error(uint8 *CLB_DYN_Cam_Height_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Progress(uint8 *CLB_DYN_Cam_Height_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Cam_Height_Status(uint8 *CLB_DYN_Cam_Height_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_Buffer(uint32 *CLB_DYN_Header_Buffer)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Header_CRC(uint32 *CLB_DYN_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pause_Reason(uint8 *CLB_DYN_Pause_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Confidence(uint8 *CLB_DYN_Pitch_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Deg(float32 *CLB_DYN_Pitch_Deg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Error(uint8 *CLB_DYN_Pitch_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Progress(uint8 *CLB_DYN_Pitch_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Px(uint16 *CLB_DYN_Pitch_Px)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Pitch_Status(uint8 *CLB_DYN_Pitch_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Protocol_Version(uint8 *CLB_DYN_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll(float32 *CLB_DYN_Roll)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Confidence(uint8 *CLB_DYN_Roll_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Error(uint8 *CLB_DYN_Roll_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Progress(uint8 *CLB_DYN_Roll_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Roll_Status(uint8 *CLB_DYN_Roll_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Run_Mode(uint8 *CLB_DYN_Run_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Sync_ID(uint8 *CLB_DYN_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist(uint16 *CLB_DYN_Total_Cam_Height_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time(uint16 *CLB_DYN_Total_Cam_Height_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist(uint16 *CLB_DYN_Total_Pitch_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Pitch_Time(uint16 *CLB_DYN_Total_Pitch_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Dist(uint16 *CLB_DYN_Total_Roll_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Roll_Time(uint16 *CLB_DYN_Total_Roll_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist(uint16 *CLB_DYN_Total_Yaw_Dist)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Total_Yaw_Time(uint16 *CLB_DYN_Total_Yaw_Time)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Confidence(uint8 *CLB_DYN_Yaw_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Deg(float32 *CLB_DYN_Yaw_Deg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Error(uint8 *CLB_DYN_Yaw_Error)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Progress(uint8 *CLB_DYN_Yaw_Progress)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Px(uint16 *CLB_DYN_Yaw_Px)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQDG_CALDYN_EYEQDG_Get_CALDYN_CLB_DYN_Yaw_Status(uint8 *CLB_DYN_Yaw_Status)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDG_CALDYN_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus(uint8 *spcProcessStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_RequestResults(Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data15ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F001_SPC_Calibration_RequestResults Routine_F001_SPC_Calibration_RequestResults
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data15ByteType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess(uint8 spcType_u8, boolean *startSPCProcess_pb, boolean freshStart_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F001_SPC_Calibration_Start Routine_F001_SPC_Calibration_Start
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F001_SPC_Calibration_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F001_SPC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F001_SPC_Calibration_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F001_SPC_Calibration_Stop Routine_F001_SPC_Calibration_Stop
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F001_SPC_Calibration_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode(uint8 VisionModeType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQ_SwitchToVisionMode_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_RequestResults(Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data2ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F002_EOL_Calibration_TAC_RequestResults Routine_F002_EOL_Calibration_TAC_RequestResults
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_RequestResults(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data2ByteType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Tac2FreshStart_De_Tac2FreshStart(boolean *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis(boolean *EyeQSPTACStartCloseTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartCloseTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis(boolean *EyeQSPTACStartFarTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartFarTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQGetSPCProcStatus(uint8 *spcProcessStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPC_EYEQMESP_TO_APPL_EYEQMESP_EyeQStartSPCProcess(uint8 spcType_u8, boolean *startSPCProcess_pb, boolean freshStart_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus(uint8 *ProcCmdResults_pu8, uint16 *ErrorCode_pu16, boolean *SPTAC_EyeQSPTACProcStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPTAC_EyeQGetSPTACProcStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_TAC2_EYEQMESP_TO_APPL_EYEQMESP_StartTAC2ProcessReq(boolean freshStart_bo, boolean *startTAC2Process_pb, boolean disableNVMWrite_bo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_TAC2_EYEQMESP_TO_APPL_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F002_EOL_Calibration_TAC_Start Routine_F002_EOL_Calibration_TAC_Start
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F002_EOL_Calibration_TAC_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F002_EOL_Calibration_TAC>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F002_EOL_Calibration_TAC_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F002_EOL_Calibration_TAC_Stop Routine_F002_EOL_Calibration_TAC_Stop
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F002_EOL_Calibration_TAC_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_RequestResults
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <RequestResults> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQ_SwitchToVisionMode_EyeQ_SwitchToVisionMode(uint8 VisionModeType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQ_SwitchToVisionMode_ReturnType
 *   Std_ReturnType Rte_Call_RP_SPTAC_EyeQGetSPTACProcStatus_SPTAC_EyeQGetSPTACProcStatus(uint8 *ProcCmdResults_pu8, uint16 *ErrorCode_pu16, boolean *SPTAC_EyeQSPTACProcStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SPTAC_EyeQGetSPTACProcStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_RequestResults(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument ResData: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F003_SPTAC_Calibration_RequestResults Routine_F003_SPTAC_Calibration_RequestResults
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_RequestResults(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_RequestResults(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data3ByteType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PP_EYEQDS_ClearFSReq_EYEQDS_ClearFSReq(uint8 ClrType_u8, boolean *Status_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQDS_ClearFSReq_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_GetClearCalProcResults_EYEQC_GetClearCalProcResults(uint8 *ProcResults_pu8, uint16 *ErrorCode_pu16, boolean *EYEQCGetClearCalProcResults_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQC_StartClearingAllCamAlignCals_EYEQC_StartClearingAllCamAlignCals(boolean *EyeQStartClearingAllCamAlignCals_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartCloseTargetAnalysis_EYEQSPTAC_EyeQStartCloseTargetAnalysis(boolean *EyeQSPTACStartCloseTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartCloseTargetAnalysis_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQSPTAC_EyeQStartFarTargetAnalysis_EYEQSPTAC_EyeQStartFarTargetAnalysis(boolean *EyeQSPTACStartFarTargetAnalysisStatus_pb)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQSPTAC_EyeQStartFarTargetAnalysis_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_Start(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F003_SPTAC_Calibration_Start Routine_F003_SPTAC_Calibration_Start
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_Start(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F003_SPTAC_Calibration_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F003_SPTAC_Calibration>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F003_SPTAC_Calibration_Stop(uint8 ReqData, Dcm_OpStatusType OpStatus, uint8 *ResData, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F003_SPTAC_Calibration_Stop Routine_F003_SPTAC_Calibration_Stop
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F003_SPTAC_Calibration_Stop(uint8 ReqData, Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ResData, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F004_LDW_Function_Validation_on_EOL_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LdwFuncTestSts_De_LdwFuncTestSts(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F004_LDW_Function_Validation_on_EOL_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F004_LDW_Function_Validation_on_EOL_Start Routine_F004_LDW_Function_Validation_on_EOL_Start
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F004_LDW_Function_Validation_on_EOL_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F004_LDW_Function_Validation_on_EOL_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LdwFuncTestSts_De_LdwFuncTestSts(uint8 data)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F004_LDW_Function_Validation_on_EOL_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F004_LDW_Function_Validation_on_EOL_Stop Routine_F004_LDW_Function_Validation_on_EOL_Stop
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F004_LDW_Function_Validation_on_EOL_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F005_HBA_Regulation_Test_Procedure_Start
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Start> of PortPrototype <RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F005_HBA_Regulation_Test_Procedure_Start(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F005_HBA_Regulation_Test_Procedure_Start Routine_F005_HBA_Regulation_Test_Procedure_Start
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F005_HBA_Regulation_Test_Procedure_Start(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Routine_F005_HBA_Regulation_Test_Procedure_Stop
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <Stop> of PortPrototype <RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Routine_F005_HBA_Regulation_Test_Procedure_Stop(Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_FORCE_RCRRP
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_PENDING
 *   RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Routine_F005_HBA_Regulation_Test_Procedure_Stop Routine_F005_HBA_Regulation_Test_Procedure_Stop
FUNC(Std_ReturnType, CpApUds_sid31_CODE) Routine_F005_HBA_Regulation_Test_Procedure_Stop(Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDS_SID31_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApUds_sid31_STOP_SEC_CODE
# include "CpApUds_sid31_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_AppDiagFaultStatus_ReturnType (1U)

# define RTE_E_IF_EYEQC_GetClearCalProcResults_ReturnType (1U)

# define RTE_E_IF_EYEQC_StartClearingAllCamAlignCals_ReturnType (1U)

# define RTE_E_IF_EYEQDG_CALDYN_ReturnType (1U)

# define RTE_E_IF_EYEQDS_ClearFSReq_ReturnType (1U)

# define RTE_E_IF_EYEQSPTAC_EyeQStartCloseTargetAnalysis_ReturnType (1U)

# define RTE_E_IF_EYEQSPTAC_EyeQStartFarTargetAnalysis_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore1_APP_ReturnType (1U)

# define RTE_E_IF_EyeQ_SwitchToVisionMode_ReturnType (1U)

# define RTE_E_IF_SPC_EYEQMESP_TO_APPL_ReturnType (1U)

# define RTE_E_IF_SPTAC_EyeQGetSPTACProcStatus_ReturnType (1U)

# define RTE_E_IF_TAC2_EYEQMESP_TO_APPL_ReturnType (1U)

# define RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_FORCE_RCRRP (12U)

# define RTE_E_RoutineServices_Routine_F001_SPC_Calibration_DCM_E_PENDING (10U)

# define RTE_E_RoutineServices_Routine_F001_SPC_Calibration_E_NOT_OK (1U)

# define RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_FORCE_RCRRP (12U)

# define RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_DCM_E_PENDING (10U)

# define RTE_E_RoutineServices_Routine_F002_EOL_Calibration_TAC_E_NOT_OK (1U)

# define RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_FORCE_RCRRP (12U)

# define RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_DCM_E_PENDING (10U)

# define RTE_E_RoutineServices_Routine_F003_SPTAC_Calibration_E_NOT_OK (1U)

# define RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_FORCE_RCRRP (12U)

# define RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_DCM_E_PENDING (10U)

# define RTE_E_RoutineServices_Routine_F004_LDW_Function_Validation_on_EOL_E_NOT_OK (1U)

# define RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_FORCE_RCRRP (12U)

# define RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_DCM_E_PENDING (10U)

# define RTE_E_RoutineServices_Routine_F005_HBA_Regulation_Test_Procedure_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPUDS_SID31_H */
