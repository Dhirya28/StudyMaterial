/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApHbaIntf.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApHbaIntf
 *  Generation Time:  2023-04-20 13:53:22
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApHbaIntf>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * NvM_RequestResultType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApHbaIntf.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * dtRef_VOID: DataReference
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint64: Integer in interval [0...18446744073709551615] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * NvM_RequestResultType: Enumeration of integer in interval [0...8] with enumerators
 *   NVM_REQ_OK (0U)
 *   NVM_REQ_NOT_OK (1U)
 *   NVM_REQ_PENDING (2U)
 *   NVM_REQ_INTEGRITY_FAILED (3U)
 *   NVM_REQ_BLOCK_SKIPPED (4U)
 *   NVM_REQ_NV_INVALIDATED (5U)
 *   NVM_REQ_CANCELED (6U)
 *   NVM_REQ_REDUNDANCY_FAILED (7U)
 *   NVM_REQ_RESTORED_FROM_ROM (8U)
 *
 * Record Types:
 * =============
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * HbaFrqNvData_t: Record with elements
 *   u8_HBA_OnOff of type uint8
 *   u8_Blockage_Full_Status of type uint8
 *   u8_Blockage_Partial_Status of type uint8
 *   u8_Blockage_LowVisibility_Status of type uint8
 *   u8_ProfileVal_Guest of type uint8
 *   u8_ProfileVal_User1 of type uint8
 *   u8_ProfileVal_User2 of type uint8
 *   u8_ProfileVal_User3 of type uint8
 *   u8_ProfileVal_User4 of type uint8
 *   u8_ProfileVal_User5 of type uint8
 *   u8_ProfileVal_User6 of type uint8
 *   u8_ProfileVal_User7 of type uint8
 *   u8_ProfileVal_User8 of type uint8
 *   u8_ProfileVal_User9 of type uint8
 *   u8_Profile_LastUser of type uint8
 *   Reserved1 of type uint8
 * HbaInput_t: Record with elements
 *   u8_HLB_Inactive_Reason of type uint8
 *   u32_HLB_Reason of type uint32
 *   u8_HLB_Decision of type uint8
 *   u8_HLB_Running_Mode of type uint8
 * HbaOccNvData_t: Record with elements
 *   u16_HBA_MIDDLE_EAST_OFF_DIST of type uint16
 *   u16_HBA_MIDDLE_EAST_ON_DELAY_TIME of type uint16
 *   u16_Cam_Blockage_Time of type uint16
 *   u8_HBA_START_VS of type uint8
 *   u8_HBA_END_VS of type uint8
 *   u8_HBA_START_VS_US of type uint8
 *   u8_HBA_END_VS_US of type uint8
 *   u8_HBA_START_VS_LIMIT of type uint8
 *   u8_HBA_END_VS_LIMIT of type uint8
 *   u8_HBA_START_VS_LIMIT_US of type uint8
 *   u8_HBA_END_VS_LIMIT_US of type uint8
 *   Reserved1 of type uint8
 *   Reserved2 of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   HbaFrqNvData_t *Rte_Pim_HbaFrqNvData(void)
 *   HbaOccNvData_t *Rte_Pim_HbaOccNvData(void)
 *
 *********************************************************************************************************************/


#define CpApHbaIntf_START_SEC_CODE
#include "CpApHbaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApHbaIntf_CODE) CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApHbaIntf_NvMNotifyJobFinished_HbaFrqNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApHbaIntf_CODE) CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished(NvM_RequestResultType JobResult) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CpApHbaIntf_NvMNotifyJobFinished_HbaOccNvData_JobFinished
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfEyeQRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_RxMsgsInFrame(uint64 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_HbaInput_De_HbaInput(const HbaInput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Brightness_Score(float32 *HLB_Brightness_Score)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Decision(uint8 *HLB_Decision)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Inactive_Reason(uint8 *HLB_Inactive_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Protocol_Version(uint8 *HLB_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Reason(uint32 *HLB_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Running_Mode(uint8 *HLB_Running_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_HLB_EYEQDG_Get_HLB_HLB_Sync_ID(uint8 *HLB_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_HLB_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Left(uint16 Index, uint16 *LSV_Angular_Velocity_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Angular_Velocity_Right(uint16 Index, uint16 *LSV_Angular_Velocity_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_H(uint16 Index, uint16 *LSV_Atten_Cent_Angle_H)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Atten_Cent_Angle_Lat(uint16 Index, uint16 *LSV_Atten_Cent_Angle_Lat)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Bottom_Angle(uint16 Index, uint16 *LSV_Bottom_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness(uint16 Index, uint32 *LSV_Brightness)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Brightness_Score(float32 *LSV_Brightness_Score)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Left(uint16 Index, uint16 *LSV_CL_Distance_Left)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Distance_Right(uint16 Index, uint16 *LSV_CL_Distance_Right)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_CL_Sub_Type(uint16 Index, uint8 *LSV_CL_Sub_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Confidence(uint16 Index, uint8 *LSV_Confidence)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Consecutive_Detection(uint16 Index, uint8 *LSV_Consecutive_Detection)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance(uint16 Index, uint16 *LSV_Distance)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Distance_STD(uint16 Index, uint8 *LSV_Distance_STD)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Decision(uint8 *LSV_HLB_Decision)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_HLB_Reason(uint32 *LSV_HLB_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_ID(uint16 Index, uint8 *LSV_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Inactive_Reason(uint8 *LSV_Inactive_Reason)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Is_New(uint16 Index, uint8 *LSV_Is_New)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Left_Angle(uint16 Index, uint16 *LSV_Left_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Protocol_Version(uint8 *LSV_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Right_Angle(uint16 Index, uint16 *LSV_Right_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Running_Mode(uint8 *LSV_Running_Mode)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sub_Type(uint16 Index, uint16 *LSV_Sub_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Sync_ID(uint8 *LSV_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Top_Angle(uint16 Index, uint16 *LSV_Top_Angle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Type(uint16 Index, uint8 *LSV_Type)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_VD_ID(uint16 Index, uint16 *LSV_VD_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_LSCVC_EYEQDG_Get_LSCVC_LSV_Vehicles_Count(uint8 *LSV_Vehicles_Count)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_LSCVC_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfEyeQRead_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfEyeQRead(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfEyeQRead
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_HbaOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApHbaIntf_CODE) Re_CpApHbaIntfMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaIntfMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaReadHbaFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaFrqNvDataRead> of PortPrototype <PP_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaReadHbaFrqNvData(HbaFrqNvData_t *HbaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaReadHbaFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaReadHbaFrqNvData(P2VAR(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HbaFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaReadHbaFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaReadHbaOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaOccNvDataRead> of PortPrototype <PP_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaReadHbaOccNvData(HbaOccNvData_t *HbaOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaOccNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaReadHbaOccNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaReadHbaOccNvData(P2VAR(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_VAR) HbaOccNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaReadHbaOccNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaWriteHbaFrqNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaFrqNvDataWrite> of PortPrototype <PP_HbaFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaWriteHbaFrqNvData(const HbaFrqNvData_t *HbaFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaWriteHbaFrqNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaWriteHbaFrqNvData(P2CONST(HbaFrqNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_DATA) HbaFrqNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaWriteHbaFrqNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApHbaWriteHbaOccNvData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <HbaOccNvDataWrite> of PortPrototype <PP_HbaOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApHbaWriteHbaOccNvData(const HbaOccNvData_t *HbaOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_HbaOccNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaWriteHbaOccNvData_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApHbaIntf_CODE) Re_CpApHbaWriteHbaOccNvData(P2CONST(HbaOccNvData_t, AUTOMATIC, RTE_CPAPHBAINTF_APPL_DATA) HbaOccNvData) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApHbaWriteHbaOccNvData (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApHbaIntf_STOP_SEC_CODE
#include "CpApHbaIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApHbaIntfHbaInfo_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApHbaIntfOut_doc)  *******************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApHbaIntfHbaInfo)  **************************/

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApHbaIntfOut)  ******************************/


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
