/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApEyeQSim.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApEyeQSim
 *  Generation Time:  2023-04-20 13:52:28
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApEyeQSim> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPEYEQSIM_H
# define _RTE_CPAPEYEQSIM_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApEyeQSim_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApEyeQSim
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApEyeQSim, RTE_CONST, RTE_CONST) Rte_Inst_CpApEyeQSim; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApEyeQSim, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn01_SignalGroup_COM_SG_RxDbgDataIn01_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn01_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn02_SignalGroup_COM_SG_RxDbgDataIn02_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn02_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn03_SignalGroup_COM_SG_RxDbgDataIn03_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn03_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn04_SignalGroup_COM_SG_RxDbgDataIn04_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn04_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn05_SignalGroup_COM_SG_RxDbgDataIn05_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn05_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn06_SignalGroup_COM_SG_RxDbgDataIn06_SignalGroup(P2VAR(COM_DT_SG_RxDbgDataIn06_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput01_De_DawLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput02_De_DawLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput03_De_DawLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput04_De_DawLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput05_De_DawLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput06_De_DawLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput07_De_DawLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput08_De_DawLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput09_De_DawLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput10_De_DawLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput11_De_DawLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput12_De_DawLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput13_De_DawLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput14_De_DawLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput15_De_DawLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput16_De_DawLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput17_De_DawLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput18_De_DawLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput19_De_DawLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput20_De_DawLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput01_De_SccLogicDbgOutput01(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput02_De_SccLogicDbgOutput02(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput03_De_SccLogicDbgOutput03(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput04_De_SccLogicDbgOutput04(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput05_De_SccLogicDbgOutput05(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput06_De_SccLogicDbgOutput06(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput07_De_SccLogicDbgOutput07(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput08_De_SccLogicDbgOutput08(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput09_De_SccLogicDbgOutput09(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput10_De_SccLogicDbgOutput10(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput11_De_SccLogicDbgOutput11(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput12_De_SccLogicDbgOutput12(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput13_De_SccLogicDbgOutput13(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput14_De_SccLogicDbgOutput14(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput15_De_SccLogicDbgOutput15(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput16_De_SccLogicDbgOutput16(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput17_De_SccLogicDbgOutput17(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput18_De_SccLogicDbgOutput18(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput19_De_SccLogicDbgOutput19(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput20_De_SccLogicDbgOutput20(P2VAR(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_01_SignalGroup_COM_SG_TxDbgDataOut_01_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_01_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_02_SignalGroup_COM_SG_TxDbgDataOut_02_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_02_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_03_SignalGroup_COM_SG_TxDbgDataOut_03_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_03_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_04_SignalGroup_COM_SG_TxDbgDataOut_04_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_04_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_05_SignalGroup_COM_SG_TxDbgDataOut_05_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_05_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_06_SignalGroup_COM_SG_TxDbgDataOut_06_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_06_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_07_SignalGroup_COM_SG_TxDbgDataOut_07_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_07_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_08_SignalGroup_COM_SG_TxDbgDataOut_08_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_08_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_09_SignalGroup_COM_SG_TxDbgDataOut_09_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_09_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_10_SignalGroup_COM_SG_TxDbgDataOut_10_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_10_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_11_SignalGroup_COM_SG_TxDbgDataOut_11_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_11_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_12_SignalGroup_COM_SG_TxDbgDataOut_12_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_12_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_13_SignalGroup_COM_SG_TxDbgDataOut_13_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_13_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_14_SignalGroup_COM_SG_TxDbgDataOut_14_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_14_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_15_SignalGroup_COM_SG_TxDbgDataOut_15_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_15_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_16_SignalGroup_COM_SG_TxDbgDataOut_16_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_16_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_17_SignalGroup_COM_SG_TxDbgDataOut_17_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_17_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_18Signal_Group_COM_SG_TxDbgDataOut_18Signal_Group(P2CONST(COM_DT_SG_TxDbgDataOut_18Signal_Group, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_19_SignalGroup_COM_SG_TxDbgDataOut_19_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_19_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_20_SignalGroup_COM_SG_TxDbgDataOut_20_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_20_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_21_SignalGroup_COM_SG_TxDbgDataOut_21_SignalGroup(P2CONST(COM_DT_SG_TxDbgDataOut_21_SignalGroup, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn01_De_CoFcaDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn02_De_CoFcaDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn03_De_CoFcaDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn04_De_CoFcaDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn05_De_CoFcaDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn06_De_CoFcaDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn01_De_DawDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn02_De_DawDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn03_De_DawDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn04_De_DawDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn05_De_DawDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_DawDbgIn06_De_DawDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn01_De_FcaDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn02_De_FcaDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn03_De_FcaDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn04_De_FcaDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn05_De_FcaDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_FcaDbgIn06_De_FcaDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn01_De_HbaDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn02_De_HbaDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn03_De_HbaDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn04_De_HbaDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn05_De_HbaDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_HbaDbgIn06_De_HbaDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn01_De_IslwDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn02_De_IslwDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn03_De_IslwDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn04_De_IslwDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn05_De_IslwDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IslwDbgIn06_De_IslwDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn01_De_IvcDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn02_De_IvcDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn03_De_IvcDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn04_De_IvcDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn05_De_IvcDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_IvcDbgIn06_De_IvcDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn01_De_LssDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn02_De_LssDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn03_De_LssDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn04_De_LssDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn05_De_LssDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_LssDbgIn06_De_LssDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn01_De_SccDbgIn01(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn02_De_SccDbgIn02(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn03_De_SccDbgIn03(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn04_De_SccDbgIn04(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn05_De_SccDbgIn05(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApEyeQSim_PP_SccDbgIn06_De_SccDbgIn06(P2CONST(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApEyeQSim_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPEYEQSIM_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_COM_SG_RxDbgDataIn01_SignalGroup_COM_SG_RxDbgDataIn01_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn01_SignalGroup_COM_SG_RxDbgDataIn01_SignalGroup
# define Rte_Read_COM_SG_RxDbgDataIn02_SignalGroup_COM_SG_RxDbgDataIn02_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn02_SignalGroup_COM_SG_RxDbgDataIn02_SignalGroup
# define Rte_Read_COM_SG_RxDbgDataIn03_SignalGroup_COM_SG_RxDbgDataIn03_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn03_SignalGroup_COM_SG_RxDbgDataIn03_SignalGroup
# define Rte_Read_COM_SG_RxDbgDataIn04_SignalGroup_COM_SG_RxDbgDataIn04_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn04_SignalGroup_COM_SG_RxDbgDataIn04_SignalGroup
# define Rte_Read_COM_SG_RxDbgDataIn05_SignalGroup_COM_SG_RxDbgDataIn05_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn05_SignalGroup_COM_SG_RxDbgDataIn05_SignalGroup
# define Rte_Read_COM_SG_RxDbgDataIn06_SignalGroup_COM_SG_RxDbgDataIn06_SignalGroup Rte_Read_CpApEyeQSim_COM_SG_RxDbgDataIn06_SignalGroup_COM_SG_RxDbgDataIn06_SignalGroup
# define Rte_Read_RP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01
# define Rte_Read_RP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02
# define Rte_Read_RP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03
# define Rte_Read_RP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04
# define Rte_Read_RP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05
# define Rte_Read_RP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06
# define Rte_Read_RP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07
# define Rte_Read_RP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08
# define Rte_Read_RP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09
# define Rte_Read_RP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10
# define Rte_Read_RP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11
# define Rte_Read_RP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12
# define Rte_Read_RP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13
# define Rte_Read_RP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14
# define Rte_Read_RP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15
# define Rte_Read_RP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16
# define Rte_Read_RP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17
# define Rte_Read_RP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18
# define Rte_Read_RP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19
# define Rte_Read_RP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20
# define Rte_Read_RP_DawLogicDbgOutput01_De_DawLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput01_De_DawLogicDbgOutput01
# define Rte_Read_RP_DawLogicDbgOutput02_De_DawLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput02_De_DawLogicDbgOutput02
# define Rte_Read_RP_DawLogicDbgOutput03_De_DawLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput03_De_DawLogicDbgOutput03
# define Rte_Read_RP_DawLogicDbgOutput04_De_DawLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput04_De_DawLogicDbgOutput04
# define Rte_Read_RP_DawLogicDbgOutput05_De_DawLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput05_De_DawLogicDbgOutput05
# define Rte_Read_RP_DawLogicDbgOutput06_De_DawLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput06_De_DawLogicDbgOutput06
# define Rte_Read_RP_DawLogicDbgOutput07_De_DawLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput07_De_DawLogicDbgOutput07
# define Rte_Read_RP_DawLogicDbgOutput08_De_DawLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput08_De_DawLogicDbgOutput08
# define Rte_Read_RP_DawLogicDbgOutput09_De_DawLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput09_De_DawLogicDbgOutput09
# define Rte_Read_RP_DawLogicDbgOutput10_De_DawLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput10_De_DawLogicDbgOutput10
# define Rte_Read_RP_DawLogicDbgOutput11_De_DawLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput11_De_DawLogicDbgOutput11
# define Rte_Read_RP_DawLogicDbgOutput12_De_DawLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput12_De_DawLogicDbgOutput12
# define Rte_Read_RP_DawLogicDbgOutput13_De_DawLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput13_De_DawLogicDbgOutput13
# define Rte_Read_RP_DawLogicDbgOutput14_De_DawLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput14_De_DawLogicDbgOutput14
# define Rte_Read_RP_DawLogicDbgOutput15_De_DawLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput15_De_DawLogicDbgOutput15
# define Rte_Read_RP_DawLogicDbgOutput16_De_DawLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput16_De_DawLogicDbgOutput16
# define Rte_Read_RP_DawLogicDbgOutput17_De_DawLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput17_De_DawLogicDbgOutput17
# define Rte_Read_RP_DawLogicDbgOutput18_De_DawLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput18_De_DawLogicDbgOutput18
# define Rte_Read_RP_DawLogicDbgOutput19_De_DawLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput19_De_DawLogicDbgOutput19
# define Rte_Read_RP_DawLogicDbgOutput20_De_DawLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_DawLogicDbgOutput20_De_DawLogicDbgOutput20
# define Rte_Read_RP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01
# define Rte_Read_RP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02
# define Rte_Read_RP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03
# define Rte_Read_RP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04
# define Rte_Read_RP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05
# define Rte_Read_RP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06
# define Rte_Read_RP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07
# define Rte_Read_RP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08
# define Rte_Read_RP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09
# define Rte_Read_RP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10
# define Rte_Read_RP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11
# define Rte_Read_RP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12
# define Rte_Read_RP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13
# define Rte_Read_RP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14
# define Rte_Read_RP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15
# define Rte_Read_RP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16
# define Rte_Read_RP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17
# define Rte_Read_RP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18
# define Rte_Read_RP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19
# define Rte_Read_RP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20
# define Rte_Read_RP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01
# define Rte_Read_RP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02
# define Rte_Read_RP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03
# define Rte_Read_RP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04
# define Rte_Read_RP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05
# define Rte_Read_RP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06
# define Rte_Read_RP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07
# define Rte_Read_RP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08
# define Rte_Read_RP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09
# define Rte_Read_RP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10
# define Rte_Read_RP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11
# define Rte_Read_RP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12
# define Rte_Read_RP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13
# define Rte_Read_RP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14
# define Rte_Read_RP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15
# define Rte_Read_RP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16
# define Rte_Read_RP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17
# define Rte_Read_RP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18
# define Rte_Read_RP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19
# define Rte_Read_RP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20
# define Rte_Read_RP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01
# define Rte_Read_RP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02
# define Rte_Read_RP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03
# define Rte_Read_RP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04
# define Rte_Read_RP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05
# define Rte_Read_RP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06
# define Rte_Read_RP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07
# define Rte_Read_RP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08
# define Rte_Read_RP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09
# define Rte_Read_RP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10
# define Rte_Read_RP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11
# define Rte_Read_RP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12
# define Rte_Read_RP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13
# define Rte_Read_RP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14
# define Rte_Read_RP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15
# define Rte_Read_RP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16
# define Rte_Read_RP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17
# define Rte_Read_RP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18
# define Rte_Read_RP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19
# define Rte_Read_RP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20
# define Rte_Read_RP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01
# define Rte_Read_RP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02
# define Rte_Read_RP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03
# define Rte_Read_RP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04
# define Rte_Read_RP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05
# define Rte_Read_RP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06
# define Rte_Read_RP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07
# define Rte_Read_RP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08
# define Rte_Read_RP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09
# define Rte_Read_RP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10
# define Rte_Read_RP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11
# define Rte_Read_RP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12
# define Rte_Read_RP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13
# define Rte_Read_RP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14
# define Rte_Read_RP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15
# define Rte_Read_RP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16
# define Rte_Read_RP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17
# define Rte_Read_RP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18
# define Rte_Read_RP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19
# define Rte_Read_RP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20
# define Rte_Read_RP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21 Rte_Read_CpApEyeQSim_RP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21
# define Rte_Read_RP_LssLogicDbgOutput01_De_LssLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput01_De_LssLogicDbgOutput01
# define Rte_Read_RP_LssLogicDbgOutput02_De_LssLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput02_De_LssLogicDbgOutput02
# define Rte_Read_RP_LssLogicDbgOutput03_De_LssLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput03_De_LssLogicDbgOutput03
# define Rte_Read_RP_LssLogicDbgOutput04_De_LssLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput04_De_LssLogicDbgOutput04
# define Rte_Read_RP_LssLogicDbgOutput05_De_LssLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput05_De_LssLogicDbgOutput05
# define Rte_Read_RP_LssLogicDbgOutput06_De_LssLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput06_De_LssLogicDbgOutput06
# define Rte_Read_RP_LssLogicDbgOutput07_De_LssLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput07_De_LssLogicDbgOutput07
# define Rte_Read_RP_LssLogicDbgOutput08_De_LssLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput08_De_LssLogicDbgOutput08
# define Rte_Read_RP_LssLogicDbgOutput09_De_LssLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput09_De_LssLogicDbgOutput09
# define Rte_Read_RP_LssLogicDbgOutput10_De_LssLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput10_De_LssLogicDbgOutput10
# define Rte_Read_RP_LssLogicDbgOutput11_De_LssLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput11_De_LssLogicDbgOutput11
# define Rte_Read_RP_LssLogicDbgOutput12_De_LssLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput12_De_LssLogicDbgOutput12
# define Rte_Read_RP_LssLogicDbgOutput13_De_LssLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput13_De_LssLogicDbgOutput13
# define Rte_Read_RP_LssLogicDbgOutput14_De_LssLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput14_De_LssLogicDbgOutput14
# define Rte_Read_RP_LssLogicDbgOutput15_De_LssLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput15_De_LssLogicDbgOutput15
# define Rte_Read_RP_LssLogicDbgOutput16_De_LssLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput16_De_LssLogicDbgOutput16
# define Rte_Read_RP_LssLogicDbgOutput17_De_LssLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput17_De_LssLogicDbgOutput17
# define Rte_Read_RP_LssLogicDbgOutput18_De_LssLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput18_De_LssLogicDbgOutput18
# define Rte_Read_RP_LssLogicDbgOutput19_De_LssLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput19_De_LssLogicDbgOutput19
# define Rte_Read_RP_LssLogicDbgOutput20_De_LssLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_LssLogicDbgOutput20_De_LssLogicDbgOutput20
# define Rte_Read_RP_SccLogicDbgOutput01_De_SccLogicDbgOutput01 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput01_De_SccLogicDbgOutput01
# define Rte_Read_RP_SccLogicDbgOutput02_De_SccLogicDbgOutput02 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput02_De_SccLogicDbgOutput02
# define Rte_Read_RP_SccLogicDbgOutput03_De_SccLogicDbgOutput03 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput03_De_SccLogicDbgOutput03
# define Rte_Read_RP_SccLogicDbgOutput04_De_SccLogicDbgOutput04 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput04_De_SccLogicDbgOutput04
# define Rte_Read_RP_SccLogicDbgOutput05_De_SccLogicDbgOutput05 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput05_De_SccLogicDbgOutput05
# define Rte_Read_RP_SccLogicDbgOutput06_De_SccLogicDbgOutput06 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput06_De_SccLogicDbgOutput06
# define Rte_Read_RP_SccLogicDbgOutput07_De_SccLogicDbgOutput07 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput07_De_SccLogicDbgOutput07
# define Rte_Read_RP_SccLogicDbgOutput08_De_SccLogicDbgOutput08 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput08_De_SccLogicDbgOutput08
# define Rte_Read_RP_SccLogicDbgOutput09_De_SccLogicDbgOutput09 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput09_De_SccLogicDbgOutput09
# define Rte_Read_RP_SccLogicDbgOutput10_De_SccLogicDbgOutput10 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput10_De_SccLogicDbgOutput10
# define Rte_Read_RP_SccLogicDbgOutput11_De_SccLogicDbgOutput11 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput11_De_SccLogicDbgOutput11
# define Rte_Read_RP_SccLogicDbgOutput12_De_SccLogicDbgOutput12 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput12_De_SccLogicDbgOutput12
# define Rte_Read_RP_SccLogicDbgOutput13_De_SccLogicDbgOutput13 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput13_De_SccLogicDbgOutput13
# define Rte_Read_RP_SccLogicDbgOutput14_De_SccLogicDbgOutput14 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput14_De_SccLogicDbgOutput14
# define Rte_Read_RP_SccLogicDbgOutput15_De_SccLogicDbgOutput15 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput15_De_SccLogicDbgOutput15
# define Rte_Read_RP_SccLogicDbgOutput16_De_SccLogicDbgOutput16 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput16_De_SccLogicDbgOutput16
# define Rte_Read_RP_SccLogicDbgOutput17_De_SccLogicDbgOutput17 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput17_De_SccLogicDbgOutput17
# define Rte_Read_RP_SccLogicDbgOutput18_De_SccLogicDbgOutput18 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput18_De_SccLogicDbgOutput18
# define Rte_Read_RP_SccLogicDbgOutput19_De_SccLogicDbgOutput19 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput19_De_SccLogicDbgOutput19
# define Rte_Read_RP_SccLogicDbgOutput20_De_SccLogicDbgOutput20 Rte_Read_CpApEyeQSim_RP_SccLogicDbgOutput20_De_SccLogicDbgOutput20


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_COM_SG_TxDbgDataOut_01_SignalGroup_COM_SG_TxDbgDataOut_01_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_01_SignalGroup_COM_SG_TxDbgDataOut_01_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_02_SignalGroup_COM_SG_TxDbgDataOut_02_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_02_SignalGroup_COM_SG_TxDbgDataOut_02_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_03_SignalGroup_COM_SG_TxDbgDataOut_03_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_03_SignalGroup_COM_SG_TxDbgDataOut_03_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_04_SignalGroup_COM_SG_TxDbgDataOut_04_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_04_SignalGroup_COM_SG_TxDbgDataOut_04_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_05_SignalGroup_COM_SG_TxDbgDataOut_05_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_05_SignalGroup_COM_SG_TxDbgDataOut_05_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_06_SignalGroup_COM_SG_TxDbgDataOut_06_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_06_SignalGroup_COM_SG_TxDbgDataOut_06_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_07_SignalGroup_COM_SG_TxDbgDataOut_07_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_07_SignalGroup_COM_SG_TxDbgDataOut_07_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_08_SignalGroup_COM_SG_TxDbgDataOut_08_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_08_SignalGroup_COM_SG_TxDbgDataOut_08_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_09_SignalGroup_COM_SG_TxDbgDataOut_09_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_09_SignalGroup_COM_SG_TxDbgDataOut_09_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_10_SignalGroup_COM_SG_TxDbgDataOut_10_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_10_SignalGroup_COM_SG_TxDbgDataOut_10_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_11_SignalGroup_COM_SG_TxDbgDataOut_11_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_11_SignalGroup_COM_SG_TxDbgDataOut_11_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_12_SignalGroup_COM_SG_TxDbgDataOut_12_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_12_SignalGroup_COM_SG_TxDbgDataOut_12_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_13_SignalGroup_COM_SG_TxDbgDataOut_13_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_13_SignalGroup_COM_SG_TxDbgDataOut_13_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_14_SignalGroup_COM_SG_TxDbgDataOut_14_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_14_SignalGroup_COM_SG_TxDbgDataOut_14_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_15_SignalGroup_COM_SG_TxDbgDataOut_15_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_15_SignalGroup_COM_SG_TxDbgDataOut_15_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_16_SignalGroup_COM_SG_TxDbgDataOut_16_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_16_SignalGroup_COM_SG_TxDbgDataOut_16_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_17_SignalGroup_COM_SG_TxDbgDataOut_17_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_17_SignalGroup_COM_SG_TxDbgDataOut_17_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_18Signal_Group_COM_SG_TxDbgDataOut_18Signal_Group Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_18Signal_Group_COM_SG_TxDbgDataOut_18Signal_Group
# define Rte_Write_COM_SG_TxDbgDataOut_19_SignalGroup_COM_SG_TxDbgDataOut_19_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_19_SignalGroup_COM_SG_TxDbgDataOut_19_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_20_SignalGroup_COM_SG_TxDbgDataOut_20_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_20_SignalGroup_COM_SG_TxDbgDataOut_20_SignalGroup
# define Rte_Write_COM_SG_TxDbgDataOut_21_SignalGroup_COM_SG_TxDbgDataOut_21_SignalGroup Rte_Write_CpApEyeQSim_COM_SG_TxDbgDataOut_21_SignalGroup_COM_SG_TxDbgDataOut_21_SignalGroup
# define Rte_Write_PP_CoFcaDbgIn01_De_CoFcaDbgIn01 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn01_De_CoFcaDbgIn01
# define Rte_Write_PP_CoFcaDbgIn02_De_CoFcaDbgIn02 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn02_De_CoFcaDbgIn02
# define Rte_Write_PP_CoFcaDbgIn03_De_CoFcaDbgIn03 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn03_De_CoFcaDbgIn03
# define Rte_Write_PP_CoFcaDbgIn04_De_CoFcaDbgIn04 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn04_De_CoFcaDbgIn04
# define Rte_Write_PP_CoFcaDbgIn05_De_CoFcaDbgIn05 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn05_De_CoFcaDbgIn05
# define Rte_Write_PP_CoFcaDbgIn06_De_CoFcaDbgIn06 Rte_Write_CpApEyeQSim_PP_CoFcaDbgIn06_De_CoFcaDbgIn06
# define Rte_Write_PP_DawDbgIn01_De_DawDbgIn01 Rte_Write_CpApEyeQSim_PP_DawDbgIn01_De_DawDbgIn01
# define Rte_Write_PP_DawDbgIn02_De_DawDbgIn02 Rte_Write_CpApEyeQSim_PP_DawDbgIn02_De_DawDbgIn02
# define Rte_Write_PP_DawDbgIn03_De_DawDbgIn03 Rte_Write_CpApEyeQSim_PP_DawDbgIn03_De_DawDbgIn03
# define Rte_Write_PP_DawDbgIn04_De_DawDbgIn04 Rte_Write_CpApEyeQSim_PP_DawDbgIn04_De_DawDbgIn04
# define Rte_Write_PP_DawDbgIn05_De_DawDbgIn05 Rte_Write_CpApEyeQSim_PP_DawDbgIn05_De_DawDbgIn05
# define Rte_Write_PP_DawDbgIn06_De_DawDbgIn06 Rte_Write_CpApEyeQSim_PP_DawDbgIn06_De_DawDbgIn06
# define Rte_Write_PP_FcaDbgIn01_De_FcaDbgIn01 Rte_Write_CpApEyeQSim_PP_FcaDbgIn01_De_FcaDbgIn01
# define Rte_Write_PP_FcaDbgIn02_De_FcaDbgIn02 Rte_Write_CpApEyeQSim_PP_FcaDbgIn02_De_FcaDbgIn02
# define Rte_Write_PP_FcaDbgIn03_De_FcaDbgIn03 Rte_Write_CpApEyeQSim_PP_FcaDbgIn03_De_FcaDbgIn03
# define Rte_Write_PP_FcaDbgIn04_De_FcaDbgIn04 Rte_Write_CpApEyeQSim_PP_FcaDbgIn04_De_FcaDbgIn04
# define Rte_Write_PP_FcaDbgIn05_De_FcaDbgIn05 Rte_Write_CpApEyeQSim_PP_FcaDbgIn05_De_FcaDbgIn05
# define Rte_Write_PP_FcaDbgIn06_De_FcaDbgIn06 Rte_Write_CpApEyeQSim_PP_FcaDbgIn06_De_FcaDbgIn06
# define Rte_Write_PP_HbaDbgIn01_De_HbaDbgIn01 Rte_Write_CpApEyeQSim_PP_HbaDbgIn01_De_HbaDbgIn01
# define Rte_Write_PP_HbaDbgIn02_De_HbaDbgIn02 Rte_Write_CpApEyeQSim_PP_HbaDbgIn02_De_HbaDbgIn02
# define Rte_Write_PP_HbaDbgIn03_De_HbaDbgIn03 Rte_Write_CpApEyeQSim_PP_HbaDbgIn03_De_HbaDbgIn03
# define Rte_Write_PP_HbaDbgIn04_De_HbaDbgIn04 Rte_Write_CpApEyeQSim_PP_HbaDbgIn04_De_HbaDbgIn04
# define Rte_Write_PP_HbaDbgIn05_De_HbaDbgIn05 Rte_Write_CpApEyeQSim_PP_HbaDbgIn05_De_HbaDbgIn05
# define Rte_Write_PP_HbaDbgIn06_De_HbaDbgIn06 Rte_Write_CpApEyeQSim_PP_HbaDbgIn06_De_HbaDbgIn06
# define Rte_Write_PP_IslwDbgIn01_De_IslwDbgIn01 Rte_Write_CpApEyeQSim_PP_IslwDbgIn01_De_IslwDbgIn01
# define Rte_Write_PP_IslwDbgIn02_De_IslwDbgIn02 Rte_Write_CpApEyeQSim_PP_IslwDbgIn02_De_IslwDbgIn02
# define Rte_Write_PP_IslwDbgIn03_De_IslwDbgIn03 Rte_Write_CpApEyeQSim_PP_IslwDbgIn03_De_IslwDbgIn03
# define Rte_Write_PP_IslwDbgIn04_De_IslwDbgIn04 Rte_Write_CpApEyeQSim_PP_IslwDbgIn04_De_IslwDbgIn04
# define Rte_Write_PP_IslwDbgIn05_De_IslwDbgIn05 Rte_Write_CpApEyeQSim_PP_IslwDbgIn05_De_IslwDbgIn05
# define Rte_Write_PP_IslwDbgIn06_De_IslwDbgIn06 Rte_Write_CpApEyeQSim_PP_IslwDbgIn06_De_IslwDbgIn06
# define Rte_Write_PP_IvcDbgIn01_De_IvcDbgIn01 Rte_Write_CpApEyeQSim_PP_IvcDbgIn01_De_IvcDbgIn01
# define Rte_Write_PP_IvcDbgIn02_De_IvcDbgIn02 Rte_Write_CpApEyeQSim_PP_IvcDbgIn02_De_IvcDbgIn02
# define Rte_Write_PP_IvcDbgIn03_De_IvcDbgIn03 Rte_Write_CpApEyeQSim_PP_IvcDbgIn03_De_IvcDbgIn03
# define Rte_Write_PP_IvcDbgIn04_De_IvcDbgIn04 Rte_Write_CpApEyeQSim_PP_IvcDbgIn04_De_IvcDbgIn04
# define Rte_Write_PP_IvcDbgIn05_De_IvcDbgIn05 Rte_Write_CpApEyeQSim_PP_IvcDbgIn05_De_IvcDbgIn05
# define Rte_Write_PP_IvcDbgIn06_De_IvcDbgIn06 Rte_Write_CpApEyeQSim_PP_IvcDbgIn06_De_IvcDbgIn06
# define Rte_Write_PP_LssDbgIn01_De_LssDbgIn01 Rte_Write_CpApEyeQSim_PP_LssDbgIn01_De_LssDbgIn01
# define Rte_Write_PP_LssDbgIn02_De_LssDbgIn02 Rte_Write_CpApEyeQSim_PP_LssDbgIn02_De_LssDbgIn02
# define Rte_Write_PP_LssDbgIn03_De_LssDbgIn03 Rte_Write_CpApEyeQSim_PP_LssDbgIn03_De_LssDbgIn03
# define Rte_Write_PP_LssDbgIn04_De_LssDbgIn04 Rte_Write_CpApEyeQSim_PP_LssDbgIn04_De_LssDbgIn04
# define Rte_Write_PP_LssDbgIn05_De_LssDbgIn05 Rte_Write_CpApEyeQSim_PP_LssDbgIn05_De_LssDbgIn05
# define Rte_Write_PP_LssDbgIn06_De_LssDbgIn06 Rte_Write_CpApEyeQSim_PP_LssDbgIn06_De_LssDbgIn06
# define Rte_Write_PP_SccDbgIn01_De_SccDbgIn01 Rte_Write_CpApEyeQSim_PP_SccDbgIn01_De_SccDbgIn01
# define Rte_Write_PP_SccDbgIn02_De_SccDbgIn02 Rte_Write_CpApEyeQSim_PP_SccDbgIn02_De_SccDbgIn02
# define Rte_Write_PP_SccDbgIn03_De_SccDbgIn03 Rte_Write_CpApEyeQSim_PP_SccDbgIn03_De_SccDbgIn03
# define Rte_Write_PP_SccDbgIn04_De_SccDbgIn04 Rte_Write_CpApEyeQSim_PP_SccDbgIn04_De_SccDbgIn04
# define Rte_Write_PP_SccDbgIn05_De_SccDbgIn05 Rte_Write_CpApEyeQSim_PP_SccDbgIn05_De_SccDbgIn05
# define Rte_Write_PP_SccDbgIn06_De_SccDbgIn06 Rte_Write_CpApEyeQSim_PP_SccDbgIn06_De_SccDbgIn06


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApEyeQSim_RP_FeatureConfig_getFeatureConfig




# define CpApEyeQSim_START_SEC_CODE
# include "CpApEyeQSim_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApEyeQSimInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApEyeQSimInit Re_CpApEyeQSimInit
FUNC(void, CpApEyeQSim_CODE) Re_CpApEyeQSimInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApEyeQSimMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 40ms
 *     and not in Mode(s) <FALSE>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn01_SignalGroup_COM_SG_RxDbgDataIn01_SignalGroup(COM_DT_SG_RxDbgDataIn01_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn02_SignalGroup_COM_SG_RxDbgDataIn02_SignalGroup(COM_DT_SG_RxDbgDataIn02_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn03_SignalGroup_COM_SG_RxDbgDataIn03_SignalGroup(COM_DT_SG_RxDbgDataIn03_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn04_SignalGroup_COM_SG_RxDbgDataIn04_SignalGroup(COM_DT_SG_RxDbgDataIn04_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn05_SignalGroup_COM_SG_RxDbgDataIn05_SignalGroup(COM_DT_SG_RxDbgDataIn05_SignalGroup *data)
 *   Std_ReturnType Rte_Read_COM_SG_RxDbgDataIn06_SignalGroup_COM_SG_RxDbgDataIn06_SignalGroup(COM_DT_SG_RxDbgDataIn06_SignalGroup *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput01_De_CoFcaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput02_De_CoFcaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput03_De_CoFcaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput04_De_CoFcaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput05_De_CoFcaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput06_De_CoFcaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput07_De_CoFcaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput08_De_CoFcaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput09_De_CoFcaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput10_De_CoFcaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput11_De_CoFcaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput12_De_CoFcaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput13_De_CoFcaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput14_De_CoFcaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput15_De_CoFcaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput16_De_CoFcaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput17_De_CoFcaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput18_De_CoFcaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput19_De_CoFcaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_CoFcaLogicDbgOutput20_De_CoFcaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput01_De_DawLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput02_De_DawLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput03_De_DawLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput04_De_DawLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput05_De_DawLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput06_De_DawLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput07_De_DawLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput08_De_DawLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput09_De_DawLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput10_De_DawLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput11_De_DawLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput12_De_DawLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput13_De_DawLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput14_De_DawLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput15_De_DawLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput16_De_DawLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput17_De_DawLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput18_De_DawLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput19_De_DawLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_DawLogicDbgOutput20_De_DawLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput01_De_HbaLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput02_De_HbaLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput03_De_HbaLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput04_De_HbaLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput05_De_HbaLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput06_De_HbaLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput07_De_HbaLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput08_De_HbaLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput09_De_HbaLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput10_De_HbaLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput11_De_HbaLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput12_De_HbaLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput13_De_HbaLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput14_De_HbaLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput15_De_HbaLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput16_De_HbaLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput17_De_HbaLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput18_De_HbaLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput19_De_HbaLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_HbaLogicDbgOutput20_De_HbaLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput01_De_IslwLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput02_De_IslwLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput03_De_IslwLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput04_De_IslwLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput05_De_IslwLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput06_De_IslwLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput07_De_IslwLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput08_De_IslwLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput09_De_IslwLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput10_De_IslwLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput11_De_IslwLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput12_De_IslwLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput13_De_IslwLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput14_De_IslwLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput15_De_IslwLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput16_De_IslwLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput17_De_IslwLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput18_De_IslwLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput19_De_IslwLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IslwLogicDbgOutput20_De_IslwLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput01_De_IvcLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput02_De_IvcLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput03_De_IvcLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput04_De_IvcLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput05_De_IvcLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput06_De_IvcLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput07_De_IvcLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput08_De_IvcLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput09_De_IvcLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput10_De_IvcLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput11_De_IvcLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput12_De_IvcLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput13_De_IvcLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput14_De_IvcLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput15_De_IvcLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput16_De_IvcLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput17_De_IvcLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput18_De_IvcLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput19_De_IvcLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput20_De_IvcLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_IvcLogicDbgOutput21_De_IvcLogicDbgOutput21(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput01_De_SccLogicDbgOutput01(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput02_De_SccLogicDbgOutput02(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput03_De_SccLogicDbgOutput03(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput04_De_SccLogicDbgOutput04(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput05_De_SccLogicDbgOutput05(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput06_De_SccLogicDbgOutput06(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput07_De_SccLogicDbgOutput07(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput08_De_SccLogicDbgOutput08(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput09_De_SccLogicDbgOutput09(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput10_De_SccLogicDbgOutput10(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput11_De_SccLogicDbgOutput11(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput12_De_SccLogicDbgOutput12(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput13_De_SccLogicDbgOutput13(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput14_De_SccLogicDbgOutput14(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput15_De_SccLogicDbgOutput15(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput16_De_SccLogicDbgOutput16(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput17_De_SccLogicDbgOutput17(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput18_De_SccLogicDbgOutput18(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput19_De_SccLogicDbgOutput19(DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Read_RP_SccLogicDbgOutput20_De_SccLogicDbgOutput20(DeLogicDbgOutput_t *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_01_SignalGroup_COM_SG_TxDbgDataOut_01_SignalGroup(const COM_DT_SG_TxDbgDataOut_01_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_02_SignalGroup_COM_SG_TxDbgDataOut_02_SignalGroup(const COM_DT_SG_TxDbgDataOut_02_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_03_SignalGroup_COM_SG_TxDbgDataOut_03_SignalGroup(const COM_DT_SG_TxDbgDataOut_03_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_04_SignalGroup_COM_SG_TxDbgDataOut_04_SignalGroup(const COM_DT_SG_TxDbgDataOut_04_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_05_SignalGroup_COM_SG_TxDbgDataOut_05_SignalGroup(const COM_DT_SG_TxDbgDataOut_05_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_06_SignalGroup_COM_SG_TxDbgDataOut_06_SignalGroup(const COM_DT_SG_TxDbgDataOut_06_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_07_SignalGroup_COM_SG_TxDbgDataOut_07_SignalGroup(const COM_DT_SG_TxDbgDataOut_07_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_08_SignalGroup_COM_SG_TxDbgDataOut_08_SignalGroup(const COM_DT_SG_TxDbgDataOut_08_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_09_SignalGroup_COM_SG_TxDbgDataOut_09_SignalGroup(const COM_DT_SG_TxDbgDataOut_09_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_10_SignalGroup_COM_SG_TxDbgDataOut_10_SignalGroup(const COM_DT_SG_TxDbgDataOut_10_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_11_SignalGroup_COM_SG_TxDbgDataOut_11_SignalGroup(const COM_DT_SG_TxDbgDataOut_11_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_12_SignalGroup_COM_SG_TxDbgDataOut_12_SignalGroup(const COM_DT_SG_TxDbgDataOut_12_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_13_SignalGroup_COM_SG_TxDbgDataOut_13_SignalGroup(const COM_DT_SG_TxDbgDataOut_13_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_14_SignalGroup_COM_SG_TxDbgDataOut_14_SignalGroup(const COM_DT_SG_TxDbgDataOut_14_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_15_SignalGroup_COM_SG_TxDbgDataOut_15_SignalGroup(const COM_DT_SG_TxDbgDataOut_15_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_16_SignalGroup_COM_SG_TxDbgDataOut_16_SignalGroup(const COM_DT_SG_TxDbgDataOut_16_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_17_SignalGroup_COM_SG_TxDbgDataOut_17_SignalGroup(const COM_DT_SG_TxDbgDataOut_17_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_18Signal_Group_COM_SG_TxDbgDataOut_18Signal_Group(const COM_DT_SG_TxDbgDataOut_18Signal_Group *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_19_SignalGroup_COM_SG_TxDbgDataOut_19_SignalGroup(const COM_DT_SG_TxDbgDataOut_19_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_20_SignalGroup_COM_SG_TxDbgDataOut_20_SignalGroup(const COM_DT_SG_TxDbgDataOut_20_SignalGroup *data)
 *   Std_ReturnType Rte_Write_COM_SG_TxDbgDataOut_21_SignalGroup_COM_SG_TxDbgDataOut_21_SignalGroup(const COM_DT_SG_TxDbgDataOut_21_SignalGroup *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn01_De_CoFcaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn02_De_CoFcaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn03_De_CoFcaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn04_De_CoFcaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn05_De_CoFcaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_CoFcaDbgIn06_De_CoFcaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn01_De_DawDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn02_De_DawDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn03_De_DawDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn04_De_DawDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn05_De_DawDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_DawDbgIn06_De_DawDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn01_De_FcaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn02_De_FcaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn03_De_FcaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn04_De_FcaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn05_De_FcaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaDbgIn06_De_FcaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn01_De_HbaDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn02_De_HbaDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn03_De_HbaDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn04_De_HbaDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn05_De_HbaDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_HbaDbgIn06_De_HbaDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn01_De_IslwDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn02_De_IslwDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn03_De_IslwDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn04_De_IslwDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn05_De_IslwDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IslwDbgIn06_De_IslwDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn01_De_IvcDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn02_De_IvcDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn03_De_IvcDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn04_De_IvcDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn05_De_IvcDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_IvcDbgIn06_De_IvcDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn01_De_LssDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn02_De_LssDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn03_De_LssDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn04_De_LssDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn05_De_LssDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssDbgIn06_De_LssDbgIn06(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn01_De_SccDbgIn01(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn02_De_SccDbgIn02(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn03_De_SccDbgIn03(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn04_De_SccDbgIn04(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn05_De_SccDbgIn05(const DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Write_PP_SccDbgIn06_De_SccDbgIn06(const DeLogicDbgInput_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApEyeQSimMain Re_CpApEyeQSimMain
FUNC(void, CpApEyeQSim_CODE) Re_CpApEyeQSimMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApEyeQSim_STOP_SEC_CODE
# include "CpApEyeQSim_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPEYEQSIM_H */
