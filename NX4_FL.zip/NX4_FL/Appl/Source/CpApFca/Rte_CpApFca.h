/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApFca.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApFca
 *  Generation Time:  2023-04-20 13:52:29
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApFca> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPFCA_H
# define _RTE_CPAPFCA_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApFca_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApFca
{
  /* dummy entry */
  uint8 _dummy;
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApFca, RTE_CONST, RTE_CONST) Rte_Inst_CpApFca; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApFca, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_Core1ZfAppCameraState_De_ZfAppCameraState(P2VAR(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn01_De_FcaDbgIn01(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn02_De_FcaDbgIn02(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn03_De_FcaDbgIn03(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn04_De_FcaDbgIn04(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn05_De_FcaDbgIn05(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaDbgIn06_De_FcaDbgIn06(P2VAR(DeLogicDbgInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaFailSafeInfo_De_FcaFailSafeInfo(P2VAR(FcaFailSafeInfo_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaInput_De_FcaInput(P2VAR(FcaInput_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA(P2VAR(FcaInternalInFromCOFCA_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApFca_RP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(P2VAR(FcaInternalInFromLSS_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_ADAS101_De_ADAS101(P2CONST(ADAS101_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaEDR_De_FcaInternalOutToEDR(P2CONST(FcaEDR_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaFrCmrOut_De_FcaFrCmrOut(P2CONST(FcaFrCmrOut_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(P2CONST(DeLogicDbgOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaOutput_De_FcaOutput(P2CONST(FcaOutput_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_FcaUxOutToIvc_De_FcaUxOutToIvc(P2CONST(FcaUxOutToIvc_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApFca_PP_SccInputFromFca_De_SccInputFromFca(P2CONST(SccInputFromFca_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_CANmsg_getCanmsg(P2VAR(CANmsg_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) CANmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_EOLInfo_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FcaFrqNvData_FcaFrqNvDataRead(P2VAR(FcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FcaFrqNvData_FcaFrqNvDataWrite(P2CONST(FcaNvmSaveVal_t, AUTOMATIC, RTE_CPAPFCA_APPL_DATA) FcaFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FeatureConfig_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FeatureVehicle_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrFS_getFrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrFcfVd_getFrCmrFcfVd(P2VAR(FcfVd_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrFcfVru_getFrCmrFcfVru(P2VAR(FcfVru_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrHdrFS_getFrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd(P2VAR(FrCmrHdrFcfVd_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrHdrFcfVd); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru(P2VAR(FrCmrHdrFcfVru_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrHdrFcfVru); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(P2VAR(FrCmrHdrLnHost_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrHdrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrHdrObj_getFrCmrHdrObj(P2VAR(FrCmrHdrObj_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrHdrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrLnHost_getFrCmrLnHost(P2VAR(LanesHost_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrLnHost); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_FrCmrObj_getFrCmrObj(P2VAR(Objects_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FrCmrObj); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_Os_Service_GetCounterValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) Value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_Os_Service_GetElapsedValue(P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) Value, P2VAR(TimeInMicrosecondsType, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) ElapsedValue); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApFca_RP_RdrInfo_getRdrInfo(P2VAR(RdrInfo_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) Rdrmsg); /* PRQA S 0850 */ /* MD_MSR_19.8 */

FUNC(void, RTE_CODE) Rte_Enter_CpApFca_ExclusiveArea_CpApFcaAppVersionInfo(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(void, RTE_CODE) Rte_Exit_CpApFca_ExclusiveArea_CpApFcaAppVersionInfo(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState Rte_Read_CpApFca_RP_Core1ZfAppCameraState_De_ZfAppCameraState
# define Rte_Read_RP_FcaDbgIn01_De_FcaDbgIn01 Rte_Read_CpApFca_RP_FcaDbgIn01_De_FcaDbgIn01
# define Rte_Read_RP_FcaDbgIn02_De_FcaDbgIn02 Rte_Read_CpApFca_RP_FcaDbgIn02_De_FcaDbgIn02
# define Rte_Read_RP_FcaDbgIn03_De_FcaDbgIn03 Rte_Read_CpApFca_RP_FcaDbgIn03_De_FcaDbgIn03
# define Rte_Read_RP_FcaDbgIn04_De_FcaDbgIn04 Rte_Read_CpApFca_RP_FcaDbgIn04_De_FcaDbgIn04
# define Rte_Read_RP_FcaDbgIn05_De_FcaDbgIn05 Rte_Read_CpApFca_RP_FcaDbgIn05_De_FcaDbgIn05
# define Rte_Read_RP_FcaDbgIn06_De_FcaDbgIn06 Rte_Read_CpApFca_RP_FcaDbgIn06_De_FcaDbgIn06
# define Rte_Read_RP_FcaFailSafeInfo_De_FcaFailSafeInfo Rte_Read_CpApFca_RP_FcaFailSafeInfo_De_FcaFailSafeInfo
# define Rte_Read_RP_FcaInput_De_FcaInput Rte_Read_CpApFca_RP_FcaInput_De_FcaInput
# define Rte_Read_RP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA Rte_Read_CpApFca_RP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA
# define Rte_Read_RP_FcaInternalInFromLSS_De_FcaInternalInFromLSS Rte_Read_CpApFca_RP_FcaInternalInFromLSS_De_FcaInternalInFromLSS


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_ADAS101_De_ADAS101 Rte_Write_CpApFca_PP_ADAS101_De_ADAS101
# define Rte_Write_PP_FcaEDR_De_FcaInternalOutToEDR Rte_Write_CpApFca_PP_FcaEDR_De_FcaInternalOutToEDR
# define Rte_Write_PP_FcaFrCmrOut_De_FcaFrCmrOut Rte_Write_CpApFca_PP_FcaFrCmrOut_De_FcaFrCmrOut
# define Rte_Write_PP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01 Rte_Write_CpApFca_PP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01
# define Rte_Write_PP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02 Rte_Write_CpApFca_PP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02
# define Rte_Write_PP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03 Rte_Write_CpApFca_PP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03
# define Rte_Write_PP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04 Rte_Write_CpApFca_PP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04
# define Rte_Write_PP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05 Rte_Write_CpApFca_PP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05
# define Rte_Write_PP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06 Rte_Write_CpApFca_PP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06
# define Rte_Write_PP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07 Rte_Write_CpApFca_PP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07
# define Rte_Write_PP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08 Rte_Write_CpApFca_PP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08
# define Rte_Write_PP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09 Rte_Write_CpApFca_PP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09
# define Rte_Write_PP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10 Rte_Write_CpApFca_PP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10
# define Rte_Write_PP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11 Rte_Write_CpApFca_PP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11
# define Rte_Write_PP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12 Rte_Write_CpApFca_PP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12
# define Rte_Write_PP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13 Rte_Write_CpApFca_PP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13
# define Rte_Write_PP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14 Rte_Write_CpApFca_PP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14
# define Rte_Write_PP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15 Rte_Write_CpApFca_PP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15
# define Rte_Write_PP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16 Rte_Write_CpApFca_PP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16
# define Rte_Write_PP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17 Rte_Write_CpApFca_PP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17
# define Rte_Write_PP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18 Rte_Write_CpApFca_PP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18
# define Rte_Write_PP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19 Rte_Write_CpApFca_PP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19
# define Rte_Write_PP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20 Rte_Write_CpApFca_PP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20
# define Rte_Write_PP_FcaOutput_De_FcaOutput Rte_Write_CpApFca_PP_FcaOutput_De_FcaOutput
# define Rte_Write_PP_FcaUxOutToIvc_De_FcaUxOutToIvc Rte_Write_CpApFca_PP_FcaUxOutToIvc_De_FcaUxOutToIvc
# define Rte_Write_PP_SccInputFromFca_De_SccInputFromFca Rte_Write_CpApFca_PP_SccInputFromFca_De_SccInputFromFca


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_CANmsg_getCanmsg Rte_Call_CpApFca_RP_CANmsg_getCanmsg
# define Rte_Call_RP_EOLInfo_getEOLInfo Rte_Call_CpApFca_RP_EOLInfo_getEOLInfo
# define Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataRead Rte_Call_CpApFca_RP_FcaFrqNvData_FcaFrqNvDataRead
# define Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataWrite Rte_Call_CpApFca_RP_FcaFrqNvData_FcaFrqNvDataWrite
# define Rte_Call_RP_FeatureConfig_getFeatureConfig Rte_Call_CpApFca_RP_FeatureConfig_getFeatureConfig
# define Rte_Call_RP_FeatureVehicle_getFeatureVehicle Rte_Call_CpApFca_RP_FeatureVehicle_getFeatureVehicle
# define Rte_Call_RP_FrCmrFS_getFrCmrFS Rte_Call_CpApFca_RP_FrCmrFS_getFrCmrFS
# define Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd Rte_Call_CpApFca_RP_FrCmrFcfVd_getFrCmrFcfVd
# define Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru Rte_Call_CpApFca_RP_FrCmrFcfVru_getFrCmrFcfVru
# define Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS Rte_Call_CpApFca_RP_FrCmrHdrFS_getFrCmrHdrFS
# define Rte_Call_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd Rte_Call_CpApFca_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd
# define Rte_Call_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru Rte_Call_CpApFca_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru
# define Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost Rte_Call_CpApFca_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost
# define Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj Rte_Call_CpApFca_RP_FrCmrHdrObj_getFrCmrHdrObj
# define Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost Rte_Call_CpApFca_RP_FrCmrLnHost_getFrCmrLnHost
# define Rte_Call_RP_FrCmrObj_getFrCmrObj Rte_Call_CpApFca_RP_FrCmrObj_getFrCmrObj
# define Rte_Call_RP_Os_Service_GetCounterValue Rte_Call_CpApFca_RP_Os_Service_GetCounterValue
# define Rte_Call_RP_Os_Service_GetElapsedValue Rte_Call_CpApFca_RP_Os_Service_GetElapsedValue
# define Rte_Call_RP_RdrInfo_getRdrInfo Rte_Call_CpApFca_RP_RdrInfo_getRdrInfo


/**********************************************************************************************************************
 * Exclusive Areas
 *********************************************************************************************************************/

# define Rte_Enter_ExclusiveArea_CpApFcaAppVersionInfo Rte_Enter_CpApFca_ExclusiveArea_CpApFcaAppVersionInfo /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */
# define Rte_Exit_ExclusiveArea_CpApFcaAppVersionInfo Rte_Exit_CpApFca_ExclusiveArea_CpApFcaAppVersionInfo /* RteAnalyzer(ExclusiveArea, OS_INTERRUPT_BLOCKING) */




# define CpApFca_START_SEC_CODE
# include "CpApFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataRead(FcaNvmSaveVal_t *FcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FcaFrqNvData_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFcaInit Re_CpApFcaInit
FUNC(void, CpApFca_CODE) Re_CpApFcaInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFcaVersionReq
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_FcaAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Exclusive Area Access:
 * ======================
 *   void Rte_Enter_ExclusiveArea_CpApFcaAppVersionInfo(void)
 *   void Rte_Exit_ExclusiveArea_CpApFcaAppVersionInfo(void)
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApFcaVersionReq(FcaAppVersionInfo_t *FcaAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FcaAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFcaVersionReq Re_CpApFcaVersionReq
FUNC(Std_ReturnType, CpApFca_CODE) Re_CpApFcaVersionReq(P2VAR(FcaAppVersionInfo_t, AUTOMATIC, RTE_CPAPFCA_APPL_VAR) FcaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCTG
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcCTG Re_CpApFca_EbcCTG
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCTG(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcCmdcJT Re_CpApFca_EbcCmdcJT
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcJT(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcVEH
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcCmdcVEH Re_CpApFca_EbcCmdcVEH
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcVEH(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCmdcVRU
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcCmdcVRU Re_CpApFca_EbcCmdcVRU
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCmdcVRU(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcCtgJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcCtgJT Re_CpApFca_EbcCtgJT
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcCtgJT(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcOIF
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcOIF Re_CpApFca_EbcOIF
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcOIF(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_EbcVmpJT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_EbcVmpJT Re_CpApFca_EbcVmpJT
FUNC(void, CpApFca_CODE) Re_CpApFca_EbcVmpJT(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_FcaOUTPUT
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_ADAS101_De_ADAS101(const ADAS101_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaEDR_De_FcaInternalOutToEDR(const FcaEDR_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaFrCmrOut_De_FcaFrCmrOut(const FcaFrCmrOut_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput01_De_FcaLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput02_De_FcaLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput03_De_FcaLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput04_De_FcaLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput05_De_FcaLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput06_De_FcaLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput07_De_FcaLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput08_De_FcaLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput09_De_FcaLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput10_De_FcaLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput11_De_FcaLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput12_De_FcaLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput13_De_FcaLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput14_De_FcaLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput15_De_FcaLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput16_De_FcaLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput17_De_FcaLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput18_De_FcaLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput19_De_FcaLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaLogicDbgOutput20_De_FcaLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaOutput_De_FcaOutput(const FcaOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaUxOutToIvc_De_FcaUxOutToIvc(const FcaUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInputFromFca_De_SccInputFromFca(const SccInputFromFca_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_FcaFrqNvData_FcaFrqNvDataWrite(const FcaNvmSaveVal_t *FcaFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FcaFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_FcaOUTPUT Re_CpApFca_FcaOUTPUT
FUNC(void, CpApFca_CODE) Re_CpApFca_FcaOUTPUT(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_FcaSDF
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core1ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn01_De_FcaDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn02_De_FcaDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn03_De_FcaDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn04_De_FcaDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn05_De_FcaDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaDbgIn06_De_FcaDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaFailSafeInfo_De_FcaFailSafeInfo(FcaFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInput_De_FcaInput(FcaInput_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInternalInFromCOFCA_De_FcaInternalInFromCOFCA(FcaInternalInFromCOFCA_t *data)
 *   Std_ReturnType Rte_Read_RP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(FcaInternalInFromLSS_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVd_getFrCmrFcfVd(FcfVd_t *FrCmrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFcfVru_getFrCmrFcfVru(FcfVru_t *FrCmrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFS_getFrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVd_getFrCmrHdrFcfVd(FrCmrHdrFcfVd_t *FrCmrHdrFcfVd)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVd_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrFcfVru_getFrCmrHdrFcfVru(FrCmrHdrFcfVru_t *FrCmrHdrFcfVru)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrFcfVru_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_RdrInfo_getRdrInfo(RdrInfo_t *Rdrmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_RdrInfo_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_FcaSDF Re_CpApFca_FcaSDF
FUNC(void, CpApFca_CODE) Re_CpApFca_FcaSDF(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApFca_IntegratedSTM
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 20ms
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApFca_IntegratedSTM Re_CpApFca_IntegratedSTM
FUNC(void, CpApFca_CODE) Re_CpApFca_IntegratedSTM(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApFca_STOP_SEC_CODE
# include "CpApFca_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_CANmsg_ReturnType (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_FcaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_FcaFrqNvData_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVd_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFcfVru_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrObj_ReturnType (1U)

# define RTE_E_IF_FrCmrLnHost_ReturnType (1U)

# define RTE_E_IF_FrCmrObj_ReturnType (1U)

# define RTE_E_IF_RdrInfo_ReturnType (1U)

# define RTE_E_Os_Service_E_OK (0U)

# define RTE_E_Os_Service_E_OS_ID (3U)

# define RTE_E_Os_Service_E_OS_VALUE (8U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPFCA_H */
