/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApUdsPlatform.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApUdsPlatform
 *  Generation Time:  2023-04-20 13:52:54
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApUdsPlatform> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPUDSPLATFORM_H
# define _RTE_CPAPUDSPLATFORM_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApUdsPlatform_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApUdsPlatform
{
  /* PIM Handles section */
  P2VAR(EOLInfo_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_EolInfo_222E; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(FeatureConfig_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_FeatureConfig; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(FeatureVehicle_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_FeatureVehicle; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(Plant_TAC2InitParamsNVM_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_PlantTAC2InitParamsNVM; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApUdsPlatform, RTE_CONST, RTE_CONST) Rte_Inst_CpApUdsPlatform; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApUdsPlatform, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_Eol_ADAS_DRV_ADAS_DRV (0U)
# define Rte_InitValue_PP_Eol_Codingcomplete_Codingcomplete (0U)
# define Rte_InitValue_PP_Eol_CountryCode_CountryCode (0U)
# define Rte_InitValue_PP_Eol_DAW_DAW (0U)
# define Rte_InitValue_PP_Eol_DriveType_DriveType (0U)
# define Rte_InitValue_PP_Eol_FCA_FCA (0U)
# define Rte_InitValue_PP_Eol_HBA_HBA (0U)
# define Rte_InitValue_PP_Eol_HDA_HDA (0U)
# define Rte_InitValue_PP_Eol_ISG_ISG (0U)
# define Rte_InitValue_PP_Eol_ISLW_ISLW (0U)
# define Rte_InitValue_PP_Eol_LFA_LFA (0U)
# define Rte_InitValue_PP_Eol_LKALDW_LKALDW (0U)
# define Rte_InitValue_PP_Eol_LampTypeLbeam_LampTypeLbeam (0U)
# define Rte_InitValue_PP_Eol_MDPSType_MDPSType (0U)
# define Rte_InitValue_PP_Eol_NSCC_NSCC (0U)
# define Rte_InitValue_PP_Eol_SCC_SCC (0U)
# define Rte_InitValue_PP_Eol_TransAxle_TransAxle (0U)
# define Rte_InitValue_PP_Eol_VehicleMY_VehicleMY (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_EOLInfo_EOLInfo(P2CONST(EOLInfo_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_FeatureConfig_FeatureConfig(P2CONST(FeatureConfig_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_FeatureVehicle_FeatureVehicle(P2CONST(FeatureVehicle_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_ADAS_DRV_ADAS_DRV(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_Codingcomplete_Codingcomplete(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_CountryCode_CountryCode(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_DAW_DAW(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_DriveType_DriveType(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_FCA_FCA(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_HBA_HBA(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_HDA_HDA(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_ISG_ISG(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_ISLW_ISLW(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_LFA_LFA(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_LKALDW_LKALDW(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_LampTypeLbeam_LampTypeLbeam(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_MDPSType_MDPSType(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_NSCC_NSCC(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_SCC_SCC(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_TransAxle_TransAxle(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Eol_VehicleMY_VehicleMY(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_PlatformCode_PlatformCode(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_PlatformCode_PlatformCode(P2CONST(PlatformCode, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_Tac2FreshStart_De_Tac2FreshStart(boolean data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_VehicleName_VehicleName(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApUdsPlatform_PP_VehicleName_VehicleName(P2CONST(VehicleName, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif
FUNC(Std_ReturnType, RTE_CODE) Rte_Switch_CpApUdsPlatform_PP_SccFunctionCallwithEOL_SccFunctionCallwithEOL(uint8 nextMode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_EnvironmentParams_EYEQMESP_GetWriteEnvironmentParamsStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams(P2VAR(EYEQMESP_EnvironmentParams_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_TAC2InitParams_EYEQMESP_GetWriteTAC2InitParamsStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams(P2VAR(EYEQMESP_TAC2InitParamsNVM_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_VehicleCalParams_EYEQMESP_GetWriteVehicleCalParamsStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams(P2VAR(EYEQMESP_VehicleCalParams_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) dstBuf_p, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) status_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_EOLInfo_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_EOLInfo_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureConfig_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureConfig_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureVehicle_WriteBlock(dtRef_const_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_GetErrorStatus(P2VAR(NvM_RequestResultType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_SetDataIndex(uint8 DataIndex); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApUdsPlatform_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_Core1ToCore2_EOLInfo_EOLInfo Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_EOLInfo_EOLInfo
# define Rte_Write_PP_Core1ToCore2_FeatureConfig_FeatureConfig Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_FeatureConfig_FeatureConfig
# define Rte_Write_PP_Core1ToCore2_FeatureVehicle_FeatureVehicle Rte_Write_CpApUdsPlatform_PP_Core1ToCore2_FeatureVehicle_FeatureVehicle
# define Rte_Write_PP_Eol_ADAS_DRV_ADAS_DRV Rte_Write_CpApUdsPlatform_PP_Eol_ADAS_DRV_ADAS_DRV
# define Rte_Write_PP_Eol_Codingcomplete_Codingcomplete Rte_Write_CpApUdsPlatform_PP_Eol_Codingcomplete_Codingcomplete
# define Rte_Write_PP_Eol_CountryCode_CountryCode Rte_Write_CpApUdsPlatform_PP_Eol_CountryCode_CountryCode
# define Rte_Write_PP_Eol_DAW_DAW Rte_Write_CpApUdsPlatform_PP_Eol_DAW_DAW
# define Rte_Write_PP_Eol_DriveType_DriveType Rte_Write_CpApUdsPlatform_PP_Eol_DriveType_DriveType
# define Rte_Write_PP_Eol_FCA_FCA Rte_Write_CpApUdsPlatform_PP_Eol_FCA_FCA
# define Rte_Write_PP_Eol_HBA_HBA Rte_Write_CpApUdsPlatform_PP_Eol_HBA_HBA
# define Rte_Write_PP_Eol_HDA_HDA Rte_Write_CpApUdsPlatform_PP_Eol_HDA_HDA
# define Rte_Write_PP_Eol_ISG_ISG Rte_Write_CpApUdsPlatform_PP_Eol_ISG_ISG
# define Rte_Write_PP_Eol_ISLW_ISLW Rte_Write_CpApUdsPlatform_PP_Eol_ISLW_ISLW
# define Rte_Write_PP_Eol_LFA_LFA Rte_Write_CpApUdsPlatform_PP_Eol_LFA_LFA
# define Rte_Write_PP_Eol_LKALDW_LKALDW Rte_Write_CpApUdsPlatform_PP_Eol_LKALDW_LKALDW
# define Rte_Write_PP_Eol_LampTypeLbeam_LampTypeLbeam Rte_Write_CpApUdsPlatform_PP_Eol_LampTypeLbeam_LampTypeLbeam
# define Rte_Write_PP_Eol_MDPSType_MDPSType Rte_Write_CpApUdsPlatform_PP_Eol_MDPSType_MDPSType
# define Rte_Write_PP_Eol_NSCC_NSCC Rte_Write_CpApUdsPlatform_PP_Eol_NSCC_NSCC
# define Rte_Write_PP_Eol_SCC_SCC Rte_Write_CpApUdsPlatform_PP_Eol_SCC_SCC
# define Rte_Write_PP_Eol_TransAxle_TransAxle Rte_Write_CpApUdsPlatform_PP_Eol_TransAxle_TransAxle
# define Rte_Write_PP_Eol_VehicleMY_VehicleMY Rte_Write_CpApUdsPlatform_PP_Eol_VehicleMY_VehicleMY
# define Rte_Write_PP_PlatformCode_PlatformCode Rte_Write_CpApUdsPlatform_PP_PlatformCode_PlatformCode
# define Rte_Write_PP_Tac2FreshStart_De_Tac2FreshStart Rte_Write_CpApUdsPlatform_PP_Tac2FreshStart_De_Tac2FreshStart
# define Rte_Write_PP_VehicleName_VehicleName Rte_Write_CpApUdsPlatform_PP_VehicleName_VehicleName


/**********************************************************************************************************************
 * Rte_Switch_<p>_<m>
 *********************************************************************************************************************/
# define Rte_Switch_PP_SccFunctionCallwithEOL_SccFunctionCallwithEOL Rte_Switch_CpApUdsPlatform_PP_SccFunctionCallwithEOL_SccFunctionCallwithEOL


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode Rte_Call_CpApUdsPlatform_RP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode
# define Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_GetWriteEnvironmentParamsStatus Rte_Call_CpApUdsPlatform_RP_EYEQMESP_EnvironmentParams_EYEQMESP_GetWriteEnvironmentParamsStatus
# define Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams Rte_Call_CpApUdsPlatform_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams
# define Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_GetWriteTAC2InitParamsStatus Rte_Call_CpApUdsPlatform_RP_EYEQMESP_TAC2InitParams_EYEQMESP_GetWriteTAC2InitParamsStatus
# define Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams Rte_Call_CpApUdsPlatform_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams
# define Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_GetWriteVehicleCalParamsStatus Rte_Call_CpApUdsPlatform_RP_EYEQMESP_VehicleCalParams_EYEQMESP_GetWriteVehicleCalParamsStatus
# define Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams Rte_Call_CpApUdsPlatform_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams
# define Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApUdsPlatform_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_NvMService_EOLInfo_GetErrorStatus Rte_Call_CpApUdsPlatform_RP_NvMService_EOLInfo_GetErrorStatus
# define Rte_Call_RP_NvMService_EOLInfo_WriteBlock Rte_Call_CpApUdsPlatform_RP_NvMService_EOLInfo_WriteBlock
# define Rte_Call_RP_NvMService_FeatureConfig_GetErrorStatus Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureConfig_GetErrorStatus
# define Rte_Call_RP_NvMService_FeatureConfig_WriteBlock Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureConfig_WriteBlock
# define Rte_Call_RP_NvMService_FeatureVehicle_WriteBlock Rte_Call_CpApUdsPlatform_RP_NvMService_FeatureVehicle_WriteBlock
# define Rte_Call_RP_NvMService_TAC2InitParams_GetErrorStatus Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_GetErrorStatus
# define Rte_Call_RP_NvMService_TAC2InitParams_ReadBlock Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_ReadBlock
# define Rte_Call_RP_NvMService_TAC2InitParams_SetDataIndex Rte_Call_CpApUdsPlatform_RP_NvMService_TAC2InitParams_SetDataIndex
# define Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus Rte_Call_CpApUdsPlatform_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_EolInfo_222E() (Rte_Inst_CpApUdsPlatform->Pim_EolInfo_222E) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_FeatureConfig() (Rte_Inst_CpApUdsPlatform->Pim_FeatureConfig) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_FeatureVehicle() (Rte_Inst_CpApUdsPlatform->Pim_FeatureVehicle) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_PlantTAC2InitParamsNVM() (Rte_Inst_CpApUdsPlatform->Pim_PlantTAC2InitParamsNVM) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   EOLInfo_t *Rte_Pim_EolInfo_222E(void)
 *   FeatureConfig_t *Rte_Pim_FeatureConfig(void)
 *   FeatureVehicle_t *Rte_Pim_FeatureVehicle(void)
 *   Plant_TAC2InitParamsNVM_t *Rte_Pim_PlantTAC2InitParamsNVM(void)
 *
 *********************************************************************************************************************/


# define CpApUdsPlatform_START_SEC_CODE
# include "CpApUdsPlatform_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_EOLInfo_EOLInfo(const EOLInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureConfig_FeatureConfig(const FeatureConfig_t *data)
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureVehicle_FeatureVehicle(const FeatureVehicle_t *data)
 *   Std_ReturnType Rte_Write_PP_Eol_ADAS_DRV_ADAS_DRV(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_Codingcomplete_Codingcomplete(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_CountryCode_CountryCode(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DAW_DAW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DriveType_DriveType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_FCA_FCA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HBA_HBA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HDA_HDA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISG_ISG(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISLW_ISLW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LFA_LFA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LKALDW_LKALDW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LampTypeLbeam_LampTypeLbeam(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_MDPSType_MDPSType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_NSCC_NSCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_SCC_SCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_TransAxle_TransAxle(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_VehicleMY_VehicleMY(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PlatformCode_PlatformCode(const uint8 *data)
 *     Argument data: uint8* is of type PlatformCode
 *   Std_ReturnType Rte_Write_PP_VehicleName_VehicleName(const uint8 *data)
 *     Argument data: uint8* is of type VehicleName
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SetAppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureVehicle_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUdsPlatform_Init CpApUdsPlatform_Init
FUNC(void, CpApUdsPlatform_CODE) CpApUdsPlatform_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getEOLInfo
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getEOLInfo> of PortPrototype <PP_EOLInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getEOLInfo(EOLInfo_t *EOLInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_EOLInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUdsPlatform_getEOLInfo CpApUdsPlatform_getEOLInfo
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getEOLInfo(P2VAR(EOLInfo_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) EOLInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getFeatureConfig
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureConfig> of PortPrototype <PP_FeatureConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureConfig_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUdsPlatform_getFeatureConfig CpApUdsPlatform_getFeatureConfig
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getFeatureConfig(P2VAR(FeatureConfig_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) FeatureConfig); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApUdsPlatform_getFeatureVehicle
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFeatureVehicle> of PortPrototype <PP_FeatureVehicle>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType CpApUdsPlatform_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FeatureVehicle_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApUdsPlatform_getFeatureVehicle CpApUdsPlatform_getFeatureVehicle
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) CpApUdsPlatform_getFeatureVehicle(P2VAR(FeatureVehicle_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) FeatureVehicle); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_A0FF_SystemConfigParameter_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_A0FF_SystemConfigParameter>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_A0FF_SystemConfigParameter_ReadData(uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_A0FF_SystemConfigParameter_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_A0FF_SystemConfigParameter_ReadData DataServices_Data_A0FF_SystemConfigParameter_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_ReadData(P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_ReadData(P2VAR(Dcm_Data3ByteType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_A0FF_SystemConfigParameter_WriteData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteData> of PortPrototype <DataServices_Data_A0FF_SystemConfigParameter>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_FeatureConfig_FeatureConfig(const FeatureConfig_t *data)
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_A0FF_SystemConfigParameter_WriteData(const uint8 *Data, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Data: uint8* is of type Dcm_Data3ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_A0FF_SystemConfigParameter_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_A0FF_SystemConfigParameter_WriteData DataServices_Data_A0FF_SystemConfigParameter_WriteData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_WriteData(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_A0FF_SystemConfigParameter_WriteData(P2CONST(Dcm_Data3ByteType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <ReadData> of PortPrototype <DataServices_Data_C0DE_ECU_Configuration_at_EOL>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData(Dcm_OpStatusType OpStatus, uint8 *Data)
 *     Argument Data: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData(Dcm_OpStatusType OpStatus, P2VAR(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_ReadData(Dcm_OpStatusType OpStatus, P2VAR(Dcm_Data8ByteType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) Data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <WriteData> of PortPrototype <DataServices_Data_C0DE_ECU_Configuration_at_EOL>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core1ToCore2_EOLInfo_EOLInfo(const EOLInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Eol_ADAS_DRV_ADAS_DRV(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_Codingcomplete_Codingcomplete(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_CountryCode_CountryCode(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DAW_DAW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_DriveType_DriveType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_FCA_FCA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HBA_HBA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_HDA_HDA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISG_ISG(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_ISLW_ISLW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LFA_LFA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LKALDW_LKALDW(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_LampTypeLbeam_LampTypeLbeam(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_MDPSType_MDPSType(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_NSCC_NSCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_SCC_SCC(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_TransAxle_TransAxle(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eol_VehicleMY_VehicleMY(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Tac2FreshStart_De_Tac2FreshStart(boolean data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AAPL_EYEQMGR_NotifyToSendInitMsgsInTac2Mode_EYEQMGR_NotifyToSendInitMsgsInTac2Mode(void)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_GetWriteEnvironmentParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_EnvironmentParams_EYEQMESP_ReadEnvironmentParams(EYEQMESP_EnvironmentParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_GetWriteTAC2InitParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_TAC2InitParams_EYEQMESP_ReadTAC2InitParams(EYEQMESP_TAC2InitParamsNVM_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_GetWriteVehicleCalParamsStatus(uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EYEQMESP_VehicleCalParams_EYEQMESP_ReadVehicleCalParams(EYEQMESP_VehicleCalParams_t *dstBuf_p, uint8 *status_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore1_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore1_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_SetAppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status FaultNum, boolean FaultStatus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_SetAppDiagFaultStatus_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_EOLInfo_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_EOLInfo_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_FeatureConfig_WriteBlock(dtRef_const_VOID SrcPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_GetErrorStatus(NvM_RequestResultType *ErrorStatus)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_TAC2InitParams_SetDataIndex(uint8 DataIndex)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData(const uint8 *Data, Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType *ErrorCode)
 *     Argument Data: uint8* is of type Dcm_Data8ByteType
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_DCM_E_PENDING
 *   RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_E_NOT_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData
# ifdef RTE_PTR2ARRAYBASETYPE_PASSING
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData(P2CONST(uint8, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# else
FUNC(Std_ReturnType, CpApUdsPlatform_CODE) DataServices_Data_C0DE_ECU_Configuration_at_EOL_WriteData(P2CONST(Dcm_Data8ByteType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_DATA) Data, Dcm_OpStatusType OpStatus, P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ErrorCode); /* PRQA S 0850 */ /* MD_MSR_19.8 */
# endif

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_EOLInfo_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_EOLInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_EOLInfo_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PP_NvMNotifyJobFinished_EOLInfo_JobFinished PP_NvMNotifyJobFinished_EOLInfo_JobFinished
FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_EOLInfo_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_FeatureConfig_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_FeatureConfig>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_FeatureConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PP_NvMNotifyJobFinished_FeatureConfig_JobFinished PP_NvMNotifyJobFinished_FeatureConfig_JobFinished
FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_FeatureConfig_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_FeatureVehicle>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished
FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_FeatureVehicle_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_TAC2InitParams>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished
FUNC(void, CpApUdsPlatform_CODE) PP_NvMNotifyJobFinished_TAC2InitParams_JobFinished(NvM_ServiceIdType ServiceId, NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApUdsPlatformMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Mode Interfaces:
 * ================
 *   Std_ReturnType Rte_Switch_PP_SccFunctionCallwithEOL_SccFunctionCallwithEOL(uint8 mode)
 *   Modes of Rte_ModeType_SccFunctionCallwithEOL:
 *   - RTE_MODE_SccFunctionCallwithEOL_SccFunctionalityDisabled
 *   - RTE_MODE_SccFunctionCallwithEOL_SccFunctionalityEnabled
 *   - RTE_TRANSITION_SccFunctionCallwithEOL
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApUdsPlatformMain Re_CpApUdsPlatformMain
FUNC(void, CpApUdsPlatform_CODE) Re_CpApUdsPlatformMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_GetEepDump
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <GetEepDump> of PortPrototype <PP_GetPtmEepDump>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_GetEepDump(uint32 nvmAddr_u32, PtmEepDumpRecord_t *ramAddr_u8, uint16 numBytes_u16, uint16 operation)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_GetEepDump Re_GetEepDump
FUNC(void, CpApUdsPlatform_CODE) Re_GetEepDump(uint32 nvmAddr_u32, P2VAR(PtmEepDumpRecord_t, AUTOMATIC, RTE_CPAPUDSPLATFORM_APPL_VAR) ramAddr_u8, uint16 numBytes_u16, uint16 operation); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApUdsPlatform_STOP_SEC_CODE
# include "CpApUdsPlatform_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_DataServices_Data_A0FF_SystemConfigParameter_E_NOT_OK (1U)

# define RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_DCM_E_PENDING (10U)

# define RTE_E_DataServices_Data_C0DE_ECU_Configuration_at_EOL_Read_E_NOT_OK (1U)

# define RTE_E_IF_EOLInfo_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_EnvironmentParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_TAC2InitParams_ReturnType (1U)

# define RTE_E_IF_EYEQMESP_VehicleCalParams_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore1_APP_ReturnType (1U)

# define RTE_E_IF_FeatureConfig_ReturnType (1U)

# define RTE_E_IF_FeatureVehicle_ReturnType (1U)

# define RTE_E_IF_SetAppDiagFaultStatus_ReturnType (1U)

# define RTE_E_NvMService_AC3_SRBS_E_NOT_OK (1U)

# define RTE_E_NvMService_AC3_SRBS_DS_E_NOT_OK (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPUDSPLATFORM_H */
