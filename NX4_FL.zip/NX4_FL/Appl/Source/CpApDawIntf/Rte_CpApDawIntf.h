/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApDawIntf.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApDawIntf
 *  Generation Time:  2023-04-20 13:52:24
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApDawIntf> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPDAWINTF_H
# define _RTE_CPAPDAWINTF_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApDawIntf_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApDawIntf
{
  /* PIM Handles section */
  P2VAR(DawFrqNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DawFrqNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  P2VAR(DawOccNvData_t, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_DawOccNvData; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApDawIntf, RTE_CONST, RTE_CONST) Rte_Inst_CpApDawIntf; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApDawIntf, TYPEDEF, RTE_CONST) Rte_Instance;


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDawIntf_RP_NvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDawIntf_RP_NvMService_DawFrqNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDawIntf_RP_NvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApDawIntf_RP_NvMService_DawOccNvData_WriteBlock(dtRef_VOID SrcPtr); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_NvMService_DawFrqNvData_ReadBlock Rte_Call_CpApDawIntf_RP_NvMService_DawFrqNvData_ReadBlock
# define Rte_Call_RP_NvMService_DawFrqNvData_WriteBlock Rte_Call_CpApDawIntf_RP_NvMService_DawFrqNvData_WriteBlock
# define Rte_Call_RP_NvMService_DawOccNvData_ReadBlock Rte_Call_CpApDawIntf_RP_NvMService_DawOccNvData_ReadBlock
# define Rte_Call_RP_NvMService_DawOccNvData_WriteBlock Rte_Call_CpApDawIntf_RP_NvMService_DawOccNvData_WriteBlock


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_DawFrqNvData() (Rte_Inst_CpApDawIntf->Pim_DawFrqNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */

# define Rte_Pim_DawOccNvData() (Rte_Inst_CpApDawIntf->Pim_DawOccNvData) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   DawFrqNvData_t *Rte_Pim_DawFrqNvData(void)
 *   DawOccNvData_t *Rte_Pim_DawOccNvData(void)
 *
 *********************************************************************************************************************/


# define CpApDawIntf_START_SEC_CODE
# include "CpApDawIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApDawIntf_NvMNotifyJobFinished_DawFrqNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApDawIntf_NvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApDawIntf_NvMNotifyJobFinished_DawFrqNvData_JobFinished CpApDawIntf_NvMNotifyJobFinished_DawFrqNvData_JobFinished
FUNC(void, CpApDawIntf_CODE) CpApDawIntf_NvMNotifyJobFinished_DawFrqNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CpApDawIntf_NvMNotifyJobFinished_DawOccNvData_JobFinished
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <JobFinished> of PortPrototype <PP_NvMNotifyJobFinished_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void CpApDawIntf_NvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_RequestResultType JobResult)
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_CpApDawIntf_NvMNotifyJobFinished_DawOccNvData_JobFinished CpApDawIntf_NvMNotifyJobFinished_DawOccNvData_JobFinished
FUNC(void, CpApDawIntf_CODE) CpApDawIntf_NvMNotifyJobFinished_DawOccNvData_JobFinished(NvM_RequestResultType JobResult); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDawIntfInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <TRUE> of ModeDeclarationGroupPrototype <ProxyCore2Ready_QM> of PortPrototype <ProxyCore2Ready_QM>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_DawFrqNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_DawOccNvData_ReadBlock(dtRef_VOID DstPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDawIntfInit Re_CpApDawIntfInit
FUNC(void, CpApDawIntf_CODE) Re_CpApDawIntfInit(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApDawIntfMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_NvMService_DawFrqNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *   Std_ReturnType Rte_Call_RP_NvMService_DawOccNvData_WriteBlock(dtRef_VOID SrcPtr)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_Proxy_NvMServices_E_NOK, RTE_E_IF_Proxy_NvMServices_E_OK
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApDawIntfMain Re_CpApDawIntfMain
FUNC(void, CpApDawIntf_CODE) Re_CpApDawIntfMain(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DawFrqNvDataRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <DawFrqNvDataRead> of PortPrototype <PP_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DawFrqNvDataRead(DawFrqNvData_t *DawFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_DawFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_DawFrqNvDataRead Re_DawFrqNvDataRead
FUNC(Std_ReturnType, CpApDawIntf_CODE) Re_DawFrqNvDataRead(P2VAR(DawFrqNvData_t, AUTOMATIC, RTE_CPAPDAWINTF_APPL_VAR) DawFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DawFrqNvDataWrite
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <DawFrqNvDataWrite> of PortPrototype <PP_DawFrqNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DawFrqNvDataWrite(const DawFrqNvData_t *DawFrqNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_DawFrqNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_DawFrqNvDataWrite Re_DawFrqNvDataWrite
FUNC(Std_ReturnType, CpApDawIntf_CODE) Re_DawFrqNvDataWrite(P2CONST(DawFrqNvData_t, AUTOMATIC, RTE_CPAPDAWINTF_APPL_DATA) DawFrqNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DawOccNvDataRead
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <DawOccNvDataRead> of PortPrototype <PP_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DawOccNvDataRead(DawOccNvData_t *DawOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_DawOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_DawOccNvDataRead Re_DawOccNvDataRead
FUNC(Std_ReturnType, CpApDawIntf_CODE) Re_DawOccNvDataRead(P2VAR(DawOccNvData_t, AUTOMATIC, RTE_CPAPDAWINTF_APPL_VAR) DawOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_DawOccNvDataWrite
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <DawOccNvDataWrite> of PortPrototype <PP_DawOccNvData>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_DawOccNvDataWrite(const DawOccNvData_t *DawOccNvData)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_DawOccNvData_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_DawOccNvDataWrite Re_DawOccNvDataWrite
FUNC(Std_ReturnType, CpApDawIntf_CODE) Re_DawOccNvDataWrite(P2CONST(DawOccNvData_t, AUTOMATIC, RTE_CPAPDAWINTF_APPL_DATA) DawOccNvData); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApDawIntf_STOP_SEC_CODE
# include "CpApDawIntf_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_DawFrqNvData_ReturnType (1U)

# define RTE_E_IF_DawOccNvData_ReturnType (1U)

# define RTE_E_IF_Proxy_NvMServices_E_NOK (1U)

# define RTE_E_IF_Proxy_NvMServices_E_OK (0U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPDAWINTF_H */
