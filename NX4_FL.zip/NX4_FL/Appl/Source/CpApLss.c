/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApLss.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApLss
 *  Generation Time:  2023-04-20 13:53:23
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApLss>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * TimeInMicrosecondsType
 *   uint32 represents integers with a minimum value of 0 and a maximum value 
 *      of 4294967295. The order-relation on uint32 is: x < y if y - x is positive.
 *      uint32 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39). 
 *      
 *      For example: 1, 0, 12234567, 104400.
 *
 *
 * Operation Prototypes:
 * =====================
 * GetCounterValue of Port Interface Os_Service
 *   This service reads the current count value of a counter (returning either the hardware timer ticks if counter is driven by hardware or the software ticks when user drives counter).
 *
 * GetElapsedValue of Port Interface Os_Service
 *   This service gets the number of ticks between the current tick value and a previously read tick value.
 *
 *
 * Mode Declaration Groups:
 * ========================
 * WdgM_Mode
 *   The mode declaration group WdgMMode represents the modes of the Watchdog Manager module that will be notified to the SW-Cs / CDDs and the RTE.
 *
 *********************************************************************************************************************/

#include "Rte_CpApLss.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * TimeInMicrosecondsType: Integer in interval [0...4294967295]
 * boolean: Boolean (standard type)
 * float32: Real in interval [-FLT_MAX...FLT_MAX] with single precision (standard type)
 * sint16: Integer in interval [-32768...32767] (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint32: Integer in interval [0...4294967295] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * CANmsg_t: Record with elements
 *   u8_FCA_SysFlrSta of type uint8
 *   u8_ADAS_ActToiSta of type uint8
 *   u8_LKA_LHLnWrnSta of type uint8
 *   u8_LKA_RcgSta of type uint8
 *   u8_LKA_RHLnWrnSta of type uint8
 *   u8_LKA_SysIndReq of type uint8
 *   u8_Lamp_HbaCtrlModTyp of type uint8
 *   u8_Wiper_PrkngPosSta of type uint8
 *   u8_CTM_TrailerAct of type uint8
 *   u16_CLU_DisSpdVal of type uint16
 *   u8_CLU_DisSpdDcmlVal of type uint8
 *   u8_CLU_SpdUnitTyp of type uint8
 *   u8_SWRC_CrsMainSwSta of type uint8
 *   u8_SWRC_CrsSwSta of type uint8
 *   u8_SWRC_SldMainSwSta of type uint8
 *   u8_CLU_DrvngModSwSta of type uint8
 *   u8_CLU_IceWrnIndSta of type uint8
 *   u8_USM_AdasISLASetReq of type uint8
 *   u8_USM_ISLAOffstSetReq of type uint8
 *   u8_USM_AdasISLANAOffstSetReq of type uint8
 *   u8_USM_AdasFCAFrSetReq of type uint8
 *   u8_USM_AdasLKA2SetReq of type uint8
 *   u8_USM_AdasHDASetReq of type uint8
 *   u8_USM_AdasISLWSetReq of type uint8
 *   u8_USM_AdasLVDASetReq of type uint8
 *   u8_USM_AdasNSCCCamSetReq of type uint8
 *   u8_USM_AdasSCCDrvModSetReq of type uint8
 *   u8_USM_AdasUSMResetReq of type uint8
 *   u8_USM_AdasWarnTimeSetReq of type uint8
 *   u8_USM_AdasSCCMLResetReq of type uint8
 *   u8_USM_AdasSCCMLChar1SetReq of type uint8
 *   u8_USM_AdasSCCMLChar2SetReq of type uint8
 *   u8_USM_AdasSCCMLChar3SetReq of type uint8
 *   u8_USM_AdasHbaSetReq of type uint8
 *   u8_USM_AdasLkaModSetReq of type uint8
 *   u8_USM_AdasISLAEUCntry1SetReq of type uint8
 *   u8_USM_AdasISLAEUCntryTglReq of type uint8
 *   u8_USM_AdasISLANACntry1SetReq of type uint8
 *   u8_USM_AdasISLANACntryTglReq of type uint8
 *   u8_HDP_ActvSta of type uint8
 *   u16_VehSpdLimVal of type uint16
 *   u16_ENG_EngSpdVal of type uint16
 *   u8_ACC_CrsSetSwLmpSta of type uint8
 *   u8_HCU_CrsCtrlOnLmpDis of type uint8
 *   u8_HCU_CrsCtrlSetLmpDis of type uint8
 *   u8_ESC_DrvBrkActvSta of type uint8
 *   u8_ENG_IsgSta of type uint8
 *   u8_ENG_SldFuncSta of type uint8
 *   u8_HCU_SpdLimDeviceActSta of type uint8
 *   u8_ENG_SldSwSta of type uint8
 *   u8_HCU_SpdLimDeviceOperSta of type uint8
 *   u16_AccelPdlVal of type uint16
 *   u8_ENG_AppAccelPdlSta of type uint8
 *   u8_ENG_EngSta of type uint8
 *   u8_HCU_HevRdySta of type uint8
 *   u8_EMS_SCCIsgEna of type uint8
 *   u8_CF_ECU_SSC_STAT of type uint8
 *   u8_EPB_SwPosSta of type uint8
 *   u8_EPB_FrcSta of type uint8
 *   u8_ABS_ActvSta of type uint8
 *   u8_ABS_DiagSta of type uint8
 *   u8_AVH_Sta of type uint8
 *   u8_ESC_Sta of type uint8
 *   u8_ESC_CylPrsrSta of type uint8
 *   u16_ESC_CylPrsrVal of type uint16
 *   s16_IEB_StrkDpthmmVal of type sint16
 *   u8_ESC_VsmActvSta of type uint8
 *   u8_TCS_Sta of type uint8
 *   u8_ESC_OffTempSta of type uint8
 *   u8_ESC_DrvOvrdSta of type uint8
 *   u8_ESC_PrkBrkActvSta of type uint8
 *   u8_ESC_StdStillVal of type uint8
 *   u8_FCA_AvlblSta of type uint8
 *   u8_FCA_EquipSta of type uint8
 *   u8_SCC_EnblReq of type uint8
 *   u8_HU_NaviCamSettingStatus of type uint8
 *   u8_HU_NaviStatus of type uint8
 *   u8_HU_AliveStatus of type uint8
 *   u8_HU_AdasSupport of type uint8
 *   u8_HU_DistributeInfo of type uint8
 *   u8_HU_Type of type uint8
 *   u16_HU_OptionInfo of type uint16
 *   u16_Navi_ISLW_CountryCode of type uint16
 *   u8_Navi_ISLW_Frwinfo of type uint8
 *   u8_Navi_ISLW_LinkClass of type uint8
 *   u8_Navi_ISLW_MapSource of type uint8
 *   u8_Navi_ISLW_SpdLimit of type uint8
 *   u8_Navi_ISLW_SpdUnit of type uint8
 *   u8_Navi_ISLW_TimeSpd of type uint8
 *   u8_Navi_ISLW_TollExist of type uint8
 *   u8_Navi_ISLW_TunnelExist of type uint8
 *   u8_POS_CyclicCounter of type uint8
 *   u16_POS_Offset of type uint16
 *   u16_POS_RangeAvgSpeed of type uint16
 *   u8_POS_PathIndex of type uint8
 *   u8_POS_CurrAltitude100m of type uint8
 *   u8_POS_CurrAltitude1m of type uint8
 *   u8_POS_CurrFuncRoadClass of type uint8
 *   u8_POS_CurrFormOfWay of type uint8
 *   u8_POS_CurrDirectionLanes of type uint8
 *   u8_POS_CurrSpeedLimit of type uint8
 *   u8_POS_CurrTrafficSpeed of type uint8
 *   u8_PROLONG_CyclicCounter of type uint8
 *   u16_PROLONG_Offset of type uint16
 *   u8_PROLONG_ProfileType of type uint8
 *   u8_PROLONG_Update of type uint8
 *   u32_PROLONG_Value of type uint32
 *   u8_PROLONG_PathIndex of type uint8
 *   u8_PROSHORT_CyclicCounter of type uint8
 *   u16_PROSHORT_Distance of type uint16
 *   u16_PROSHORT_Offset of type uint16
 *   u8_PROSHORT_ProfileType of type uint8
 *   u16_PROSHORT_Value0 of type uint16
 *   u16_PROSHORT_Value1 of type uint16
 *   u8_PROSHORT_PathIndex of type uint8
 *   u8_PROSHORT_Accuracy of type uint8
 *   u8_SEG_CalculatedRoute of type uint8
 *   u8_SEG_CyclicCounter of type uint8
 *   u8_SEG_DirectionLanes of type uint8
 *   u8_SEG_FormOfWay of type uint8
 *   u8_SEG_FuncRoadClass of type uint8
 *   u16_SEG_Offset of type uint16
 *   u8_SEG_Retransmission of type uint8
 *   u8_SEG_SpeedLimit of type uint8
 *   u8_SEG_SpeedLimitUnder5 of type uint8
 *   u8_SEG_PathIndex of type uint8
 *   u8_Warn_AsstDrSwSta of type uint8
 *   u8_Warn_DrvDrSwSta of type uint8
 *   u8_Warn_DrvStBltSwSta of type uint8
 *   u8_Warn_RrLftDrSwSta of type uint8
 *   u8_Warn_RrRtDrSwSta of type uint8
 *   u8_ExtLamp_HzrdSwSta of type uint8
 *   u8_Lamp_TrnSigLmpLftActiveSt of type uint8
 *   u8_Lamp_TrnSigLmpRtActiveSt of type uint8
 *   u8_ExtLamp_TrnSigLmpLftSwSta of type uint8
 *   u8_ExtLamp_TrnSigLmpRtSwSta of type uint8
 *   u8_MDPS_LkaToiUnblSta of type uint8
 *   u8_MDPS_LkaToiFltSta of type uint8
 *   u16_MDPS_StrTqSnsrVal of type uint16
 *   u8_MDPS_LkaToiActvSta of type uint8
 *   s16_SAS_AnglVal of type sint16
 *   u8_SAS_IntSta of type uint8
 *   u8_SAS_SpdVal of type uint8
 *   u8_SWRC_LFASwSta of type uint8
 *   u8_GearSlctDis of type uint8
 *   u16_WHL_SpdFLVal of type uint16
 *   u16_WHL_SpdFRVal of type uint16
 *   u16_WHL_SpdRLVal of type uint16
 *   u16_WHL_SpdRRVal of type uint16
 *   u8_WHL_PlsFLVal of type uint8
 *   u8_WHL_PlsFRVal of type uint8
 *   u8_WHL_PlsRLVal of type uint8
 *   u8_WHL_PlsRRVal of type uint8
 *   u8_YRS_YawSigSta of type uint8
 *   u8_YRS_LatAccelSigSta of type uint8
 *   u8_YRS_LongAccelSigSta of type uint8
 *   u8_YRS_AcuRstSta of type uint8
 *   u16_YRS_YawRtVal of type uint16
 *   u16_YRS_LatAccelVal of type uint16
 *   u16_YRS_LongAccelVal of type uint16
 *   u8_ICU_MtGearPosRSta of type uint8
 *   u8_FCA_FrOnOffEquipSta of type uint8
 *   u8_SCC_OpSta of type uint8
 *   u8_SCC_InfoDis of type uint8
 *   u8_SCC_ObjSta of type uint8
 *   u8_SCC_TrgtSpdSetVal of type uint8
 *   u8_SCC_MainOnOffSta of type uint8
 *   u8_SCC_SysFlrSta of type uint8
 *   u8_RSPA_Sta of type uint8
 *   u8_RSPA_Actv of type uint8
 *   u8_ESC_RspaSta of type uint8
 *   u8_DMIC_IndEngModSta of type uint8
 *   u8_MDPS_PaModeSta of type uint8
 *   u8_META_Country_OptADAS of type uint8
 *   u8_META_CyclicCounter of type uint8
 *   u8_ENG_TransmsnTyp of type uint8
 *   u8_HCU_SccEnblSta of type uint8
 *   u8_ESC_IMURstStaAck of type uint8
 *   u8_IAU_ProfileIDRVal of type uint8
 *   u8_CF_AVN_ProfileIDRValue of type uint8
 *   u8_ICC_WarningStat of type uint8
 *   u8_ICC_DistLvlStat of type uint8
 *   u8_ICC_IntvStat of type uint8
 *   u8_ICC_IntvSDLvlStat of type uint8
 *   u8_ICC_IntvDrwsLvlStat of type uint8
 *   u8_ICC_SymStat of type uint8
 *   u8_Haptic_USMCurState_OnOff of type uint8
 *   u8_USM_AdasLKAWrngVolSetReq of type uint8
 *   u8_USM_CluAdasVolSta of type uint8
 *   u8_DATC_OutTempDispC of type uint8
 *   u8_DATC_OutTempDispF of type uint8
 *   u8_CF_AVN_LKAWrngVolNvalueSet of type uint8
 *   u8_ICC_WarningSmblDistStat of type uint8
 *   u8_ICC_WarningSndStat of type uint8
 *   u8_ICC_WarningSnd2Stat of type uint8
 *   u8_ICC_AoIStat of type uint8
 *   u8_Navi_ISLA_TImeZone of type uint8
 * CoFcaInternalInFromLSS_t: Record with elements
 *   LSS_TrlrOffDispSta of type uint8
 * DawOutToLss_t: Record with elements
 *   u8_Daw_CF_LKA_HandsOff_Snd of type uint8
 * DeLogicDbgInput_t: Record with elements
 *   u32_DbgDataIn_01 of type uint32
 *   u32_DbgDataIn_02 of type uint32
 *   u32_DbgDataIn_03 of type uint32
 *   u32_DbgDataIn_04 of type uint32
 *   u32_DbgDataIn_05 of type uint32
 *   u32_DbgDataIn_06 of type uint32
 *   u32_DbgDataIn_07 of type uint32
 *   u32_DbgDataIn_08 of type uint32
 *   u32_DbgDataIn_09 of type uint32
 *   u32_DbgDataIn_10 of type uint32
 *   u32_DbgDataIn_11 of type uint32
 *   u32_DbgDataIn_12 of type uint32
 *   u32_DbgDataIn_13 of type uint32
 *   u32_DbgDataIn_14 of type uint32
 *   u32_DbgDataIn_15 of type uint32
 *   u32_DbgDataIn_16 of type uint32
 * DeLogicDbgOutput_t: Record with elements
 *   u32_DbgData_01 of type uint32
 *   u32_DbgData_02 of type uint32
 *   u32_DbgData_03 of type uint32
 *   u32_DbgData_04 of type uint32
 *   u32_DbgData_05 of type uint32
 *   u32_DbgData_06 of type uint32
 *   u32_DbgData_07 of type uint32
 *   u32_DbgData_08 of type uint32
 *   u32_DbgData_09 of type uint32
 *   u32_DbgData_10 of type uint32
 *   u32_DbgData_11 of type uint32
 *   u32_DbgData_12 of type uint32
 *   u32_DbgData_13 of type uint32
 *   u32_DbgData_14 of type uint32
 *   u32_DbgData_15 of type uint32
 *   u32_DbgData_16 of type uint32
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * FailSafe_t: Record with elements
 *   FS_CRC of type uint32
 *   FS_Camera_ID of type uint8
 *   FS_Free_Sight of type boolean
 *   FS_Splashes of type uint8
 *   FS_Sun_Ray of type uint8
 *   FS_Low_Sun of type uint8
 *   FS_Blur_Image of type uint8
 *   FS_Partial_Blockage of type uint8
 *   FS_Full_Blockage of type uint8
 *   FS_Frozen_Windshield_Lens of type uint8
 *   FS_Out_Of_Focus of type uint8
 *   FS_C2C_Out_Of_Calib of type uint8
 * FcaInternalInFromLSS_t: Record with elements
 *   LSS_TrlrOffDispSta of type uint8
 * FeatureConfig_t: Record with elements
 *   u8_CANDbgMsg of type uint8
 *   u8_CANDbgMode of type uint8
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   b_HBA_TestMode of type boolean
 *   b_ISLA_TestMode of type boolean
 *   u8_reserved3 of type uint8
 *   u8_reserved4 of type uint8
 * FeatureVehicle_t: Record with elements
 *   u16_NVM_r_VehicleWidth of type uint16
 *   u8_reserved0 of type uint8
 *   u8_reserved1 of type uint8
 *   u8_CAN_Type of type uint8
 *   u8_VehicleType of type uint8
 *   u8_reserved2 of type uint8
 *   u8_reserved3 of type uint8
 * FrCmrHdrLDW_t: Record with elements
 *   LDW_Protocol_Version of type uint8
 *   LDW_Sync_ID of type uint8
 * FrCmrHdrLnHost_t: Record with elements
 *   LH_Protocol_Version of type uint8
 *   LH_Sync_ID of type uint8
 *   LH_Lanes_Count of type uint8
 *   LH_Estimated_Width of type uint16
 * FrCmrHdrLnRdEdg_t: Record with elements
 *   LRE_Header_CRC of type uint32
 *   LRE_Protocol_Version of type uint8
 *   LRE_Sync_ID of type uint8
 *   LRE_Count of type uint8
 * FrCmrHdrObj_t: Record with elements
 *   OBJ_Header_CRC of type uint32
 *   OBJ_Protocol_Version of type uint8
 *   OBJ_Sync_ID of type uint8
 *   OBJ_VRU_Count of type uint8
 *   OBJ_VD_Count of type uint8
 *   OBJ_General_OBJ_Count of type uint8
 *   OBJ_Animal_Count of type uint8
 *   OBJ_VD_NIV_Left of type uint8
 *   OBJ_VD_NIV_Right of type uint8
 *   OBJ_VD_CIPV_ID of type uint8
 *   OBJ_VD_CIPV_Lost of type uint8
 *   OBJ_VD_Allow_Acc of type uint8
 *   OBJ_Is_Blocked_Left of type boolean
 *   OBJ_Is_Blocked_Right of type boolean
 * LDW_t: Record with elements
 *   LDW_Suppression_Reason_Left of type uint32
 *   LDW_Suppression_Reason_Right of type uint32
 *   LDW_Time_To_Warning_Left of type float32
 *   LDW_Time_To_Warning_Right of type float32
 *   LDW_Warning_Status_Left of type uint8
 *   LDW_Warning_Status_Right of type uint8
 * LanesHost_t: Record with elements
 *   LH_CRC of type uint32
 *   LH_Is_Triggered_SDM_Type of type uint8
 *   LH_Is_Triggered_SDM_Model of type uint8
 *   LH_Track_ID of type uint8
 *   LH_Age of type uint8
 *   LH_Confidence of type uint8
 *   LH_Prediction_Reason of type uint8
 *   LH_Availability_State of type uint8
 *   LH_Color of type uint8
 *   LH_Color_Confidence of type uint8
 *   LH_Lanemark_Type of type uint8
 *   LH_DLM_Type of type uint8
 *   LH_DECEL_Type of type uint8
 *   LH_Lanemark_Type_Conf of type uint8
 *   LH_Side of type uint8
 *   LH_Crossing of type boolean
 *   LH_Marker_Width of type uint8
 *   LH_Marker_Width_STD of type uint8
 *   LH_Dash_Average_Available of type boolean
 *   LH_Dash_Average_Length of type uint8
 *   LH_Dash_Average_Gap of type uint8
 *   LH_Is_Multi_Clothoid of type boolean
 *   LH_Line_First_C0 of type float32
 *   LH_Line_First_C1 of type float32
 *   LH_Line_First_C2 of type float32
 *   LH_Line_First_C3 of type float32
 *   LH_First_VR_Start of type uint16
 *   LH_First_VR_End of type uint16
 *   LH_First_Measured_VR_End of type uint16
 *   LH_Second_Measured_VR_End of type uint16
 *   LH_Line_Second_C0 of type float32
 *   LH_Line_Second_C1 of type float32
 *   LH_Line_Second_C2 of type float32
 *   LH_Line_Second_C3 of type float32
 *   LH_Second_VR_Start of type uint16
 *   LH_Second_VR_End of type uint16
 *   LH_Is_Construction_Area of type boolean
 * LanesRoadEdge_t: Record with elements
 *   LRE_Element_CRC of type uint32
 *   LRE_ID of type uint8
 *   LRE_Age of type uint8
 *   LRE_Confidence of type uint8
 *   LRE_Type of type uint8
 *   LRE_Prediction_Reason of type uint8
 *   LRE_Availability_State of type uint8
 *   LRE_Height of type uint8
 *   LRE_Height_STD of type uint8
 *   LRE_View_Range_Start of type uint16
 *   LRE_View_Range_End of type uint16
 *   LRE_Measured_VR_End of type uint16
 *   LRE_Side of type uint8
 *   LRE_Is_Triggered_SDM_Model of type uint8
 *   LRE_Line_C3 of type float32
 *   LRE_Line_C2 of type float32
 *   LRE_Line_C1 of type float32
 *   LRE_Line_C0 of type float32
 *   LRE_Position of type uint8
 * LssAppVersionInfo_t: Record with elements
 *   u16_LssAppVersion of type uint16
 * LssCanSigFailSafeInfo_t: Record with elements
 *   b_OverrideDTCforCal of type uint8
 *   b_OverrideDTC of type uint8
 *   b_LfaFail of type uint8
 *   b_Navi_Fault of type uint8
 *   b_HDA_Fault of type uint8
 *   b_LdwFail of type uint8
 *   b_LkaFail of type uint8
 *   b_LkaHwSwFail of type uint8
 *   b_CMRTempSta of type uint8
 *   b_BlockageSta of type uint8
 * LssFrqNvData_t: Record with elements
 *   s16_NVM_r_SteerWhlAgOffs of type sint16
 *   s16_NVM_r_YawRateOffs of type sint16
 *   s16_NVM_r_StrColTqOffs of type sint16
 *   s16_Nvm_Rom_HdngAngOffset of type sint16
 *   u8_NVM_r_LkasUsmOpt of type uint8
 *   u8_NVM_r_LkasUsmOptDelay of type uint8
 *   u8_NVM_r_LFA_Opt_USM of type uint8
 *   u8_Rom_SysOff of type uint8
 *   u8_NVM_LKA_Status of type uint8
 *   u8_NVM_LFA_Status of type uint8
 *   u8_NVM_HdaStatus_User1 of type uint8
 *   u8_NVM_HdaStatus_User2 of type uint8
 *   u8_NVM_HdaStatus_Guest of type uint8
 *   u8_NVM_ProfileIDRVal of type uint8
 *   u8_NVM_WarnSndUSMSta of type uint8
 *   Reserved of type uint8
 * LssInput_t: Record with elements
 *   b_Uds_LdwFuncValidCmd of type uint8
 *   u8_FCA_Status of type uint8
 *   u8_FCA_FailInfo of type uint8
 *   u8_ACCMode of type uint8
 *   u8_SCC_InfoDisplay of type uint8
 *   u8_SCC_VSetDis of type uint8
 *   u8_SCC_MainMode_ACC of type uint8
 *   u8_SCC_ACCFailInfo of type uint8
 * LssMeInfo_t: Record with elements
 *   b_MEFailSafeLKA of type uint8
 *   u8_DrivingSideME of type uint8
 * LssMrmUxOutToIvc_t: Record with elements
 *   u8_ux_PU_F_Group1_ADASWarn1_2Sta_MRM of type uint8
 * LssOutput_t: Record with elements
 *   u8_LKA_CF_Lkas_ActToi of type uint8
 *   u8_LKA_CF_Lkas_SysWarning of type uint8
 *   u8_LKA_CF_Lkas_ToiFlt of type uint8
 *   u16_LKA_CR_Lkas_StrToqReq of type uint16
 *   u8_LKA_OnOffEquip2Sta of type uint8
 *   u8_CF_LKA_HandsOff_Snd of type uint8
 *   u8_CF_LKA_SymbolState of type uint8
 *   u8_LKA_WarnSndUSMSta of type uint8
 *   u8_CF_HDA_Opt_USM of type uint8
 *   u8_CF_HDA_Mode of type uint8
 *   u8_CF_HDA_InfoDisplay of type uint8
 *   u8_CF_HDA_LFA_SteeringState of type uint8
 *   u8_CF_LKA_LaneRecogState of type uint8
 *   u8_CF_HDA_InfoDisplay2 of type uint8
 *   u8_CF_HDA_LFA_Wrn_Snd of type uint8
 *   u8_CF_LKA_LHWarning of type uint8
 *   u8_CF_LKA_RHWarning of type uint8
 *   u8_ADAS_Damping_Gain of type uint8
 *   u8_LKA_EmergencyRampDown of type uint8
 *   u8_CF_HDA_TDMRMDecelReq of type uint8
 * LssUxOutToIvc_t: Record with elements
 *   ux_TT_LnSftySymbSta of type uint8
 *   ux_SMV_HDA_SymbSta of type uint8
 *   ux_SMV_LFA_SymbSta of type uint8
 *   ux_MV_DrvLnCtLnSta of type uint8
 *   ux_MV_LtLnSta_LKA of type uint8
 *   ux_MV_LtLnSta_LFA of type uint8
 *   ux_MV_RtLnSta_LKA of type uint8
 *   ux_MV_RtLnSta_LFA of type uint8
 *   ux_MV_HostVeh1Sta_LKA of type uint8
 *   ux_MV_HostVeh1Sta_LFA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_LKA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_LFA of type uint8
 *   ux_PU_F_Group1_ADASWarn1_2Sta_HDA of type uint8
 *   ux_PU_F_Group7_LnSftyFlrSta of type uint8
 *   ux_PU_F_Group7_LFA_FlrSta of type uint8
 *   ux_PU_F_Group7_HDA_FlrSta of type uint8
 *   ux_LKA_SND_ADASWarn1_2Sta of type uint8
 *   ux_LFA_SND_ADASWarn1_2Sta of type uint8
 *   ux_HDA_SND_ADASWarn1_2Sta of type uint8
 *   ux_LFA_SND_ADASWarn1_4Sta of type uint8
 *   ux_SND_ADASWarn1_5Sta of type uint8
 *   ux_HPT_StrWhlWarn1Sta_LKA of type uint8
 * Objects_t: Record with elements
 *   OBJ_CRC of type uint32
 *   OBJ_ID of type uint8
 *   OBJ_VD_CIPVFlag of type uint8
 *   OBJ_Existence_Probability of type uint8
 *   OBJ_Fusion_Source of type uint16
 *   OBJ_Triggered_SDM of type uint8
 *   OBJ_Motion_Category of type uint8
 *   OBJ_Object_Age of type uint16
 *   OBJ_Measuring_Status of type uint8
 *   OBJ_Object_Class of type uint8
 *   OBJ_Class_Probability of type uint8
 *   OBJ_Camera_Source of type uint8
 *   OBJ_Motion_Status of type uint8
 *   OBJ_Motion_Orientation of type uint8
 *   OBJ_Has_Cut_Lane of type boolean
 *   OBJ_Has_Cut_Path of type boolean
 *   OBJ_Brake_Light_Validity of type boolean
 *   OBJ_Brake_Light of type boolean
 *   OBJ_Turn_Indicator_Right of type boolean
 *   OBJ_Turn_Indicator_Left of type boolean
 *   OBJ_Turn_Indicator_Validity of type boolean
 *   OBJ_Right_Out_Of_Image of type boolean
 *   OBJ_Left_Out_Of_Image of type boolean
 *   OBJ_Right_Out_Of_Image_V of type boolean
 *   OBJ_Left_Out_Of_Image_V of type boolean
 *   OBJ_Top_Out_Of_Image of type boolean
 *   OBJ_Bottom_Out_Of_Image of type boolean
 *   OBJ_Top_Out_Of_Image_V of type boolean
 *   OBJ_Bottom_Out_Of_Image_V of type boolean
 *   OBJ_Lane_Assignment of type uint8
 *   OBJ_Lane_Assignment_V of type boolean
 *   OBJ_Age_Seconds of type uint8
 *   OBJ_Age_Seconds_V of type boolean
 *   OBJ_Width of type uint16
 *   OBJ_Width_V of type boolean
 *   OBJ_Width_STD of type uint16
 *   OBJ_Width_STD_V of type boolean
 *   OBJ_Length of type uint16
 *   OBJ_Length_V of type boolean
 *   OBJ_Length_STD of type uint16
 *   OBJ_Length_STD_V of type boolean
 *   OBJ_Height of type uint16
 *   OBJ_Height_V of type boolean
 *   OBJ_Height_STD of type uint16
 *   OBJ_Height_STD_V of type boolean
 *   OBJ_Abs_Long_Velocity of type uint16
 *   OBJ_Abs_Long_Velocity_V of type boolean
 *   OBJ_Abs_Long_Velocity_STD of type uint16
 *   OBJ_Abs_Long_Vel_STD_V of type boolean
 *   OBJ_Abs_Lat_Velocity of type uint16
 *   OBJ_Abs_Lat_Velocity_V of type boolean
 *   OBJ_Abs_Lat_Velocity_STD of type uint16
 *   OBJ_Abs_Lat_Vel_STD_V of type boolean
 *   OBJ_Abs_Long_Acc of type uint16
 *   OBJ_Abs_Long_Acc_V of type boolean
 *   OBJ_Abs_Long_Acc_STD of type uint16
 *   OBJ_Abs_Long_Acc_STD_V of type boolean
 *   OBJ_Abs_Lat_Acc of type uint16
 *   OBJ_Abs_Lat_Acc_V of type boolean
 *   OBJ_Abs_Lat_Acc_STD of type uint16
 *   OBJ_Abs_Lat_Acc_STD_V of type boolean
 *   OBJ_Abs_Acceleration of type uint16
 *   OBJ_Abs_Acceleration_V of type boolean
 *   OBJ_Abs_Acc_STD of type uint16
 *   OBJ_Abs_Acc_STD_V of type boolean
 *   OBJ_Inv_TTC of type uint16
 *   OBJ_Inv_TTC_V of type boolean
 *   OBJ_Inv_TTC_STD of type uint16
 *   OBJ_Inv_TTC_STD_V of type boolean
 *   OBJ_Relative_Long_Acc of type uint16
 *   OBJ_Relative_Long_Acc_V of type boolean
 *   OBJ_Relative_Long_Acc_STD of type uint16
 *   OBJ_Rel_Long_Acc_STD_V of type boolean
 *   OBJ_Relative_Long_Velocity of type uint16
 *   OBJ_Relative_Long_Velocity_V of type boolean
 *   OBJ_Relative_Long_Vel_STD of type uint16
 *   OBJ_Rel_Long_Vel_STD_V of type boolean
 *   OBJ_Relative_Lat_Velocity of type uint16
 *   OBJ_Relative_Lat_Velocity_V of type boolean
 *   OBJ_Relative_Lat_Velocity_STD of type uint16
 *   OBJ_Rel_Lat_Vel_STD_V of type boolean
 *   OBJ_Long_Distance of type uint16
 *   OBJ_Long_Distance_V of type boolean
 *   OBJ_Long_Distance_STD of type uint16
 *   OBJ_Long_Distance_STD_V of type boolean
 *   OBJ_Lat_Distance of type uint16
 *   OBJ_Lat_Distance_V of type boolean
 *   OBJ_Lat_Distance_STD of type uint16
 *   OBJ_Lat_Distance_STD_V of type boolean
 *   OBJ_Absolute_Speed of type uint16
 *   OBJ_Absolute_Speed_V of type boolean
 *   OBJ_Absolute_Speed_STD of type uint16
 *   OBJ_Absolute_Speed_STD_V of type boolean
 *   OBJ_Heading of type uint16
 *   OBJ_Heading_V of type boolean
 *   OBJ_Heading_STD of type uint16
 *   OBJ_Heading_STD_V of type boolean
 *   OBJ_Angle_Rate_STD of type uint16
 *   OBJ_Angle_Rate_STD_V of type boolean
 *   OBJ_Angle_Rate of type uint16
 *   OBJ_Angle_Rate_V of type boolean
 *   OBJ_Angle_Right of type uint16
 *   OBJ_Angle_Right_V of type boolean
 *   OBJ_Angle_Right_STD of type uint16
 *   OBJ_Angle_Right_STD_V of type boolean
 *   OBJ_Angle_Left of type uint16
 *   OBJ_Angle_Left_V of type boolean
 *   OBJ_Angle_Left_STD of type uint16
 *   OBJ_Angle_Left_STD_V of type boolean
 *   OBJ_Angle_Side of type uint16
 *   OBJ_Angle_Side_V of type boolean
 *   OBJ_Angle_Side_STD of type uint16
 *   OBJ_Angle_Side_STD_V of type boolean
 *   OBJ_Angle_Mid_V of type boolean
 *   OBJ_Angle_Mid of type uint16
 *   OBJ_Angle_Mid_STD of type uint16
 *   OBJ_Angle_Mid_STD_V of type boolean
 *   OBJ_Angle_Bottom_V of type boolean
 *   OBJ_Angle_Bottom of type uint16
 *   OBJ_Angle_Bottom_STD of type uint16
 *   OBJ_Angle_Bottom_STD_V of type boolean
 *   OBJ_Visibility_Side_V of type boolean
 *   OBJ_Visibility_Side of type uint8
 *   OBJ_Is_In_Drivable_Area of type boolean
 *   OBJ_Is_In_Drivable_Area_V of type boolean
 *   OBJ_Is_VeryClose_V of type boolean
 *   OBJ_Is_VeryClose of type boolean
 *   OBJ_Is_EMERGENCY_VCL of type boolean
 *   OBJ_EMERGENCY_LIGHT_COLOR of type uint8
 *   OBJ_EMERGENCY_V of type boolean
 *   OBJ_Open_Door_Left of type boolean
 *   OBJ_Open_Door_Right of type boolean
 *   OBJ_Visible_Left_or_Right of type uint8
 *   OBJ_Visible_Left_or_Right_V of type boolean
 *   OBJ_2W_Is_Motorbike_Probability of type uint8
 *   OBJ_2W_Is_Bicycle_Probability of type uint8
 *   Obj_partially_in_lane of type boolean
 * SccInternalInFromLSS_t: Record with elements
 *   u8_Hands_On_Status of type uint8
 *   u8_LFA_Failure_Status of type uint8
 * ZfAppCameraState_t: Record with elements
 *   CameraState_u8 of type uint8
 *   Camera_SubState_u8 of type uint8
 *   Reserved1_u8 of type uint8
 *   Reserved2_u8 of type uint8
 *
 *********************************************************************************************************************/


#define CpApLss_START_SEC_CODE
#include "CpApLss_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssDebugOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput01_De_LssLogicDbgOutput01(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput02_De_LssLogicDbgOutput02(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput03_De_LssLogicDbgOutput03(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput04_De_LssLogicDbgOutput04(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput05_De_LssLogicDbgOutput05(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput06_De_LssLogicDbgOutput06(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput07_De_LssLogicDbgOutput07(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput08_De_LssLogicDbgOutput08(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput09_De_LssLogicDbgOutput09(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput10_De_LssLogicDbgOutput10(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput11_De_LssLogicDbgOutput11(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput12_De_LssLogicDbgOutput12(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput13_De_LssLogicDbgOutput13(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput14_De_LssLogicDbgOutput14(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput15_De_LssLogicDbgOutput15(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput16_De_LssLogicDbgOutput16(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput17_De_LssLogicDbgOutput17(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput18_De_LssLogicDbgOutput18(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput19_De_LssLogicDbgOutput19(const DeLogicDbgOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssLogicDbgOutput20_De_LssLogicDbgOutput20(const DeLogicDbgOutput_t *data)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssDebugOut_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssDebugOut(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssDebugOut
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <RP_ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureConfig_getFeatureConfig(FeatureConfig_t *FeatureConfig)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureConfig_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssFrqNvData_ReadLssFrqNvData(LssFrqNvData_t *LssFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssIsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2ZfAppCameraState_De_ZfAppCameraState(ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Read_RP_DawOutToLss_De_DawOutToLss(DawOutToLss_t *data)
 *   Std_ReturnType Rte_Read_RP_LssCanSigFailSafeInfo_De_LssCanSigFailSafeInfo(LssCanSigFailSafeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn01_De_LssDbgIn01(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn02_De_LssDbgIn02(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn03_De_LssDbgIn03(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn04_De_LssDbgIn04(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn05_De_LssDbgIn05(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssDbgIn06_De_LssDbgIn06(DeLogicDbgInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssInput_De_LssInput(LssInput_t *data)
 *   Std_ReturnType Rte_Read_RP_LssMeInfo_De_LssMeInfo(LssMeInfo_t *data)
 *   Std_ReturnType Rte_Read_RP_MrmUxOutToLss_De_MrmUxOutToIvc(LssMrmUxOutToIvc_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_CANmsg_getCanmsg(CANmsg_t *CANmsg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_CANmsg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FeatureVehicle_getFeatureVehicle(FeatureVehicle_t *FeatureVehicle)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FeatureVehicle_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrFS_getFrCmrFS(FailSafe_t *FrCmrFS)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrFS_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLDW_getFrCmrHdrLDW(FrCmrHdrLDW_t *FrCmrHdrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnHost_getFrCmrHdrLnHost(FrCmrHdrLnHost_t *FrCmrHdrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrLnRdEdg_getFrCmrHdrLnRdEdg(FrCmrHdrLnRdEdg_t *FrCmrHdrLnRdEdg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrLnRdEdg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrHdrObj_getFrCmrHdrObj(FrCmrHdrObj_t *FrCmrHdrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrHdrObj_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLDW_getFrCmrLDW(LDW_t *FrCmrLDW)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLDW_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnHost_getFrCmrLnHost(LanesHost_t *FrCmrLnHost)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnHost_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrLnRdEdg_getFrCmrLnRdEdg(LanesRoadEdge_t *FrCmrLnRdEdg)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrLnRdEdg_ReturnType
 *   Std_ReturnType Rte_Call_RP_FrCmrObj_getFrCmrObj(Objects_t *FrCmrObj)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_FrCmrObj_ReturnType
 *
 * Service Calls:
 * ==============
 *   Service Invocation:
 *   -------------------
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetCounterValue(TimeInMicrosecondsType *Value)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID
 *   Std_ReturnType Rte_Call_RP_Os_Service_GetElapsedValue(TimeInMicrosecondsType *Value, TimeInMicrosecondsType *ElapsedValue)
 *     Synchronous Service Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_Os_Service_E_OK, RTE_E_Os_Service_E_OS_ID, RTE_E_Os_Service_E_OS_VALUE
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIsp_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssIsp(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssIsp
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssLfa
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssLfa_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssLfa(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssLfa
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssLka
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssLka_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssLka(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssLka
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssOsp
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_CoFcaInternalInFromLSS_De_CoFcaInternalInFromLSS(const CoFcaInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Write_PP_FcaInternalInFromLSS_De_FcaInternalInFromLSS(const FcaInternalInFromLSS_t *data)
 *   Std_ReturnType Rte_Write_PP_LssOutput_De_LssOutput(const LssOutput_t *data)
 *   Std_ReturnType Rte_Write_PP_LssUxOutToIvc_De_LssUxOutToIvc(const LssUxOutToIvc_t *data)
 *   Std_ReturnType Rte_Write_PP_SccInternalInFromLSS_De_SccInternalInFromLSS(const SccInternalInFromLSS_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_LssFrqNvData_WriteLssFrqNvData(const LssFrqNvData_t *LssFrqNvData)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssFrqNvData_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssOsp_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApLss_CODE) Re_CpApLssOsp(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssOsp
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApLssVersionReq
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <AppVersionInfo> of PortPrototype <PP_LssAppVersionInfo>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApLssVersionReq(LssAppVersionInfo_t *LssAppVestionInfo)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssVersionReq_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(Std_ReturnType, CpApLss_CODE) Re_CpApLssVersionReq(P2VAR(LssAppVersionInfo_t, AUTOMATIC, RTE_CPAPLSS_APPL_VAR) LssAppVestionInfo) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApLssVersionReq (returns application error)
 *********************************************************************************************************************/

  return RTE_E_OK;

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApLss_STOP_SEC_CODE
#include "CpApLss_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/



#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApLssVersionInfo_doc)  ***************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApLssVersionInfo)  **************************/

  return RTE_E_OK;

/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApLssLdw_doc)  ***********************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApLssLdw)  **********************************/


/***  End of saved code  ************************************************************************************/
#endif


#if 0
/***  Start of saved code (symbol: documentation area:Re_CpApLssHda_doc)  ***********************************/


/***  End of saved code  ************************************************************************************/
#endif

#if 0
/***  Start of saved code (symbol: runnable implementation:Re_CpApLssHda)  **********************************/


/***  End of saved code  ************************************************************************************/
#endif

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
