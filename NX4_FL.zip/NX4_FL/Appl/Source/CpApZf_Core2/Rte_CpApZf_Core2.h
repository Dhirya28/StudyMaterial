/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CpApZf_Core2.h
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApZf_Core2
 *  Generation Time:  2023-04-20 13:53:01
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  Application header file for SW-C <CpApZf_Core2> (Contract Phase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CPAPZF_CORE2_H
# define _RTE_CPAPZF_CORE2_H

# ifdef RTE_APPLICATION_HEADER_FILE
#  error Multiple application header files included.
# endif
# define RTE_APPLICATION_HEADER_FILE
# ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#  define RTE_PTR2ARRAYBASETYPE_PASSING
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CpApZf_Core2_Type.h"
# include "Rte_DataHandleType.h"


/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

struct Rte_CDS_CpApZf_Core2
{
  /* PIM Handles section */
  P2VAR(ArrFrCmrFS, TYPEDEF, RTE_VAR_DEFAULT_RTE_PIM_GROUP) Pim_ArrFrCmrFS; /* PRQA S 0850 */ /* MD_MSR_19.8 */
  /* Vendor specific section */
};

# define RTE_START_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern CONSTP2CONST(struct Rte_CDS_CpApZf_Core2, RTE_CONST, RTE_CONST) Rte_Inst_CpApZf_Core2; /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CONST_UNSPECIFIED
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

typedef P2CONST(struct Rte_CDS_CpApZf_Core2, TYPEDEF, RTE_CONST) Rte_Instance;


/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

# define Rte_InitValue_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8 (0U)
# define Rte_InitValue_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus (0U)
# define Rte_InitValue_RP_EyeQ_FrameReady_FrameIndex (0U)
# define Rte_InitValue_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8 (0U)


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZf_Core2_RP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(P2VAR(IsMsgVaildObjtAEBStatus_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZf_Core2_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZf_Core2_RP_EyeQ_FrameReady_FrameIndex(P2VAR(uint32, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_CpApZf_Core2_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZf_Core2_PP_Core22Core1AppInfo_De_AppVersionInfo(P2CONST(Core2AppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZf_Core2_PP_Core2ZfAppCameraState_De_ZfAppCameraState(P2CONST(ZfAppCameraState_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_DATA) data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CpApZf_Core2_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_DawAppVersionInfo_AppVersionInfo(P2VAR(DawAppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) DawAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) APP_Main_State); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(P2VAR(uint16, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) isValid_pu16); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Blur_Image); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(P2VAR(uint16, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Buffer_C1); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_C2C_Out_Of_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_C2W_OOR); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, P2VAR(uint32, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Camera_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Cameras_Number); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Fog); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Free_Sight); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Frozen_Windshield_Lens); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Full_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(P2VAR(uint32, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Header_CRC); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(P2VAR(uint16, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Impacted_Technologies); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Low_Sun); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Out_Of_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Out_Of_Focus); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Partial_Blockage); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Protocol_Version); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Rain); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Splashes); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Sun_Ray); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_Sync_ID); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FS_TSR_Out_OF_Calib); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) MainState_pu8, P2VAR(uint8, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) SubState_pu8); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_HbaAppVersionInfo_AppVersionInfo(P2VAR(HbaAppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) HbaAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_IslwAppVersionInfo_AppVersionInfo(P2VAR(IslwAppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) IslwAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_IvcAppVersionInfo_AppVersionInfo(P2VAR(IvcAppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) IvcAppVersionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Call_CpApZf_Core2_RP_LssAppVersionInfo_AppVersionInfo(P2VAR(LssAppVersionInfo_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) LssAppVestionInfo); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */



/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Read_RP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus Rte_Read_CpApZf_Core2_RP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus
# define Rte_Read_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus Rte_Read_CpApZf_Core2_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus
# define Rte_Read_RP_EyeQ_FrameReady_FrameIndex Rte_Read_CpApZf_Core2_RP_EyeQ_FrameReady_FrameIndex
# define Rte_Read_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8 Rte_Read_CpApZf_Core2_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
# define Rte_Write_PP_Core22Core1AppInfo_De_AppVersionInfo Rte_Write_CpApZf_Core2_PP_Core22Core1AppInfo_De_AppVersionInfo
# define Rte_Write_PP_Core2ZfAppCameraState_De_ZfAppCameraState Rte_Write_CpApZf_Core2_PP_Core2ZfAppCameraState_De_ZfAppCameraState
# define Rte_Write_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8 Rte_Write_CpApZf_Core2_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (C/S invocation)
 *********************************************************************************************************************/
# define Rte_Call_RP_DawAppVersionInfo_AppVersionInfo Rte_Call_CpApZf_Core2_RP_DawAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1 Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID
# define Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib Rte_Call_CpApZf_Core2_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib
# define Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState Rte_Call_CpApZf_Core2_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState
# define Rte_Call_RP_HbaAppVersionInfo_AppVersionInfo Rte_Call_CpApZf_Core2_RP_HbaAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_IslwAppVersionInfo_AppVersionInfo Rte_Call_CpApZf_Core2_RP_IslwAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_IvcAppVersionInfo_AppVersionInfo Rte_Call_CpApZf_Core2_RP_IvcAppVersionInfo_AppVersionInfo
# define Rte_Call_RP_LssAppVersionInfo_AppVersionInfo Rte_Call_CpApZf_Core2_RP_LssAppVersionInfo_AppVersionInfo


/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

# define Rte_Pim_ArrFrCmrFS() (Rte_Inst_CpApZf_Core2->Pim_ArrFrCmrFS) /* PRQA S 3453 */ /* MD_MSR_19.7 */




/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Per-Instance Memory:
 * ====================
 *   ArrFrCmrFS *Rte_Pim_ArrFrCmrFS(void)
 *
 *********************************************************************************************************************/


# define CpApZf_Core2_START_SEC_CODE
# include "CpApZf_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_FrCmrFS
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrFS> of PortPrototype <PP_FrCmrFS>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZf_Core2_FrCmrFS(FailSafe_t *FrCmrFS)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrFS_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZf_Core2_FrCmrFS Re_CpApZf_Core2_FrCmrFS
FUNC(Std_ReturnType, CpApZf_Core2_CODE) Re_CpApZf_Core2_FrCmrFS(P2VAR(FailSafe_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FrCmrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_FrCmrHdrFS
 *
 * This runnable can be invoked concurrently (reentrant implementation).
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <getFrCmrHdrFS> of PortPrototype <PP_FrCmrHdrFS>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   Std_ReturnType Re_CpApZf_Core2_FrCmrHdrFS(FrCmrHdrFS_t *FrCmrHdrFS)
 *
 **********************************************************************************************************************
 *
 * Available Application Errors:
 * =============================
 *   RTE_E_IF_FrCmrHdrFS_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZf_Core2_FrCmrHdrFS Re_CpApZf_Core2_FrCmrHdrFS
FUNC(Std_ReturnType, CpApZf_Core2_CODE) Re_CpApZf_Core2_FrCmrHdrFS(P2VAR(FrCmrHdrFS_t, AUTOMATIC, RTE_CPAPZF_CORE2_APPL_VAR) FrCmrHdrFS); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on entering of Mode <True> of ModeDeclarationGroupPrototype <ProxyCore2Ready> of PortPrototype <ProxyCore2Ready>
 *
 **********************************************************************************************************************
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core22Core1AppInfo_De_AppVersionInfo(const Core2AppVersionInfo_t *data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DawAppVersionInfo_AppVersionInfo(DawAppVersionInfo_t *DawAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaAppVersionInfo_AppVersionInfo(HbaAppVersionInfo_t *HbaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwAppVersionInfo_AppVersionInfo(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssAppVersionInfo_AppVersionInfo(LssAppVersionInfo_t *LssAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZf_Core2_Init Re_CpApZf_Core2_Init
FUNC(void, CpApZf_Core2_CODE) Re_CpApZf_Core2_Init(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApZf_Core2_Main
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 5ms
 *     and not in Mode(s) <False>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_Core2IsMsgVaildObjtAEBStatus_IsMsgVaildObjtAEBStatus(IsMsgVaildObjtAEBStatus_t *data)
 *   Std_ReturnType Rte_Read_RP_Core2IsMsgValidLaneStatus_IsMsgValidLaneStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EyeQ_FrameReady_FrameIndex(uint32 *data)
 *   Std_ReturnType Rte_Read_RP_SR_EyeQCurrentMainState_EyeQCurrentMainState_u8(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Core22Core1AppInfo_De_AppVersionInfo(const Core2AppVersionInfo_t *data)
 *   Std_ReturnType Rte_Write_PP_Core2ZfAppCameraState_De_ZfAppCameraState(const ZfAppCameraState_t *data)
 *   Std_ReturnType Rte_Write_PP_Core2Zf_SendDefaultData_DefaultObjectData_u8(uint8 data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_DawAppVersionInfo_AppVersionInfo(DawAppVersionInfo_t *DawAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_DawAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_APP_EYEQDG_Get_APP_APP_Main_State(uint8 *APP_Main_State)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_APP_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_FLSF_IsMsgValid(uint16 *isValid_pu16)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Blur_Image(uint16 Index, uint8 *FS_Blur_Image)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Buffer_C1(uint16 *FS_Buffer_C1)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2C_Out_Of_Calib(uint16 Index, uint8 *FS_C2C_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_C2W_OOR(uint8 *FS_C2W_OOR)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_CRC(uint16 Index, uint32 *FS_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Camera_ID(uint16 Index, uint8 *FS_Camera_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Cameras_Number(uint8 *FS_Cameras_Number)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Fog(uint8 *FS_Fog)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Free_Sight(uint16 Index, uint8 *FS_Free_Sight)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Frozen_Windshield_Lens(uint16 Index, uint8 *FS_Frozen_Windshield_Lens)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Full_Blockage(uint16 Index, uint8 *FS_Full_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Header_CRC(uint32 *FS_Header_CRC)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Impacted_Technologies(uint16 *FS_Impacted_Technologies)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Low_Sun(uint16 Index, uint8 *FS_Low_Sun)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Calib(uint8 *FS_Out_Of_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Out_Of_Focus(uint16 Index, uint8 *FS_Out_Of_Focus)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Partial_Blockage(uint16 Index, uint8 *FS_Partial_Blockage)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Protocol_Version(uint8 *FS_Protocol_Version)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Rain(uint8 *FS_Rain)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Splashes(uint16 Index, uint8 *FS_Splashes)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sun_Ray(uint16 Index, uint8 *FS_Sun_Ray)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_Sync_ID(uint8 *FS_Sync_ID)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQCddSatCore2_FLSF_EYEQDG_Get_FLSF_FS_TSR_Out_OF_Calib(uint8 *FS_TSR_Out_OF_Calib)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType
 *   Std_ReturnType Rte_Call_RP_EyeQSatCore2_CoreSystemState_EyeQSYSS_CoreSystemState(uint8 *MainState_pu8, uint8 *SubState_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType
 *   Std_ReturnType Rte_Call_RP_HbaAppVersionInfo_AppVersionInfo(HbaAppVersionInfo_t *HbaAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_HbaAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IslwAppVersionInfo_AppVersionInfo(IslwAppVersionInfo_t *IslwAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IslwAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_IvcAppVersionInfo_AppVersionInfo(IvcAppVersionInfo_t *IvcAppVersionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_IvcAppVersionInfo_ReturnType
 *   Std_ReturnType Rte_Call_RP_LssAppVersionInfo_AppVersionInfo(LssAppVersionInfo_t *LssAppVestionInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_LssAppVersionInfo_ReturnType
 *
 *********************************************************************************************************************/

# define RTE_RUNNABLE_Re_CpApZf_Core2_Main Re_CpApZf_Core2_Main
FUNC(void, CpApZf_Core2_CODE) Re_CpApZf_Core2_Main(void); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define CpApZf_Core2_STOP_SEC_CODE
# include "CpApZf_Core2_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

# define RTE_E_IF_DawAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_APP_ReturnType (1U)

# define RTE_E_IF_EyeQCddSatCore2_FLSF_ReturnType (1U)

# define RTE_E_IF_EyeQSatCore2_CoreSystemState_ReturnType (1U)

# define RTE_E_IF_FrCmrFS_ReturnType (1U)

# define RTE_E_IF_FrCmrHdrFS_ReturnType (1U)

# define RTE_E_IF_HbaAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_IslwAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_IvcAppVersionInfo_ReturnType (1U)

# define RTE_E_IF_LssAppVersionInfo_ReturnType (1U)

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CPAPZF_CORE2_H */
