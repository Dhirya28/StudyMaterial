/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference..
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use..
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CpApPreCond.c
 *           Config:  O:/Application/ThirdParty/BSW/Dynamic/Config_Project/NX4_FL/CoreCam.dpa
 *        SW-C Type:  CpApPreCond
 *  Generation Time:  2023-04-20 13:53:24
 *
 *        Generator:  MICROSAR RTE Generator Version 4.20.0
 *                    RTE Core Version 1.20.0
 *          License:  CBD1900215
 *
 *      Description:  C-Code implementation template for SW-C <CpApPreCond>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_5.1_777, MD_MSR_5.1_779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CpApPreCond.h" /* PRQA S 0857 */ /* MD_MSR_1.1_857 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * CpApDiag_Status: Integer in interval [0...65535]
 * boolean: Boolean (standard type)
 * uint16: Integer in interval [0...65535] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Record Types:
 * =============
 * EOLInfo_t: Record with elements
 *   u8_EolProjYear of type uint8
 *   u8_EolSpecGroup of type uint8
 *   u8_EolDriveType of type uint8
 *   u8_EolBodyType of type uint8
 *   u8_EolTransAxle of type uint8
 *   u8_EolVehicleHeight of type uint8
 *   u8_EolRWS of type uint8
 *   u8_EolISG of type uint8
 *   u8_EolMDPSType of type uint8
 *   u8_EolLowBeamType of type uint8
 *   u8_EolSpdOdoUnit of type uint8
 *   u8_EolExtraRegion of type uint8
 *   u8_EolFCA of type uint8
 *   u8_EolLDWLKADAW of type uint8
 *   u8_EolLFA of type uint8
 *   u8_EolHBA of type uint8
 *   u8_EolSpeedLimit of type uint8
 *   u8_EolHDA of type uint8
 *   u8_EolSCC of type uint8
 *   u8_EolNSCC of type uint8
 *   u8_EolADASDRV of type uint8
 *   u8_EolBumperType of type uint8
 *   u8_EolCodingcomplete of type uint8
 *   U8_Resreved of type uint8
 * VCan_ENG_EngSta_t: Record with elements
 *   ENG_EngSta of type uint8
 * VCan_ENG_IsgSta_t: Record with elements
 *   ENG_IsgSta of type uint8
 *
 *********************************************************************************************************************/


#define CpApPreCond_START_SEC_CODE
#include "CpApPreCond_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApCommunicationControl
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered by server invocation for OperationPrototype <EnableDisableCommunication> of PortPrototype <PP_CpApEnableDisableCommunication>
 *
 **********************************************************************************************************************
 *
 * Runnable prototype:
 * ===================
 *   void Re_CpApCommunicationControl(uint8 arg)
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApCommunicationControl_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPreCond_CODE) Re_CpApCommunicationControl(uint8 arg) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApCommunicationControl
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondInit
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 **********************************************************************************************************************
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_EOLInfo_getEOLInfo(EOLInfo_t *EOLInfo)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_EOLInfo_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondInit_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPreCond_CODE) Re_CpApPreCondInit(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondInit
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondMain
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_RP_BattVoltRaw_De_BattVoltRaw(uint16 *data)
 *   Std_ReturnType Rte_Read_RP_CpApZfBattStatus_De_CpApZfBattStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_ECU_SSC_STAT_De_ECU_SSC_STAT(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_EMS01_EMS02_EMS03_AlvCRC_Status_De_EMS01_EMS02_EMS03_AlvCRC_Status(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_ENG_EngSta_De_VCan_ENG_EngSta(VCan_ENG_EngSta_t *data)
 *   Std_ReturnType Rte_Read_RP_ENG_IsgSta_De_VCan_ENG_IsgSta(VCan_ENG_IsgSta_t *data)
 *   Std_ReturnType Rte_Read_RP_HCU_HevRdySta_De_HCU_HevRdySta(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_PCan_BusOFFStatus_De_PCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 *data)
 *   Std_ReturnType Rte_Read_RP_VCan_BusOFFStatus_De_VCan_BusOFFStatus(uint8 *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PP_Eng3_Power9v_NoBusOFF_De_Eng3_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_De_Eng3_SccEng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng3_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_EnableCANDtc_De_Eng_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power10v_NoBusOFF_De_Eng_Power10v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power10v_NoBusOFF_EnableCANDtc_De_Eng_Power10v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_De_Eng_Power9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_NoBusOFF_De_Eng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_NoBusOFF_De_Eng_SccEng_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_De_Eng_SccEng_Power9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_De_Eng_SccEng_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc_De_Eng_SccEng_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_De_Eng_SccEng_Power9v_NoPBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Eng_SccEng_Power9v_NoPBusOFF_EnableCANDtc_De_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power10v_EnableCANDtc_De_Power10v_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power10v_NoBusOFF_EnableCANDtc_De_Power10v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_EnableCANDtc_De_Power9v_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_EnableCANDtc_VarCodNA_De_Power9v_EnableCANDtc_VarCodNA(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_De_Power9v_NoBusOFF(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_EnableCANDtc_De_Power9v_NoBusOFF_EnableCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_Power9v_NoBusOFF_EnablePCANDtc_De_Power9v_NoBusOFF_EnablePCANDtc(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_BattStatus_10v_De_PreCond_BattStatus_10v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_BattStatus_9v_De_PreCond_BattStatus_9v(uint8 data)
 *   Std_ReturnType Rte_Write_PP_PreCond_EngRunStatus_De_PreCond_EngRunStatus(uint8 data)
 *
 * Mode Interfaces:
 * ================
 *   uint8 Rte_Mode_DcmControlDtcSetting_DcmControlDtcSetting(void)
 *   Modes of Rte_ModeType_DcmControlDtcSetting:
 *   - RTE_MODE_DcmControlDtcSetting_DISABLEDTCSETTING
 *   - RTE_MODE_DcmControlDtcSetting_ENABLEDTCSETTING
 *   - RTE_TRANSITION_DcmControlDtcSetting
 *   uint8 Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Rx_BswM_MDGP_DNMT_VCAN_Rx(void)
 *   Modes of Rte_ModeType_DNMT_VCAN_Rx:
 *   - RTE_MODE_DNMT_VCAN_Rx_RX_DISABLE
 *   - RTE_MODE_DNMT_VCAN_Rx_RX_ENABLE
 *   - RTE_TRANSITION_DNMT_VCAN_Rx
 *   uint8 Rte_Mode_Switch_BswMSwitchPort_DNMT_VCAN_Tx_BswM_MDGP_DNMT_VCAN_Tx(void)
 *   Modes of Rte_ModeType_DNMT_VCAN_Tx:
 *   - RTE_MODE_DNMT_VCAN_Tx_TX_DISABLE
 *   - RTE_MODE_DNMT_VCAN_Tx_TX_ENABLE
 *   - RTE_TRANSITION_DNMT_VCAN_Tx
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_GetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean *faultStatus_pu8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *   Std_ReturnType Rte_Call_RP_AppDiagFaultStatus_SetAppDiagFltStatus(CpApDiag_Status faultNum_u16, boolean faultStatus_u8)
 *     Synchronous Server Invocation. Timeout: None
 *     Returned Application Errors: RTE_E_IF_AppDiagFaultStatus_ReturnType
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondMain_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPreCond_CODE) Re_CpApPreCondMain(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondMain
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: Re_CpApPreCondOut
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 10ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondOut_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CpApPreCond_CODE) Re_CpApPreCondOut(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: Re_CpApPreCondOut
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CpApPreCond_STOP_SEC_CODE
#include "CpApPreCond_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
